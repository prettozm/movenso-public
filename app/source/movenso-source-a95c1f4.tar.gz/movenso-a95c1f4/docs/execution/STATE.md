# STATE — tableau de bord de reprise

> **Type : vivant** · Ce fichier ne contient **que le présent**. Aucun
> historique : il vit dans Git, dans [DECISIONS.md](DECISIONS.md) et dans les
> fiches de [`lots/`](lots/). Un STATE qui raconte est un STATE qu'on ne lit
> plus (D-275).
>
> Le **commit** et la **branche** ne sont pas écrits ici, volontairement : ils
> seraient périmés par le commit même qui les écrit. `git log -1` fait foi.

## PHASE

**STABILISATION V1 → B4 (RC).** Référence : l'audit externe
[`audit-stabilisation-v1.md`](audit-stabilisation-v1.md), loti dans
[`lots/`](lots/). Lots S1, S2 et S4 clos ; S3 clos hors reliquats ci-dessous.

## BOUCLE COURANTE

**Correctifs de recette REC-B4-001 : série TERMINÉE** (D-291 → D-298) et
**R2-1 : TERMINÉE** (D-299 → D-302). **Finition éditoriale des six packs
INTÉGRÉE** (D-306, fournitures porteur, go du 2026-08-12) : sources
`donnees/` régénérées depuis les conteneurs (S4.8), preuve d'équivalence
`publier` ↔ fournitures, +10 couvertures de familles judo embarquées,
26 autres au parc sans embarquement (D-245) — republication en cours,
voir « En ligne ».

**PR** : `movenso` #6 et `movenso-public` #6 **fusionnées par le porteur**
(2026-08-12) — plus aucune PR ouverte.

**Chantier COMPOSITIONS ouvert** (dossier
[`lots/compositions-seances.md`](lots/compositions-seances.md), spécification UI
D-314) : maquette soumise et arbitrée (D-315 → D-318, couleurs conservées,
grammaire des planches, huit recommandations). **INTÉGRÉES** : **UI-2 — fiche de
consultation** (D-319 : ouvrir = lire, l'édition passe par le ✎), **UI-1 — liste
Mes | Packs** (D-320 : liseré = discipline dominante), **UI-3 — éditeur**
(D-321 : bandeau dérivé partagé, timeline), **UI-4 — ajout d'étape progressif**
(D-322 : le contenu d'abord ; deux demandes des planches annulées par le journal),
**UI-5 — lecteur** (D-323 : jauge, anneau, « Ensuite » avec le rôle suivant ;
moteur intouché) et **UI-6 — « Continuer »** (D-324 : une entrée, dans les
préférences, donc sans migration). Regarder l'écran avec les vrais packs
y a trouvé **quatre défauts** — identifiant ULID affiché, mot `provenance`
affiché, duplication qui ne rendait pas la copie personnelle, et deux compteurs
contradictoires côte à côte — tous corrigés. **Reste DEUX passes** : **AG-1** (Agenda — le seul ajout métier :
`Planification`, bump de schéma, migration additive, **relecture checker
requise**) et **AG-2** (Calendrier, même donnée, autre rendu). Le lot **E**
(rappels système) reste hors chantier (arbitrage D-290 n° 6).

**Relectures checker : TROIS verdicts, tous TRAITÉS** (D-303, D-304, D-326).
Le dernier couvre toute la série compositions (`6108a0c..96d1225`) : un
constat unique, accepté et corrigé — le nombre d'étapes divergeait entre la
liste et la fiche (kata publié : 26 contre 21), parce que « qu'est-ce qu'un
pas » vivait dans la couche `app/`. `nombreDePas` descend dans le domaine,
et deux compteurs voisins du même objet ont été alignés au passage
(rangs de l'éditeur, notation de la carte « Continuer »).
Relèvements de cliquet **confirmés par le porteur** (D-305, puis 2026-08-13).

**Dépôt du 2026-08-13** : la première tentative a été **refusée par la garde**
(rien n'a été déposé) — une épingle e2e pariait sur le tirage de « Centrer au
hasard », second piège du même dé après D-313. Corrigée (D-325), sans toucher
au produit. **L'app en ligne précède le correctif D-326** : les compteurs
d'étapes y divergent encore sur les katas (judo, jujitsu) — à redéposer au
prochain dépôt.

## GEL

**LEVÉ le 2026-08-13** (D-307, décision porteur : des corrections UX
arrivent). Les corrections UX des parcours existants sont recevables ;
une fonction nouvelle reste soumise au lot courant.

## P0

Aucun.

## P1

- **`REC-B4-001` : socle DÉROULÉ, bloc compositions suspendu** (2026-08-11,
  build `f8c51d6`). Verts : préambule, R0, R3, R4, R5, R6, R6bis, R7 hors
  compositions — résultats et constats dans la fiche. **Neuf entrées en file
  post-recette** (R3-1, R5-1, R6bis-1→4, R7-1, dossier bandeau ×2 —
  la scission Stockage/Sauvegardes est FAITE, D-308). **Reste** : R1/R2/R2bis + trame R4 +
  séance minutée R7, suspendus à l'arbitrage « recetter tel quel ou faire
  évoluer les compositions d'abord » (le porteur penche pour l'évolution).
- **Keystore de publication** : le perdre, c'est perdre définitivement la mise
  à jour de l'app sur Play. Aucune procédure de sauvegarde écrite.

## RESTE À FAIRE

Tout ce qui n'est pas fait — chemin critique v1, décisions humaines
attendues, chantiers post-v1, dette acceptée — vit dans
**[RESTE.md](RESTE.md)** : une ligne par chantier, chacune citant sa source
(D-288). Un chantier clos **sort** du fichier dans le commit qui le clôt —
le journal est la liste du terminé, pas une seconde liste ici. Seuls les
**P0/P1** restent dans ce tableau de bord.

## DERNIÈRE PREUVE

- `npm run verifier` : **vert** — il annonce lui-même ses compteurs.
- CI : **verte** depuis D-270 (elle était rouge six commits durant sans que le
  vérificateur local le voie — lire le run, pas seulement le local).
- **En ligne** : `movenso-public` @ `7e8a726` — app build `c7e1780`
  (schéma 6, movpack v5, **refonte UX des compositions D-319 → D-325**),
  six packs **inchangés** (judo 0.7.6, karaté 0.3.2, jujitsu 0.3.4,
  jjb 0.2.4, taïso 0.2.4, yoga 0.4.4) et source dans le même commit,
  garde du site verte après dépôt, `catalogues` et Pages `success`
  (18:43Z). Le catalogue `packs/index.json` n'a pas bougé : aucun contenu
  n'a changé, seule l'interface.

## PROCHAINE ACTION EXACTE

**AG-1 — l'Agenda** (dossier `lots/compositions-seances.md` §8) : le **seul
ajout métier** du chantier. `Planification { compositionId, date, heure? }` →
**bump de schéma + migration additive**, donc **relecture checker REQUISE**
(D-280). Écrire son CYCLE avant le code (D-251), notamment : part-elle dans la
sauvegarde complète (question ouverte n° 1) ? Vue **Liste d'abord** ; l'Agenda
est une **vue de l'onglet Compositions**, pas un sixième onglet (D-314).

Puis, indépendamment : dérouler **`REC-B4-001` sur appareil** à partir de **R0**.

## FAITS GÉNÉRÉS

> Écrits par `npm run etat`, jamais à la main. `npm run verifier:etat` refuse
> l'écart (D-275) — ces nombres ont menti trop souvent (D-273).

<!-- FAITS:DÉBUT -->
Application : 0.9.0-rc.1
Schéma : 6
Movpack : 5
Tests : 278
Chapitres e2e : 24
Sources de packs : 6/6
Publication : dist-publication/
Fichiers TS (src/) : 68
racine.ts : 1548 lignes
movpack.ts : 666 lignes
<!-- FAITS:FIN -->

## PROCÉDURE DE REPRISE

1. **Git** : vérifier branche, commit, état. Dans `movenso`, **toujours une
   branche, jamais `main`, jamais de fusion**. Dans `movenso-public`, la
   publication directe sur `main` est permise sous conditions — « Deux dépôts,
   deux régimes » dans `CLAUDE.md` (D-267). Si une consigne de démarrage nomme
   la même branche pour les deux dépôts, le **signaler**.
2. **Lire** : ce fichier, [MASTER.md](MASTER.md), le lot courant dans
   [`lots/`](lots/), les sections concernées de [QUALITY.md](QUALITY.md). Du
   journal [DECISIONS.md](DECISIONS.md), **seulement** les décisions désignées
   par ce fichier et par le lot courant — plus la queue si le contexte récent
   manque (D-276). Le lire en entier fait remonter des raisonnements périmés.
3. **Vérifier** : `npm run verifier` (~2 min, tient dans un appel au premier
   plan — ne pas le lancer en tâche de fond pour l'attendre en boucle, D-237).
   Un chapitre seul : `npm run e2e:chapitre <nom>` (~4 s). Charge :
   `npm run campagne:charge`.
4. **Lire le run CI**, pas seulement le vérificateur local (D-270) : ils ne
   couvrent pas la même chose.
5. **Publier** : quatre conditions cumulatives (D-267) — commit `movenso`
   poussé, `npm run verifier` vert sur ce commit, `verifier-catalogues.mjs`
   vert **après** dépôt, et **app + packs + source dans le même commit**. Un
   `git push` n'est pas une publication : vérifier que Pages conclut `success`.
6. **Trois niveaux de vérification** (D-281) : `verifier:rapide` (~13 s, pour
   itérer — il dit ce qu'il ne regarde pas), `verifier` (~2 min, pour clore une
   boucle), `verifier:release` (avant de distribuer).
7. **Publier n'est pas déposer** : `npm run publier` produit dans
   `dist-publication/` et n'écrit nulle part ailleurs ; `npm run verifier:release`
   valide ; `npm run deposer -- --vers <site>` est le seul geste qui écrit dans
   le dépôt public. Contrôler un conteneur reçu : `tools/inspecter-movpack.ts`. Avant d'intégrer un pack
   fourni, TOUJOURS le comparer au publié — c'est ainsi qu'on a vu le karaté
   perdre ses 109 images (D-245) et l'identité du jujitsu dériver (D-247).
8. **Avant de committer** : `npm run etat` si un fait a bougé.
