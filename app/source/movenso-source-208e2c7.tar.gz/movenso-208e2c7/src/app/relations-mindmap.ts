/**
 * RELATIONS — VUE MINDMAP « carte synthétique » (S3.A4, tranche 2 — extraite de
 * relations-visuelle.ts, code déménagé tel quel) : gabarit spatial FIXE + mapping
 * DÉTERMINISTE type métier → slot (D-148→D-154), chips légende/filtre, dépliage
 * « +N » sur place (D-152), connecteurs SVG tracés derrière les cartes (D-153).
 */

import { html, nothing, type TemplateResult } from "lit";
import { ref } from "lit/directives/ref.js";
import type { Bibliotheque, Technique, RoleRelation } from "../domaine/modele.ts";
import type { RelationAffichee } from "../domaine/relations.ts";
import type { MovensoApp } from "./racine.ts";
import { vignetteTechnique } from "./vignette.ts";
import { etat, pousser, nomFamille, iconeRole, pastilleAlerte } from "./relations-commun.ts";

/** ---- Vue MINDMAP « carte synthétique » (D-148, gabarit spatial FIXE + mapping
 *  DÉTERMINISTE — spec porteur) : zone-carte à HAUTEUR FIXE, la technique AU
 *  CENTRE (≈38 % de large), les familles ANCRÉES par un **gabarit spatial
 *  sémantique** — Similaires en HAUT, Enchaînée depuis à GAUCHE, Enchaîne vers à
 *  DROITE, Fondamentaux requis EN DESSOUS, Contre encore en dessous. Chaque
 *  relation est classée par son **type métier réel** (rôle brut du type), JAMAIS
 *  par l'ordre/le nombre/la place restante, et **jamais par repli vers Similaire** :
 *  un type sans rôle mais « fondamental » (id/libellé) va aux Fondamentaux, sinon
 *  à « Autres liens ». 2 cartes représentatives par famille + compte + « +N » (le
 *  reste → Liste filtrée). Légende/filtres en chips (masquent/affichent une
 *  famille) ; recherche par icône ; connecteurs SVG colorés DERRIÈRE les cartes.
 *  Toucher une carte recentre (R4) ; « Centrer » restaure la technique de départ. ---- */
const MM_CAP = 2; // cartes représentatives par famille (le reste → Liste filtrée)

type Slot = "top" | "left" | "right" | "bottom" | "second" | "autres";

/** Mapping DÉTERMINISTE type métier (rôle) → emplacement visuel. */
const relationDisplaySlots: Record<RoleRelation, Slot> = {
  peer: "top", // Similaires
  before: "left", // Enchaînée depuis (précurseurs)
  after: "right", // Enchaîne vers (suites)
  context: "bottom", // Fondamentaux requis / kata
  opposition: "second", // Contre
};
/** Rôle « représentatif » d'un slot (pour l'icône). Comme le prototype, la
 *  famille « Enchaînée depuis » s'illustre d'une flèche → (le sens du flux vers
 *  le centre), pas d'une flèche ← (D-151). */
const ROLE_DE_SLOT: Record<Slot, RoleRelation> = {
  top: "peer", left: "after", right: "after", bottom: "context", second: "opposition", autres: "context",
};
/** Couleur d'une zone — celle du RÔLE qu'elle représente, et rien d'autre.
 *
 *  Elle alimente `data-couleur` (:254), relu pour tracer les connecteurs SVG.
 *  C'était un QUATRIÈME lieu où la table des couleurs vivait, `top` y empruntait
 *  encore `--accent` et deux teintes y étaient recopiées : D-349 a fermé deux
 *  lieux, D-350 en a fermé un troisième et s'est déclaré clos — celui-ci
 *  restait, dans la vue que D-350 nommait « la plus utilisée » (D-352).
 *
 *  Le commentaire d'avant annonçait « indépendante du code couleur des rôles »
 *  et « Enchaînée depuis en VERT, Enchaîne vers en BLEU (inverse des rôles) » :
 *  ni indépendante ni inverse — identique. C'est mot pour mot la faute que le
 *  même commit corrigeait dans l'en-tête de `relations.css`. */
function couleurSlot(slot: Slot): string {
  return slot === "autres" ? "var(--sourdine)" : `var(--role-${ROLE_COULEUR_DE_SLOT[slot]})`;
}
/** Le rôle dont la zone porte la COULEUR. Distinct de `ROLE_DE_SLOT`, qui donne
 *  le rôle dont elle porte l'ICÔNE (`left` s'illustre d'une flèche →, D-151). */
const ROLE_COULEUR_DE_SLOT: Record<Exclude<Slot, "autres">, RoleRelation> = {
  top: "peer", left: "before", right: "after", bottom: "context", second: "opposition",
};
const ORDRE_SLOT: Slot[] = ["top", "left", "right", "bottom", "second", "autres"];
/** Slots dont les cartes s'affichent EN RANGÉE (haut / bas) vs EN COLONNE (côtés). */
const SLOT_RANGEE = new Set<Slot>(["top", "bottom", "second", "autres"]);
/** Nom générique d'un slot quand il regroupe plusieurs libellés (sinon libellé réel). */
const NOM_SLOT: Record<Slot, string> = {
  top: "Similaires", left: "Enchaînée depuis", right: "Enchaîne vers",
  bottom: "Fondamentaux requis", second: "Contre", autres: "Autres liens",
};

/** Slot d'une liaison — partition par TYPE MÉTIER réel (rôle brut du type, sans le
 *  repli `peer` de l'affichage), avec flip de l'inverse dérivé. Un type SANS rôle
 *  mais « fondamental » (id/libellé) → Fondamentaux ; sinon → Autres. JAMAIS de
 *  repli vers Similaire. */
function slotLiaison(b: Bibliotheque, l: RelationAffichee): Slot {
  const def = b.typesRelation.find((t) => t.id === l.typeId);
  let r = def?.role;
  if (r === undefined) {
    const s = `${l.typeId} ${l.libelle}`.toLowerCase();
    if (/kata|fondament|prerequis|prérequis|prealable|préalable|requis|kihon|principe|\bbase\b/.test(s)) return "bottom";
    if (typeof console !== "undefined") console.warn(`[mindmap] relation de type sans rôle « ${l.typeId} » (${l.libelle}) → Autres`);
    return "autres";
  }
  if (!l.directe) { if (r === "after") r = "before"; else if (r === "before") r = "after"; }
  return relationDisplaySlots[r];
}

interface FamilleMindmap { slot: Slot; label: string; liste: RelationAffichee[]; total: number; filtre: string | null; }
/** Tri par priorité éditoriale (D-134), départage stable. */
function parPrioriteAll(liste: RelationAffichee[]): RelationAffichee[] {
  return [...liste].map((l, i) => ({ l, i }))
    .sort((a, z) => (a.l.priorite ?? Infinity) - (z.l.priorite ?? Infinity) || a.i - z.i)
    .map((x) => x.l);
}

/** Trace les LIAISONS hub→familles (D-153, décision porteur : PAS de pointes de
 *  flèche — des liaisons épaisses et propres suffisent, la position donne le
 *  sens) : un tronc part du bord du hub puis se divise en branches vers CHAQUE
 *  carte — éventail vers le haut, accolades vers les côtés, traits courts vers
 *  Fondamentaux, ligne distincte vers Contre. Trait **2 px** (D-154), extrémités
 *  glissées SOUS les cartes (le calque est derrière : contact net garanti).
 *  Mesures DOM (rAF, best-effort), origine = `.rel-mm-monde`. */
function tracerLiensMindmap(container: Element): void {
  try {
    const monde = (container.querySelector(".rel-mm-monde") ?? container) as HTMLElement;
    const svg = monde.querySelector(".rel-mm-liens") as SVGSVGElement | null;
    const hub = monde.querySelector(".rel-mm-hub") as HTMLElement | null;
    if (!svg || !hub) return;
    const cr = monde.getBoundingClientRect();
    if (cr.width === 0) return;
    svg.setAttribute("viewBox", `0 0 ${cr.width} ${cr.height}`);
    const rel = (r: DOMRect) => ({ l: r.left - cr.left, t: r.top - cr.top, r: r.right - cr.left, b: r.bottom - cr.top, cx: (r.left + r.right) / 2 - cr.left, cy: (r.top + r.bottom) / 2 - cr.top });
    const h = rel(hub.getBoundingClientRect());
    const GAP = 11; // longueur du tronc avant division
    const ANCRE = 2; // l'extrémité plonge SOUS la carte (contact sans couture)
    // S1.11 (D-166) : éléments SVG TYPÉS (createElementNS) — plus d'innerHTML
    // dans l'app ; attributs identiques à l'ancienne concaténation, rendu
    // inchangé (Mindmap gelée).
    const chemins: SVGPathElement[] = [];
    const branches = Array.from(monde.querySelectorAll(".rel-mm-branche"));

    branches.forEach((brEl) => {
      const br = brEl as HTMLElement;
      const slot = br.dataset.slot ?? "";
      const col = br.dataset.couleur ?? "var(--sourdine)";
      const cartes = Array.from(br.querySelectorAll(".rel-mm-carte")).map((c) => rel(c.getBoundingClientRect()));
      if (cartes.length === 0) return;
      const chemin = (d: string) => {
        const p = document.createElementNS("http://www.w3.org/2000/svg", "path");
        p.setAttribute("d", d);
        p.setAttribute("style", `stroke:${col};fill:none;stroke-width:2;opacity:.9`);
        p.setAttribute("stroke-linecap", "round");
        chemins.push(p);
      };
      const ligne = (ax: number, ay: number, bx: number, by: number) => chemin(`M${ax} ${ay} L${bx} ${by}`);
      const brancheV = (ax: number, ay: number, tx: number, ty: number) => chemin(`M${ax} ${ay} C ${ax} ${(ay + ty) / 2} ${tx} ${(ay + ty) / 2} ${tx} ${ty}`);
      const brancheH = (ax: number, ay: number, tx: number, ty: number) => chemin(`M${ax} ${ay} C ${(ax + tx) / 2} ${ay} ${(ax + tx) / 2} ${ty} ${tx} ${ty}`);

      if (slot === "top") {
        const ay = h.t - GAP; ligne(h.cx, h.t, h.cx, ay);
        cartes.forEach((c) => brancheV(h.cx, ay, c.cx, c.b - ANCRE)); // extrémité sous la carte
      } else if (slot === "left") {
        const ax = h.l - GAP; ligne(h.l, h.cy, ax, h.cy);
        cartes.forEach((c) => brancheH(ax, h.cy, c.r - ANCRE, c.cy));
      } else if (slot === "right") {
        const ax = h.r + GAP; ligne(h.r, h.cy, ax, h.cy);
        cartes.forEach((c) => brancheH(ax, h.cy, c.l + ANCRE, c.cy));
      } else if (slot === "bottom" || slot === "second" || slot === "autres") {
        // Zones SOUS le hub (D-378). Les liens s'arrêtaient au-dessus du titre de
        // famille — des moignons flottants qui ne touchaient AUCUNE carte, d'où
        // « incomplets ». Deux régimes :
        //  - synthèse (rangée courte) : une courbe ATTEINT chaque carte ;
        //  - déplié (grille de N cartes, ex. un kata qui en contient 15) : un
        //    tronc net jusqu'au titre — tirer une courbe vers chacune croiserait
        //    tout ; la grille sous le titre se lit alors comme « contenue ».
        const brBox = rel(br.getBoundingClientRect());
        if (br.classList.contains("depliee")) {
          ligne(h.cx, h.b, h.cx, Math.max(h.b + 12, brBox.t - 4));
        } else {
          cartes.forEach((c) => brancheV(h.cx, h.b, c.cx, c.t + ANCRE));
        }
      }
    });
    svg.replaceChildren(...chemins);
  } catch { /* mesure best-effort : jamais bloquant */ }
}

export function vueMindmap(app: MovensoApp, b: Bibliotheque, centre: Technique, liaisons: RelationAffichee[]): TemplateResult {
  // Partition DÉTERMINISTE par type métier → slot (jamais par ordre/place/repli).
  const parSlot = new Map<Slot, RelationAffichee[]>();
  for (const l of liaisons) { const s = slotLiaison(b, l); parSlot.set(s, [...(parSlot.get(s) ?? []), l]); }
  const toutesFamilles: FamilleMindmap[] = ORDRE_SLOT
    .filter((s) => (parSlot.get(s)?.length ?? 0) > 0)
    .map((slot) => {
      const liste = parSlot.get(slot)!;
      const libs = [...new Set(liste.map((l) => l.libelle))];
      return {
        slot,
        label: libs.length === 1 ? libs[0]! : NOM_SLOT[slot],
        liste: parPrioriteAll(liste), total: liste.length,
        filtre: libs.length === 1 ? libs[0]! : null,
      };
    });
  // Chips = légende ET filtre (masquent/affichent une famille). Une famille
  // masquée n'occupe aucune zone ; son chip reste (grisé) pour la ré-afficher.
  const familles = toutesFamilles.filter((f) => !etat.mmMasque.has(f.slot));

  // Nouvelle fonction à chaque rendu → Lit relance le ref. Deux modes (D-152) :
  // SYNTHÈSE (aucune famille dépliée) — la scène est MISE À L'ÉCHELLE pour tenir
  // dans la hauteur réellement disponible (D-150 : la barre d'URL du navigateur
  // réduit le viewport) ; EXPLORATION (« +N » déplié) — échelle 1, la zone
  // DÉFILE verticalement pour parcourir la famille, « réduire » ramène à la
  // synthèse. Les connecteurs sont tracés après, sur les positions rendues.
  const etendu = etat.mmDeplie.size > 0;
  const dessiner = (el?: Element) => {
    if (!el) return;
    requestAnimationFrame(() => {
      const scene = el.querySelector(".rel-mm-scene") as HTMLElement | null;
      if (scene) {
        scene.style.transform = ""; // re-mesure à l'échelle 1
        if (!etendu) {
          const k = Math.min(1, el.clientHeight / Math.max(1, scene.scrollHeight), el.clientWidth / Math.max(1, scene.scrollWidth));
          if (k < 0.999) scene.style.transform = `scale(${k})`;
        }
      }
      requestAnimationFrame(() => tracerLiensMindmap(el));
    });
  };
  const fam = nomFamille(b, centre);

  return html`
    <div class="rel-mm-chips" role="list" aria-label="Familles de relations (légende / filtre)">
      ${toutesFamilles.map((f) => {
        const masque = etat.mmMasque.has(f.slot);
        return html`<button role="listitem" class="rel-mm-chip slot--${f.slot} ${masque ? "masque" : ""}"
          @click=${() => { masque ? etat.mmMasque.delete(f.slot) : etat.mmMasque.add(f.slot); app.requestUpdate(); }}
          title=${masque ? `Afficher « ${f.label} »` : `Masquer « ${f.label} »`}>
          ${iconeRole(ROLE_DE_SLOT[f.slot])}<span class="rel-mm-chip-lib">${f.label}</span><span class="rel-mm-chip-n">${f.total}</span>
        </button>`;
      })}
    </div>
    <div class="rel-mm-radial ${etendu ? "defile" : ""}" ${ref(dessiner)}>
      <div class="rel-mm-monde">
        <svg class="rel-mm-liens" aria-hidden="true"></svg>
        <div class="rel-mm-scene">
          <button class="rel-mm-hub" @click=${() => app.ouvrirFiche(centre.id)} title="Ouvrir la fiche">
            <span class="rel-mm-hub-media">${vignetteTechnique(app, centre)}</span>
            <span class="rel-mm-hub-nom">${centre.nom}${pastilleAlerte(app, centre.id)}</span>
            ${fam ? html`<span class="rel-mm-hub-sous">${fam}</span>` : nothing}
            <span class="rel-mm-hub-badge">${liaisons.length} relation${liaisons.length > 1 ? "s" : ""}</span>
          </button>
          ${familles.map((f) => familleMindmap(app, b, f))}
        </div>
      </div>
    </div>
  `;
}

/** Une famille ancrée dans sa zone du gabarit : titre coloré (icône + nom, SANS
 *  compteur — le compte vit sur les chips, comme le prototype) + jusqu'à MM_CAP
 *  cartes représentatives + « +N ». Couleur PROPRE à la Mindmap (`slot--*`). */
function familleMindmap(app: MovensoApp, b: Bibliotheque, f: FamilleMindmap): TemplateResult {
  const role = ROLE_DE_SLOT[f.slot];
  const dispo = SLOT_RANGEE.has(f.slot) ? "rangee" : "colonne";
  // « +N » déplie la famille SUR PLACE dans la Mindmap (D-152) — jamais de saut
  // vers la Liste ; « réduire » ramène à la synthèse. Le titre reste le chemin
  // vers la Liste filtrée (vue exhaustive).
  const deplie = etat.mmDeplie.has(f.slot);
  const visibles = deplie ? f.liste : f.liste.slice(0, MM_CAP);
  const reste = f.total - visibles.length;
  const ouvrirListe = () => { etat.vue = "liste"; etat.filtre = f.filtre; app.requestUpdate(); };
  const basculer = () => { deplie ? etat.mmDeplie.delete(f.slot) : etat.mmDeplie.add(f.slot); app.requestUpdate(); };
  return html`
    <section class="rel-mm-branche slot--${f.slot} ${dispo} ${deplie ? "depliee" : ""}" style="grid-area:${f.slot}" data-slot=${f.slot} data-couleur=${couleurSlot(f.slot)}>
      <button class="rel-mm-label" @click=${ouvrirListe} title="Voir « ${f.label} » dans la Liste">
        ${SLOT_RANGEE.has(f.slot) ? iconeRole(role) : nothing}<span class="rel-mm-label-txt">${f.label}</span>
      </button>
      <div class="rel-mm-cartes">
        ${visibles.map((l) => noeudMindmap(app, b, l, f.slot))}
        ${reste > 0 ? html`<button class="rel-mm-plus" @click=${basculer} title="Déplier les ${reste} autres ici">+${reste}</button>` : nothing}
        ${deplie ? html`<button class="rel-mm-plus" @click=${basculer} title="Revenir à la vue synthétique">réduire</button>` : nothing}
      </div>
    </section>
  `;
}

/** Carte satellite : vignette 16/10 avec **badge d'icône de rôle** en haut-gauche
 *  (comme le prototype) + nom (≤2 lignes) + famille ; couleur par slot. Clic =
 *  recentrage (R4) ; raison en infobulle. */
function noeudMindmap(app: MovensoApp, b: Bibliotheque, l: RelationAffichee, slot: Slot): TemplateResult {
  const t = app.technique(l.techniqueId);
  if (!l.presente || !t) return html`<div class="rel-mm-carte slot--${slot} absente" title="Absente de la bibliothèque">absente</div>`;
  const fam = nomFamille(b, t);
  return html`
    <button class="rel-mm-carte slot--${slot}" title=${l.note ?? nothing} @click=${() => pousser(app, t.id)}>
      <span class="rel-mm-carte-media">${vignetteTechnique(app, t)}<span class="rel-mm-carte-badge">${iconeRole(ROLE_DE_SLOT[slot])}</span></span>
      <span class="rel-mm-carte-nom">${t.nom}${pastilleAlerte(app, t.id)}</span>
      ${fam ? html`<span class="rel-mm-carte-fam">${fam}</span>` : nothing}
    </button>
  `;
}
