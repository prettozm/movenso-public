/**
 * Feuille de capture — 3 gestes maximum, rattachement OPTIONNEL
 * (increment-1.md §2 : le moment chaud n'exige jamais de nommer).
 * Sert aussi le rattachement différé d'une capture « à rattacher ».
 */

import { html, nothing, type TemplateResult } from "lit";
import { chercherTechniques } from "../domaine/recherche.ts";
import type { Provenance } from "../domaine/modele.ts";
import { vignetteTechnique } from "./vues.ts";
import type { MovensoApp } from "./racine.ts";

export interface EtatCapture {
  etape: "contenu" | "apercu" | "note" | "rattacher";
  note: string;
  /** `| undefined` explicites : le contenu s'ABANDONNE depuis l'aperçu
   *  (lot 4 §6) — exactOptionalPropertyTypes. */
  video?: File | undefined;
  /** Lien vers un média en ligne (YouTube ou autre) — alternative à filmer. */
  lien?: string | undefined;
  saisieLien?: boolean;
  /** Aperçu du contenu capturé (lot 4 §6) : URL objet de la vidéo, révoquée
   *  en quittant l'aperçu ; `camera` distingue « Refilmer » de « Choisir un
   *  autre fichier ». */
  apercuUrl?: string | undefined;
  camera?: boolean;
  /** Recherche de rattachement élargie à toutes les disciplines (§7.A). */
  chercherPartout?: boolean;
  /** Nature de la contribution : `personnel` par défaut ; la source est posée à
   *  plat (D-379), facultative, plus derrière une bascule (lot 4 §8 révisé). */
  provenance?: Provenance;
  attribution?: string;
  /** « Que faire de cette capture ? » (lot 4 §16) — posée par le retour
   *  Android quand un contenu existe déjà, jamais de perte silencieuse. */
  question?: boolean;
  demarreA: number;
  /** Depuis une composition : la capture peut devenir un repère de celle-ci. */
  compositionCible?: string;
  rattacherSeul?: string; // id d'une contribution existante à rattacher
  rechercheRattache?: string;
  /** Nom d'une technique à créer (fermeture 1, D-023 : la création est un
   *  chemin toujours visible, pas un repli caché derrière la recherche). */
  nouveauNom?: string;
  /** Cible d'une technique créée à la volée quand la discipline n'est pas évidente (D-017). */
  disciplineChoisieId?: string;
  disciplineNom?: string;
}

export function gabaritCapture(app: MovensoApp): TemplateResult {
  const capture = app.capture!;
  const corps = capture.question
    ? etapeQuestion(app)
    : capture.etape === "contenu"
      ? etapeContenu(app)
      : capture.etape === "apercu"
        ? etapeApercu(app)
        : capture.etape === "note"
          ? etapeNote(app)
          : etapeRattacher(app);
  const titre = capture.rattacherSeul ? "Rattacher" : "Capturer";
  const geste = capture.question
    ? "Que faire de cette capture ?"
    : capture.rattacherSeul
    ? "Un seul geste"
    : capture.etape === "contenu"
      ? "Geste 1 / 3 — le contenu"
      : capture.etape === "apercu"
        ? "Geste 1 / 3 — vérifier le contenu"
        : capture.etape === "note"
          ? "Geste 2 / 3 — la note"
          : "Geste 3 / 3 — sais-tu où le ranger ?";
  return html`
    <div class="voile" @click=${() => app.fermerCapture()}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label=${titre}>
      <div class="prise"></div>
      <h2>${titre}</h2>
      <div class="geste">${geste}</div>
      ${corps}
    </div>
  `;
}

/** Exportée : le panneau « Ajouter » (lot 4 §2) déclenche le même geste —
 *  un seul chemin vidéo, toujours via l'aperçu. */
function choisirFichierVideo(app: MovensoApp, camera: boolean): void {
  const champ = document.createElement("input");
  champ.type = "file";
  champ.accept = "video/*";
  if (camera) champ.setAttribute("capture", "environment");
  champ.onchange = () => {
    const fichier = champ.files?.[0];
    if (!fichier || !app.capture) return;
    if (app.capture.apercuUrl) URL.revokeObjectURL(app.capture.apercuUrl);
    // Aperçu AVANT tout (lot 4 §6) : Utiliser / Refilmer / Abandonner.
    app.capture = { ...app.capture, video: fichier, apercuUrl: URL.createObjectURL(fichier), camera, etape: "apercu" };
  };
  champ.click();
}

/** « Que faire de cette capture ? » (lot 4 §16) : un contenu existe et le
 *  retour veut sortir — Garder pour plus tard / Continuer / Abandonner.
 *  Rien ne se perd en silence, rien ne s'enregistre sans décision. */
function etapeQuestion(app: MovensoApp): TemplateResult {
  const capture = app.capture!;
  const gardable = (capture.provenance ?? "personnel") !== "ressource" || (capture.attribution ?? "").trim() !== "";
  return html`
    <div class="gestes-ajouter">
      <button class="option-ajouter" ?disabled=${!gardable}
        title=${gardable ? "" : "Une ressource a besoin de sa source avant d'être conservée"}
        @click=${() => void app.terminerCapture(null)}>
        Garder pour plus tard <span>tu la retrouveras dans Plus › À vérifier › Captures à rattacher</span>
      </button>
      <button class="option-ajouter" @click=${() => (app.capture = { ...capture, question: false })}>
        Continuer <span>revenir où tu en étais</span>
      </button>
      <button class="option-ajouter" @click=${() => app.fermerCapture()}>
        Abandonner <span>rien ne sera enregistré</span>
      </button>
    </div>
  `;
}

/** Aperçu du contenu capturé (lot 4 §6) — rien n'est enregistré ici : le
 *  fichier ne s'écrit qu'à la toute fin (jamais d'orphelin sur abandon). */
function etapeApercu(app: MovensoApp): TemplateResult {
  const capture = app.capture!;
  const quitterApercu = (suite: Partial<EtatCapture>) => {
    if (capture.apercuUrl) URL.revokeObjectURL(capture.apercuUrl);
    app.capture = { ...capture, apercuUrl: undefined, ...suite };
  };
  const domaine = (lien: string): string => {
    if (/youtube\.com|youtu\.be/.test(lien)) return "YouTube — lecture en ligne";
    try {
      return `${new URL(lien).hostname} — lecture en ligne`;
    } catch {
      return "lien — lecture en ligne";
    }
  };
  return html`
    ${capture.video && capture.apercuUrl
      ? html`<div class="media-video"><video src=${capture.apercuUrl} controls playsinline autoplay muted></video></div>
          <div class="apercu-infos">${(capture.video.size / 1e6).toFixed(1)} Mo — rien n'est encore enregistré</div>`
      : nothing}
    ${capture.lien
      ? html`<div class="apercu-lien">
            <span class="joint">🔗 ${capture.lien}</span>
            <div class="apercu-infos">${domaine(capture.lien)} — l'URL est conservée telle quelle</div>
          </div>`
      : nothing}
    <div class="actions">
      <button class="bouton" @click=${() => quitterApercu({ video: undefined, lien: undefined, etape: "contenu" })}>
        Abandonner
      </button>
      ${capture.video
        ? html`<button class="bouton" @click=${() => choisirFichierVideo(app, capture.camera ?? false)}>
            ${capture.camera ? "Refilmer" : "Choisir un autre fichier"}
          </button>`
        : html`<button class="bouton" @click=${() => quitterApercu({ saisieLien: true, etape: "contenu" })}>
            Modifier
          </button>`}
      <button class="bouton principal" @click=${() => quitterApercu({ etape: "note" })}>Utiliser</button>
    </div>
  `;
}

function etapeContenu(app: MovensoApp): TemplateResult {
  const capture = app.capture!;
  return html`
    <div class="choix-double">
      <button @click=${() => choisirFichierVideo(app, true)}>
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="14" height="12" rx="2"/><path d="m16 10 6-3v10l-6-3"/></svg>
        Filmer <span class="indice">caméra, hors ligne</span>
      </button>
      <button @click=${() => (app.capture = { ...app.capture!, etape: "note" })}>
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
        Noter <span class="indice">un mot peut suffire</span>
      </button>
    </div>
    <div class="choix-secondaire">
      <button class="action-douce" @click=${() => choisirFichierVideo(app, false)}>
        ⤒ Ajouter une vidéo existante <span>(depuis l'appareil, stockée hors ligne)</span>
      </button>
      ${capture.saisieLien
        ? html`<div class="creation-discipline" style="margin-top:6px">
            <input placeholder="Coller un lien (YouTube ou autre)…" aria-label="Lien de la vidéo" autofocus .value=${capture.lien ?? ""}
                   @keydown=${(e: KeyboardEvent) => {
                     if (e.key === "Enter") {
                       const v = (e.target as HTMLInputElement).value.trim();
                       if (v) app.capture = { ...capture, lien: v, etape: "apercu" };
                     }
                   }}>
            <button class="bouton principal"
              @click=${(e: Event) => {
                const v = (e.target as HTMLElement).parentElement!.querySelector("input")!.value.trim();
                if (v) app.capture = { ...capture, lien: v, etape: "apercu" };
              }}>OK</button>
          </div>`
        : html`<button class="action-douce" @click=${() => (app.capture = { ...capture, saisieLien: true })}>
            🔗 Coller un lien <span>(YouTube ou autre — lecture en ligne)</span>
          </button>`}
    </div>
  `;
}

function etapeNote(app: MovensoApp): TemplateResult {
  const capture = app.capture!;
  const surSaisie = (e: InputEvent) => {
    app.capture = { ...capture, note: (e.target as HTMLTextAreaElement).value };
  };
  const provenance = capture.provenance ?? "personnel";
  const choisir = (p: Provenance) =>
    (app.capture = { ...capture, provenance: p, ...(p === "personnel" ? { attribution: "" } : {}) });
  const pretPourSuite = provenance !== "ressource" || (capture.attribution ?? "").trim() !== "";
  return html`
    ${capture.video
      ? html`<span class="joint">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
          vidéo jointe (${(capture.video.size / 1e6).toFixed(1)} Mo)
        </span><div style="height:10px"></div>`
      : nothing}
    ${capture.lien ? html`<span class="joint">🔗 ${capture.lien}</span><div style="height:10px"></div>` : nothing}
    <textarea class="champ-note"
              placeholder="Un mot peut suffire (« la banane »). Une vidéo peut suffire. Développe si tu veux."
              .value=${capture.note} @input=${surSaisie} autofocus></textarea>
    <!-- Source posée à plat (D-379) : par défaut « Moi », choix facultatif — plus
         de bascule « Ce contenu vient de quelqu'un d'autre », qui était presque
         accusatoire (constat porteur). Une capture reste valide sans source. -->
    <div class="source-capture" style="margin-top:12px">
      <div class="source-capture-tete">Source <span>facultatif</span></div>
      <div class="chips-filtres" style="padding:6px 0 0" aria-label="D'où vient ce contenu ?">
        <button class="chip-filtre ${provenance === "personnel" ? "actif" : ""}" @click=${() => choisir("personnel")}>Moi</button>
        <button class="chip-filtre ${provenance === "enseignement" ? "actif" : ""}" @click=${() => choisir("enseignement")}>Mon prof / club</button>
        <button class="chip-filtre ${provenance === "ressource" ? "actif" : ""}" @click=${() => choisir("ressource")}>Une ressource</button>
      </div>
      ${provenance !== "personnel"
        ? html`<div style="margin-top:8px">
            <input class="champ-note" style="min-height:0" aria-label=${provenance === "enseignement" ? "Qui l'enseigne ?" : "Source"}
                   placeholder=${provenance === "enseignement" ? "Qui l'enseigne ? (ex. Club, Sensei Dupont)" : "Source (obligatoire — ex. chaîne, livre)"}
                   .value=${capture.attribution ?? ""}
                   @input=${(e: InputEvent) => (app.capture = { ...app.capture!, attribution: (e.target as HTMLInputElement).value })}>
          </div>`
        : nothing}
    </div>
    <div class="actions">
      <button class="bouton" @click=${() => app.fermerCapture()}>Annuler</button>
      <button class="bouton principal" ?disabled=${!pretPourSuite}
        @click=${() => (app.capture = { ...app.capture!, etape: "rattacher" })}>
        Rattacher →
      </button>
    </div>
  `;
}

function etapeRattacher(app: MovensoApp): TemplateResult {
  const capture = app.capture!;
  const b = app.bibliotheque!;
  const suggestion = !capture.rattacherSeul && app.ecran.type === "fiche" ? app.technique(app.ecran.techniqueId) : undefined;
  const requete = capture.rechercheRattache ?? "";
  // §7.A : chercher d'abord dans la discipline présélectionnée, élargir sur demande.
  const cadre = capture.chercherPartout ? undefined : capture.disciplineChoisieId;
  const resultats = requete.trim()
    ? chercherTechniques(b, requete, 30)
        .filter((t) => !cadre || t.disciplineId === cadre)
        .slice(0, 6)
    : [];
  const nomDiscipline = (id: string) => b.disciplines.find((d) => d.id === id)?.nom ?? "";
  const surSaisie = (e: InputEvent) => {
    app.capture = { ...capture, rechercheRattache: (e.target as HTMLInputElement).value };
  };
  // Reprise d'une capture conservée (lot 4 §9) : son contenu se consulte,
  // son texte se modifie, elle se supprime — avec confirmation.
  const reprise = capture.rattacherSeul ? b.contributions.find((c) => c.id === capture.rattacherSeul) : undefined;
  return html`
    ${reprise
      ? html`<div class="reprise-contenu">
          <textarea class="champ-note" style="min-height:52px" .value=${reprise.description ?? ""}
            placeholder="Ton mot, ton libellé — modifiable ici"
            @change=${(e: Event) => void app.majContribution(reprise.id, (e.target as HTMLTextAreaElement).value)}></textarea>
          ${reprise.medias.map((m) =>
            m.type === "local"
              ? html`<movenso-video-locale .app=${app} .mediaId=${m.id}></movenso-video-locale>`
              : html`<span class="joint" style="margin-top:6px">🔗 ${m.ref}</span>`,
          )}
          ${reprise.provenance !== "personnel"
            ? html`<div class="apercu-infos">
                ${reprise.provenance === "enseignement" ? "Enseignement" : "Ressource"}${reprise.attribution ? ` · ${reprise.attribution}` : ""}
                — la provenance choisie est conservée
              </div>`
            : nothing}
          <button class="action-douce" style="margin:8px 0"
            @click=${() => {
              app.demanderConfirmation({
                titre: "Supprimer cette capture ?",
                corps: "Réversible — un snapshot est conservé.",
                bouton: "Supprimer la capture",
                action: () => { void app.supprimerContribution(reprise.id); app.fermerCapture(); },
              });
            }}>
            ✕ Supprimer cette capture <span>réversible — snapshot conservé</span>
          </button>
        </div>`
      : nothing}
    ${suggestion
      ? html`<span class="joint">Suggestion : ${suggestion.nom} (fiche ouverte)</span><div style="height:8px"></div>`
      : nothing}
    ${capture.compositionCible && !capture.rattacherSeul
      ? html`<button class="action-douce" style="width:100%; margin-bottom:8px"
          @click=${() => void app.terminerCaptureRepere()}>
          ⧉ Ajouter comme repère à « ${app.bibliotheque!.compositions.find((c) => c.id === capture.compositionCible)?.nom ?? "la composition"} »
          <span>le mot et la vidéo rejoignent la composition, pas une fiche</span>
        </button>`
      : nothing}
    <div class="recherche" style="margin:0">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
      <input placeholder="À quelle technique ?" aria-label="Chercher la technique à rattacher" autocomplete="off" .value=${requete} @input=${surSaisie}>
    </div>
    <div class="resultats" style="padding:6px 0 0">
      ${suggestion && !requete.trim()
        ? html`<button class="resultat" @click=${() => void app.terminerCapture(suggestion.id)}>
            <span>${suggestion.nom}</span><span class="jp">${suggestion.nomTraditionnel ?? ""}</span><span class="fam">suggérée</span>
          </button>`
        : nothing}
      ${resultats.map(
        (t) => html`<button class="resultat" @click=${() => void app.terminerCapture(t.id)}>
          ${vignetteTechnique(app, t)}
          <span class="resultat-nom">${t.nom}</span><span class="jp">${t.nomTraditionnel ?? ""}</span>
          ${capture.chercherPartout ? html`<span class="fam">${nomDiscipline(t.disciplineId)}</span>` : nothing}
        </button>`,
      )}
      ${requete.trim() && resultats.length === 0
        ? html`<p class="fil-vide" style="padding:6px 0 0">
            Rien de ce nom${cadre ? ` dans ${nomDiscipline(cadre)}` : ""} — crée-la ci-dessous.
          </p>`
        : nothing}
      ${cadre && requete.trim()
        ? html`<button class="action-douce" style="margin-top:6px"
            @click=${() => (app.capture = { ...capture, chercherPartout: true })}>
            Chercher dans toutes les disciplines <span>(au-delà de ${nomDiscipline(cadre)})</span>
          </button>`
        : nothing}
      ${gabaritCreation(app, requete.trim())}
    </div>
    <div class="actions">
      <button class="bouton" @click=${() => app.fermerCapture()}>Annuler</button>
      ${capture.rattacherSeul
        ? nothing
        : html`<button class="bouton" title="Tu la retrouveras dans Plus › À vérifier › Captures à rattacher"
            @click=${() => void app.terminerCapture(null)}>Garder pour plus tard</button>`}
    </div>
  `;
}

/** Création à la volée — chemin TOUJOURS visible (fermeture 1, D-023) : la
 *  technique se nomme ici, la discipline se choisit ou se nomme quand elle
 *  n'est pas évidente — l'app fonctionne sans aucun contenu préinstallé (D-017). */
function gabaritCreation(app: MovensoApp, requete: string): TemplateResult {
  const capture = app.capture!;
  const b = app.bibliotheque!;
  const nom = (capture.nouveauNom ?? requete).trim();
  const contexteFiche = app.ecran.type === "fiche" ? app.technique(app.ecran.techniqueId)?.disciplineId : undefined;
  const choixNecessaire = b.disciplines.length > 1 && !contexteFiche;
  const choisie = capture.disciplineChoisieId ?? contexteFiche ?? b.disciplines[0]?.id;
  const creer = () => {
    if (!nom) return;
    void app.terminerCapture(null, nom, {
      ...(choisie ? { disciplineId: choisie } : {}),
      ...(capture.disciplineNom ? { disciplineNom: capture.disciplineNom } : {}),
    });
  };
  return html`
    <div class="section-titre" style="padding:12px 4px 2px">Ou créer une nouvelle technique</div>
    <div style="padding:2px 0">
      <input class="champ-note champ-nouveau-nom" style="min-height:0" aria-label="Nom de la nouvelle technique"
             placeholder="Nom de la nouvelle technique…"
             .value=${capture.nouveauNom ?? requete}
             @input=${(e: InputEvent) => (app.capture = { ...capture, nouveauNom: (e.target as HTMLInputElement).value })}>
    </div>
    ${b.disciplines.length === 0
      ? html`<div style="padding:6px 0 2px">
          <input class="champ-note champ-discipline" style="min-height:0" aria-label="Discipline" placeholder="Dans quelle discipline ? (ex. Judo, Boxe…)"
                 .value=${capture.disciplineNom ?? ""}
                 @input=${(e: InputEvent) => (app.capture = { ...capture, disciplineNom: (e.target as HTMLInputElement).value })}>
        </div>`
      : nothing}
    ${choixNecessaire
      ? html`<div class="chips-filtres" style="padding:8px 0 2px">
          ${b.disciplines.map(
            (d) => html`<button class="chip-filtre ${choisie === d.id ? "actif" : ""}"
              @click=${() => (app.capture = { ...capture, disciplineChoisieId: d.id })}>${d.nom}</button>`,
          )}
        </div>`
      : nothing}
    <button class="resultat creer" ?disabled=${!nom} @click=${creer}>
      <span>＋ Créer ${nom ? `« ${nom} »` : "cette technique"}</span><span class="fam">et y rattacher la capture</span>
    </button>
  `;
}
