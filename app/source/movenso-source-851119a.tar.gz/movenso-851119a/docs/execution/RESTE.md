# RESTE — tout ce qui n'est pas fait

> **Type : vivant** · Une ligne par chantier, chacune **citant sa source**
> (décision, fiche, document). Règle de vie (D-288) :
>
> - un chantier qui se **termine** sort d'ici **dans le commit qui le clôt** —
>   il n'y a pas de « liste du terminé » : le journal
>   ([DECISIONS.md](DECISIONS.md)) EST cette liste, et Git garde la ligne
>   supprimée ;
> - un chantier qui **naît** entre ici dans le commit qui le fait naître ;
> - ce fichier ne porte **aucun détail** : il pointe. Le détail vit dans la
>   source citée — une copie divergerait (D-253).
>
> Les **P0/P1** vivent dans [STATE.md](STATE.md) (tableau de bord de reprise),
> pas ici. Les **limites assumées** vivent dans
> [KNOWN_LIMITATIONS.md](../KNOWN_LIMITATIONS.md) (D-216), pas ici.
>
> **États et propriétaires (D-289)** : chaque ligne du chemin critique porte
> qui la tient — `(porteur)`, `(agent)`, ou `(bloqué : <quoi>)` quand elle
> attend un échange ou un arbitrage. Ailleurs, le marqueur n'apparaît que
> s'il dit quelque chose. L'état vit **sur la ligne**, jamais dans un
> emplacement : déplacer un fichier pour dire son statut est une copie
> d'état qu'aucune garde ne tient.
>
> **Un sujet qui dépasse une ligne gagne une FICHE** : `lots/<sujet>.md`
> (le patron : [S1-10-dossier-stockage.md](lots/S1-10-dossier-stockage.md)),
> pointée depuis sa ligne. La fiche ne déménage **jamais** — c'est la ligne
> qui vit et meurt ici, et la clôture s'inscrit au journal.

## Chemin critique vers la v1

- `(porteur)` **REC-B4-001 sur appareil**, R0 d'abord — le P1 de STATE ;
  repasses manuels raccrochés : REC-243-001, REC-249-001, REC-255-001 (R7).
- `(agent, sur retour de recette)` **Correctifs de recette** qui en sortiront
  (seuls recevables sous gel D-240, avec le contenu et la dette structurelle).
- `(porteur)` **Relectures checker en session neuve** (D-280) : lot
  D-271→D-283, puis boucles D-284→D-289 — verdicts au journal.
- `(porteur)` **Fusion de la branche** `claude/movenso-reprise-oa46uj`
  (D-284→D-289).
- `(porteur)` **PR `movenso-public` #6** (garde du site, D-285).
- `(porteur)` **Keystore** : poser le secret `ANDROID_DEBUG_KEYSTORE_B64`
  (commande dans D-110) et écrire la procédure de sauvegarde — le P1 de STATE.
- `(porteur)` **Protéger `main` côté GitHub** (D-283) — droits
  d'administration.
- `(bloqué : arbitrage porteur)` **Publication automatisée** (D-283) : trois
  voies, préconisation (b).
- `(porteur)` **Contenu : versions détaillées des deux katas** (Goshin-jutsu,
  Nage-no-kata) — il les dicte (D-238/D-239).
- `(porteur)` **Soumission Play + bêta interne** — avec la note de
  réinstallation Judo/Jujitsu (D-247, KNOWN_LIMITATIONS).
- `(porteur)` **Config du lanceur de session** : ne plus assigner de branche
  de travail à `movenso-public` (constat D-284) — hors dépôt.

## Sessions dédiées réservées (sur demande explicite du porteur)

- `(bloqué : ouverture sur demande du porteur)` **Bandeau de persistance** —
  spécifié et arbitré (D-257/D-259), non implémenté.
- `(bloqué : ouverture sur demande du porteur)` **Compositions / séances** —
  **instruite** : maquettes analysées, arbitrages posés (D-290), confrontation
  au modèle réel faite — fiche
  [lots/compositions-seances.md](lots/compositions-seances.md).

## Post-v1 — chantiers nommés

- **PWA / service worker** : démarrage hors connexion, installation, mises à
  jour contrôlées de l'app web (D-163, S1.8 option B).
- **Registre des packs installés** : mémoriser la version éditoriale — champ
  optionnel, sans migration (D-222, KNOWN_LIMITATIONS).
- **Stockage hybride / emplacement choisi** `Documents/movenso` (D-167,
  dossier S1.10 option 2) — déclenchable sur besoin réel.
- **ZIP64** : exports au-delà de ~4 Go (D-166).
- **Fin de la décomposition de `racine.ts`** : navigation/pile et rendu à
  sortir par composition (D-274).
- **Compositions : embranchements** (variante, « si… alors », D-234) et
  **réaction ciblée** entre deux pas (D-235).
- **Compositions à rôles > 6** : mise en page au-delà de la colonne unique
  (D-231).

## Dette technique acceptée (surveillée, non planifiée)

- Médias **multi-Go non mesurés** en environnement contraint (REC-S2-016).
- **TalkBack** : traversée exhaustive non certifiée (D-172) — remontées
  utilisateur font foi.
- **21 délais fixes** assumés dans l'e2e (durées réelles, tailles OPFS).
- Comportements **natifs Android** hors portée e2e web (garde D-110,
  `Filesystem` D-106/D-111) — couverts par la recette appareil.
- Le reste est consigné dans
  [KNOWN_LIMITATIONS.md](../KNOWN_LIMITATIONS.md) (D-216).
