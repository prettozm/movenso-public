/**
 * ÉCRAN « À PROPOS » (D-362) — court, identitaire, et sans rien de négatif.
 *
 * Demande du porteur du 2026-08-17 : « À propos devient joli et ne contient
 * rien de négatif ». Le contenu anxiogène n'a pas disparu, il est DESCENDU là
 * où il est actionnable — « Limites connues » et « désinstaller efface tout »
 * sont des rubriques de l'aide, pas des cartes d'identité.
 *
 * Une exception, assumée et nommée plutôt qu'appliquée en silence :
 * l'avertissement de version d'évaluation RESTE. Il prévient une perte réelle
 * sur une build RC non signée, et la fiche de recette exige de lire le build
 * dans cet écran. Il change de ton — une ligne qui dit le geste plutôt que la
 * menace — et il s'efface tout seul en version stable.
 *
 * Sorti de `atelier-reglages.ts`, qui était à son cliquet : la refonte y
 * ajoutait plus qu'elle n'y retirait (D-278).
 *
 * TUTOIEMENT : cet écran était le dernier au vouvoiement (« vos disciplines »),
 * reste signalé depuis D-310. Tranché ici, dans le sens du reste du produit.
 */

import { html, nothing, type TemplateResult } from "lit";
import { SPRITE_ILLUSTRATIONS, illustration } from "./aide-illustrations.ts";
import { VERSION, COMMIT } from "./version.ts";
import type { MovensoApp } from "./racine.ts";

const COCHE = html`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"
  stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7"/></svg>`;

/** Vraie pour une build d'évaluation — la condition existait déjà, elle est
 *  simplement nommée : elle décide de l'avertissement ET de la pastille. */
const EVALUATION = VERSION.includes("dev") || VERSION.includes("rc") || VERSION.includes("beta");

export function ecranApropos(app: MovensoApp): TemplateResult {
  return html`
    ${SPRITE_ILLUSTRATIONS}
    <div class="aide-page">
      <div class="apropos-heros">
        ${illustration("heros-apropos", "apropos-heros-art", "0 0 200 160")}
        <h2>Movenso</h2>
        <p class="apropos-accroche">Ta bibliothèque personnelle de mouvements</p>
        <p>Sans compte, sans cloud imposé. Tes fiches, tes notes et tes médias restent sur cet appareil.</p>
        <p>Une connexion peut être utile pour charger l’application, la mettre à jour ou ouvrir une
          ressource externe.</p>
        ${EVALUATION ? html`<span class="apropos-pastille">Version d’évaluation</span>` : nothing}
      </div>

      <div class="apropos-majeure">
        ${illustration("donnees", "apropos-majeure-art")}
        <h3>Tes données, ton espace</h3>
        <ul>
          <li>${COCHE} Rien n’est envoyé</li>
          <li>${COCHE} Tout reste sur l’appareil</li>
          <li>${COCHE} Fonctionne hors ligne</li>
        </ul>
      </div>

      <div class="apropos-majeure">
        ${illustration("licences", "apropos-majeure-art")}
        <h3>Licences &amp; crédits</h3>
        <ul class="apropos-licences">
          <li>Application : <b>GNU GPL v3</b></li>
          <li>Starter packs : <b>CC BY-NC-SA 4.0</b></li>
          <li>Vidéos liées : à leurs auteurs</li>
        </ul>
      </div>

      <div class="apropos-version">
        <span class="apropos-version-cle">Version</span>
        <span class="apropos-version-valeur">${VERSION}+${COMMIT}</span>
      </div>
      ${EVALUATION
        ? html`<p class="apropos-mention">Exporte une sauvegarde avant chaque mise à jour.</p>`
        : nothing}

      <button class="apropos-porte" @click=${() => app.ouvrirPlusSection("aide")}>
        ${illustration("porte", "apropos-porte-art")}
        <span class="apropos-porte-corps">
          <b>Besoin d’aide ?</b>
          <span>Les repères essentiels, rubrique par rubrique.</span>
        </span>
        <span class="apropos-rond">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"
               stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h13m-5-6 6 6-6 6"/></svg>
        </span>
      </button>
    </div>
  `;
}
