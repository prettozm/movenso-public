/**
 * ILLUSTRATIONS DE L'AIDE ET D'À PROPOS (D-362, D-366) — un seul lieu.
 *
 * DIX illustrations du porteur sont EMBARQUÉES (`public/img/aide-*.webp`,
 * 192 px, ~102 Ko au total). Elles ne dépendent d'aucun réseau : l'aide
 * s'ouvre entière hors ligne, dans l'APK comme sur le web.
 *
 * TROIS manquent encore à la série — `partager`, `securite`, `porte`. Elles
 * gardent un CALQUE dessiné à la main, qui reprend la composition attendue.
 * Le procédé et sa bascule sont ceux de D-331 → D-332 : le calque disparaît
 * le jour où le fichier arrive, et la substitution est une SUPPRESSION.
 * Pour `partager`, la vignette devra montrer DEUX objets côte à côte — un
 * colis et un coffre : la rubrique dit « partager n'est pas sauvegarder », et
 * une image à un seul objet contredirait sa propre phrase.
 *
 * PALETTE DES CALQUES : fixe, jamais les tokens de thème — une illustration
 * ne suit pas la tonalité (D-136), comme les WebP qui les remplacent.
 */

import { html, svg, type TemplateResult } from "lit";

/** Clés d'illustration — le compilateur refuse une vignette qui n'existe pas. */
export type CleIllustration =
  | "demarrer" | "retrouver" | "fiche" | "medias" | "relations"
  | "partager" | "donnees" | "securite" | "limites"
  | "heros-apropos" | "heros-aide" | "licences" | "porte";

/** Les clés dont le fichier du porteur est EMBARQUÉ. Les autres retombent sur
 *  leur calque. Une clé qui entre ici doit voir son symbole quitter le sprite —
 *  la garde `verifier:mort` ne le dira pas, un `<symbol>` inutilisé n'étant pas
 *  un export mort. */
const EMBARQUEES = new Set<CleIllustration>([
  "demarrer", "retrouver", "fiche", "medias", "relations", "donnees",
  "limites", "licences", "heros-aide", "heros-apropos",
]);

const fichier = (cle: CleIllustration): string => `./img/aide-${cle}.webp`;

/** Une vignette. Décorative, donc masquée aux lecteurs d'écran. */
export function vignette(cle: CleIllustration, classe = "aide-vignette"): TemplateResult {
  return EMBARQUEES.has(cle)
    ? html`<img class=${classe} src=${fichier(cle)} alt="" aria-hidden="true" width="192" height="192" decoding="async">`
    : html`<svg class=${classe} viewBox="0 0 120 120" aria-hidden="true"><use href="#ill-${cle}"></use></svg>`;
}

/** Une illustration de format libre (héros, carte majeure). */
export function illustration(cle: CleIllustration, classe: string, boite = "0 0 120 120"): TemplateResult {
  return EMBARQUEES.has(cle)
    ? html`<img class=${classe} src=${fichier(cle)} alt="" aria-hidden="true" decoding="async">`
    : html`<svg class=${classe} viewBox=${boite} aria-hidden="true"><use href="#ill-${cle}"></use></svg>`;
}

/** Le sprite. Rendu UNE fois par écran qui s'en sert — les `<use>` y puisent.
 *  Un seul lieu de définition : deux copies divergeraient (D-253). */
export const SPRITE_ILLUSTRATIONS: TemplateResult = html`
<svg class="ill-sprite" width="0" height="0" aria-hidden="true" focusable="false">${svg`
<defs>
<style>
  .il-f{fill:#F5F1E8}.il-s{fill:#93A48C}.il-sc{fill:#6E8168}.il-c{fill:#DD6A4E}.il-c2{fill:#C4553F}
  .il-b{fill:#6B5645}.il-bl{fill:#A08A73}.il-k{fill:#E7E0D0}.il-w{fill:#FCFAF6}.il-n{fill:#1C1A18}
  .il-n2{fill:#2A2724}.il-kr{fill:#C09A6B}.il-kr2{fill:#A8814F}.il-kr3{fill:#D9BC94}
  .il-pa{fill:#E6DCC6}.il-pa2{fill:#CFC2A6}.il-g{fill:#8A8378}.il-o{fill:#000;opacity:.26}
</style>







<symbol id="ill-partager" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="104" rx="44" ry="7"/>
  <path class="il-kr" d="M6 44h52v46a6 6 0 0 1-6 6H12a6 6 0 0 1-6-6Z"/>
  <path class="il-kr2" d="M6 44h52v9H6Z"/><rect class="il-c" x="26" y="44" width="12" height="52"/>
  <path class="il-c2" d="M20 34h24l-6 10H26Z"/><rect class="il-kr3" x="14" y="72" width="14" height="9" rx="2"/>
  <rect class="il-n" x="64" y="36" width="50" height="52" rx="7"/><rect class="il-n2" x="70" y="42" width="38" height="40" rx="4"/>
  <circle class="il-c2" cx="96" cy="62" r="9"/>
  <path fill="#E6DCC6" opacity=".9" d="M96 56c2.4 1.2 4 1.4 5 1.4 0 5-1.6 7.4-5 9-3.4-1.6-5-4-5-9 1 0 2.6-.2 5-1.4Z"/>
  <rect class="il-g" x="76" y="57" width="8" height="12" rx="4"/><rect class="il-g" x="78.5" y="53" width="3" height="7" rx="1.5"/>
  <path class="il-s" d="M64 26c0-10 5-15 12-15 0 10-5 15-12 15Z"/>
  <path class="il-sc" d="M62 28c-7 0-12-5-12-12 7 0 12 5 12 12Z"/></symbol>

<symbol id="ill-securite" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="100" rx="42" ry="7"/>
  <path class="il-s" d="M14 74h84v16a6 6 0 0 1-6 6H20a6 6 0 0 1-6-6Z"/><path class="il-sc" d="M14 74h84v5H14Z"/>
  <path class="il-bl" d="M20 60h72v14H20Z"/><path class="il-kr3" d="M20 60h72v4H20Z"/>
  <path class="il-s" d="M26 46h60v14H26Z"/><path class="il-sc" d="M26 46h60v4H26Z"/>
  <g transform="rotate(7 76 32)"><rect class="il-pa" x="56" y="14" width="40" height="34" rx="4"/>
    <circle class="il-c" cx="76" cy="31" r="12"/>
    <path fill="#E6DCC6" d="M74.6 24h3v9h-3zm0 11.6h3v3h-3z"/></g>
  <path class="il-s" d="M28 42c0-12 6-18 14-18 0 12-6 18-14 18Z"/>
  <path class="il-sc" d="M26 44c-9 0-15-6-15-15 9 0 15 6 15 15Z"/></symbol>



<symbol id="ill-porte" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="102" rx="40" ry="7"/>
  <path class="il-k" d="M20 96V38a6 6 0 0 1 6-6h32v64Z"/>
  <path class="il-w" d="M58 32h34a6 6 0 0 1 6 6v58H58Z"/>
  <path class="il-pa2" d="M58 32h34a6 6 0 0 1 6 6v58H58Z" opacity=".45"/>
  <g class="il-pa2"><rect x="28" y="46" width="22" height="4.4" rx="2.2"/><rect x="28" y="57" width="17" height="4.4" rx="2.2"/></g>
  <circle class="il-c" cx="78" cy="62" r="18"/><circle class="il-w" cx="78" cy="62" r="7.4"/>
  <path class="il-w" d="M65.6 49.6 71 55l-5.4 5.4-5.4-5.4Zm24.8 0L96 55l-5.4 5.4L85.2 55Zm0 24.8L96 69l-5.4-5.4L85.2 69Zm-24.8 0L71 69l-5.4-5.4L60.2 69Z" opacity=".92"/></symbol>


</defs>`}</svg>`;
