/**
 * COULEURS DES RÔLES DE RELATION — garde exécutable (D-349, D-350, D-352).
 *
 * Constat de recette D8 : « À ne pas confondre » devait être corail ; le rôle
 * `peer` empruntait `--accent`, donc suivait la TONALITÉ choisie, jusqu'à
 * prendre la couleur d'un AUTRE rôle (forêt 18 du vert de `before`, acier 20 et
 * indigo 29 du bleu de `after` — quand la palette sépare déjà ses rôles de 54).
 *
 * TROIS VERSIONS DE CETTE GARDE ONT ÉTÉ AVEUGLES, et c'est la raison de sa
 * forme actuelle :
 *  - D-349 ne regardait que `relations.css` et `couleurRole()` — la Mindmap
 *    tenait une troisième copie dans son CSS ;
 *  - D-350 a fermé ce CSS et s'est déclaré clos — `couleurSlot()`
 *    (`relations-mindmap.ts`), qui colore les connecteurs SVG, était un
 *    QUATRIÈME lieu où le défaut vivait encore ;
 *  - et aucune des deux ne surveillait `base.css`, le lieu qu'elles
 *    instituent : y écrire `--role-peer:var(--accent)` les laissait vertes.
 *
 * Elle est donc écrite depuis la QUESTION — « qui colore un rôle ? » — et non
 * depuis une liste de fichiers, qui était à chaque fois celle que l'auteur
 * avait en tête. Elle balaie `src/`, et elle lit la SOURCE autant que ses
 * dérivations, sous les six tonalités.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";

const SRC = new URL("../src/", import.meta.url);
const ROLES = ["before", "after", "opposition", "peer", "context"] as const;
/** Une zone de la Mindmap EST un rôle (`ROLE_COULEUR_DE_SLOT`). */
const ZONES = { top: "peer", left: "before", right: "after", bottom: "context", second: "opposition" } as const;

/** Tous les fichiers de `src/`, en profondeur — aucune liste à tenir à jour. */
function fichiers(dossier: URL): { chemin: string; texte: string }[] {
  return readdirSync(dossier, { withFileTypes: true }).flatMap((e) => {
    if (e.isDirectory()) return fichiers(new URL(`${e.name}/`, dossier));
    if (!/\.(ts|css)$/.test(e.name)) return [];
    const u = new URL(e.name, dossier);
    return [{ chemin: u.pathname.slice(u.pathname.indexOf("/src/") + 1), texte: readFileSync(u, "utf8") }];
  });
}
const TOUT = fichiers(SRC);
const BASE = TOUT.find((f) => f.chemin.endsWith("styles/base.css"))!;

/** Une ligne de CSS parle d'un rôle si son sélecteur le nomme — c'est vrai en
 *  CSS, où sélecteur et déclaration partagent la ligne. */
const selecteurDeRole = (l: string) =>
  ROLES.some((r) => l.includes(`role--${r}`)) || Object.keys(ZONES).some((z) => l.includes(`slot--${z}`));
const estCommentaire = (l: string) => l.trimStart().startsWith("*") || l.trimStart().startsWith("//") || l.trimStart().startsWith("/*");

test("D-352 — aucune règle CSS de rôle ou de zone n'emprunte le thème ni une couleur en dur", () => {
  const fautes: string[] = [];
  for (const { chemin, texte } of TOUT.filter((f) => f.chemin.endsWith(".css"))) {
    for (const [i, l] of texte.split("\n").entries()) {
      if (estCommentaire(l) || !selecteurDeRole(l)) continue;
      const ou = `${chemin}:${i + 1}`;
      if (/var\(--accent/.test(l)) fautes.push(`${ou} : emprunte --accent — la couleur suivrait la tonalité (D8)`);
      if (/#[0-9a-fA-F]{6}\b/.test(l)) fautes.push(`${ou} : couleur EN DUR — elle vit dans base.css (D-253)`);
    }
  }
  assert.deepEqual(fautes, []);
});

/**
 * Le TS ne se vérifie PAS ligne à ligne — c'est ce qui a laissé passer la
 * cinquième version : le sabotage `slot === "top" ? "var(--accent)"` ne contient
 * ni `case "top"` ni `slot--top`, donc l'heuristique par ligne l'ignorait.
 *
 * Règle TOTALE, qu'aucun renommage ni réécriture ne contourne : dans les
 * fichiers qui rendent les relations, `--accent` et les couleurs en dur sont
 * interdits, point. Mesuré avant de l'écrire : ces fichiers n'en avaient aucun
 * usage légitime. Une couleur y vient d'un token de rôle, ou n'y vient pas.
 */
test("D-352 — les vues de relations ne connaissent AUCUNE couleur, seulement des tokens", () => {
  const vues = TOUT.filter((f) => /app\/relations-[a-z-]+\.ts$|domaine\/relations\.ts$/.test(f.chemin));
  assert.ok(vues.length >= 4, `la garde doit voir les vues de relations (vues : ${vues.length})`);
  const fautes: string[] = [];
  for (const { chemin, texte } of vues)
    for (const [i, l] of texte.split("\n").entries()) {
      if (estCommentaire(l)) continue;
      if (/var\(--accent/.test(l)) fautes.push(`${chemin}:${i + 1} : --accent dans une vue de relations — une couleur y est un token de rôle (D8)`);
      if (/#[0-9a-fA-F]{6}\b/.test(l)) fautes.push(`${chemin}:${i + 1} : couleur EN DUR dans une vue de relations (D-253)`);
    }
  assert.deepEqual(fautes, []);
});

test("D-352 — la SOURCE elle-même ne dérive jamais du thème", () => {
  // Le trou de D-349/D-350 : ils interdisaient `--accent` dans les dérivations
  // et laissaient `base.css` libre d'y poser `--role-peer:var(--accent)`.
  for (const [i, l] of BASE.texte.split("\n").entries())
    for (const r of ROLES)
      if (new RegExp(`--role-${r}\\s*:`).test(l))
        assert.ok(!/var\(--accent/.test(l),
          `styles/base.css:${i + 1} : --role-${r} dérive de --accent — c'est le défaut D8 posé à sa source`);
});

test("D-352 — les cinq rôles restent distinguables sous les SIX tonalités et les trois thèmes", () => {
  const bloc = (re: RegExp, quoi: string) => {
    const m = re.exec(BASE.texte);
    assert.ok(m?.[1], `bloc « ${quoi} » introuvable dans base.css`);
    return m![1]!;
  };
  const clair = BASE.texte.slice(0, BASE.texte.indexOf("@media (prefers-color-scheme: dark)"));
  const themes: [string, string][] = [
    ["clair", clair],
    ["sombre (système)", clair + bloc(/prefers-color-scheme:\s*dark[^{]*\{([\s\S]*?)\n\s*\}\n\}/, "sombre système")],
    ["sombre (forcé)", clair + bloc(/:root\[data-theme="sombre"\]\{([\s\S]*?)\n\}/, "sombre forcé")],
  ];
  // Les six tonalités ne redéfinissent QUE --accent : si un rôle en dérivait,
  // le test précédent l'aurait dit ; on les empile quand même, pour que la
  // garde soit vraie de ce que le navigateur applique et pas d'un sous-cas.
  const tonalites = [...BASE.texte.matchAll(/:root\[data-tonalite="([a-z]+)"\]\{([^}]*)\}/g)];
  assert.equal(tonalites.length, 5, `cinq tonalités déclarées en plus du défaut (vues : ${tonalites.length})`);

  // La DERNIÈRE déclaration gagne, comme en CSS : lire la première rendait la
  // garde aveugle aux surcharges (D-349).
  const val = (nom: string, b: string): string => {
    const brut = [...b.matchAll(new RegExp(`--${nom}:\\s*([^;}]+)`, "g"))].at(-1)?.[1]?.trim();
    assert.ok(brut, `--${nom} introuvable`);
    const indirect = /var\(--([a-z-]+)\)/.exec(brut!)?.[1];
    return indirect ? val(indirect, b) : brut!;
  };
  const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const dist = (a: string, b: string) => {
    const [x, y, z] = hex(a), [u, v, w] = hex(b);
    return Math.sqrt((x! - u!) ** 2 + (y! - v!) ** 2 + (z! - w!) ** 2);
  };
  for (const [nomTheme, base] of themes) {
    for (const [, ton, corps] of [["", "défaut", ""] as string[], ...tonalites.map((m) => ["", m[1]!, m[2]!])]) {
      const b = base + (corps ?? "");
      const couleurs = ROLES.map((r) => val(`role-${r}`, b));
      for (let i = 0; i < couleurs.length; i++)
        for (let j = i + 1; j < couleurs.length; j++) {
          const d = dist(couleurs[i]!, couleurs[j]!);
          // 50 : la barre que la palette tolère déjà (before/after à 54 en clair).
          assert.ok(d >= 50, `${nomTheme} / tonalité ${ton} : « ${ROLES[i]} » et « ${ROLES[j]} » sont à ${Math.round(d)} — indistinguables`);
        }
    }
  }
});

test("D-352 — chaque zone de la Mindmap dérive le token du rôle qu'elle représente", () => {
  const css = TOUT.find((f) => f.chemin.endsWith("styles/relations.css"))!.texte;
  for (const [zone, role] of Object.entries(ZONES)) {
    const regles = css.split("\n").filter((l) => l.includes(`.slot--${zone}`) && /color|background|border/.test(l));
    // Compte EXACT : un plancher laissait passer la disparition d'une règle —
    // le constat ④ du verdict précédent, reproduit dans ce fichier neuf (D-352).
    assert.equal(regles.length, 4, `la zone « ${zone} » porte quatre règles de couleur (vues : ${regles.length})`);
    for (const l of regles)
      assert.ok(l.includes(`var(--role-${role})`), `zone « ${zone} » doit dériver --role-${role} : ${l.trim()}`);
  }
});
