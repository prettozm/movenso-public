/**
 * CHAPITRE e2e (S3.A7) — D-067/D-068 — dé-fusion + doublons (deux packs de même discipline).
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { surveiller, lent, allerMenuPlus, ouvrirPlus, allerBiblio, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
/* ===== D-067/D-068 — dé-fusion + doublons : deux packs de même discipline
   partageant un nom de technique produisent DEUX fiches distinctes (source en
   badge), consultables/favorisables/partageables/supprimables séparément ;
   l'Atelier propose (jamais n'impose) de les conserver, fusionner ou écarter.
   Fixtures JSON minimales écrites sur disque (le .movpack non-zip est traité
   comme un JSON historique par l'importeur). ===== */
{
  // ULID valides (26 car., alphabet Crockford) dérivés d'une graine.
  const U = (graine) => (graine.toUpperCase().replace(/[^0-9A-HJKMNP-TV-Z]/g, "0") + "0".repeat(26)).slice(0, 26);
  const maintenant = new Date().toISOString();
  const packJudo = (pack, videoRef, texte, attribution) => ({
    versionSchema: 3,
    typesRelation: [
      { id: "prepare", libelle: "Prépare", libelleInverse: "Préparée par" },
      { id: "enchaine", libelle: "Enchaîne vers", libelleInverse: "Enchaînée depuis" },
      { id: "contre", libelle: "Contre", libelleInverse: "Contrée par" },
      { id: "similaire", libelle: "Similaire à", symetrique: true },
    ],
    disciplines: [{ id: U("DISC" + pack), nom: "Judo", familles: [], niveaux: [] }],
    techniques: [
      {
        id: U("TECH" + pack),
        disciplineId: U("DISC" + pack),
        nom: "Ashi-guruma",
        niveauxIds: [],
        relations: [],
        origine: { pack, element: "e0" },
      },
    ],
    contributions: [
      {
        id: U("CON" + pack),
        techniqueId: U("TECH" + pack),
        provenance: "enseignement",
        attribution,
        description: texte,
        pointsCles: [],
        creeLe: maintenant,
        medias: [{ id: U("MED" + pack), type: "plateforme", service: "youtube", ref: videoRef }],
        origine: { pack, element: "c0" },
      },
    ],
    compositions: [],
    favoris: [],
  });
  const fPackK = join(tmpdir(), "movenso-defusion-kodokan.movpack");
  const fPackC = join(tmpdir(), "movenso-defusion-clubjudo.movpack");
  writeFileSync(fPackK, JSON.stringify(packJudo("kodokan", "KODVIDEO001", "Version Kodokan : hanche haute, balayage ample.", "Kodokan")));
  writeFileSync(fPackC, JSON.stringify(packJudo("clubjudo", "CLUBVIDEO02", "Version club : entrée courte, appui sur le genou.", "Clubjudo")));

  const allerRacineBiblio = (p) => allerBiblio(p);
  // Importe un fichier : pack #1 par l'état vide, les suivants par Plus (D-071).
  const importerJson = async (p, chemin, viaAtelier) => {
    if (viaAtelier) {
      await allerMenuPlus(p);
      const [sel] = await Promise.all([
        p.waitForEvent("filechooser"),
        p.locator(".ligne-menu", { hasText: "Importer un pack" }).click(),
      ]);
      await sel.setFiles(chemin);
    } else {
      const [sel] = await Promise.all([
        p.waitForEvent("filechooser"),
        p.locator(".action-douce", { hasText: "Importer" }).click(),
      ]);
      await sel.setFiles(chemin);
    }
    await p.waitForSelector(".feuille .actions .bouton.principal");
    assert.ok((await p.locator(".feuille .points").innerText()).includes("ajout"), "l'aperçu d'import doit annoncer le contenu");
    await p.locator(".feuille .actions .bouton.principal").click();
    const rapport = p.locator(".feuille[aria-label=\"Rapport d'import\"]");
    await rapport.waitFor();
    assert.ok((await rapport.innerText()).includes("installé ✓"), "le rapport d'import doit dire ce qui a changé");
    await rapport.locator(".actions .bouton.principal").click();
    await rendu(p);
    if (viaAtelier) await allerRacineBiblio(p);
  };
  const installerPaire = async (p) => {
    await importerJson(p, fPackK, false);
    await importerJson(p, fPackC, true);
    await allerRacineBiblio(p);
  };

  /* --- Contexte principal : dé-fusion (1-6, 8, 9 détection, 7 suppression) --- */
  {
    const ctxDF = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
    const p = await ctxDF.newPage();
    surveiller(p);
    // (5) stub du partage natif AVANT navigation (Web Share API)
    await p.addInitScript(() => {
      window.__shared = [];
      navigator.share = async (d) => { window.__shared.push(d?.title ?? true); window.__partageTaille = d?.files?.[0]?.size ?? 0; };
      navigator.canShare = () => true;
    });
    await p.goto("http://localhost:4517/");
    await p.waitForSelector(".action-douce");
    // (1) importer les deux packs
    await installerPaire(p);
    // (2) deux fiches « Ashi-guruma » distinctes, deux badges de source
    assert.equal(await p.locator(".carte-nom", { hasText: "Ashi-guruma" }).count(), 2, "dé-fusion : deux fiches Ashi-guruma attendues");
    // tuning post-V3 : plus de badge de source sur les cartes ni de filtre par
    // source ; on ouvre une fiche d'une source précise par son identité
    // (origine.pack) via le modèle, et on vérifie les sources distinctes ainsi.
    const ouvrirSource = async (pack) => {
      const id = await p.evaluate((pk) => {
        const app = document.querySelector("movenso-app");
        const t = app.bibliotheque.techniques.find((x) => /ashi-guruma/i.test(x.nom) && (x.origine?.pack ?? "") === pk);
        return t?.id ?? null;
      }, pack);
      assert.ok(id, "identité introuvable pour la source " + pack);
      await p.evaluate((i) => document.querySelector("movenso-app").ouvrirFiche(i), id);
    };
    const packsAshi = await p.evaluate(() => {
      const app = document.querySelector("movenso-app");
      return [...new Set(app.bibliotheque.techniques.filter((t) => /ashi-guruma/i.test(t.nom)).map((t) => t.origine?.pack ?? "local"))];
    });
    assert.ok(packsAshi.length >= 2, "deux sources distinctes doivent départager les fiches : " + packsAshi.join(" | "));
    // (3) chaque fiche ne montre QUE le texte de son pack
    await ouvrirSource("kodokan");
    await p.waitForSelector(".bloc-lecture");
    let texte = await p.locator(".bloc-lecture:not(.commentaire)").first().innerText();
    assert.ok(texte.includes("Version Kodokan") && !texte.includes("Version club"), "la fiche Kodokan ne doit montrer que son propre texte");
    await p.click(".barre [aria-label=\"Retour\"]");
    await p.waitForSelector(".marque");
    await ouvrirSource("clubjudo");
    await p.waitForSelector(".bloc-lecture");
    texte = await p.locator(".bloc-lecture:not(.commentaire)").first().innerText();
    assert.ok(texte.includes("Version club") && !texte.includes("Version Kodokan"), "la fiche Club ne doit montrer que son propre texte");
    await p.click(".barre [aria-label=\"Retour\"]");
    await p.waitForSelector(".marque");
    // (4) favori depuis le cœur d'une carte — SANS ouvrir la fiche
    await p.locator(".carte-technique").first().locator(".coeur").click();
    await finit(async () => assert.equal(await p.locator(".carte-technique .coeur.actif").count(), 1, "le cœur d'une carte doit marquer le favori sans ouvrir la fiche"));
    assert.equal(await p.locator(".fiche-entete").count(), 0, "cliquer le cœur ne doit jamais ouvrir la fiche");
    await p.locator(".btn-coeur").click(); // D-336 : le cœur de la barre filtre la grille
    await p.waitForSelector(".carte-technique");
    assert.ok((await p.locator(".carte-technique", { hasText: "Ashi-guruma" }).count()) >= 1, "le favori doit rester dans la grille filtrée (D-336)");
    await p.locator(".btn-coeur").click(); // on relâche
    await allerRacineBiblio(p);
    // (5) partager depuis une fiche → le partage natif stubbé est invoqué
    await ouvrirSource("kodokan");
    await p.waitForSelector(".fiche-entete h1");
    await p.locator('.barre [aria-label="Partager"]').click();
    await p.waitForTimeout(lent(300));
    assert.ok((await p.evaluate(() => window.__shared.length)) >= 1, "le partage natif doit être invoqué");
    await p.click(".barre [aria-label=\"Retour\"]");
    await p.waitForSelector(".marque");
    // (5bis) D-092 : avec une vidéo LOCALE présente, une feuille de pré-partage
    // s'intercale (reçu + choix d'inclure les vidéos) ; sans vidéo locale (ci-dessus)
    // le partage reste direct.
    const nbAvantPartage = await p.evaluate(() => window.__shared.length);
    const idAvecVideo = await p.evaluate(async () => {
      const app = document.querySelector("movenso-app");
      const b = app.bibliotheque;
      const t = b.techniques[0];
      // ids ULID valides (26 car. [0-9A-HJKMNP-TV-Z]) : le pack est validé à l'extraction
      const VID = "0000000000000000000000MEDA";
      const CTB = "0000000000000000000000CNTB";
      await app.stockage.ecrireVideo(VID, new Blob([new Uint8Array(4096)], { type: "video/webm" }));
      // provenance NON personnelle : le pack exclut le personnel (D-067), donc une
      // vidéo locale n'est embarquée que si elle vient d'une contribution partageable.
      b.contributions.push({
        id: CTB, techniqueId: t.id, provenance: "enseignement",
        pointsCles: [], creeLe: new Date().toISOString(),
        medias: [{ id: VID, type: "local", ref: "clip-local.webm", mime: "video/webm" }],
      });
      await app.majMediaLabel(VID, "clip local"); // persiste b (contribution incluse)
      return t.id;
    });
    await p.evaluate((id) => document.querySelector("movenso-app").ouvrirFiche(id), idAvecVideo);
    await p.waitForSelector(".fiche-entete h1");
    await p.locator('.barre [aria-label="Partager"]').click();
    await p.waitForSelector('.feuille[aria-label="Partager la technique"]');
    assert.match(
      await p.locator('.feuille[aria-label="Partager la technique"] .geste').innerText(),
      /vidéo locale/i,
      "la feuille de pré-partage annonce la vidéo locale",
    );
    await p.locator('.feuille[aria-label="Partager la technique"] .interrupteur').click(); // décocher les vidéos
    await p.locator('.feuille[aria-label="Partager la technique"] .bouton.principal', { hasText: "Partager" }).click();
    await p.waitForTimeout(lent(300));
    assert.ok((await p.evaluate(() => window.__shared.length)) > nbAvantPartage, "confirmer la feuille déclenche le partage natif");
    assert.equal(await p.locator('.feuille[aria-label="Partager la technique"]').count(), 0, "la feuille se ferme après le partage");

    // (5bis-suite, S4.5/D-262) — le cas COÛTEUX, jusqu'ici jamais joué : on
    // partage en GARDANT la vidéo. Elle transite désormais par blocs vers une
    // archive temporaire ; auparavant elle était lue entièrement en mémoire
    // puis l'archive y était construite, sur le geste le plus banal.
    const avantAvecVideo = await p.evaluate(() => window.__shared.length);
    await p.evaluate(() => document.querySelector("movenso-app").operationLongue = null);
    await p.locator('.barre [aria-label="Partager"]').click();
    await p.waitForSelector('.feuille[aria-label="Partager la technique"]');
    await p.locator('.feuille[aria-label="Partager la technique"] .bouton.principal', { hasText: "Partager" }).click(); // vidéo CONSERVÉE
    await finit(async () =>
      assert.ok((await p.evaluate(() => window.__shared.length)) > avantAvecVideo, "le partage avec vidéo aboutit"));
    // L'export en flux se DÉCLARE comme opération longue (voile à progression
    // + annulation, et trace au diagnostic). Le chemin en mémoire, lui, ne
    // déclarait rien : c'est le témoin qui distingue les deux.
    const trace = await p.evaluate(() => document.querySelector("movenso-app").operationLongue?.libelle ?? null);
    assert.match(String(trace), /^Export de .+\.movpack$/, "le partage avec vidéo passe par l'export en flux (S4.5)");
    // Et la vidéo est bien PARTIE : l'archive pèse au moins ses 4 096 octets.
    assert.ok(await p.evaluate(() => window.__partageTaille) > 4096,
      "l'archive partagée contient réellement la vidéo locale");

    await p.click(".barre [aria-label=\"Retour\"]");
    await p.waitForSelector(".marque");
    // (5ter) D-119 : le stylo des médias en ligne modifie le nom ET le lien —
    // `majMediaLien` re-analyse l'URL (YouTube → service + id, sinon lien nu).
    {
      const r = await p.evaluate(async () => {
        const app = document.querySelector("movenso-app");
        const t = app.bibliotheque.techniques[0];
        // ids ULID valides (Crockford base32 : ni I, L, O, U)
        const MID = "0000000000000000000000MEDX";
        app.bibliotheque.contributions.push({
          id: "0000000000000000000000CTBX", techniqueId: t.id, provenance: "enseignement",
          pointsCles: [], creeLe: new Date().toISOString(),
          medias: [{ id: MID, type: "lien", ref: "https://exemple.test/x" }],
        });
        const lire = () => app.bibliotheque.contributions.flatMap((c) => c.medias).find((m) => m.id === MID);
        await app.majMediaLien(MID, "https://www.youtube.com/watch?v=abc123XYZ");
        const y = lire();
        const yt = { type: y.type, service: y.service, ref: y.ref };
        await app.majMediaLien(MID, "https://vimeo.test/42");
        const l = lire();
        const lien = { type: l.type, service: l.service ?? null, ref: l.ref };
        return { yt, lien };
      });
      assert.equal(r.yt.type, "plateforme", "une URL YouTube devient un média plateforme");
      assert.equal(r.yt.service, "youtube");
      assert.equal(r.yt.ref, "abc123XYZ", "l'id de vidéo est extrait de l'URL");
      assert.equal(r.lien.type, "lien", "une URL quelconque redevient un lien nu");
      assert.equal(r.lien.service, null, "le service YouTube est retiré quand l'URL n'est plus YouTube");
      assert.equal(r.lien.ref, "https://vimeo.test/42");
    }
    // (5quater) D-124 : l'éditeur de composition porte une consigne (pas), une
    // durée (séance minutée) et une présentation (niveau composition, jamais un
    // pas) — fondation additive. On exerce les vrais chemins app.
    {
      const r = await p.evaluate(async () => {
        const app = document.querySelector("movenso-app");
        const b = app.bibliotheque;
        const t = b.techniques[0];
        // ids ULID valides (Crockford base32 : ni I, L, O, U)
        const CID = "0000000000000000000000CMP1";
        b.compositions.push({ id: CID, nom: "Séance test", provenance: "personnel", creeLe: new Date().toISOString(), blocs: [] });
        await app.modifierComposition(CID, (c) => {
          c.blocs.push({ id: "0000000000000000000000BK01", type: "technique", techniqueId: t.id, consigne: "gauche et droite", medias: [] });
          c.blocs.push({ id: "0000000000000000000000BK02", type: "etape", texte: "échauffement", dureeSec: 300, medias: [] });
        });
        await app.ajouterMediaPresentation(CID, { lien: "https://exemple.test/demo" });
        const c1 = b.compositions.find((x) => x.id === CID);
        const apres = {
          consigne: c1.blocs[0].consigne,
          dureeSec: c1.blocs[1].dureeSec,
          nbBlocs: c1.blocs.length,
          presentation: c1.presentation?.medias.length ?? 0,
        };
        await app.retirerMediaPresentation(CID, c1.presentation.medias[0].id);
        return { apres, presentationApresRetrait: b.compositions.find((x) => x.id === CID).presentation ?? null };
      });
      assert.equal(r.apres.consigne, "gauche et droite", "la consigne est portée par le pas technique (D-124)");
      assert.equal(r.apres.dureeSec, 300, "la durée du segment est stockée en secondes (D-124)");
      assert.equal(r.apres.nbBlocs, 2, "la présentation n'ajoute JAMAIS un pas à la séquence (D-124)");
      assert.equal(r.apres.presentation, 1, "le média de présentation est au niveau composition (D-124)");
      assert.equal(r.presentationApresRetrait, null, "retirer le dernier média de présentation supprime le champ (D-124)");
      // Lecture + pas-à-pas honnêtes (D-124 boucle 3) : total de séance en tête,
      // consigne SOUS le pas technique, durée du segment — jamais de pas creux.
      await p.evaluate(() => document.querySelector("movenso-app").ouvrirComposition("0000000000000000000000CMP1"));
      // D-124 : le total de séance s'affiche en lecture — il vit désormais dans la
      // ligne de statistiques de la FICHE (UI-2/D-319), à côté du nombre d'étapes.
      await p.waitForSelector(".fiche-compo-stats");
      assert.match(await p.locator(".fiche-compo-stats").innerText(), /min|\bh\b|\bs\b/,
        "le total de séance s'affiche en consultation (D-124) : " + (await p.locator(".fiche-compo-stats").innerText()));
      await p.evaluate(() => { document.querySelector("movenso-app").definirTransition(0); window.__voix = []; }); // prépa OFF (déterministe) + journal vocal (D-125)
      await p.locator('.barre .bouton-icone[aria-label="Passer en revue"]').click();
      await p.waitForSelector(".ecran.entrainement");
      assert.match(await p.locator(".entrainement-consigne").innerText(), /gauche et droite/, "la consigne du pas s'affiche dans le pas-à-pas (D-124)");
      assert.ok((await p.evaluate(() => window.__voix.length)) >= 1, "la voix annonce le nom du pas à l'entrée (D-125)");
      // D-125 : le segment minuté déroule un chrono (mm:ss) avec pause + son ;
      // la voix annonce le nom du segment ET sa durée en toutes lettres.
      await p.locator(".entrainement-actions .bouton.principal", { hasText: "Suivant" }).click();
      await p.waitForSelector(".entrainement-chrono");
      assert.ok(
        (await p.evaluate(() => window.__voix)).some((t) => /échauffement, 5 minutes/i.test(t)),
        "la voix annonce le nom du segment et sa durée (D-125)",
      );
      assert.match(await p.locator(".entrainement-chrono").innerText(), /^\d+:\d\d$/, "le segment déroule un décompte mm:ss (D-125)");
      // UI-5 (D-323) : au bord du tatami on ne LIT pas un nombre, on VOIT une part
      // qui se vide. L'anneau entoure le décompte d'un pas minuté (et lui seul), et
      // sa part se dérive de la phase courante — le chrono n'a gagné aucun champ.
      assert.equal(await p.locator(".entrainement-anneau .entrainement-chrono").count(), 1,
        "un pas minuté porte son anneau de décompte (UI-5)");
      {
        const part = Number(await p.locator(".entrainement-anneau").evaluate((n) => getComputedStyle(n).getPropertyValue("--part")));
        assert.ok(part > 0 && part <= 1, "la part de l'anneau est une fraction lisible : " + part);
      }
      // La jauge de séance dit où l'on en est, sans avoir à lire « 2 / 6 ».
      assert.equal(await p.locator(".entrainement-jauge").count(), 1, "la séance porte sa jauge de progression (UI-5)");
      assert.equal(await p.locator(".entrainement-chrono-controles .bouton", { hasText: "Pause" }).count(), 1, "un bouton Pause est présent (D-125)");
      await p.locator(".entrainement-chrono-controles .bouton", { hasText: "Pause" }).click(); // pause
      await finit(async () => assert.equal(await p.locator(".entrainement-chrono.en-pause").count(), 1, "le chrono en pause est signalé (D-125)"));
      assert.equal(await p.locator(".entrainement-son").count(), 1, "un réglage de son (voix/bips) est présent (D-125)");
      // le réglage cycle voix+bips → voix → bips → muet (D-125)
      assert.match(await p.locator(".entrainement-son").innerText(), /Voix \+ bips/i, "par défaut : voix + bips");
      await p.locator(".entrainement-son").click();
      await finit(async () => assert.match(await p.locator(".entrainement-son").innerText(), /Voix/i, "un clic passe à voix seule"));
      await p.locator(".entrainement-actions .bouton", { hasText: "Quitter" }).click();
      await p.waitForSelector(".fiche-compo-tete"); // quitter revient à la FICHE (UI-2)
      // D-125 : à zéro, le chrono passe SEUL au pas suivant (segment d'1 s).
      await p.evaluate(() => {
        const app = document.querySelector("movenso-app");
        const t = app.bibliotheque.techniques[0];
        app.bibliotheque.compositions.push({
          id: "0000000000000000000000CMP2", nom: "Auto", provenance: "personnel", creeLe: new Date().toISOString(),
          blocs: [
            { id: "0000000000000000000000BK21", type: "etape", texte: "court", dureeSec: 1, medias: [] },
            { id: "0000000000000000000000BK22", type: "technique", techniqueId: t.id, medias: [] },
          ],
        });
        app.ouvrirComposition("0000000000000000000000CMP2");
      });
      await p.waitForSelector('.barre .bouton-icone[aria-label="Passer en revue"]');
      // D-125 : transition de PRÉPARATION (3 s) avant le pas minuté — « Préparez-vous ».
      await p.evaluate(() => { document.querySelector("movenso-app").definirTransition(3); window.__voix = []; });
      await p.locator('.barre .bouton-icone[aria-label="Passer en revue"]').click();
      await p.waitForSelector(".entrainement-prepa");
      assert.match(await p.locator(".entrainement-prepa").innerText(), /Préparez-vous/i, "la préparation s'affiche avant le pas minuté (D-125)");
      await p.waitForFunction(
        () => (document.querySelector(".entrainement-progression")?.textContent ?? "").trim().startsWith("2 /"),
        null,
        { timeout: 9000 },
      ); // préparation (3 s) puis décompte (1 s) → avance sans clic
      const voix = await p.evaluate(() => window.__voix);
      assert.ok(voix.some((t) => /Préparez-vous/i.test(t)), "la voix annonce la préparation (D-125)");
      assert.ok(voix.some((t) => /court, 1 seconde/i.test(t)), "puis le nom + la durée du segment (D-125)");
      await p.locator(".entrainement-actions .bouton", { hasText: "Quitter" }).click();
      await p.waitForSelector(".fiche-compo-tete"); // quitter revient à la FICHE (UI-2)
      // D-126 : SORTIR du player coupe le chrono — pas d'auto-avance qui
      // ré-ouvrirait l'écran (ni son résiduel). Prépa 0 → le segment d'1 s
      // s'auto-avancerait à ~1 s si le chrono continuait après la sortie.
      await p.evaluate(() => document.querySelector("movenso-app").definirTransition(0));
      await p.evaluate(() => document.querySelector("movenso-app").demarrerEntrainement("0000000000000000000000CMP2"));
      await p.waitForSelector(".ecran.entrainement");
      await p.evaluate(() => document.querySelector("movenso-app").retour()); // sortie « retour Android »
      await p.waitForTimeout(lent(2000)); // > durée du segment : un chrono qui traîne ré-ouvrirait le player
      assert.equal(await p.locator(".ecran.entrainement").count(), 0, "sortir coupe le chrono — pas de retour forcé dans le player (D-126)");
      // S2.2 (D-169) : TERMINER proprement une séance — au dernier pas le bouton
      // devient « Terminer », le résumé dit la durée RÉALISÉE, Fermer sort net.
      await p.evaluate(() => { document.querySelector("movenso-app").definirTransition(0); window.__voix = []; });
      await p.evaluate(() => document.querySelector("movenso-app").demarrerEntrainement("0000000000000000000000CMP2"));
      await p.waitForSelector(".ecran.entrainement");
      // bloc 1 minuté (1 s, prépa 0) → auto-avance vers le bloc 2 (dernier, manuel)
      await p.waitForFunction(
        () => (document.querySelector(".entrainement-progression")?.textContent ?? "").trim().startsWith("2 /"),
        null, { timeout: 8000 },
      );
      assert.equal(await p.locator(".entrainement-actions .bouton.principal", { hasText: "Suivant" }).count(), 0, "au dernier pas, plus de « Suivant » grisé");
      await p.locator(".entrainement-actions .bouton.principal", { hasText: "Terminer" }).click();
      await p.waitForSelector(".entrainement-resume");
      const resumeTexte = await p.locator(".entrainement-resume").innerText();
      assert.match(resumeTexte, /Séance terminée/i, "le résumé dit la fin");
      assert.match(resumeTexte, /2 pas parcourus/, "le résumé compte les pas");
      assert.match(resumeTexte, /durée réalisée/, "le résumé donne la durée réellement écoulée");
      assert.ok((await p.evaluate(() => window.__voix)).some((t) => /Séance terminée/i.test(t)), "la fin est annoncée vocalement");
      await p.locator(".entrainement-resume .bouton.principal", { hasText: "Fermer" }).click();
      await finit(async () => assert.equal(await p.locator(".ecran.entrainement").count(), 0, "Fermer sort du pas-à-pas sans ambiguïté"));
      // S2.2 : un DERNIER pas minuté conclut SEUL la séance (auto-avance → résumé)
      await p.evaluate(() => {
        const app = document.querySelector("movenso-app");
        app.bibliotheque.compositions.push({
          id: "0000000000000000000000CMP3", nom: "Solo minuté", provenance: "personnel", creeLe: new Date().toISOString(),
          blocs: [{ id: "0000000000000000000000BK31", type: "etape", texte: "unique", dureeSec: 1, medias: [] }],
        });
        app.demarrerEntrainement("0000000000000000000000CMP3");
      });
      await p.waitForSelector(".entrainement-resume", { timeout: 8000 });
      assert.match(await p.locator(".entrainement-resume").innerText(), /1 pas parcourus?/, "le dernier pas minuté conclut seul la séance");
      await p.locator(".entrainement-resume .bouton.principal", { hasText: "Fermer" }).click();
      await rendu(p);
      // S2.3 (D-170) : l'ARRIÈRE-PLAN suspend la séance (les minuteurs d'un
      // onglet caché dérivent — recette appareil) et l'entraînement pose un
      // verrou d'écran (wake lock) pour que l'écran ne s'éteigne pas tout seul.
      await p.evaluate(() => {
        const app = document.querySelector("movenso-app");
        window.__verrous = [];
        Object.defineProperty(navigator, "wakeLock", {
          configurable: true,
          value: {
            request: async () => {
              window.__verrous.push("request");
              return { released: false, release() { this.released = true; window.__verrous.push("release"); return Promise.resolve(); } };
            },
          },
        });
        app.bibliotheque.compositions.push({
          id: "0000000000000000000000CMP4", nom: "Fond", provenance: "personnel", creeLe: new Date().toISOString(),
          blocs: [{ id: "0000000000000000000000BK41", type: "etape", texte: "long", dureeSec: 120, medias: [] }],
        });
        app.demarrerEntrainement("0000000000000000000000CMP4");
      });
      await p.waitForSelector(".entrainement-chrono");
      assert.ok((await p.evaluate(() => window.__verrous)).includes("request"), "l'entraînement pose un verrou d'écran (S2.3/D-170)");
      await p.evaluate(() => {
        Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "hidden" });
        document.dispatchEvent(new Event("visibilitychange"));
      });
      await finit(async () => assert.equal(await p.locator(".entrainement-chrono.en-pause").count(), 1, "l'arrière-plan met la séance en pause (S2.3/D-170)"));
      assert.ok((await p.locator(".ecran.entrainement").innerText()).includes("mise en pause"), "le bandeau explique la pause automatique");
      {
        const restantFige = await p.locator(".entrainement-chrono").innerText();
        await p.waitForTimeout(lent(1600));
        assert.equal(await p.locator(".entrainement-chrono").innerText(), restantFige, "suspendue : le décompte ne bouge plus");
      }
      // retour au premier plan : la séance RESTE en pause (reprise d'un geste, jamais automatique)
      await p.evaluate(() => {
        Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "visible" });
        document.dispatchEvent(new Event("visibilitychange"));
      });
      await finit(async () => assert.equal(await p.locator(".entrainement-chrono.en-pause").count(), 1, "au retour, la séance reste en pause"));
      await p.locator(".entrainement-chrono-controles .bouton", { hasText: "Reprendre" }).click();
      await finit(async () => assert.equal(await p.locator(".entrainement-chrono.en-pause").count(), 0, "▶ Reprendre relance le décompte"));
      assert.equal(await p.locator(".entrainement-pause-auto").count(), 0, "le bandeau de pause auto disparaît à la reprise");
      await p.locator(".entrainement-actions .bouton", { hasText: "Quitter" }).click();
      await finit(async () => assert.ok((await p.evaluate(() => window.__verrous)).includes("release"), "quitter relâche le verrou d'écran (S2.3/D-170)"));
      // D-126 : édition INLINE en lecture — ✕ retire un pas, ＋ ouvre l'ajout (sans crayon).
      await p.evaluate(() => document.querySelector("movenso-app").ouvrirComposition("0000000000000000000000CMP1"));
      // UI-2 (D-319) : la composition s'ouvre en fiche ; le ✎ mène à l'éditeur,
      // où vivent ＋ Ajouter et les outils de chaque pas.
      await p.waitForSelector(".fiche-compo-tete");
      await p.locator(".basculer-edition").click();
      await p.waitForSelector(".composition-titre-lecture");
      assert.equal(await p.locator(".ajouter-pas-inline").count(), 1, "＋ Ajouter un élément vit dans l'éditeur (UI-2)");
      const avantInline = await p.locator(".bloc:not(.menu-bloc)").count();
      assert.ok(avantInline >= 1, "CMP1 a au moins un pas");
      await p.locator('.bloc:not(.menu-bloc) [aria-label="Retirer ce pas"]').first().click(); // ✕ retire un pas
      await finit(async () => assert.equal(await p.locator(".bloc:not(.menu-bloc)").count(), avantInline - 1, "✕ retire un pas directement en lecture (D-126)"));
      await p.locator(".ajouter-pas-inline").click();
      await p.waitForSelector('.feuille[aria-label="Ajouter un élément"]');
      await p.locator('.feuille[aria-label="Ajouter un élément"] .actions .bouton', { hasText: "Terminer" }).click();
      await p.waitForSelector(".bloc:not(.menu-bloc)");
      // D-126 : ÉDITION UNITAIRE — ✎ ouvre une mini-feuille limitée au type du pas.
      await p.locator('.bloc:not(.menu-bloc) [aria-label="Détails de ce pas"]').first().click();
      await p.waitForSelector('.feuille[aria-label="Modifier le pas"]');
      assert.equal(await p.locator('.feuille[aria-label="Modifier le pas"] .duree-roues select').count(), 2, "la mini-feuille porte les molettes min + s (D-126)");
      await p.locator('.feuille[aria-label="Modifier le pas"] .actions .bouton.principal', { hasText: "Terminer" }).click();
      await p.waitForSelector(".bloc:not(.menu-bloc)");
      await p.locator(".barre-nav .nav-onglet", { hasText: "Bibliothèque" }).click(); // revenir pour la suite
      await p.waitForSelector(".marque");
    }
    // (6) filtre : la puce Judo ouvre l'écran de la discipline (deux fiches).
    // Le filtre par SOURCE a été retiré (tuning post-V3) : on vérifie que les
    // deux identités homonymes coexistent bien dans la discipline réunie.
    await p.locator(".chip-discipline", { hasText: "Judo" }).click();
    await p.waitForSelector(".carte-technique");
    assert.equal(await p.locator(".carte-nom", { hasText: "Ashi-guruma" }).count(), 2, "les deux fiches doivent être présentes dans la discipline");
    // (8) deux colonnes sur téléphone (400px)
    const colonnes = await p.evaluate(() => getComputedStyle(document.querySelector(".grille")).gridTemplateColumns.trim().split(/\s+/).length);
    assert.equal(colonnes, 2, "la grille doit afficher deux colonnes sur téléphone");
    // (9) Plus › « Doublons potentiels » propose la paire (liste d'abord, D-071),
    // puis le détail à la sélection montre ses deux côtés (le badge/méta de source
    // par côté a été retiré du détail — tuning post-V3)
    await ouvrirPlus(p, "Doublons potentiels");
    await p.waitForSelector(".ligne-doublon");
    assert.equal(await p.locator(".ligne-doublon").count(), 1, "une paire de doublons potentiels doit être détectée");
    // la sous-ligne annonce des noms identiques venus de deux sources
    assert.ok((await p.locator(".ligne-doublon").first().innerText()).includes("même nom, deux sources"), "la ligne compacte doit résumer la paire homonyme");
    await p.locator(".ligne-doublon").first().click();
    await p.waitForSelector(".doublon");
    assert.equal(await p.locator(".doublon .doublon-cote").count(), 2, "la paire doit montrer ses deux côtés");
    // les deux côtés portent des titres distincts (A · … / B · …)
    const titresDoublon = await p.locator(".doublon .doublon-cote .doublon-titre").allInnerTexts();
    assert.equal(titresDoublon.length, 2, "chaque côté doit porter son titre : " + titresDoublon.join(" | "));
    // (7) supprimer UNE fiche → l'autre survit ; la suppression vit désormais
    // dans Plus › « Techniques » (entrée de menu à part entière, post-V3)
    await ouvrirPlus(p, "Gestion des techniques");
    await p.fill(".recherche input", "ashi-guruma");
    await rendu(p);
    await p.locator('.supprimer-technique[aria-label="Retirer Ashi-guruma"]').first().click();
    await p.waitForSelector(".feuille-confirmation"); // C2 : feuille nommée
    await p.locator(".feuille-confirmation .bouton.danger").click();
    await p.waitForTimeout(lent(400));
    await allerRacineBiblio(p);
    assert.equal(await p.locator(".carte-nom", { hasText: "Ashi-guruma" }).count(), 1, "après suppression d'une fiche, l'autre Ashi-guruma doit subsister");
    await ctxDF.close();
  }

  /* --- (11) Fusionner en une fiche --- */
  {
    const ctxMg = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
    const p = await ctxMg.newPage();
    surveiller(p);
    await p.goto("http://localhost:4517/");
    await p.waitForSelector(".action-douce");
    await installerPaire(p);
    await ouvrirPlus(p, "Doublons potentiels");
    await p.locator(".ligne-doublon").first().click();
    await p.waitForSelector(".doublon");
    await p.locator(".doublon-decisions .chip-filtre", { hasText: "Fusionner" }).click();
    await p.waitForSelector(".fusion-panneau");
    // S2.6 (D-168) : les impacts externes et le point de restauration sont
    // DITS avant de fusionner — jamais une fusion à l'aveugle.
    assert.match(await p.locator(".fusion-impacts").innerText(), /point de restauration.*défusionnable/is, "le panneau de fusion annonce le point de restauration et la défusion");
    // choix par défaut (titre A, médias les deux) — le défaut « Textes » est
    // désormais « les deux » (tuning post-V3), aucun PIN configuré
    await p.locator(".fusion-panneau .bouton.principal", { hasText: "Fusionner en une fiche" }).click();
    await p.waitForTimeout(lent(400));
    await allerRacineBiblio(p);
    assert.equal(await p.locator(".carte-nom", { hasText: "Ashi-guruma" }).count(), 1, "après fusion, une SEULE fiche Ashi-guruma doit rester");
    await p.locator(".carte-technique", { hasText: "Ashi-guruma" }).first().locator(".carte-ouvrir").click();
    await p.waitForSelector(".bloc-lecture");
    // la présentation affichée reste cohérente (une voix montrée à la fois)
    assert.ok((await p.locator(".bloc-lecture").first().innerText()).includes("Version Kodokan"), "la fiche fusionnée doit porter une présentation cohérente");
    // défaut « Textes : les deux » (tuning post-V3) : les DEUX contributions
    // survivent à la fusion, chacune avec son texte (vérifié sur les données).
    const textesFusion = await p.evaluate(() => {
      const app = document.querySelector("movenso-app");
      const t = app.bibliotheque.techniques.find((x) => x.nom === "Ashi-guruma");
      return app.bibliotheque.contributions
        .filter((c) => c.techniqueId === t.id && c.provenance !== "personnel")
        .map((c) => c.description ?? "");
    });
    assert.ok(textesFusion.some((d) => d.includes("Version Kodokan")), "la fusion doit conserver le texte A");
    assert.ok(textesFusion.some((d) => d.includes("Version club")), "le défaut « Textes : les deux » doit conserver AUSSI le texte B après fusion");
    // D-101 (voie H) : la fusion est DÉFUSIONNABLE — rétablit les deux fiches.
    await ouvrirPlus(p, "Doublons potentiels");
    assert.ok((await p.locator(".carte-atelier", { hasText: "Fusions réversibles" }).count()) >= 1, "la fusion doit apparaître dans « Fusions réversibles »");
    await p.locator("button.chip-filtre", { hasText: "Défuser" }).first().click();
    await p.waitForTimeout(lent(400));
    const nbApresDefusion = await p.evaluate(() =>
      document.querySelector("movenso-app").bibliotheque.techniques.filter((t) => /ashi.?guruma/i.test(t.nom)).length,
    );
    assert.equal(nbApresDefusion, 2, "après défusion, les DEUX fiches Ashi-guruma d'origine reviennent");
    await ctxMg.close();
  }

  /* --- (10) Conserver les deux → la paire disparaît, les deux fiches restent --- */
  {
    const ctxCo = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
    const p = await ctxCo.newPage();
    surveiller(p);
    await p.goto("http://localhost:4517/");
    await p.waitForSelector(".action-douce");
    await installerPaire(p);
    await ouvrirPlus(p, "Doublons potentiels");
    await p.locator(".ligne-doublon").first().click();
    await p.waitForSelector(".doublon");
    await p.locator(".doublon-decisions .chip-filtre", { hasText: "Conserver les deux" }).click();
    await p.waitForTimeout(lent(300));
    assert.equal(await p.locator(".doublon").count(), 0, "« Conserver les deux » doit retirer la paire de la liste");
    await allerRacineBiblio(p);
    assert.equal(await p.locator(".carte-nom", { hasText: "Ashi-guruma" }).count(), 2, "« Conserver les deux » doit laisser les deux fiches intactes");
    await ctxCo.close();
  }

  /* --- (12) Ce ne sont pas des doublons → plus jamais proposé pour cette paire --- */
  {
    const ctxNo = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
    const p = await ctxNo.newPage();
    surveiller(p);
    await p.goto("http://localhost:4517/");
    await p.waitForSelector(".action-douce");
    await installerPaire(p);
    await ouvrirPlus(p, "Doublons potentiels");
    await p.locator(".ligne-doublon").first().click();
    await p.waitForSelector(".doublon");
    await p.locator(".doublon-decisions .chip-filtre", { hasText: "Ce ne sont pas des doublons" }).click();
    await p.waitForTimeout(lent(300));
    assert.equal(await p.locator(".doublon").count(), 0, "« Ce ne sont pas des doublons » doit écarter la paire");
    // rouvrir Plus › Doublons : la paire écartée n'est plus reproposée
    await allerRacineBiblio(p);
    await ouvrirPlus(p, "Doublons potentiels");
    await finit(async () => assert.equal(await p.locator(".doublon").count(), 0, "la paire écartée ne doit plus jamais être proposée"));
    assert.equal(await p.locator(".ligne-doublon").count(), 0, "la paire écartée ne doit plus figurer dans la liste");
    await ctxNo.close();
  }
}
}
