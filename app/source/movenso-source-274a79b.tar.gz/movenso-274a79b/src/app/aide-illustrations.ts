/**
 * ILLUSTRATIONS DE L'AIDE ET D'À PROPOS (D-362) — un sprite, un seul lieu.
 *
 * Ce sont des CALQUES D'ATTENTE, et le dire est le point de ce fichier : le
 * porteur a fourni dix rendus 3D, mais une image jointe à une conversation ne
 * peut pas être enregistrée sur le disque par une session d'agent. Chaque
 * symbole reprend donc la COMPOSITION du rendu correspondant — mêmes objets,
 * même disposition, même cadrage — pour que l'écran soit juste tout de suite.
 *
 * Le procédé a un précédent exact : D-331 a écrit à la main des SVG qui
 * approchaient les rendus du porteur, et D-332 les a remplacés par ses WebP.
 * La bascule ici tient en une ligne par emplacement : `vignette(cle)` devient
 * un `<img src="/img/aide/<cle>.webp">`. Le contrat de nommage vit dans
 * `docs/execution/lots/aide-apropos-refonte.md` §7bis.
 *
 * TROIS manquent à la série fournie et sont dessinés sans modèle :
 * `partager` (un colis À CÔTÉ d'un coffre — la rubrique dit qu'il y a deux
 * objets, une image à un seul contredirait sa phrase), `securite` et `porte`.
 *
 * PALETTE FIXE, jamais les tokens de thème : une illustration ne suit pas la
 * tonalité (D-136). Elle garde ses couleurs en clair comme en sombre, comme
 * les cinq WebP de la première ouverture (D-332).
 */

import { html, svg, type TemplateResult } from "lit";
import { urlIllustrationAide } from "./services/illustrations-aide.ts";

/** Clés d'illustration — le compilateur refuse une vignette qui n'existe pas. */
export type CleIllustration =
  | "demarrer" | "retrouver" | "fiche" | "medias" | "relations"
  | "partager" | "donnees" | "securite" | "limites"
  | "heros-apropos" | "heros-aide" | "licences" | "porte";

/* ---------- PRÉCÉDENCE (D-363) ----------
   1. l'image servie par le SITE, si elle est arrivée — zéro octet dans l'app ;
   2. sinon le CALQUE dessiné ci-dessous.
   Le repli n'est pas une panne : c'est l'état normal hors ligne, et l'état
   permanent tant que les fichiers du porteur ne sont pas déposés. Le jour où
   une illustration est EMBARQUÉE (les deux héros, décidés le 2026-08-17), son
   symbole disparaît d'ici et la fonction sert un `<img>` local : la bascule
   est une suppression, jamais une réécriture (procédé D-331 → D-332). */

/** Une vignette. Décorative, donc masquée aux lecteurs d'écran. */
export function vignette(cle: CleIllustration, classe = "aide-vignette"): TemplateResult {
  const distante = urlIllustrationAide(cle);
  return distante
    ? html`<img class=${classe} src=${distante} alt="" aria-hidden="true" decoding="async">`
    : html`<svg class=${classe} viewBox="0 0 120 120" aria-hidden="true"><use href="#ill-${cle}"></use></svg>`;
}

/** Une illustration de format libre (héros, carte majeure). */
export function illustration(cle: CleIllustration, classe: string, boite = "0 0 120 120"): TemplateResult {
  const distante = urlIllustrationAide(cle);
  return distante
    ? html`<img class=${classe} src=${distante} alt="" aria-hidden="true" decoding="async">`
    : html`<svg class=${classe} viewBox=${boite} aria-hidden="true"><use href="#ill-${cle}"></use></svg>`;
}

/** Les clés que porte un écran — ce qu'il demande au site en arrivant. */
export const CLES_AIDE: readonly CleIllustration[] = [
  "heros-aide", "demarrer", "retrouver", "fiche", "medias", "relations",
  "partager", "donnees", "securite", "limites",
];
export const CLES_APROPOS: readonly CleIllustration[] = ["heros-apropos", "donnees", "licences", "porte"];

/** Le sprite. Rendu UNE fois par écran qui s'en sert — les `<use>` y puisent.
 *  Un seul lieu de définition : deux copies divergeraient (D-253). */
export const SPRITE_ILLUSTRATIONS: TemplateResult = html`
<svg class="ill-sprite" width="0" height="0" aria-hidden="true" focusable="false">${svg`
<defs>
<style>
  .il-f{fill:#F5F1E8}.il-s{fill:#93A48C}.il-sc{fill:#6E8168}.il-c{fill:#DD6A4E}.il-c2{fill:#C4553F}
  .il-b{fill:#6B5645}.il-bl{fill:#A08A73}.il-k{fill:#E7E0D0}.il-w{fill:#FCFAF6}.il-n{fill:#1C1A18}
  .il-n2{fill:#2A2724}.il-kr{fill:#C09A6B}.il-kr2{fill:#A8814F}.il-kr3{fill:#D9BC94}
  .il-pa{fill:#E6DCC6}.il-pa2{fill:#CFC2A6}.il-g{fill:#8A8378}.il-o{fill:#000;opacity:.26}
</style>

<symbol id="ill-demarrer" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="104" rx="43" ry="7"/>
  <path class="il-kr3" d="M52 20 84 12l24 16-30 8Z"/><path class="il-kr" d="M12 30 40 18l16 12-28 12Z"/>
  <path class="il-n" d="M24 46h72v46a6 6 0 0 1-6 6H30a6 6 0 0 1-6-6Z"/>
  <path class="il-n2" d="M24 46h36v52H30a6 6 0 0 1-6-6Z"/>
  <rect class="il-c" x="82" y="72" width="12" height="7" rx="2"/>
  <g transform="rotate(-6 56 42)"><rect class="il-n" x="42" y="18" width="30" height="42" rx="3"/>
    <rect class="il-n2" x="66" y="18" width="4" height="42"/>
    <g fill="#DD6A4E"><circle cx="52" cy="34" r="3"/><circle cx="62" cy="28" r="2.6"/><circle cx="58" cy="44" r="2.6"/></g>
    <g stroke="#DD6A4E" stroke-width="1.6"><path d="M53 33.6 60 29m-3.6 7.4L58 42"/></g>
    <circle cx="57" cy="38" r="4.6" fill="none" stroke="#DD6A4E" stroke-width="1.8"/></g>
  <g transform="rotate(-10 42 60)"><rect class="il-bl" x="30" y="42" width="26" height="34" rx="3"/>
    <rect class="il-pa" x="26" y="46" width="26" height="34" rx="3"/>
    <path class="il-c" d="m32 51 1.6 3.4 3.6.4-2.8 2.4.9 3.6-3.3-2-3.3 2 .9-3.6-2.8-2.4 3.6-.4Z"/>
    <g class="il-pa2"><rect x="30" y="63" width="18" height="2" rx="1"/><rect x="30" y="68" width="18" height="2" rx="1"/>
      <rect x="30" y="73" width="12" height="2" rx="1"/></g></g>
  <rect class="il-bl" x="72" y="40" width="22" height="20" rx="4"/><rect class="il-kr3" x="70" y="36" width="26" height="7" rx="2"/>
  <path class="il-s" d="M83 36c0-11 5-17 13-17 0 11-5 17-13 17Z"/>
  <path class="il-sc" d="M81 36c-8 0-13-5-13-13 8 0 13 5 13 13Z"/>
  <path class="il-s" d="M84 34c2-9 8-13 15-11-3 8-8 12-15 11Z"/>
  <rect class="il-n" x="96" y="42" width="5" height="26" rx="2.5" transform="rotate(10 98 55)"/></symbol>

<symbol id="ill-retrouver" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="106" rx="42" ry="7"/>
  <g transform="rotate(4 92 56)"><rect class="il-bl" x="76" y="20" width="30" height="72" rx="4"/>
    <rect class="il-pa" x="80" y="24" width="26" height="68" rx="3"/><rect class="il-c" x="74" y="30" width="8" height="12" rx="2"/></g>
  <rect class="il-n" x="14" y="20" width="66" height="76" rx="8"/>
  <rect class="il-n2" x="20" y="26" width="54" height="12" rx="6"/>
  <circle cx="28" cy="32" r="3.4" fill="none" stroke="#8A8378" stroke-width="1.6"/>
  <path stroke="#8A8378" stroke-width="1.6" d="m31 35 3 3"/>
  <rect class="il-pa" x="20" y="43" width="54" height="17" rx="5"/>
  <circle class="il-g" cx="30" cy="51" r="4.4"/>
  <g class="il-pa2"><rect x="39" y="47" width="26" height="3" rx="1.5"/><rect x="39" y="54" width="18" height="3" rx="1.5"/></g>
  <rect class="il-n2" x="20" y="64" width="54" height="17" rx="5"/>
  <circle class="il-g" cx="30" cy="72" r="4.4" opacity=".7"/>
  <g class="il-g" opacity=".55"><rect x="39" y="68" width="26" height="3" rx="1.5"/><rect x="39" y="75" width="18" height="3" rx="1.5"/></g>
  <circle cx="63" cy="55" r="21" fill="#E6DCC6" opacity=".16"/>
  <circle cx="63" cy="55" r="21" fill="none" stroke="#C08A5E" stroke-width="4"/>
  <circle class="il-c" cx="52" cy="51" r="4.4"/>
  <rect class="il-n" x="76" y="70" width="8" height="26" rx="4" transform="rotate(-40 80 83)"/>
  <rect class="il-c" x="10" y="76" width="20" height="20" rx="5"/>
  <path class="il-pa" d="m20 81 1.8 3.8 4.2.5-3.1 2.8 1 4.2-3.9-2.3-3.9 2.3 1-4.2-3.1-2.8 4.2-.5Z"/></symbol>

<symbol id="ill-fiche" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="107" rx="40" ry="7"/>
  <g transform="rotate(-3 60 58)">
    <rect class="il-n" x="26" y="12" width="66" height="88" rx="7"/>
    <rect class="il-pa" x="32" y="16" width="58" height="82" rx="4"/>
    <rect class="il-g" x="44" y="22" width="42" height="24" rx="3"/>
    <path class="il-n2" d="m44 46 12-11 8 7 6-6 16 10Z"/><circle class="il-c" cx="76" cy="28" r="4.4"/>
    <rect class="il-n2" x="44" y="50" width="30" height="5" rx="2.5"/>
    <g class="il-pa2"><rect x="44" y="60" width="42" height="4" rx="2"/><rect x="44" y="68" width="42" height="4" rx="2"/>
      <rect x="44" y="76" width="34" height="4" rx="2"/><rect x="44" y="84" width="38" height="4" rx="2"/></g>
    <rect class="il-n" x="33" y="58" width="9" height="9" rx="2.5"/><rect class="il-c" x="33" y="70" width="9" height="9" rx="2.5"/>
    <rect class="il-n" x="33" y="82" width="9" height="9" rx="2.5"/>
    <path class="il-kr3" d="M90 24h14v22l-6-5-8 5Z" opacity=".9"/></g>
  <path class="il-c" d="M84 8h10v20l-5-4.6L84 28Z"/>
  <rect class="il-n" x="92" y="72" width="7" height="30" rx="3.5" transform="rotate(20 95 87)"/>
  <circle cx="26" cy="88" r="10" fill="none" stroke="#1C1A18" stroke-width="3.4"/>
  <circle cx="26" cy="88" r="8" fill="#E6DCC6" opacity=".2"/>
  <rect class="il-n" x="30" y="94" width="6" height="14" rx="3" transform="rotate(-40 33 101)"/></symbol>

<symbol id="ill-medias" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="104" rx="42" ry="7"/>
  <g transform="rotate(-7 40 46)"><rect class="il-pa" x="18" y="22" width="34" height="32" rx="2"/>
    <rect class="il-g" x="21" y="25" width="28" height="22"/><path class="il-n2" d="m21 47 9-10 6 6 5-6 12 10Z"/>
    <circle class="il-c" cx="29" cy="32" r="3.4"/></g>
  <rect class="il-kr" x="34" y="30" width="30" height="26" rx="3" opacity=".75"/>
  <rect class="il-n" x="42" y="34" width="52" height="44" rx="6"/>
  <g class="il-pa"><rect x="45" y="38" width="6" height="6" rx="1.4"/><rect x="45" y="48" width="6" height="6" rx="1.4"/>
    <rect x="45" y="58" width="6" height="6" rx="1.4"/><rect x="45" y="68" width="6" height="6" rx="1.4"/>
    <rect x="85" y="38" width="6" height="6" rx="1.4"/><rect x="85" y="48" width="6" height="6" rx="1.4"/>
    <rect x="85" y="58" width="6" height="6" rx="1.4"/><rect x="85" y="68" width="6" height="6" rx="1.4"/></g>
  <rect class="il-n2" x="55" y="40" width="26" height="32" rx="4"/><path class="il-c" d="m64 48 12 8-12 8Z"/>
  <circle class="il-n" cx="26" cy="76" r="15"/><circle class="il-n2" cx="26" cy="76" r="4"/>
  <g class="il-n2"><circle cx="26" cy="68" r="3.4"/><circle cx="33" cy="80" r="3.4"/><circle cx="19" cy="80" r="3.4"/></g>
  <path class="il-n" d="M36 84c10-4 22-2 30 6H40Z"/>
  <rect class="il-c" x="90" y="66" width="22" height="22" rx="6"/>
  <path fill="none" stroke="#E6DCC6" stroke-width="2.6" stroke-linecap="round" d="M97 79a4 4 0 0 1 0-6l2-2m6 0a4 4 0 0 1 0 6l-2 2m-4-4 4-4"/>
  <path class="il-s" d="M104 40c0-11 5-17 13-17 0 11-5 17-13 17Z"/>
  <path class="il-sc" d="M102 42c-8 0-13-5-13-13 8 0 13 5 13 13Z"/></symbol>

<symbol id="ill-relations" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="104" rx="42" ry="7"/>
  <rect class="il-n" x="30" y="38" width="56" height="46" rx="7" transform="rotate(-4 58 61)"/>
  <rect class="il-n2" x="76" y="34" width="34" height="34" rx="6"/>
  <rect class="il-c" x="80" y="38" width="7" height="7" rx="3.5"/><rect class="il-c" x="90" y="40" width="16" height="3.4" rx="1.7"/>
  <rect class="il-kr3" x="80" y="49" width="7" height="7" rx="3.5"/><rect class="il-g" x="90" y="51" width="16" height="3.4" rx="1.7"/>
  <rect class="il-kr3" x="80" y="60" width="7" height="7" rx="3.5"/><rect class="il-g" x="90" y="62" width="12" height="3.4" rx="1.7"/>
  <g stroke="#E6DCC6" stroke-width="4" stroke-linecap="round"><path d="M58 56 40 34m18 22 26-14m-26 14-24 12m24-12 4 26"/></g>
  <circle class="il-n" cx="40" cy="32" r="11"/><circle class="il-kr3" cx="40" cy="32" r="5.4"/>
  <circle class="il-n" cx="88" cy="26" r="11"/><circle class="il-c" cx="88" cy="26" r="5.4"/>
  <circle class="il-n" cx="26" cy="62" r="10"/><circle class="il-c" cx="26" cy="62" r="5"/>
  <circle class="il-n" cx="56" cy="86" r="11"/><circle class="il-kr3" cx="56" cy="86" r="5.4"/>
  <circle class="il-c2" cx="58" cy="56" r="15"/><circle class="il-c" cx="58" cy="53" r="12"/>
  <path fill="none" stroke="#EFA48C" stroke-width="4" stroke-linecap="round" d="M72 58c10 2 12 12 20 16"/>
  <path class="il-c" d="m90 68 12 8-12 6Z"/>
  <g transform="rotate(-4 20 84)"><rect class="il-n" x="4" y="70" width="34" height="26" rx="4"/>
    <rect class="il-pa" x="8" y="68" width="32" height="26" rx="3"/><rect class="il-c" x="4" y="72" width="6" height="8" rx="2"/>
    <g class="il-pa2"><rect x="24" y="76" width="13" height="2.6" rx="1.3"/><rect x="24" y="82" width="13" height="2.6" rx="1.3"/></g>
    <circle cx="16" cy="80" r="5" fill="none" stroke="#8A8378" stroke-width="1.6"/></g></symbol>

<symbol id="ill-donnees" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="104" rx="44" ry="7"/>
  <rect class="il-n" x="36" y="18" width="62" height="60" rx="8"/>
  <rect class="il-n2" x="42" y="24" width="50" height="48" rx="5"/>
  <circle class="il-c2" cx="76" cy="48" r="11"/>
  <path fill="#E6DCC6" opacity=".9" d="M76 41c3 1.4 5 1.6 6 1.6 0 6-2 9-6 11-4-2-6-5-6-11 1 0 3-.2 6-1.6Z"/>
  <path fill="none" stroke="#C4553F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="m73.6 47.6 1.8 1.8 3.4-3.6"/>
  <rect class="il-g" x="50" y="42" width="9" height="14" rx="4.5"/><rect class="il-g" x="53" y="38" width="4" height="8" rx="2"/>
  <g class="il-n"><rect x="94" y="30" width="5" height="10" rx="2"/><rect x="94" y="52" width="5" height="10" rx="2"/></g>
  <rect class="il-n" x="16" y="78" width="30" height="22" rx="5"/><rect class="il-n2" x="21" y="82" width="20" height="13" rx="3"/>
  <circle class="il-c" cx="41" cy="97" r="1.8"/>
  <g transform="rotate(-2 82 90)"><rect class="il-bl" x="58" y="82" width="46" height="12" rx="3"/>
    <rect class="il-pa" x="60" y="80" width="42" height="4"/><rect class="il-c" x="64" y="88" width="4" height="10" rx="1.5"/></g>
  <rect class="il-n" x="62" y="70" width="42" height="14" rx="3"/><rect class="il-n2" x="90" y="72" width="10" height="6" rx="2"/>
  <rect class="il-n" x="62" y="68" width="42" height="4" rx="2"/>
  <rect class="il-bl" x="8" y="52" width="22" height="22" rx="5"/>
  <path class="il-s" d="M20 52c0-13 6-20 15-20 0 13-6 20-15 20Z"/>
  <path class="il-sc" d="M17 52C7 52 1 46 1 36c10 0 16 6 16 16Z"/>
  <path class="il-s" d="M21 50c2-11 9-16 18-14-4 10-10 15-18 14Z"/></symbol>

<symbol id="ill-partager" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="104" rx="44" ry="7"/>
  <path class="il-kr" d="M6 44h52v46a6 6 0 0 1-6 6H12a6 6 0 0 1-6-6Z"/>
  <path class="il-kr2" d="M6 44h52v9H6Z"/><rect class="il-c" x="26" y="44" width="12" height="52"/>
  <path class="il-c2" d="M20 34h24l-6 10H26Z"/><rect class="il-kr3" x="14" y="72" width="14" height="9" rx="2"/>
  <rect class="il-n" x="64" y="36" width="50" height="52" rx="7"/><rect class="il-n2" x="70" y="42" width="38" height="40" rx="4"/>
  <circle class="il-c2" cx="96" cy="62" r="9"/>
  <path fill="#E6DCC6" opacity=".9" d="M96 56c2.4 1.2 4 1.4 5 1.4 0 5-1.6 7.4-5 9-3.4-1.6-5-4-5-9 1 0 2.6-.2 5-1.4Z"/>
  <rect class="il-g" x="76" y="57" width="8" height="12" rx="4"/><rect class="il-g" x="78.5" y="53" width="3" height="7" rx="1.5"/>
  <path class="il-s" d="M64 26c0-10 5-15 12-15 0 10-5 15-12 15Z"/>
  <path class="il-sc" d="M62 28c-7 0-12-5-12-12 7 0 12 5 12 12Z"/></symbol>

<symbol id="ill-securite" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="100" rx="42" ry="7"/>
  <path class="il-s" d="M14 74h84v16a6 6 0 0 1-6 6H20a6 6 0 0 1-6-6Z"/><path class="il-sc" d="M14 74h84v5H14Z"/>
  <path class="il-bl" d="M20 60h72v14H20Z"/><path class="il-kr3" d="M20 60h72v4H20Z"/>
  <path class="il-s" d="M26 46h60v14H26Z"/><path class="il-sc" d="M26 46h60v4H26Z"/>
  <g transform="rotate(7 76 32)"><rect class="il-pa" x="56" y="14" width="40" height="34" rx="4"/>
    <circle class="il-c" cx="76" cy="31" r="12"/>
    <path fill="#E6DCC6" d="M74.6 24h3v9h-3zm0 11.6h3v3h-3z"/></g>
  <path class="il-s" d="M28 42c0-12 6-18 14-18 0 12-6 18-14 18Z"/>
  <path class="il-sc" d="M26 44c-9 0-15-6-15-15 9 0 15 6 15 15Z"/></symbol>

<symbol id="ill-limites" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="58" cy="106" rx="40" ry="7"/>
  <rect class="il-bl" x="16" y="14" width="70" height="88" rx="6"/>
  <rect class="il-pa" x="22" y="22" width="58" height="74" rx="4"/>
  <rect class="il-n" x="40" y="8" width="26" height="16" rx="4"/>
  <circle cx="53" cy="14" r="3.4" fill="none" stroke="#E6DCC6" stroke-width="2"/>
  <rect class="il-kr3" x="28" y="32" width="12" height="12" rx="3"/>
  <rect class="il-kr3" x="28" y="50" width="12" height="12" rx="3"/>
  <rect class="il-kr3" x="28" y="68" width="12" height="12" rx="3"/>
  <g fill="none" stroke="#1C1A18" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
    <path d="m31 38 2.6 2.6 4.4-5m-7 20.4 2.6 2.6 4.4-5m-7 20.4 2.6 2.6 4.4-5"/></g>
  <rect class="il-pa2" x="28" y="86" width="12" height="12" rx="3" opacity=".7"/>
  <g class="il-pa2"><rect x="46" y="34" width="30" height="4" rx="2"/><rect x="46" y="41" width="24" height="4" rx="2"/>
    <rect x="46" y="52" width="30" height="4" rx="2"/><rect x="46" y="59" width="20" height="4" rx="2"/>
    <rect x="46" y="70" width="30" height="4" rx="2"/><rect x="46" y="77" width="26" height="4" rx="2"/>
    <rect x="46" y="88" width="24" height="4" rx="2"/></g>
  <g transform="rotate(4 66 88)"><rect class="il-c" x="46" y="70" width="40" height="38" rx="4"/>
    <circle cx="66" cy="89" r="13" fill="none" stroke="#8E3A28" stroke-width="3"/>
    <path fill="#8E3A28" d="M64.4 81h3.2v11h-3.2zm0 13h3.2v3.4h-3.2z"/></g>
  <rect class="il-bl" x="86" y="80" width="24" height="22" rx="5"/>
  <path class="il-s" d="M98 80c0-12 6-18 14-18 0 12-6 18-14 18Z"/>
  <path class="il-sc" d="M96 80c-9 0-15-6-15-15 9 0 15 6 15 15Z"/>
  <path class="il-s" d="M99 78c2-10 8-15 16-13-3 9-9 14-16 13Z"/></symbol>

<symbol id="ill-licences" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="58" cy="104" rx="42" ry="7"/>
  <rect class="il-n" x="10" y="84" width="86" height="16" rx="3"/>
  <rect class="il-c" x="16" y="84" width="5" height="16"/><rect class="il-c" x="84" y="84" width="5" height="16"/>
  <rect class="il-bl" x="18" y="72" width="72" height="14" rx="3"/><rect class="il-pa" x="20" y="70" width="68" height="4"/>
  <path class="il-pa" d="M20 16c0-2 2-4 4-4h56c-4 4-4 8-4 12v56c0 4 0 8 4 12H24c-2 0-4-2-4-4Z"/>
  <path class="il-pa2" d="M76 12c-4 4-4 8-4 12v56c0 4 0 8 4 12 6 0 10-4 10-10V22c0-6-4-10-10-10Z"/>
  <g class="il-pa2"><rect x="30" y="26" width="34" height="5" rx="2.5"/><rect x="30" y="38" width="40" height="4" rx="2"/>
    <rect x="30" y="47" width="40" height="4" rx="2"/><rect x="30" y="56" width="34" height="4" rx="2"/>
    <rect x="30" y="65" width="26" height="4" rx="2"/></g>
  <path fill="none" stroke="#B5A588" stroke-width="1.8" stroke-linecap="round" d="M32 78c4-5 7 2 11-2s6 3 10-1"/>
  <path class="il-n" d="M56 84h7l3 12-6-4-6 4Zm12 0h7l-1 12-6-4-3 3Z"/>
  <circle class="il-c2" cx="66" cy="80" r="13"/><circle class="il-c" cx="66" cy="78" r="11"/>
  <path fill="none" stroke="#8E3A28" stroke-width="1.8" stroke-linecap="round" d="M66 84V74m0 4c-4 0-6-2-6-5 4 0 6 2 6 5Zm0-2c0-3 2-5 6-5 0 3-2 5-6 5Z"/>
  <path class="il-s" d="M96 40c0-12 6-18 14-18 0 12-6 18-14 18Zm4 14c2-12 9-18 18-16-4 11-10 17-18 16Zm-6 16c0-12 6-18 14-18 0 12-6 18-14 18Z"/>
  <path class="il-sc" d="M94 34c-8 0-13-5-13-13 8 0 13 5 13 13Zm0 18c-8 0-13-5-13-13 8 0 13 5 13 13Z"/></symbol>

<symbol id="ill-porte" viewBox="0 0 120 120">
  <ellipse class="il-o" cx="60" cy="102" rx="40" ry="7"/>
  <path class="il-k" d="M20 96V38a6 6 0 0 1 6-6h32v64Z"/>
  <path class="il-w" d="M58 32h34a6 6 0 0 1 6 6v58H58Z"/>
  <path class="il-pa2" d="M58 32h34a6 6 0 0 1 6 6v58H58Z" opacity=".45"/>
  <g class="il-pa2"><rect x="28" y="46" width="22" height="4.4" rx="2.2"/><rect x="28" y="57" width="17" height="4.4" rx="2.2"/></g>
  <circle class="il-c" cx="78" cy="62" r="18"/><circle class="il-w" cx="78" cy="62" r="7.4"/>
  <path class="il-w" d="M65.6 49.6 71 55l-5.4 5.4-5.4-5.4Zm24.8 0L96 55l-5.4 5.4L85.2 55Zm0 24.8L96 69l-5.4-5.4L85.2 69Zm-24.8 0L71 69l-5.4-5.4L60.2 69Z" opacity=".92"/></symbol>

<symbol id="ill-heros-apropos" viewBox="0 0 200 160">
  <ellipse class="il-o" cx="104" cy="140" rx="86" ry="10"/>
  <g transform="rotate(-3 168 34)"><rect class="il-kr3" x="146" y="12" width="42" height="44" rx="2"/>
    <circle class="il-kr2" cx="167" cy="18" r="2.6"/>
    <circle cx="167" cy="34" r="7" fill="none" stroke="#8A6B44" stroke-width="2"/>
    <g fill="#8A6B44"><circle cx="155" cy="28" r="2.6"/><circle cx="179" cy="28" r="2.6"/><circle cx="167" cy="46" r="2.6"/></g>
    <g stroke="#8A6B44" stroke-width="1.6"><path d="m158 30 3 2m12-2-3 2m-3 9v-2"/></g>
    <rect class="il-pa2" x="154" y="50" width="26" height="2.6" rx="1.3"/></g>
  <g transform="rotate(5 130 24)"><rect class="il-c" x="112" y="8" width="34" height="30" rx="2"/>
    <g fill="#A84A34"><rect x="118" y="16" width="22" height="2.4" rx="1.2"/><rect x="118" y="22" width="22" height="2.4" rx="1.2"/>
      <rect x="118" y="28" width="14" height="2.4" rx="1.2"/></g></g>
  <rect class="il-n2" x="60" y="26" width="96" height="72" rx="7"/>
  <rect class="il-n" x="64" y="30" width="88" height="64" rx="4"/>
  <circle cx="72" cy="38" r="2.6" fill="#DD6A4E"/><rect x="78" y="37" width="14" height="2.6" rx="1.3" fill="#4A4640"/>
  <circle cx="72" cy="48" r="2.6" fill="#DD6A4E"/><rect x="78" y="47" width="10" height="2.6" rx="1.3" fill="#4A4640"/>
  <circle cx="72" cy="58" r="2.6" fill="#4A4640"/><rect x="78" y="57" width="12" height="2.6" rx="1.3" fill="#4A4640"/>
  <circle cx="72" cy="68" r="2.6" fill="#4A4640"/><circle cx="72" cy="78" r="2.6" fill="#4A4640"/>
  <rect class="il-pa" x="98" y="36" width="24" height="24" rx="3"/><rect class="il-pa" x="126" y="36" width="22" height="24" rx="3"/>
  <rect class="il-pa" x="98" y="64" width="24" height="24" rx="3"/><rect class="il-pa" x="126" y="64" width="22" height="24" rx="3"/>
  <g class="il-pa2"><rect x="102" y="40" width="8" height="8" rx="2"/><rect x="130" y="40" width="8" height="8" rx="2"/>
    <rect x="130" y="68" width="8" height="8" rx="2"/>
    <rect x="102" y="52" width="16" height="2.6" rx="1.3"/><rect x="130" y="52" width="14" height="2.6" rx="1.3"/>
    <rect x="102" y="80" width="16" height="2.6" rx="1.3"/><rect x="130" y="80" width="14" height="2.6" rx="1.3"/></g>
  <rect class="il-c" x="102" y="68" width="8" height="8" rx="2"/>
  <path class="il-n2" d="M96 98h28l-6 14H102Z"/>
  <g transform="rotate(-4 70 116)"><rect class="il-kr3" x="40" y="100" width="60" height="26" rx="3"/>
    <rect class="il-pa" x="40" y="98" width="60" height="4"/>
    <g fill="none" stroke="#8A6B44" stroke-width="1.5" opacity=".6"><circle cx="66" cy="112" r="5"/>
      <rect x="54" y="106" width="7" height="7" rx="2"/><rect x="74" y="106" width="7" height="7" rx="2"/></g>
    <rect class="il-n" x="44" y="122" width="46" height="5" rx="2.5"/></g>
  <g transform="rotate(3 130 118)"><rect class="il-pa" x="104" y="104" width="52" height="30" rx="3"/>
    <g class="il-pa2"><rect x="110" y="112" width="30" height="2.6" rx="1.3"/><rect x="110" y="119" width="30" height="2.6" rx="1.3"/></g>
    <path class="il-c" d="m146 110 1.6 3.4 3.6.4-2.8 2.4.9 3.6-3.3-2-3.3 2 .9-3.6-2.8-2.4 3.6-.4Z"/></g>
  <rect class="il-bl" x="160" y="96" width="34" height="16" rx="2"/><rect class="il-n" x="158" y="110" width="38" height="16" rx="2"/>
  <rect class="il-c" x="164" y="92" width="6" height="10" rx="1.5"/><rect class="il-c" x="176" y="106" width="6" height="10" rx="1.5"/>
  <path class="il-pa" d="M8 104h30v26a4 4 0 0 1-4 4H12a4 4 0 0 1-4-4Z"/>
  <path fill="none" stroke="#CFC2A6" stroke-width="4" d="M38 110h6a6 6 0 0 1 0 12h-6"/>
  <ellipse class="il-n" cx="23" cy="106" rx="15" ry="4"/>
  <rect class="il-bl" x="34" y="72" width="26" height="24" rx="5"/>
  <path class="il-s" d="M47 72c0-13 6-20 15-20 0 13-6 20-15 20Z"/>
  <path class="il-sc" d="M44 72c-10 0-16-6-16-16 10 0 16 6 16 16Z"/>
  <path class="il-s" d="M48 70c2-11 9-16 18-14-4 10-10 15-18 14Z"/></symbol>

<symbol id="ill-heros-aide" viewBox="0 0 200 160">
  <ellipse class="il-o" cx="100" cy="140" rx="90" ry="10"/>
  <ellipse fill="#F0D9A8" opacity=".16" cx="72" cy="86" rx="76" ry="52"/>
  <ellipse class="il-n" cx="26" cy="126" rx="20" ry="6"/><rect class="il-n" x="22" y="70" width="5" height="54" rx="2.5"/>
  <rect class="il-n" x="24" y="58" width="30" height="5" rx="2.5" transform="rotate(28 39 60)"/>
  <path class="il-n" d="M46 40h34l10 26H36Z" transform="rotate(6 63 53)"/>
  <ellipse fill="#E8C88A" cx="66" cy="66" rx="24" ry="6"/><circle fill="#FFF3D4" cx="66" cy="64" r="9"/>
  <rect class="il-kr3" x="42" y="72" width="56" height="12" rx="2"/><rect class="il-pa" x="44" y="70" width="52" height="3"/>
  <rect class="il-n" x="40" y="84" width="60" height="12" rx="2"/><rect class="il-pa2" x="42" y="82" width="56" height="3"/>
  <rect class="il-bl" x="44" y="96" width="56" height="11" rx="2"/><rect class="il-c" x="50" y="76" width="5" height="10" rx="1.5"/>
  <g transform="rotate(-2 100 122)">
    <path class="il-n" d="M56 108h88v22a3 3 0 0 1-3 3H59a3 3 0 0 1-3-3Z"/>
    <path class="il-pa" d="M60 106h40v26H60Zm40 0h40v26h-40Z"/>
    <path class="il-pa2" d="M99 106h2v26h-2Z"/>
    <g fill="none" stroke="#B5A588" stroke-width="1.6"><circle cx="80" cy="116" r="4.4"/><circle cx="68" cy="112" r="3"/>
      <circle cx="90" cy="112" r="3"/><rect x="66" y="120" width="6" height="6" rx="1.4"/><rect x="86" y="120" width="6" height="6" rx="1.4"/>
      <path d="m71 113 5 2m10-2-5 2m-1 6-4 3m8-3 4 3"/></g>
    <circle class="il-c" cx="80" cy="116" r="3"/>
    <g class="il-pa2"><rect x="106" y="112" width="26" height="2.6" rx="1.3"/><rect x="106" y="118" width="26" height="2.6" rx="1.3"/>
      <rect x="106" y="124" width="18" height="2.6" rx="1.3"/></g>
    <g class="il-c"><circle cx="102" cy="113" r="2"/><circle cx="102" cy="119" r="2"/><circle cx="102" cy="125" r="2"/></g>
    <rect class="il-c" x="94" y="132" width="6" height="10" rx="1.5"/></g>
  <rect class="il-n" x="60" y="136" width="42" height="5" rx="2.5" transform="rotate(-2 81 138)"/>
  <rect class="il-n" x="150" y="56" width="46" height="46" rx="6"/><rect class="il-n2" x="155" y="61" width="36" height="36" rx="4"/>
  <circle class="il-c2" cx="176" cy="79" r="9"/>
  <path fill="#E6DCC6" opacity=".9" d="M176 73c2.4 1.2 4 1.4 5 1.4 0 5-1.6 7.4-5 9-3.4-1.6-5-4-5-9 1 0 2.6-.2 5-1.4Z"/>
  <rect class="il-g" x="160" y="74" width="7" height="11" rx="3.5"/>
  <path class="il-pa" d="M156 108h30v22a4 4 0 0 1-4 4h-22a4 4 0 0 1-4-4Z"/>
  <path fill="none" stroke="#CFC2A6" stroke-width="4" d="M186 114h5a6 6 0 0 1 0 12h-5"/>
  <ellipse class="il-n" cx="171" cy="110" rx="15" ry="4"/>
  <g transform="rotate(4 130 132)"><rect class="il-bl" x="108" y="124" width="46" height="14" rx="2"/>
    <rect class="il-pa" x="110" y="120" width="44" height="6"/><rect class="il-pa2" x="112" y="126" width="40" height="4"/>
    <circle cx="140" cy="124" r="5" fill="none" stroke="#C4553F" stroke-width="2"/></g>
  <rect class="il-bl" x="112" y="76" width="24" height="22" rx="5"/>
  <path class="il-s" d="M124 76c0-13 6-20 15-20 0 13-6 20-15 20Z"/>
  <path class="il-sc" d="M121 76c-10 0-16-6-16-16 10 0 16 6 16 16Z"/>
  <path class="il-s" d="M125 74c2-11 9-16 18-14-4 10-10 15-18 14Z"/></symbol>
</defs>`}</svg>`;
