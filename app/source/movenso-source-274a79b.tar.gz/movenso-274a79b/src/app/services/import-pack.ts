/**
 * Service IMPORT DE PACK (S3.A1, tranche T1 — extrait de racine.ts, code
 * déménagé tel quel) : proposition, confirmation transactionnelle (promotion
 * des médias + rollback D-166), restauration complète/légère, annulations.
 * Fonctions recevant `app` — l'état d'attente (importEnAttente,
 * restaurationEnAttente, rapportApresImport) reste des propriétés réactives
 * de la racine ; le drapeau d'annulation de LECTURE vit ici (module).
 */

import { lireMovpackFlux, type ContenuMovpackFlux, type MediaStreame } from "../../echange/movpack.ts";
import { estZip, type ManifesteMovpack } from "../../echange/movpack-contrat.ts";
import type { ImageDetachee } from "../../domaine/migrations.ts";
import { importerDansBibliotheque, arbitrerConflitLiaison } from "../../domaine/rapprochement.ts";
import type { Bibliotheque, ConflitLiaison } from "../../domaine/modele.ts";
import { migrerBibliotheque } from "../../domaine/migrations.ts";
import { validerBibliotheque } from "../../domaine/validation.ts";
import { espaceSuffisant, octetsMedias, estimationEspace } from "./espace.ts";
import type { MovensoApp } from "../racine.ts";

/** Lecture d'archive annulée par l'utilisateur (S2.4) — état de module. */
let lectureAnnulee = false;

export function choisirPackAImporter(app: MovensoApp): void {
  if (!app.garde("modification", "Saisis le PIN pour importer un pack.", () => void app.choisirPackAImporter())) return;
  const champ = document.createElement("input");
  champ.type = "file";
  champ.accept = ".movpack";
  champ.onchange = () => {
    const fichier = champ.files?.[0];
    if (fichier) void app.importerPack(fichier);
  };
  champ.click();
}

export async function importerPack(app: MovensoApp, fichier: File): Promise<void> {
  const b = app.bibliotheque;
  if (!b) return;
  // Un import précédent non confirmé a pu laisser des médias en staging : on
  // repart propre (D-114) — jamais deux conteneurs mêlés dans la zone d'import.
  // On abandonne aussi toute proposition en attente : ses médias stagés vont
  // être effacés, la garder pointerait vers des fichiers disparus (une
  // confirmation ultérieure persisterait une bibliothèque aux vidéos manquantes).
  app.importEnAttente = null;
  app.restaurationEnAttente = null;
  await app.stockage.nettoyerImport();
  try {
    // Détection par CONTENU (contrat §6) : archive .movpack ou JSON nu — sur
    // les 4 premiers octets seuls, jamais en chargeant tout le fichier.
    const tete = new Uint8Array(await fichier.slice(0, 4).arrayBuffer());
    let pack: Bibliotheque;
    let packId: string;
    let manifeste: ManifesteMovpack | undefined;
    let medias: MediaStreame[] = [];
    let images: ImageDetachee[] = [];
    let avertissements: string[] = [];
    if (estZip(tete)) {
      // S1.9 (D-163) : borne basse FIABLE avant d'écrire quoi que ce soit en
      // staging — le contenu décompressé pèsera AU MOINS la taille de
      // l'archive (les médias dominent et ne se recompressent pas). Refus
      // propre avant de commencer une opération vouée à l'échec.
      if (!espaceSuffisant(app, fichier.size, await app.stockage.estimerEspace())) return;
      // Lecture EN FLUX (D-114) : médias écrits par blocs dans staging/import,
      // vérifiés, jamais chargés en entier — l'archive ne réside pas dans le tas.
      // L'espace fin se contrôle À L'ÉCRITURE : un staging qui déborde échoue proprement
      // (staging nettoyé, rien de définitif écrit), plutôt que sur une estimation.
      lectureAnnulee = false;
      app.annulationOccupe = { libelle: "Annuler", executer: () => { lectureAnnulee = true; } };
      let contenu: ContenuMovpackFlux;
      try {
        contenu = await app.occuperPendant("Lecture du pack…", () =>
          lireMovpackFlux(fichier.stream(), app.stockage.puitsImport(), { estAnnule: () => lectureAnnulee }),
        );
      } finally {
        app.annulationOccupe = null;
      }
      if (contenu.manifeste.portee === "complet") {
        await proposerRestauration(app, contenu);
        return;
      }
      medias = contenu.medias; // promus seulement à la confirmation
      images = contenu.images; // écrites seulement à la confirmation
      pack = contenu.bibliotheque;
      packId = contenu.manifeste.id;
      manifeste = contenu.manifeste;
      avertissements = contenu.avertissements;
    } else {
      // JSON nu (historique, sans média) : petit par construction — lecture directe.
      const octets = new Uint8Array(await fichier.arrayBuffer());
      pack = migrerBibliotheque(JSON.parse(new TextDecoder().decode(octets)));
      validerBibliotheque(pack);
      packId = pack.contributions[0]?.origine?.pack ?? fichier.name.replace(/\.(json|movpack)$/i, "");
      // §26 : un JSON nu est un format HISTORIQUE — le dire honnêtement,
      // ne jamais le présenter comme un .movpack (ni manifeste ni intégrité).
      avertissements = ["Fichier JSON historique : ni manifeste ni intégrité de conteneur — analysé et validé, mais non vérifié par empreinte."];
    }
    // Ce pack est-il DÉJÀ installé ? (au moins un élément porte son origine) —
    // un réimport MET À JOUR le contenu du pack à cette version (D-118).
    const dejaInstalle =
      b.techniques.some((t) => t.origine?.pack === packId) || b.contributions.some((c) => c.origine?.pack === packId);
    // Fusion PROPOSÉE, jamais subie (D-023) : le résultat est calculé à
    // blanc (fonction pure), présenté, et n'est écrit qu'à la confirmation.
    const resultat = importerDansBibliotheque(b, pack, {
      packId,
      ...(manifeste?.versionEditoriale !== undefined ? { versionEditoriale: manifeste.versionEditoriale } : {}),
    });
    app.importEnAttente = {
      ...resultat,
      packId,
      medias,
      images,
      dejaInstalle,
      ...(manifeste ? { manifeste } : {}),
      volume: fichier.size,
      contenus: { techniques: pack.techniques.length, contributions: pack.contributions.length },
      avertissements,
    };
    app.requestUpdate();
  } catch (e) {
    await app.stockage.nettoyerImport(); // aucun média orphelin après un échec
    if (e instanceof Error && e.message === "Import annulé") {
      app.afficherToast("Import annulé — rien n'a été écrit");
      return;
    }
    app.consignerEchec("MOV-E02", e);
    app.afficherToast(`Import impossible : ${e instanceof Error ? e.message : "fichier illisible"}`, "alerte");
  }
}

export async function confirmerImport(app: MovensoApp): Promise<void> {
  const attente = app.importEnAttente;
  if (!attente) return;
  // §10 : rien de définitif si l'espace fiable manque — la proposition reste,
  // les médias stagés seront jetés à l'annulation.
  if (!espaceSuffisant(app, octetsMedias(attente.medias), await estimationEspace(app))) return;
  await app.stockage.snapshot(`avant-import-${attente.packId}`);
  // Les médias sont déjà écrits et VÉRIFIÉS en staging (D-114) : on les promeut
  // (déplacement idempotent), on persiste l'état, puis on vide la zone d'import.
  // Un pépin de promotion/persistance ne doit jamais laisser un demi-état ni
  // une erreur non gérée : on le dit et on garde la proposition (retry/annuler).
  try {
    await app.occuperPendant("Installation du pack…", async () => {
      // S1.5 (D-166, option B) : la promotion dit ce qu'elle a RÉELLEMENT
      // déplacé — si la persistance échoue, on le re-déplace : jamais un
      // fichier promu sans bibliothèque qui le référence (pas d'orphelin).
      const promus = await app.stockage.promouvoirImportMedias(attente.medias.map((m) => m.nomPhysique));
      // Les images AVANT l'état qui les déclare (D-269) : l'inventaire ne
      // devient la vérité qu'une fois les fichiers là. L'écriture est
      // idempotente (nom = empreinte), donc un retour en arrière n'a rien à
      // défaire — au pire des octets en trop, que le balayage retirera.
      await app.stockage.poserImagesRecues(attente.images);
      try {
        await app.persister(attente.bibliotheque);
      } catch (e) {
        await app.stockage.annulerPromotionMedias(promus);
        throw e;
      }
    });
  } catch (e) {
    app.consignerEchec("MOV-E03", e);
    app.afficherToast(`Import impossible : ${e instanceof Error ? e.message : "écriture refusée"}`, "alerte");
    return;
  }
  await app.stockage.nettoyerImport();
  const r = attente.rapport;
  app.importEnAttente = null;
  // Rapport compact APRÈS import (§18) : ce qui a changé, avec actions.
  app.rapportApresImport = {
    discipline: r.discipline,
    disciplineId: attente.bibliotheque.disciplines.find((d) => d.nom === r.discipline)?.id ?? null,
    rejointes: r.rejointes.length,
    creees: r.creees.length,
    suggestions: r.suggestions,
    videos: attente.medias.length,
    conflitsLiaisons: r.conflitsLiaisons,
    conflitsContributions: r.conflitsContributions,
    retraitsProposes: r.retraitsProposes,
    fichesModifiees: r.fichesModifiees,
    compositionsModifiees: r.compositionsModifiees,
    imagesAjoutees: r.imagesAjoutees,
    // Le compteur était calculé et montré AVANT l'import, puis perdu ici :
    // une édition qui n'apporte que des liens (yoga, +27 en D-306) affichait
    // « 27 lien(s) ajouté(s) » à l'aperçu, puis un rapport vide (verdict checker).
    relationsAjoutees: r.relationsAjoutees,
  };
  app.requestUpdate();
}

export function fermerRapportImport(app: MovensoApp): void {
  app.rapportApresImport = null;
  app.requestUpdate();
}

export async function annulerImport(app: MovensoApp): Promise<void> {
  app.importEnAttente = null;
  await app.stockage.nettoyerImport(); // médias stagés jetés (D-114)
  app.requestUpdate();
  app.afficherToast("Import annulé — rien n'a été écrit");
}

async function proposerRestauration(app: MovensoApp, contenu: ContenuMovpackFlux): Promise<void> {
  const b = app.bibliotheque!;
  const vierge =
    b.disciplines.length === 0 && b.techniques.length === 0 && b.contributions.length === 0 && b.compositions.length === 0;
  if (!vierge) {
    await app.stockage.nettoyerImport(); // médias stagés inutiles : jetés (D-114)
    app.afficherToast(
      "Cet export complet se restaure sur une installation vierge — ici, importe plutôt un pack de discipline (Plus › Créer ou exporter un pack)",
    );
    return;
  }
  app.restaurationEnAttente = contenu;
  app.requestUpdate();
}

export async function confirmerRestauration(app: MovensoApp): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour restaurer cette sauvegarde.", () => void app.confirmerRestauration())) return;
  const contenu = app.restaurationEnAttente;
  if (!contenu) return;
  // §10 : jamais de bibliothèque partiellement restaurée par manque d'espace —
  // refus AVANT toute mutation de la bibliothèque LIVE (la proposition reste,
  // les médias stagés seront jetés à l'annulation). La promotion elle-même est
  // un déplacement quasi gratuit.
  if (!espaceSuffisant(app, octetsMedias(contenu.medias), await estimationEspace(app))) return;
  try {
    await app.occuperPendant("Restauration en cours…", async () => {
      // S1.5 (D-166, option B) : même transaction qu'à l'import — un échec
      // de persistance re-déplace les médias promus, la proposition reste.
      const promus = await app.stockage.promouvoirImportMedias(contenu.medias.map((m) => m.nomPhysique));
      await app.stockage.poserImagesRecues(contenu.images); // octets avant l'état qui les déclare (D-269)
      try {
        await app.persister(contenu.bibliotheque);
      } catch (e) {
        await app.stockage.annulerPromotionMedias(promus);
        throw e;
      }
    });
  } catch (e) {
    app.consignerEchec("MOV-E04", e);
    app.afficherToast(`Restauration impossible : ${e instanceof Error ? e.message : "écriture refusée"}`, "alerte");
    return;
  }
  await app.stockage.nettoyerImport();
  app.restaurationEnAttente = null;
  // §21 / D-065 : le SAVOIR et les MÉDIAS reviennent à l'identique ; les
  // réglages d'appareil (thème, démarrage, protections/PIN) ne voyagent
  // jamais et se reconfigurent — dit, jamais une promesse implicite.
  app.afficherToast(
    `Bibliothèque restaurée ✓ ${contenu.bibliotheque.techniques.length} techniques, ${contenu.medias.length} vidéo${contenu.medias.length > 1 ? "s" : ""} — réglages d'appareil (thème, démarrage, protections) à reconfigurer`,
  );
}

export async function annulerRestauration(app: MovensoApp): Promise<void> {
  app.restaurationEnAttente = null;
  await app.stockage.nettoyerImport(); // médias stagés jetés (D-114)
  app.requestUpdate();
  app.afficherToast("Restauration annulée — rien n'a été écrit");
}

/** Accepte EN BLOC les retraits de liens proposés par un pack (D-243).
 *
 *  Arbitrer 255 arêtes une par une n'a aucun sens — l'action groupée est donc
 *  indispensable, et c'est elle, pas les retraits à l'unité, qui porte
 *  l'avertissement : un lien tracé à la main entre deux techniques du pack est
 *  INDISCERNABLE d'un lien du pack, il peut donc se trouver dans le lot. D'où
 *  la confirmation nommée (C2) qui dit le nombre exact et ce risque, et le
 *  point de restauration pris AVANT, jamais après. */
export function retirerLiensProposes(app: MovensoApp, packId: string): void {
  const b = app.bibliotheque;
  if (!b) return;
  const lot = (b.conflitsLiaisons ?? []).filter((c) => c.sens === "retrait" && c.pack === packId);
  if (lot.length === 0) return;
  const s = lot.length > 1 ? "s" : "";
  app.demanderConfirmation({
    titre: `Retirer ${lot.length} lien${s} ?`,
    corps: "Ce pack ne les déclare plus. Un lien que tu as tracé toi-même entre deux de ses techniques peut se trouver dans le lot — rien ne les distingue. Un point de restauration est pris avant.",
    bouton: "Retirer",
    action: () => void appliquerRetraits(app, lot),
  });
}

async function appliquerRetraits(app: MovensoApp, lot: ConflitLiaison[]): Promise<void> {
  const b = app.bibliotheque;
  if (!b) return;
  await app.stockage.snapshot(`avant-retrait-liens-${lot[0]!.pack}`);
  for (const c of lot) arbitrerConflitLiaison(b, c, "retirer");
  await app.persister(b);
  const s = lot.length > 1 ? "s" : "";
  app.afficherToast(`${lot.length} lien${s} retiré${s} — point de restauration conservé`);
}
