/**
 * VIGNETTES DE L'AIDE SERVIES PAR LE SITE (D-363) — zéro octet dans l'app.
 *
 * Même mécanique que les illustrations des starter packs
 * (`packs-officiels.ts`), et c'est délibéré : elle est déjà éprouvée, la CSP
 * la couvre déjà (`img-src blob:`, `connect-src` vers le site), et une seconde
 * façon de faire la même chose aurait divergé.
 *
 * POURQUOI le site plutôt que l'application. Le budget `dist/` plafonne à
 * 900 000 octets ; les treize illustrations de l'aide, au poids constaté des
 * illustrations existantes (~11 Ko à 192 px), coûteraient ~143 Ko — elles ne
 * tiennent pas. Servies par le site, elles coûtent **zéro octet** : c'est ce
 * que fait l'écran des starter packs depuis D-335, où 26 fichiers et 389 Ko
 * vivent sur le site sans peser sur l'app.
 *
 * CE QU'ON ACCEPTE EN ÉCHANGE, arbitrage du porteur du 2026-08-17 : hors
 * ligne, la vignette manque. Le web est presque toujours connecté, et le
 * dégradé est acceptable ; **l'APK est logé à la même enseigne**, contrairement
 * à ce qu'on pourrait croire — `urlSite` part en absolu vers le site en natif.
 * Rien n'est perdu de l'INFORMATION : les illustrations sont décoratives
 * (`aria-hidden`), et un calque dessiné prend le relais.
 *
 * L'échec est SILENCIEUX et voulu : une vignette absente n'est pas une panne.
 */

import { urlSite } from "./site-public.ts";
import type { MovensoApp } from "../racine.ts";

/** clé → URL `blob:`. `""` = requête en cours ou échouée : dans les deux cas
 *  on ne redemande pas, et l'appelant retombe sur son calque. */
const chargees = new Map<string, string>();

/** Chemin d'une vignette sur le site. Un seul lieu : le contrat de nommage de
 *  la fiche `lots/aide-apropos-refonte.md` §7bis dérive de cette ligne. */
const cheminDe = (cle: string): string => `img/aide/${cle}.webp`;

/** L'URL locale d'une vignette déjà chargée, ou `undefined`. */
export function urlIllustrationAide(cle: string): string | undefined {
  return chargees.get(cle) || undefined;
}

/** Demande les vignettes manquantes et redessine au fil de l'eau.
 *
 *  Appelé depuis le RENDU des écrans qui s'en servent, et c'est assumé : la
 *  fonction est idempotente (la Map réserve la clé avant la requête, donc une
 *  clé n'est jamais demandée deux fois), le rendu lui-même reste synchrone, et
 *  aucune donnée d'écran n'en dépend — sans elles, l'écran est complet, il est
 *  seulement moins joli. L'alternative aurait été d'accrocher le chargement à
 *  la navigation, dans `racine.ts`, qui est au cliquet. */
export function chargerIllustrationsAide(app: MovensoApp, cles: readonly string[]): void {
  const manquantes = cles.filter((c) => !chargees.has(c));
  if (manquantes.length === 0) return;
  for (const cle of manquantes) chargees.set(cle, ""); // réservé avant la requête
  void (async () => {
    for (const cle of manquantes) {
      try {
        const rep = await fetch(urlSite(cheminDe(cle)), { cache: "force-cache" });
        if (!rep.ok) throw new Error(`HTTP ${rep.status}`);
        const blob = await rep.blob();
        // Une 404 servie en HTML par un hébergeur statique passerait `ok` :
        // on refuse ce qui ne se déclare pas image, sinon la vignette
        // afficherait une page d'erreur en guise d'illustration.
        if (!blob.type.startsWith("image/")) throw new Error(`type ${blob.type}`);
        chargees.set(cle, URL.createObjectURL(blob));
        app.requestUpdate();
      } catch { /* pas d'illustration, pas de drame */ }
    }
  })();
}
