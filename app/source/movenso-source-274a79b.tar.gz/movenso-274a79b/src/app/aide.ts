/**
 * ÉCRAN « AIDE » (D-362) — huit à neuf portes d'entrée, un sous-écran chacune.
 *
 * Refonte demandée par le porteur le 2026-08-17, validée sur maquette avant
 * toute ligne de code (D-279, `docs/prototypes/apropos-aide.html`). Ce qui
 * change, et pourquoi :
 *
 *   - la pile d'accordéons devient une LISTE qui ouvre des sous-écrans. Sur
 *     neuf rubriques, le repliable obligeait à défiler pour trouver, puis à
 *     défiler pour lire ;
 *   - les repères « PIN » quittent les titres. Ils faisaient croire que des
 *     zones entières sont verrouillées par nature, alors que c'est une
 *     protection facultative que l'utilisateur active. Une seule rubrique
 *     l'explique, et mieux ;
 *   - le mot « bêta » quitte l'aide : la rubrique n'apparaît toujours que si
 *     la capacité est activée, mais si tu l'as, elle marche — le vocabulaire
 *     interne n'a rien à faire ici.
 *
 * L'entrée « Aide » disparaît du menu Plus : on y arrive depuis À propos
 * (D-362). C'est la révision partielle de D-308 §3, qui avait scindé les deux
 * en deux entrées ; les deux PAGES restent distinctes.
 *
 * Le CONTENU vit dans `aide-contenu.ts`, pas ici : un seul tableau nourrit la
 * liste et les sous-écrans (D-253).
 */

import { html, nothing, type TemplateResult } from "lit";
import { rubriquesVisibles, rubriqueParCle, ouvrirSujet, sujetCourant } from "./aide-contenu.ts";
import { SPRITE_ILLUSTRATIONS, illustration, vignette, CLES_AIDE } from "./aide-illustrations.ts";
import { chargerIllustrationsAide } from "./services/illustrations-aide.ts";
import type { MovensoApp } from "./racine.ts";

const CHEVRON = html`<svg class="aide-chevron" width="19" height="19" viewBox="0 0 24 24" fill="none"
  stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>`;

/** La page d'aide : un héros, puis une porte par sujet. */
export function ecranAide(app: MovensoApp): TemplateResult {
  chargerIllustrationsAide(app, CLES_AIDE);
  return html`
    ${SPRITE_ILLUSTRATIONS}
    <div class="aide-page">
      <div class="aide-heros">
        ${illustration("heros-aide", "aide-heros-art", "0 0 200 160")}
        <h2>Besoin d’aide ?</h2>
        <p>Les repères essentiels pour bien démarrer, te servir de l’application et protéger tes données.</p>
      </div>

      ${rubriquesVisibles(app).map(
        (r) => html`
          <button class="aide-rubrique" @click=${() => ouvrirSujet(app, r.cle)}>
            ${vignette(r.illustration, "aide-vignette")}
            <span class="aide-rub-corps">
              <b>${r.titre(app)}</b>
              <span>${r.resume}</span>
            </span>
            ${CHEVRON}
          </button>
        `,
      )}
    </div>
  `;
}

/** Un sous-écran : une idée illustrée, trois réponses courtes, une alerte
 *  s'il en faut une. L'aide doit donner l'impression qu'on trouve en vingt
 *  secondes, pas qu'on ouvre le manuel du produit. */
export function ecranAideSujet(app: MovensoApp): TemplateResult {
  chargerIllustrationsAide(app, CLES_AIDE);
  const rubrique = sujetCourant() ? rubriqueParCle(sujetCourant()!) : undefined;
  // Filet : la section ne s'ouvre que par `ouvrirSujet`, mais un retour
  // arrière du navigateur peut la rejouer sans sujet. On ne montre pas un
  // écran vide — on renvoie la liste.
  if (!rubrique) return ecranAide(app);

  return html`
    ${SPRITE_ILLUSTRATIONS}
    <div class="aide-page">
      <div class="aide-idee">
        ${illustration(rubrique.illustration, "aide-idee-art")}
        <b>${rubrique.idee}</b>
        <p>${rubrique.sousIdee}</p>
      </div>

      ${rubrique.reponses(app).map(
        (r) => html`
          <div class="aide-reponse">
            <h3>${r.titre}</h3>
            <p>${r.corps}</p>
          </div>
        `,
      )}

      ${rubrique.alerte
        ? html`
            <div class="aide-alerte">
              <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                   stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M10.3 3.9 1.9 18.4A1.9 1.9 0 0 0 3.6 21.3h16.8a1.9 1.9 0 0 0 1.7-2.9L13.7 3.9a1.9 1.9 0 0 0-3.4 0Z"/>
                <path d="M12 9.5v4.5M12 17.5h.01"/>
              </svg>
              <p>${rubrique.alerte}</p>
            </div>
          `
        : nothing}
    </div>
  `;
}
