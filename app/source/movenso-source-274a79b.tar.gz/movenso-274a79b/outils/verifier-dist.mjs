// Vérification du contenu du build (S1.2, D-162) — le dossier dist/ publié
// ne doit contenir QUE l'app compilée : ni source, ni sourcemap, ni secret,
// ni donnée locale. Échoue (exit 1) à la moindre anomalie ; la CI et
// `npm run verifier` l'exécutent après chaque build.
import { readdir, readFile, stat } from "node:fs/promises";
import { join, extname, relative } from "node:path";

const RACINE = new URL("../dist", import.meta.url).pathname;

// Liste blanche : tout fichier hors de ces extensions est un intrus.
// `.webp` (D-332) : les illustrations de la première ouverture pèsent 68 Ko en
// WebP contre 129 Ko en PNG réduit à 128 px, pour un budget qui n'offrait que
// 109 Ko de marge. Format d'image comme les autres, il n'élargit aucune
// surface : seuls les fichiers TEXTE sont fouillés pour les secrets.
const EXTENSIONS_PERMISES = new Set([".html", ".js", ".css", ".svg", ".png", ".webp", ".ico", ".woff2"]);
// Interdits explicites, quel que soit le contexte.
const EXTENSIONS_INTERDITES = new Set([".map", ".ts", ".tsx", ".json", ".env", ".md", ".sh", ".zip", ".movpack"]);
// Motifs de secrets/chemins locaux dans les fichiers texte.
const MOTIFS_SUSPECTS = [
  { motif: /-----BEGIN [A-Z ]*PRIVATE KEY-----/, nom: "clé privée PEM" },
  { motif: /AKIA[0-9A-Z]{16}/, nom: "clé AWS" },
  { motif: /gh[pousr]_[A-Za-z0-9]{20,}/, nom: "jeton GitHub" },
  { motif: /\/home\/[a-z0-9_-]+\//i, nom: "chemin local absolu" },
  { motif: /node_modules\//, nom: "référence node_modules" },
];

async function lister(dossier) {
  const resultat = [];
  for (const entree of await readdir(dossier, { withFileTypes: true })) {
    const chemin = join(dossier, entree.name);
    if (entree.isDirectory()) resultat.push(...(await lister(chemin)));
    else resultat.push(chemin);
  }
  return resultat;
}

const erreurs = [];
let fichiers;
try {
  fichiers = await lister(RACINE);
} catch {
  console.error("verifier-dist : dist/ absent — lancer `npm run build` d'abord.");
  process.exit(1);
}

if (!fichiers.some((f) => relative(RACINE, f) === "index.html"))
  erreurs.push("index.html absent de dist/");

for (const chemin of fichiers) {
  const rel = relative(RACINE, chemin);
  const ext = extname(rel).toLowerCase();
  const nom = rel.split("/").pop();

  // 1) Emplacement : uniquement la racine et assets/ (pas d'arborescence surprise).
  const dossier = rel.includes("/") ? rel.slice(0, rel.lastIndexOf("/")) : "";
  // `img/` (D-332) : les illustrations servies depuis `public/img/`. Un
  // dossier NOMMÉ de plus, pas une arborescence libre — la règle continue de
  // refuser tout autre emplacement.
  if (dossier !== "" && dossier !== "assets" && dossier !== "img") erreurs.push(`emplacement inattendu : ${rel}`);

  // 2) Extension : liste blanche stricte + interdits nommés.
  if (nom.startsWith(".")) erreurs.push(`fichier caché : ${rel}`);
  else if (EXTENSIONS_INTERDITES.has(ext)) erreurs.push(`extension interdite (${ext}) : ${rel}`);
  else if (!EXTENSIONS_PERMISES.has(ext)) erreurs.push(`extension hors liste blanche (${ext}) : ${rel}`);

  // 3) Contenu des fichiers texte : aucun secret, aucun chemin local.
  if ([".html", ".js", ".css", ".svg"].includes(ext)) {
    const texte = await readFile(chemin, "utf8");
    for (const { motif, nom: quoi } of MOTIFS_SUSPECTS)
      if (motif.test(texte)) erreurs.push(`${quoi} détecté dans ${rel}`);
    if (ext === ".html" && /src=["'][^"']*\/src\//.test(texte))
      erreurs.push(`index.html référence les sources (src/) : ${rel}`);
  }

  // 4) Aucun fichier vide (build tronqué).
  if ((await stat(chemin)).size === 0) erreurs.push(`fichier vide : ${rel}`);
}

// 5) BUDGET du bundle (S3.A10, D-198) : le poids total de dist/ reste sous un
// plafond calibré. Empêche l'inflation silencieuse (dépendance lourde, asset
// oublié).
//
// CALIBRAGES SUCCESSIFS — le nombre n'a de sens qu'avec ce qui l'a produit :
//   D-198 : 900 000 o  ← ~685 Ko mesurés + ~30 % de marge
//   D-365 : 1 100 000 o ← 886 Ko mesurés + les 13 illustrations de l'aide
//           (~143 Ko au poids constaté des illustrations existantes, 192 px)
//           = ~1 029 Ko, plus ~70 Ko de marge. Marge VOLONTAIREMENT courte :
//           un plafond large ne garde plus rien.
//
// IL EST FAIT POUR REDESCENDRE. Deux marques SVG pèsent 220 Ko pour un logo
// affiché à 40 px (RESTE.md) ; le jour où elles sont dégraissées, ce plafond
// se resserre — un cliquet qui ne redescend jamais n'est qu'une dérive lente.
//
// QUI PEUT LE BOUGER : le porteur, et lui seul. Ce n'est pas une limite
// technique — Play accepte 150 Mo — mais un ARBITRAGE (D-198 §1). Le relever
// se fait ICI, en une ligne, avec sa décision au journal.
//
// POURQUOI IL PRÉVIENT AVANT DE REFUSER (D-364). Un seuil qui ne parle qu'au
// moment du dépassement laisse une session le contourner par conception : sur
// l'écran d'aide, ce plafond a orienté trois décisions de suite — pictogrammes
// au trait, calques dessinés, puis chargement réseau — sans que la question
// « veux-tu le relever ? » soit posée une seule fois. La garde ne pouvait pas
// le savoir : elle n'était jamais franchie. Elle dit donc désormais où l'on en
// est AVANT d'avoir mal, et rappelle que le choix appartient au porteur.
const BUDGET_DIST_OCTETS = 1_100_000;
/** Au-delà de cette part du budget, la garde le DIT — sans refuser. */
const ALERTE_PART = 0.9;
let totalOctets = 0;
for (const chemin of fichiers) totalOctets += (await stat(chemin)).size;
if (totalOctets > BUDGET_DIST_OCTETS)
  erreurs.push(`poids total de dist/ : ${totalOctets} octets > budget ${BUDGET_DIST_OCTETS} (S3.A10 — recalibrer par décision ou dégraisser)`);

if (erreurs.length) {
  console.error(`verifier-dist : ${erreurs.length} anomalie(s) dans dist/ :`);
  for (const e of erreurs) console.error("  - " + e);
  process.exit(1);
}
const part = totalOctets / BUDGET_DIST_OCTETS;
console.log(`verifier-dist : dist/ propre (${fichiers.length} fichiers, extensions et contenus contrôlés, ${Math.round(totalOctets / 1000)} Ko ≤ budget ${BUDGET_DIST_OCTETS / 1000} Ko).`);
if (part >= ALERTE_PART) {
  // Les trois premiers postes, pour que la marge ne soit pas une abstraction :
  // savoir QUE c'est serré n'aide pas, savoir OÙ ça passe si.
  const gros = (await Promise.all(fichiers.map(async (f) => [relative(RACINE, f), (await stat(f)).size])))
    .sort((a, b) => b[1] - a[1]).slice(0, 3)
    .map(([f, o]) => `${f} ${Math.round(o / 1000)} Ko`).join(", ");
  console.log(
    `  ⚠ ${Math.round(part * 100)} % du budget. Ce plafond est un ARBITRAGE du porteur (D-198 §1), pas une
` +
    `    limite technique : il se relève ICI (\`BUDGET_DIST_OCTETS\`) par décision. Ne pas concevoir
` +
    `    autour de lui en silence — la question se pose (D-364). Postes les plus lourds : ${gros}.`,
  );
}
