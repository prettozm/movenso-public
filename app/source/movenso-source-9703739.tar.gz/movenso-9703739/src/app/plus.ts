/**
 * « Plus » (D-071) — remplace l'Atelier : un MENU simple de réglages et de
 * gestion, sans accordéons ni tableau de bord. Chaque ligne (icône + titre +
 * état court + chevron) ouvre un sous-écran spécialisé. Aucun vocabulaire
 * technique interne ; les explications vivent dans les sous-écrans, jamais ici.
 */

import { html, nothing, type TemplateResult } from "lit";
import type { MovensoApp, SectionPlus } from "./racine.ts";
import { ecranPacksOfficiels } from "./packs-officiels-vue.ts";
import { sourceDe } from "../domaine/modele.ts";
import { VERSION } from "./version.ts";
import {
  ecranApparence,
  ecranAide,
  ecranAvance,
  ecranApropos,
  ecranATraiter,
  ecranCorbeille,
  ecranDiagnostic,
  ecranDoublons,
  ecranMedias,
  ecranPacksDisciplines,
  ecranPublier,
  ecranRelations,
  ecranSauvegardes,
  ecranStockage,
  ecranSecurite,
  ecranTechniques,
} from "./atelier.ts";

const TITRES: Record<SectionPlus, string> = {
  packs: "Disciplines et classement",
  techniques: "Gestion des techniques",
  atraiter: "À traiter",
  doublons: "Doublons potentiels",
  medias: "Médias",
  relations: "Relations entre techniques",
  corbeille: "Corbeille",
  "packs-officiels": "Starter packs",
  publier: "Créer ou exporter un pack",
  sauvegardes: "Sauvegardes",
  stockage: "Stockage",
  securite: "Sécurité",
  apparence: "Apparence",
  avance: "Réglages avancés",
  diagnostic: "Diagnostic et maintenance",
  apropos: "À propos",
  aide: "Aide",
};

function contenuSection(app: MovensoApp, section: SectionPlus): TemplateResult {
  switch (section) {
    case "packs": return ecranPacksDisciplines(app);
    case "stockage": return ecranStockage(app);
    case "aide": return ecranAide(app);
    case "techniques": return ecranTechniques(app);
    case "atraiter": return ecranATraiter(app);
    case "doublons": return ecranDoublons(app);
    case "medias": return ecranMedias(app);
    case "relations": return ecranRelations(app);
    case "corbeille": return ecranCorbeille(app);
    case "packs-officiels":
      // D-333 : les éditions POSÉES sur cet appareil (D-307) décident de
      // « Installé » et de « Mise à jour disponible ».
      return ecranPacksOfficiels(app.catalogueOfficiel, {
        installer: (e) => void app.installerPackOfficiel(e),
        recharger: () => app.rechargerCataloguePacks(),
      }, app.bibliotheque?.editionsPacks ?? []);
    case "publier": return ecranPublier(app);
    case "sauvegardes": return ecranSauvegardes(app);
    case "securite": return ecranSecurite(app);
    case "apparence": return ecranApparence(app);
    case "avance": return ecranAvance(app);
    case "diagnostic": return ecranDiagnostic(app);
    case "apropos": return ecranApropos(app);
  }
}

/** Sous-écran d'une entrée de « Plus » : titre simple, retour, ses seules
 *  fonctions. */
export function gabaritPlusSection(app: MovensoApp, section: SectionPlus): TemplateResult {
  return html`
    <div class="ecran">
      <div class="barre">
        <button class="bouton-icone" aria-label="Retour" @click=${() => app.retour()}>
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M15 5l-7 7 7 7"/></svg>
        </button>
        <span class="contexte">${TITRES[section]}</span>
      </div>
      ${contenuSection(app, section)}
    </div>
  `;
}

/* ---------- le menu ---------- */

interface EntreeMenu {
  section?: SectionPlus;
  action?: (app: MovensoApp) => void;
  icone: string;
  fond: string;
  titre: string;
  etat?: string;
}

function etatsMenu(app: MovensoApp): {
  bibliotheque: EntreeMenu[];
  echange: EntreeMenu[];
  preferences: EntreeMenu[];
} {
  const b = app.bibliotheque!;
  const sources = new Set<string>();
  for (const t of b.techniques) if (sourceDe(t) !== "local") sources.add(sourceDe(t));
  for (const c of b.contributions) if (sourceDe(c) !== "local") sources.add(sourceDe(c));
  const nbPacks = sources.size;
  const nbDisc = b.disciplines.length;
  const nbTech = b.techniques.length;
  const nbCat = b.disciplines.reduce((n, d) => n + d.familles.length, 0);
  const nbNiv = b.disciplines.reduce((n, d) => n + d.niveaux.length, 0);

  const nbDoublons = app.doublonsPotentiels().length;

  const nbFichiers = app.taillesVideos.size;
  // « À traiter » (D-107) : le total actionnable, agrégé en un seul endroit.
  const avecMedia = new Set(b.contributions.filter((c) => c.techniqueId && c.medias.length).map((c) => c.techniqueId));
  const aRattacher = b.contributions.filter((c) => c.techniqueId === null).length;
  const sansVideo = b.techniques.filter((t) => !avecMedia.has(t.id)).length;
  const sansClasse = b.techniques.filter((t) => !t.familleId && t.niveauxIds.length === 0).length;
  const aTraiter = aRattacher + sansVideo + sansClasse + app.mediasManquants.length + app.videosOrphelines.length + nbDoublons + (b.conflitsContributions ?? []).length;

  const nbRel = b.techniques.reduce((n, t) => n + t.relations.length, 0);
  const nbCorbeille = (b.corbeille ?? []).length;

  const dernier = app.sauvegardes[0];
  const dateSauv = dernier ? (dernier.replace(".json", "").split("__")[0] ?? "").slice(0, 10) : "";

  const info = app.infoEspace;
  const espaceUtilise = info
    ? info.usage >= 1_000_000 ? `${(info.usage / 1_000_000).toFixed(1)} Mo utilisés` : `${Math.max(1, Math.round(info.usage / 1000))} Ko utilisés`
    : "";
  const p = app.preferences.protections;
  const secu = p && (p.modifications || p.suppressions) ? "PIN actif" : "Modification libre";
  const theme = app.preferences.theme ?? "auto";
  const themeLisible = theme === "auto" ? "Auto (système)" : theme === "clair" ? "Jour" : "Nuit";

  // Mode avancé (D-084) : les outils de curation/maintenance ne s'affichent que
  // s'il est activé — surface du pratiquant sobre par défaut.
  const av = app.preferences.modeAvance ?? false;
  const actives = [
    av ? "mode avancé" : null,
    (app.preferences.vueRelationBeta ?? false) ? "Relations" : null,
    (app.preferences.compositionsBeta ?? false) ? "Compositions" : null,
  ].filter(Boolean);
  const etatAvance = actives.length ? `Actifs : ${actives.join(" · ")}` : "Rien d'activé";
  // Relations : les VUES visuelles restent sous « Vue relation (bêta) »
  // (D-086), mais la GESTION — arbitrages de liaisons, retraits proposés —
  // est toujours accessible (D-296) : le rapport d'installation y pointe,
  // elle est le complément obligatoire de D-243, pas une expérimentation.
  return {
    bibliotheque: [
      { section: "packs", icone: "📚", fond: "var(--indigo-doux, #e7ecf3)", titre: "Disciplines et classement",
        etat: `${nbDisc} discipline${nbDisc > 1 ? "s" : ""} · ${nbCat} catégorie${nbCat > 1 ? "s" : ""} · ${nbNiv} niveau${nbNiv > 1 ? "x" : ""}` },
      { section: "techniques", icone: "🥋", fond: "#e5ece6", titre: "Gestion des techniques",
        etat: `${nbTech} technique${nbTech > 1 ? "s" : ""}` },
      { section: "atraiter", icone: "🩹", fond: "#efe3d6", titre: "À traiter",
        etat: aTraiter ? `${aTraiter} à traiter` : "Rien à traiter" },
      { section: "corbeille", icone: "🗑", fond: "#efe3d6", titre: "Corbeille",
        etat: nbCorbeille ? `${nbCorbeille} fiche${nbCorbeille > 1 ? "s" : ""} restaurable${nbCorbeille > 1 ? "s" : ""}` : "Vide" },
      ...(av
        ? [
            { section: "doublons" as const, icone: "🔀", fond: "#efe3d6", titre: "Doublons potentiels",
              etat: nbDoublons ? `${nbDoublons} à examiner` : "Aucun doublon détecté" },
            { section: "medias" as const, icone: "🎞", fond: "#e5ece6", titre: "Médias",
              etat: nbFichiers ? `${nbFichiers} vidéo${nbFichiers > 1 ? "s" : ""} locale${nbFichiers > 1 ? "s" : ""}` : "Parc de médias" },
          ]
        : []),
      { section: "relations", icone: "🔗", fond: "#e8e4ef", titre: "Relations entre techniques",
        etat: `${nbRel} relation${nbRel > 1 ? "s" : ""}` },
    ],
    echange: [
      { section: "packs-officiels", icone: "🧳", fond: "#e5ece6", titre: "Starter packs",
        etat: "Découvrir et installer les packs publiés" },
      { action: (a) => a.choisirPackAImporter(), icone: "📂", fond: "#e5ece6", titre: "Importer un pack",
        etat: "Depuis un fichier .movpack reçu" },
      { section: "publier", icone: "📤", fond: "#efe3d6", titre: "Créer ou exporter un pack",
        etat: "Produire un fichier partageable" },
      // D-308 : Stockage et Sauvegardes sont deux questions — ce qu'on occupe,
      // et quand on a mis à l'abri. Chacune a son entrée et son état.
      { section: "stockage", icone: "📦", fond: "#e5ece6", titre: "Stockage",
        etat: espaceUtilise || "Espace occupé et persistance" },
      { section: "sauvegardes", icone: "💾", fond: "var(--indigo-doux, #e7ecf3)", titre: "Sauvegardes",
        etat: dateSauv ? `dernière sauvegarde ${dateSauv}` : "aucune sauvegarde" },
    ],
    preferences: [
      { section: "securite", icone: "🔒", fond: "#e8e4ef", titre: "Sécurité", etat: secu },
      { section: "apparence", icone: "🎨", fond: "#efe3d6", titre: "Apparence", etat: themeLisible },
      // D-234 : les réglages avancés quittent la carte reléguée en bas
      // d'Apparence — ce sont des choix de PÉRIMÈTRE, pas de présentation.
      { section: "avance", icone: "🧪", fond: "#e8e4ef", titre: "Réglages avancés", etat: etatAvance },
      ...(av
        ? [{ section: "diagnostic" as const, icone: "🩺", fond: "#e5ece6", titre: "Diagnostic et maintenance" }]
        : []),
      { section: "aide", icone: "❓", fond: "#e5ece6", titre: "Aide",
        etat: "Prise en main et gestes qui sauvent" },
      { section: "apropos", icone: "ℹ️", fond: "var(--indigo-doux, #e7ecf3)", titre: "À propos",
        etat: `Movenso · v${VERSION}` },
    ],
  };
}

function ligneMenu(app: MovensoApp, e: EntreeMenu): TemplateResult {
  const ouvrir = () => (e.section ? app.ouvrirPlusSection(e.section) : e.action?.(app));
  return html`<button class="ligne-menu" @click=${ouvrir}>
    <span class="ligne-menu-icone" style="background:${e.fond}" aria-hidden="true">${e.icone}</span>
    <span class="ligne-menu-corps">
      <span class="ligne-menu-titre">${e.titre}</span>
      ${e.etat ? html`<span class="ligne-menu-etat">${e.etat}</span>` : nothing}
    </span>
    <span class="chevron" aria-hidden="true">›</span>
  </button>`;
}

/** Écran « Plus » : un menu court et compréhensible (D-071). */
export function gabaritPlus(app: MovensoApp): TemplateResult {
  const groupes = etatsMenu(app);
  const groupe = (titre: string, entrees: EntreeMenu[]) => html`
    <div class="menu-section-titre">${titre}</div>
    <div class="menu-groupe">${entrees.map((e) => ligneMenu(app, e))}</div>`;
  return html`
    <div class="ecran plus">
      <header class="marque"><div style="flex:1"><div class="nom">Plus</div>
        <div class="devise">Gérer, importer, sauvegarder, régler.</div></div></header>
      ${groupe("Ma bibliothèque", groupes.bibliotheque)}
      ${groupe("Importer, exporter et sauvegarder", groupes.echange)}
      ${groupe("Préférences", groupes.preferences)}
    </div>
  `;
}
