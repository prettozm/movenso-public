# Workflows Movenso — carte visuelle vivante

> **Type : vivant** · **Statut : NON VALIDÉ (descriptif — le code fait foi)**
> **Remis en cohérence avec le code le 2026-07-24** (nav réelle à 4-5 onglets,
> chrono de séance, « Plus » à la place de « Atelier »).
> Support visuel **unique** des workflows (D-020.7). Chaque workflow porte son
> état : **✅ implémenté techniquement — validation terrain EN ATTENTE
> (recette, D-022)** · **🎨 prototypé** · **⏳ différé** · **❓ hypothèse**.
> Aucun ✅ ne vaut validation définitive : seule la recette (Validation 4)
> valide. Les workflows implémentés se démontrent dans **l'application
> elle-même** (`npm run dev`, ou l'APK) — un prototype HTML ne serait qu'une
> copie ; les prototypes (D-008) sont réservés aux conceptions non encore
> construites.

## 0. Trois contextes, un système

```mermaid
flowchart LR
    P["📱 Pratiquant<br/>téléphone personnel<br/>consulter · capturer · composer"]
    S["🖥️ Sensei / curateur<br/>grand écran<br/>construire · gouverner · publier"]
    T["📺 Tablette de club<br/>lieu de pratique<br/>consulter un corpus choisi"]
    M((Movenso<br/>même code<br/>mêmes données))
    P --- M
    S --- M
    T --- M
    S -- "pack .movpack" --> P
    S -- "pack .movpack" --> T
```

Le pack est le **véhicule de diffusion** entre contextes : produit depuis
**Plus › Créer ou exporter un pack**, installé volontairement partout ailleurs.
Aucun compte, aucun service distant.

## 1. Navigation globale — trois onglets (Relations et Compositions en bêta opt-in, D-084/D-223)

```mermaid
flowchart TD
    subgraph barre [Barre basse — 3 destinations, +Relations/+Compositions si bêtas actives]
      B[Bibliothèque]
      FA[Favoris]
      RL[Relations ⃰ gated]
      CO[Compositions ⃰ gated]
      PL[Plus ⋯]
    end
    B --> R[Racine : disciplines ·<br/>recherche globale · état vide actionnable]
    R --> D[Discipline<br/>grille visuelle · filtres cumulables · action « ＋ Ajouter »]
    D --> F[Fiche technique<br/>média principal · voix · carnet · relations]
    F --> F
    FA --> F
    RL --> RV[Relations — 4 vues, bêta, gated<br/>entrée déterministe : centre mémorisé/transmis, sinon « point de départ »<br/>fil d'Ariane Explorer seulement (D-160) · Liste raisons par rôle · Carte mindmap HTML pan/zoom/pincement + dépliage multi-niveaux sur place, chips filtre, sans chevauchement (D-158→D-160) · Mindmap synthétique (hub central + zones sémantiques par type, liaisons 2px — D-148/D-153) · Explorer guidé (badges de rôle par étape, mélange d’objectifs affiché — D-198/O1) → composition]
    CO --> CL[Compositions — Mes | Packs<br/>liseré de discipline · méta à icônes · ▶ + ⋮/Dupliquer]
    CL --> CE[Fiche de composition<br/>lecture · ✎ mode édition · ⋮<br/>entraînement pas-à-pas + chrono]
    CE --> F
    F -.« Utilisée dans ».-> CE
    PL --> PLR[sous-écrans : disciplines · techniques · à traiter ·<br/>doublons · médias · relations · corbeille ·<br/>publier · stockage et sauvegardes · sécurité ·<br/>apparence · réglages avancés · diagnostic]
```

**Démarrage** (D-014, migration testée) : la **Bibliothèque** par défaut —
liste des disciplines, ou **écran de première ouverture** proposant **quatre
départs nommés** (D-311) : *Installer un pack* (le catalogue,
joignable dès la première ouverture), *Importer un pack depuis un fichier*,
*Restaurer une sauvegarde* (le geste de qui change d'appareil) et *Créer ta
première technique*. Le premier est **recommandé** — c'est le seul qui remplit
la bibliothèque en un geste ; les trois autres sont des recours (D-328).
Chacun porte une **icône en traits**, comme la nav basse et les cartes. Cet
écran n'apparaît que sur l'état **VIERGE** du domaine (`bibliothequeVierge` —
aucun pack, technique, composition, ni contenu importé ou restauré, ni trace
d'un contenu qui aurait existé), et l'action flottante « ＋ Ajouter » y est
**masquée** : elle revient dès qu'un contenu existe (D-328). Le réglage (Plus › Apparence) permet aussi : Favoris ·
Compositions · dernière discipline consultée · discipline choisie. Une ancienne
préférence « accueil » est **migrée automatiquement** vers la Bibliothèque.

**Starter packs** (D-211, refondu D-333, dégraissé D-335 — l'écran s'appelait
« Packs officiels ») : le catalogue du site, une illustration par pack (servie
par le site, récupérée par le canal du catalogue et affichée en `blob:`, la CSP
n'est pas ouverte davantage), l'avertissement « des bases pour commencer » qui
nomme le professeur qualifié, le **cadre adapté**, le partenaire consentant et
le risque de blessure, la version et la date, l'état **installé** (une pastille,
pas un bouton) ou **mise à jour disponible** (dérivé de `editionsPacks` et du
`packId` publié), puis une section **« Envie de contribuer ? »** proposant les
disciplines sans pack comme des IDÉES, sans statut ni bouton, retirées
d'elles-mêmes dès que leur pack paraît. La maturité (Alpha/Bêta) reste publiée
au catalogue mais n'est plus affichée dans l'app (D-335). L'installation passe
par le circuit d'import normal, inchangé.

**Le savoir « à rattacher »** (capture gardée pour plus tard, technique sans
contenu) vit dans **Plus › À traiter** — il n'existe plus de « À reprendre »
(code mort retiré, D-127). La capture rapide passe par l'action contextuelle
« ＋ Ajouter » d'une discipline (jamais un bouton global).

**Bouton retour Android** (déterministe — vérification appareil en attente) :
feuille ou panneau ouvert → fermer · édition → quitter (sauvegardée au fil de
l'eau) · pile → revenir d'où l'on vient (filtres et position restaurés) ·
sous-destination → racine de son onglet · racine d'un onglet → Bibliothèque ·
racine Bibliothèque → système.

**Conservation d'état** : chaque onglet garde écran, pile, filtres et
défilement pendant la session ; un **second appui** sur l'onglet actif revient
à sa racine (comportement constant).

## 2. Les workflows : entrée → étapes → sortie, et ce qui est réellement démontré

> **Démontré = e2e** (parcours utilisateur complet dans un vrai Chromium,
> OPFS réel) ou **manuel** (vérifié à la main, pas encore couvert par le
> parcours automatisé). Un test unitaire seul ne qualifie jamais un workflow.
> La **validation terrain reste entièrement en attente** (recette, D-022/D-023).

| # | Workflow | Entrée | Étapes | Sortie | Démontré |
|---|---|---|---|---|---|
| A | Premier lancement vide | Installation vierge | importer OU créer sa discipline OU capturer (technique + discipline à la volée) | corpus initialisé, jamais d'impasse | **e2e** (scénario A) |
| A′ | Peupler sans capture | Discipline vide : « Créer la première technique » + « Importer un pack » (lot 2 §11) | champ nom → fiche en édition → compléter → retour | technique visible dans la grille — aucune impasse | **e2e** (scénario A) |
| B | Explorer au lieu de pratique | Onglet Bibliothèque | racine (compteurs d'identités · sources · voix ; recherche globale contextualisée) → grille (badge « N voix », aperçu selon la source filtrée) → filtres cumulables + « Réinitialiser » → fiche → retour (filtres PAR discipline conservés) | technique trouvée, ≤ 3 gestes, jamais de doublon | **e2e** (lot 2 : compteurs, sources, réinitialisation, aucun-résultat, mémoire par discipline, scénarios C/E) |
| C | Capturer → rattacher | « ＋ Ajouter » (racine et discipline) · carnet de la fiche — l'éditeur de composition n'ouvre PLUS la capture (5.7) | filmer / vidéo existante / lien / mot → nature+auteur si besoin → rattacher / **créer** (discipline présélectionnée) / plus tard | contribution sur fiche, ou « à rattacher » dans **Plus › À traiter** | **e2e** (note, plus tard → À traiter, rattachement différé, création à la volée) · vidéo réelle : **spike appareil** |
| D | Consulter une fiche | Recherche, grille, relation, bloc | média principal en tête → voix par provenance → relations, « Utilisée dans » | lecture immédiate, autorité identifiable | **e2e** (2 voix, opt-in vidéo) |
| E | Modifier en contexte | Fiche → menu ⋮ | nom, appellation, taxonomies, média principal, carnet, **Retirer** | fiche corrigée, ou identité retirée (notes → « à rattacher », snapshot) | édition : **e2e** (Terminer) · retrait : **manuel** |
| F | Composer | Compositions → Créer | ajouter techniques + blocs libres → réordonner → Terminer | « Ma spéciale » consultable | **e2e** (scénario F) |
| G | Composition à l'entraînement | Composition (lecture) → ▶ | mode entraînement pas-à-pas (lot 5 §14) — jauge de séance, anneau de décompte, « Ensuite » avec le **rôle suivant** et la passation Tori → Uke (D-323) → fiche → **retour pile** au même bloc | composition déroulée bloc par bloc, sans notification parasite | **e2e** + recette Android (les blocs repère existants restent lisibles ; l'éditeur n'ouvre plus la capture, 5.7) |
| H | Publier une sélection maîtrisée | Plus › Créer ou exporter un pack | cocher les sources (local seul par défaut) ; **option opt-in « Mes séances »** (D-127) → .movpack | pack sans carnet ni contenu d'autrui non coché ; séances jouables embarquées | périmètre : **test unitaire** + **manuel** (⚠ pas de e2e) |
| I | Protéger / restaurer | Plus › Créer ou exporter un pack (sauvegarde complète) | .movpack complet → import sur installation vierge | tout restauré sans perte | **e2e** (scénario I) |
| I′ | Exporter / partager une composition | Composition → ⋮ → Exporter (ou ▸ partager) | .movpack (portée composition + techniques + disciplines) → import ailleurs | composition **jouable** chez le destinataire (D-127) | import multi-disciplines : **test unitaire** · export : **manuel** |
| J | Rollback | Plus › Sauvegardes | choisir un snapshot motivé → restaurer | état restauré, l'actuel snapshoté | **manuel** |
| J′ | Décider des liens qu'un pack retire | Mise à jour d'un pack → rapport d'import (« N liens que tu as ne sont plus déclarés — rien n'a été retiré ») | Plus › Relations → « garder » / « retirer » à l'unité, ou « Tout retirer » (confirmation nommée + point de restauration) | maillage aligné sur la version du pack, ou conservé — le choix est dit, jamais subi (D-243) | **e2e** (chapitre `retraits-liens`) + **unit** |
| K | Import proposé | Plus › Importer un pack | rapport calculé à blanc → Installer / Annuler | rien d'écrit sans accord | **e2e** (chaque import du parcours) |
| L | Démarrage choisi | Plus › Apparence | Bibliothèque / Favoris / Compositions / dernière discipline / discipline choisie (« accueil » migré) | l'app s'ouvre où l'on vit | migration : **test unitaire** · réglage : **manuel** |
| M | Naviguer entre onglets | Barre basse (4-5 onglets) | Bibliothèque ↔ Favoris ↔ [Relations] ↔ Compositions ↔ Plus — état conservé par onglet, second appui = racine | jamais de contexte perdu en session | **e2e** (mémoire d'onglet, second appui) |

## 3. Premier lancement vide (A) — ✅

```mermaid
flowchart LR
    V[Installation vide] --> Q{Bibliothèque prête<br/>deux gestes directs}
    Q --> I[⤓ Importer un pack<br/>officiel · club · perso]
    Q --> N[＋ Créer une discipline]
    N --> K[« ＋ Ajouter » sur la discipline<br/>capture, technique à la volée]
    K --> R[Structurer plus tard<br/>Plus › À traiter]
```

*(Lot 1 : la capture sans discipline n'a plus de point d'entrée sur une
installation totalement vide — le lot 4 §2 la réintroduira depuis la racine
Bibliothèque : « Filmer ou garder quelque chose ».)*

Aucun pack embarqué en production (D-017) ; les packs de démonstration sont
distribués séparément (artefact `packs-demo`).

## 4. Ajouter du savoir : création, capture, rattachement (C) — ✅ refondu au lot 04

```mermaid
flowchart TD
    A[« Ajouter »<br/>racine ou discipline] --> T[Une technique]
    A --> C[Capture : filmer · fichier · lien · mot]
    T --> F[Fiche — visible dans la grille]
    C --> AP[Aperçu : Utiliser / Refilmer / Abandonner]
    AP --> N[Note — un mot suffit<br/>Moi par défaut]
    N --> R{Sais-tu où le ranger ?}
    R --> EX[Technique existante] --> F
    R --> NV[Nouvelle technique] --> F
    R --> PT[Garder pour plus tard] --> REP[Plus > À traiter] -->|rattacher plus tard| R
```

- **Création minimale** : « Ajouter » → Une technique — nom obligatoire,
  discipline présélectionnée/choisie/créée dans le parcours ; appellation
  et « Classer maintenant » facultatifs (« Je le ferai plus tard ») ; la
  fiche s'ouvre, la technique est dans la grille. Doublons suggérés
  pendant la saisie (« Utiliser « X » » / « Créer quand même », l'exact
  exige une confirmation). — *entrée : panneau Ajouter · sortie : identité
  + fiche · démontré : e2e + unit (doublons)*
- **Capture vidéo / fichier** : sélecteur (caméra ou fichiers) → APERÇU
  (rien n'est écrit) → Utiliser / Refilmer / Abandonner → note → ranger.
  — *données : contribution + média local OPFS écrits à la toute fin ·
  démontré : e2e (fichier réel) ; caméra et permissions : Android manuel*
- **Lien** : collé, service ou domaine détecté LOCALEMENT (l'URL est
  conservée telle quelle, aucun réseau) → Utiliser / Modifier / Abandonner.
  — *démontré : e2e ; hors ligne réel : recette Android*
- **Mot / repère** : champ libre, un mot suffit, aucune taxonomie.
  — *démontré : e2e (indexé par la recherche)*
- **Rattachement** : « Sais-tu où le ranger ? » — existante (recherche
  cadrée à la discipline, élargissable, vignettes), nouvelle (création
  atomique : la capture suit, jamais d'identité partielle), ou « Garder
  pour plus tard » → conservé dans **Plus › À traiter**.
  — *démontré : e2e (les trois chemins, reprise après relance comprise)*
- **Provenance** : Moi · Personnel par défaut, SANS question ; « Ce contenu
  vient de quelqu'un d'autre » ouvre prof/club/ressource (attribution
  exigée pour le sourcé ; jamais le nom d'un pack par défaut ; pas de
  « référentiel » à la capture — aucun rôle de curation représentable).
  Une capture non personnelle se garde aussi pour plus tard, provenance
  conservée. — *démontré : e2e + unit (validation)*
- **À traiter (Plus)** : consulter (texte, vidéo, lien), modifier le
  texte, rattacher, ou supprimer avec confirmation (snapshot préalable).
  — *démontré : e2e*
- **Annulation / retour** : étape par étape ; un contenu existant pose
  « Que faire de cette capture ? » (Garder / Continuer / Abandonner) ;
  sans contenu, sortie directe. Écritures sûres : anti double-geste,
  rollback si la persistance échoue (fichier retiré, capture conservée —
  chemin d'erreur revu à la main, non automatisé). — *démontré : e2e
  (logique pilotée) ; ordre clavier→feuille : Android manuel*
- **Permissions Android (§15)** : la caméra et les fichiers passent par le
  sélecteur système de la WebView (permissions natives) ; un refus rend
  simplement le geste sans résultat — la capture reste à l'étape contenu
  avec les alternatives (fichier, lien, mot). Le refus permanent n'est pas
  détectable depuis `input file` : documenté, à observer en recette.
  — *validation terrain en attente*

## 5. Fiche technique (D) — ✅ refondue au lot 03

```mermaid
flowchart TD
    B[Bibliothèque] --> F[Fiche]
    F --> M[Média principal + légende<br/>auteur · provenance — galerie compacte]
    F --> V[Voix — UNE ouverte à la fois<br/>importée = intacte D-027 · locale = éditable]
    F --> C[Mon carnet — édition directe]
    F --> R[Relations · N / Utilisée dans · N]
    R -->|toucher une cible| F2[Fiche liée] -->|retour| F
    F -->|retour| B
```

- **Consultation** : média principal en tête avec légende éditoriale
  (« auteur · provenance », « Moi » si personnel, jamais un slug) ; galerie
  compacte si plusieurs médias — afficher un autre média est un choix de
  session ; « Utiliser comme aperçu principal de cette technique » rend
  l'effet global explicite. — *démontré : e2e + recette Android à venir*
- **Changement de voix** : accordéon (une seule ouverte), titres
  « Provenance · auteur », ordre : voix du média affiché, puis
  référentiel → enseignement → ressource → personnel. — *démontré : e2e*
- **Repère personnel** : ajout direct dans Mon carnet (champ « ＋ note »,
  Entrée), édition et suppression sans Capturer ; indexé par la recherche.
  — *démontré : e2e*
- **Ajout de médias** : feuille « Ajouter un média » (menu ⋮, ＋ de la
  galerie, état « Aucun média ») — filmer / fichier de l'appareil / lien,
  questions utiles seulement, jamais « à quelle technique ? ».
  — *démontré : e2e (lien) ; filmer/fichier : recette Android*
- **Voix importée (D-027)** : jamais éditable directement — explication
  affichée + « Créer une adaptation locale » (préremplie, attribuée,
  modifiable, jamais écrasée par une réimportation). — *démontré : e2e + unit*
- **Relations** : « Relations · N », aperçu de 3, « Voir toutes les
  relations » ; toucher une cible ouvre sa fiche, le retour conserve la
  voix, le média et l'état déplié (§19). — *démontré : e2e*
- **Compositions** : « Utilisée dans · N composition(s) », aller-retour
  fiche ↔ composition par la pile. — *démontré : e2e*
- **Retrait sécurisé** : menu ⋮ → confirmation nommant les compositions
  dépendantes, snapshot préalable, notes redevenues « à rattacher ».
  — *démontré : e2e (menu) ; confirmation native : recette Android*

## 6. Favoris et Compositions (onglets dédiés) + chrono (F/G) — ✅ refondu au lot 05 + finition

Favoris et Compositions sont des **onglets de premier niveau** ; le savoir « à
rattacher » vit dans **Plus › À traiter** (l'ancienne « À reprendre » est
retirée, D-127).

```mermaid
flowchart TD
    FA[Onglet Favoris — cartes 2 colonnes] -->|toucher| FT[Fiche technique]
    CO[Onglet Compositions — Mes | Packs :<br/>liseré de discipline · méta à icônes · ▶ + ⋮/Dupliquer] --> CE[Fiche de composition — CONSULTER :<br/>provenance · étapes/durée/rôles dérivés · aperçu · Démarrer]
    CE -->|✎ barre haute| ED[Mode édition :<br/>＋ Ajouter · rôle · lien · ▲▼ · ⋯ · ✕ — une colonne]
    CE --> AJ[⋮ hors-séquence : renommer · présentation · dupliquer · supprimer]
    CE --> EN[Entraînement pas-à-pas :<br/>progression · chrono · voix/bips · barre masquée]
    EN -->|Voir la fiche| FT -->|retour au même bloc| EN
    AT[Plus › À traiter] --> RA[Rattacher / Créer / Modifier / Supprimer]
```

- **Favoris** : étoile sur la fiche (immédiat, réversible, sans
  confirmation) ; **onglet dédié** en cartes deux colonnes ; champ `favoris`
  (schéma v3) sauvegardé/restauré, JAMAIS publié ; référence orpheline ignorée
  à l'affichage, nettoyée au retrait local. — *démontré : e2e + unit*
- **À traiter (Plus)** : captures inachevées et techniques sans contenu,
  rattachables plus tard. — *démontré : e2e*
- **Création d'une composition** : titre obligatoire, description
  facultative, éditeur ouvert aussitôt. — *démontré : e2e*
- **Ajouter une technique** : recherche + favoris ★ + discipline des
  résultats ; référence à l'identité stable + libellé de secours.
  — *démontré : e2e*
- **Ajouter une étape, progressivement** (D-322) : la feuille demande **quoi**
  d'abord ; *qui agit*, *en même temps* et la **durée** n'apparaissent qu'une fois
  le contenu posé. Exception : en saisie libre, une **durée seule crée une
  pause**, donc la durée y reste offerte tout de suite. La recherche n'est plus
  un cul-de-sac — sans rien taper, elle propose les techniques de la discipline
  du **dernier pas technique** (sinon de la seule discipline installée, sinon
  rien : jamais un choix arbitraire). Et l'étape du nom **nomme le second
  départ** — partir d'une séance de tes packs et la dupliquer — quand il existe
  vraiment une composition de pack. — *démontré : e2e + unit*
- **Ajouter du texte / segment / pause** : champ libre (type interne
  générique) ou, en édition inline, un segment minuté / une pause ; les **neuf
  types** restent en données (anciens blocs lisibles et intacts à
  l'import/réimport) — aucun libellé interne de type n'est visible.
  — *démontré : e2e + unit*
- **Composition à plusieurs** (D-227/D-231/D-232/D-235) : les **rôles** se
  déclarent **dans l'entonnoir de création** — étape « Qui pratique ? », deux
  choix seulement : *Seul* (défaut, se passe d'un geste) et *À plusieurs*, qui
  commence à deux et grandit par « ＋ Ajouter un rôle » (D-232 : un palier
  « Plus » arbitraire n'apportait rien). **L'app ne propose aucun nom** :
  champs vides, on ne passe pas tant qu'ils ne sont pas tous remplis, et rien
  n'est jamais nommé « Rôle 3 ». Le ⋮ sert au rattrapage d'une composition
  existante (même règle : un rôle n'existe qu'une fois nommé). À l'ajout d'un
  pas, deux choix de plus : **qui agit** (rôle **alterné par défaut**, « Tous »
  = neutre) et **un unique interrupteur**, *Rejoint le temps précédent*
  (D-235) — coché, le pas se joue en même temps que le précédent ; décoché, il
  ouvre un temps. Il n'existe **aucune autre relation** : la cause (« en
  réponse au blocage ») se dit en consigne, en texte libre.
  **Retirer un rôle ne supprime aucun pas** : ses pas redeviennent neutres
  (confirmation qui le dit). — *démontré : e2e + unit*
- **Reprendre une séance interrompue** (D-324, UI-6) : une carte **« Continuer »**
  en tête de l'onglet nomme la composition et l'étape (« Étape 3 sur 13 · Cercles
  d'épaules ») ; son ▶ relance le lecteur **au pas noté**. **Une seule** entrée —
  lire une autre composition remplace la précédente. **« Quitter » garde** la
  position, **« Terminer » l'efface** (une séance finie n'a rien à continuer). La
  position est un réglage d'**appareil** : elle ne part ni dans un pack ni dans
  une sauvegarde — changer de téléphone ne rapporte pas la reprise.
  — *démontré : e2e*
- **Retrouver une composition** (D-320, UI-1) : l'onglet s'ouvre sur une
  **bascule Mes compositions | Packs**, dont les deux compteurs sont annoncés —
  un onglet vide se voit avant d'être touché, et l'entrée se fait du côté qui a
  du contenu. Recherche et chips de discipline portent sur les deux côtés.
  **Mes** : cartes compactes, tri Récent / Nom / Durée, ⋮ sur la carte
  (renommer, décrire, rôles, dupliquer, supprimer). **Packs** : groupes par
  discipline, aperçu de trois puis « Voir les N », **Dupliquer** à la place du ⋮
  — et un pied qui dit pourquoi : *l'originale suit les mises à jour du pack, ta
  copie t'appartient*. Chaque carte porte le **liseré de sa discipline
  dominante** (dérivée du contenu ; liseré neutre et chip « Mixte · a + b » en
  cas d'égalité), une **ligne de méta à icônes** (étapes · durée si elle existe ·
  Seul / À deux / N rôles) et les **rôles nommés** à partir de deux.
  **Dupliquer une composition de pack en fait la mienne** : elle change de côté,
  perd son badge de provenance, et récupère son ⋮. — *démontré : e2e*
- **Consulter une composition** (D-319, UI-2) : ouvrir une composition mène à
  une **fiche de lecture**, jamais à l'éditeur — c'est ce qui manquait, et
  c'est ce qui faisait qu'on modifiait le contenu d'un pack sans l'avoir
  voulu. La fiche répond à quatre questions avant tout geste : *qu'est-ce que
  c'est* (vignette, titre, description), *d'où ça vient* (badge de provenance
  quand ce n'est pas personnel), *ce que ça engage* (nombre d'étapes, durée
  totale si elle existe, rôles ou « Seul » — **tout dérivé**, aucune saisie),
  *à quoi ça ressemble* (aperçu des cinq premières étapes, « Voir les N
  étapes » déplie sur place). Une seule action forte, **Démarrer** ; Dupliquer
  au second rang ; **Planifier présent mais désactivé**, et il dit qu'il
  attend l'Agenda. Les intertitres d'un kata (« — Te-waza — ») s'affichent en
  **jalons** non numérotés : ce ne sont pas des gestes à faire. Une
  composition **à plusieurs** garde son déroulé « en temps » plutôt qu'un
  aperçu plat — la simultanéité est une information qu'une liste perd.
  — *démontré : e2e*
- **Modifier une composition entière** (D-233, geste d'entrée revu D-319,
  hiérarchie revue D-321) : l'éditeur annonce ce que la séance **pèse** — même
  bandeau dérivé que la fiche (étapes · temps si la composition se lit en temps ·
  durée · rôles ou « Seul »), et les pas se lisent comme une **suite** : rang sur
  un rail vertical continu. Le **✎ de la barre haute**
  bascule l'écran en **mode édition** — tous les pas montrent alors, sur place,
  *qui agit*, leur *lien avec le pas précédent*, les flèches ▲/▼, un ⋯ vers la
  feuille détaillée (consigne, durée, remplacer la technique) et un ✕. On
  corrige toute la composition sans ouvrir une feuille par pas ; le ✓ referme.
  L'édition se lit **en une colonne** quelle que soit la largeur (éditer est
  linéaire ; lire est structuré). **En lecture, aucun outil de pas n'existe** —
  depuis D-319 la lecture n'est même plus la même surface : c'est la fiche, et
  « ＋ Ajouter un élément » vit désormais dans l'éditeur. — *démontré : e2e*
- **Réordonner** (D-233) : **les flèches ▲/▼ sont le seul mécanisme**, ici
  comme pour les disciplines, les catégories et les niveaux. Le
  glisser-déposer a été retiré : WCAG 2.5.7 impose de toute façon une
  alternative à pointeur unique, il n'auto-défilait pas aux bords (donc ne
  pouvait pas déplacer un élément hors écran), et sa poignée mangeait la
  largeur. Chaque déplacement est annoncé (`aria-live`).
  — *démontré : e2e (compositions, disciplines, catégories)*
- **Lire une composition à rôles** (D-229/D-231/D-235) : une **rangée = un
  temps** (numéroté à gauche), une **colonne = un rôle** (nommé une seule fois
  en tête), deux cartes empilées dans une case = deux actions **simultanées du
  même rôle**. **Aucun glyphe, aucun mot de liaison** : la mise en page porte la
  temporalité. Le nombre de voies suit la largeur de l'écran (2 dès 360 px,
  3 dès 530, 4 dès 700…) ; replié en une colonne, ce qui partage un numéro se
  joue ensemble et le badge dit qui. Une **couleur par rôle** (six teintes)
  encadre chaque carte, en renfort du nom. La cause d'un pas (« en réponse
  au blocage ») se lit en consigne.
  — *démontré : e2e (quatre rôles sur écran étroit ET large) + unit*
- **Exactement deux constructions** (5.7) : l'éditeur n'expose que
  « Ajouter une technique » et « Ajouter du texte » — l'action « Filmer
  ou noter un repère » a été retirée sur décision humaine ; les blocs
  repère existants restent lisibles, le workflow de capture (lot 4) est
  inchangé. — *démontré : e2e (NR-005-002)*
- **Supprimer une composition** (5.7) : action « Supprimer la
  composition » (jamais « Retirer » seul), traitement dangereux distinct
  d'Exporter/Fermer, confirmation NOMMANT la composition, snapshot
  préalable. — *démontré : e2e*
- **Notifications transitoires** (5.7) : un toast disparaît seul (~3,4 s),
  est remplacé par le plus récent, s'efface à tout changement d'écran et
  n'apparaît jamais dans le mode entraînement. — *démontré : e2e
  (NR-005-001) ; durée perçue sur appareil : recette Android*
- **Réordonnancement** : Monter/Descendre accessibles, persisté, stable
  après relance. — *démontré : e2e (ordre après restauration compris)*
- **Menu d'un bloc technique** : Voir la fiche / Remplacer (répare aussi
  une référence indisponible) / Ajouter du texte après / Retirer.
  — *démontré : e2e (scénario G complet)*
- **Mode entraînement** : pas-à-pas plein écran, progression N/M, bloc en
  grand, « Ensuite : … », Précédent/Quitter/Suivant, barre masquée, fiche
  → retour au même bloc. — *démontré : e2e ; tactile/tablette : Android*
- **Chrono de séance vivant** (D-125/126) : pour les segments minutés,
  décompte qui tourne, **passage automatique** au bloc suivant à zéro,
  pause/reprendre, transition de préparation réglable (3-2-1), **voix**
  (TTS natif Android / `speechSynthesis` web) et **bips**, mode son cyclable
  (voix / bips / les deux / muet). Coupé à toute sortie. — *démontré : e2e
  (déroulé pas-à-pas) ; voix/bips réels sur appareil : recette S2.3 phase A
  (Samsung A36, 6/6)*
- **Arrière-plan et verrouillage** (S2.3/D-170) : pendant la séance,
  **l'écran ne s'éteint pas tout seul** (verrou d'écran) ; app cachée ou
  téléphone verrouillé volontairement = **séance mise en pause** (voix
  coupée net, bandeau explicatif au retour), reprise d'un geste là où on
  était — jamais de décompte fantôme qui dérive. — *démontré : e2e
  (visibilitychange + verrou simulés) ; à confirmer sur appareil (contre-
  recette courte)*
- **Dupliquer** : nouvelles références, jamais de copie de technique ou
  média, l'originale intacte. — *démontré : e2e*
- **Export/Import** : rapport AVANT export (blocs, identités seules sans
  contributions, vidéos, carnet jamais inclus) ; à l'import les
  références rejoignent par le rapprochement, une référence absente
  s'affiche « à retrouver » sans casser la structure. — *démontré : unit
  (multi-disciplines, idempotence, anciens types) + e2e (§17)*
- **Sauvegarde/restauration** : favoris, compositions (ordre, textes),
  captures à reprendre — restaurés sur installation vierge, mode
  entraînement fonctionnel. — *démontré : e2e (contexte C)*

## 7. Plus : gouverner le corpus (ancien « Atelier », lot 06 + refonte D-071) — ✅ livré

« Plus » est un **menu plat** (icône + titre + état + chevron) ; chaque ligne
ouvre un **sous-écran spécialisé** (plus d'accordéons « 4 intentions »).
Certaines entrées n'apparaissent qu'en **mode avancé** ou en **relations bêta**.

```mermaid
flowchart TD
    PL[Onglet Plus — menu plat] --> G1[Ma bibliothèque]
    PL --> G2[Importer, exporter, sauvegarder]
    PL --> G3[Préférences]
    G1 --> C1[Disciplines et classement : renommer · réordonner ·<br/>ouvrir · suppression sécurisée]
    G1 --> C3[Gestion des techniques · Types de relation · Sources]
    G1 --> AT2[À traiter · Corbeille]
    G1 --> M3[Doublons ⃰avancé · Médias ⃰avancé · Relations ⃰bêta]
    G2 --> E1[Importer un pack : aperçu → rapport]
    G2 --> E2[Créer ou exporter un pack : sources + opt-in séances →<br/>métadonnées → prévisualisation → sortie]
    G2 --> E4[Sauvegardes : complète / légère · restaurer · snapshots]
    G3 --> R1[Sécurité · Apparence : thème/tonalité/démarrage ·<br/>Diagnostic ⃰avancé]
```

Les workflows, avec leur niveau réel de démonstration :

| Workflow | Entrée → étapes → sortie | Données affectées | Démontré | Limites connues |
|---|---|---|---|---|
| Navigation Plus (A) | onglet → menu plat de sous-écrans (entrées avancées/bêta conditionnelles) → chaque ligne ouvre son sous-écran | aucune | **e2e** | interactions au doigt : recette Android |
| Discipline (B) | Construire → créer (nom seul) / renommer / réordonner (▲/▼ au doigt **ou** au clavier — seul mécanisme depuis D-233) / ouvrir / retirer vide / suppression sécurisée (contenu présenté, export proposé, confirmation renforcée, snapshot) | disciplines, techniques, contributions (personnelles → « à rattacher ») | **e2e** (scénario B complet, réordonnancement par les flèches) | renommage → nouvel `idDePack` à la republication (8B) |
| Taxonomies (C) | familles/niveaux : créer, renommer, ordonner (▲/▼ au doigt ou au clavier, D-233), couleurs → suppression avec arbitrage (remplacer / retirer la classification / annuler) | disciplines, techniques (reclassées, jamais de référence invalide, snapshot) | **e2e** (scénario C complet) | — |
| Types de relation (D) | lignes libellé/inverse/⇄ + usages → renommer, symétrie si inutilisé, suppression si inutilisé | typesRelation | **e2e** (créer, renommer, refus) | « l'utiliser » impossible : aucune UI ne crée de relation (tracé) |
| Média manquant (E) | Médias et qualité → fiches concernées → retirer la note sur la fiche | contributions | détection : **e2e indirect** · traitement : **manuel** (exige un fichier réellement absent) | recette Android |
| Média orphelin (F) | analyse → prévisualisation OBLIGATOIRE → suppression unitaire confirmée | fichiers OPFS seulement | **e2e** (scénario F complet) | — |
| Import (G) | fichier → aperçu (contenu, volume, manifeste) → confirmer → RAPPORT (Ouvrir la discipline / Fermer) | tout (snapshot d'abord) | **e2e** | annulation d'un pack : couverte par le calcul à blanc (unit) + annulation de restauration (e2e) |
| Publication (H) | sources éditoriales opt-in → nom/auteur/conditions/vidéos → prévisualisation exacte (exclus dits) → .movpack + sortie honnête | aucune (lecture) | **e2e** (scénario H) + unit (périmètre) | version éditoriale absente du manifeste (8B) ; partage Android = Téléchargements (8D) |
| Sauvegarde (I) | « Sauvegarde complète de cette installation » (ou légère, qui le DIT) → fichier + sortie nom/taille/contenu | aucune (lecture) | **e2e** | — |
| Restauration (J) | .movpack complet → contenu affiché AVANT → confirmer / annuler — installation vierge seulement (refus explicite sinon) | tout (écrit à la confirmation) | **e2e** (aperçu, annulation, restauration, vérifications) | fusion de sauvegardes : non supportée, dit |
| Rollback (K) | snapshot motivé lisible → confirmation expliquant le remplacement et l'absence des vidéos → état courant re-snapshoté | bibliothèque (jamais les fichiers vidéo) | mécanisme : **unit stockage** · parcours : **recette Android** | octets vidéo hors snapshots (8C) |
| Démarrage (L) | Réglages → Bibliothèque / dernière / discipline choisie ; disparue → Bibliothèque + information discrète | préférences | **e2e** (scénario L complet) | — |

## 7bis. Sécurité et modes d'usage (lot 07) — ✅ livré

```mermaid
flowchart TD
    P[Appareil personnel — DÉFAUT] -->|aucune protection| M[Modification directe<br/>zéro PIN, zéro badge]
    T[Appareil partagé<br/>préréglage Tablette partagée] --> C[Consultation LIBRE :<br/>fiches · médias · recherche ·<br/>compositions · entraînement]
    T -->|action protégée| PIN[Panneau PIN contextuel<br/>la raison est dite]
    PIN -->|succès| S[Session curateur temporaire<br/>🔓 indicateur discret]
    S -->|inactivité 5-15 min ·<br/>Verrouiller · arrière-plan ·<br/>fermeture| T
    PIN -->|Annuler| C
```

- **Appareil personnel** (défaut produit) : tout libre, suppressions
  confirmées + snapshots — aucun PIN nulle part. — *démontré : e2e (tout
  le parcours sans protection traverse les 36 gardes librement)*
- **Activation** : explication → PIN (6-12 chiffres, évidents refusés,
  PBKDF2/SHA-256 · 310 000 itérations, jamais en clair) → confirmation ;
  deux protections indépendantes, un seul PIN ; préréglage « Tablette
  partagée ». — *démontré : e2e + unit*
- **Action protégée** : PIN au point d'action, reprise automatique,
  annulation sans perte ; sur une suppression, PIN AVANT la confirmation
  destructive qui reste due. — *démontré : e2e (scénarios B, C, D)*
- **Session curateur** : 5/15 min d'inactivité ou jusqu'à l'arrière-plan,
  indicateur discret + « Verrouiller maintenant », temporisation
  progressive des échecs. — *démontré : e2e + unit ; expiration réelle,
  arrière-plan, clavier numérique : recette Android*
- **Changer le PIN** : ancien vérifié, nouveau sel, ancien refusé ensuite,
  session fermée. — *démontré : e2e (scénario G)*
- **Exports sans secret** : les protections vivent dans les préférences
  d'appareil, jamais exportées — restaurer ailleurs = reconfigurer.
  — *démontré : unit*
- **Réinitialisation** : PIN si protégé → explication → sauvegarde
  proposée → confirmation renforcée → Bibliothèque vide, ni hash ni
  session. — *démontré : e2e (scénario L)*

## 8. Sauvegarde et restauration (I/J) — ✅ prouvé en e2e (R8)

```mermaid
sequenceDiagram
    participant U as Utilisateur
    participant A as App
    participant S as OPFS
    Note over U,S: Export complet (fondation produit, D-018.2)
    U->>A: Plus › Créer ou exporter un pack (sauvegarde complète)
    A->>S: lire bibliothèque + vidéos locales
    A-->>U: fichier .movpack (manifeste + JSON + vidéos)
    Note over U,S: Restauration sur installation vierge
    U->>A: Importer le .movpack
    A->>A: valider → rapprocher → restaurer vidéos
    A->>S: écrire (snapshot d'abord)
    A-->>U: aucune perte : identités, contributions,<br/>sources, médias, relations, taxonomies, compositions
```

**Sauvegarde complète vs partielle (lot 8C §20)** — « Sauvegarde complète »
seulement si les vidéos sont incluses ET aucune ne manque au stockage ; sinon
« Sauvegarde PARTIELLE » avec les exclusions nommées. Les réglages d'appareil
(thème, démarrage, protections/PIN) ne voyagent JAMAIS (D-065) — dit dans la
sortie ET le rapport de restauration (« à reconfigurer »).

**Transaction et interruption (lot 8C §17-19)** — toute écriture d'état passe
par un temporaire relu/revalidé puis basculé ; toute écriture média+métier
retire les fichiers neufs sur échec (aucun orphelin). Au démarrage, un commit
interrompu (`bibliotheque.json.tmp`) est écarté et `staging/` vidé.

```mermaid
sequenceDiagram
    participant U as Utilisateur
    participant A as App
    participant S as OPFS
    Note over U,S: Écriture média + métier (capture, ajout)
    U->>A: valider (fichier + contribution)
    A->>S: écrire le média NEUF (staging → videos/)
    A->>S: sauvegarder l'état (tmp → relire → valider → bascule)
    alt persistance OK
        A-->>U: enregistré ✓
    else échec
        A->>S: retirer le fichier NEUF + annuler la mutation
        A-->>U: refusé — capture conservée, aucun orphelin
    end
    Note over U,S: Au démarrage suivant
    A->>S: écarter un .tmp résiduel, vider staging/
    A-->>U: dernier état valide, aucune corruption
```

**Snapshot vs sauvegarde (lot 8C §22-23)** — un snapshot local
(`sauvegardes/`) est l'état métier SEUL (pas les octets vidéo, limite dite) ;
la suppression physique d'un média est différée à l'orphelin confirmé, donc
restaurer un snapshot ramène la contribution ET sa vidéo tant qu'elle n'a pas
été purgée. Une « sauvegarde complète » `.movpack` est le seul artefact
portable et intègre.

## 9. Hypothèses visibles sur cette carte

- ❓ **H1** : la capture sera-t-elle réellement faite — seule la recette
  tranche. (H2 « Reprendre » est résolue : le fil a disparu de l'UX, son
  code mort a été purgé — S3.A12/D-177 ; le non-rattaché vit dans
  Plus › À traiter.)
- ❓ La consultation d'une composition **pendant** l'entraînement (G) suffira-t-elle
  en lecture simple (pas de mode « lecteur » dédié) — à éprouver en recette.
- ❓ La nouvelle identité visuelle (encre/washi, accent vermillon, filets de
  provenance) est un choix autonome (D-021) — le jugement de désirabilité
  reste humain (D-009).
- ⏳ Différés tracés dans la matrice historique
  ([archives/increment-1.md](archives/increment-1.md) §6bis) et le backlog de
  durcissement ([execution/note-modele-donnees.md](execution/note-modele-donnees.md)
  §7bis) : historique des modifications, modifications d'ensemble depuis Plus,
  PWA installable, section « VAR » (vidéos d'analyse rattachées) — post-bêta.
