/**
 * Stockage — implémentation UNIQUE sur OPFS (contrat §3-4), la même sur web
 * et Android (WebView). Confirmé sur appareil réel par le spike S1
 * (2026-07-11 : écriture 141 Mo/s, lecture 458 Mo/s, persistance OK).
 *
 * Arborescence OPFS (lot 8A §7 — responsabilités séparées) :
 *   bibliotheque.json          état courant (source de vérité)
 *   preferences.json           réglages d'appareil (jamais exportés)
 *   videos/<ULID>.<ext>        médias définitifs (lot 8A §6) ; les fichiers
 *                              historiques restent nommés <ULID> nu et
 *                              restent lisibles (résolution compatible —
 *                              jamais de renommage en masse)
 *   staging/                   écritures temporaires : un fichier n'apparaît
 *                              dans videos/ qu'une fois complet ; vidé au
 *                              démarrage (un résidu = débris, jamais une donnée)
 *   sauvegardes/<ISO>.json     snapshots (1 par session de modification +
 *                              avant opération destructrice, rotation 10)
 *   images/<sha256>            couvertures (schéma 6, D-269) : le nom EST
 *                              l'empreinte du contenu, donc l'écriture est
 *                              idempotente et deux fiches qui montrent la
 *                              même image n'occupent qu'un fichier
 *   (aucun dossier de miniatures : rien n'est généré, les vignettes sont
 *   des rendus à la volée — lot 8A §9)
 */

import type { Bibliotheque, Image } from "../domaine/modele.ts";
import { AnnulationIngestion } from "../domaine/ingestion.ts";
import { migrerAvecImages, migrerBibliotheque, type ImageDetachee } from "../domaine/migrations.ts";
import { validerBibliotheque } from "../domaine/validation.ts";
import { sha256Hex } from "../domaine/sha256.ts";
import type { PuitsMediaFlux } from "../echange/movpack.ts";

const FICHIER_BIBLIOTHEQUE = "bibliotheque.json";
/** Commit en cours de l'état métier (lot 8C §18) : le nouvel état s'écrit ICI,
 *  se relit et se valide, PUIS bascule vers le fichier courant. Un résidu au
 *  démarrage = commit interrompu → écarté, le dernier état validé est conservé. */
const FICHIER_BIBLIOTHEQUE_TMP = "bibliotheque.json.tmp";
const FICHIER_PREFERENCES = "preferences.json";
const DOSSIER_VIDEOS = "videos";
/** Images des couvertures (schéma 6, D-269), nommées par leur EMPREINTE. Le
 *  nom dit le contenu : réécrire `images/<sha256>` avec les mêmes octets est
 *  sans effet, et aucune écriture ne peut en abîmer une autre. */
const DOSSIER_IMAGES = "images";
const DOSSIER_STAGING = "staging";
/** Sous-dossier de staging RÉSERVÉ à un import/restauration en flux (D-114) :
 *  les médias d'un conteneur y sont écrits et vérifiés AVANT confirmation ; ils
 *  ne rejoignent `videos/` qu'à la promotion. Un abandon (annulation ou échec
 *  d'intégrité) le vide entièrement — jamais un média à moitié importé parmi
 *  les définitifs. Nettoyé aussi au démarrage (sous `staging/`). */
const DOSSIER_IMPORT = "import";
const DOSSIER_SAUVEGARDES = "sauvegardes";
const ROTATION_SAUVEGARDES = 10;

/** Nom physique d'une vidéo (lot 8A §6) : `<mediaId>.<extension-canonique>`
 *  quand l'extension est connue, l'id nu sinon — JAMAIS dérivé du nom de la
 *  technique, du pack ou du fichier d'origine (ces valeurs changent ; le nom
 *  original vit dans les métadonnées du média). Sûr sur toute plateforme :
 *  ULID + point + extension ASCII. */
export function nomPhysiqueVideo(id: string, extension?: string): string {
  return extension ? `${id}.${extension}` : id;
}

/** Id logique ← nom physique — un ULID ne contient jamais de point. */
function idDepuisNom(nom: string): string {
  const point = nom.indexOf(".");
  return point === -1 ? nom : nom.slice(0, point);
}

/**
 * Préférences de l'appareil (D-020.4) — hors bibliothèque : elles ne voyagent
 * jamais dans un pack ni un export (c'est l'appareil qui choisit, pas le savoir).
 */
export interface Preferences {
  version: 1;
  /** Comportement de démarrage (lot 1 §3) : la Bibliothèque par défaut,
   *  la dernière discipline consultée, ou une discipline choisie. */
  demarrage: { mode: "bibliotheque" | "compositions" | "relations" | "derniere" | "discipline"; disciplineId?: string };
  derniereDisciplineId?: string;
  /** Apparence (D-025) : thème et tonalité d'accent — choix d'appareil. */
  theme?: "auto" | "clair" | "sombre";
  tonalite?: "vermillon" | "indigo" | "foret" | "ocre" | "prune" | "acier";
  /** Pseudo local (D-072) : signe le contenu créé sur cet appareil (« Mon
   *  contenu » → le pseudo). Réglage d'appareil — jamais exporté. */
  pseudo?: string;
  /** Mode avancé (D-084) : révèle les outils de curation/maintenance (doublons,
   *  relations, médias, diagnostic) — masqués par défaut pour garder la surface
   *  du pratiquant sobre. Réglage d'appareil, off par défaut. */
  modeAvance?: boolean;
  /** Vignettes distantes (S4.3/D-260) : quand une fiche n'a pas d'illustration
   *  locale, on PEUT afficher la miniature fournie par YouTube — ce qui
   *  suppose de contacter un tiers SANS que l'utilisateur l'ait demandé.
   *  **Off par défaut** : la promesse « rien ne part sans geste » prime sur
   *  la richesse visuelle. Réglage d'appareil, jamais exporté. */
  vignettesDistantes?: boolean;
  /** Vue relation en bêta (D-084) : quand active, le bouton « Voir en graphe »
   *  apparaît sur les fiches. Remplace l'ancien onglet permanent. Off par défaut. */
  vueRelationBeta?: boolean;
  /** Compositions en bêta (D-223) : quand actif, l'onglet Compositions et ses
   *  points d'entrée apparaissent. Off par défaut — la CAPACITÉ reste entière
   *  (données, packs, sauvegardes), seule la visibilité est optionnelle. */
  compositionsBeta?: boolean;
  /** Écran Relations (D-137) — réglage d'APPAREIL, jamais exporté : dernière
   *  technique centrale et dernier mode de lecture, restaurés entre sessions.
   *  Absents = aucun contexte mémorisé (l'écran propose un point de départ). */
  relationsCentreId?: string;
  relationsVue?: "liste" | "mindmap"; // D-373 : ids retirés repliés a la lecture
  /** Densité de la grille Bibliothèque (D-087) : nombre de colonnes choisi
   *  (1 à 4). Absent = grille responsive par défaut. Réglage d'appareil. */
  densiteBibliotheque?: number;
  /** Limite d'espace volontaire pour les vidéos locales (D-097), en Mo.
   *  Absent = défaut 5 Go. `0` = illimité (plafonné seulement par le quota
   *  système). Réglage d'appareil, jamais exporté. */
  limiteEspaceMo?: number;
  /** Transition de préparation avant un pas minuté dans le pas-à-pas (D-125),
   *  en secondes. Absent = défaut 3 s ; `0` = aucune. Réglage d'appareil. */
  transitionSec?: number;
  /** Retour sonore du pas-à-pas (D-125) : voix + bips (défaut), voix seule,
   *  bips seuls, ou muet. Réglage d'appareil. */
  sonSeance?: "les-deux" | "voix" | "bips" | "muet";
  /** Dernière position de lecture (UI-6, D-324) — **UNE** entrée, écrite par le
   *  lecteur sans geste de l'utilisateur. Vivant ici, elle ne voyage ni dans un
   *  pack ni dans une sauvegarde (D-020.4) : on ne restaure pas une position, on
   *  reprend la séance. Cycle complet dans D-324. */
  derniereLecture?: { compositionId: string; index: number; quand: string };
  /** Protections facultatives (lot 7) — réglage d'APPAREIL : jamais
   *  exporté (les préférences ne voyagent dans aucune sauvegarde), le PIN
   *  n'existe que dérivé (sel + empreinte PBKDF2, src/securite/pin.ts). */
  protections?: {
    modifications: boolean;
    suppressions: boolean;
    /** Durée de la session curateur (§8) — 5 min par défaut. */
    verrouillage?: "5min" | "15min" | "arriere-plan";
    verification?: import("../securite/pin.ts").VerificationPin;
  };
}

export function preferencesDefaut(): Preferences {
  return { version: 1, demarrage: { mode: "bibliotheque" } };
}

/** Migration des préférences (lot 1 §2-3) — pure, testable en Node.
 *  « accueil » et « favoris » (D-336) visent des écrans SUPPRIMÉS : y pointer
 *  ouvrirait l'app sur du vide. Inconnu ou illisible → défauts. */
export function migrerPreferences(brut: unknown): Preferences {
  if (typeof brut !== "object" || brut === null) return preferencesDefaut();
  const p = brut as Preferences & { demarrage?: { mode?: string } };
  if (p.version !== 1 || !p.demarrage?.mode) return preferencesDefaut();
  if (["accueil", "favoris"].includes(p.demarrage.mode as string)) return { ...p, demarrage: { mode: "bibliotheque" } };
  return p;
}

async function racine(): Promise<FileSystemDirectoryHandle> {
  return navigator.storage.getDirectory();
}

async function lireTexte(nom: string): Promise<string | null> {
  try {
    const h = await (await racine()).getFileHandle(nom);
    return await (await h.getFile()).text();
  } catch {
    return null; // absent
  }
}

async function ecrireTexte(nom: string, contenu: string): Promise<void> {
  const h = await (await racine()).getFileHandle(nom, { create: true });
  const w = await h.createWritable();
  await w.write(contenu);
  await w.close();
}

/** Écrit les images qui manquent, et SEULEMENT celles-là (D-269).
 *
 *  L'opération est idempotente par construction : le nom du fichier est
 *  l'empreinte de son contenu, donc une image déjà posée n'a rien à recevoir,
 *  et deux écritures de la même image ne peuvent pas diverger. C'est ce qui
 *  permet de les poser AVANT la bascule de `bibliotheque.json` sans transaction
 *  à plusieurs fichiers : une interruption laisse au pire des octets en trop,
 *  jamais un état incohérent — l'inventaire, lui, ne bascule qu'avec l'état.
 *
 *  Rend les images qui n'ont PAS pu être écrites : l'appelant décide (une
 *  vignette manquante se dégrade, elle ne bloque pas). */
async function poserImages(images: readonly ImageDetachee[]): Promise<ImageDetachee[]> {
  if (!images.length) return [];
  const dossier = await (await racine()).getDirectoryHandle(DOSSIER_IMAGES, { create: true });
  const presentes = new Set<string>();
  for await (const [n] of dossier as unknown as AsyncIterable<[string, FileSystemHandle]>) presentes.add(n);
  const echecs: ImageDetachee[] = [];
  for (const image of images) {
    // DERNIÈRE LIGNE (D-271) : ici, le nom du fichier devient l'identité du
    // contenu pour toute la suite — l'inventaire, les couvertures, la
    // déduplication. Le stockage ne fait donc pas confiance à son appelant :
    // il recalcule. Écrire des octets sous le nom d'une AUTRE image
    // empêcherait à jamais la vraie d'être écrite (l'écriture est
    // idempotente : le nom existe déjà).
    if (sha256Hex(image.octets) !== image.id) {
      echecs.push(image);
      continue;
    }
    if (presentes.has(image.id)) continue;
    try {
      const h = await dossier.getFileHandle(image.id, { create: true });
      const w = await h.createWritable();
      await w.write(image.octets as unknown as BufferSource);
      await w.close();
    } catch {
      echecs.push(image);
    }
  }
  return echecs;
}

async function supprimerFichier(nom: string): Promise<void> {
  try {
    await (await racine()).removeEntry(nom);
  } catch {
    /* déjà absent */
  }
}

export class StockageOpfs {
  #sauvegardeFaiteCetteSession = false;
  /** File d'attente des sauvegardes (lot 8C §18/§concurrence) : deux
   *  persistances ne s'entrelacent JAMAIS — sinon elles se disputeraient le
   *  temporaire de bascule. Sérialiser rend aussi sûrs les appels concurrents. */
  #chaineSauvegarde: Promise<unknown> = Promise.resolve();

  /** Charge, migre et valide la bibliothèque. `null` si aucune (premier lancement).
   *  Reprend d'abord une transaction inachevée (§18) : un `bibliotheque.json.tmp`
   *  résiduel est un commit interrompu → écarté, le dernier état COURANT validé
   *  reste la vérité (jamais de bascule vers un état à moitié écrit). */
  async charger(): Promise<Bibliotheque | null> {
    await this.reprendreTransactionInachevee();
    const texte = await lireTexte(FICHIER_BIBLIOTHEQUE);
    if (texte === null) return null;
    const { bibliotheque, imagesDetachees } = migrerAvecImages(JSON.parse(texte));
    validerBibliotheque(bibliotheque);
    // Passage au schéma 6 (D-269) : la migration a sorti les images du JSON
    // mais n'écrit rien — le domaine est pur. On pose les fichiers PUIS on
    // persiste, dans cet ordre : l'inventaire ne devient la vérité sur disque
    // qu'une fois les octets là. Un échec ici n'empêche pas d'ouvrir
    // l'application — l'état reste en schéma 5 sur le disque et la prochaine
    // ouverture réessaiera ; au pire une vignette manque.
    if (imagesDetachees.length) {
      try {
        await poserImages(imagesDetachees);
        await this.sauvegarder(bibliotheque);
      } catch {
        // Migration non persistée (disque plein, permission perdue…) :
        // l'application s'ouvre quand même sur l'état migré EN MÉMOIRE, le
        // disque reste en schéma 5, et la prochaine ouverture réessaiera.
        // Se réparer tout seul vaut mieux qu'un démarrage refusé.
      }
    }
    return bibliotheque;
  }

  /** Octets d'une image de couverture (D-269), `null` si le fichier manque —
   *  une vignette absente se dégrade, elle ne casse rien. */
  async lireImage(id: string): Promise<Blob | null> {
    try {
      const dossier = await (await racine()).getDirectoryHandle(DOSSIER_IMAGES);
      return await (await dossier.getFileHandle(id)).getFile();
    } catch {
      return null;
    }
  }

  /** Pose les octets d'images reçus d'un conteneur (D-269). Idempotent : une
   *  image déjà présente n'est pas réécrite. Rend le nombre d'images qui n'ont
   *  PAS pu être écrites — l'appelant décide, une vignette absente se
   *  dégradant sans rien casser. */
  async poserImagesRecues(images: readonly ImageDetachee[]): Promise<number> {
    return (await poserImages(images)).length;
  }

  /** Écrit une image et rend son entrée d'inventaire — le SEUL chemin par
   *  lequel une image entre dans la bibliothèque (couverture choisie par
   *  l'utilisateur, pack importé). L'empreinte est calculée ici : personne
   *  n'a à la fournir, donc personne ne peut la fournir fausse. */
  async ajouterImage(octets: Uint8Array, mime: string): Promise<Image> {
    const image: Image = { id: sha256Hex(octets), mime, taille: octets.length };
    const echecs = await poserImages([{ ...image, octets }]);
    if (echecs.length) throw new Error("Impossible d'enregistrer l'image (espace insuffisant ?)");
    return image;
  }

  /** Octets des images déclarées par une bibliothèque, pour un export
   *  (D-269). Une image dont le fichier manque est simplement absente : c'est
   *  l'écrivain du conteneur qui refusera, avec un message qui nomme le
   *  problème — ici on ne fabrique rien. */
  async octetsImages(b: Bibliotheque): Promise<Map<string, Uint8Array>> {
    const octets = new Map<string, Uint8Array>();
    for (const i of b.images ?? []) {
      const blob = await this.lireImage(i.id);
      if (blob) octets.set(i.id, new Uint8Array(await blob.arrayBuffer()));
    }
    return octets;
  }

  /** Supprime les fichiers image que plus aucune image de l'inventaire ne
   *  déclare. Balayage SÉPARÉ de la sauvegarde, et c'est voulu : perdre une
   *  image encore utilisée est irréversible, alors qu'un fichier en trop ne
   *  coûte que de la place. Rend le nombre de fichiers retirés. */
  async balayerImagesOrphelines(b: Bibliotheque): Promise<number> {
    const declarees = new Set((b.images ?? []).map((i) => i.id));
    let retires = 0;
    try {
      const dossier = await (await racine()).getDirectoryHandle(DOSSIER_IMAGES);
      const noms: string[] = [];
      for await (const [n] of dossier as unknown as AsyncIterable<[string, FileSystemHandle]>) noms.push(n);
      for (const nom of noms) {
        if (declarees.has(nom)) continue;
        await dossier.removeEntry(nom);
        retires++;
      }
    } catch {
      /* pas de dossier images : rien à balayer */
    }
    return retires;
  }

  /** Écarte un commit d'état interrompu (§18/§19, scénario E) — le temporaire
   *  n'a jamais basculé, le fichier courant est le dernier état valide. Retourne
   *  `true` si un résidu a été nettoyé (diagnostic). */
  async reprendreTransactionInachevee(): Promise<boolean> {
    const enCours = await lireTexte(FICHIER_BIBLIOTHEQUE_TMP);
    if (enCours === null) return false;
    await supprimerFichier(FICHIER_BIBLIOTHEQUE_TMP);
    return true;
  }

  /** Valide puis persiste par BASCULE PROTÉGÉE (§18) : le nouvel état s'écrit
   *  dans un temporaire, se RELIT et se REVALIDE, PUIS seulement remplace le
   *  fichier courant — jamais d'écrasement direct non vérifié. Une erreur avant
   *  la bascule laisse l'état courant intact (le service remonte l'exception et
   *  restaure sa copie mémoire). Première mutation de la session → snapshot
   *  d'abord (contrat §4). */
  async sauvegarder(b: Bibliotheque): Promise<void> {
    validerBibliotheque(b); // jamais d'écriture d'un état invalide (avant la file : échoue tôt)
    // Sérialisation : on attend la sauvegarde précédente avant de toucher le
    // temporaire de bascule (jamais deux écritures concurrentes sur le .tmp).
    const precedent = this.#chaineSauvegarde;
    const aNous = (async () => {
      await precedent.catch(() => {}); // l'échec d'une précédente ne bloque pas la suivante
      if (!this.#sauvegardeFaiteCetteSession) {
        await this.snapshot("debut-de-session");
        this.#sauvegardeFaiteCetteSession = true;
      }
      const texte = JSON.stringify(b);
      await ecrireTexte(FICHIER_BIBLIOTHEQUE_TMP, texte);
      const relu = await lireTexte(FICHIER_BIBLIOTHEQUE_TMP);
      if (relu !== texte) throw new Error("Écriture d'état incohérente — bascule annulée, état courant conservé");
      validerBibliotheque(migrerBibliotheque(JSON.parse(relu))); // le temporaire relu est un état valide
      await ecrireTexte(FICHIER_BIBLIOTHEQUE, relu); // bascule dans `sauvegarder` — SEUL écrivain (createWritable OPFS : swap atomique au close)
      await supprimerFichier(FICHIER_BIBLIOTHEQUE_TMP);
    })();
    this.#chaineSauvegarde = aNous;
    await aNous;
  }

  /** Préférences d'appareil : lecture tolérante — un fichier illisible vaut
   *  défauts ; une ancienne préférence « accueil » est migrée et réécrite. */
  async chargerPreferences(): Promise<Preferences> {
    const texte = await lireTexte(FICHIER_PREFERENCES);
    if (texte === null) return preferencesDefaut();
    try {
      const brut = JSON.parse(texte) as { demarrage?: { mode?: string } };
      const p = migrerPreferences(brut);
      if (brut?.demarrage?.mode === "accueil") await this.sauvegarderPreferences(p); // migration persistée
      return p;
    } catch {
      return preferencesDefaut();
    }
  }

  async sauvegarderPreferences(p: Preferences): Promise<void> {
    await ecrireTexte(FICHIER_PREFERENCES, JSON.stringify(p));
  }

  /** Snapshot explicite, MOTIVÉ (D-023 : un rollback se choisit en sachant
   *  ce qu'il annule) — le motif vit dans le nom du fichier. */
  async snapshot(motif = "session"): Promise<void> {
    const texte = await lireTexte(FICHIER_BIBLIOTHEQUE);
    if (texte === null) return; // rien à sauvegarder
    const dossier = await (await racine()).getDirectoryHandle(DOSSIER_SAUVEGARDES, { create: true });
    const slug = motif.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").slice(0, 40);
    const nom = new Date().toISOString().replaceAll(":", "-") + "__" + slug + ".json";
    const h = await dossier.getFileHandle(nom, { create: true });
    const w = await h.createWritable();
    await w.write(texte);
    await w.close();
    // rotation
    const noms: string[] = [];
    for await (const [n] of dossier as unknown as AsyncIterable<[string, FileSystemHandle]>) noms.push(n);
    for (const n of noms.sort().slice(0, Math.max(0, noms.length - ROTATION_SAUVEGARDES))) {
      await dossier.removeEntry(n);
    }
  }

  async listerSauvegardes(): Promise<string[]> {
    try {
      const dossier = await (await racine()).getDirectoryHandle(DOSSIER_SAUVEGARDES);
      const noms: string[] = [];
      for await (const [n] of dossier as unknown as AsyncIterable<[string, FileSystemHandle]>) noms.push(n);
      return noms.sort().reverse();
    } catch {
      return [];
    }
  }

  /** Restaure un snapshot : l'état COURANT est d'abord snapshoté (réversible),
   *  le snapshot restauré est migré et validé avant toute écriture.
   *
   *  L'écriture passe par `sauvegarder` (S4.4/D-258) et non plus par un
   *  `ecrireTexte` direct : c'était le SEUL chemin d'écriture de la
   *  bibliothèque sans la bascule protégée (temporaire → relecture →
   *  revalidation) ni la file de sérialisation — et il s'exerce précisément
   *  quand l'utilisateur récupère après un problème, donc au pire moment pour
   *  écraser l'état courant par une écriture partielle. */
  async restaurerSauvegarde(nom: string): Promise<Bibliotheque> {
    const dossier = await (await racine()).getDirectoryHandle(DOSSIER_SAUVEGARDES);
    const texte = await (await (await dossier.getFileHandle(nom)).getFile()).text();
    const b = migrerBibliotheque(JSON.parse(texte));
    validerBibliotheque(b);
    await this.snapshot("avant-restauration");
    await this.sauvegarder(b);
    return b;
  }

  /** Résout le fichier d'un média : id nu (fichier historique) OU
   *  `<id>.<ext>` (§6) — résolution compatible ancien/nouvel emplacement,
   *  jamais de renommage en masse. */
  async #fichierVideo(id: string): Promise<FileSystemFileHandle | null> {
    try {
      const dossier = await (await racine()).getDirectoryHandle(DOSSIER_VIDEOS);
      try {
        return await dossier.getFileHandle(id); // historique : id nu
      } catch {
        for await (const [n, h] of dossier as unknown as AsyncIterable<[string, FileSystemHandle]>)
          if (h.kind === "file" && n.startsWith(id + ".")) return h as FileSystemFileHandle;
        return null;
      }
    } catch {
      return null; // dossier absent
    }
  }

  /** Écrit une vidéo en flux (jamais de base64 — dette V2 exclue), via la
   *  zone temporaire `staging/` (§7) : le fichier n'apparaît dans `videos/`
   *  qu'une fois COMPLET — une interruption ne laisse jamais un fichier
   *  partiel parmi les définitifs, seulement un débris de staging nettoyé
   *  au démarrage. */
  async ecrireVideo(
    id: string,
    contenu: Blob,
    extension?: string,
    onProgress?: (fraction: number) => void,
    estAnnule?: () => boolean,
  ): Promise<void> {
    const nom = nomPhysiqueVideo(id, extension);
    const staging = await (await racine()).getDirectoryHandle(DOSSIER_STAGING, { create: true });
    const brouillon = await staging.getFileHandle(nom, { create: true });
    const w = await brouillon.createWritable();
    // Progression (D-098) : on compte les octets qui passent, rapportés au
    // total. Annulation (S2.4) : vérifiée entre les blocs — l'abandon jette
    // le brouillon de staging, rien de définitif n'existe encore.
    const total = contenu.size;
    let fait = 0;
    const flux =
      (onProgress && total > 0) || estAnnule
        ? contenu.stream().pipeThrough(
            new TransformStream<Uint8Array, Uint8Array>({
              transform(chunk, ctrl) {
                if (estAnnule?.()) throw new AnnulationIngestion();
                fait += chunk.byteLength;
                if (onProgress && total > 0) onProgress(Math.min(1, fait / total));
                ctrl.enqueue(chunk);
              },
            }),
          )
        : contenu.stream();
    try {
      await flux.pipeTo(w);
    } catch (e) {
      try { await w.abort(); } catch { /* déjà clos */ }
      try { await staging.removeEntry(nom); } catch { /* déjà absent */ }
      throw e;
    }
    if (onProgress) onProgress(1);
    const videos = await (await racine()).getDirectoryHandle(DOSSIER_VIDEOS, { create: true });
    try {
      // déplacement quasi instantané (moteurs récents, dont la WebView à jour)
      await (brouillon as FileSystemFileHandle & { move(d: FileSystemDirectoryHandle): Promise<void> }).move(videos);
    } catch {
      // repli WebView plus ancienne : copie puis retrait du temporaire
      const final = await videos.getFileHandle(nom, { create: true });
      const wf = await final.createWritable();
      await (await brouillon.getFile()).stream().pipeTo(wf);
      await staging.removeEntry(nom);
    }
  }

  async #dossierImport(create = false): Promise<FileSystemDirectoryHandle> {
    const staging = await (await racine()).getDirectoryHandle(DOSSIER_STAGING, { create });
    return staging.getDirectoryHandle(DOSSIER_IMPORT, { create });
  }

  /** Puits d'écriture d'un import/restauration EN FLUX (D-114) — branché sur
   *  `staging/import/`. Chaque média y est écrit au fil de l'eau ; rien
   *  n'apparaît dans `videos/` avant la promotion (confirmation humaine). Un
   *  abandon vide tout le sous-dossier — jamais un média partiel définitif. */
  puitsImport(): PuitsMediaFlux {
    const self = this;
    let writable: FileSystemWritableFileStream | null = null;
    return {
      async ouvrir(nomPhysique: string): Promise<void> {
        const dir = await self.#dossierImport(true);
        const h = await dir.getFileHandle(nomPhysique, { create: true });
        writable = await h.createWritable();
      },
      async ecrire(bloc: Uint8Array): Promise<void> {
        await writable!.write(bloc as BufferSource);
      },
      async fermer(): Promise<void> {
        await writable!.close();
        writable = null;
      },
      async abandonner(): Promise<void> {
        try {
          if (writable) await writable.close();
        } catch {
          /* déjà clos */
        }
        writable = null;
        await self.nettoyerImport();
      },
    };
  }

  /** Promeut les médias importés (staging → `videos/`). IDEMPOTENT (D-114) :
   *  si le média est DÉJÀ dans `videos/` (réimport du même pack → même id, donc
   *  même contenu déjà vérifié à la lecture), on **ne l'écrase pas** — on jette
   *  simplement la copie de staging. Sinon on déplace (repli copie sur WebView
   *  sans `move`). On ne dépend jamais d'un `move` par-dessus un fichier existant
   *  (sémantique variable selon la WebView Android). Un nom absent est ignoré.
   *  Retourne les noms RÉELLEMENT déplacés (S1.5/D-166) — la matière exacte
   *  d'un rollback si la persistance qui suit échoue. */
  async promouvoirImportMedias(nomsPhysiques: string[]): Promise<string[]> {
    if (nomsPhysiques.length === 0) return [];
    const deplaces: string[] = [];
    const dir = await this.#dossierImport(false);
    const videos = await (await racine()).getDirectoryHandle(DOSSIER_VIDEOS, { create: true });
    for (const nom of nomsPhysiques) {
      let h: FileSystemFileHandle;
      try {
        h = await dir.getFileHandle(nom);
      } catch {
        continue; // absent : rien à promouvoir
      }
      let dejaPresent = false;
      try {
        await videos.getFileHandle(nom);
        dejaPresent = true; // même nom physique = même id+extension = même contenu (§14)
      } catch {
        /* absent de videos/ : à déplacer */
      }
      if (dejaPresent) {
        try {
          await dir.removeEntry(nom);
        } catch {
          /* déjà retiré */
        }
        continue;
      }
      try {
        await (h as FileSystemFileHandle & { move(d: FileSystemDirectoryHandle): Promise<void> }).move(videos);
      } catch {
        const final = await videos.getFileHandle(nom, { create: true });
        const wf = await final.createWritable();
        await (await h.getFile()).stream().pipeTo(wf);
        try {
          await dir.removeEntry(nom);
        } catch {
          /* déjà retiré */
        }
      }
      deplaces.push(nom);
    }
    return deplaces;
  }

  /** ROLLBACK d'une promotion (S1.5/D-166) : re-déplace vers `staging/import/`
   *  les fichiers qu'une promotion venait de mettre dans `videos/`, quand la
   *  persistance qui suivait a échoué — l'état revient à « proposition en
   *  attente », rien de définitif, aucun orphelin. Best-effort symétrique :
   *  un fichier déjà reparti n'arrête pas les autres. */
  async annulerPromotionMedias(nomsDeplaces: string[]): Promise<void> {
    if (nomsDeplaces.length === 0) return;
    const dir = await this.#dossierImport(true);
    const videos = await (await racine()).getDirectoryHandle(DOSSIER_VIDEOS, { create: true });
    for (const nom of nomsDeplaces) {
      let h: FileSystemFileHandle;
      try {
        h = await videos.getFileHandle(nom);
      } catch {
        continue; // déjà reparti / jamais arrivé
      }
      try {
        await (h as FileSystemFileHandle & { move(d: FileSystemDirectoryHandle): Promise<void> }).move(dir);
      } catch {
        try {
          const retour = await dir.getFileHandle(nom, { create: true });
          const wf = await retour.createWritable();
          await (await h.getFile()).stream().pipeTo(wf);
          await videos.removeEntry(nom);
        } catch {
          /* best-effort : au pire le balayage d'orphelins du démarrage le signalera */
        }
      }
    }
  }

  /** Vide la zone d'import (après promotion, annulation ou échec). */
  async nettoyerImport(): Promise<void> {
    try {
      const staging = await (await racine()).getDirectoryHandle(DOSSIER_STAGING);
      await staging.removeEntry(DOSSIER_IMPORT, { recursive: true });
    } catch {
      /* absent */
    }
  }

  /** Lit un média LOCAL par blocs de taille fixe (lot 8B §15) — chaque
   *  tranche `Blob.slice(...).arrayBuffer()` ne charge QUE ce bloc en
   *  mémoire, jamais le fichier entier. Rien si le média est absent. */
  async *lireMediaParBlocs(id: string, tailleBloc: number): AsyncGenerator<Uint8Array> {
    const h = await this.#fichierVideo(id);
    if (!h) return;
    const fichier = await h.getFile();
    for (let pos = 0; pos < fichier.size; pos += tailleBloc) {
      const tranche = fichier.slice(pos, Math.min(pos + tailleBloc, fichier.size));
      yield new Uint8Array(await tranche.arrayBuffer());
    }
  }

  /** Ouvre une archive temporaire en écriture PROGRESSIVE (lot 8B §15/§18) :
   *  OPFS n'expose le fichier qu'au `close()` (écriture dans un swap) — aucun
   *  fichier final visible avant finalisation, aucun `.movpack` partiel
   *  présenté comme valide. Vit dans `staging/`, nettoyée au démarrage.
   *  Rejette si OPFS/`createWritable` est indisponible (refus borné, §10). */
  async ouvrirArchiveTemp(nom: string): Promise<FileSystemWritableFileStream> {
    const staging = await (await racine()).getDirectoryHandle(DOSSIER_STAGING, { create: true });
    const h = await staging.getFileHandle(nom, { create: true });
    return h.createWritable();
  }

  /** Le fichier temporaire finalisé, adossé au disque (jamais copié dans le
   *  tas JS) — sert d'objet de téléchargement. */
  async fichierArchiveTemp(nom: string): Promise<File> {
    const staging = await (await racine()).getDirectoryHandle(DOSSIER_STAGING);
    return (await staging.getFileHandle(nom)).getFile();
  }

  async supprimerArchiveTemp(nom: string): Promise<void> {
    try {
      const staging = await (await racine()).getDirectoryHandle(DOSSIER_STAGING);
      await staging.removeEntry(nom);
    } catch {
      /* déjà absent */
    }
  }

  /** Balaie les archives d'export temporaires laissées par une session
   *  précédente (nettoyage après succès/annulation, appelé avant chaque
   *  nouvel export) — les vidéos en cours d'ingestion (autres noms) restent
   *  intactes. */
  async nettoyerArchivesTemp(): Promise<void> {
    try {
      const staging = await (await racine()).getDirectoryHandle(DOSSIER_STAGING);
      const noms: string[] = [];
      for await (const [n] of staging as unknown as AsyncIterable<[string, FileSystemHandle]>)
        if (n.startsWith("export-") && n.endsWith(".movpack")) noms.push(n);
      for (const n of noms) await staging.removeEntry(n);
    } catch {
      /* staging absent */
    }
  }

  /** Vide la zone temporaire (appelé au démarrage) : un résidu de staging
   *  est un débris d'écriture interrompue — jamais une donnée. */
  async nettoyerStaging(): Promise<void> {
    try {
      await (await racine()).removeEntry(DOSSIER_STAGING, { recursive: true });
    } catch {
      /* absent */
    }
  }

  /** Estimation honnête de l'espace (§10) : `null` quand le navigateur ne
   *  sait pas répondre — jamais une garantie inventée. */
  async estimerEspace(): Promise<{ usage: number; quota: number } | null> {
    try {
      const e = await navigator.storage.estimate();
      if (typeof e.usage !== "number" || typeof e.quota !== "number") return null;
      return { usage: e.usage, quota: e.quota };
    } catch {
      return null;
    }
  }

  /** État de persistance du stockage (S1.9) : lit `persisted()` et, sur
   *  demande, sollicite `persist()`. Répond honnêtement `null` quand le
   *  navigateur ne sait pas dire (API absente) — jamais bloquant, jamais
   *  une garantie inventée. */
  async persistanceStockage(demander = false): Promise<boolean | null> {
    try {
      if (!navigator.storage?.persisted) return null;
      if (await navigator.storage.persisted()) return true;
      if (demander && navigator.storage.persist) return await navigator.storage.persist();
      return false;
    } catch {
      return null;
    }
  }

  /** Le fichier PHYSIQUE d'une vidéo (S2.12 : rattachement d'un orphelin
   *  retrouvé) — null si absent ; le nom porte l'extension canonique. */
  async fichierVideo(id: string): Promise<File | null> {
    const h = await this.#fichierVideo(id);
    if (!h) return null;
    try {
      return await h.getFile();
    } catch {
      return null;
    }
  }

  /** Le File OPFS est adossé au disque : l'URL objet se lit en continu sans charger en mémoire. */
  async urlVideo(id: string): Promise<string | null> {
    const h = await this.#fichierVideo(id);
    if (!h) return null; // vidéo manquante : affichage dégradé, jamais bloquant
    try {
      return URL.createObjectURL(await h.getFile());
    } catch {
      return null;
    }
  }

  /** Contenu d'une vidéo locale (pour l'export .movpack). `null` si absente. */
  async lireVideo(id: string): Promise<Uint8Array | null> {
    const h = await this.#fichierVideo(id);
    if (!h) return null;
    try {
      return new Uint8Array(await (await h.getFile()).arrayBuffer());
    } catch {
      return null;
    }
  }

  /** Ids LOGIQUES des vidéos réellement présentes (diagnostic des médias
   *  manquants) — le nom physique porte l'extension, l'id jamais (§6). */
  async listerVideos(): Promise<Set<string>> {
    try {
      const dossier = await (await racine()).getDirectoryHandle(DOSSIER_VIDEOS);
      const ids = new Set<string>();
      for await (const [n] of dossier as unknown as AsyncIterable<[string, FileSystemHandle]>) ids.add(idDepuisNom(n));
      return ids;
    } catch {
      return new Set();
    }
  }

  /** Tailles des vidéos présentes (médiathèque, lot 6 §14) — lecture seule,
   *  indexée par id LOGIQUE. */
  async taillesVideos(): Promise<Map<string, number>> {
    const tailles = new Map<string, number>();
    try {
      const dossier = await (await racine()).getDirectoryHandle(DOSSIER_VIDEOS);
      for await (const [n, h] of dossier as unknown as AsyncIterable<[string, FileSystemHandle]>) {
        if (h.kind === "file") tailles.set(idDepuisNom(n), (await (h as FileSystemFileHandle).getFile()).size);
      }
    } catch {
      /* dossier absent : aucune vidéo */
    }
    return tailles;
  }

  async supprimerVideo(id: string): Promise<void> {
    const h = await this.#fichierVideo(id); // nom historique OU <id>.<ext>
    if (!h) return; // déjà absente
    try {
      const dossier = await (await racine()).getDirectoryHandle(DOSSIER_VIDEOS);
      await dossier.removeEntry(h.name);
    } catch {
      /* déjà absente */
    }
  }

  /** Remise à zéro COMPLÈTE (lot 7 §22) : bibliothèque, vidéos, snapshots,
   *  préférences — réglages de sécurité compris. Rien ne survit. */
  async reinitialiser(): Promise<void> {
    const dossier = await racine();
    for (const nom of [FICHIER_BIBLIOTHEQUE, FICHIER_BIBLIOTHEQUE_TMP, FICHIER_PREFERENCES]) {
      try {
        await dossier.removeEntry(nom);
      } catch {
        /* déjà absent */
      }
    }
    // AUDIT 2026-08-13, P1-1 : `images/` manquait à cette liste. La promesse de
    // l'écran est « Tout sera supprimé de cet appareil » — et les couvertures
    // importées ou choisies survivaient en octets orphelins. Une CATÉGORIE DE
    // STOCKAGE NOUVELLE (schéma 6, D-269) n'avait pas été rattachée à la
    // primitive qui efface tout : les gardes étaient vertes, la promesse fausse.
    for (const nom of [DOSSIER_VIDEOS, DOSSIER_IMAGES, DOSSIER_STAGING, DOSSIER_SAUVEGARDES]) {
      try {
        await dossier.removeEntry(nom, { recursive: true });
      } catch {
        /* déjà absent */
      }
    }
  }
}
