/**
 * ÉCRAN « AIDE » (D-308 pour la scission, D-310 pour le contenu) — utiliser
 * l'application, du premier démarrage à la sécurité de la pratique.
 *
 * Rédigé sur la maquette du porteur, mais chaque affirmation a été VÉRIFIÉE
 * dans le code avant d'être écrite : la maquette annonçait une version Windows
 * portable (absente en V3, §35 de `docs/systeme.md`) et un « accès admin »
 * (il n'existe pas de rôle — seulement deux protections PIN facultatives,
 * `src/securite/politique.ts`). Une aide qui décrit un produit imaginaire coûte
 * plus cher que pas d'aide du tout.
 */

import { html, nothing, type TemplateResult } from "lit";
import { RELATIONS_VISUELLES } from "./fonctionnalites.ts";
import type { MovensoApp } from "./racine.ts";

/** Un volet d'aide (D-310) : titre, éventuel repère « PIN », contenu replié.
 *  Même mécanique que les volets de l'Atelier — un seul modèle de repliable
 *  dans tout Plus. */
function voletAide(titre: string, pin: boolean, contenu: unknown): TemplateResult {
  return html`
    <details class="carte-atelier sous-volet">
      <summary class="encart-entete">
        <span class="titre-atelier">${titre}</span>
        ${pin ? html`<span class="aide-repere-pin">PIN</span>` : nothing}
        <span class="chevron" aria-hidden="true">▸</span>
      </summary>
      <div class="aide-volet-corps">${contenu}</div>
    </details>
  `;
}

/** Sous-écran « Aide » (D-308, rédigé sur la maquette porteur en D-310) :
 *  utiliser l'application, du premier démarrage à la sécurité de la pratique.
 *  Chaque volet décrit ce que l'application FAIT — pas ce qu'on aimerait
 *  qu'elle fasse : les plateformes annoncées et le sens du repère « PIN » ont
 *  été vérifiés dans le code avant d'être écrits. */
export function ecranAide(app: MovensoApp): TemplateResult {
  const beta = app.preferences.compositionsBeta || (RELATIONS_VISUELLES && (app.preferences.vueRelationBeta ?? false));
  return html`
    <div class="carte-atelier aide-intro">
      <p>Movenso est ta <b>bibliothèque de techniques</b>. Elle fonctionne
        <b>entièrement hors ligne</b> : pas de compte, pas de connexion obligatoire,
        et tes contenus restent sur cet appareil. Movenso s'utilise sur téléphone
        (application Android) et dans un navigateur.</p>
      <p class="details">Les volets marqués <span class="aide-repere-pin">PIN</span> demandent un code
        <b>seulement si tu as activé les protections</b> (Plus › Sécurité) — elles sont
        désactivées par défaut, et la lecture n'est jamais bloquée.</p>
    </div>

    ${voletAide("Premier démarrage", false, html`
      <p>Deux façons de commencer, au choix :</p>
      <ul class="apropos-liste">
        <li><b>Installer un pack</b> — Plus › <em>Packs officiels</em> : judo, karaté,
          jujitsu, JJB, taïso, yoga. Chaque pack s'annonce avant de s'installer
          (ce qu'il ajoute, ce qu'il met à jour) et se retire entièrement.</li>
        <li><b>Partir de zéro</b> — Plus › <em>Disciplines et classement</em> › ＋ :
          crée ta discipline, tes catégories et tes niveaux, puis ajoute tes
          techniques depuis la Bibliothèque.</li>
      </ul>
      <p class="details">Rien ne s'écrit sans ton accord : un import est toujours
        <b>proposé</b>, jamais appliqué d'office.</p>
    `)}

    ${voletAide("Naviguer et retrouver une technique", false, html`
      <ul class="apropos-liste">
        <li><b>Bibliothèque</b> : toutes tes techniques en grille. Les puces du haut
          filtrent par discipline, puis par catégorie et par niveau.</li>
        <li><b>Recherche</b> : le champ cherche dans le titre et le sous-titre, sans
          accent ni casse — « uki goshi » trouve « Uki-goshi ».</li>
        <li><b>Favoris</b> : le ♥ d'une fiche la range dans l'onglet Favoris, avec sa
          propre recherche.</li>
        <li><b>Densité</b> : le nombre de colonnes se règle dans Plus › Apparence.</li>
      </ul>
    `)}

    ${voletAide("Lire une fiche", false, html`
      <ul class="apropos-liste">
        <li><b>En tête</b> : l'image ou la vidéo principale, le titre et le sous-titre
          (ce que fait la technique, en français).</li>
        <li><b>Les voix</b> : chaque bloc de texte dit <em>qui parle</em> — le pack, ou
          toi. Ton carnet personnel ne part jamais dans un pack partagé.</li>
        <li><b>Points clés et variantes</b> : l'essentiel du geste, replié par défaut.</li>
        <li><b>Liens</b> : ce qui prépare, enchaîne, contre ou ressemble — avec la
          raison du lien, jamais une flèche nue.</li>
        <li><b>Alertes</b> : certaines techniques portent un repère (information,
          prudence, danger) posé par le pack.</li>
      </ul>
    `)}

    ${voletAide("Vidéos et images", true, html`
      <ul class="apropos-liste">
        <li><b>Filmer</b> : la caméra fonctionne hors ligne, la vidéo est écrite sur
          l'appareil et n'est <b>jamais envoyée</b> nulle part.</li>
        <li><b>Choisir un fichier</b> déjà présent, ou <b>coller un lien YouTube</b> —
          un lien reste un lien : la vidéo se lit chez l'hébergeur, rien n'est copié.</li>
        <li><b>Vignette</b> : touche l'image d'une fiche pour choisir une image, une
          vidéo, ou la retirer.</li>
        <li><b>Parc de médias</b> : Plus › Médias liste les vidéos locales, leur poids,
          et les fichiers que plus aucune fiche n'utilise.</li>
      </ul>
    `)}

    ${voletAide("Protéger l'application (PIN)", true, html`
      <p>Le PIN est <b>facultatif</b> et se règle dans Plus › <em>Sécurité</em>. Deux
        protections indépendantes :</p>
      <ul class="apropos-liste">
        <li><b>Modifications</b> — éditer une fiche, ajouter un média, renommer.</li>
        <li><b>Suppressions et opérations sensibles</b> — retirer, vider la corbeille,
          exporter, restaurer.</li>
      </ul>
      <p class="details">La <b>consultation n'est jamais bloquée</b>. Une fois le code
        saisi, la session reste ouverte 5 ou 15 minutes, ou jusqu'à la mise en
        arrière-plan — au choix. Le PIN vit sur cet appareil : il ne part
        <b>ni dans une sauvegarde, ni dans un pack</b>.</p>
    `)}

    ${voletAide("Partager & exporter", true, html`
      <p>Plus › <em>Créer ou exporter un pack</em> produit un fichier
        <code>.movpack</code> que tu peux transmettre : une discipline entière, ou une
        composition.</p>
      <p><b>Partager n'est pas sauvegarder.</b> Un pack partagé exclut par principe ton
        <b>carnet personnel</b> et tes <b>captures vidéo</b> — ce qui est à toi reste
        à toi.</p>
    `)}

    ${voletAide("Sauvegardes & historique", true, html`
      <ul class="apropos-liste">
        <li><b>Sauvegarde complète</b> (Plus › Sauvegardes) : bibliothèque, carnet
          personnel, favoris <b>et vidéos</b> dans un fichier — de quoi repartir sur un
          appareil vierge.</li>
        <li><b>Sauvegarde légère</b> : tout sauf les vidéos. Ce n'est
          <b>pas</b> une sauvegarde complète — les vidéos restent ici.</li>
        <li><b>Points de restauration</b> : l'application en crée un toute seule avant
          chaque geste risqué (import, suppression de discipline) — pour revenir en
          arrière sans avoir rien préparé.</li>
        <li><b>Corbeille</b> : une fiche retirée y reste restaurable tant que tu ne la
          vides pas.</li>
      </ul>
      <p class="details">⚠️ Une sauvegarde n'est pas chiffrée : elle contient ton contenu
        privé en clair. À garder pour toi ou un appareil de confiance. Les réglages
        d'appareil et le PIN ne voyagent pas — à reconfigurer après restauration.</p>
    `)}

    ${voletAide("Où sont mes données ?", false, html`
      <p>Dans le <b>stockage privé de l'application, sur cet appareil</b>. Aucun serveur,
        aucun compte, aucune synchronisation : personne d'autre n'y accède, et Movenso
        n'envoie rien sans un geste de ta part (les vignettes distantes sont même
        désactivées par défaut).</p>
      <p>Plus › <em>Stockage</em> dit ce que l'application occupe et si le navigateur
        garantit la <b>persistance</b> de ces données.</p>
      <p class="details">La contrepartie est réelle : <b>désinstaller l'application</b>, ou
        <b>effacer les données du site</b> dans le navigateur, efface tout. C'est
        exactement ce contre quoi une sauvegarde protège.</p>
    `)}

    ${voletAide("Sécurité de la pratique", false, html`
      <ul class="apropos-liste">
        <li>Les packs sont une <b>base de travail</b>, pas une référence officielle : à
          vérifier et à enrichir selon ta pratique.</li>
        <li>Ils ne remplacent pas <b>l'enseignement d'un professeur</b> — en cas
          d'écart, ce que dit ton enseignant prime.</li>
        <li>Certaines techniques portent une <b>alerte</b> : lis-la avant d'essayer.</li>
        <li>Adapte à ton niveau et à celui de ton partenaire ; arrête en cas de douleur
          aiguë, de vertige ou de malaise.</li>
      </ul>
    `)}

    ${beta
      ? voletAide("Compositions et relations", false, html`
          <ul class="apropos-liste">
            ${app.preferences.compositionsBeta
              ? html`<li><b>Composer une séance</b> : onglet Compositions › Créer. En lecture,
                  ▶ déroule le pas-à-pas avec le chrono (voix et bips optionnels).</li>`
              : nothing}
            ${RELATIONS_VISUELLES && (app.preferences.vueRelationBeta ?? false)
              ? html`<li><b>Naviguer par les liens</b> : quatre vues d'un même graphe.
                  <button class="chip-filtre" style="vertical-align:1px" @click=${() => app.ouvrirBienvenueRelations()}>🔗 Découvrir Relations</button></li>`
              : nothing}
          </ul>
          <p class="details">Ces deux espaces sont en bêta : ils s'activent dans
            Plus › Réglages avancés.</p>
        `)
      : nothing}
  `;
}
