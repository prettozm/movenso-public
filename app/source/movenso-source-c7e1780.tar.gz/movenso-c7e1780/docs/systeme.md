# Le système tel que construit

> **Type : vivant** · **Statut : NON VALIDÉ (descriptif — le code fait foi)**
> **Remis en cohérence avec le code le 2026-07-24** (phase finition bêta).
> Ce document décrit **ce qui existe** pour qu'un nouveau mainteneur (humain ou
> agent) comprenne le système avec un minimum de lecture. Le *pourquoi* vit
> dans le journal des décisions ([decisions.md](decisions.md) D-001→D-027,
> [execution/DECISIONS.md](execution/DECISIONS.md) D-028→) ; le *présent* dans
> [execution/STATE.md](execution/STATE.md) ; les choix structurants dans
> [contrat-construction.md](contrat-construction.md) ; les parcours dans
> [workflows.md](workflows.md).

## 1. En une phrase

Movenso est un **système souverain de savoir martial** (D-017, D-020) :
structurer, gouverner, diffuser, consulter, enrichir et **réutiliser** son
savoir — identités stables où les voix se rencontrent, provenance visible,
compositions, données et vidéos sur son appareil (l'app web peut nécessiter
une connexion pour se charger — promesse réduite S1.8/D-163), sans compte.
Aucun contenu n'est
embarqué ; les packs `.movpack` s'installent volontairement ; l'export
intégral se restaure sans perte.

## 2. Architecture réelle

```mermaid
flowchart LR
    subgraph engin [Une seule implémentation par règle — contrat §3]
      UI[src/app — UI Lit<br/>racine · vues · capture · compositions chrono + composition-fiche/-liste/-lecteur<br/>plus · aide · atelier (entrée) + atelier-medias/-taxonomies/-reglages<br/>relations-visuelle + relations-carte/-mindmap/-commun · vignette · video-locale · feuilles<br/>atelier-commun · services/ : espace · import-pack · export-pack · fichiers<br/>compositions-actions · medias-fiche · capture<br/>favoris-doublons · taxonomies · atelier-etat — découpages S3.A1/A3/A4/A10]
      DOM[src/domaine — métier PUR<br/>modele · validation · migrations · relations<br/>recherche · rapprochement · composition · medias · ulid]
      SEC[src/securite<br/>politique d'action · PIN PBKDF2]
      ECH[src/echange/movpack.ts<br/>conteneur .movpack v5 : manifeste,<br/>intégrité par fichier SHA-256, images en fichiers,<br/>extraction de pack]
      STO[src/stockage/opfs.ts<br/>bibliothèque JSON + vidéos + snapshots<br/>+ préférences d'appareil]
    end
    UI --> DOM
    UI --> ECH
    UI --> STO
    UI --> SEC
    ECH --> DOM
    STO --> DOM
    CAP[Coquille Capacitor Android<br/>générée à la volée par CI, non versionnée] -.enrobe.-> UI
    OUT[tools/ — conversion packs V2,<br/>inspection/emballage de packs] --> DOM
```

| Dossier | Responsabilité | Règles |
|---|---|---|
| `src/domaine/` | Tout le métier : types (dont **types de relation en données** D-020.2 et **compositions** D-020.1), invariants, migrations n→n+1, graphe (inverse **dérivé des données**), recherche tolérante (+ mots personnels), **rapprochement** à l'import (6 propriétés D-015, compositions comprises), **médias (lot 8A)** : registre DÉRIVÉ (`medias.ts` — références recalculées, jamais un compteur), ingestion unique + déduplication taille+SHA-256 (`ingestion.ts`), verdict d'espace (`espace.ts`) | Pur : zéro E/S, zéro dépendance ; tout testé (l'empreinte utilise Web Crypto, disponible en Node) |
| `src/echange/` | **Trois modules séparés** (D-274) — `movpack-contrat.ts` : ce qu'on EXIGE d'un conteneur `.movpack` **v5** (`VERSION_MOVPACK = 5`), **sans importer `fflate`** ; `movpack.ts` : le codec ZIP qui ouvre et referme ; `extraction-pack.ts` : quel sous-ensemble de la bibliothèque part dans un pack (D-023), pur, sans conteneur. Le contrat : manifeste **validé, jamais casté** (identité stable, auteur, portée, versions conteneur/schéma/éditoriale, **inventaire d'intégrité SHA-256 par fichier**, conditions), images de couverture en fichiers `images/<empreinte>` dont le **nom est revérifié contre le contenu** (D-271), lecture/écriture ZIP, import en flux (`lireMovpackFlux`), extraction d'un pack de discipline / d'une composition / d'une technique (jamais le carnet). Les conteneurs **v4** et **v3** restent lisibles (repli) | Octets ↔ structures, zéro E/S ; détection par contenu ; intégrité vérifiée avant toute mutation |
| `src/securite/` | Politique d'action centralisée (`politique.ts` : consultation libre, modification/suppression protégeables), **PIN** (`pin.ts` : PBKDF2-SHA-256 310 000 itérations, jamais en clair) et **validation des URL externes** (`liens.ts`, S1.3/D-164 : `analyserLien` à la saisie — https seul, normalisation, YouTube par liste blanche d'hôtes + id strict ; `urlSure`/`idYoutubeValide` au rendu — une donnée stockée non sûre devient du texte inerte, jamais un lien actif) | Un seul PIN local ; aucun secret dans un export ; aucune chaîne brute vers `href`/`src`/embed |
| `src/stockage/` | OPFS uniquement (validé sur appareil, D-011) : `bibliotheque.json`, `videos/<ULID>.<ext>` (flux, via `staging/` — §5bis), `sauvegardes/*.json` (rotation 10, restaurables), `preferences.json` (appareil — jamais exporté) | Valide avant toute écriture ; jamais d'écrasement silencieux ; anciens fichiers nus résolus sans renommage |

**Ordre des couches (S3.A6/D-176, gardé statiquement par `verifier-sources`
dans `verifier` et la CI)** : `app → (echange | stockage | securite) →
domaine`. Le domaine n'importe jamais une autre couche ; echange, stockage et
securite n'importent jamais app. Un import dans le mauvais sens fait échouer
la vérification — toute exception se discute (décision).
| `src/app/` | **Shell à trois onglets** (Bibliothèque · Favoris · Plus — **Relations** et **Compositions** s'y ajoutent quand leur bêta opt-in est activée, D-084/D-223) : **Bibliothèque** (disciplines + recherche + état vide ; explorateur grille/filtres ; fiche média-en-tête à voix repliables + édition contextuelle), **Favoris** (marque-pages en cartes), **Relations** (refonte D-135, *gated* §8 : sélecteur de **quatre vues** d'un même graphe — Liste · Carte · Mindmap · Explorer ; **Mindmap** (id `classique`) = **carte synthétique à HAUTEUR FIXE + gabarit spatial sémantique** (D-148) : zone-carte occupant tout l'espace entre l'en-tête et la nav basse (`.mm-plein`, scène `flex:1`, safe-areas) — **hub centre visible sans défiler**. **Mapping DÉTERMINISTE par type métier** (`slotLiaison` : rôle **brut** du type, sans le repli `peer`, → `relationDisplaySlots`) : chaque relation va dans une **zone nommée** (grille CSS `top/left·hub·right/bottom/second/autres`) — **Similaires en haut, Enchaînée depuis à gauche, Enchaîne vers à droite, Fondamentaux requis SOUS le centre, Contre encore en dessous** ; un type sans rôle mais « fondamental » (id/libellé) → Fondamentaux, sinon → « Autres liens », **jamais de repli vers Similaire** ; jamais de zone déterminée par l'ordre/le nombre/la place restante. Composition **centrée et compacte** (pas de moitié inférieure vide), hub **≈38 %** de large (dominant sans écraser), satellites compacts, **titres jamais tronqués**. **2 cartes** représentatives + compte + **« +N » → Liste filtrée**. **Chips légende/filtre** (masquent/affichent une famille), **recherche par icône**, « Centrer » restaure la technique de départ. **Connecteurs** SVG colorés **derrière** les cartes. **Couleur stable par famille** (Fondamentaux en **or** `#C9971E` ≠ orange Similaires). Remise en parallèle de la Carte pour **comparer les deux UX** (D-141→D-148, coexistence temporaire jusqu'à arbitrage) — **Liste** (liens groupés par rôle + **raison** de chaque lien + tri pertinence/priorité) ; **Carte** (ex-« Mindmap » ; D-140 : **mindmap HTML pannable/zoomable**, hub au centre + **cartes-vignettes** (vraie `<img>`, liseré coloré par rôle, nom + raison) placées par RÔLE — avant à gauche, après à droite, opposition en bas, pair en haut, contexte en bas-gauche — reliées par des **courbes de Bézier** colorées (couche `<svg>` de fond de scène) ; **pan** glisser + **zoom** molette + **pincement** deux doigts via `transform` CSS sur la scène (`translate()+scale()`), **lisibilité d'abord** (plancher `K_FIT_MIN`, le fit ne grossit jamais au-delà de 1 et **centre la scène sur le hub** : au-delà le graphe déborde et on se déplace ; le transform persiste entre rendus et se recadre au changement de centre / plein écran), **double-toucher / ⊙ = fit**, **toucher une carte = recentrer** (historique R4), le **hub ouvre la fiche**, pastille ⚠️, **bouton plein écran ⛶** ; **exploration multi-niveaux (D-158→D-160)** : badge « +n » par nœud dépliant ses voisins sur place (niveau 2 atténué, jamais de doublon), carte « +N autres » d'une famille capée **dépliée sur place** (plus de renvoi vers la Liste, D-160), chips légende/filtre par famille, ⊞/⊟ tout déplier/replier, **raison jamais tronquée** (la carte grandit) et **aucun chevauchement de tuiles** (séparation symétrique, hub fixe), pointeur capturé seulement au seuil de glissement (les taps restent des clics) ; refonte de la version 100 % SVG de D-138, jugée illisible par défaut et sans vignettes) ; **Explorer** (entrée guidée « que veux-tu faire ? » → parcours court dérivé d'arêtes réelles, chaque flèche = la raison, enregistrable comme composition) ; code couleur par **rôle** ; **point d'entrée déterministe (D-137)** : centre explicite depuis une fiche → centre mémorisé (`Preferences.relationsCentreId`/`relationsVue`, réglages d'appareil) → dernière technique ouverte → sinon écran **« Choisis un point de départ »** rendu dans l'onglet — **jamais de redirection vers la Bibliothèque**, et cet écran ne sert plus QUE la toute première visite (D-179) et il est devenu une **BIENVENUE explicative** (D-180 : « règles du jeu » en 6 lignes — le centre, les 4 vues et leurs rôles, les outils d'en-tête — puis choix du départ), réinvocable via **Plus › Aide › « Découvrir Relations »** (`ouvrirBienvenueRelations`) ; **en-tête UNIFORME sur les quatre vues** (S3.D1-D2/D-179) : loupe « Rechercher une technique à centrer » ouvrant le panneau partagé `panneauCentrer` (l'ancienne barre inline `selecteurCentre` est supprimée), **🎲 « Centrer au hasard »** = recentrage SUR PLACE dans la vue courante (technique reliée au sort, jamais d'écran intermédiaire), ⌖ « Revenir à la technique de départ » (si historique) ; **fil d'Ariane** de session en tête d'**Explorer seulement** (chemin des centres visités : maillon cliquable, ← Revenir dépile ; **masqué dans la Liste** depuis D-140 — doublon perçu avec le groupe « Enchaîné depuis » — et **retiré de la Carte** en D-160 : le recentrage tactile s'y suffit)), **Compositions** (liste + création + lecture/entraînement avec **chrono de séance vivant**, §4bis), **Plus** (menu à sous-écrans : ancien « Atelier » — diagnostics, taxonomies, packs, sauvegardes, sécurité, réglages). Capture guidée par l'action contextuelle « ＋ Ajouter » d'une discipline | Light DOM, tokens CSS (`src/styles/app.css` — identité D-021), état dans `<movenso-app>` |
| `donnees/` | **Fixtures et contenus distribués** (jamais embarqués) : `kodokan.json`, `club-judo.json`, `rapprochements-judo.json` — au schéma v1, migrés à l'import | Testés par `tests/donnees-*.test.ts` et `tests/assemblage.test.ts` |
| `tools/` | `convertir-movpack-v2.ts` (pack V2 → V3), `rapport-rapprochement.ts` (assemblage + lot de suggestions) | La compatibilité V2 est payée ici, jamais dans l'app |

### Shell et routes réels

Les **zones** (barre basse, type `Zone`) : `bibliotheque` · `favoris` ·
`relations` (rendue seulement si `RELATIONS_VISUELLES` **et**
`preferences.vueRelationBeta`, §8) · `compositions` · `plus`. Les **écrans**
(type `Ecran`, le « routeur ») : `bibliotheques` (racine Bibliothèque) ·
`discipline` · `fiche` · `favoris` · `compositions` (racine) · `composition` ·
`entrainement` (pas-à-pas d'une composition, index dans l'écran) · `relations` ·
`plus` (avec `section: SectionPlus | null`). **`SectionPlus`** (sous-écrans de
Plus) : `packs · techniques · atraiter · doublons · medias · relations ·
corbeille · publier · sauvegardes · securite · apparence · diagnostic ·
apropos` (`section: null` = le menu lui-même). **À propos** (`apropos`, D-130)
affiche la **version** (`src/app/version.ts`, injectée au build par Vite depuis
`package.json` — `__APP_VERSION__`), la nature bêta/debug de la build, une aide
rapide et l'explication sauvegarde/restauration + partage ≠ sauvegarde.
**Retours d'opération (D-131)** : un **voile « … en cours »** (`occupe` réactif +
`#occuperPendant`) bloque l'écran pendant les opérations longues (lecture/
installation d'un pack, restauration) ; un **avertissement « sauvegarde non
chiffrée, à garder pour soi »** est affiché sous les boutons de Sauvegardes. Il n'existe **ni onglet « Pratique » ni
onglet « Atelier »** — « Atelier » ne survit que comme nom de fichier interne
(`atelier.ts`, qui construit les sous-écrans de Plus). Le savoir « à
rattacher » / gardé pour plus tard vit dans **Plus › À traiter**, plus dans une
ancienne « À reprendre » (code mort retiré, D-127).
Il n'existe **plus de route Accueil** ; le démarrage résout la préférence
(`bibliotheque` par défaut — modes `favoris`/`compositions`/`relations`/
`derniere`/`discipline` ; une ancienne valeur `accueil` est migrée par
`migrerPreferences`, testée unitairement) vers l'écran voulu. Navigation : pile `{ecran, defilement}` (retour = d'où l'on
vient, position restaurée) + **mémoire par onglet** (écran, pile,
défilement conservés pendant la session ; second appui sur l'onglet actif =
racine). Le bouton retour Android suit l'ordre du lot 1 §9 (feuille →
édition → pile → racine d'onglet → Bibliothèque → système). L'action
contextuelle du shell est définie par l'écran (« ＋ Ajouter » sur une
discipline uniquement) ; la barre basse disparaît sous les feuilles
(capture, proposition d'import). **Bibliothèque (lot 2)** : les compteurs
de la racine viennent de `resumeDiscipline` (identités visibles — jamais
l'addition des contributions) ; les filtres de l'explorateur sont
conservés **par discipline** pendant la session (`majFiltres` + mémoire) ;
sous filtre de source, l'aperçu d'une carte privilégie un média de cette
source sans toucher au média principal global.

## 3. Modèle de données (contrat exécutable : `src/domaine/modele.ts` + `validation.ts`)

**Discipline** (= la pratique, D-013) → taxonomie en données (familles,
niveaux avec couleurs). **Technique** = *identité* stable (ULID) portant les
**relations** (un seul sens, inverse dérivé à l'affichage, cibles absentes
tolérées ; chaque relation peut porter une **note** — raison pédagogique — et
une **priorité** d'affichage, optionnelles, D-134) et un **média principal**
optionnel. Une technique peut aussi porter des **alertes** (D-136 : réglementaires/sécurité,
ex. « interdit en compétition IJF » — jamais des arêtes du graphe ; `typesAlerte`
déclarés au niveau bibliothèque). **TypeRelationDef** = les types
de relation sont des **données** (D-020.2, H5 levée) : id, libellé, libellé
inverse ou symétrie, **rôle sémantique** (D-136 : `before/after/peer/opposition/context`
— l'UI place d'après le rôle, jamais d'après le texte français), ordre, origine —
quatre défauts semés (`prepare/enchaine/
contre/similaire`), extensibles depuis Plus › Gestion des techniques et par les
packs. **Contribution**
= unité de savoir attachée à une identité, qualifiée par sa **provenance**
(`referentiel|enseignement|ressource|personnel`) — attribution obligatoire si
sourcée ; `techniqueId: null` = capture « à rattacher » (toute provenance depuis le lot 4 §9 ; attribution exigée pour le sourcé).
**Composition** (D-020.1) = savoir réutilisé (« Ma spéciale », programme,
cours — des *finalités*, pas des provenances, D-019) : blocs ordonnés
(référence de technique — jamais une duplication —, étape, transition,
consigne, objectif, durée, média, repère) ; ses transitions ne sont **pas**
des relations du graphe. **Media** typé `local|lien|plateforme` (+ `service:
"youtube"` obligatoire pour plateforme). **Origine** `{pack, element}` sur
techniques, contributions, compositions et types importés = traçabilité +
idempotence de réimport.

La **Bibliothèque** (document racine) porte aussi `favoris: string[]` (purs
marque-pages vers des identités, D-045), `corbeille[]` (flag `supprimeeLe`,
D-078), `fusions[]` (liens de fusion persistants, D-116) et `doublonsIgnores[]`.

Invariants complets : `validerBibliotheque` (rejette, ne corrige jamais).
**Schéma versionné : `VERSION_SCHEMA = 6`** (`modele.ts`), chaîne de migrations
dès le jour 1 (`migrations.ts` : 1→2 = types de relation en données +
compositions ; 2→3 = favoris ; 3→4 = **rôles sémantiques rétro-appliqués** aux
types de relation par défaut persistés sans rôle, D-140 ; 4→5 = l'image
**remonte sur la famille**, la technique la dérive, D-266 ; 5→6 = les images
**quittent l'état** pour des fichiers adressés par leur empreinte, D-269 — la
migration rend les octets à l'appelant, le domaine n'écrit rien) — une version
future est refusée avec message actionnable. Toutes les entités portent un **ULID**
(`ulid.ts`).

## 4. Flux principaux

```mermaid
sequenceDiagram
    participant U as Utilisateur
    participant A as App
    participant D as Domaine
    participant S as OPFS
    Note over U,S: Premier lancement (D-017 : vide mais actionnable)
    A->>S: charger()
    S-->>A: null → bibliothèque vide sauvegardée
    U->>A: Importer un pack (fichier .json)
    A->>D: migrer + valider + importerDansBibliotheque(packId)
    D-->>A: bibliothèque réunie + rapport (rejointes/créées/suggestions)
    A->>S: sauvegarder (snapshot de session d'abord)
    Note over U,S: Capture (moment chaud)
    U->>A: « ＋ Ajouter » (discipline) → filmer/noter → rattacher (optionnel)
    A->>S: ecrireVideo(ULID, flux) si vidéo
    A->>D: contribution personnel (techniqueId ou null)
    A->>S: sauvegarder
```

Le **rapprochement** (`rapprochement.ts`) est le cœur de l'import : un pack
rejoint la discipline et les identités existantes (nom normalisé, même
discipline, non ambigu, ou règle arbitrée) ; sinon il crée des identités et
signale les quasi-correspondances. Jamais de fusion silencieuse ; réimport
idempotent ; relations réécrites puis tout est validé. **Mise à jour d'un
pack déjà installé (D-118/D-222)** : sur ses propres éléments, le pack fait
foi pour l'IDENTITÉ — nom, nom traditionnel et couverture FOURNIS remplacent
la version locale ; un champ que le pack n'apporte pas ne retire rien (une
couverture posée localement survit) ; la voix locale (contributions,
adaptations) reste intouchable (D-027).

### Créer, capturer, rattacher (lot 04)

- **Composants partagés** : `ajouter.ts` (panneau contextuel par gestes +
  création minimale avec `doublonsPotentiels`, fonction pure de
  `rapprochement.ts` — le moteur d'import n'est pas modifié) ;
  `capture.ts` (contenu → aperçu → note → « sais-tu où le ranger ? ») ;
  `ajout-media.ts` (depuis la fiche : média OU contribution complète —
  mode `contribution`). Un seul chemin vidéo : `choisirFichierVideo`
  (exportée) passe toujours par l'aperçu.
- **Cycle de vie d'une capture** : tout reste en MÉMOIRE (File + URL objet
  d'aperçu, révoquée en quittant) jusqu'à la terminaison — l'écriture OPFS
  et la contribution n'existent qu'à la fin (`terminerCapture` :
  anti double-geste `#terminaisonEnCours`, rollback si la persistance
  échoue : contribution ressortie, fichier supprimé, capture conservée).
  Abandon = rien à nettoyer.
- **Provenance par défaut** : `personnel`, silencieusement ; le choix vit
  derrière « Ce contenu vient de quelqu'un d'autre ». Une capture non
  rattachée accepte TOUTE provenance depuis le lot 4 §9 (invariant
  d'increment-1 §2 remplacé — validation adaptée, attribution exigée pour
  le sourcé). Le non-rattaché se retrouve dans Plus › À traiter (« Captures
  à rattacher ») — l'ancien fil « Reprendre » et son code (`filPersonnel`,
  `carteCapture`, `masquerReprise`, préférence `repriseMasquees`) ont été
  purgés (S3.A12/D-177 : plus aucun appelant).
- **Échecs** : permissions refusées → geste sans résultat, alternatives
  visibles ; persistance refusée → toast + état conservé ; hors ligne →
  aucun parcours local n'exige le réseau (le « service » d'un lien est
  déduit de l'URL, jamais requêté).

### Favoris et compositions (onglets dédiés — lot 05 + finition)

Favoris et Compositions sont désormais des **onglets de premier niveau** (plus
une sous-partie d'une « Pratique » disparue).

- **Favoris** : `Bibliotheque.favoris: string[]` (schéma v3, migration
  2→3) — de purs marque-pages vers des identités ; validation = ULID
  uniques ; les orphelins (technique retirée par réimport) sont tolérés en
  données, ignorés à l'affichage (`techniquesFavorites`), nettoyés par
  `supprimerTechnique` ; exclus de `extrairePackDiscipline` ET de
  `exporterComposition` par construction.
- **Réglages (D-234, D-236)** : familles distinctes dans « Plus » — **Sécurité**
  (protections), **Apparence** (thème, tonalité, densité, démarrage, pseudo),
  **Réglages avancés** (mode avancé + fonctions en bêta) et **Stockage et
  sauvegardes**. Deux déménagements, même critère : Apparence dit comment ça se
  PRÉSENTE, rien d'autre. Les avancés en sont sortis parce qu'ils décident du
  **périmètre** (D-234) ; l'**espace de stockage** parce qu'il dit ce que l'app
  **occupe** (D-236) — et sa ligne de persistance (S1.9) est une question de
  sécurité des données, donc sa place est auprès des sauvegardes. Les entrées
  du menu disent leur état : ce qui est actif, l'espace utilisé et la date de
  la dernière sauvegarde.
- **Diagnostic (D-217, enrichi D-234)** : le fichier texte s'ouvre par un **BOM
  UTF-8** et déclare `charset=utf-8` — sans quoi un éditeur Windows ou un
  visionneur Android lit l'UTF-8 en Latin-1 (« Movenso â€” diagnostic »). Il
  rapporte, en plus du socle : **sources du contenu** (identifiant de pack ou
  « local », et combien de techniques en viennent), **sauvegardes internes**
  (nombre + la plus récente), **maillage** (relations, compositions à rôles),
  **capacités réelles de la plateforme** (OPFS, stockage persistant accordé,
  verrou d'écran, partage natif, synthèse vocale, requêtes de conteneur,
  langue) et **réglages NON sensibles**. Chaque section est **omise** si elle
  n'a rien à dire — le rapport ne gonfle pas à vide. La garde unitaire « aucun
  secret » interdit d'écrire les mots des protections, **même pour dire qu'on
  ne les rapporte pas**. **Réserve connue** : la bibliothèque ne retient PAS la
  version éditoriale d'un pack installé, seulement son identifiant sur chaque
  élément — le diagnostic ne l'invente donc pas.
- **Compositions à PLUSIEURS (D-227)** : une composition peut déclarer ses
  **acteurs** (`Composition.acteurs?: { id, nom }[]` — « Tori/Uke »,
  « Attaquant/Défenseur », « Leader/Follower »… nommés librement, **aucun
  vocabulaire de discipline dans le modèle**) ; chaque bloc dit alors QUI agit
  (`Bloc.acteurId?`) et, en option, son **lien avec le pas précédent**
  (`Bloc.lien?`, D-229). Les trois champs sont **optionnels** :
  absents, le comportement solo est strictement inchangé (aucune migration,
  schéma 4). Les acteurs vivent sur la COMPOSITION et non sur la discipline
  (une composition peut être mixte, D-215 — et aucune taxonomie de plus à
  gouverner) ; leur id est un **emplacement local** (« r1 »), donc la
  validation exige l'unicité mais **pas** le format ULID. Une référence
  d'acteur orpheline est tolérée : le bloc redevient neutre à l'affichage,
  jamais une erreur. Saisie (**D-231**) : les rôles se déclarent **dans
  l'entonnoir de création** — étape « Qui pratique ? » (Seul / À plusieurs, D-232)
  **avant** les pas, pour que chaque pas puisse dire qui agit dès sa création ;
  le ⋮ ne sert plus qu'au rattrapage d'une composition existante. **L'app ne
  propose AUCUN nom** : champs vides, aucune paire toute faite, aucun « Rôle N »
  automatique — un rôle n'existe qu'une fois nommé par l'utilisateur (arbitrage
  porteur : « generifie »). Rôle choisi à l'ajout d'un pas avec **alternance
  proposée** (`acteurSuivantPropose`), et **six teintes distinctes** par **rang**
  du rôle (insensible aux retraits/ajouts), à l'écart des couleurs sémantiques.
- **Temps et lecture en TRAME (D-229, grammaire fermée D-235)** : le modèle ne
  connaît **qu'une seule relation** — `Bloc.lien: boolean`, « ce pas **rejoint
  le temps** du précédent ». Absent = il ouvre un temps. **La simultanéité n'est
  pas une étiquette : c'est le SENS de partager un temps**, et la mise en page
  la porte. La cause (« en réponse au blocage ») se dit en `consigne`, texte
  libre — jamais une valeur de structure. Le découpage est une fonction PURE
  (`decouperEnTemps`, `repartirTemps`).
  **Lecture** : une **rangée = un temps**, numérotée sur l'axe de gauche ; une
  **colonne = un rôle**, nommée une seule fois en tête ; deux cartes empilées
  dans une case = deux actions **simultanées du même rôle**. Aucun glyphe,
  aucun mot de liaison. Le nombre de voies suit la **largeur** (D-231) ; replié
  en une colonne, un temps reste un groupe — tout ce qui partage un numéro se
  joue ensemble, sans rien à déduire.
  **Stabilité du regroupement (garde-fou porteur D-235)** — le booléen est
  RELATIF à la position, donc il est normalisé et les gestes sont explicites :
  `normaliserTemps` (idempotente) est appelée à **chaque écriture** depuis
  l'unique chemin `modifierComposition`, ce qui couvre ajout, suppression,
  déplacement, duplication et import ; `retirerBloc` transmet le rôle
  d'**ouvreur** au pas suivant (un temps amputé survit au lieu d'être absorbé,
  et supprimer le premier pas ne rend plus la bibliothèque invalide) ;
  `deplacerBloc`/`reordonnerBloc` réattachent les liens à la **position**, si
  bien qu'échanger deux pas d'un même temps ne le scinde jamais. Un
  identifiant de groupe a été écarté : le tableau `blocs` est déjà la source de
  vérité de l'ordre, deux vérités d'ordre finissent par diverger.
  **Compatibilité** : les valeurs D-229 (`simultane`/`puis`/`reaction`) sont
  réinterprétées à la LECTURE (`estLie` : `simultane` rejoint le temps, les
  autres en ouvrent un) — rien n'est réécrit sur disque tant que l'utilisateur
  ne modifie pas, et la validation les accepte encore en entrée (un import ne
  casse jamais). Un lien posé sur le premier pas est toléré et ignoré.
- **Blocs de composition** : **neuf types internes** conservés (`technique,
  etape, transition, consigne, objectif, duree, media, repere, pause` —
  `LIBELLES_BLOC`) ; l'interface n'expose que **technique / texte libre**
  (et, en édition inline, segment minuté / pause) — AUCUN libellé interne de
  type n'est rendu ; un nouveau texte = type `etape` ; chaque bloc technique
  porte un libellé de secours (`bloc.texte`) — la résilience d'affichage
  quand l'identité manque, l'identité restant la vérité. Un bloc porte
  `consigne?` et `dureeSec?`. **L'ajout d'un pas est PROGRESSIF** (UI-4, D-322) :
  la feuille demande d'abord le contenu (technique ou saisie libre) ; « qui
  agit », « même temps » et la durée n'apparaissent qu'ensuite — sauf en saisie
  libre, où une durée seule crée une **pause** et reste donc offerte d'emblée. À
  champ de recherche vide, elle propose `techniquesAPortee` (discipline du
  dernier pas technique, sinon la seule discipline installée, sinon rien). La
  suppression d'une composition est une action
  dédiée (confirmation nommée, snapshot préalable, style danger).
- **« Continuer » (UI-6, D-324)** — carte de reprise en tête de l'onglet, **au-dessus
  de la bascule** (ce qu'on reprend peut être une séance de pack). **UNE** entrée,
  jamais un historique. La donnée vit dans `Preferences.derniereLecture`
  (`{compositionId, index, quand}`) : écrite par le **lecteur** quand un pas
  s'affiche, **jamais exportée ni sauvegardée** (D-020.4) — donc **aucun bump de
  schéma, aucune migration**. « Terminer » l'efface, « Quitter » la garde ; une
  référence orpheline est **ignorée à l'affichage** (jamais nettoyée sans geste,
  comme un favori orphelin D-127). `demarrerEntrainement(id, index)` relance au
  pas noté.
- **Liste des compositions (UI-1, D-320)** — module dédié
  `src/app/compositions-liste.ts`. **Bascule Mes | Packs** sur `provenance`
  (compteurs annoncés ; entrée du côté qui a du contenu), recherche et chips de
  discipline **au-dessus** des deux côtés. Côté **Mes** : cartes compactes, tri
  Récent / Nom / Durée (session), **⋮** sur la carte. Côté **Packs** : groupes
  par discipline dominante, aperçu de trois puis « Voir les N »,
  **Dupliquer** à la place du ⋮, pied explicatif. **Liseré = discipline
  DOMINANTE**, pesée sur le nombre de pas qui la citent, teinte prise sur la
  palette de six des rôles via le **rang de la discipline dans la
  bibliothèque** (un seul lieu de calcul) ; **égalité = liseré neutre + chip
  « Mixte · a + b »**. **Ligne de méta à icônes** composée de ce qui existe
  (étapes hors jalons · durée si elle existe · Seul / À deux / N rôles). La
  carte de pack **ne porte pas** le nom de son pack : aucun des six packs
  officiels n'attribue ses compositions et leur `origine.pack` est un ULID
  (D-247) — la chip aurait affiché un identifiant. Le libellé d'origine a un
  seul lieu, `origineLisible()` : rien si c'est à moi, l'attribution si elle
  existe, « Pack » sinon — **jamais** `provenance`, qui est un mot du modèle.
  Grammaire écrite en **classes communes** (`.carte-liste`, `.meta-ligne`,
  `.badge-*`, `.rond-action`) pour adoption progressive ailleurs.
- **Écran d'une composition (D-124→126, revu D-233, puis D-319)** : la barre
  reprend la structure d'une fiche (retour + contexte à gauche, actions à
  DROITE : **✎ · ⋮ · ▶ · partager**). **En LECTURE, l'écran est une FICHE de
  consultation** (`src/app/composition-fiche.ts`, UI-2) : vignette discrète
  (54 px — elle se répète trop pour porter l'identité), titre, **badge de
  provenance**, description, puis une ligne de statistiques **entièrement
  dérivée** (nombre d'étapes, durée totale si elle existe, rôles ou « Seul »),
  un **aperçu des cinq premières étapes** dépliable sur place, et une barre
  d'actions à **une seule action forte** (Démarrer) suivie de Dupliquer et d'un
  Planifier **désactivé qui dit pourquoi** (AG-1 n'existe pas). Trois règles :
  la ligne de méta se compose **de ce qui est présent** (aucun pack publié ne
  réunit rôles ET durées) ; les séparateurs d'un kata (« — Te-waza — ») sont
  des **jalons**, pas des étapes numérotées ; une composition **à plusieurs**
  garde sa lecture « en temps » (§4bis) au lieu d'être aplatie en liste.
  `ouvrirComposition` mène TOUJOURS à la fiche : ouvrir, c'est consulter.
  En **ÉDITION** (UI-3, D-321), l'écran porte **le même bandeau de statistiques
  dérivé** que la fiche (`statsCompo` — un seul lieu de calcul, plus le nombre de
  **temps** quand la composition se lit en temps : deux chiffres comparables dans
  un seul bandeau, au lieu d'un résumé « N temps » qui vivait au-dessus et
  semblait le contredire) et les pas forment une **timeline** — rang sur un rail
  vertical continu, hors de la carte. Le rail est **décoratif** : le rang reste
  dans `.bloc-nature`. Le **✎ bascule tout l'écran en mode édition** —
  c'est là, et seulement là, que chaque pas montre son rôle, son lien, les
  flèches ▲/▼, un ⋯ vers la feuille détaillée et un ✕, et l'écran se lit alors
  en **une colonne** (éditer est linéaire, lire est structuré). **En lecture,
  un pas ne porte aucun outil** : la place revient au contenu. « ＋ Ajouter un
  élément » ouvre une feuille légère technique/segment/pause. Le **menu ⋮**
  (`menuComposition`) ne garde que le hors-séquence : renommer, description,
  consigne, présentation, dupliquer, supprimer — chaque action derrière la
  garde d'écriture PIN héritée. **Dupliquer rend la copie PERSONNELLE**
  (D-320) : `origine`, `provenance` et `attribution` partent ensemble — une
  copie qui garderait la provenance d'un pack resterait rangée du côté des
  packs et se republierait avec eux. Durée saisie façon chrono (min:s) avec
  bascule d'unité `min`/`s`, valeur stockée en secondes.
- **Fabrique des packs officiels (D-238→D-248)** — les **six** packs sont
  produits par `tools/publier.ts` à partir de `donnees/<pack>.json` (kodokan,
  jujitsu, karate-shotokan, jjb, taiso, yoga — la dette « Yoga sans source »
  est levée, D-273). Les **illustrations vivent en FICHIERS**, jamais en
  base64 dans la source : `donnees/images/<pack>/techniques/<origine.element>.jpg`
  pour une image PROPRE à une technique, `donnees/images/<pack>/<familleId>.jpg`
  pour une carte de FAMILLE. L'emballage pose l'image propre d'abord, la carte
  de famille à défaut, rien sinon — une carte générique ne remplace jamais une
  illustration spécifique (D-245), et une fiche sans image reste nue plutôt que
  d'afficher ce qu'elle ne montre pas. Depuis le **schéma 6** (D-269) la chaîne
  ne fabrique plus aucun base64 : elle inscrit l'image à l'inventaire et pose
  ses octets dans `images/<empreinte>` du conteneur. L'ancienne précaution
  « garder la data-URL sous 32 Kio pour que deflate replie les copies »
  (D-244) n'a plus d'objet — une image identique n'existe qu'une fois, par
  construction, puisque son identité EST son contenu.
- **Identité d'un pack : sa DISCIPLINE, jamais son nom (D-247)** — le manifeste
  porte `idPackStable(disciplineId)`, et c'est par cet id que l'app reconnaît un
  pack : le changer fait voir une mise à jour comme une installation neuve et
  **duplique tout le contenu**. La règle vaut pour les packs officiels comme
  pour ceux qu'un utilisateur exporte de sa propre bibliothèque — un seul
  mécanisme, donc les deux mondes s'accordent. Elle est invariante au
  renommage, ce qui est exactement le point : `idDePack(nom)` ne sert qu'à
  fabriquer un NOM DE FICHIER. Un test épingle les identités publiées
  (`tests/packs-identite.test.ts`) : une identité ne bouge pas par accident.
- **Ce qu'un pack PROPOSE, jamais ce qu'il impose (D-157, étendu D-243)** — à
  l'import, deux désaccords possibles sur une arête sont consignés dans
  `conflitsLiaisons` sans rien appliquer : une **raison différente** (`sens`
  absent ou `contenu`) et, depuis D-243, un **lien que la nouvelle version ne
  déclare plus** (`sens: "retrait"`). Le second existe parce qu'une mise à jour
  n'ajoutait que des relations : une épuration éditoriale (D-241 : 315 → 67
  liens) n'atteignait que les installations neuves, en silence. Rien n'est
  retiré d'office et ce n'est pas un compromis : **une arête ne porte pas
  d'`origine`**, donc rien ne distingue celle du pack de celle que l'humain a
  tracée — la supprimer détruirait son travail. Le calcul se fait à l'import
  (différence entre les arêtes déclarées et celles présentes **entre deux
  techniques du pack** : un lien vers ses propres techniques n'est jamais
  proposé), il est idempotent, et une proposition redevenue caduque disparaît.
  L'arbitrage se fait dans Plus › Relations — « garder » classe, « retirer »
  supprime l'arête ; l'action groupée passe par une confirmation nommée et un
  point de restauration. Le champ `sens` est optionnel : les conflits déjà
  enregistrés se relisent sans migration. **Le même patron protège les
  CONTRIBUTIONS amendées (D-298)** : une contribution qu'un humain a modifiée
  (`modifiePar`) n'est jamais écrasée par la mise à jour du pack — la
  proposition du pack part dans `conflitsContributions`, la version locale
  reste en place, et l'arbitrage (« la mienne / celle du pack ») se fait dans
  Plus › À traiter. Choisir « celle du pack » efface la signature d'édition,
  qui mentirait sur un texte redevenu 100 % pack ; un texte local réaligné
  sur le pack fait disparaître l'entrée ET la signature d'office. **Les
  compteurs du rapport parlent de CET import** (D-307) : la table
  `conflitsLiaisons` garde les propositions de tous les packs, mais le
  rapport ne compte que celles du pack importé — la compter entière
  annonçait les conflits du Judo à qui installait le Jujitsu. Le rapport dit
  aussi le **changement réel d'une mise à jour** (fiches dont le nom, le
  sous-titre, la couverture ou le texte du pack change ; compositions
  modifiées ; images et liens ajoutés) — sans quoi la feuille d'avant-import
  disait « rien de nouveau » sur une mise à jour qui réécrivait 91 fiches.
  Enfin l'**édition installée est retenue** (`editionsPacks`, une entrée par
  pack, écrite à l'import depuis le `versionEditoriale` du manifeste) : la
  feuille de mise à jour peut dire « Édition 11 → 12 ». Métadonnée locale,
  jamais publiée, validée à la frontière comme les conflits.
- **Réordonner : les flèches, et rien d'autre (S2.9, puis D-233)** — partout
  où l'on réordonne (disciplines, catégories, niveaux — `src/app/glisser.ts` —
  et blocs de composition), les boutons **▲/▼** (« Monter X » / « Descendre X »,
  désactivés en butée) sont le **seul** mécanisme, utilisables au doigt, au
  clavier et via un lecteur d'écran. Le **glisser-déposer a été RETIRÉ de toute
  l'app** (D-233) : WCAG 2.5.7 imposait de toute façon l'alternative à pointeur
  unique, il n'auto-défilait pas aux bords (donc ne pouvait pas sortir un
  élément de la zone visible) et sa poignée ⠿ mangeait la largeur — celle-là
  même qui manque à la trame des compositions. Le nom du module est un
  reliquat historique. Chaque déplacement persiste aussitôt (garde PIN) et est
  **annoncé** dans une zone `aria-live` polie (`annoncer`, `.annonce-lecteur`).
  Subtilité assumée : `reordonner(x, cible)` (retirer puis insérer à l'index de
  la cible) ne sait faire avancer que l'élément d'APRÈS — « descendre » se fait
  donc en faisant monter le voisin du dessous (`deplacerDunCran`).
- **Modales réellement modales (S2.10 tranche 2)** : chaque feuille
  `role="dialog"` porte `aria-modal="true"` + `tabindex="-1"` ; **Échap
  ferme la modale du dessus** (listener central dans la racine : il clique
  le dernier `.voile`, même chemin que le toucher hors feuille — le voile
  OCCUPÉ n'est pas concerné) ; le **focus est géré centralement**
  (`updated()`) : il entre dans la feuille à l'ouverture (`[autofocus]`
  sinon la feuille) et revient à l'élément ouvreur à la fermeture.
- **Notifications transitoires (5.7)** : `afficherToast` remplace la
  précédente et pose une péremption ; triple garde — minuteur (~3,4 s),
  expiration revérifiée au rendu (`willUpdate`, contre les minuteurs gelés
  par la WebView), effacement systématique à tout changement d'écran ;
  jamais rendue sur l'écran `entrainement`.
- **Références absentes** : jamais supprimées en masse — le retrait d'une
  technique nomme les compositions dépendantes, laisse les blocs avec
  leur libellé, « Remplacer la technique » répare.
- **Export / partage d'une composition** : `extrairePackComposition` (pur) =
  composition + identités de technique enchaînées + leurs disciplines, SANS
  contributions ni carnet ni favoris. `exporterComposition` et
  `partagerComposition` passent tous deux par lui (D-127) → une séance
  partagée reste **jouable** chez le destinataire même sans le pack d'origine.

### Chrono de séance — le pas-à-pas devient vivant (finition, D-125/126)

**Le LECTEUR (UI-5, D-323)** — `src/app/composition-lecteur.ts` : une **jauge de
séance** (part parcourue, dérivée du rang, `aria-hidden` car le « N / M » voisin
le dit déjà), un **anneau** autour du décompte (part de la phase courante, en
`conic-gradient` masqué ; ses bornes se dérivent AU RENDU — le chrono ne gagne
aucun champ) et un bloc **« Ensuite »** portant le **rôle** du pas suivant, avec
la **passation** (« Tori → Uke ») quand il change. Le moteur (décompte, voix,
préparation, suspension en arrière-plan) est **intouché**.

Le mode entraînement (`{type:"entrainement", compositionId, index}`,
`compositions.ts`) porte un **vrai décompte** pour les séances minutées (cas
taïso) :

- **Décompte** `setInterval` 1 s ; à zéro, **passage automatique** au bloc
  suivant (l'index vit dans l'écran ; la pile restaure LE MÊME bloc au retour
  d'une fiche) ; **pause / reprendre** ; barre basse masquée.
- **Transition de préparation** réglable (`transitionSec`, défaut 3 s ;
  0/3/5/10) : phase « Préparez-vous » avec bips 3-2-1 avant un segment minuté,
  jamais sur un pas manuel.
- **Voix réelle des annonces** (`parler`) : TTS natif
  (`@capacitor-community/text-to-speech`) sur Android, `speechSynthesis` sur
  le web, `fr-FR` ; annonces d'entrée (nom + durée en mots) et repères
  (mi-parcours, 30 s, 10 s — `annonceCue`).
- **Bips** (`AudioContext`, sans dépendre du TTS) et **mode son** cyclable
  (`sonSeance` : les-deux / voix / bips / muet). Le chrono est **coupé sur
  tout chemin de sortie** (`stopperChrono`).
- **Arrière-plan = séance SUSPENDUE (S2.3/D-170)** : les minuteurs d'un
  onglet caché sont bridés par le navigateur (le décompte dériverait « selon
  les cas » — recette appareil Samsung A36) ; plutôt qu'une fausse promesse,
  `visibilitychange` → hidden pendant l'entraînement appelle
  `suspendreSeance` — même pause que le bouton, voix coupée net, bandeau
  « Séance mise en pause — l'app est passée en arrière-plan » au retour,
  reprise d'un GESTE (jamais automatique). En complément, un **verrou
  d'écran** (Screen Wake Lock, `maintenirEcranSeance`/`relacherEcranSeance`)
  est posé tant qu'on est sur l'écran d'entraînement : l'écran ne s'éteint
  pas tout seul en pleine série — la suspension n'arrive que si l'utilisateur
  verrouille ou change d'app lui-même. Silencieux si l'API manque ; le
  navigateur relâche seul le verrou quand l'app se cache, il est redemandé au
  retour. **Promesse documentée** : la séance tourne écran allumé, app au
  premier plan ; app cachée ou téléphone verrouillé = pause, reprise où on
  était.

### Plus : gouverner le corpus (ancien « Atelier », lot 06 + refonte D-071)

« Plus » (`plus.ts` ; sous-écrans construits par `atelier.ts`) agit sur le
corpus dans son ensemble (structurer, vérifier, échanger, protéger) — jamais
le passage obligé du quotidien (consulter, capturer, favoris, compositions
vivent dans leurs propres onglets).

- **Forme réelle (D-071)** : un **menu plat** (lignes icône + titre + état +
  chevron), **pas** d'accordéons — chaque ligne ouvre un **sous-écran
  spécialisé** (`SectionPlus`), regroupé en *Ma bibliothèque* / *Importer,
  exporter et sauvegarder* / *Préférences*. Certaines entrées n'apparaissent
  qu'en **mode avancé** (`modeAvance` : Doublons, Médias, Diagnostic) ou en
  **relations bêta** (`vueRelationBeta` : Relations entre techniques).
- Une vidéo locale absente affiche un message dégradé sur la fiche et renvoie
  vers **Plus › Médias et qualité** pour diagnostiquer.
- **Diagnostics** : deux natures SÉPARÉES — intégrité (vidéos manquantes,
  relations cassées, fichiers orphelins) et « à compléter » (à rattacher,
  sans contenu, sans niveau — explicitement pas des erreurs). L'état
  calculé (`#rafraichirAtelier`) liste les fichiers OPFS (`taillesVideos`)
  et les confronte aux références (contributions + blocs de composition) ;
  un orphelin exige la prévisualisation avant suppression et la référence
  est revérifiée à l'instant de supprimer. Les fichiers VÉRIFIÉS peuvent
  ensuite partir **ensemble** (D-171, précision de D-107 : la masse reste
  interdite pour les références et les fiches ; pour des fichiers sans
  aucune référence, chacun prévisualisé, un bouton « Supprimer les N
  fichiers vérifiés — X Mo » apparaît dès 2 vérifiés, chaque fichier étant
  RE-vérifié orphelin à l'instant de supprimer). Un média retrouvé peut
  aussi être rattaché à une fiche (S2.12).
- **Règles de suppression** (§30) : libellés précis (« Retirer cette
  discipline vide », « Supprimer la discipline et son contenu »,
  « Retirer la classification », « Supprimer ce fichier inutilisé »),
  conséquences présentées AVANT, snapshot motivé dès que des données
  changent en masse, jamais de référence invalide (taxonomies :
  remplacement ou retrait propre ; types de relation : suppression
  refusée tant qu'utilisé).
- **Publication ≠ sauvegarde** : publier = corpus DISTRIBUABLE, borné aux
  sources maîtrisées (opt-in), métadonnées éditoriales (nom, auteur,
  conditions — portées par le manifeste), prévisualisation exacte avec
  exclusions dites (carnet, favoris, captures, sources non cochées) ;
  sauvegarder = « Sauvegarde complète de cette installation » (tout,
  favoris compris, vidéos incluses — la « légère » DIT ne pas être
  complète). Les deux sorties donnent nom réel, taille et résumé
  (`dernierFichier`) ; le fichier va aux Téléchargements (partage système
  Android : lot 8D).
- **Orchestration import/restauration** : import = aperçu (contenu,
  volume, manifeste) → fusion calculée À BLANC (D-023) → confirmation →
  rapport actionnable (`rapportApresImport`) ; restauration complète =
  contenu affiché avant toute écriture (`restaurationEnAttente`),
  installation vierge seulement ; rollback = snapshots motivés, la
  confirmation explique le remplacement et l'ABSENCE des octets vidéo
  dans les snapshots (refactor 8C), l'état courant est re-snapshoté.

### Sécurité et modes d'usage (lot 07)

- **Politique centralisée** (`src/securite/politique.ts`) :
  `autorisation(catégorie, protections, session)` → libre / pin_requis —
  trois catégories (CONSULTATION jamais bloquée, MODIFICATION,
  DESTRUCTION_OU_SENSIBLE), deux protections indépendantes, une session
  libère les deux niveaux (un seul PIN local). Les composants passent par
  `app.autoriser()` / les 36 gardes de méthode `#autorise` — aucune
  condition dispersée.
- **Stockage du PIN** (`src/securite/pin.ts`) : jamais en clair —
  PBKDF2/SHA-256 (Web Crypto), 310 000 itérations documentées, sel
  aléatoire de 16 octets par création, stockage {version, sel,
  itérations, empreinte} dans les préférences d'APPAREIL (fichier séparé,
  jamais lu par l'export : aucun secret dans les `.movpack`, décision
  §21 — restaurer ailleurs = reconfigurer). Vérification à temps
  constant ; format 6-12 chiffres, valeurs évidentes refusées ;
  temporisation progressive plafonnée dès la 5e erreur.
- **Session curateur** : mémoire seulement (horodatage du dernier geste
  autorisé) — expire par inactivité (5/15 min) ou vit jusqu'à
  l'arrière-plan (`visibilitychange` verrouille ce mode immédiatement) ;
  fermée par « Verrouiller maintenant », la fermeture de l'app, le
  changement de PIN, la reconfiguration des protections ; jamais
  persistée ni sauvegardée. Indicateur discret 🔓 (jamais un mode Admin).
- **Opérations asynchrones** : la permission se vérifie AVANT le début
  (gardes à l'entrée) — une restauration ou un export lancé n'est jamais
  interrompu par l'expiration. Les formulaires ne se perdent pas : les
  arguments voyagent dans la fermeture de reprise.
- **Événements** : journal minimal en mémoire de session (déverrouillage,
  verrouillage, protections, PIN modifié, échecs cumulés) — sans valeur
  secrète, jamais persisté ni exporté.
- **Limites réelles** (§25, dites sans dramatiser) : le PIN protège les
  actions DANS Movenso — il ne chiffre pas les données au repos et ne
  protège ni du système de fichiers, ni de la désinstallation ; la
  sécurité du terminal reste nécessaire.

### La fiche technique (lot 03)

- **Construction** (`vues.ts` : `gabaritFiche`) : en-tête compact (retour ·
  discipline · menu ⋮) → média principal (choix explicite
  `mediaPrincipalId`, sinon premier média de la voix la plus sourcée) avec
  légende éditoriale et galerie compacte — **sans aucun média, la
  COUVERTURE (D-083) prend la place** avec la mention « Illustration —
  aucune vidéo pour l'instant » et l'ajout de média en compact (D-224) ;
  sans couverture non plus, l'état vide + invitation inchangés → voix ordonnées (celle du média
  affiché, puis référentiel → enseignement → ressource → personnel) →
  Mon carnet → **section « Relations · N »** (D-138 R5/R19 : `sectionRelationsFiche`,
  aperçu **groupé par rôle**, ≈2 liens/rôle avec leur raison ; « Présente dans »
  à part ; l'icône réseau du haut → Carte, « Voir toutes les relations » → écran
  Relations en Liste centré) → « Utilisée dans · N ».
- **Composants** : `racine.ts` porte l'état de session de la fiche
  (`mediaAffiche`, `voixOuverte`, `relationsDepliees` — conservés PAR fiche
  dans `#etatFiches`, §19) ; `ajout-media.ts` est la feuille d'ajout ;
  `video-locale.ts` lit une vidéo OPFS en URL objet (flux disque, message
  dégradé + renvoi vers Plus › Médias et qualité si absente).
- **Règles d'édition (D-027)** : une contribution AVEC `origine` (pack) est
  intacte — l'app ne l'édite jamais (`amenderContribution` la refuse) et la
  fiche explique la règle + propose « Créer une adaptation locale »
  (contribution `personnel` attribuée « Adaptation locale d'après … », sans
  `origine` — donc jamais écrasée par un réimport). Une contribution locale
  reste directement modifiable. Faiblesse assumée : pas de marqueur
  explicite d'adaptation dans le modèle (§21) — à traiter au lot 6.
- **Chargement différé** : embeds YouTube opt-in (nocookie, sur geste),
  vidéos locales en URL objet `preload=metadata`, miniatures YouTube en
  `loading=lazy` — jamais tous les lecteurs actifs à la fois.
- **Navigation contextuelle** : pile (fiche ↔ fiche liée ↔ composition),
  chaque retour restaure défilement et état de consultation de la fiche.

## 5. Format d'échange et migrations

- **Conteneur `.movpack` v5 — construit et prouvé** (`src/echange/movpack.ts`,
  D-018.1, lot 8B) : ZIP versionné, extension `.movpack`, **MIME applicatif
  `application/vnd.movenso.movpack+zip`** (repli `application/zip` /
  `application/octet-stream` selon les limites de partage Android).
  - **Structure canonique** : `manifeste.json` + `bibliotheque.json` +
    `medias/<mediaId>.<extension>` (l'extension vient du registre 8A ;
    `medias/<id>` nu si inconnue) + `images/<empreinte SHA-256>` (**v5**,
    D-269 : les couvertures sont des fichiers, nommés par leur contenu). Les
    conteneurs **v4** (images en base64 dans `bibliotheque.json`) et **v3**
    (médias sous `videos/<ULID>`) restent **importables** — la migration de
    schéma détache leurs images à la lecture, et l'appelant les reçoit
    exactement comme celles d'un v5 : **un seul chemin d'écriture en aval**,
    donc un seul à prouver.
  - **Manifeste (§13)** : identité TECHNIQUE stable (`id` dérivé de l'ULID de
    l'entité — invariant au renommage, clé d'idempotence D-013/D-015 ; le nom
    éditorial ne sert qu'au nom de fichier), nom, portée (= type d'objet :
    `complet` sauvegarde / `discipline` pack / `composition`), auteur,
    conditions, date, version du conteneur, version du schéma, **version
    éditoriale**, **options d'inclusion DITES** (médias, contenu personnel),
    **inventaire d'intégrité par fichier** {chemin, taille, SHA-256} +
    algorithme, empreinte globale de `bibliotheque.json` (repli).
  - **Intégrité à la lecture (§14)** : vérification fichier par fichier —
    liste → tailles → empreintes — pour `bibliotheque.json` ET chaque média ;
    tout écart (fichier manquant, taille ou empreinte différente) fait
    **refuser le conteneur AVANT toute mutation**, en nommant le fichier
    fautif. Un fichier présent mais hors inventaire est **ignoré avec
    avertissement** (remonté dans l'aperçu d'import/restauration), jamais
    exécuté.
  - **Détection par contenu** (jamais l'extension seule) : signature ZIP +
    `manifeste.json` + `format` + `version` ; l'app importe indifféremment un
    `.movpack` et un JSON nu ; une version future est refusée avec un message
    actionnable (« mettre à jour l'application »).
  - **Export à mémoire bornée (§15, lot 8B.3)** : l'app exporte par un
    pipeline borné par blocs — source média → lecture par blocs de 1 Mio →
    SHA-256 INCRÉMENTAL (`src/domaine/sha256.ts`, WebCrypto étant one-shot) →
    poussée progressive de l'entrée ZIP (`ZipPassThrough`) → fichier
    temporaire OPFS `staging/`, puis téléchargement depuis ce fichier adossé
    au disque. Ni le média entier, ni l'archive entière ne résident en
    mémoire. Temporaire nettoyé avant chaque export et au démarrage ;
    annulation/échec → abandonné ; OPFS indisponible → refus borné. La MESURE
    sur gros médias est le harnais 8B.4 ; la vérification appareil est la
    recette Android. `exporterMovpack` (en mémoire) subsiste pour les
    fixtures de test uniquement.
- **Export complet → restauration** : ids conservés tels quels, uniquement
  sur une **installation vierge** (D-021.2) — prouvé en e2e (contexte
  Chromium vierge, OPFS réel). C'est la fondation de la propriété des
  données (D-018.2) : **R8 levé**.
- **Publication de pack** : extraction par discipline, contributions et
  compositions **non personnelles** uniquement (D-021.3) ; réimport
  idempotent par origine `{pack, element}`.
- **Migrations** : schéma **v6** (`VERSION_SCHEMA = 6`) ; migrations 1→2 (types
  de relation en données, compositions, média principal — D-020), 2→3 (favoris)
  et 3→4 (rôles sémantiques rétro-appliqués aux types par défaut persistés sans
  rôle — D-140) enregistrées et testées. Les données `donnees/` sont migrées à
  l'import (les rôles y sont déjà présents ; la migration 3→4 y est un no-op).
- Les **préférences d'appareil** (`preferences.json` : démarrage, dernière
  bibliothèque) ne voyagent jamais dans un export (D-021.6).

## 5bis. Stockage réel des médias et cycle de vie (lot 8A, §6-10 du lot 8)

**Persistance (S1.9, D-163)** : au démarrage web, `persist()` est demandé et
son résultat **lu** (`persisted()`) — l'état s'affiche honnêtement dans la
carte « Espace de stockage » (Plus › Apparence) : *accordée* / *non
garantie* (avec bouton « Demander la persistance ») / *stockage applicatif
natif* (Android : bac à sable, pas d'éviction navigateur) / *inconnue*
(API absente). Jamais bloquant, jamais une garantie inventée.

**Arborescence OPFS** (responsabilités séparées, §7) : `bibliotheque.json`
(état courant), `preferences.json` (appareil, jamais exporté),
`videos/` (médias définitifs), `images/<empreinte SHA-256>` (couvertures,
schéma 6 — D-269), `staging/` (écritures temporaires — un
fichier n'apparaît dans `videos/` qu'une fois complet ; vidé au
démarrage), `sauvegardes/` (snapshots, rotation 10). Aucun dossier de
miniatures : **rien n'est généré** — les vignettes et aperçus sont des
rendus à la volée depuis l'original (politique §9 : un aperçu absent
n'est pas une perte de donnée ; rien à inclure dans les sauvegardes, rien
à régénérer après restauration).

**Les images sont nommées par leur EMPREINTE** (schéma 6, D-269) — pas par un
ULID. Trois propriétés en découlent, et ce sont elles qui rendent le stockage
sûr sans transaction à plusieurs fichiers : deux fiches qui montrent la même
image n'occupent **qu'un fichier** ; écrire `images/<id>` est **idempotent**
(même nom, même contenu — une écriture interrompue puis reprise ne peut pas
produire un fichier à moitié différent) ; et l'inventaire `Bibliotheque.images`
est le **seul lieu** qui déclare une image, les couvertures s'y référant sans
jamais porter d'octets. L'ordre d'écriture est donc toujours le même : **les
octets d'abord, l'état qui les déclare ensuite** — `bibliotheque.json` reste le
seul fichier transactionnel, et la bascule protégée (§18) est inchangée. Le
balayage des fichiers orphelins est une opération **séparée et plus prudente**
que l'épuration de l'inventaire : perdre une image encore utilisée est
irréversible, un fichier en trop ne coûte que de la place.

**Ce que ça change en poids** : `bibliotheque.json` passe de 5025 à 136 Ko pour
le karaté (37×), et c'est ce fichier que la bascule protégée réécrit en trois
passes à chaque sauvegarde — mesuré 419 ms sans images, 3802 ms avec 12 Mo
(D-268). Le CONTENEUR, lui, ne gagne quasiment rien (1 à 3 %) : un `.movpack`
est un ZIP, et deflate récupérait déjà l'inflation du base64.

**Nommage physique** (§6) : `videos/<mediaId>.<extension-canonique>`
(ex. `01ARZ….webm`) — l'extension canonique dérive du MIME réel
(`extensionCanonique`, `src/domaine/medias.ts`), JAMAIS du nom fourni par
l'utilisateur, du nom de la technique ou du pack (ces valeurs changent ;
le nom d'origine vit dans `media.nomOriginal`). Les fichiers d'avant le
lot 8A restent nommés par l'id nu et restent lisibles : la résolution
(`#fichierVideo`) essaie l'id nu puis `<id>.<ext>` — **jamais de
renommage en masse**, donc aucune stratégie de reprise à maintenir.
`ecrireVideo` écrit dans `staging/` puis déplace (`move`, repli
copie+retrait pour les WebView plus anciennes).

**Espace** (§10) : avant une écriture volumineuse (restauration, import),
`navigator.storage.estimate()` → verdict PUR `evaluerEspace`
(`src/domaine/espace.ts`, marge 10 % avec plancher 16 Mo). Estimation
fiable et insuffisante → **refus avant toute mutation**, les deux tailles
sont dites, la proposition reste ouverte. Estimation indisponible → on
procède sans inventer ni refus ni garantie.

**Emplacements réels par cible** (§8) :

| Cible | Où vivent les données | Ce qu'il faut savoir |
|---|---|---|
| Android (Capacitor/WebView) | OPFS de la WebView, dans le stockage privé de l'application (`/data/data/fr.prettozm.movenso.v3/…`) | invisible dans l'explorateur de fichiers (OPFS n'est PAS un dossier visible) ; conservé lors d'une mise à jour de l'app ; **supprimé à la désinstallation** ; sortir un fichier de l'espace privé = export `.movpack` (téléchargement WebView ; partage système natif : lot 8D) |
| Navigateur | OPFS propre à l'origine | « Effacer les données du site » supprime TOUT (bibliothèque, vidéos, snapshots) ; quota géré par le navigateur (`storage.estimate`) ; navigation privée = stockage éphémère ; `navigator.storage.persist()` est demandé au démarrage pour limiter l'éviction (sans garantie) |
| PWA | non livrée en V3 | si elle l'était : même origine et même OPFS que l'onglet ; désinstaller l'icône ne supprime pas les données — seul l'effacement des données du site le fait |

La propriété des données repose sur **l'export et la sauvegarde**
(`.movpack` complet), jamais sur l'accès manuel au stockage privé.

## 5ter. Transactions, bascule et reprise (lot 8C, §17-23 du lot 8)

**Bascule d'état protégée (§18)** — `StockageOpfs.sauvegarder` n'écrase plus
`bibliotheque.json` en place : il écrit `bibliotheque.json.tmp`, le **relit**,
le **revalide** (`migrerBibliotheque`+`validerBibliotheque`), PUIS bascule vers
le fichier courant (le `createWritable` OPFS ne publie qu'au `close()`), et
supprime le temporaire. Une erreur avant la bascule laisse l'état courant
intact ; le service (`racine.ts`) remonte l'exception et restaure sa copie
mémoire. Les sauvegardes sont **sérialisées** (`#chaineSauvegarde`) : deux
écritures ne se disputent jamais le temporaire. **Atomicité non parfaite
revendiquée** — OPFS n'offre pas de rename transactionnel garanti ; la
stratégie est « écrire-valider-basculer + écarter un résidu au prochain
lancement ».

**Reprise au démarrage (§18-19)** — `charger()` appelle
`reprendreTransactionInachevee()` : un `bibliotheque.json.tmp` résiduel est un
commit interrompu → **écarté**, le dernier état courant validé reste la
vérité ; `staging/` est vidé (un résidu d'écriture média interrompue n'est
jamais promu parmi les définitifs). Aucune bibliothèque à moitié écrite,
aucun fichier partiel visible.

**Atomicité média + donnée métier (§17, §19)** — tout parcours qui écrit un
média NEUF puis persiste (`ajouterMediaFiche`, `terminerCapture`,
`terminerCaptureRepere`) passe par `#persisterAvecMediasNeufs` : sur échec, les
fichiers NEUFS sont retirés (jamais un dédupliqué, partagé avec d'autres
références) et la mutation mémoire est annulée. Résultat : jamais d'orphelin,
jamais de référence fantôme, la capture reste ouverte (rien n'est perdu). Une
garde unique (`#ecritureMediaEnCours`, posée synchronement) neutralise le
double-appui ; deux ajouts du même fichier → une seule ingestion (empreinte)
et une seule contribution.

**Amendement transactionnel (§18)** — `appliquerAmendement`
(`src/domaine/contribution.ts`) est PUR : il retourne une nouvelle contribution
sans muter l'originale, qui sert de point de rollback fidèle (aucune valeur
modifiée ne réapparaît).

**Import / restauration (§17)** — proposés AVANT toute mutation
(`importEnAttente` / `restaurationEnAttente`), snapshot préalable, refus
d'espace avant écriture ; les médias s'écrivent puis l'état bascule. La
restauration intégrale reste réservée à une **installation vierge** (jamais de
fusion implicite, D-021.2).

**Snapshots et rétention (§22-23)** — les snapshots (`sauvegardes/`, rotation
10, motivés) sont l'**état métier SEUL** (stratégie B, sans octets vidéo — dit
dans la confirmation de rollback). La suppression physique d'un média n'arrive
JAMAIS immédiatement après une action métier : seulement à l'orphelin
**confirmé** dans Plus › Médias et qualité (prévisualisation + confirmation).
Cette rétention de
fait donne un sens au rollback — restaurer un snapshot ramène la contribution
ET sa vidéo tant que l'orphelin n'a pas été purgé. Pas de corbeille dédiée
(jugée hors périmètre, §23). **Réglages d'appareil** (thème, démarrage,
protections/PIN) : jamais dans une sauvegarde (D-065) — reconfigurés après
restauration, dit honnêtement. Une sauvegarde n'est « complète » que si les
vidéos sont incluses ET aucune ne manque, sinon « partielle » aux exclusions
nommées (§20).

## 5quater. Plateformes, build et release (lot 8D, §29-37)

**Stratégie Android : B — projet généré déterministe (§29).** Aucun dossier
`android/` n'est versionné ; il est régénéré à l'identique par `npx cap add
android` + `npx cap sync android` (aucune modification native manuelle
requise), puis `gradlew assembleDebug`. La CI (`apk.yml`) le prouve à chaque
push touchant `src/`, `capacitor.config.json` ou `package.json`. Si un réglage
natif devient nécessaire (permission, plugin, FileProvider), il faudra basculer
en stratégie A (versionner `android/`) — tracé, pas anticipé.

**Identité et configuration Android (§30).** `capacitor.config.json` :
`appId = fr.prettozm.movenso.v3` (cohabite avec une V2 installée),
`appName = Movenso`, `webDir = dist`. `versionName` d'intention : `3.0.x` ;
`versionCode` : géré par la chaîne release (l'APK debug porte les valeurs par
défaut de Capacitor — assumé pour la recette). **Permissions minimales** :
aucune permission de stockage globale (le sélecteur système et OPFS
suffisent) ; la caméra passe par l'**intent système** via `<input capture>`
(pas de permission `CAMERA` détenue par l'app). Orientation libre, **tablette
prioritaire** (D-051). Sauvegarde Android auto : l'OPFS vit dans le stockage
privé, supprimé à la désinstallation (la propriété repose sur l'export).

**Export et partage Android (§31).** Mécanisme LIVRÉ : après production d'un
`.movpack`, l'app le **télécharge** via la WebView vers les Téléchargements de
l'appareil (accessibles depuis Files, Drive, une messagerie), et la sortie
(`dernierFichier`) **DIT** son nom, sa taille et son contenu — jamais un chemin
interne muet. **Share-sheet natif : DIFFÉRÉ, raison documentée** — (1) il exige
une vérification sur appareil réel, hors de portée de l'automatisation ; (2) le
seul chemin Capacitor disponible (`@capacitor/filesystem` en base64 +
`@capacitor/share`) chargerait le fichier entier en mémoire, ce qui casserait
la garantie de **mémoire bornée** du lot 8B sur les grosses sauvegardes.
Livrer un partage qui expose au dépassement mémoire serait une régression : on
préfère le mécanisme honnête existant et on trace la réserve.

**Signature et release (§33).** L'APK debug non signé sert la recette
(artefact CI `movenso-apk`). Chaîne release à préparer, jamais activée sans
secrets : `assembleRelease` + signature via un **keystore EXTERNE au dépôt**
(secrets CI : `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`,
`KEY_PASSWORD`), `versionCode`/`versionName` injectés, artefact APK/AAB. **Ne
jamais committer keystore, mot de passe ni secret** — le workflow reste
documenté et désactivé tant que les secrets n'existent pas.

**Matrice des plateformes (§36).**

| Cible | Statut | Build | Stockage | Import/Export | Caméra | Hors ligne | Partage | Signature | Limites |
|---|---|---|---|---|---|---|---|---|---|
| Android (Capacitor/WebView) | **livré ; recette Android** | `npx cap add/sync` + `gradlew assembleDebug` (CI `apk.yml`) | OPFS privé app | `.movpack` (téléchargement WebView) | intent système (`<input capture>`) | oui (tout local) | téléchargement Téléchargements (share-sheet natif différé) | debug non signé ; release documentée | mémoire bornée à confirmer sur gros fichiers (recette) |
| Navigateur desktop (Chromium) | **démontré** (e2e OPFS réel) | `npm run build` → `dist/` | OPFS origine | `.movpack` (téléchargement) | `<input capture>` selon navigateur | oui | téléchargement | — | quota navigateur ; effacement des données du site = tout perdu |
| PWA | **différée** (§34) | — | (serait OPFS même origine) | — | — | — | — | — | ni manifeste installable ni service worker : non livrée |
| Windows portable | **absent** (§35) | — | — | — | — | — | — | — | perte vs V2 : exécutable portable / stockage à côté de l'app — remplacé par Web+Android, pas d'équivalent ZIP portable |
| Electron | **absent** (§35) | — | — | — | — | — | — | — | non introduit ; réintroduction = arbitrage humain compact si besoin dur |

**Web et PWA (§34).** Cible **Web livrée** (application dans un navigateur,
OPFS, fonctionnement local après chargement selon le cache réel). **PWA
DIFFÉRÉE** : aucun `manifest.webmanifest` installable, aucun service worker,
aucun cache applicatif — la cible n'est donc PAS appelée « PWA ». Décision :
« Web uniquement, PWA différée » (pas de service worker fragile pour cocher une
case).

**Windows et Electron (§35).** **Electron : absent** depuis le début de V3 (non
introduit ici sans décision justifiée). Perte réelle par rapport à la V2 :
exécutable Windows portable, accès fichier plus direct, stockage à côté de
l'application. Ce que Web/Android remplacent : consultation et gestion hors
ligne, export/sauvegarde `.movpack` souverains. Ce qu'ils ne remplacent PAS :
un binaire portable Windows autonome. Si ce besoin redevient dur → **arbitrage
humain compact avant** d'ajouter Electron (jamais automatiquement).

## 5quinquies. Identité visuelle et système (lot 9)

**Direction (validée par l'humain, §2)** : **coque sombre, contenu clair**,
accent **vermillon** par défaut. La coque (en-tête de racine `.marque`, barre
supérieure `.barre`, navigation basse `.barre-nav`) est une surface sombre
stable dans les deux thèmes ; le contenu est clair (thème jour) et l'identité
martiale vient du contenu, des gestes, de la précision — jamais du folklore.

**Système de tokens (`src/styles/base.css`, §4)** — depuis S3.A5 (D-192),
`src/styles/app.css` est un INDEX de neuf feuilles thématiques importées dans
l'ordre des sections d'origine (cascade inchangée, une seule feuille au
build) : `base` (tokens/thèmes/reset), `shell`, `fiche`, `bibliotheque`,
`compositions`, `atelier`, `navigation`, `relations`, `capture`. Les tokens
vivent dans `base.css` ; anciens noms conservés en ALIAS :
- Surfaces : `--surface-shell`/`-2` (coque), `--surface-page`/`--surface`/
  `--surface-muted` (contenu), `--surface-media` (letterbox média).
- Textes : `--text-primary`, `--text-secondary`, `--text-on-shell`/`-mute`.
- Bordure : `--border-subtle`.
- Accent : `--accent-primary` = vermillon `#B23A26` par défaut, **suit la
  tonalité** (D-025, 6 accents) ; `--accent-sur-shell` = accent éclairci
  (`color-mix`) pour lecture SUR la coque sombre.
- Sémantiques FIXES (indépendantes de la tonalité, §28) : `--state-danger`,
  `--state-warning`, `--state-success`, `--state-info` (+ variantes `-doux`).
- Système : `--space-1..6`, `--radius-sm/md/pill`, `--ombre-elevee`, échelle
  typo `--t-page/section/technique/corps/meta/action/legende`.

**Thèmes (§3)** : jour (référence) ; nuit (même hiérarchie, surfaces
distinctes — jamais une simple inversion) ; système. La coque reste plus sombre
que le contenu en nuit. Les 6 tonalités s'appliquent en JOUR et NUIT (accent +
accent-sur-shell recalculés) ; les couleurs sémantiques ne changent JAMAIS avec
la tonalité.

**Couleur (§5, contrainte 2)** : le vermillon est le seul accent ; le **bleu
(indigo) est réservé** à une sémantique de provenance/source documentée (voix
Référentiel, badge de voix, relations) — jamais un second accent décoratif (les
initiales de repli et filets de bloc ont été neutralisés). L'ocre = savoir
personnel (carnet, favoris, captures).

**Provenance (§17)** : nom de source PRIORITAIRE, provenance en tag secondaire
(« Kodokan · Référentiel ») ; la couleur sémantique ne vit que sur le tag ;
jamais un état déduit de la seule couleur (toujours libellé/forme).

**Alertes (§28)** : trois niveaux — information/neutre, attention (`warning`),
erreur/danger (`danger`, rouge RÉSERVÉ à l'intégrité rompue, la suppression, la
perte). « À compléter » n'est PAS une erreur → voyant neutre.

**Responsive (§7, §31)** : téléphone (grille 2 colonnes, zones tactiles
confortables) ; tablette (grille auto-fill, largeur de LECTURE maîtrisée à ~62ch
pour le texte long, média non étiré ~620px, sans sur-colonnage) ; contenu centré
`max-width:980px` au-delà de 900px. Zones sûres via `env(safe-area-inset-*)`.

**Accessibilité (§29)** : `:focus-visible` (contour accent), `prefers-reduced-
motion` (animations désactivées), états jamais représentés par la seule couleur,
zones tactiles ≥ ~44px sur les actions.

**Architecture CSS (§35)** : un seul fichier de tokens + styles composant ; pas
de logique métier dans les styles. Classes réutilisables : `.barre`/`.marque`/
`.barre-nav` (coque), `.carte-*`, `.chip-filtre`, `.bouton`(`.principal`),
`.action-danger`, `.voyant` (vert/rouge/neutre), `.feuille`, `.toast`.

**Limites visuelles restantes** (tracées, non bloquantes) : (a) **famille
d'icônes SVG unique (§9)** — quelques emojis subsistent dans les menus/flux de
capture (🎞 🎥 🔗 🔒 🔓) ; les glyphes monochromes (→ ✓ ✕ ↑ ↓ ★) sont cohérents ;
une consolidation SVG complète reste à faire ; (b) **vue tablette côte à côte**
(fiche média-gauche / voix-droite, §31) non implémentée — le contenu reste
centré en une colonne large ; (c) **marque typographique** conservée (pas de
nouveau logo, §33).

## 6. Procédures

| Quoi | Comment |
|---|---|
| Développer | `npm ci` puis `npm run dev` (Vite, http://localhost:5173) |
| Tout vérifier | `npm run verifier` = typecheck + tests unitaires (node:test) + build + e2e Playwright (Chromium, OPFS réel) |
| e2e seul | `npm run build && npm run test:e2e` — A : vide-actionnable ; B : import + fusion des voix + capture + fiche ; F : composition verticale ; I : export complet → restauration sur installation vierge |
| Exporter / restaurer / publier | Dans l'app : **Plus › Créer ou exporter un pack** (sauvegarde complète ou pack de discipline/composition) et **Plus › Sauvegardes** ; import via **Plus › Importer un pack** |
| APK Android | workflow GitHub `apk`, **à la demande seulement** (D-197) → artefact `movenso-apk` (debug, `fr.prettozm.movenso.v3`). Plus de pack de démonstration (D-272) : les packs s'installent DANS l'app, par « Packs officiels » (D-213/D-219) |
| Convertir un pack V2 | `node --experimental-strip-types tools/convertir-movpack-v2.ts <in.movpack> <out.json> --pack <id> --discipline <Art> --provenance <referentiel|enseignement> --attribution <Source>` |
| Inspecter / emballer un pack | `node --experimental-strip-types tools/inspecter-movpack.ts <fichier.movpack>` · `tools/publier.ts` (chaîne complète : conteneurs + catalogue) |
| Release | Geste humain (pas de signing en CI — contrat §9.5) |

**Diagnostic** : les données vivent dans l'OPFS de l'app (Android : stockage
privé de l'app ; web : origine du site). `sauvegardes/` contient les snapshots
(rotation 10). Un import raté n'écrit rien (validation avant écriture) ; le
rapport d'import s'affiche en toast. Erreur « version plus récente que
l'application » = mettre à jour l'app, pas les données.

**Garde-fous CI** : le job `verifier` échoue si le produit change sans mise à
jour du présent (`docs/execution/STATE.md` — ou `docs/etat.md` par
compatibilité, D-014).

## 7. Reprendre le travail

1. Lire [execution/STATE.md](execution/STATE.md) — phase, réserves, prochaines actions.
2. Ce document pour la carte du système ; [workflows.md](workflows.md) pour
   la carte des parcours et leurs statuts ;
   [conventions.md](conventions.md) pour les règles (carte documentaire §2,
   statuts, marqueurs, doc au fil de l'eau §12, pièges de code §10).
3. Les capacités conservées / différées / sacrifiées : matrice historique
   [archives/increment-1.md](archives/increment-1.md) §6bis (les sacrifices
   récents sont au journal des décisions). Les choix d'exécution autonomes
   de la synthèse : D-021.
