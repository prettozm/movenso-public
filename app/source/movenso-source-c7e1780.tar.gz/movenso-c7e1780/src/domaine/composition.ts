/**
 * Compositions (D-020.1) : le savoir se RÉUTILISE — « Ma spéciale », un
 * programme de grade, un cours… Une composition référence des identités de
 * technique (jamais de duplication) ; ses transitions sont contextuelles,
 * distinctes des relations objectives du graphe (D-016, engagement figé).
 */

import type { Acteur, Bibliotheque, Bloc, Composition, Provenance, Technique, TypeBloc } from "./modele.ts";
import { genererUlid } from "./ulid.ts";

/** Une durée dite en toutes lettres pour la voix (D-125) : « 30 secondes »,
 *  « 5 minutes », « 1 minute 30 ». Base des annonces du chrono. */
export function dureeEnMots(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  const min = Math.floor(s / 60);
  const rest = s % 60;
  if (min === 0) return `${rest} seconde${rest > 1 ? "s" : ""}`;
  const mots = `${min} minute${min > 1 ? "s" : ""}`;
  return rest === 0 ? mots : `${mots} ${rest}`;
}

/** Annonce vocale au fil d'un segment minuté (D-125) — ou `null` si ce tic ne
 *  déclenche rien. Mi-temps (≥ 60 s), « 30 secondes » (> 40 s), « 10 secondes »
 *  (> 12 s pour ne pas doubler l'annonce d'entrée). Fonction PURE, testable. */
export function annonceCue(dureeSec: number, restant: number): string | null {
  if (dureeSec >= 60 && restant === Math.round(dureeSec / 2)) return "mi-temps";
  if (dureeSec > 40 && restant === 30) return "30 secondes";
  if (dureeSec > 12 && restant === 10) return "10 secondes";
  return null;
}

/** Les compositions qui référencent une identité — pour la fiche (« utilisée dans »). */
export function compositionsUtilisant(b: Bibliotheque, techniqueId: string): Composition[] {
  return b.compositions.filter((c) => c.blocs.some((x) => x.type === "technique" && x.techniqueId === techniqueId));
}

export function nouvelleComposition(
  nom: string,
  provenance: Provenance = "personnel",
  type?: Composition["type"],
): Composition {
  return {
    id: genererUlid(),
    nom,
    provenance,
    creeLe: new Date().toISOString(),
    ...(type ? { type } : {}),
    blocs: [],
  };
}

export function nouveauBloc(
  type: TypeBloc,
  contenu: { techniqueId?: string; texte?: string; consigne?: string; dureeSec?: number;
             acteurId?: string; lien?: boolean } = {},
): Bloc {
  return {
    id: genererUlid(),
    type,
    ...(contenu.techniqueId !== undefined ? { techniqueId: contenu.techniqueId } : {}),
    ...(contenu.texte !== undefined ? { texte: contenu.texte } : {}),
    ...(contenu.consigne !== undefined ? { consigne: contenu.consigne } : {}),
    ...(contenu.dureeSec !== undefined ? { dureeSec: contenu.dureeSec } : {}),
    ...(contenu.acteurId !== undefined ? { acteurId: contenu.acteurId } : {}),
    ...(contenu.lien ? { lien: true } : {}),
    medias: [],
  };
}

/** Acteur d'un bloc, résolu sur la composition (D-227). Rend `undefined` pour
 *  un bloc neutre OU pour une référence orpheline — jamais d'erreur. */
export function acteurDuBloc(composition: Composition, bloc: Bloc): Acteur | undefined {
  if (!bloc.acteurId) return undefined;
  return composition.acteurs?.find((a) => a.id === bloc.acteurId);
}

/** Prochain acteur PROPOSÉ à la saisie (D-227) : une séquence à deux est
 *  alternée neuf fois sur dix — on propose donc celui qui n'a pas agi en
 *  dernier. Sans acteurs, ou sans dernier bloc joué, rend le premier. */
export function acteurSuivantPropose(composition: Composition): string | undefined {
  const acteurs = composition.acteurs ?? [];
  if (acteurs.length === 0) return undefined;
  const dernier = [...composition.blocs].reverse().find((x) => x.acteurId);
  if (!dernier) return acteurs[0]!.id;
  const i = acteurs.findIndex((a) => a.id === dernier.acteurId);
  return i < 0 ? acteurs[0]!.id : acteurs[(i + 1) % acteurs.length]!.id;
}

/* ---------- temps et colonnes (D-229) : la composition lue comme un DIALOGUE ---------- */

/** Un TEMPS (D-229) : une phase de la séquence. Un bloc sans `lien` en ouvre un
 *  nouveau ; les blocs liés (simultané, réaction, puis) le rejoignent. Une
 *  composition sans aucun lien a donc exactement un temps par pas — le
 *  comportement historique, inchangé. */
export interface Temps {
  numero: number;
  blocs: Bloc[];
}

/** Ce bloc rejoint-il le temps du précédent ? (D-235) Lecture TOLÉRANTE : les
 *  valeurs héritées de D-229 sont réinterprétées sans rien réécrire sur disque —
 *  `simultane` rejoignait le temps, `puis` et `reaction` disaient une suite,
 *  donc un nouveau temps. Une composition jamais rouverte se lit juste. */
export function estLie(bloc: Bloc): boolean {
  return bloc.lien === true || bloc.lien === "simultane";
}

/** Découpe les blocs en temps (D-229/D-235). Les blocs `media` hérités
 *  (présentation d'avant D-124) sont écartés : ils ne sont pas des pas. */
export function decouperEnTemps(composition: Composition): Temps[] {
  const temps: Temps[] = [];
  for (const bloc of composition.blocs) {
    if (bloc.type === "media") continue;
    const dernier = temps.at(-1);
    if (estLie(bloc) && dernier) dernier.blocs.push(bloc);
    else temps.push({ numero: temps.length + 1, blocs: [bloc] });
  }
  return temps;
}

/** NORMALISE le regroupement en temps (D-235, garde-fou porteur). Idempotente,
 *  appelée à CHAQUE écriture — un seul chemin (`modifierComposition`) couvre
 *  donc l'ajout, la suppression, le déplacement, la duplication et l'import.
 *  Trois invariants : le premier pas n'ouvre rien d'autre que lui-même, un bloc
 *  média n'est pas un pas, et les valeurs héritées deviennent le booléen. */
export function normaliserTemps(composition: Composition): void {
  let premierPasVu = false;
  for (const bloc of composition.blocs) {
    if (bloc.type === "media") { delete bloc.lien; continue; }
    const lie = estLie(bloc) && premierPasVu; // le premier pas n'a rien à rejoindre
    if (lie) bloc.lien = true;
    else delete bloc.lien;
    premierPasVu = true;
  }
}

/** Retire un pas SANS déplacer le regroupement (D-235). Si le pas retiré
 *  OUVRAIT un temps, le suivant hérite du rôle d'ouvreur : le temps survit,
 *  amputé, au lieu d'être absorbé par le précédent. Sans cette règle,
 *  supprimer le 1er pas d'un temps y fusionnait silencieusement tous les
 *  autres — et supprimer le tout premier pas d'une composition rendait la
 *  bibliothèque invalide (lien sur le premier pas). */
export function retirerBloc(composition: Composition, blocId: string): void {
  const i = composition.blocs.findIndex((x) => x.id === blocId);
  if (i < 0) return;
  const retire = composition.blocs[i]!;
  const suivant = composition.blocs[i + 1];
  if (!estLie(retire) && suivant && estLie(suivant)) delete suivant.lien;
  composition.blocs.splice(i, 1);
  normaliserTemps(composition);
}

/** Vrai si la composition se lit en TRAME PAR TEMPS (D-231) — dès qu'il y a
 *  plusieurs rôles, ou qu'un pas est lié à son précédent. Le NOMBRE de voies
 *  affichées n'est PAS décidé ici : c'est la largeur disponible qui trancha,
 *  en CSS (une voie par rôle si ça tient, une seule colonne sinon). Le domaine
 *  ne connaît que les temps ; les temps restent lisibles dans les deux cas. */
export function lectureEnTemps(composition: Composition): boolean {
  return (composition.acteurs?.length ?? 0) >= 2 || composition.blocs.some((b) => b.lien !== undefined);
}

/** Répartit les blocs d'un temps entre les colonnes de rôle (D-229).
 *  `colonnes[i]` suit l'ordre de `composition.acteurs` ; un bloc neutre (ou
 *  dont le rôle a disparu) va dans `neutres` et se lit en pleine largeur. */
export function repartirTemps(composition: Composition, temps: Temps): { colonnes: Bloc[][]; neutres: Bloc[] } {
  const acteurs = composition.acteurs ?? [];
  const colonnes: Bloc[][] = acteurs.map(() => []);
  const neutres: Bloc[] = [];
  for (const bloc of temps.blocs) {
    const i = bloc.acteurId ? acteurs.findIndex((a) => a.id === bloc.acteurId) : -1;
    if (i >= 0) colonnes[i]!.push(bloc);
    else neutres.push(bloc);
  }
  return { colonnes, neutres };
}

/** Déplace le bloc `blocId` d'un cran (delta -1 = monter, +1 = descendre). Sans effet aux bords. */
export function deplacerBloc(composition: Composition, blocId: string, delta: -1 | 1): void {
  const i = composition.blocs.findIndex((x) => x.id === blocId);
  const j = i + delta;
  if (i < 0 || j < 0 || j >= composition.blocs.length) return;
  const liens = composition.blocs.map((x) => x.lien);
  const [bloc] = composition.blocs.splice(i, 1);
  composition.blocs.splice(j, 0, bloc!);
  reposerLiens(composition, liens);
}

/** Réattache les liens à leur POSITION après un réordonnancement (D-235) :
 *  échanger deux pas d'un MÊME temps ne doit jamais le scinder, et franchir une
 *  frontière de temps doit bien faire changer de temps — ce qui est le geste
 *  voulu. Un lien décrit une place dans la chaîne, pas une propriété du bloc. */
function reposerLiens(composition: Composition, liens: (Bloc["lien"])[]): void {
  composition.blocs.forEach((bloc, k) => {
    const l = liens[k];
    if (l === undefined) delete bloc.lien;
    else bloc.lien = l;
  });
  normaliserTemps(composition);
}

/** Réordonne : place le bloc `blocId` À l'emplacement du bloc `cibleId`
 *  (glisser-déposer). Le glissé prend la position de la cible ; les autres se
 *  décalent. Sans effet si l'un des deux est absent ou si c'est le même bloc. */
export function reordonnerBloc(composition: Composition, blocId: string, cibleId: string): void {
  if (blocId === cibleId) return;
  const i = composition.blocs.findIndex((x) => x.id === blocId);
  if (i < 0) return;
  const liens = composition.blocs.map((x) => x.lien);
  const [bloc] = composition.blocs.splice(i, 1);
  const j = composition.blocs.findIndex((x) => x.id === cibleId);
  if (j < 0) { composition.blocs.splice(i, 0, bloc!); return; } // cible disparue : on remet
  composition.blocs.splice(j, 0, bloc!);
  reposerLiens(composition, liens);
}

/** Durée d'un segment en libellé court (D-124) : « 45 s », « 5 min », « 1 h 05 ».
 *  Vit ici, aux côtés de `dureeEnMots`, depuis que la FICHE de composition en a
 *  besoin aussi (UI-2, D-319) : une information, un lieu — la recopier dans
 *  deux vues, c'est se préparer à ce qu'elles divergent. */
export function formaterDuree(sec: number): string {
  if (sec < 60) return `${Math.round(sec)} s`;
  const min = Math.round(sec / 60);
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  const r = min % 60;
  return r ? `${h} h ${`${r}`.padStart(2, "0")}` : `${h} h`;
}

/** Total d'une séance minutée (D-124) : somme des durées présentes des blocs. */
export function dureeTotale(compo: Composition): number {
  return compo.blocs.reduce((s, x) => s + (x.dureeSec ?? 0), 0);
}

/** Les techniques DÉJÀ SOUS LA MAIN pour le pas suivant (UI-4, D-322) : celles
 *  de la discipline du dernier pas technique de la composition ; à défaut, celles
 *  de la seule discipline installée ; sinon rien. Sert à ce que la recherche
 *  d'ajout ne s'ouvre pas sur un champ vide et une liste vide.
 *
 *  Ce n'est PAS un moteur de suggestion : aucune relation, aucune famille, aucun
 *  score — une dérivation de ce que la composition dit déjà, et rien de plus
 *  (les suggestions par relations restent hors périmètre, dossier §6). */
export function techniquesAPortee(
  b: { techniques: Technique[]; disciplines: { id: string }[] },
  composition: Composition | undefined,
  limite = 6,
): Technique[] {
  let disciplineId: string | undefined;
  for (let i = (composition?.blocs.length ?? 0) - 1; i >= 0 && !disciplineId; i--) {
    const id = composition!.blocs[i]!.techniqueId;
    disciplineId = id ? b.techniques.find((t) => t.id === id)?.disciplineId : undefined;
  }
  if (!disciplineId && b.disciplines.length === 1) disciplineId = b.disciplines[0]!.id;
  return disciplineId ? b.techniques.filter((t) => t.disciplineId === disciplineId).slice(0, limite) : [];
}
