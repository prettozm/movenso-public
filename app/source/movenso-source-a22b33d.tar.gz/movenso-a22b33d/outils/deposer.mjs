/**
 * DÉPOSER vers le site public (D-281) — le seul geste qui écrit hors du dépôt.
 *
 *   node outils/deposer.mjs --vers <dossier-site> [--sans-app]
 *
 * Quatre gestes, et ils ne se confondent pas :
 *
 *   1. `npm run publier`          PRODUIRE   → dist-publication/, rien d'autre
 *   2. `npm run verifier:release` VALIDER    → tout est-il cohérent ?
 *   3. le porteur                 AUTORISER  → il sait ce qu'il distribue
 *   4. `npm run deposer`          DÉPOSER    → écrit dans le dépôt public
 *
 * Tant que produire et déposer tenaient dans une option (`publier --vers`),
 * une frappe distraite publiait. La séparation n'est pas cosmétique : c'est la
 * même raison qui fait qu'on n'envoie pas un courrier en le rédigeant.
 *
 * Ce geste-ci REFUSE de partir seul : il rejoue `verifier:release` — le
 * script npm COMPLET, `verifier` compris ; il a dit « rejoue » en n'appelant
 * que le second étage, c'était un mensonge de doc (D-287) —, dépose
 * application + packs + source **ensemble** (D-267 ; `--sans-app` supprimé
 * sur décision porteur, D-287), puis relance la garde du site. Il ne pousse
 * rien — le commit et la poussée restent des gestes humains.
 *
 * L'ordre du dépôt est une transaction de fait (D-287) : l'étape qui peut
 * REFUSER (la source, qui exige un arbre propre) part en PREMIER — si elle
 * échoue, le site n'a pas été touché. `build.json` annonce alors le commit
 * neuf, et les fichiers de l'app partent en DERNIER : tout état partiel
 * laisse la garde d'après-dépôt ROUGE, c'est la copie finale qui la rend
 * verte. Limite dite : ce n'est pas une transaction atomique — c'est un ordre
 * qui rend chaque interruption VISIBLE au lieu de plausible.
 */
import { execSync, execFileSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync, readdirSync, rmSync, mkdirSync, cpSync } from "node:fs";
import { join } from "node:path";

const i = process.argv.indexOf("--vers");
const site = i >= 0 ? process.argv[i + 1] : null;
if (!site) {
  console.error("deposer : --vers <dossier-site> est obligatoire.");
  process.exit(2);
}
if (!existsSync(site)) {
  console.error(`deposer : ${site} introuvable.`);
  process.exit(2);
}
/* ---------- 2. VALIDER — jamais sauté, et TOUT le troisième niveau ---------- */
console.log("→ validation (verifier:release, verifier complet compris)…\n");
try {
  execSync(`npm run verifier:release --silent -- --site ${JSON.stringify(site)}`, { stdio: "inherit" });
} catch {
  console.error("\ndeposer : la validation a échoué — rien n'a été déposé.");
  process.exit(1);
}

/* ---------- 4. DÉPOSER — app, packs et source ENSEMBLE ---------- */
console.log("\n→ dépôt…");
// La source d'abord : elle refuse un arbre sale, et tant qu'elle n'a pas
// accepté, RIEN n'a été écrit dans le site.
try {
  execSync(`node tools/source-du-build.mjs --vers ${JSON.stringify(site)}`, { stdio: "inherit" });
} catch {
  console.error("\ndeposer : la source correspondante a refusé — rien n'a été déposé.");
  process.exit(1);
}

const packs = JSON.parse(readFileSync("publication/packs.json", "utf8"));
for (const p of packs) cpSync(join("dist-publication/packs", p.fichier), join(site, "packs", p.fichier));
cpSync("dist-publication/index.json", join(site, "packs", "index.json"));
console.log(`  ${packs.length} packs + catalogue`);

// Les anciens fichiers hachés du build ne doivent pas survivre au nouveau :
// ils resteraient servis sans que rien ne les référence. L'app part en
// DERNIER — voir l'en-tête : c'est elle qui rend la garde verte.
const assets = join(site, "app", "assets");
if (existsSync(assets)) rmSync(assets, { recursive: true });
mkdirSync(assets, { recursive: true });
cpSync("dist/assets", assets, { recursive: true });
for (const f of readdirSync("dist").filter((f) => f !== "assets")) cpSync(join("dist", f), join(site, "app", f));
console.log("  application (dist/)");

/* ---------- contrôle APRÈS dépôt ---------- */
console.log("\n→ garde du site, après dépôt…");
try {
  console.log(execSync("node verifier-catalogues.mjs", { cwd: site, encoding: "utf8" }).trim());
} catch (e) {
  console.error(String(e.stdout ?? e.message).trim());
  console.error("\ndeposer : le dépôt est FAIT mais la garde le refuse — ne pas committer, corriger d'abord.");
  process.exit(1);
}

const etat = execFileSync("git", ["status", "--porcelain"], { cwd: site, encoding: "utf8" }).trim();
console.log(`\ndeposer : ${etat.split("\n").filter(Boolean).length} fichier(s) modifiés dans ${site}.`);
console.log("Le commit et la poussée restent des gestes HUMAINS — relire le diff avant.");
