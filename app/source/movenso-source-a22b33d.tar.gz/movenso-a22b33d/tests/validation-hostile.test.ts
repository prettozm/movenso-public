/**
 * D-255 — un pack tiers peut porter n'importe quoi dans un champ FACULTATIF.
 *
 * Ces champs n'étaient pas validés : `alertes: {}` passait `validerBibliotheque`
 * puis cassait l'affichage de la fiche sur `alertes.map`. Un état invalide
 * franchissait donc l'import pour planter plus tard, loin de sa cause.
 *
 * Chaque cas ci-dessous est ACCEPTÉ par le validateur d'avant le correctif.
 * La contrepartie est testée juste après : ce qui est légitime reste accepté —
 * une validation qui refuse trop est aussi grave qu'une validation qui laisse
 * passer, elle rendrait des packs publiés impossibles à installer.
 */

import test from "node:test";
import assert from "node:assert/strict";
import { validerBibliotheque, ErreurValidation } from "../src/domaine/validation.ts";
import { bibliotheque, disciplineJudo, technique, contribution } from "./aide.ts";
import { genererUlid } from "../src/domaine/ulid.ts";

/** Construit une bibliothèque d'une technique portant `patch`. */
function avecTechnique(patch: Record<string, unknown>) {
  const judo = disciplineJudo();
  const t = technique(judo.id, patch as never);
  return bibliotheque({ disciplines: [judo], techniques: [t], contributions: [] });
}

const refuse = (b: Parameters<typeof validerBibliotheque>[0], quoi: string) =>
  assert.throws(() => validerBibliotheque(b), ErreurValidation, `${quoi} doit être REFUSÉ`);

test("alertes : seul un tableau d'alertes complètes est accepté", () => {
  refuse(avecTechnique({ alertes: {} }), "alertes en objet");
  refuse(avecTechnique({ alertes: "interdit en compétition" }), "alertes en chaîne");
  refuse(avecTechnique({ alertes: [{}] }), "alerte sans type ni libellé");
  refuse(avecTechnique({ alertes: [{ type: "ijf", libelle: "Interdite" }] }), "alerte sans niveau");
  refuse(avecTechnique({ alertes: [{ type: "ijf", libelle: "Interdite", niveau: "critique" }] }), "niveau inconnu");
  refuse(avecTechnique({ alertes: [{ type: "ijf", libelle: "X", niveau: "danger", bloquante: "oui" }] }), "bloquante non booléenne");
  refuse(avecTechnique({ alertes: [{ type: "ijf", libelle: "X", niveau: "danger", reference: "IJF" }] }), "référence non objet");

  // Légitime : l'alerte complète des packs publiés.
  validerBibliotheque(avecTechnique({
    alertes: [{ type: "ijf", niveau: "danger", libelle: "Interdite en compétition IJF", detail: "Depuis 2010", bloquante: true, reference: { organisation: "IJF" } }],
  }));
});

test("couverture : image DÉCLARÉE à l'inventaire, ou média désigné par un ULID", () => {
  const EMPREINTE = "a".repeat(64);
  refuse(avecTechnique({ couverture: { type: "inconnu" } }), "type de couverture inconnu");
  refuse(avecTechnique({ couverture: 42 }), "couverture numérique");
  refuse(avecTechnique({ couverture: { type: "fichier" } }), "renvoi sans imageId");
  refuse(avecTechnique({ couverture: { type: "fichier", imageId: "pas-une-empreinte" } }), "imageId hors format");
  refuse(avecTechnique({ couverture: { type: "image", dataUrl: "data:image/jpeg;base64,/9j/" } }), "base64 inline : la forme du schéma 5 n'est plus acceptée");
  refuse(avecTechnique({ couverture: { type: "media", mediaId: "pas-un-ulid" } }), "média mal formé");

  // Le piège que la validation doit tenir (D-269) : une couverture qui désigne
  // une image que RIEN ne déclare. Elle ne s'affichera jamais, et personne ne
  // saurait dire pourquoi — on la refuse à l'écriture.
  refuse(avecTechnique({ couverture: { type: "fichier", imageId: EMPREINTE } }), "image non déclarée à l'inventaire");

  const declaree = avecTechnique({ couverture: { type: "fichier", imageId: EMPREINTE } });
  declaree.images = [{ id: EMPREINTE, mime: "image/jpeg", taille: 128 }];
  validerBibliotheque(declaree);
  validerBibliotheque(avecTechnique({ couverture: { type: "media", mediaId: genererUlid() } }));
});

test("inventaire des images : empreintes uniques, MIME d'image, taille réelle", () => {
  const EMPREINTE = "b".repeat(64);
  const avecInventaire = (images: unknown) => {
    const b = avecTechnique({});
    (b as { images?: unknown }).images = images;
    return b;
  };
  refuse(avecInventaire("pas un tableau"), "inventaire non tableau");
  refuse(avecInventaire([{ id: "court", mime: "image/jpeg", taille: 1 }]), "identité hors format");
  refuse(avecInventaire([{ id: EMPREINTE, mime: "video/webm", taille: 1 }]), "MIME qui n'est pas une image");
  refuse(avecInventaire([{ id: EMPREINTE, mime: "image/jpeg", taille: 0 }]), "taille nulle");
  refuse(
    avecInventaire([{ id: EMPREINTE, mime: "image/jpeg", taille: 1 }, { id: EMPREINTE, mime: "image/png", taille: 2 }]),
    "deux déclarations contradictoires des mêmes octets",
  );
  validerBibliotheque(avecInventaire([{ id: EMPREINTE, mime: "image/jpeg", taille: 4096 }]));
});

test("origine : un pack et un élément, sinon la source affichée est fausse", () => {
  refuse(avecTechnique({ origine: "pack-judo" }), "origine en chaîne");
  refuse(avecTechnique({ origine: {} }), "origine vide");
  refuse(avecTechnique({ origine: { pack: "pack-judo" } }), "origine sans element");
  refuse(avecTechnique({ origine: { pack: "", element: "x" } }), "pack vide");

  validerBibliotheque(avecTechnique({ origine: { pack: "pack-judo", element: "o-soto-gari" } }));
});

test("un champ qu'on parcourt est refusé proprement, jamais par une erreur technique", () => {
  // Avant D-255 : « t.relations is not iterable » — un message de moteur JS,
  // pas un refus. Le message doit désormais dire ce qui ne va pas.
  const b = avecTechnique({ relations: {} });
  assert.throws(() => validerBibliotheque(b), (e: Error) => {
    assert.ok(e instanceof ErreurValidation, "un refus, pas un TypeError");
    assert.match(e.message, /relations.*tableau/i, "le message nomme le champ fautif");
    return true;
  });

  refuse(avecTechnique({ niveauxIds: "gokyo-1" }), "niveaux en chaîne");
  const judo = disciplineJudo();
  const t = technique(judo.id);
  refuse(bibliotheque({ disciplines: [judo], techniques: [t], contributions: [contribution(t.id, { pointsCles: {} as never })] }), "points clés en objet");
  refuse(bibliotheque({ disciplines: [judo], techniques: {} as never, contributions: [] }), "collection de techniques en objet");
});

test("non-régression : une bibliothèque nominale reste valide", () => {
  validerBibliotheque(bibliotheque());
});

/* ---------- D-271 — les champs facultatifs RESTANTS (audit porteur) ----------
 *
 * D-255 avait couvert alertes, couverture et origine. L'audit du 2026-08-10 a
 * montré que le reste passait toujours : une priorité de relation en texte,
 * une note en objet, une taille de média en toutes lettres, et les types
 * d'alerte de la bibliothèque, jamais validés du tout.
 *
 * Ce ne sont pas des champs décoratifs : `priorite` ORDONNE l'affichage des
 * liens, `taille` entre dans le calcul d'espace, `extension` compose le NOM
 * PHYSIQUE du fichier vidéo.
 */

/** Une bibliothèque d'une technique et d'une contribution portant `medias`. */
function avecMedia(patch: Record<string, unknown>) {
  const judo = disciplineJudo();
  const t = technique(judo.id, {} as never);
  const c = contribution(t.id, { medias: [{ id: genererUlid(), type: "lien", ref: "https://exemple.test/a", ...patch }] } as never);
  return bibliotheque({ disciplines: [judo], techniques: [t], contributions: [c] });
}

test("relation : la note s'affiche et la priorité ordonne — donc elles sont typées", () => {
  const lien = (patch: Record<string, unknown>) =>
    avecTechnique({ relations: [{ type: "prepare", cibleId: genererUlid(), ...patch }] });
  refuse(lien({ priorite: "forte" }), "priorité en texte");
  refuse(lien({ priorite: 1.5 }), "priorité fractionnaire");
  refuse(lien({ priorite: 0 }), "priorité nulle (elle commence à 1)");
  refuse(lien({ note: {} }), "note en objet");
  refuse(avecTechnique({ relations: ["prepare"] }), "relation qui n'est pas un objet");

  validerBibliotheque(lien({ note: "le balayage ouvre l'arrière", priorite: 1 }));
  validerBibliotheque(lien({}));
});

test("média : les métadonnées facultatives décident de l'espace et du nom de fichier", () => {
  refuse(avecMedia({ label: {} }), "libellé en objet");
  refuse(avecMedia({ taille: "beaucoup" }), "taille en toutes lettres");
  refuse(avecMedia({ taille: -1 }), "taille négative");
  refuse(avecMedia({ mime: 42 }), "MIME numérique");
  refuse(avecMedia({ extension: "../../etc/passwd" }), "extension qui compose un chemin");
  refuse(avecMedia({ sha256: "pas-une-empreinte" }), "empreinte mal formée");
  refuse(avecMedia({ origineMedia: "telepathie" }), "origine inconnue");

  validerBibliotheque(avecMedia({
    label: "Démonstration", mime: "video/webm", extension: "webm", taille: 3072,
    sha256: "a".repeat(64), origineMedia: "fichier", nomOriginal: "demo.webm",
    ajouteLe: new Date(0).toISOString(),
  }));
});

test("typesAlerte : ils voyagent dans les packs, l'affichage les parcourt", () => {
  const avecTypes = (v: unknown) => {
    const b = avecTechnique({});
    (b as { typesAlerte?: unknown }).typesAlerte = v;
    return b;
  };
  refuse(avecTypes({}), "objet au lieu d'un tableau");
  refuse(avecTypes([42]), "entrée qui n'est pas un objet");
  refuse(avecTypes([{ id: "ijf", libelle: "IJF" }]), "type sans niveau");
  refuse(avecTypes([{ id: "ijf", libelle: "IJF", niveau: "critique" }]), "niveau inconnu");
  refuse(avecTypes([{ id: "ijf", libelle: "A", niveau: "info" }, { id: "ijf", libelle: "B", niveau: "info" }]), "id en double");

  validerBibliotheque(avecTypes([{ id: "ijf", libelle: "Interdite en compétition", niveau: "danger", icone: "⚠" }]));
  validerBibliotheque(avecTypes(undefined));
});

test("conflits proposés par un pack : ils voyagent dans une sauvegarde, « À traiter » les parcourt (D-298)", () => {
  // Même classe que typesAlerte (D-271) : un champ jamais validé qui traverse
  // la frontière de restauration, puis casse au premier parcours.
  const avec = (champ: "conflitsLiaisons" | "conflitsContributions" | "editionsPacks", v: unknown) => {
    const b = avecTechnique({});
    (b as unknown as Record<string, unknown>)[champ] = v;
    return b;
  };
  refuse(avec("conflitsLiaisons", {}), "objet au lieu d'un tableau");
  refuse(avec("conflitsLiaisons", [42]), "entrée qui n'est pas un objet");
  refuse(avec("conflitsLiaisons", [{ pack: "p", sourceId: "s", cibleId: "c", type: "t" }]), "conflit sans date de détection");
  refuse(avec("conflitsLiaisons", [{ pack: "p", sourceId: "s", cibleId: "c", type: "t", detecteLe: "d", sens: "fusion" }]), "sens inconnu");
  validerBibliotheque(avec("conflitsLiaisons", [{ pack: "p", sourceId: "s", cibleId: "c", type: "t", detecteLe: "d", sens: "retrait" }]));
  validerBibliotheque(avec("conflitsLiaisons", undefined));

  refuse(avec("editionsPacks", {}), "objet au lieu d'un tableau");
  refuse(avec("editionsPacks", [{ pack: "p", versionEditoriale: 0, majLe: "d" }]), "édition < 1");
  refuse(avec("editionsPacks", [{ pack: "p", versionEditoriale: "11", majLe: "d" }]), "édition non numérique");
  refuse(avec("editionsPacks", [{ pack: "p", versionEditoriale: 1, majLe: "d" }, { pack: "p", versionEditoriale: 2, majLe: "d" }]), "deux éditions pour le même pack");
  validerBibliotheque(avec("editionsPacks", [{ pack: "p", versionEditoriale: 11, majLe: "2026-08-12" }]));
  validerBibliotheque(avec("editionsPacks", undefined));

  refuse(avec("conflitsContributions", {}), "objet au lieu d'un tableau");
  refuse(avec("conflitsContributions", [{ pack: "p", element: "e", contributionId: "c", detecteLe: "d" }]), "conflit sans pointsCles");
  refuse(avec("conflitsContributions", [{ pack: "p", element: "e", contributionId: "c", detecteLe: "d", pointsCles: [42] }]), "point clé non textuel");
  validerBibliotheque(avec("conflitsContributions", [{ pack: "p", element: "e", contributionId: "c", detecteLe: "d", pointsCles: ["a"], description: "x" }]));
  validerBibliotheque(avec("conflitsContributions", undefined));
});
