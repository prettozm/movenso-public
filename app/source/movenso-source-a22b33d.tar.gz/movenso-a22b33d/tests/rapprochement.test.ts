/** Les six propriétés du rapprochement (D-015) — chacune a son test. */

import { test } from "node:test";
import assert from "node:assert/strict";
import type { Bibliotheque } from "../src/domaine/modele.ts";
import { bibliothequeVide } from "../src/domaine/modele.ts";
import { genererUlid } from "../src/domaine/ulid.ts";
import { importerDansBibliotheque, doublonsPotentiels, arbitrerConflitLiaison, arbitrerConflitContribution, ErreurRapprochement } from "../src/domaine/rapprochement.ts";
import { relationsPourFiche } from "../src/domaine/relations.ts";
import { composition, contribution, disciplineJudo, technique } from "./aide.ts";

/** Fabrique un pack (bibliothèque à une discipline) avec origines posées. */
function pack(packId: string, nomDiscipline: string, noms: string[], options: { relations?: [string, string][] } = {}): Bibliotheque {
  const d = disciplineJudo({ nom: nomDiscipline });
  const techniques = noms.map((nom, i) =>
    technique(d.id, { nom, origine: { pack: packId, element: `e${i}` } }),
  );
  for (const [de, vers] of options.relations ?? []) {
    const source = techniques.find((t) => t.nom === de)!;
    const cible = techniques.find((t) => t.nom === vers)!;
    source.relations.push({ type: "prepare", cibleId: cible.id });
  }
  const contributions = techniques.map((t, i) =>
    contribution(t.id, {
      provenance: "enseignement",
      attribution: packId,
      description: `desc ${t.nom}`,
      origine: { pack: packId, element: `e${i}` },
    }),
  );
  return { ...bibliothequeVide(), disciplines: [d], techniques, contributions };
}

test("propriété 1 (D-067) — deux packs de même nom → deux identités distinctes, chacune liée à son pack", () => {
  const base = importerDansBibliotheque(bibliothequeVide(), pack("kodokan", "Judo", ["Harai-goshi"]), { packId: "kodokan" });
  const { bibliotheque: b, rapport } = importerDansBibliotheque(
    base.bibliotheque,
    pack("club", "Judo", ["Harai Goshi"]),
    { packId: "club" },
  );
  // AUCUNE fusion automatique : deux fiches indépendantes dans la même discipline.
  assert.equal(b.techniques.length, 2, "un homonyme d'un autre pack reste une identité distincte");
  assert.equal(b.disciplines.length, 1, "la discipline, elle, reste unique (rejointe par nom)");
  assert.deepEqual(rapport.rejointes, [], "rien n'est fusionné automatiquement");
  assert.deepEqual(rapport.creees, ["Harai Goshi"]);
  assert.deepEqual(rapport.suggestions, [], "un homonyme exact seul ne génère aucun bruit");
  // Chaque identité porte son pack et sa propre contribution — jamais mêlées.
  const parPack = new Map(b.techniques.map((t) => [t.origine!.pack, t]));
  for (const packId of ["kodokan", "club"]) {
    const t = parPack.get(packId)!;
    const contribs = b.contributions.filter((c) => c.techniqueId === t.id);
    assert.equal(contribs.length, 1, `« ${packId} » n'éclaire que sa propre identité`);
    assert.equal(contribs[0]!.origine!.pack, packId);
  }

  // Même nom, discipline différente : distinct aussi, deux disciplines.
  const autre = importerDansBibliotheque(b, pack("karate", "Karaté", ["Harai Goshi"]), { packId: "karate" });
  assert.equal(autre.bibliotheque.techniques.length, 3);
  assert.equal(autre.bibliotheque.disciplines.length, 2);
});

test("propriété 2 — jamais de fusion silencieuse : l'ambigu reste distinct et signalé", () => {
  let b = importerDansBibliotheque(bibliothequeVide(), pack("a", "Judo", ["Kata-guruma"]), { packId: "a" }).bibliotheque;
  // Deux identités homonymes préexistantes (cas pathologique volontaire).
  const judo = b.disciplines[0]!;
  b.techniques.push(technique(judo.id, { nom: "Kata guruma" }));
  const resultat = importerDansBibliotheque(b, pack("c", "Judo", ["KATA GURUMA"]), { packId: "c" });
  assert.equal(resultat.rapport.suggestions[0]?.motif, "ambigu");
  assert.equal(resultat.bibliotheque.techniques.length, 3, "identité distincte créée, pas de fusion");
});

test("propriété 3 — traçabilité : identités créées et contributions portent pack + élément", () => {
  const { bibliotheque: b } = importerDansBibliotheque(bibliothequeVide(), pack("club", "Judo", ["O Goshi"]), { packId: "club" });
  assert.deepEqual(b.techniques[0]!.origine, { pack: "club", element: "e0" });
  assert.deepEqual(b.contributions[0]!.origine, { pack: "club", element: "e0" });
});

test("propriété 4 — réimport idempotent : même pack deux fois → même bibliothèque ; élément disparu → retiré", () => {
  const p = pack("club", "Judo", ["O Goshi", "Uki Goshi"]);
  const une = importerDansBibliotheque(bibliothequeVide(), p, { packId: "club" }).bibliotheque;
  const deux = importerDansBibliotheque(une, structuredClone(p), { packId: "club" }).bibliotheque;
  assert.deepEqual(deux, une, "réimport sans effet");

  // Le pack évolue : « Uki Goshi » disparaît, plus rien ne s'y rattache → retirée.
  const reduit = pack("club", "Judo", ["O Goshi"]);
  const trois = importerDansBibliotheque(deux, reduit, { packId: "club" });
  assert.deepEqual(trois.rapport.retirees, ["Uki Goshi"]);
  assert.equal(trois.bibliotheque.techniques.length, 1);

  // Mais une identité qui porte une capture personnelle survit au retrait.
  const avecCapture = structuredClone(deux);
  const uki = avecCapture.techniques.find((t) => t.nom === "Uki Goshi")!;
  avecCapture.contributions.push(contribution(uki.id, { description: "ma note" }));
  const quatre = importerDansBibliotheque(avecCapture, structuredClone(reduit), { packId: "club" });
  assert.ok(quatre.bibliotheque.techniques.some((t) => t.nom === "Uki Goshi"), "le savoir personnel protège l'identité");
});

test("D-222 — mise à jour d'un pack : sous-titre et couverture FOURNIS remplacent, un champ absent ne retire rien", () => {
  const v1 = pack("officiel", "Yoga", ["Montagne", "Arbre"]);
  const une = importerDansBibliotheque(bibliothequeVide(), v1, { packId: "officiel" }).bibliotheque;
  // Adaptations locales AVANT la mise à jour : une couverture posée sur « Arbre ».
  const arbre = une.techniques.find((t) => t.nom === "Arbre")!;
  const LOCALE = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
  arbre.couverture = { type: "fichier", imageId: LOCALE };
  une.images = [{ id: LOCALE, mime: "image/jpeg", taille: 12 }];
  // v2 du pack : « Montagne » gagne sous-titre + couverture ; « Arbre » n'apporte rien.
  const v2 = pack("officiel", "Yoga", ["Montagne", "Arbre"]);
  const montagneV2 = v2.techniques.find((t) => t.nom === "Montagne")!;
  montagneV2.nomTraditionnel = "Tadasana";
  const DU_PACK = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
  montagneV2.couverture = { type: "fichier", imageId: DU_PACK };
  v2.images = [{ id: DU_PACK, mime: "image/jpeg", taille: 34 }];
  const { bibliotheque: b } = importerDansBibliotheque(une, v2, { packId: "officiel" });
  const montagne = b.techniques.find((t) => t.nom === "Montagne")!;
  assert.equal(montagne.nomTraditionnel, "Tadasana", "le sous-titre fourni par le pack propriétaire s'applique à la mise à jour");
  assert.equal(montagne.couverture?.type === "fichier" && montagne.couverture.imageId, DU_PACK, "la couverture fournie s'applique");
  const arbreApres = b.techniques.find((t) => t.nom === "Arbre")!;
  assert.equal(arbreApres.couverture?.type === "fichier" && arbreApres.couverture.imageId, LOCALE, "un pack SANS couverture ne retire pas celle posée localement");
  assert.ok(b.images?.some((i) => i.id === LOCALE), "l'image locale reste DÉCLARÉE tant qu'une couverture la désigne");
  assert.ok(b.images?.some((i) => i.id === DU_PACK), "l'inventaire du pack a rejoint le nôtre");
  // Et le sous-titre se met aussi À JOUR (pas seulement se complète) :
  const v3 = structuredClone(v2);
  v3.techniques.find((t) => t.nom === "Montagne")!.nomTraditionnel = "Tadasana (montagne)";
  const apresV3 = importerDansBibliotheque(b, v3, { packId: "officiel" }).bibliotheque;
  assert.equal(apresV3.techniques.find((t) => t.nom === "Montagne")!.nomTraditionnel, "Tadasana (montagne)");
});

test("propriété 5 — quasi-correspondance : identité distincte + suggestion ; règle arbitrée → rapprochement déterministe", () => {
  const base = importerDansBibliotheque(bibliothequeVide(), pack("kodokan", "Judo", ["De-ashi-harai"]), { packId: "kodokan" }).bibliotheque;
  // Sans règle : pas de fusion, suggestion explicite.
  const sans = importerDansBibliotheque(base, pack("club", "Judo", ["De Ashi Barai"]), { packId: "club" });
  assert.equal(sans.bibliotheque.techniques.length, 2);
  assert.deepEqual(sans.rapport.suggestions, [
    { nom: "De Ashi Barai", candidats: ["De-ashi-harai"], motif: "quasi-correspondance" },
  ]);
  // Avec la règle issue de l'arbitrage : fusion déterministe.
  const avec = importerDansBibliotheque(base, pack("club", "Judo", ["De Ashi Barai"]), {
    packId: "club",
    regles: [{ de: "De Ashi Barai", vers: "De-ashi-harai" }],
  });
  assert.equal(avec.bibliotheque.techniques.length, 1);
  assert.deepEqual(avec.rapport.rejointes, ["De Ashi Barai"]);
  // Une règle qui ne pointe sur rien est une erreur franche, pas un silence.
  assert.throws(
    () => importerDansBibliotheque(base, pack("club", "Judo", ["X"]), { packId: "club", regles: [{ de: "X", vers: "Inexistante" }] }),
    ErreurRapprochement,
  );
});

test("propriété 6 (D-067) — relations réécrites vers les identités DU PACK, sans doublon ni fuite entre packs", () => {
  const base = importerDansBibliotheque(bibliothequeVide(), pack("kodokan", "Judo", ["O-soto-gari", "Ko-uchi-gari"]), { packId: "kodokan" }).bibliotheque;
  const club = pack("club", "Judo", ["O Soto Gari", "Ko Uchi Gari"], { relations: [["Ko Uchi Gari", "O Soto Gari"]] });
  const { bibliotheque: b } = importerDansBibliotheque(base, club, { packId: "club" });
  // Quatre identités distinctes (aucune fusion) ; la relation du club vit
  // ENTRE les identités du club, jamais vers celles du kodokan.
  assert.equal(b.techniques.length, 4);
  const osotoClub = b.techniques.find((t) => t.nom === "O Soto Gari")!;
  const osotoKodokan = b.techniques.find((t) => t.nom === "O-soto-gari")!;
  assert.deepEqual(
    relationsPourFiche(b, osotoClub.id).map((r) => r.libelle),
    ["Préparée par"],
    "la relation du club éclaire l'identité du club",
  );
  assert.deepEqual(relationsPourFiche(b, osotoKodokan.id), [], "l'identité kodokan reste intacte");
  // La cible de la relation est bien l'identité du club, jamais celle du kodokan.
  const kouchiClub = b.techniques.find((t) => t.nom === "Ko Uchi Gari")!;
  assert.deepEqual(kouchiClub.relations, [{ type: "prepare", cibleId: osotoClub.id }]);
  // Réimport : la relation ne se duplique pas.
  const encore = importerDansBibliotheque(b, structuredClone(club), { packId: "club" }).bibliotheque;
  const kouchi = encore.techniques.find((t) => t.nom === "Ko Uchi Gari")!;
  assert.equal(kouchi.relations.length, 1);
});

test("la complétion enrichit sans écraser (kanji, famille, niveaux) — via une règle explicite (D-067)", () => {
  const kodokan = pack("kodokan", "Judo", ["Harai-goshi"]);
  kodokan.techniques[0]!.nomTraditionnel = "払腰";
  const club = pack("club", "Judo", ["Harai Goshi"]);
  club.disciplines[0]!.niveaux = [{ id: "jaune", nom: "Jaune" }];
  club.techniques[0]!.niveauxIds = ["jaune"];
  let b = importerDansBibliotheque(bibliothequeVide(), kodokan, { packId: "kodokan" }).bibliotheque;
  // Sans règle : deux identités distinctes (D-067). La complétion n'a lieu que
  // lors d'une réunion EXPLICITE.
  const distinct = importerDansBibliotheque(b, structuredClone(club), { packId: "club" }).bibliotheque;
  assert.equal(distinct.techniques.length, 2, "sans règle, aucune fusion — donc aucune complétion");
  // Avec la règle d'arbitrage : la réunion complète sans écraser.
  b = importerDansBibliotheque(b, club, { packId: "club", regles: [{ de: "Harai Goshi", vers: "Harai-goshi" }] }).bibliotheque;
  assert.equal(b.techniques.length, 1, "la règle réunit les deux identités");
  const t = b.techniques[0]!;
  assert.equal(t.nomTraditionnel, "払腰", "le kanji du référentiel n'est pas écrasé");
  assert.ok(t.niveauxIds.includes("jaune"), "la ceinture du club complète l'identité");
  assert.ok(t.niveauxIds.includes("gokyo-1"), "sans écraser les niveaux existants");
});

test("D-027 — une réimportation restaure l'original et n'écrase jamais l'adaptation locale", () => {
  const kodokan = pack("kodokan", "Judo", ["Harai-goshi"]);
  let b = importerDansBibliotheque(bibliothequeVide(), kodokan, { packId: "kodokan" }).bibliotheque;
  const idTech = b.techniques[0]!.id;

  // Adaptation locale (invariants 58-59) : contribution SANS origine,
  // préremplie depuis la voix source, attribuée lisiblement.
  const originale = b.contributions.find((c) => c.origine?.pack === "kodokan")!;
  const adaptation = contribution(idTech, {
    description: "Ma version : kuzushi plus court",
    attribution: "Adaptation locale d'après kodokan",
  });
  b.contributions.push(adaptation);

  // L'original est altéré hors interface (cas limite) : le réimport le restaure.
  originale.description = "texte corrompu localement";

  const encore = importerDansBibliotheque(b, structuredClone(kodokan), { packId: "kodokan" }).bibliotheque;
  const apresOriginale = encore.contributions.find((c) => c.origine?.pack === "kodokan")!;
  const apresAdaptation = encore.contributions.find((c) => c.id === adaptation.id);
  assert.equal(apresOriginale.description, "desc Harai-goshi", "le réimport doit restaurer la voix du pack");
  assert.deepEqual(apresAdaptation, adaptation, "le réimport ne doit jamais toucher l'adaptation locale");
  assert.equal(apresAdaptation!.techniqueId, idTech, "l'adaptation reste rattachée à la même identité");
});

test("lot 4 §5 — doublons potentiels à la création : exact recommandé, proches suggérés, jamais entre disciplines", () => {
  let b = importerDansBibliotheque(
    bibliothequeVide(),
    pack("kodokan", "Judo", ["De-ashi-harai", "Seoi-nage", "Morote-seoi-nage"]),
    { packId: "kodokan" },
  ).bibliotheque;
  const judo = b.disciplines[0]!;

  // Quasi-correspondance (barai/harai : distance 1) — suggérée, pas exacte.
  const quasi = doublonsPotentiels(b, judo.id, "De Ashi Barai");
  assert.equal(quasi.exacte, null);
  assert.deepEqual(quasi.proches.map((t) => t.nom), ["De-ashi-harai"]);

  // Inclusion : « seoi » propose les deux identités.
  const inclusion = doublonsPotentiels(b, judo.id, "seoi");
  assert.deepEqual(inclusion.proches.map((t) => t.nom).sort(), ["Morote-seoi-nage", "Seoi-nage"]);

  // Correspondance exacte unique (normalisée) : recommandée.
  const exacte = doublonsPotentiels(b, judo.id, "seoi nage");
  assert.equal(exacte.exacte?.nom, "Seoi-nage");

  // Saisie trop courte : silence (pas d'alerte anxiogène pendant le geste).
  assert.deepEqual(doublonsPotentiels(b, judo.id, "se"), { exacte: null, proches: [] });

  // Jamais entre disciplines.
  b = importerDansBibliotheque(b, pack("karate", "Karaté", ["Seoi-nage"]), { packId: "karate" }).bibliotheque;
  const karate = b.disciplines.find((d) => d.nom === "Karaté")!;
  const croise = doublonsPotentiels(b, karate.id, "de ashi barai");
  assert.equal(croise.exacte, null);
  assert.equal(croise.proches.length, 0);

  // Plusieurs correspondances exactes (ambigu) : candidates, pas de décision.
  b.techniques.push(technique(judo.id, { nom: "Seoi nage" })); // homonyme volontaire
  const ambigu = doublonsPotentiels(b, judo.id, "seoi-nage");
  assert.equal(ambigu.exacte, null, "deux exactes = ambigu, aucune recommandation unique");
  assert.ok(ambigu.proches.length >= 2, "les candidates ambiguës sont présentées");
});

test("propriété 4bis (D-116b) : réimporter un pack EXPORTÉ d'ici (mêmes ULID) rejoint, jamais un doublon d'id", async () => {
  const { extrairePackDiscipline } = await import("../src/echange/extraction-pack.ts");
  // Bibliothèque LOCALE (créée dans l'app) : ni pack, ni origine.
  const d = disciplineJudo();
  const t = technique(d.id, { nom: "Seoi-nage" });
  const c = { ...contribution(t.id), provenance: "enseignement" as const, attribution: "Coach" };
  const lib: Bibliotheque = { ...bibliothequeVide(), disciplines: [d], techniques: [t], contributions: [c] };

  // Round-trip : on publie cette discipline, on la réimporte alors que les
  // originaux locaux (mêmes ULID) sont toujours là.
  const { extrait } = extrairePackDiscipline(lib, d.id, new Set(["local"]));
  assert.equal(extrait.techniques[0]!.id, t.id, "le pack conserve l'ULID d'origine (idempotence des ids)");

  const { bibliotheque, rapport } = importerDansBibliotheque(lib, extrait, { packId: `pack-${d.id}` });
  // Aucun doublon : validerBibliotheque (dans importerDansBibliotheque) ne lève pas,
  // et l'identité est REJOINTE, pas dupliquée.
  assert.equal(bibliotheque.techniques.length, 1, "une seule identité (rejointe, pas un doublon d'id)");
  assert.equal(bibliotheque.disciplines.length, 1, "une seule discipline");
  assert.equal(bibliotheque.contributions.length, 1, "une seule contribution (remplacée, pas dupliquée)");
  assert.deepEqual(rapport.rejointes, ["Seoi-nage"]);
  assert.deepEqual(rapport.creees, []);
  // Idempotent : un second réimport ne change rien non plus.
  const { bibliotheque: b2 } = importerDansBibliotheque(bibliotheque, extrait, { packId: `pack-${d.id}` });
  assert.equal(b2.techniques.length, 1);
  assert.equal(b2.contributions.length, 1);
});

test("D-127 — un pack COMPOSITION embarque ses techniques : import NON bloquant même si les techniques existent déjà", () => {
  const d = disciplineJudo({ nom: "Taïso" });
  const tA = technique(d.id, { nom: "Mobilité épaules", origine: { pack: "taiso", element: "eA" } });
  const tB = technique(d.id, { nom: "Gainage", origine: { pack: "taiso", element: "eB" } });
  // La discipline + ses techniques sont DÉJÀ installées (pack « taiso »).
  const base: Bibliotheque = { ...bibliothequeVide(), disciplines: [d], techniques: [tA, tB] };
  // Un pack COMPOSITION rebundle la MÊME discipline + les MÊMES techniques (mêmes
  // ULID, comme le ferait un export) + une séance qui les enchaîne.
  const seance = composition({
    nom: "Séance 01",
    provenance: "enseignement",
    attribution: "taiso-12",
    origine: { pack: "taiso-12", element: "c0" },
    blocs: [
      { id: genererUlid(), type: "technique", techniqueId: tA.id, medias: [] },
      { id: genererUlid(), type: "technique", techniqueId: tB.id, medias: [] },
    ],
  });
  const packCompo: Bibliotheque = {
    ...bibliothequeVide(),
    disciplines: [structuredClone(d)],
    techniques: [structuredClone(tA), structuredClone(tB)],
    compositions: [seance],
  };
  // NE DOIT PAS lever (validerBibliotheque en fin), NE DOIT PAS dupliquer.
  const { bibliotheque: b } = importerDansBibliotheque(base, packCompo, { packId: "taiso-12" });
  assert.equal(b.techniques.length, 2, "les techniques présentes rejoignent par ULID — aucun doublon");
  assert.equal(b.compositions.length, 1, "la séance embarquée est ajoutée");
  const refs = b.compositions[0]!.blocs.filter((x) => x.type === "technique").map((x) => x.techniqueId).sort();
  assert.deepEqual(refs, [tA.id, tB.id].sort(), "les blocs pointent les identités déjà présentes");
});

test("D-127 — le même pack COMPOSITION fonctionne AUSSI quand les techniques manquent (composition autonome)", () => {
  const d = disciplineJudo({ nom: "Taïso" });
  const tA = technique(d.id, { nom: "Mobilité épaules", origine: { pack: "taiso", element: "eA" } });
  const tB = technique(d.id, { nom: "Gainage", origine: { pack: "taiso", element: "eB" } });
  const seance = composition({
    nom: "Séance 01",
    provenance: "enseignement",
    attribution: "taiso-12",
    origine: { pack: "taiso-12", element: "c0" },
    blocs: [
      { id: genererUlid(), type: "technique", techniqueId: tA.id, medias: [] },
      { id: genererUlid(), type: "technique", techniqueId: tB.id, medias: [] },
    ],
  });
  const packCompo: Bibliotheque = {
    ...bibliothequeVide(),
    disciplines: [d],
    techniques: [tA, tB],
    compositions: [seance],
  };
  // Bibliothèque vierge : la discipline + les techniques embarquées sont CRÉÉES,
  // la séance reste jouable de bout en bout.
  const { bibliotheque: b } = importerDansBibliotheque(bibliothequeVide(), packCompo, { packId: "taiso-12" });
  assert.equal(b.techniques.length, 2, "les techniques embarquées sont créées");
  assert.equal(b.compositions.length, 1, "la séance est présente");
  const refs = b.compositions[0]!.blocs.filter((x) => x.type === "technique").map((x) => x.techniqueId);
  assert.ok(refs.every((id) => b.techniques.some((t) => t.id === id)), "chaque bloc pointe une technique présente");
});

test("D-134 — l'import préserve la note (raison) et la priorité d'une relation", () => {
  const p = pack("kodokan", "Judo", ["A", "B"], { relations: [["A", "B"]] });
  const src = p.techniques.find((t) => t.nom === "A")!;
  src.relations[0]!.note = "B ouvre l'arrière";
  src.relations[0]!.priorite = 1;
  const { bibliotheque: b } = importerDansBibliotheque(bibliothequeVide(), p, { packId: "kodokan" });
  const rel = b.techniques.find((t) => t.nom === "A")!.relations[0]!;
  assert.equal(rel.note, "B ouvre l'arrière");
  assert.equal(rel.priorite, 1);
});

test("D-157 — conflit de liaison : détecté à l'import, jamais appliqué ni écarté en silence, une seule entrée par arête", () => {
  const p = pack("kodokan", "Judo", ["A", "B"], { relations: [["A", "B"]] });
  p.techniques.find((t) => t.nom === "A")!.relations[0]!.note = "raison du pack";
  p.techniques.find((t) => t.nom === "A")!.relations[0]!.priorite = 1;
  let b = importerDansBibliotheque(bibliothequeVide(), p, { packId: "kodokan" }).bibliotheque;
  assert.equal(b.conflitsLiaisons, undefined, "premier import : aucun conflit");
  // Édition locale de la raison (D-156), puis réimport du même pack.
  b.techniques.find((t) => t.nom === "A")!.relations[0]!.note = "ma raison éditée";
  const { bibliotheque: b2, rapport } = importerDansBibliotheque(b, structuredClone(p), { packId: "kodokan" });
  assert.equal(rapport.conflitsLiaisons, 1, "le rapport annonce le conflit");
  assert.equal(b2.conflitsLiaisons?.length, 1);
  assert.equal(b2.conflitsLiaisons![0]!.note, "raison du pack", "l'entrée porte la proposition DU PACK");
  assert.equal(b2.techniques.find((t) => t.nom === "A")!.relations[0]!.note, "ma raison éditée", "la version locale reste en place");
  // Réimport encore : toujours UNE seule entrée (remplacée, pas dupliquée).
  const b3 = importerDansBibliotheque(b2, structuredClone(p), { packId: "kodokan" }).bibliotheque;
  assert.equal(b3.conflitsLiaisons?.length, 1, "pas de doublon d'entrée au réimport");
  // Si le désaccord disparaît (local réaligné), l'entrée périmée disparaît.
  b3.techniques.find((t) => t.nom === "A")!.relations[0]!.note = "raison du pack";
  const b4 = importerDansBibliotheque(b3, structuredClone(p), { packId: "kodokan" }).bibliotheque;
  assert.equal(b4.conflitsLiaisons, undefined, "plus de désaccord → plus d'entrée");
});

test("D-157 — arbitrage d'un conflit : la mienne / celle du pack / les deux", () => {
  const monter = () => {
    const p = pack("kodokan", "Judo", ["A", "B"], { relations: [["A", "B"]] });
    p.techniques.find((t) => t.nom === "A")!.relations[0]!.note = "raison du pack";
    p.techniques.find((t) => t.nom === "A")!.relations[0]!.priorite = 2;
    let b = importerDansBibliotheque(bibliothequeVide(), p, { packId: "kodokan" }).bibliotheque;
    const rel = () => b.techniques.find((t) => t.nom === "A")!.relations[0]!;
    rel().note = "ma raison";
    rel().priorite = 1;
    b = importerDansBibliotheque(b, structuredClone(p), { packId: "kodokan" }).bibliotheque;
    return { b, rel: () => b.techniques.find((t) => t.nom === "A")!.relations[0]! };
  };
  // La mienne : rien ne bouge, l'entrée disparaît.
  let m = monter();
  arbitrerConflitLiaison(m.b, m.b.conflitsLiaisons![0]!, "local");
  assert.equal(m.rel().note, "ma raison");
  assert.equal(m.rel().priorite, 1);
  assert.equal(m.b.conflitsLiaisons, undefined);
  // Celle du pack : raison + priorité du pack remplacent les locales.
  m = monter();
  arbitrerConflitLiaison(m.b, m.b.conflitsLiaisons![0]!, "pack");
  assert.equal(m.rel().note, "raison du pack");
  assert.equal(m.rel().priorite, 2);
  assert.equal(m.b.conflitsLiaisons, undefined);
  // Les deux : raisons concaténées (locale d'abord), priorité locale conservée.
  m = monter();
  arbitrerConflitLiaison(m.b, m.b.conflitsLiaisons![0]!, "deux");
  assert.equal(m.rel().note, "ma raison\n\nraison du pack");
  assert.equal(m.rel().priorite, 1);
  assert.equal(m.b.conflitsLiaisons, undefined);
});

test("D-243 — un lien que le pack ne déclare plus est PROPOSÉ au retrait, jamais retiré d'office", () => {
  // v1 du pack : deux arêtes. v2 : le porteur en retire une (épuration D-241).
  const v1 = pack("kodokan", "Judo", ["A", "B", "C"], { relations: [["A", "B"], ["A", "C"]] });
  let b = importerDansBibliotheque(bibliothequeVide(), v1, { packId: "kodokan" }).bibliotheque;
  assert.equal(b.techniques.find((t) => t.nom === "A")!.relations.length, 2);
  assert.equal(b.conflitsLiaisons, undefined, "premier import : rien à proposer");

  const v2 = pack("kodokan", "Judo", ["A", "B", "C"], { relations: [["A", "B"]] });
  const { bibliotheque: b2, rapport } = importerDansBibliotheque(b, v2, { packId: "kodokan" });
  // Le cœur de la décision : l'arête est TOUJOURS LÀ, seule une proposition existe.
  assert.equal(b2.techniques.find((t) => t.nom === "A")!.relations.length, 2, "rien n'est retiré d'office");
  assert.equal(rapport.retraitsProposes, 1, "le rapport annonce le retrait proposé");
  assert.equal(rapport.conflitsLiaisons, 0, "un retrait n'est pas un désaccord de raison : compté à part");
  const prop = b2.conflitsLiaisons!.find((c) => c.sens === "retrait")!;
  assert.equal(prop.cibleId, b2.techniques.find((t) => t.nom === "C")!.id);

  // Idempotence (propriété 4) : réimporter v2 ne duplique pas la proposition.
  const b3 = importerDansBibliotheque(b2, structuredClone(v2), { packId: "kodokan" }).bibliotheque;
  assert.equal(b3.conflitsLiaisons!.filter((c) => c.sens === "retrait").length, 1, "pas de doublon au réimport");

  // Le pack redéclare l'arête : la proposition périmée disparaît d'elle-même.
  const b4 = importerDansBibliotheque(b3, structuredClone(v1), { packId: "kodokan" }).bibliotheque;
  assert.equal(b4.conflitsLiaisons, undefined, "arête redéclarée → plus de proposition");
});

test("D-243 — un lien tracé À LA MAIN vers ses propres techniques n'est jamais proposé au retrait", () => {
  const v1 = pack("kodokan", "Judo", ["A", "B"], { relations: [["A", "B"]] });
  let b = importerDansBibliotheque(bibliothequeVide(), v1, { packId: "kodokan" }).bibliotheque;
  // L'utilisateur crée SA technique et la relie à une technique du pack.
  const mienne = { id: "01KX9CT5WN7HH6JWRTX9WPDZZZ", nom: "Ma technique", disciplineId: b.disciplines[0]!.id,
    niveauxIds: [], relations: [], alertes: [] };
  b.techniques.push(mienne);
  b.techniques.find((t) => t.nom === "A")!.relations.push({ type: "enchaine", cibleId: mienne.id });

  const v2 = pack("kodokan", "Judo", ["A", "B"], { relations: [] });
  const { bibliotheque: b2 } = importerDansBibliotheque(b, v2, { packId: "kodokan" });
  const retraits = (b2.conflitsLiaisons ?? []).filter((c) => c.sens === "retrait");
  assert.equal(retraits.length, 1, "seule l'arête ENTRE DEUX techniques du pack est proposée");
  assert.notEqual(retraits[0]!.cibleId, mienne.id, "le lien vers ma propre technique n'est jamais touché");
  assert.ok(b2.techniques.find((t) => t.nom === "A")!.relations.some((r) => r.cibleId === mienne.id), "il reste en place");
});

test("D-243 — arbitrage d'un retrait proposé : garder ne touche à rien, retirer supprime l'arête", () => {
  const monter = () => {
    const v1 = pack("kodokan", "Judo", ["A", "B", "C"], { relations: [["A", "B"], ["A", "C"]] });
    let b = importerDansBibliotheque(bibliothequeVide(), v1, { packId: "kodokan" }).bibliotheque;
    const v2 = pack("kodokan", "Judo", ["A", "B", "C"], { relations: [["A", "B"]] });
    b = importerDansBibliotheque(b, v2, { packId: "kodokan" }).bibliotheque;
    return { b, a: () => b.techniques.find((t) => t.nom === "A")! };
  };
  // « Garder » (local) : l'entrée est classée, l'arête ne bouge pas.
  let m = monter();
  arbitrerConflitLiaison(m.b, m.b.conflitsLiaisons!.find((c) => c.sens === "retrait")!, "local");
  assert.equal(m.a().relations.length, 2, "garder ne détruit rien");
  assert.equal(m.b.conflitsLiaisons, undefined, "la proposition est classée");
  // « Retirer » : l'arête part, et elle seule.
  m = monter();
  arbitrerConflitLiaison(m.b, m.b.conflitsLiaisons!.find((c) => c.sens === "retrait")!, "retirer");
  assert.equal(m.a().relations.length, 1, "l'arête proposée au retrait est partie");
  assert.equal(m.a().relations[0]!.cibleId, m.b.techniques.find((t) => t.nom === "B")!.id, "l'autre est intacte");
  assert.equal(m.b.conflitsLiaisons, undefined);
});

/* ===== R3-1 (REC-B4-001) / D-298 — patron D-243 pour les CONTRIBUTIONS :
   une contribution AMENDÉE par l'utilisateur (modifiePar) n'est jamais
   écrasée par la mise à jour du pack — la version du pack part en conflit,
   la locale reste en place tant que l'humain n'a pas tranché. ===== */

test("D-298 — une contribution amendée n'est PAS écrasée : la proposition du pack part en conflit", () => {
  const p = pack("kodokan", "Judo", ["A"]);
  let b = importerDansBibliotheque(bibliothequeVide(), p, { packId: "kodokan" }).bibliotheque;
  const c = () => b.contributions.find((x) => x.origine?.element === "e0")!;
  c().description = "ma description";
  c().modifiePar = "moi"; // le geste d'édition signe (tuning post-V3)
  const { bibliotheque: b2, rapport } = importerDansBibliotheque(b, structuredClone(p), { packId: "kodokan" });
  b = b2;
  assert.equal(rapport.conflitsContributions, 1, "le rapport annonce le conflit");
  assert.equal(c().description, "ma description", "la version locale reste en place");
  assert.equal(c().modifiePar, "moi", "la signature reste");
  assert.equal(b.conflitsContributions?.length, 1);
  assert.equal(b.conflitsContributions![0]!.description, "desc A", "l'entrée porte la proposition DU PACK");
  // Réimport encore : UNE seule entrée (remplacée, jamais dupliquée).
  b = importerDansBibliotheque(b, structuredClone(p), { packId: "kodokan" }).bibliotheque;
  assert.equal(b.conflitsContributions?.length, 1, "pas de doublon d'entrée au réimport");
  // Le désaccord disparaît (local réaligné) : l'entrée part, la signature aussi.
  c().description = "desc A";
  b = importerDansBibliotheque(b, structuredClone(p), { packId: "kodokan" }).bibliotheque;
  assert.equal(b.conflitsContributions, undefined, "plus de désaccord → plus d'entrée");
  assert.equal(c().modifiePar, undefined, "texte redevenu 100 % pack → la signature ne ment plus");
});

test("D-298 — arbitrage d'un conflit de contribution : la mienne / celle du pack", () => {
  const monter = () => {
    const p = pack("kodokan", "Judo", ["A"]);
    let b = importerDansBibliotheque(bibliothequeVide(), p, { packId: "kodokan" }).bibliotheque;
    const c = () => b.contributions.find((x) => x.origine?.element === "e0")!;
    c().description = "ma description";
    c().modifiePar = "moi";
    b = importerDansBibliotheque(b, structuredClone(p), { packId: "kodokan" }).bibliotheque;
    return { b, c: () => b.contributions.find((x) => x.origine?.element === "e0")! };
  };
  // La mienne : rien ne bouge, l'entrée disparaît.
  let m = monter();
  arbitrerConflitContribution(m.b, m.b.conflitsContributions![0]!, "locale");
  assert.equal(m.c().description, "ma description");
  assert.equal(m.c().modifiePar, "moi");
  assert.equal(m.b.conflitsContributions, undefined);
  // Celle du pack : le texte du pack remplace, la signature part (elle mentirait).
  m = monter();
  arbitrerConflitContribution(m.b, m.b.conflitsContributions![0]!, "pack");
  assert.equal(m.c().description, "desc A");
  assert.equal(m.c().modifiePar, undefined);
  assert.equal(m.b.conflitsContributions, undefined);
});

test("contrepartie D-298 — sans amendement signé, la mise à jour remplace comme avant", () => {
  const p = pack("kodokan", "Judo", ["A"]);
  const b1 = importerDansBibliotheque(bibliothequeVide(), p, { packId: "kodokan" }).bibliotheque;
  const v2 = structuredClone(p);
  v2.contributions[0]!.description = "desc v2 du pack";
  const { bibliotheque: b2, rapport } = importerDansBibliotheque(b1, v2, { packId: "kodokan" });
  assert.equal(b2.contributions.find((x) => x.origine?.element === "e0")!.description, "desc v2 du pack",
    "le contenu du pack se met à jour normalement");
  assert.equal(rapport.conflitsContributions, 0, "aucun conflit sans édition signée");
  assert.equal(b2.conflitsContributions, undefined);
});

test("D-307 (MAJ-3) — le rapport compte les conflits de CE pack, jamais la table globale", () => {
  // Le constat porteur : installer le Jujitsu annonçait les 4 conflits pendants
  // du Judo — le compteur lisait la table entière, tous packs confondus.
  const p = pack("kodokan", "Judo", ["A", "B"], { relations: [["A", "B"]] });
  p.techniques.find((t) => t.nom === "A")!.relations[0]!.note = "raison du pack";
  let b = importerDansBibliotheque(bibliothequeVide(), p, { packId: "kodokan" }).bibliotheque;
  b.techniques.find((t) => t.nom === "A")!.relations[0]!.note = "ma raison éditée";
  b = importerDansBibliotheque(b, structuredClone(p), { packId: "kodokan" }).bibliotheque;
  assert.equal(b.conflitsLiaisons?.length, 1, "préambule : un conflit du Judo est pendant");
  // Import d'un AUTRE pack, sans aucun désaccord : son rapport doit dire zéro.
  const { bibliotheque: b2, rapport } = importerDansBibliotheque(b, pack("jjb", "JJB", ["X"]), { packId: "jjb" });
  assert.equal(rapport.conflitsLiaisons, 0, "le rapport parle de CET import, pas de la table globale");
  assert.equal(rapport.retraitsProposes, 0);
  assert.equal(b2.conflitsLiaisons?.length, 1, "le conflit du Judo, lui, reste pendant");
});

test("D-307 (MAJ-2) — l'édition installée est retenue à l'import, remplacée à la mise à jour, jamais perdue", () => {
  const r1 = importerDansBibliotheque(bibliothequeVide(), pack("kodokan", "Judo", ["A"]), {
    packId: "kodokan", versionEditoriale: 11,
  });
  assert.deepEqual(
    r1.bibliotheque.editionsPacks?.map((e) => [e.pack, e.versionEditoriale]),
    [["kodokan", 11]],
    "l'édition du manifeste est retenue",
  );
  const r2 = importerDansBibliotheque(r1.bibliotheque, pack("kodokan", "Judo", ["A"]), {
    packId: "kodokan", versionEditoriale: 12,
  });
  assert.deepEqual(
    r2.bibliotheque.editionsPacks?.map((e) => [e.pack, e.versionEditoriale]),
    [["kodokan", 12]],
    "une entrée par pack, la plus récente",
  );
  // Import sans édition (JSON historique) : rien n'est écrit, rien n'est perdu.
  const r3 = importerDansBibliotheque(r2.bibliotheque, pack("club", "Karaté", ["X"]), { packId: "club" });
  assert.deepEqual(r3.bibliotheque.editionsPacks?.map((e) => [e.pack, e.versionEditoriale]), [["kodokan", 12]]);
});

test("D-307 (MAJ-1) — le rapport dit le changement réel d'une mise à jour ; à l'identique, tout est à zéro", () => {
  const v1 = pack("kodokan", "Judo", ["A", "B"]);
  v1.compositions = [composition({ nom: "Kata", provenance: "enseignement", origine: { pack: "kodokan", element: "k1" } })];
  let b = importerDansBibliotheque(bibliothequeVide(), v1, { packId: "kodokan" }).bibliotheque;

  // Réimport à l'identique : idempotent, et le rapport le DIT.
  const memePack = importerDansBibliotheque(b, structuredClone(v1), { packId: "kodokan" });
  assert.equal(memePack.rapport.fichesModifiees, 0, "rien ne change → zéro fiche");
  assert.equal(memePack.rapport.compositionsModifiees, 0);
  assert.equal(memePack.rapport.imagesAjoutees, 0);
  assert.equal(memePack.rapport.relationsAjoutees, 0);

  // v2 : une description change, une image de couverture arrive sur A, la
  // composition est renommée, une relation apparaît.
  const v2 = structuredClone(v1);
  v2.contributions.find((c) => c.techniqueId === v2.techniques.find((t) => t.nom === "B")!.id)!.description = "réécrite";
  const empreinte = "a".repeat(64);
  v2.images = [{ id: empreinte, mime: "image/webp", taille: 10 }];
  v2.techniques.find((t) => t.nom === "A")!.couverture = { type: "fichier", imageId: empreinte };
  v2.compositions![0]!.nom = "Kata — vue d'ensemble";
  v2.techniques.find((t) => t.nom === "A")!.relations.push({ type: "prepare", cibleId: v2.techniques.find((t) => t.nom === "B")!.id });
  const { rapport } = importerDansBibliotheque(b, v2, { packId: "kodokan" });
  assert.equal(rapport.fichesModifiees, 2, "A (couverture) et B (texte) — chacune comptée une fois");
  assert.equal(rapport.compositionsModifiees, 1);
  assert.equal(rapport.imagesAjoutees, 1);
  assert.equal(rapport.relationsAjoutees, 1);
});
