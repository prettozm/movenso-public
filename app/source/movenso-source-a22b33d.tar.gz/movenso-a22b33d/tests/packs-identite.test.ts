/**
 * IDENTITÉ DES PACKS PUBLIÉS (D-247) — garde de non-régression.
 *
 * L'app reconnaît un pack par l'id de son MANIFESTE. Si cet id change, une mise
 * à jour n'est plus reconnue comme telle : elle s'installe comme un pack neuf
 * et DUPLIQUE tout son contenu chez ceux qui l'avaient déjà. C'est arrivé deux
 * fois — au judo, puis au jujitsu — et à chaque fois en silence, parce que rien
 * ne comparait l'id produit à l'id publié.
 *
 * Ce test épingle les identités. Il échoue si :
 *  - l'ULID d'une discipline change dans `donnees/` (régénération de source) ;
 *  - un pack est ajouté sans que son identité soit inscrite ici ;
 *  - l'outil d'emballage repasse à une dérivation par nom de fichier.
 *
 * Une identité ne se change JAMAIS par accident. Modifier une valeur ci-dessous
 * est une décision : elle oblige les installations existantes à retirer la
 * discipline puis à réinstaller.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { idPackStable } from "../src/echange/extraction-pack.ts";
import type { Bibliotheque } from "../src/domaine/modele.ts";

/** Identités PUBLIÉES, relevées sur les conteneurs du site (D-247). */
const IDENTITES: Record<string, string> = {
  kodokan: "pack-01KX9CT5W7HQ9YVG00MA9M4C8G",
  jujitsu: "pack-01KY8EE8F8WKY718X9G1PB3TR6",
  "karate-shotokan": "pack-01KY8DX4EZBYNZE34J6DVXBW36",
  jjb: "pack-01KY8ERV8XKH7GSHEVEQ8KWCDX",
  taiso: "pack-01KY8F8AV3R8BW9MWRS74R13FE",
  // Le yoga n'avait pas de source versionnée jusqu'à S4.8 : il était donc le
  // seul pack publié dont l'identité n'était épinglée nulle part. Reconstruit
  // depuis le conteneur publié, il rejoint la garde — relevé sur le fichier en
  // ligne, pas recalculé depuis la source qu'on vient d'en tirer.
  yoga: "pack-01KYA0SRD09M7RBCQH1Q46K1J9",
};

const lire = (f: string) => JSON.parse(readFileSync(`donnees/${f}.json`, "utf8")) as Bibliotheque;

test("D-247 — l'identité d'un pack publié ne bouge pas", () => {
  for (const [fichier, attendu] of Object.entries(IDENTITES)) {
    const b = lire(fichier);
    assert.equal(b.disciplines.length, 1, `${fichier} : un pack de discipline en contient exactement une`);
    assert.equal(
      idPackStable(b.disciplines[0]!.id),
      attendu,
      `${fichier} : l'identité du conteneur a CHANGÉ — une mise à jour dupliquerait tout le contenu ` +
        `chez qui l'a déjà installé. Ne corriger ce test qu'en connaissance de cause.`,
    );
  }
});

test("D-247 — l'emballage dérive l'identité de la discipline, jamais du nom de fichier", () => {
  const outil = readFileSync("tools/publier.ts", "utf8");
  const code = outil.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, ""); // hors commentaires
  assert.match(code, /id:\s*idPackStable\(/, "l'emballage doit poser `idPackStable` comme identité");
  assert.doesNotMatch(
    code,
    /id:\s*[^,]*idDePack\(/,
    "`idDePack` dérive du NOM : l'employer comme identité casse la reconnaissance des mises à jour (D-247)",
  );
});

test("D-247 — chaque pack publié a son identité épinglée", () => {
  // La liste des packs est une DONNÉE depuis S4.9 : elle se lit, elle ne
  // s'extrait plus du code de l'outil à l'expression régulière.
  const packs: { source: string }[] = JSON.parse(readFileSync("publication/packs.json", "utf8"));
  assert.ok(packs.length > 0, "aucun pack dans la source de publication");
  for (const p of packs) {
    assert.ok(p.source in IDENTITES, `le pack « ${p.source} » est publié mais son identité n'est pas épinglée ici`);
  }
});
