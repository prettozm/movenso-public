/**
 * Assemblage des contenus distribués — le chemin exact du premier lancement
 * de l'application : import des packs SANS règles (comportement réel de l'app
 * depuis D-067 — aucune fusion automatique). Filet de régression : ces chiffres
 * bougent si les données changent — les mettre à jour est alors le geste attendu.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { bibliothequeVide } from "../src/domaine/modele.ts";
import { migrerBibliotheque } from "../src/domaine/migrations.ts";
import { validerBibliotheque } from "../src/domaine/validation.ts";
import { importerDansBibliotheque } from "../src/domaine/rapprochement.ts";
import { normaliserPourRecherche as norm } from "../src/domaine/recherche.ts";

function lire(nom: string): unknown {
  return JSON.parse(readFileSync(new URL(`../donnees/${nom}`, import.meta.url), "utf8"));
}

const PACKS = [
  { fichier: "kodokan.json", packId: "kodokan" },
  { fichier: "club-judo.json", packId: "club-judo" },
];

function assembler() {
  let b = bibliothequeVide();
  const rapports = [];
  for (const { fichier, packId } of PACKS) {
    // Chemin RÉEL de l'app : import sans `regles` → aucune fusion (D-067).
    const resultat = importerDansBibliotheque(b, migrerBibliotheque(lire(fichier)), { packId });
    b = resultat.bibliotheque;
    rapports.push(resultat.rapport);
  }
  return { b, rapports };
}

test("l'assemblage réunit UNE discipline Judo mais garde toutes les identités distinctes (D-067)", () => {
  const { b } = assembler();
  validerBibliotheque(b);
  assert.equal(b.disciplines.length, 1, "les packs d'une même discipline rejoignent la discipline");
  assert.equal(b.disciplines[0]!.nom, "Judo");
  assert.equal(b.contributions.length, 160, "aucune contribution perdue");
  // Sans fusion automatique : autant d'identités que la somme des packs.
  const attendu = PACKS.reduce((n, { fichier }) => n + (migrerBibliotheque(lire(fichier)) as { techniques: unknown[] }).techniques.length, 0);
  assert.equal(b.techniques.length, attendu, "chaque élément de pack reste une identité distincte");
});

test("aucune identité n'est composite : deux packs de même nom = deux fiches, chacune à sa voix (D-067)", () => {
  const { b } = assembler();
  const multiVoix = b.techniques.filter(
    (t) => new Set(b.contributions.filter((c) => c.techniqueId === t.id).map((c) => c.origine?.pack)).size > 1,
  );
  assert.equal(multiVoix.length, 0, "plus aucune fiche multisource");
  // Les homonymes des deux packs coexistent, distincts et chacun lié à son pack.
  const haraiKodokan = b.techniques.find((t) => norm(t.nom) === "haraigoshi" && t.origine?.pack === "kodokan");
  const haraiClub = b.techniques.find((t) => norm(t.nom) === "haraigoshi" && t.origine?.pack === "club-judo");
  assert.ok(haraiKodokan && haraiClub, "une identité Harai-goshi par pack");
  assert.notEqual(haraiKodokan!.id, haraiClub!.id, "identités bien distinctes");
  assert.equal(haraiKodokan!.nomTraditionnel, "hanche fauchée", "le sous-titre du référentiel est conservé (glose française depuis D-297/D-299)");
  for (const t of [haraiKodokan!, haraiClub!]) {
    const voix = new Set(b.contributions.filter((c) => c.techniqueId === t.id).map((c) => c.origine?.pack));
    assert.equal(voix.size, 1, "chaque fiche ne porte que la voix de son pack");
  }
});

test("les relations restent internes à leur pack — jamais de lien tissé entre packs (D-067)", () => {
  const { b } = assembler();
  const parId = new Map(b.techniques.map((t) => [t.id, t]));
  let verifiees = 0;
  for (const t of b.techniques) {
    for (const r of t.relations) {
      const cible = parId.get(r.cibleId);
      if (!cible) continue; // cible tolérée absente : hors sujet ici
      verifiees++;
      assert.equal(cible.origine?.pack, t.origine?.pack, `relation ${t.nom} → ${cible.nom} ne doit pas franchir les packs`);
    }
  }
  assert.ok(verifiees >= 1, "des relations internes doivent exister pour que le test soit probant");
});

test("les suggestions d'homonymie restent connues et bornées (indices, jamais fusion)", () => {
  const { rapports } = assembler();
  const suggestions = rapports.flatMap((r) => r.suggestions).map((s) => s.nom).sort();
  assert.ok(suggestions.length <= 7, `suggestions inattendues : ${suggestions.join(", ")}`);
});
