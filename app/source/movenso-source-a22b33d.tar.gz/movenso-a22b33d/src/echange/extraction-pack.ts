/**
 * EXTRACTION d'un pack — quel SOUS-ENSEMBLE de la bibliothèque part (D-274).
 *
 * Rien de tout cela n'est un conteneur : ce sont des décisions ÉDITORIALES,
 * pures et sans E/S. Le périmètre de sources (D-023) en est le cœur — une
 * publication n'emporte jamais par défaut les contributions d'une source que
 * l'auteur ne maîtrise pas, et le carnet personnel ne se publie jamais. Ces
 * fonctions vivaient dans `movpack.ts` par accident d'histoire ; elles n'y
 * avaient aucune ligne de ZIP.
 */
import type { Bibliotheque, Composition, Contribution, Media, Technique } from "../domaine/modele.ts";
import { sourceDe } from "../domaine/modele.ts";
import { normaliserPourRecherche } from "../domaine/recherche.ts";
import { registreMedias } from "../domaine/medias.ts";
import { validerBibliotheque } from "../domaine/validation.ts";
import { ErreurMovpack } from "./movpack-contrat.ts";

interface RelationExclue {
  techniqueId: string;
  techniqueNom: string;
  type: string;
  cibleId: string;
}

export interface ExtractionPack {
  extrait: Bibliotheque;
  /** Relations retirées du FICHIER publié (jamais de la bibliothèque locale)
   *  parce que leur identité cible n'appartient pas au périmètre du pack. */
  relationsExclues: RelationExclue[];
}

export function extrairePackDiscipline(
  b: Bibliotheque,
  disciplineId: string,
  sources: ReadonlySet<string> = new Set(["local"]),
  techniquesChoisies?: ReadonlySet<string>,
  opts: { compositionsPersonnelles?: boolean } = {},
): ExtractionPack {
  const discipline = b.disciplines.find((d) => d.id === disciplineId);
  if (!discipline) throw new ErreurMovpack("Discipline introuvable");
  // Sous-ensemble explicite de techniques (tuning post-V3 : « choix de
  // techniques ») — restreint le périmètre en plus des sources.
  const choisie = (id: string) => !techniquesChoisies || techniquesChoisies.has(id);
  const contributions = b.contributions.filter(
    (c) => c.provenance !== "personnel" && c.techniqueId !== null && choisie(c.techniqueId) && sources.has(sourceDe(c)),
  );
  const idsContribues = new Set(contributions.map((c) => c.techniqueId!));
  // Identités : celles du périmètre de sources, plus celles que les
  // contributions incluses éclairent (une contribution voyage avec son identité).
  const techniques = b.techniques.filter(
    (t) => t.disciplineId === disciplineId && choisie(t.id) && (sources.has(sourceDe(t)) || idsContribues.has(t.id)),
  );
  const ids = new Set(techniques.map((t) => t.id));
  // Règle (lot 10B, A1) : une relation n'est exportée que si sa SOURCE et sa
  // CIBLE sont toutes deux dans le périmètre. Une cible hors périmètre → la
  // relation est EXCLUE du fichier publié (jamais de relation pendante créée en
  // silence), la relation LOCALE n'est jamais modifiée, la cible n'est JAMAIS
  // ajoutée implicitement. Les exclusions sont comptées et détaillées.
  const relationsExclues: RelationExclue[] = [];
  const techniquesPubliees = techniques.map((t) => {
    const clone = structuredClone(t);
    clone.relations = t.relations.filter((r) => {
      if (ids.has(r.cibleId)) return true;
      relationsExclues.push({ techniqueId: t.id, techniqueNom: t.nom, type: r.type, cibleId: r.cibleId });
      return false;
    });
    return clone;
  });
  const extrait: Bibliotheque = {
    versionSchema: b.versionSchema,
    typesRelation: structuredClone(b.typesRelation),
    ...(b.typesAlerte ? { typesAlerte: structuredClone(b.typesAlerte) } : {}), // D-136 : types d'alerte voyagent
    disciplines: [structuredClone(discipline)],
    techniques: techniquesPubliees,
    contributions: structuredClone(contributions.filter((c) => ids.has(c.techniqueId!))),
    // Compositions embarquées AVEC la discipline (D-127) : une séance/kata
    // « voyage » avec le pack de sa discipline pour rester JOUABLE à l'import,
    // même sur un appareil qui n'a pas encore le pack. On retient, en plus de
    // celles issues des sources de la discipline, toute composition non
    // personnelle dont TOUS les pas techniques pointent des techniques du
    // périmètre exporté (`ids`) — donc sans référence pendante à l'arrivée.
    compositions: structuredClone(
      b.compositions.filter((c) => {
        const pasTech = c.blocs.filter((x) => x.type === "technique" && x.techniqueId);
        const jouableIci = pasTech.length > 0 && pasTech.every((x) => ids.has(x.techniqueId!));
        // Composition PERSONNELLE : publiée seulement sur OPT-IN explicite
        // (D-127) et seulement si elle est jouable dans ce périmètre (jamais de
        // référence pendante). Sinon, le carnet reste privé (lot 5 §4).
        if (c.provenance === "personnel") return (opts.compositionsPersonnelles ?? false) && jouableIci;
        return jouableIci || sources.has(sourceDe(c));
      }),
    ),
    favoris: [], // marque-pages personnels : exclus de toute publication (lot 5 §4)
  };
  validerBibliotheque(extrait);
  return { extrait, relationsExclues };
}

/**
 * Extrait un pack pour UNE seule technique (partage individuel — D-067). Le
 * pack porte la discipline de la fiche, la fiche elle-même et SES contributions
 * sourcées (jamais le carnet personnel, §31). Les relations vers d'autres
 * identités sont exclues du fichier (cible hors périmètre, D-066) : un pack
 * d'une technique ne contient jamais de lien pendant. Fonction pure.
 */
export function extrairePackTechnique(b: Bibliotheque, techniqueId: string): ExtractionPack {
  const t = b.techniques.find((x) => x.id === techniqueId);
  if (!t) throw new ErreurMovpack("Technique introuvable");
  const discipline = b.disciplines.find((d) => d.id === t.disciplineId);
  if (!discipline) throw new ErreurMovpack("Discipline introuvable");
  const contributions = b.contributions.filter((c) => c.techniqueId === t.id && c.provenance !== "personnel");
  const relationsExclues: RelationExclue[] = [];
  const clone = structuredClone(t);
  clone.relations = t.relations.filter((r) => {
    if (r.cibleId === t.id) return true; // (auto-référence improbable) tolérée
    relationsExclues.push({ techniqueId: t.id, techniqueNom: t.nom, type: r.type, cibleId: r.cibleId });
    return false;
  });
  const extrait: Bibliotheque = {
    versionSchema: b.versionSchema,
    typesRelation: structuredClone(b.typesRelation),
    ...(b.typesAlerte ? { typesAlerte: structuredClone(b.typesAlerte) } : {}), // D-136 : types d'alerte voyagent
    disciplines: [structuredClone(discipline)],
    techniques: [clone],
    contributions: structuredClone(contributions),
    compositions: [],
    favoris: [],
  };
  validerBibliotheque(extrait);
  return { extrait, relationsExclues };
}

/**
 * Extrait le pack d'UNE composition (D-020.1, verrouillé D-127) : la composition
 * PLUS les IDENTITÉS de technique qu'elle enchaîne (jamais leur carnet personnel)
 * et les disciplines de ces identités. L'export ET le partage d'une composition
 * passent par ici : une composition partagée reste JOUABLE à l'import même sur un
 * appareil qui n'a pas le pack d'origine. Fonction pure.
 */
export function extrairePackComposition(b: Bibliotheque, compositionId: string): Bibliotheque {
  const compo = b.compositions.find((c) => c.id === compositionId);
  if (!compo) throw new ErreurMovpack("Composition introuvable");
  const idsTechniques = new Set(
    compo.blocs.filter((x) => x.type === "technique" && x.techniqueId).map((x) => x.techniqueId!),
  );
  const techniques = b.techniques.filter((t) => idsTechniques.has(t.id));
  const idsDisciplines = new Set(techniques.map((t) => t.disciplineId));
  const extrait: Bibliotheque = {
    versionSchema: b.versionSchema,
    typesRelation: structuredClone(b.typesRelation),
    disciplines: structuredClone(b.disciplines.filter((d) => idsDisciplines.has(d.id))),
    techniques: structuredClone(techniques),
    contributions: [], // un pack de composition ne transporte pas de carnet
    compositions: [structuredClone(compo)],
    favoris: [],
  };
  validerBibliotheque(extrait);
  return extrait;
}

/** Nom de FICHIER lisible d'un pack — dérivé du nom éditorial (peut changer
 *  avec lui). Ce n'est PAS l'identité technique du pack (voir idPackStable). */
export function idDePack(nom: string): string {
  return `pack-${normaliserPourRecherche(nom)}`;
}

/** Identité TECHNIQUE stable d'un pack (lot 8B) — clé d'idempotence au
 *  réimport (D-013/D-015). Dérivée de l'ULID de l'entité publiée (discipline
 *  ou composition), donc INVARIANTE au renommage : republier après un
 *  renommage produit le même id → réimport = mise à jour, pas doublon. */
export function idPackStable(entiteId: string): string {
  return `pack-${entiteId}`;
}
