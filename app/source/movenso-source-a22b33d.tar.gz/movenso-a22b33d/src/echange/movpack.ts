/**
 * Conteneur `.movpack` v3 (contrat §6, exigences D-018.1) — le véhicule de la
 * souveraineté : identité du pack, auteur, portée, version, INTÉGRITÉ
 * vérifiée, conditions d'utilisation, réimport idempotent (les ids voyagent).
 *
 * ZIP (fflate) : manifeste.json + bibliotheque.json + videos/<ULID>.
 * Aucune E/S ici : octets → structures et retour. Détection par contenu,
 * jamais par extension.
 */

import { unzipSync, zipSync, Zip, ZipDeflate, ZipPassThrough, Unzip, UnzipInflate, type Zippable } from "fflate";
// Le CONTRAT vit à part (D-274) : ce module-ci ouvre et referme des archives,
// il ne décide pas de ce qu'on exige d'elles.
import {
  VERSION_MOVPACK, ErreurMovpack, LIMITES_MOVPACK, contratIntegrite, validerManifeste,
  estCheminImage, estCheminMedia, exigerImages, exigerNomFidele, idMediaDepuisChemin,
  signatureExecutable, cheminEntreeSur, EXTENSIONS_MEDIA_ARCHIVE,
  type FichierManifeste, type ManifesteMovpack, type OctetsImages,
} from "./movpack-contrat.ts";
import { sourceDe, type Bibliotheque } from "../domaine/modele.ts";
import { migrerAvecImages, type ImageDetachee } from "../domaine/migrations.ts";
import { validerBibliotheque } from "../domaine/validation.ts";
import { registreMedias, type EntreeRegistre } from "../domaine/medias.ts";
import { normaliserPourRecherche } from "../domaine/recherche.ts";
import { Sha256, sha256Hex } from "../domaine/sha256.ts";

/** Version du CONTENEUR (indépendante du schéma de la bibliothèque).
 *  v5 (D-269) : les IMAGES de couverture sont des fichiers `images/<sha256>`,
 *  inscrits à l'inventaire d'intégrité comme les médias — elles ne voyagent
 *  plus en base64 dans `bibliotheque.json`.
 *  v4 (lot 8B) : inventaire d'intégrité PAR FICHIER (bibliotheque.json ET
 *  chaque média), version éditoriale, options d'inclusion explicites.
 *  v3 (empreinte globale de bibliotheque.json seule) reste lisible.
 *  Les v4 et v3 restent LISIBLES : leurs images en base64 sont détachées à la
 *  lecture par la migration de schéma, et l'appelant les reçoit exactement
 *  comme celles d'un v5 — un seul chemin d'écriture en aval. */

export interface MetaExport {
  id: string;
  nom: string;
  portee: ManifesteMovpack["portee"];
  auteur?: string;
  conditions?: string;
  /** Version éditoriale du pack (défaut 1). */
  versionEditoriale?: number;
}

/** Chemin canonique d'un média (§12) : `medias/<mediaId>.<extension>`,
 *  l'extension venant du registre (8A) ; `medias/<id>` nu si inconnue. */
function cheminMedia(registre: Map<string, EntreeRegistre>, id: string): string {
  const ext = registre.get(id)?.media.extension;
  return ext ? `medias/${id}.${ext}` : `medias/${id}`;
}

/** Assemble le manifeste v4 à partir d'un inventaire déjà calculé. */
function construireManifeste(
  b: Bibliotheque,
  meta: MetaExport,
  ids: string[],
  inventaire: FichierManifeste[],
  empreinteBib: string,
  aDesMedias: boolean,
  creeLe: string,
): ManifesteMovpack {
  return {
    format: "movpack",
    version: VERSION_MOVPACK,
    id: meta.id,
    nom: meta.nom,
    portee: meta.portee,
    ...(meta.auteur ? { auteur: meta.auteur } : {}),
    ...(meta.conditions ? { conditions: meta.conditions } : {}),
    creeLe,
    versionSchema: b.versionSchema,
    empreinte: empreinteBib,
    videos: ids,
    versionEditoriale: meta.versionEditoriale ?? 1,
    algorithme: "SHA-256",
    // Options d'inclusion DITES, jamais devinées : les médias présents dans
    // le conteneur ; le contenu personnel n'accompagne que l'export complet.
    inclusions: { medias: aDesMedias, contenuPersonnel: meta.portee === "complet" },
    fichiers: inventaire,
  };
}

/**
 * Export EN MÉMOIRE (petits paquets, fixtures de test) — construit tout
 * l'archive d'un coup. Pour l'app et les gros médias, utiliser
 * `exporterMovpackFlux` (mémoire bornée par blocs, lot 8B §15).
 */
export async function exporterMovpack(
  b: Bibliotheque,
  meta: MetaExport,
  videos: Map<string, Uint8Array>,
  images: OctetsImages = new Map(),
): Promise<Uint8Array> {
  validerBibliotheque(b); // jamais un conteneur invalide en circulation
  exigerImages(b, images);
  const json = new TextEncoder().encode(JSON.stringify(b));
  const empreinteBib = sha256Hex(json);
  const registre = registreMedias(b);
  const inventaire: FichierManifeste[] = [
    { chemin: "bibliotheque.json", taille: json.length, sha256: empreinteBib },
  ];
  for (const [id, contenu] of videos)
    inventaire.push({ chemin: cheminMedia(registre, id), taille: contenu.length, sha256: sha256Hex(contenu) });
  // Les images sont nommées par leur empreinte : l'inventaire la répète, ce
  // qui n'est pas une duplication mais le format commun à tous les fichiers.
  for (const i of b.images ?? [])
    inventaire.push({ chemin: `images/${i.id}`, taille: i.taille, sha256: i.id });
  const manifeste = construireManifeste(b, meta, [...videos.keys()], inventaire, empreinteBib, videos.size > 0, new Date().toISOString());
  const fichiers: Zippable = {
    "manifeste.json": new TextEncoder().encode(JSON.stringify(manifeste, null, 2)),
    "bibliotheque.json": json,
  };
  for (const [id, contenu] of videos) {
    fichiers[cheminMedia(registre, id)] = [contenu, { level: 0 }]; // déjà compressé (vidéo)
  }
  for (const i of b.images ?? []) {
    fichiers[`images/${i.id}`] = [images.get(i.id)!, { level: 0 }]; // JPEG/PNG/WebP : déjà compressés
  }
  return zipSync(fichiers, { level: 6 });
}

/** Rôle du flux d'écriture d'un export à mémoire bornée (§15). */
export interface SortieFlux {
  /** Écrit un chunk du conteneur (progressivement, vers un fichier temporaire). */
  ecrire(chunk: Uint8Array): Promise<void>;
}

/**
 * Export à MÉMOIRE BORNÉE PAR BLOCS (lot 8B §15) — le chemin réel de l'app.
 *
 * De bout en bout : chaque média est lu par blocs de taille fixe
 * (`lireBlocs`, jamais `arrayBuffer()` intégral), haché en SHA-256
 * INCRÉMENTAL, poussé progressivement dans son entrée ZIP (stockée sans
 * compression), et les chunks du conteneur sont écrits au fil de l'eau via
 * `sortie` (vers un fichier temporaire OPFS). Ni le média entier, ni
 * l'archive entière ne résident jamais en mémoire : le pic est borné à
 * quelques blocs (celui lu + celui en attente d'écriture) + les petits JSON.
 *
 * Le manifeste et `bibliotheque.json` (petits) restent en mémoire (autorisé).
 * `estAnnule()` est consulté entre les blocs : une annulation lève
 * `ErreurMovpack` — l'appelant nettoie le fichier temporaire.
 */
export async function exporterMovpackFlux(
  b: Bibliotheque,
  meta: MetaExport,
  ids: string[],
  lireBlocs: (id: string) => AsyncIterable<Uint8Array>,
  sortie: SortieFlux,
  opts: {
    creeLe: string;
    estAnnule?: () => boolean;
    surProgression?: (fait: number, total: number) => void;
    /** Octets des images de couverture (D-269). Petits et en nombre borné —
     *  ils tiennent en mémoire, contrairement aux vidéos qui passent par
     *  `lireBlocs`. Absents alors que l'inventaire en déclare : refus. */
    images?: OctetsImages;
  },
): Promise<ManifesteMovpack> {
  validerBibliotheque(b);
  const images = opts.images ?? new Map();
  exigerImages(b, images);
  const registre = registreMedias(b);
  const json = new TextEncoder().encode(JSON.stringify(b));
  const inventaire: FichierManifeste[] = [
    { chemin: "bibliotheque.json", taille: json.length, sha256: sha256Hex(json) },
  ];

  // File d'attente des chunks émis par fflate (drainée après chaque poussée :
  // ne dépasse jamais la sortie d'un bloc).
  let file: Uint8Array[] = [];
  let erreurZip: Error | null = null;
  const zip = new Zip((err, chunk) => {
    if (err) erreurZip = err;
    else if (chunk && chunk.length) file.push(chunk);
  });
  const drainer = async (): Promise<void> => {
    if (erreurZip) throw new ErreurMovpack(`Compression du conteneur échouée : ${erreurZip.message}`);
    const lot = file;
    file = [];
    for (const c of lot) await sortie.ecrire(c);
  };
  const verifierAnnulation = (): void => {
    if (opts.estAnnule?.()) throw new ErreurMovpack("Export annulé");
  };

  // 1) bibliotheque.json (petit, compressé)
  const eBib = new ZipDeflate("bibliotheque.json", { level: 6 });
  zip.add(eBib);
  eBib.push(json, true);
  await drainer();

  // 2) chaque média, par blocs — lecture, hachage incrémental, poussée ZIP
  for (const id of ids) {
    verifierAnnulation();
    const chemin = cheminMedia(registre, id);
    const entree = new ZipPassThrough(chemin); // vidéo : stockée sans compression
    zip.add(entree);
    const hacheur = new Sha256();
    let taille = 0;
    let enAttente: Uint8Array | null = null; // un bloc d'avance → marquer le dernier
    for await (const bloc of lireBlocs(id)) {
      if (enAttente) {
        entree.push(enAttente, false);
        hacheur.update(enAttente);
        taille += enAttente.length;
        await drainer();
        verifierAnnulation();
      }
      enAttente = bloc;
    }
    if (enAttente) {
      entree.push(enAttente, true);
      hacheur.update(enAttente);
      taille += enAttente.length;
    } else {
      entree.push(new Uint8Array(0), true); // média vide : entrée valide, empreinte du vide
    }
    await drainer();
    inventaire.push({ chemin, taille, sha256: hacheur.digestHex() });
    opts.surProgression?.(inventaire.length - 1, ids.length);
  }

  // 3) les images de couverture — petites, stockées telles quelles (déjà
  //    compressées), et nommées par leur empreinte : l'inventaire la reprend.
  for (const i of b.images ?? []) {
    verifierAnnulation();
    const chemin = `images/${i.id}`;
    const entree = new ZipPassThrough(chemin);
    zip.add(entree);
    entree.push(images.get(i.id)!, true);
    await drainer();
    inventaire.push({ chemin, taille: i.taille, sha256: i.id });
  }

  // 4) manifeste.json en DERNIER (il porte l'inventaire complet)
  const manifeste = construireManifeste(b, meta, ids, inventaire, inventaire[0]!.sha256, ids.length > 0, opts.creeLe);
  const eMan = new ZipDeflate("manifeste.json", { level: 6 });
  zip.add(eMan);
  eMan.push(new TextEncoder().encode(JSON.stringify(manifeste, null, 2)), true);
  await drainer();

  zip.end();
  await drainer();
  return manifeste;
}

/**
 * Réunit les images d'un conteneur, quelle que soit leur provenance.
 *
 * Un v5 les porte en fichiers ; un v4 les portait en base64, et la migration
 * de schéma vient de les détacher. Les deux aboutissent au MÊME objet, avec la
 * même identité (l'empreinte), donc l'appelant n'a qu'un cas à traiter.
 *
 * L'inventaire de la bibliothèque fait autorité : une image du ZIP que
 * personne ne déclare est ignorée (elle serait un fichier orphelin dès
 * l'écriture), et une image déclarée mais absente n'est pas fabriquée — la
 * vignette se dégradera, ce qui est visible, plutôt que d'échouer à l'import
 * d'un pack par ailleurs valide.
 */
function reunirImages(
  b: Bibliotheque,
  detachees: ImageDetachee[],
  duConteneur: Map<string, Uint8Array>,
): ImageDetachee[] {
  const parId = new Map(detachees.map((i) => [i.id, i]));
  for (const declaree of b.images ?? []) {
    if (parId.has(declaree.id)) continue;
    const octets = duConteneur.get(declaree.id);
    if (octets) parId.set(declaree.id, { ...declaree, octets });
  }
  return [...parId.values()];
}

export interface ContenuMovpack {
  manifeste: ManifesteMovpack;
  bibliotheque: Bibliotheque;
  videos: Map<string, Uint8Array>;
  /** Images de couverture, octets compris (D-269). L'appelant les écrit en
   *  fichiers ; il n'a PAS à savoir d'où elles viennent — d'un `images/` du
   *  conteneur (v5) ou du base64 détaché par la migration de schéma (v4 et
   *  antérieurs). Un seul chemin d'écriture en aval, donc un seul à prouver. */
  images: ImageDetachee[];
  /** Fichiers présents dans l'archive mais absents de l'inventaire :
   *  ignorés, jamais exécutés, mais SIGNALÉS (§14). */
  avertissements: string[];
}

export async function lireMovpack(octets: Uint8Array): Promise<ContenuMovpack> {
  let fichiers: Record<string, Uint8Array>;
  try {
    fichiers = unzipSync(octets);
  } catch {
    throw new ErreurMovpack("Fichier illisible : pas une archive .movpack valide");
  }
  const brutManifeste = fichiers["manifeste.json"];
  const brutBibliotheque = fichiers["bibliotheque.json"];
  if (!brutManifeste || !brutBibliotheque) {
    throw new ErreurMovpack("Archive incomplète : manifeste.json et bibliotheque.json attendus");
  }
  const manifeste = validerManifeste(JSON.parse(new TextDecoder().decode(brutManifeste)));
  if (manifeste.version > VERSION_MOVPACK) {
    throw new ErreurMovpack(
      `Conteneur .movpack v${manifeste.version}, plus récent que l'application (v${VERSION_MOVPACK}) — mettre à jour l'application`,
    );
  }

  // Intégrité (§14) : TOUT est vérifié AVANT de construire ou de retourner
  // quoi que ce soit — un conteneur douteux est refusé avant toute mutation.
  const avertissements: string[] = [];
  const videos = new Map<string, Uint8Array>();
  const imagesDuConteneur = new Map<string, Uint8Array>(); // v5 : `images/<empreinte>`
  const inventaire = contratIntegrite(manifeste);
  if (inventaire) {
    // v4 : inventaire par fichier — liste, puis tailles, puis empreintes.
    const declares = new Set<string>(["manifeste.json"]);
    let bibliothequeDeclaree = false;
    for (const f of inventaire) {
      declares.add(f.chemin);
      const contenu = fichiers[f.chemin];
      if (!contenu) throw new ErreurMovpack(`Fichier manquant : ${f.chemin} est déclaré mais absent de l'archive`);
      if (contenu.length !== f.taille)
        throw new ErreurMovpack(`Taille inattendue : ${f.chemin} (${contenu.length} octets, ${f.taille} attendus)`);
      if (sha256Hex(contenu) !== f.sha256)
        throw new ErreurMovpack(`Intégrité en échec : ${f.chemin} ne correspond pas à son empreinte`);
      if (f.chemin === "bibliotheque.json") bibliothequeDeclaree = true;
      else if (estCheminImage(f.chemin)) {
        exigerNomFidele(f.chemin, contenu);
        imagesDuConteneur.set(f.chemin.slice(7), contenu);
      }
      else if (estCheminMedia(f.chemin)) videos.set(idMediaDepuisChemin(f.chemin), contenu);
    }
    if (!bibliothequeDeclaree)
      throw new ErreurMovpack("Manifeste incomplet : bibliotheque.json absent de l'inventaire d'intégrité");
    for (const chemin of Object.keys(fichiers))
      if (!declares.has(chemin)) avertissements.push(`Fichier inattendu ignoré : ${chemin}`);
  } else {
    // v3 (repli) : empreinte globale de bibliotheque.json seule.
    if (sha256Hex(brutBibliotheque) !== manifeste.empreinte)
      throw new ErreurMovpack("Intégrité en échec : le contenu ne correspond pas à l'empreinte du manifeste");
    for (const [chemin, contenu] of Object.entries(fichiers))
      if (estCheminMedia(chemin)) videos.set(idMediaDepuisChemin(chemin), contenu);
  }

  const { bibliotheque, imagesDetachees } = migrerAvecImages(JSON.parse(new TextDecoder().decode(brutBibliotheque)));
  validerBibliotheque(bibliotheque);
  return {
    manifeste,
    bibliotheque,
    videos,
    images: reunirImages(bibliotheque, imagesDetachees, imagesDuConteneur),
    avertissements,
  };
}

/**
 * Puits d'écriture des médias d'un conteneur lu EN FLUX (bêta, D-114) : l'app
 * le branche sur le staging OPFS, les tests sur une collecte mémoire. AUCUN
 * octet de média ne transite jamais par le tas de `lireMovpackFlux` — ils
 * partent au fil de l'eau vers ce puits.
 */
export interface PuitsMediaFlux {
  /** Ouvre l'écriture d'un média (nom physique `<id>.<ext>`). */
  ouvrir(nomPhysique: string): Promise<void>;
  /** Ajoute un bloc au média courant. */
  ecrire(bloc: Uint8Array): Promise<void>;
  /** Clôt le média courant, complet. */
  fermer(): Promise<void>;
  /** Abandonne et nettoie tout ce qui a été mis en attente (échec/annulation). */
  abandonner(): Promise<void>;
}

/** Limites de dépouillement d'une archive (S1.4, D-165) — LARGES pour tout
 *  usage légitime, fatales pour une archive hostile. Surchargées en test. */
export interface MediaStreame {
  id: string;
  nomPhysique: string;
  taille: number;
  sha256: string;
}

export interface ContenuMovpackFlux {
  manifeste: ManifesteMovpack;
  bibliotheque: Bibliotheque;
  /** Médias vérifiés, stockés par le puits — prêts à être promus. */
  medias: MediaStreame[];
  /** Images de couverture, octets compris (D-269) — mêmes que `ContenuMovpack`,
   *  et de la même façon quelle que soit la version du conteneur. */
  images: ImageDetachee[];
  avertissements: string[];
}

type EvenementFlux =
  | { t: "debut"; nom: string }
  | { t: "donnee"; nom: string; bloc: Uint8Array; final: boolean };

function concatener(morceaux: Uint8Array[]): Uint8Array {
  if (morceaux.length === 1) return morceaux[0]!;
  let total = 0;
  for (const m of morceaux) total += m.length;
  const out = new Uint8Array(total);
  let pos = 0;
  for (const m of morceaux) {
    out.set(m, pos);
    pos += m.length;
  }
  return out;
}

/**
 * Lecture EN FLUX d'un `.movpack` (D-114) — la variante à MÉMOIRE BORNÉE de
 * `lireMovpack`, pour l'import/restauration de conteneurs volumineux (la vidéo
 * locale de la bêta). Les petits JSON (manifeste, bibliotheque) sont accumulés
 * en mémoire (autorisé) ; CHAQUE média est décompressé par blocs et poussé
 * aussitôt dans `puits` (staging), haché en SHA-256 INCRÉMENTAL — ni le média
 * entier ni l'archive entière ne résident jamais dans le tas. L'ordre des
 * entrées n'importe pas (le manifeste est vérifié une fois le flux consommé).
 *
 * L'INTÉGRITÉ garde la règle de `lireMovpack` (§14) : tout est vérifié AVANT
 * de rien retourner. Un conteneur douteux `abandonner()` le puits (staging
 * nettoyé) et lève `ErreurMovpack` — les médias ne sont promus qu'à la
 * confirmation, donc l'appelant n'a alors rien de définitif à défaire.
 */
export async function lireMovpackFlux(
  source: ReadableStream<Uint8Array>,
  puits: PuitsMediaFlux,
  opts: { estAnnule?: () => boolean; limites?: Partial<typeof LIMITES_MOVPACK> } = {},
): Promise<ContenuMovpackFlux> {
  // S1.4 (D-165) : bornes de dépouillement — une archive qui les dépasse est
  // HOSTILE ou corrompue, l'import s'arrête proprement (staging nettoyé).
  const lim = { ...LIMITES_MOVPACK, ...opts.limites };
  let entrees = 0;
  let totalDecompresse = 0;
  let brutManifeste: Uint8Array | null = null;
  let brutBibliotheque: Uint8Array | null = null;
  const mediasParChemin = new Map<string, MediaStreame>();
  const imagesDuConteneur = new Map<string, Uint8Array>(); // v5 : `images/<empreinte>`
  let octetsImagesCumules = 0; // accumulées en mémoire : bornées à part (D-271)
  const tousLesNoms = new Set<string>();

  // File d'événements émis SYNCHRONEMENT par fflate pendant `push` ; drainée
  // (asynchrone : écritures OPFS) après chaque push — jamais plus d'un bloc
  // d'entrée en attente.
  const evenements: EvenementFlux[] = [];
  let erreurZip: Error | null = null;
  const uz = new Unzip();
  uz.register(UnzipInflate); // gère « stored » (0) ET « deflate » (8)
  uz.onfile = (fichier) => {
    evenements.push({ t: "debut", nom: fichier.name });
    fichier.ondata = (err, bloc, final) => {
      if (err) erreurZip = err;
      else evenements.push({ t: "donnee", nom: fichier.name, bloc, final });
    };
    fichier.start();
  };

  // Un seul média en écriture à la fois (le ZIP est séquentiel).
  let media: { chemin: string; id: string; nomPhysique: string; hacheur: Sha256; taille: number } | null = null;
  // Petit fichier en cours : JSON connu (accumulé) ou inattendu (drainé sans le garder).
  let petit: { nom: string; garder: boolean; morceaux: Uint8Array[]; taille: number } | null = null;

  const drainer = async (): Promise<void> => {
    while (evenements.length) {
      const e = evenements.shift()!;
      if (e.t === "debut") {
        // S1.4 : chaque entrée est contrôlée AVANT d'être traitée — nombre,
        // chemin sûr, unicité, extension de média attendue.
        if (++entrees > lim.entreesMax)
          throw new ErreurMovpack(`Archive refusée : plus de ${lim.entreesMax} entrées`);
        if (!cheminEntreeSur(e.nom))
          throw new ErreurMovpack(`Archive refusée : chemin dangereux (${e.nom})`);
        if (tousLesNoms.has(e.nom))
          throw new ErreurMovpack(`Archive refusée : chemin en double (${e.nom})`);
        tousLesNoms.add(e.nom);
        if (estCheminMedia(e.nom)) {
          const nomPhysique = e.nom.slice(e.nom.indexOf("/") + 1);
          const ext = nomPhysique.match(/\.([a-z0-9]{1,5})$/i)?.[1]?.toLowerCase();
          if (ext !== undefined && !EXTENSIONS_MEDIA_ARCHIVE.has(ext))
            throw new ErreurMovpack(`Archive refusée : type de média inattendu (${e.nom})`);
          media = { chemin: e.nom, id: idMediaDepuisChemin(e.nom), nomPhysique, hacheur: new Sha256(), taille: 0 };
          await puits.ouvrir(nomPhysique);
        } else {
          // Les IMAGES de couverture (v5) passent par le chemin des petits
          // fichiers : quelques dizaines de Ko chacune, donc l'accumulation
          // reste bornée — inutile de leur ouvrir le puits des médias, qui
          // écrit dans le staging vidéo et promeut vers `videos/`.
          petit = {
            nom: e.nom,
            garder: e.nom === "manifeste.json" || e.nom === "bibliotheque.json" || estCheminImage(e.nom),
            morceaux: [],
            taille: 0,
          };
        }
      } else if (media && e.nom === media.chemin) {
        if (e.bloc.length) {
          // S1.4 : le TYPE RÉEL prime sur l'extension — un exécutable déguisé
          // en vidéo est refusé sur ses premiers octets, borne totale tenue.
          if (media.taille === 0) {
            const s = signatureExecutable(e.bloc);
            if (s) throw new ErreurMovpack(`Archive refusée : ${media.chemin} est un ${s}, pas une vidéo`);
          }
          totalDecompresse += e.bloc.length;
          if (totalDecompresse > lim.octetsTotal)
            throw new ErreurMovpack(`Archive refusée : volume décompressé au-delà de ${Math.round(lim.octetsTotal / 1_000_000)} Mo`);
          media.hacheur.update(e.bloc);
          media.taille += e.bloc.length;
          await puits.ecrire(e.bloc);
        }
        if (e.final) {
          await puits.fermer();
          mediasParChemin.set(media.chemin, { id: media.id, nomPhysique: media.nomPhysique, taille: media.taille, sha256: media.hacheur.digestHex() });
          media = null;
        }
      } else if (petit && e.nom === petit.nom) {
        if (e.bloc.length) {
          // S1.4 : l'accumulation en mémoire des petits fichiers est BORNÉE —
          // c'est la cible exacte d'une « zip bomb » (JSON ultra-compressé).
          totalDecompresse += e.bloc.length;
          petit.taille += e.bloc.length;
          if (totalDecompresse > lim.octetsTotal)
            throw new ErreurMovpack(`Archive refusée : volume décompressé au-delà de ${Math.round(lim.octetsTotal / 1_000_000)} Mo`);
          const plafond = estCheminImage(petit.nom) ? lim.octetsImage : lim.octetsPetitFichier;
          if (petit.taille > plafond)
            throw new ErreurMovpack(`Archive refusée : ${petit.nom} dépasse ${Math.round(plafond / 1_000_000)} Mo`);
          if (estCheminImage(petit.nom)) {
            octetsImagesCumules += e.bloc.length;
            if (octetsImagesCumules > lim.octetsImagesTotal)
              throw new ErreurMovpack(
                `Archive refusée : ses images dépassent ${Math.round(lim.octetsImagesTotal / 1_000_000)} Mo cumulés`
                + " — elles sont lues en mémoire, un appareil modeste n'y survivrait pas",
              );
          }
          if (petit.garder) petit.morceaux.push(e.bloc.slice()); // copie : le tampon fflate est réutilisé au push suivant
        }
        if (e.final) {
          if (petit.garder) {
            const total = concatener(petit.morceaux);
            if (petit.nom === "manifeste.json") brutManifeste = total;
            else if (petit.nom === "bibliotheque.json") brutBibliotheque = total;
            else imagesDuConteneur.set(petit.nom.slice(7), total);
          }
          petit = null;
        }
      }
    }
  };

  const illisible = () => new ErreurMovpack("Fichier illisible : pas une archive .movpack valide");

  try {
    const lecteur = source.getReader();
    for (;;) {
      if (opts.estAnnule?.()) throw new ErreurMovpack("Import annulé");
      const { done, value } = await lecteur.read();
      try {
        uz.push(value ?? new Uint8Array(0), done);
      } catch {
        throw illisible();
      }
      if (erreurZip) throw illisible();
      await drainer();
      if (done) break;
    }

    // Intégrité — TOUT est vérifié avant de rien retourner (§14). (Capture en
    // const : ces `let` sont assignés dans une closure, le CFA de TS ne les
    // affine pas sinon.)
    const octetsManifeste = brutManifeste as Uint8Array | null;
    const octetsBibliotheque = brutBibliotheque as Uint8Array | null;
    if (!octetsManifeste || !octetsBibliotheque)
      throw new ErreurMovpack("Archive incomplète : manifeste.json et bibliotheque.json attendus");
    const manifeste = validerManifeste(JSON.parse(new TextDecoder().decode(octetsManifeste)));
    if (manifeste.version > VERSION_MOVPACK)
      throw new ErreurMovpack(
        `Conteneur .movpack v${manifeste.version}, plus récent que l'application (v${VERSION_MOVPACK}) — mettre à jour l'application`,
      );

    const avertissements: string[] = [];
    let medias: MediaStreame[];
    const inventaire = contratIntegrite(manifeste);
    if (inventaire) {
      // v4 : inventaire par fichier — chaque déclaration confrontée à ce qui a
      // réellement transité (taille + empreinte), rien de promu sans preuve.
      const declares = new Set<string>(["manifeste.json"]);
      let bibliothequeDeclaree = false;
      medias = [];
      for (const f of inventaire) {
        declares.add(f.chemin);
        if (f.chemin === "bibliotheque.json") {
          if (octetsBibliotheque.length !== f.taille)
            throw new ErreurMovpack(`Taille inattendue : bibliotheque.json (${octetsBibliotheque.length} octets, ${f.taille} attendus)`);
          if (sha256Hex(octetsBibliotheque) !== f.sha256)
            throw new ErreurMovpack("Intégrité en échec : bibliotheque.json ne correspond pas à son empreinte");
          bibliothequeDeclaree = true;
        } else if (estCheminImage(f.chemin)) {
          const octets = imagesDuConteneur.get(f.chemin.slice(7));
          if (!octets) throw new ErreurMovpack(`Fichier manquant : ${f.chemin} est déclaré mais absent de l'archive`);
          if (octets.length !== f.taille)
            throw new ErreurMovpack(`Taille inattendue : ${f.chemin} (${octets.length} octets, ${f.taille} attendus)`);
          if (sha256Hex(octets) !== f.sha256)
            throw new ErreurMovpack(`Intégrité en échec : ${f.chemin} ne correspond pas à son empreinte`);
          exigerNomFidele(f.chemin, octets);
        } else {
          const m = mediasParChemin.get(f.chemin);
          if (!m) throw new ErreurMovpack(`Fichier manquant : ${f.chemin} est déclaré mais absent de l'archive`);
          if (m.taille !== f.taille)
            throw new ErreurMovpack(`Taille inattendue : ${f.chemin} (${m.taille} octets, ${f.taille} attendus)`);
          if (m.sha256 !== f.sha256)
            throw new ErreurMovpack(`Intégrité en échec : ${f.chemin} ne correspond pas à son empreinte`);
          medias.push(m);
        }
      }
      if (!bibliothequeDeclaree)
        throw new ErreurMovpack("Manifeste incomplet : bibliotheque.json absent de l'inventaire d'intégrité");
      // « Ignoré » doit être VRAI : une image collectée au fil du flux mais
      // absente de l'inventaire n'a jamais rencontré `exigerNomFidele` — la
      // laisser dans `imagesDuConteneur`, c'est laisser `reunirImages` la
      // promouvoir avec des octets jamais confrontés à son nom (D-271). Le
      // lecteur non-flux ne collecte que dans la boucle d'inventaire ; ici on
      // évince, même parité.
      for (const nom of tousLesNoms) {
        if (declares.has(nom)) continue;
        avertissements.push(`Fichier inattendu ignoré : ${nom}`);
        if (estCheminImage(nom)) imagesDuConteneur.delete(nom.slice(7));
      }
    } else {
      // v3 (repli) : empreinte globale de bibliotheque.json seule. Les images
      // en fichiers n'existent qu'à partir de v5 : un `images/<hash>` dans un
      // conteneur qui se déclare v3 n'a rencontré AUCUN contrôle de nom — le
      // promouvoir laisserait un conteneur choisir la rigueur qu'on lui
      // applique (D-263/D-271). Le lecteur non-flux ne collecte jamais
      // d'images sur cette branche : même parité, on évince.
      if (sha256Hex(octetsBibliotheque) !== manifeste.empreinte)
        throw new ErreurMovpack("Intégrité en échec : le contenu ne correspond pas à l'empreinte du manifeste");
      medias = [...mediasParChemin.values()];
      for (const h of imagesDuConteneur.keys()) avertissements.push(`Fichier inattendu ignoré : images/${h}`);
      imagesDuConteneur.clear();
    }

    const { bibliotheque, imagesDetachees } = migrerAvecImages(JSON.parse(new TextDecoder().decode(octetsBibliotheque)));
    validerBibliotheque(bibliotheque);
    return {
      manifeste,
      bibliotheque,
      medias,
      images: reunirImages(bibliotheque, imagesDetachees, imagesDuConteneur),
      avertissements,
    };
  } catch (e) {
    await puits.abandonner();
    throw e instanceof ErreurMovpack ? e : illisible();
  }
}

/** Source d'un élément : le pack d'origine, ou « local » (créé sur cet appareil). */
/**
 * Extrait un pack publiable d'une discipline, borné à un PÉRIMÈTRE DE SOURCES
 * (D-023, fermeture 2) : une publication n'emporte jamais par défaut les
 * contributions d'une source que l'auteur ne maîtrise pas — le contenu local
 * seul par défaut, chaque source importée en opt-in explicite. Le carnet
 * personnel ne se publie jamais. Fonction pure.
 */
/** Une relation exclue de la publication car sa cible est hors périmètre
 *  (lot 10B, A1) — pour l'annonce d'aperçu et le rapport final. */