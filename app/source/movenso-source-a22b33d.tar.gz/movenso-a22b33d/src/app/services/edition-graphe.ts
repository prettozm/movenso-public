/**
 * ÉDITION DU GRAPHE et vie des fiches (extrait de `racine.ts`, D-274).
 *
 * Ce qui réunit ces gestes n'est pas un écran, c'est une exigence : **rien de
 * destructeur sans point de retour.** Une arête se retire mais l'arbitrage
 * d'un conflit d'import reste explicite (D-157/D-243) ; une fiche va en
 * corbeille et en revient (D-081) ; une discipline annonce ce qu'elle emporte
 * avant de partir ; et la purge PHYSIQUE ne touche que ce que plus rien ne
 * référence — corbeille comprise, tant qu'une fiche y est restaurable.
 *
 * Extraction à comportement strictement inchangé (méthode S3.A1) : la classe
 * garde la surface que les vues et l'e2e appellent, la logique vit ici.
 */
import type { Bibliotheque, ConflitContribution, ConflitLiaison, Relation } from "../../domaine/modele.ts";
import { arbitrerConflitLiaison as arbitrerConflitLiaisonDomaine, arbitrerConflitContribution as arbitrerConflitContributionDomaine } from "../../domaine/rapprochement.ts";
import { referencesVideosLocales } from "../../domaine/medias.ts";
import { retirerLiensProposes } from "./import-pack.ts";
import { reinitEditionLien as reinitEditionLienFeuille } from "../relations-visuelle.ts";
import type { EntreeCorbeille } from "../../domaine/modele.ts";
import type { MovensoApp } from "../racine.ts";

/** Arbitre UN conflit de liaison détecté à l'import (D-157/D-243) : la
 *  mienne / celle du pack / les deux, ou — pour un retrait proposé — garder
 *  ou retirer. Jamais silencieux. */
export async function arbitrerConflitLiaison(app: MovensoApp, conflit: ConflitLiaison, choix: "local" | "pack" | "deux" | "retirer"): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour arbitrer ce conflit.", () => void app.arbitrerConflitLiaison(conflit, choix))) return;
  const b = app.bibliotheque;
  if (!b) return;
  arbitrerConflitLiaisonDomaine(b, conflit, choix);
  await app.persister(b);
  app.afficherToast(
    choix === "retirer" ? "Lien retiré ✓"
      : choix === "local" ? "Ton lien conservé ✓"
      : choix === "pack" ? "Version du pack appliquée ✓"
      : "Les deux raisons conservées ✓",
  );
}

/** Arbitre un conflit de CONTRIBUTION (D-298, patron D-243) : « la mienne »
 *  classe sans toucher au texte, « celle du pack » remplace et efface la
 *  signature d'édition. */
export async function arbitrerConflitContribution(app: MovensoApp, conflit: ConflitContribution, choix: "locale" | "pack"): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour arbitrer ce texte.", () => void arbitrerConflitContribution(app, conflit, choix))) return;
  const b = app.bibliotheque;
  if (!b) return;
  arbitrerConflitContributionDomaine(b, conflit, choix);
  await app.persister(b);
  app.afficherToast(choix === "locale" ? "Ton texte conservé ✓" : "Texte du pack appliqué ✓");
}

/** Accepte EN BLOC les retraits proposés par un pack (D-243) — le détail vit
 *  au service (`services/import-pack.ts`), racine ne fait que déléguer. */
export async function retirerTousLesLiensProposes(app: MovensoApp, packId: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour retirer ces liens.", () => void app.retirerTousLesLiensProposes(packId))) return;
  retirerLiensProposes(app, packId);
}

/** Ouvre la feuille « Lien » (D-156) — création (cible/type absents) ou
 *  édition d'une arête existante. `sourceId` null = source à choisir aussi
 *  (entrée Plus › Relations, avec un type présélectionné). */
export function ouvrirEditionLien(app: MovensoApp, sourceId: string | null, cibleId?: string, typeId?: string, typePrefere?: string): void {
  if (!app.garde("modification", "Saisis le PIN pour modifier les liens.", () => app.ouvrirEditionLien(sourceId, cibleId, typeId, typePrefere))) return;
  reinitEditionLienFeuille();
  app.editionLien = {
    sourceId,
    ...(cibleId !== undefined ? { cibleId } : {}),
    ...(typeId !== undefined ? { typeId } : {}),
    ...(typePrefere !== undefined ? { typePrefere } : {}),
  };
  app.requestUpdate();
}

/** Crée UN lien (source → type → cible) avec sa raison/priorité (D-156).
 *  Refus actionnables : cible absente, auto-lien, doublon (même type + même
 *  cible). L'inverse n'est JAMAIS stocké (dérivé, contrat §2.1). */
export async function ajouterRelation(app: MovensoApp, sourceId: string, rel: Relation): Promise<boolean> {
  if (!app.garde("modification", "Saisis le PIN pour créer un lien.", () => void app.ajouterRelation(sourceId, rel))) return false;
  const b = app.bibliotheque;
  const source = b?.techniques.find((t) => t.id === sourceId);
  if (!b || !source) return false;
  if (rel.cibleId === sourceId) { app.afficherToast("Une technique ne peut pas être liée à elle-même", "alerte"); return false; }
  if (!b.techniques.some((t) => t.id === rel.cibleId)) { app.afficherToast("Technique cible introuvable", "alerte"); return false; }
  if (source.relations.some((r) => r.type === rel.type && r.cibleId === rel.cibleId)) {
    app.afficherToast("Ce lien existe déjà", "alerte"); return false;
  }
  source.relations.push({
    type: rel.type, cibleId: rel.cibleId,
    ...(rel.note !== undefined ? { note: rel.note } : {}),
    ...(rel.priorite !== undefined ? { priorite: rel.priorite } : {}),
  });
  await app.persister(b);
  app.afficherToast("Lien ajouté ✓");
  return true;
}

/** Modifie une arête existante (D-156) : raison, priorité, type. `null`
 *  efface le champ (la raison/priorité redeviennent absentes). */
export async function modifierRelation(
  app: MovensoApp,
  sourceId: string, cibleId: string, typeId: string,
  patch: { type?: string; note?: string | null; priorite?: number | null },
): Promise<boolean> {
  if (!app.garde("modification", "Saisis le PIN pour modifier ce lien.", () => void app.modifierRelation(sourceId, cibleId, typeId, patch))) return false;
  const b = app.bibliotheque;
  const source = b?.techniques.find((t) => t.id === sourceId);
  const r = source?.relations.find((x) => x.type === typeId && x.cibleId === cibleId);
  if (!b || !source || !r) return false;
  if (patch.type !== undefined && patch.type !== r.type) {
    if (source.relations.some((x) => x !== r && x.type === patch.type && x.cibleId === cibleId)) {
      app.afficherToast("Un lien de ce type vers cette technique existe déjà", "alerte"); return false;
    }
    r.type = patch.type;
  }
  if (patch.note !== undefined) { if (patch.note === null || patch.note.trim() === "") delete r.note; else r.note = patch.note.trim(); }
  if (patch.priorite !== undefined) { if (patch.priorite === null) delete r.priorite; else r.priorite = patch.priorite; }
  await app.persister(b);
  app.afficherToast("Lien modifié ✓");
  return true;
}

/** Supprime un type de lien — UNIQUEMENT s'il est inutilisé (lot 6 §10,
 *  remplace la rupture consentie : retirer d'abord les relations sur les
 *  fiches concernées, jamais de suppression en masse depuis l'Atelier). */
export async function supprimerTypeRelation(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer ce type de lien.", () => void app.supprimerTypeRelation(id))) return;
  const b = app.bibliotheque;
  const type = b?.typesRelation.find((t) => t.id === id);
  if (!b || !type) return;
  const rompues = app.usagesTypeRelation(id);
  if (rompues) {
    app.afficherToast(`« ${type.libelle} » est utilisé par ${rompues} relation${rompues > 1 ? "s" : ""} — retire-les d'abord des fiches concernées`, "alerte");
    return;
  }
  b.typesRelation = b.typesRelation.filter((t) => t.id !== id);
  await app.persister(b);
  app.afficherToast(`Lien « ${type.libelle} » supprimé ✓`);
}

/** Retire une identité (analyse D-023 : aucune impasse — l'erreur se corrige).
 *  Les notes personnelles redeviennent « à rattacher » ; le savoir sourcé
 *  attaché part avec elle ; les références (relations, blocs) restent
 *  tolérées absentes et diagnostiquées à l'Atelier. */
/** Retire une technique en la plaçant EN CORBEILLE (D-081) : geste réversible
 *  tant que la corbeille n'est pas vidée. La fiche et ses contributions quittent
 *  les listes vivantes (donc disparaissent partout : biblio, favoris, filtres,
 *  compteurs, relations dérivées) mais rien n'est détruit ni nettoyé — les liens
 *  ENTRANTS restent en place, simplement masqués (leur cible ne résout plus). */
export async function supprimerTechnique(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour retirer cette technique.", () => void app.supprimerTechnique(id))) return;
  const b = app.bibliotheque;
  const t = b?.techniques.find((x) => x.id === id);
  if (!b || !t) return;
  const contributions = b.contributions.filter((c) => c.techniqueId === id);
  const entree: EntreeCorbeille = {
    supprimeeLe: new Date().toISOString(),
    technique: t,
    contributions,
    etaitFavori: b.favoris.includes(id),
  };
  b.corbeille = [entree, ...(b.corbeille ?? [])];
  b.techniques = b.techniques.filter((x) => x.id !== id);
  b.contributions = b.contributions.filter((c) => c.techniqueId !== id);
  b.favoris = b.favoris.filter((x) => x !== id); // le marque-page suit l'identité (lot 5 §6)
  await app.persister(b);
  app.editionFiche = false;
  // Ne dépiler QUE si l'écran courant est la fiche supprimée : depuis la
  // liste de Plus › Gestion des techniques, `retour()` renvoyait au menu
  // Plus au lieu de rester dans le sous-écran (constat porteur, D-308).
  if (app.ecran.type === "fiche" && app.ecran.techniqueId === id) app.retour();
  app.afficherToast(`« ${t.nom} » mise en corbeille ✓ — restaurable depuis Plus › Corbeille`);
}

/** Restaure une fiche depuis la corbeille (D-081) : elle et ses contributions
 *  reviennent à l'identique, le favori est rétabli, ses liens entrants (jamais
 *  touchés) se rallument. */
export async function restaurerTechnique(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour restaurer cette fiche.", () => void app.restaurerTechnique(id))) return;
  const b = app.bibliotheque;
  const e = b?.corbeille?.find((x) => x.technique.id === id);
  if (!b || !e) return;
  b.corbeille = (b.corbeille ?? []).filter((x) => x.technique.id !== id);
  b.techniques = [...b.techniques, e.technique];
  b.contributions = [...b.contributions, ...e.contributions];
  if (e.etaitFavori && !b.favoris.includes(id)) b.favoris = [...b.favoris, id];
  await app.persister(b);
  app.afficherToast(`« ${e.technique.nom} » restaurée ✓`);
}

/** Purge DÉFINITIVEMENT une entrée de corbeille (D-081) — irréversible.
 *  C'est ICI que la cascade s'exécute enfin : les liens entrants qui pointaient
 *  vers la fiche sont nettoyés (les deux lectures d'un coup, l'inverse étant
 *  dérivé), les notes personnelles reviennent « à rattacher », le savoir sourcé
 *  disparaît. Les compositions utilisatrices ne gardent qu'un repère « absente ».
 *  Un snapshot est pris avant tout vidage (filet général). */
async function purger(app: MovensoApp, b: Bibliotheque, ids: string[]): Promise<void> {
  const cible = new Set(ids);
  const entrees = (b.corbeille ?? []).filter((e) => cible.has(e.technique.id));
  if (entrees.length === 0) return;
  for (const t of b.techniques) t.relations = t.relations.filter((r) => !cible.has(r.cibleId));
  for (const e of entrees) {
    const perso = e.contributions
      .filter((c) => c.provenance === "personnel")
      .map((c) => ({ ...c, techniqueId: null }));
    b.contributions = [...b.contributions, ...perso]; // le savoir sourcé n'existe pas sans son identité
  }
  b.corbeille = (b.corbeille ?? []).filter((e) => !cible.has(e.technique.id));
  await app.persister(b);
}

/** Supprime définitivement UNE fiche de la corbeille (avec confirmation en amont). */
export async function supprimerDefinitivement(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer définitivement.", () => void app.supprimerDefinitivement(id))) return;
  const b = app.bibliotheque;
  const e = b?.corbeille?.find((x) => x.technique.id === id);
  if (!b || !e) return;
  await app.stockage.snapshot(`avant-purge-${e.technique.nom}`);
  await purger(app, b, [id]);
  app.afficherToast(`« ${e.technique.nom} » supprimée définitivement ✓ — point de restauration conservé`);
}

/** Vide TOUTE la corbeille (D-081) — irréversible, snapshot pris avant. */
export async function viderCorbeille(app: MovensoApp): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour vider la corbeille.", () => void app.viderCorbeille())) return;
  const b = app.bibliotheque;
  if (!b || !(b.corbeille ?? []).length) return;
  const n = b.corbeille!.length;
  await app.stockage.snapshot("avant-vidage-corbeille");
  await purger(app, b, b.corbeille!.map((e) => e.technique.id));
  app.afficherToast(`Corbeille vidée ✓ — ${n} fiche${n > 1 ? "s" : ""} supprimée${n > 1 ? "s" : ""}, point de restauration conservé`);
}

/** Retire une discipline VIDE (sinon message actionnable — jamais de perte en masse silencieuse). */
export async function supprimerDiscipline(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour retirer cette discipline.", () => void app.supprimerDiscipline(id))) return;
  const b = app.bibliotheque;
  const d = b?.disciplines.find((x) => x.id === id);
  if (!b || !d) return;
  const restantes = b.techniques.filter((t) => t.disciplineId === id).length;
  if (restantes) {
    app.afficherToast(`« ${d.nom} » contient encore ${restantes} technique${restantes > 1 ? "s" : ""} — retire-les d'abord (fiche → crayon → Retirer)`, "alerte");
    return;
  }
  await app.stockage.snapshot(`avant-retrait-${d.nom}`);
  b.disciplines = b.disciplines.filter((x) => x.id !== id);
  await app.persister(b);
  app.afficherToast(`Discipline « ${d.nom} » retirée ✓`);
}

/** Déplace une discipline d'un cran dans l'ordre de la racine (lot 6 §6). */
export function reordonnerDiscipline(app: MovensoApp, id: string, delta: -1 | 1): void {
  if (!app.garde("modification", "Saisis le PIN pour réordonner les disciplines.", () => void app.reordonnerDiscipline(id, delta))) return;
  const b = app.bibliotheque;
  if (!b) return;
  const i = b.disciplines.findIndex((d) => d.id === id);
  const j = i + delta;
  if (i < 0 || j < 0 || j >= b.disciplines.length) return;
  const [d] = b.disciplines.splice(i, 1);
  b.disciplines.splice(j, 0, d!);
  void app.persister(b);
}
