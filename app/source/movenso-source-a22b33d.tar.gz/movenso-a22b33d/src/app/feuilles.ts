/**
 * FEUILLES ET VOILES DU SHELL (S3.A1, tranche T7 — gabarits extraits de
 * racine.ts, code déménagé tel quel) : voile « … en cours » (annulable S2.4),
 * proposition d'import, rapport d'import (conflits D-157 compris),
 * restauration, partage de technique, panneau de progression d'enregistrement.
 * Fonctions de RENDU recevant `app` — l'état reste sur la racine.
 */

import { html, nothing, type TemplateResult } from "lit";
import type { MovensoApp } from "./racine.ts";

/** Voile « … en cours » bloquant (D-127) pendant une opération longue — import,
 *  restauration, préparation d'un fichier d'export (avec sa progression média
 *  quand elle est connue). Évite le sentiment d'app figée. */
export function voileOccupe(app: MovensoApp): TemplateResult | typeof nothing {
  const p = app.progressionExport;
  const message = p
    ? p.total > 0
      ? `Préparation du fichier — ${p.fait} / ${p.total} vidéo${p.total > 1 ? "s" : ""}`
      : "Préparation du fichier…"
    : app.occupe;
  if (!message) return nothing;
  return html`<div class="voile-occupe" role="status" aria-live="polite">
    <div class="occupe-carte"><span class="occupe-spinner" aria-hidden="true"></span><span>${message}</span>
      ${app.annulationOccupe
        ? html`<button class="chip-filtre" style="margin-left:6px"
            @click=${() => app.annulationOccupe?.executer()}>${app.annulationOccupe.libelle}</button>`
        : nothing}
    </div>
  </div>`;
}

/** Proposition de fusion à l'import (D-023) : rien ne s'écrit sans accord.
 *  Lot 6 §17 : l'aperçu montre aussi le manifeste (nom, auteur, portée,
 *  volume) quand le fichier est un vrai conteneur .movpack. */
export function feuilleImport(app: MovensoApp) {
  const attente = app.importEnAttente!;
  const { rapport, manifeste, volume, medias } = attente;
  const nbVideos = medias.length;
  const ligne = (n: number, quoi: string) =>
    n ? html`<li><b>${n}</b> ${quoi}</li>` : nothing;
  const ko = volume >= 1_000_000 ? `${(volume / 1_000_000).toFixed(1)} Mo` : `${Math.max(1, Math.round(volume / 1000))} Ko`;
  const nbAjout = rapport.creees.length;
  const miseAJour = rapport.rejointes.length > 0 || rapport.retirees.length > 0;
  const deja = attente.dejaInstalle;
  const nom = manifeste?.nom ?? rapport.discipline;
  // MAJ-2 (D-307) : l'édition retenue au dernier import — pour dire d'où vers où.
  const editionInstallee = app.bibliotheque?.editionsPacks?.find((e) => e.pack === attente.packId)?.versionEditoriale;
  // MAJ-1 (D-307) : sur une mise à jour, dire ce qui CHANGE — « rien de
  // nouveau » sur 91 fiches réécrites faisait douter de l'app.
  const rienNeChange = deja && !nbAjout && !rapport.fichesModifiees && !rapport.compositionsModifiees
    && !rapport.imagesAjoutees && !rapport.relationsAjoutees && !rapport.retirees.length
    && !rapport.conflitsLiaisons && !rapport.retraitsProposes && !rapport.conflitsContributions;
  return html`
    <div class="voile" @click=${() => app.annulerImport()}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Proposition d'import">
      <div class="prise"></div>
      <h2>${deja ? html`Mettre à jour « ${nom} » ?` : html`Installer « ${nom} » ?`}</h2>
      <div class="geste manifeste-import">
        ${manifeste?.auteur ? html`${manifeste.auteur} · ` : nothing}${nbVideos
          ? html`${nbVideos} vidéo${nbVideos > 1 ? "s" : ""} · `
          : nothing}${ko}${manifeste?.conditions ? html`<br>Conditions : ${manifeste.conditions}` : nothing}${manifeste?.versionEditoriale
          ? html`<br>Édition ${deja && editionInstallee && editionInstallee !== manifeste.versionEditoriale
              ? html`${editionInstallee} → ${manifeste.versionEditoriale}`
              : manifeste.versionEditoriale}`
          : nothing}
      </div>
      ${deja
        ? html`<div class="geste avertissement-import" style="color:var(--attention,#b26b00)">
            ⚠ Ce pack est déjà installé. Le mettre à jour remplace le contenu du pack par cette version.
            Tes vidéos, notes et favoris sont conservés ; un texte de fiche <b>du pack</b> que tu as modifié n'est jamais écrasé — les écarts te seront proposés.</div>`
        : nothing}
      ${attente.avertissements.length
        ? html`<div class="geste avertissement-import" style="color:var(--attention,#b26b00)">
            ⚠ ${attente.avertissements.join(" · ")}</div>`
        : nothing}
      <ul class="points" style="margin:8px 0 0; list-style:none; padding:0">
        ${deja
          ? html`
            ${ligne(nbAjout, "technique(s) ajoutée(s)")}
            ${ligne(rapport.fichesModifiees, "fiche(s) mise(s) à jour")}
            ${ligne(rapport.compositionsModifiees, "composition(s) mise(s) à jour")}
            ${ligne(rapport.imagesAjoutees, "image(s) ajoutée(s)")}
            ${ligne(rapport.relationsAjoutees, "lien(s) ajouté(s)")}
            ${ligne(rapport.retirees.length, "élément(s) que cette version ne contient plus")}
            ${rienNeChange ? html`<li>À jour — cette version ne change rien.</li>` : nothing}`
          : html`
            <li>${nbAjout ? html`<b>${nbAjout}</b> technique${nbAjout > 1 ? "s" : ""} ser${nbAjout > 1 ? "ont" : "a"} ajoutée${nbAjout > 1 ? "s" : ""}.` : "Rien de nouveau à ajouter."}</li>
            <li>${miseAJour ? "Le contenu du pack déjà installé est mis à jour." : "Aucune technique existante ne sera modifiée."}</li>`}
        ${rapport.conflitsLiaisons
          ? html`<li><b>${rapport.conflitsLiaisons}</b> liaison${rapport.conflitsLiaisons > 1 ? "s" : ""} diffère${rapport.conflitsLiaisons > 1 ? "nt" : ""} du pack — te ser${rapport.conflitsLiaisons > 1 ? "ont" : "a"} proposée${rapport.conflitsLiaisons > 1 ? "s" : ""}, rien d'appliqué d'office.</li>`
          : nothing}
        ${rapport.retraitsProposes
          ? html`<li><b>${rapport.retraitsProposes}</b> lien${rapport.retraitsProposes > 1 ? "s" : ""} que tu as ${rapport.retraitsProposes > 1 ? "ne sont" : "n'est"} plus déclaré${rapport.retraitsProposes > 1 ? "s" : ""} par cette version — te ser${rapport.retraitsProposes > 1 ? "ont" : "a"} proposé${rapport.retraitsProposes > 1 ? "s" : ""} au retrait, rien de retiré d'office.</li>`
          : nothing}
        ${rapport.conflitsContributions
          ? html`<li><b>${rapport.conflitsContributions}</b> texte${rapport.conflitsContributions > 1 ? "s" : ""} que tu as modifié${rapport.conflitsContributions > 1 ? "s" : ""} diffère${rapport.conflitsContributions > 1 ? "nt" : ""} de cette version — te ser${rapport.conflitsContributions > 1 ? "ont" : "a"} proposé${rapport.conflitsContributions > 1 ? "s" : ""}, rien d'écrasé d'office.</li>`
          : nothing}
      </ul>
      ${rapport.suggestions.length
        ? html`<p class="geste" style="padding:8px 0 0; line-height:1.5">
            <b>${rapport.suggestions.length}</b> technique${rapport.suggestions.length > 1 ? "s semblent" : " semble"} déjà présente${rapport.suggestions.length > 1 ? "s" : ""} dans un autre pack.
            Elles resteront séparées et pourront être comparées plus tard dans Plus › Doublons potentiels.</p>`
        : nothing}
      <div class="actions">
        <button class="bouton" @click=${() => app.annulerImport()}>Annuler</button>
        <button class="bouton principal" @click=${() => void app.confirmerImport()}>${deja ? "Mettre à jour" : "Installer"}</button>
      </div>
    </div>
  `;
}

/** Rapport compact APRÈS import (lot 6 §18) : ce qui a changé, avec des
 *  actions — jamais un simple « Import réussi », jamais de renvoi forcé. */
export function feuilleRapportImport(app: MovensoApp) {
  const r = app.rapportApresImport!;
  const ligne = (n: number, quoi: string) => (n ? html`<li><b>${n}</b> ${quoi}</li>` : nothing);
  return html`
    <div class="voile" @click=${() => app.fermerRapportImport()}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Rapport d'import">
      <div class="prise"></div>
      <h2>« ${r.discipline} » installé ✓</h2>
      <ul class="points" style="margin:4px 0 0; list-style:none; padding:0">
        ${ligne(r.creees, "technique(s) ajoutée(s)")}
        ${ligne(r.fichesModifiees, "fiche(s) mise(s) à jour")}
        ${ligne(r.compositionsModifiees, "composition(s) mise(s) à jour")}
        ${ligne(r.imagesAjoutees, "image(s) ajoutée(s)")}
        ${ligne(r.videos, "vidéo(s) ajoutée(s)")}
      </ul>
      ${r.suggestions.length
        ? html`<p class="geste" style="padding:8px 0 0; line-height:1.5">
            <b>${r.suggestions.length}</b> technique${r.suggestions.length > 1 ? "s" : ""} à comparer plus tard dans Plus › Doublons potentiels.
          </p>`
        : nothing}
      ${r.conflitsLiaisons
        ? html`<p class="geste" style="padding:8px 0 0; line-height:1.5">
            <b>${r.conflitsLiaisons}</b> liaison${r.conflitsLiaisons > 1 ? "s" : ""} diffère${r.conflitsLiaisons > 1 ? "nt" : ""} du pack —
            <button class="lien-texte" @click=${() => { app.fermerRapportImport(); app.ouvrirPlusSection("relations"); }}>à arbitrer dans Plus › Relations</button>.
          </p>`
        : nothing}
      <!-- D-243 : la phrase qui manquait. « J'ai mis à jour et rien n'a
           changé » venait de là — un pack qui RETIRE des liens ne disait rien,
           parce que rien n'était retiré. Le nombre est dit, et rien n'a bougé. -->
      ${r.retraitsProposes
        ? html`<p class="geste" style="padding:8px 0 0; line-height:1.5">
            <b>${r.retraitsProposes}</b> lien${r.retraitsProposes > 1 ? "s" : ""} que tu as ${r.retraitsProposes > 1 ? "ne sont" : "n'est"} plus déclaré${r.retraitsProposes > 1 ? "s" : ""} par ce pack — rien n'a été retiré :
            <button class="lien-texte" @click=${() => { app.fermerRapportImport(); app.ouvrirPlusSection("relations"); }}>à décider dans Plus › Relations</button>.
          </p>`
        : nothing}
      ${r.conflitsContributions
        ? html`<p class="geste" style="padding:8px 0 0; line-height:1.5">
            <b>${r.conflitsContributions}</b> texte${r.conflitsContributions > 1 ? "s" : ""} que tu as modifié${r.conflitsContributions > 1 ? "s" : ""} diffère${r.conflitsContributions > 1 ? "nt" : ""} de cette version — rien n'a été écrasé :
            <button class="lien-texte" @click=${() => { app.fermerRapportImport(); app.ouvrirPlusSection("atraiter"); }}>à arbitrer dans Plus › À traiter</button>.
          </p>`
        : nothing}
      <div class="actions">
        ${r.disciplineId
          ? html`<button class="bouton" @click=${() => { const id = r.disciplineId!; app.fermerRapportImport(); app.ouvrirDiscipline(id); }}>
              Ouvrir la discipline</button>`
          : nothing}
        <button class="bouton principal" @click=${() => app.fermerRapportImport()}>Fermer</button>
      </div>
    </div>
  `;
}

/** Restauration complète proposée AVANT toute écriture (lot 6 §23.A) :
 *  contenu, date et volume visibles, annulable sans changement. */
export function feuilleRestauration(app: MovensoApp) {
  const c = app.restaurationEnAttente!;
  const b = c.bibliotheque;
  return html`
    <div class="voile" @click=${() => app.annulerRestauration()}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Restauration complète">
      <div class="prise"></div>
      <h2>Restaurer cette sauvegarde complète ?</h2>
      <div class="geste">
        ${c.manifeste.creeLe.slice(0, 10)} ·
        ${b.disciplines.length} discipline${b.disciplines.length > 1 ? "s" : ""} (${b.disciplines.map((d) => d.nom).join(", ")}) ·
        ${b.techniques.length} techniques · ${b.contributions.length} contenus ·
        ${b.compositions.length} composition${b.compositions.length > 1 ? "s" : ""} ·
        ${b.favoris.length} favori${b.favoris.length > 1 ? "s" : ""} ·
        ${c.medias.length} vidéo${c.medias.length > 1 ? "s" : ""}
      </div>
      ${c.avertissements.length
        ? html`<div class="geste avertissement-import" style="color:var(--attention,#b26b00)">
            ⚠ ${c.avertissements.join(" · ")}</div>`
        : nothing}
      <p class="fil-vide" style="padding:6px 0 0">
        Cette installation est vierge : rien n'est remplacé. Rien n'est
        écrit avant ta confirmation.
      </p>
      <div class="actions">
        <button class="bouton" @click=${() => app.annulerRestauration()}>Annuler</button>
        <button class="bouton principal" @click=${() => void app.confirmerRestauration()}>Restaurer</button>
      </div>
    </div>
  `;
}

/** Feuille de pré-partage (D-092) : un petit reçu de ce qui part + le choix
 *  d'inclure ou non les vidéos locales (au poids parfois lourd). N'apparaît
 *  que s'il y a une telle vidéo à inclure. */
export function feuillePartage(app: MovensoApp) {
  const p = app.partagePreparation!;
  const mo = (o: number) => (o >= 1_000_000 ? `${(o / 1_000_000).toFixed(1)} Mo` : `${Math.max(1, Math.round(o / 1000))} Ko`);
  const basculer = () => {
    app.partagePreparation = { ...p, avecVideos: !p.avecVideos };
    app.requestUpdate();
  };
  return html`
    <div class="voile" @click=${() => (app.partagePreparation = null)}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Partager la technique">
      <div class="prise"></div>
      <h2>Partager « ${p.nom} »</h2>
      <div class="geste">
        1 technique${p.nbLiens ? ` · ${p.nbLiens} vidéo${p.nbLiens > 1 ? "s" : ""} en lien` : ""}
        · ${p.nbLocales} vidéo${p.nbLocales > 1 ? "s" : ""} locale${p.nbLocales > 1 ? "s" : ""}${p.avecVideos ? ` (~${mo(p.octetsLocaux)})` : ""}
      </div>
      <button class="interrupteur ${p.avecVideos ? "actif" : ""}" role="switch" aria-checked=${p.avecVideos} @click=${basculer}>
        <span class="interrupteur-texte">
          <span class="interrupteur-titre">Inclure les vidéos locales</span>
          <span class="interrupteur-aide">${p.avecVideos ? `Fichier plus lourd (~${mo(p.octetsLocaux)})` : "Fichier léger — les liens restent inclus"}</span>
        </span>
        <span class="interrupteur-piste" aria-hidden="true"><span class="interrupteur-bouton"></span></span>
      </button>
      <p class="fil-vide" style="padding:6px 0 0">Sans tes notes privées ni tes favoris.</p>
      <div class="actions">
        <button class="bouton" @click=${() => (app.partagePreparation = null)}>Annuler</button>
        <button class="bouton principal" @click=${() => void app.confirmerPartage()}>Partager</button>
      </div>
    </div>
  `;
}

/** Panneau de progression à l'écriture d'un média local (D-098) : bloquant
 *  (on n'interrompt pas une écriture en flux), phase « Analyse… » (empreinte,
 *  indéterminé) puis « Enregistrement… X % · ~Ns ». */
export function feuilleEnregistrement(app: MovensoApp) {
  const e = app.enregistrementMedia!;
  const poids = e.octets >= 1_000_000 ? `${(e.octets / 1_000_000).toFixed(1)} Mo` : `${Math.max(1, Math.round(e.octets / 1000))} Ko`;
  const pct = Math.round(e.fraction * 100);
  return html`
    <div class="voile"></div>
    <div class="feuille feuille-progression" role="dialog" aria-modal="true" tabindex="-1" aria-label="Enregistrement en cours" aria-live="polite">
      <div class="prise"></div>
      <h2>${e.phase === "analyse" ? "Analyse de la vidéo…" : "Enregistrement…"}</h2>
      <div class="geste">
        ${poids}${e.phase === "ecriture"
          ? html` · ${pct} %${e.etaSec !== null ? html` · ~${e.etaSec} s restant` : nothing}`
          : ""}
      </div>
      <div class="barre-progression">
        <div class="barre-progression-jauge ${e.phase === "analyse" ? "indeterminee" : ""}"
          style=${e.phase === "ecriture" ? `width:${pct}%` : ""}></div>
      </div>
      <div class="actions" style="padding-top:10px">
        <button class="bouton" @click=${() => app.annulerIngestionVideo()}>Annuler</button>
      </div>
    </div>
  `;
}

/** C2 (D-204) : feuille de CONFIRMATION nommée — remplace le confirm() natif
 *  sur les chemins destructifs (thémable, verbe explicite, testable). Voile et
 *  « Annuler » referment sans effet ; l'action ne part que par son bouton. */
export function feuilleConfirmation(app: MovensoApp) {
  const c = app.confirmation!;
  const fermer = () => { app.confirmation = null; app.requestUpdate(); };
  return html`
    <div class="voile" @click=${fermer}></div>
    <div class="feuille feuille-confirmation" role="dialog" aria-modal="true" tabindex="-1" aria-label=${c.titre}>
      <div class="prise"></div>
      <h2>${c.titre}</h2>
      ${c.corps ? html`<p class="confirmation-corps">${c.corps}</p>` : nothing}
      <div class="actions">
        <button class="bouton" @click=${fermer}>Annuler</button>
        <button class="bouton principal danger" @click=${() => { const action = c.action; fermer(); action(); }}>${c.bouton}</button>
      </div>
    </div>
  `;
}
