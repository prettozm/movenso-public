/**
 * ATELIER — PUBLIER, SAUVEGARDES, SÉCURITÉ, APPARENCE, À PROPOS, DIAGNOSTIC
 * (S3.A3, tranche 3 — écrans extraits d'atelier.ts, code déménagé tel quel) :
 * création/export de packs (sources en opt-in D-023), sauvegardes complètes/
 * légères + restauration + réinitialisation (zone danger), protections PIN,
 * apparence (thème, tonalité, densité, espace S1.9, démarrage), à propos et
 * aide, diagnostic.
 */

import { html, nothing, type TemplateResult } from "lit";
import { VERSION, COMMIT } from "./version.ts";
import { RELATIONS_VISUELLES } from "./fonctionnalites.ts";
import { carteSection, tailleLisible } from "./atelier-commun.ts";
import type { MovensoApp } from "./racine.ts";

/** Sous-écran « Créer ou exporter un pack » (Plus) : produire un .movpack
 *  distribuable à partir d'une sélection maîtrisée. */
export function ecranPublier(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  if (b.disciplines.length === 0)
    return html`<p class="fil-vide" style="padding-top:10px">Rien à publier pour l'instant — crée ou importe d'abord du contenu.</p>`;
  return html`
    <p class="fil-vide" style="padding:8px 2px 0">Un pack, c'est du contenu <b>à partager</b> — sans ton carnet ni tes favoris. Pour une archive complète <b>pour toi</b>, va dans « Sauvegardes ».</p>
    ${sectionPublier(app)}
  `;
}

/** Sous-écran « Sauvegardes » (Plus) : sauvegarde complète, légère, points de
 *  restauration locaux, et restauration sur installation vierge. */
/** Sous-écran « Stockage » (D-308, scission demandée en R5 puis actée) : ce
 *  que Movenso occupe et la persistance — distinct de « mettre à l'abri ». */
export function ecranStockage(app: MovensoApp): TemplateResult {
  return carteEspace(app);
}

export function ecranSauvegardes(app: MovensoApp): TemplateResult {
  return html`
    ${carteSection("Sauvegarder", html`
      <p class="fil-vide" style="padding:0 2px 6px">Une sauvegarde, c'est <b>tout, pour toi</b> (avec ton carnet et tes favoris) — pour restaurer ton installation. Pour partager à d'autres, utilise « Créer ou exporter un pack ».</p>
      <div class="actions-bibliotheque" style="padding-top:0">
        <button class="action-douce" @click=${() => void app.exporterTout(true)}>
          ⇓ Sauvegarde complète <span>fichier avec les vidéos — savoir, compositions, favoris et vidéos reviennent sur un appareil vierge ; réglages d'appareil et PIN à reconfigurer</span>
        </button>
        <button class="action-douce" @click=${() => void app.exporterTout(false)}>
          ⇓ Sauvegarde légère, sans les vidéos <span>ce n'est PAS une sauvegarde complète — les vidéos restent sur cet appareil</span>
        </button>
      </div>
      <p class="avertissement-sauvegarde" style="margin-top:8px; padding:10px 12px; border:1px solid var(--trait); border-radius:12px; background:var(--papier); line-height:1.5">
        ⚠️ <b style="color:var(--encre)">Une sauvegarde n'est pas chiffrée.</b> Le fichier
        contient ton <b>carnet personnel</b> et tes <b>vidéos</b>, lisibles tels quels par
        quiconque l'ouvre. Garde-le <b>pour toi</b> (ou un appareil de confiance) —
        ne l'envoie jamais à quelqu'un d'autre. Pour transmettre du contenu,
        passe par « Créer ou exporter un pack », qui <b>exclut ton carnet</b>.
      </p>
      ${app.dernierFichier
        ? html`<div class="suppression-discipline" style="border-color:var(--trait); background:var(--papier)">
            <p class="details fichier-produit" style="line-height:1.5">
              <b style="color:var(--encre)">${app.dernierFichier.role}</b><br>
              ${app.dernierFichier.nom} · ${app.dernierFichier.taille >= 1_000_000 ? `${(app.dernierFichier.taille / 1_000_000).toFixed(1)} Mo` : `${Math.max(1, Math.round(app.dernierFichier.taille / 1000))} Ko`}<br>
              ${app.dernierFichier.resume}<br>
              L'emplacement du fichier est indiqué dans la confirmation à l'enregistrement.
            </p>
          </div>`
        : nothing}
    `)}
    ${carteSection("Revenir à un état précédent", sectionSauvegardes(app))}
    ${carteSection("Restaurer une sauvegarde complète", html`
      <div class="actions-bibliotheque" style="padding-top:0">
        <button class="action-douce" @click=${() => app.choisirPackAImporter()}>
          ⤒ Restaurer depuis un fichier <span>importe une sauvegarde complète — sur une installation vierge</span>
        </button>
      </div>
    `)}
  `;
}

/** Sous-écran « Sécurité » (Plus) : protections facultatives (modifications,
 *  suppressions) par PIN local. */
export function ecranSecurite(app: MovensoApp): TemplateResult {
  return html`${sectionProtections(app)}`;
}

/** Sous-écran « Apparence » (Plus) : thème, tonalité, comportement de démarrage. */
export function ecranApparence(app: MovensoApp): TemplateResult {
  const theme = app.preferences.theme ?? "auto";
  const tonalite = app.preferences.tonalite ?? "vermillon";
  return html`
    <div class="carte-atelier">
      <div class="encart-entete"><span class="titre-atelier">Thème</span></div>
      <div class="chips-filtres" style="padding:2px 0 0">
        ${(["auto", "clair", "sombre"] as const).map(
          (t) => html`<button class="chip-filtre ${theme === t ? "actif" : ""}"
            @click=${() => app.changerApparence({ theme: t })}>${t === "auto" ? "Auto (système)" : t === "clair" ? "Jour" : "Nuit"}</button>`,
        )}
      </div>
    </div>

    <div class="carte-atelier">
      <div class="encart-entete"><span class="titre-atelier">Tonalité</span></div>
      <div class="chips-filtres" style="flex-wrap:wrap; padding:2px 0 0">
        ${TONALITES.map(
          (t) => html`<button class="chip-filtre ${tonalite === t.id ? "actif" : ""}"
            @click=${() => app.changerApparence({ tonalite: t.id })}>
            <span class="puce-niveau" style="background:${t.couleur}"></span>${t.nom}</button>`,
        )}
      </div>
    </div>

    ${carteDensite(app)}

    <div class="carte-atelier">
      <div class="encart-entete"><span class="titre-atelier">Au démarrage</span></div>
      ${sectionDemarrage(app)}
    </div>

    <div class="carte-atelier">
      <div class="encart-entete"><span class="titre-atelier">Ton pseudo</span></div>
      <div class="aide" style="font-size:12px; color:var(--sourdine)">Signe les techniques que tu crées ou modifies (« Modifié par… »).</div>
      <input class="champ-mini" placeholder="Ton nom ou ton pseudo"
             .value=${(app.preferences.pseudo ?? "").trim()} aria-label="Ton pseudo"
             @change=${(e: Event) => app.changerPseudo((e.target as HTMLInputElement).value)}>
    </div>
  `;
}

/** Sous-écran « Réglages avancés » (Plus, D-234) : ce qui change le PÉRIMÈTRE de
 *  l'app — outils de curation, fonctions en bêta. Sorti d'Apparence, où il
 *  n'avait rien à faire : l'apparence dit comment ça se présente, pas ce qui
 *  existe. Chaque bascule dit ce qu'elle allume et ce qu'elle n'efface pas. */
export function ecranAvance(app: MovensoApp): TemplateResult {
  return html`
    <div class="carte-atelier">
      <div class="encart-entete"><span class="titre-atelier">Outils</span></div>
      ${interrupteur(app, "Mode avancé", "Affiche les outils de curation dans « Plus » : doublons, médias, relations, diagnostic et maintenance.", "modeAvance")}
    </div>

    <div class="carte-atelier">
      <div class="encart-entete"><span class="titre-atelier">Réseau</span></div>
      <div class="aide" style="font-size:12px; color:var(--sourdine); padding:0 0 6px">
        Movenso fonctionne hors ligne. Une vidéo ne se charge qu'au moment où tu
        la lances — ça, ça ne change pas.
      </div>
      ${interrupteur(app, "Vignettes distantes",
        "Illustre les fiches sans image locale avec la miniature fournie par YouTube. Désactivé, aucune requête n'est faite sans ton geste.",
        "vignettesDistantes")}
    </div>

    <div class="carte-atelier">
      <div class="encart-entete"><span class="titre-atelier">Fonctions en bêta</span></div>
      <div class="aide" style="font-size:12px; color:var(--sourdine); padding:0 0 6px">
        Des fonctions complètes mais encore en ajustement. Les masquer ne supprime
        jamais rien : les données restent intactes et reviennent avec l'onglet.
      </div>
      ${interrupteur(app, "Relations", "Les liens entre techniques : sur les fiches, en graphe, et leur édition.", "vueRelationBeta")}
      ${interrupteur(app, "Compositions", "L'onglet Compositions : enchaînements, séances minutées, lecture pas à pas, rôles.", "compositionsBeta")}
    </div>
  `;
}

/** Interrupteur simple pour un réglage d'appareil booléen (D-084). */
function interrupteur(app: MovensoApp, titre: string, aide: string, cle: "modeAvance" | "vueRelationBeta" | "compositionsBeta" | "vignettesDistantes"): TemplateResult {
  const actif = app.preferences[cle] ?? false;
  return html`
    <button class="interrupteur ${actif ? "actif" : ""}" role="switch" aria-checked=${actif}
      @click=${() => app.basculerReglage(cle)}>
      <span class="interrupteur-texte">
        <span class="interrupteur-titre">${titre}</span>
        <span class="interrupteur-aide">${aide}</span>
      </span>
      <span class="interrupteur-piste" aria-hidden="true"><span class="interrupteur-bouton"></span></span>
    </button>`;
}

/** Densité de la grille Bibliothèque (D-090) : curseur avec « Auto » (défaut,
 *  réactif à la taille de l'écran) puis 1 à 6 colonnes forcées. 0 = Auto. */
function carteDensite(app: MovensoApp): TemplateResult {
  const val = app.preferences.densiteBibliotheque ?? 0;
  const libelle =
    val === 0
      ? "Auto — s'adapte à l'écran (2 sur téléphone, plus sur tablette)"
      : `${val} colonne${val > 1 ? "s" : ""}`;
  return html`
    <div class="carte-atelier">
      <div class="encart-entete"><span class="titre-atelier">Densité de la bibliothèque</span></div>
      <div class="aide" style="font-size:12px; color:var(--sourdine)">Nombre de colonnes de la grille des techniques.</div>
      <div class="densite-reglage">
        <input type="range" min="0" max="6" step="1" .value=${String(val)}
          aria-label="Nombre de colonnes de la bibliothèque"
          @input=${(e: Event) => {
            const n = Number((e.target as HTMLInputElement).value);
            app.changerDensite(n === 0 ? null : n);
          }}>
        <span class="densite-valeur">${libelle}</span>
      </div>
    </div>`;
}

/** Limite d'espace volontaire (D-097) : curseur à paliers, de 200 Mo (liens en
 *  ligne uniquement) à Illimité (défaut 5 Go), avec rappel de l'usage et du max
 *  appareil + avertissement en illimité. Se combine au garde-fou (D-096). */
function carteEspace(app: MovensoApp): TemplateResult {
  const PALIERS = [200, 500, 1000, 2000, 5000, 10000, 20000, 0]; // Mo ; 0 = illimité
  const moActuel = app.preferences.limiteEspaceMo ?? 5000;
  const idx = PALIERS.indexOf(moActuel);
  const idxSafe = idx >= 0 ? idx : 4; // défaut 5 Go
  const lib = (mo: number) => (mo === 0 ? "Illimité" : mo >= 1000 ? `${mo / 1000} Go` : `${mo} Mo`);
  const info = app.infoEspace;
  return html`
    <div class="carte-atelier">
      <div class="encart-entete"><span class="titre-atelier">Espace de stockage</span></div>
      <div class="aide" style="font-size:12px; color:var(--sourdine)">Limite que Movenso peut utiliser pour les vidéos locales — les liens en ligne ne comptent pas.</div>
      <div class="densite-reglage">
        <input type="range" min="0" max="7" step="1" .value=${String(idxSafe)}
          aria-label="Limite d'espace pour les vidéos"
          @input=${(e: Event) => void app.changerLimiteEspace(PALIERS[Number((e.target as HTMLInputElement).value)] ?? 5000)}>
        <span class="densite-valeur">${lib(moActuel)}</span>
      </div>
      <div class="aide" style="font-size:11.5px; color:var(--sourdine)">
        Minimum 200 Mo → Illimité.
        ${info ? html`<br>Utilisé : ${tailleLisible(info.usage)} · max appareil ~${tailleLisible(info.quota)}` : nothing}
      </div>
      ${moActuel === 0
        ? html`<div class="aide" style="font-size:11.5px; color:var(--attention, #b26b00)">⚠ Sans limite, Movenso peut remplir le stockage de l'appareil.</div>`
        : nothing}
      ${lignePersistance(app)}
    </div>`;
}

/** État de persistance du stockage (S1.9) : dit honnêtement si le navigateur
 *  garantit de ne pas purger OPFS — et permet de redemander quand ce n'est
 *  pas (encore) accordé. Sur Android natif, le bac à sable de l'app suffit. */
function lignePersistance(app: MovensoApp): TemplateResult {
  const etat = app.persistanceStockage;
  const contenu =
    etat === "accordee"
      ? html`✓ Persistance accordée — le navigateur ne purgera pas ces données.`
      : etat === "native"
        ? html`Stockage applicatif natif — géré par le système, pas de purge navigateur.`
        : etat === "refusee"
          ? html`⚠ Persistance non garantie : le navigateur pourrait purger ces données s'il manque de place.
              <button class="lien-texte" @click=${() => void app.redemanderPersistance()}>Demander la persistance</button>`
          : html`Persistance : ce navigateur ne sait pas répondre — pense aux sauvegardes régulières.`;
  return html`<div class="aide persistance-stockage" style="font-size:11.5px; color:${etat === "refusee" ? "var(--attention, #b26b00)" : "var(--sourdine)"}">${contenu}</div>`;
}

/** Sous-écran « Diagnostic et maintenance » (Plus) : diagnostic technique, et
 *  zone danger nettement séparée (réinitialisation). */
/** « À propos » (finition bêta) : identité, version, nature de la build, et une
 *  aide rapide découvrable (jamais imposée — D-017). Regroupe les explications
 *  clés : importer, sauvegarder/restaurer, et la distinction partage ≠ sauvegarde. */
/** Sous-écran « Aide » (D-308, scindé d'« À propos ») : la prise en main et
 *  les gestes qui sauvent — l'identité de l'app reste dans À propos. Le
 *  contenu s'étoffera sur le prototype fourni par le porteur. */
export function ecranAide(app: MovensoApp): TemplateResult {
  return html`
    ${carteSection("Prise en main rapide", html`
      <ul class="apropos-liste">
        <li><strong>Ajouter du contenu</strong> : ouvre une discipline puis « ＋ Ajouter »
          pour créer une technique ou capturer une vidéo/note.</li>
        <li><strong>Installer un pack</strong> : Plus › <em>Importer un pack</em>, puis choisis
          un fichier <code>.movpack</code>. Les techniques rejoignent ta bibliothèque
          sans écraser tes notes.</li>
        ${app.preferences.compositionsBeta
          ? html`<li><strong>Composer une séance</strong> : onglet Compositions › Créer ; en lecture,
              ▶ lance le pas-à-pas avec le chrono (voix et bips optionnels).</li>`
          : nothing}
        ${RELATIONS_VISUELLES && (app.preferences.vueRelationBeta ?? false)
          ? html`<li><strong>Naviguer par les liens</strong> :
              <button class="chip-filtre" style="vertical-align:1px" @click=${() => app.ouvrirBienvenueRelations()}>🔗 Découvrir Relations</button>
              — les règles du jeu et le rôle de chaque vue.</li>`
          : nothing}
      </ul>
    `)}
    ${carteSection("Sauvegarde et restauration", html`
      <div class="aide" style="font-size:13px">
        <p>Une <strong>sauvegarde complète</strong> (Plus › Sauvegardes)
          emporte ta bibliothèque, ton carnet perso, tes favoris et tes vidéos
          dans un seul fichier <code>.movpack</code>, restaurable sur une installation
          vierge. Les réglages propres à l'appareil (thème,
          démarrage) et le PIN ne voyagent jamais — à reconfigurer après.</p>
        <p><strong>Partage ≠ sauvegarde.</strong> Un pack que tu <em>partages</em> (une
          discipline, une composition) exclut par principe ton carnet personnel et tes
          captures. Une <em>sauvegarde complète</em>, elle, contient ton contenu privé
          <strong>en clair</strong> : ne la partage qu'avec toi-même ou un appareil de
          confiance.</p>
      </div>
    `)}
  `;
}

export function ecranApropos(app: MovensoApp): TemplateResult {
  return html`
    ${carteSection("Movenso", html`
      <div class="apropos-version">
        <div><strong>Version</strong> ${VERSION}+${COMMIT}</div>
        <div class="aide" style="font-size:12px; color:var(--sourdine)">
          Bibliothèque personnelle de vos disciplines du mouvement — sans compte ni
          cloud. Les données et vidéos restent sur cet appareil ; une connexion peut
          être nécessaire pour charger ou mettre à jour l'application web et
          consulter les ressources externes.
        </div>
        ${VERSION.includes("dev") || VERSION.includes("rc") || VERSION.includes("beta")
          ? html`<div class="aide" style="font-size:12px; color:var(--state-warning, #9a6a00)">
              Version d'évaluation : build de test possiblement non signée —
              pense à exporter une sauvegarde avant chaque mise à jour.
            </div>`
          : nothing}
      </div>
    `)}
    ${carteSection("Limites connues", html`
      <ul class="apropos-liste">
        <li><strong>Export volumineux</strong> : un fichier d'export (sauvegarde ou pack)
          qui dépasserait ~4 Go n'est pas garanti — préfère la sauvegarde légère
          ou plusieurs packs si ta vidéothèque est très lourde.</li>
        <li><strong>Hors ligne</strong> : tes données restent sur l'appareil, mais
          l'application web peut demander une connexion pour se charger ; les
          vignettes en ligne laissent place à l'initiale de la technique.</li>
        <li><strong>Lecteur d'écran</strong> : le socle est en place ; si un parcours
          TalkBack coince, dis-le — les remontées font foi.</li>
      </ul>
    `)}
    ${carteSection("Licences", html`
      <ul class="apropos-liste apropos-licences">
        <li><strong>Application</strong> : logiciel libre, licence
          <strong>GNU GPL v3</strong> — le code est public et le restera
          (fichier <code>LICENSE</code> du dépôt).</li>
        <li><strong>Packs officiels</strong> (noms, classifications, niveaux, notes,
          liens) : <strong>CC BY-NC-SA 4.0</strong> — réutilisables avec attribution
          « Movenso », SANS usage commercial, à repartager sous la même licence.</li>
        <li><strong>Vidéos liées</strong> : elles restent la propriété de leurs
          auteurs et de leurs chaînes — l'application n'en fait que des
          <em>liens</em> (lecture chez l'hébergeur), jamais de copie.</li>
      </ul>
    `)}
  `;
}

export function ecranDiagnostic(app: MovensoApp): TemplateResult {
  return html`
    ${carteSection("Diagnostic", html`
      <div class="aide" style="font-size:12px; color:var(--sourdine)">Un fichier texte (compteurs, santé des médias, stockage, versions, dernier échec avec son code, opération en cours) pour comprendre un souci d'import, d'export ou de place — sans aucun secret.</div>
      <button class="chip-filtre diagnostic-export" @click=${() => void app.exporterDiagnostic()}>Exporter le diagnostic</button>
    `)}
    ${sectionReinitialisation(app)}
  `;
}

/** État du formulaire d'export (session, tuning post-V3, D-078) : une
 *  discipline ; tout ou un choix de techniques ; avec/sans vidéos ; auteur ;
 *  note de diffusion. Plus de choix de source (on emporte toute la discipline). */
const publierEtat: {
  disciplineId: string | null;
  tout: boolean;
  techniques: Set<string>;
  avecVideos: boolean;
  auteur: string;
  note: string;
  compositionsPerso: boolean;
} = { disciplineId: null, tout: true, techniques: new Set(), avecVideos: true, auteur: "", note: "", compositionsPerso: false };

function sectionPublier(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;

  // Étape 2 — un pack est prêt : taille réelle + choix Enregistrer local / Partager.
  const prete = app.publicationPrete;
  if (prete)
    return html`
      <div class="carte-atelier">
        <div class="titre-atelier">Pack prêt</div>
        <p class="details" style="line-height:1.5"><b style="color:var(--encre)">${prete.nomPack}</b> · ${tailleLisible(prete.taille)}<br>${prete.resume}</p>
        <div class="edition-actions">
          <button class="bouton principal" @click=${() => app.enregistrerPublicationLocale()}>⇓ Enregistrer localement</button>
          <button class="bouton" @click=${() => void app.partagerPublication()}>↗ Partager</button>
        </div>
        <button class="action-douce" style="margin-top:6px" @click=${() => app.fermerPublication()}>← Préparer un autre pack</button>
      </div>
    `;

  const selId = publierEtat.disciplineId && b.disciplines.some((d) => d.id === publierEtat.disciplineId) ? publierEtat.disciplineId : b.disciplines[0]!.id;
  publierEtat.disciplineId = selId;
  const sel = b.disciplines.find((d) => d.id === selId)!;
  const techniques = b.techniques.filter((t) => t.disciplineId === selId);
  const nbChoisies = publierEtat.tout ? techniques.length : techniques.filter((t) => publierEtat.techniques.has(t.id)).length;
  const majDisc = (id: string) => { publierEtat.disciplineId = id; publierEtat.techniques = new Set(); publierEtat.tout = true; app.requestUpdate(); };
  // Estimation du poids des VIDÉOS LOCALES embarquées (les liens ne pèsent rien).
  // Comme à l'extraction, le personnel est exclu : seules les vidéos des
  // contributions partageables comptent.
  const idsSel = new Set(publierEtat.tout ? techniques.map((t) => t.id) : techniques.filter((t) => publierEtat.techniques.has(t.id)).map((t) => t.id));
  const idsVideosLocales = new Set<string>();
  for (const c of b.contributions)
    if (c.techniqueId && idsSel.has(c.techniqueId) && c.provenance !== "personnel")
      for (const m of c.medias) if (m.type === "local") idsVideosLocales.add(m.id);
  const octetsVideos = [...idsVideosLocales].reduce((s, id) => s + (app.taillesVideos.get(id) ?? 0), 0);
  // Séances PERSONNELLES jouables dans ce périmètre (opt-in D-127) : celles dont
  // tous les pas techniques pointent des techniques du choix courant.
  const compoPersoJouables = b.compositions.filter(
    (c) =>
      c.provenance === "personnel" &&
      c.blocs.some((x) => x.type === "technique" && x.techniqueId) &&
      c.blocs.every((x) => x.type !== "technique" || !x.techniqueId || idsSel.has(x.techniqueId)),
  );

  return html`
    <p class="fil-vide" style="padding-top:0">
      Produire un fichier <b>à partager</b> — pas une sauvegarde. Ton carnet, tes
      favoris et tes captures à reprendre ne partent jamais.
    </p>
    <div class="carte-atelier">
      <div class="etiquette-champ">Discipline</div>
      <div class="chips-filtres">
        ${b.disciplines.map((d) => html`<button class="chip-filtre ${d.id === selId ? "actif" : ""}" @click=${() => majDisc(d.id)}>${d.nom}</button>`)}
      </div>

      <div class="etiquette-champ">Contenu</div>
      <div class="chips-filtres">
        <button class="chip-filtre ${publierEtat.tout ? "actif" : ""}" @click=${() => { publierEtat.tout = true; app.requestUpdate(); }}>Tout (${techniques.length})</button>
        <button class="chip-filtre ${!publierEtat.tout ? "actif" : ""}" @click=${() => { publierEtat.tout = false; app.requestUpdate(); }}>Choix de techniques</button>
      </div>
      ${!publierEtat.tout
        ? html`<div class="publier-techniques">
            ${techniques.map(
              (t) => html`<label class="niveau-coche">
                <input type="checkbox" ?checked=${publierEtat.techniques.has(t.id)}
                  @change=${() => { publierEtat.techniques.has(t.id) ? publierEtat.techniques.delete(t.id) : publierEtat.techniques.add(t.id); app.requestUpdate(); }}>
                <span>${t.nom}</span>
              </label>`,
            )}
            ${techniques.length === 0 ? html`<p class="fil-vide">Aucune technique dans cette discipline.</p>` : nothing}
          </div>`
        : nothing}

      <div class="etiquette-champ">Vidéos</div>
      <div class="chips-filtres">
        <button class="chip-filtre ${publierEtat.avecVideos ? "actif" : ""}" @click=${() => { publierEtat.avecVideos = true; app.requestUpdate(); }}>Avec les vidéos locales</button>
        <button class="chip-filtre ${!publierEtat.avecVideos ? "actif" : ""}" @click=${() => { publierEtat.avecVideos = false; app.requestUpdate(); }}>Sans les vidéos</button>
      </div>
      <p class="fil-vide" style="padding:4px 0 0">Les liens (YouTube…) restent inclus dans les deux cas.</p>

      ${compoPersoJouables.length
        ? html`<div class="etiquette-champ">Mes séances</div>
            <label class="niveau-coche">
              <input type="checkbox" ?checked=${publierEtat.compositionsPerso}
                @change=${() => { publierEtat.compositionsPerso = !publierEtat.compositionsPerso; app.requestUpdate(); }}>
              <span>Inclure ${compoPersoJouables.length} séance${compoPersoJouables.length > 1 ? "s" : ""} personnelle${compoPersoJouables.length > 1 ? "s" : ""} (jouable${compoPersoJouables.length > 1 ? "s" : ""} avec ce pack)</span>
            </label>
            <p class="fil-vide" style="padding:2px 0 0">Par défaut, tes séances perso restent privées.</p>`
        : nothing}

      <div class="etiquette-champ">Auteur du pack</div>
      <input class="champ-mini" placeholder="Auteur ou organisation (recommandé)" .value=${publierEtat.auteur}
             aria-label="Auteur du pack" @input=${(e: Event) => (publierEtat.auteur = (e.target as HTMLInputElement).value)}>

      <div class="etiquette-champ">Note de diffusion</div>
      <input class="champ-mini" placeholder="Note de diffusion (facultatif)" .value=${publierEtat.note}
             aria-label="Note de diffusion" @input=${(e: Event) => (publierEtat.note = (e.target as HTMLInputElement).value)}>

      <div class="details" style="padding-top:4px">${nbChoisies} technique${nbChoisies > 1 ? "s" : ""}${publierEtat.avecVideos ? (octetsVideos ? ` · ~${tailleLisible(octetsVideos)} de vidéos` : " · aucune vidéo locale") : " · sans les vidéos"}</div>
      <button class="bouton principal" style="margin-top:8px; align-self:flex-start" ?disabled=${nbChoisies === 0}
        @click=${() => void app.preparerPublication(selId, {
          ...(publierEtat.tout ? {} : { techniques: publierEtat.techniques }),
          avecVideos: publierEtat.avecVideos,
          auteur: publierEtat.auteur,
          note: publierEtat.note,
          nom: sel.nom,
          compositionsPersonnelles: publierEtat.compositionsPerso,
        })}>Valider</button>
    </div>
  `;
}

function sectionSauvegardes(app: MovensoApp): TemplateResult {
  if (app.sauvegardes.length === 0)
    return html`<p class="fil-vide" style="padding-top:2px">
      Aucun point de restauration pour l'instant — ils se créent seuls avant chaque
      action sensible (import, suppression, restauration).
    </p>`;
  return html`
    <div class="chips-filtres" style="flex-wrap:wrap">
      ${app.sauvegardes.map((nom) => {
        const [horodatage, motif] = nom.replace(".json", "").split("__");
        const lisible = `${(horodatage ?? "").replace("T", " ").slice(0, 16)}${motif ? ` · ${motif.replaceAll("-", " ")}` : ""}`;
        return html`<button class="chip-filtre"
          @click=${() =>
            app.autoriser("destruction_ou_sensible", "Saisis le PIN pour revenir à un état précédent.", () => {
              app.demanderConfirmation({
                titre: `Revenir à l'état « ${lisible} » ?`,
                corps: "— La bibliothèque actuelle (techniques, contributions, compositions, favoris) sera REMPLACÉE par cet état ; tout ce qui a été créé depuis sera retiré.\n— Les fichiers vidéo de l'appareil ne bougent PAS (les points de restauration n'incluent pas les vidéos).\n— L'état actuel est lui-même sauvegardé d'abord : ce retour est annulable.",
                bouton: "Revenir à cet état",
                action: () => { void app.restaurerSauvegarde(nom); },
              });
            })}>↺ ${lisible}</button>`;
      })}
    </div>
    <p class="fil-vide" style="padding-top:6px">
      Points de restauration automatiques (10 conservés), données seules — pour la vraie
      sauvegarde avec vidéos, utilise « Sauvegarde complète ».
    </p>
  `;
}

const TONALITES: { id: NonNullable<import("../stockage/opfs.ts").Preferences["tonalite"]>; nom: string; couleur: string }[] = [
  { id: "vermillon", nom: "Vermillon", couleur: "#B23A26" },
  { id: "indigo", nom: "Indigo", couleur: "#35506F" },
  { id: "foret", nom: "Forêt", couleur: "#2F6B4F" },
  { id: "ocre", nom: "Ocre", couleur: "#96682B" },
  { id: "prune", nom: "Prune", couleur: "#7A3E68" },
  { id: "acier", nom: "Acier", couleur: "#47586B" },
];

let reinitialisationOuverte = false;

function sectionReinitialisation(app: MovensoApp): TemplateResult {
  const fermer = () => {
    reinitialisationOuverte = false;
    app.requestUpdate();
  };
  return html`
    ${carteSection("Réinitialisation", html`
    ${reinitialisationOuverte
      ? html`<div class="suppression-discipline">
          <p class="details" style="line-height:1.5">
            Tout sera supprimé de cet appareil : la bibliothèque (techniques,
            contenus, compositions, favoris), les vidéos locales, les
            points de restauration ET les réglages — protections et PIN compris. Movenso
            reviendra à une Bibliothèque vide. Pense à faire une sauvegarde
            complète d'abord.
          </p>
          <div class="chips-filtres" style="flex-wrap:wrap; padding:4px 0 0">
            <button class="chip-filtre" @click=${fermer}>Annuler</button>
            <button class="chip-filtre" @click=${() => void app.exporterTout(true)}>Sauvegarder d'abord (.movpack)</button>
            <button class="action-danger" style="padding:6px 10px; font-size:12px"
              @click=${() => {
                app.demanderConfirmation({
                  titre: "Tout supprimer définitivement de cet appareil ?",
                  corps: "Cette action ne se défait pas.",
                  bouton: "Tout supprimer définitivement",
                  action: () => { fermer(); void app.reinitialiserTout(); },
                });
              }}>Tout supprimer définitivement</button>
          </div>
        </div>`
      : html`<div class="ligne-atelier">
          <button class="action-danger reinitialiser"
            @click=${() =>
              app.autoriser("destruction_ou_sensible", "Saisis le PIN pour réinitialiser Movenso.", () => {
                reinitialisationOuverte = true;
                app.requestUpdate();
              })}>Réinitialiser Movenso…</button>
        </div>`}
    `)}
  `;
}

const etatProtections: {
  /** Formulaire de création de PIN ouvert, et pour quelle intention. */
  formulaire: "modifications" | "suppressions" | null;
  /** Désactivation en attente du PIN, pour quelle protection. */
  desactivation: "modifications" | "suppressions" | null;
  changementPin: boolean;
  erreur: string;
  reveler: boolean;
} = { formulaire: null, desactivation: null, changementPin: false, erreur: "", reveler: false };

const EXPLICATIONS: Record<"modifications" | "suppressions", string> = {
  modifications:
    "Un PIN sera demandé pour créer, modifier, capturer, importer ou composer — la consultation reste toujours libre.",
  suppressions:
    "Un PIN sera demandé pour supprimer, restaurer, revenir en arrière, publier ou sauvegarder — la consultation reste toujours libre.",
};

function sectionProtections(app: MovensoApp): TemplateResult {
  const p = app.reglagesProtections;
  const aPin = !!app.preferences.protections?.verification;
  const verrouillage = app.preferences.protections?.verrouillage ?? "5min";
  const fermer = () => {
    etatProtections.formulaire = null;
    etatProtections.desactivation = null;
    etatProtections.changementPin = false;
    etatProtections.erreur = "";
    etatProtections.reveler = false;
    app.requestUpdate();
  };
  const ligneProtection = (quoi: "modifications" | "suppressions", nom: string) => html`
    <div class="ligne-atelier">
      <span class="details" style="flex:1">${p[quoi] ? "🔒" : "—"} ${nom} : <b>${p[quoi] ? "protégée par le PIN" : "libre"}</b></span>
      ${p[quoi]
        ? html`<button class="chip-filtre" @click=${() => { etatProtections.desactivation = quoi; etatProtections.formulaire = null; etatProtections.erreur = ""; app.requestUpdate(); }}>Désactiver…</button>`
        : html`<button class="chip-filtre" @click=${() => {
            if (aPin) void app.activerProtection(quoi); // un PIN existe : pas de nouveau PIN (§3)
            else { etatProtections.formulaire = quoi; etatProtections.desactivation = null; etatProtections.erreur = ""; app.requestUpdate(); }
          }}>Protéger…</button>`}
    </div>
    ${etatProtections.desactivation === quoi ? formulaireDesactivation(app, quoi, fermer) : nothing}
    ${etatProtections.formulaire === quoi ? formulaireCreationPin(app, quoi, fermer) : nothing}
  `;
  return html`
    ${carteSection("Protections", html`
    ${!p.modifications && !p.suppressions
      ? html`<p class="fil-vide etat-protections" style="padding-top:2px">
          Aucune protection active : tout est libre sur cet appareil. Tu peux
          demander un PIN local avant certaines actions (aucun compte, aucun serveur).
        </p>`
      : nothing}
    ${ligneProtection("modifications", "Modifications")}
    ${ligneProtection("suppressions", "Suppressions et opérations sensibles")}
    ${p.modifications || p.suppressions
      ? html`<div class="reglage-session">
            <span class="details" style="display:block;padding-bottom:4px">Garder la session déverrouillée :</span>
            <div class="chips-filtres">
              ${([["5min", "5 min"], ["15min", "15 min"], ["arriere-plan", "jusqu'à l'arrière-plan"]] as const).map(
                ([mode, nom]) => html`<button class="chip-filtre ${verrouillage === mode ? "actif" : ""}"
                  @click=${() => void app.choisirVerrouillage(mode)}>${nom}</button>`,
              )}
            </div>
          </div>
          <div class="ligne-atelier">
            <button class="chip-filtre" @click=${() => { etatProtections.changementPin = !etatProtections.changementPin; etatProtections.erreur = ""; app.requestUpdate(); }}>Changer le PIN…</button>
          </div>
          ${etatProtections.changementPin ? formulaireChangementPin(app, fermer) : nothing}
          ${app.journalSecurite.length || app.echecsCumules
            ? html`<p class="details journal-securite" style="padding-top:2px">
                Journal (session) : ${app.journalSecurite.slice(-3).join(" · ")}${app.echecsCumules ? ` · échecs cumulés : ${app.echecsCumules}` : ""}
              </p>`
            : nothing}
          <p class="fil-vide" style="padding-top:4px">
            PIN oublié ? Aucune récupération à distance : restaure une sauvegarde,
            ou réinitialise ci-dessous. Le PIN protège les actions dans l'app,
            pas le téléphone.
          </p>`
      : nothing}
    `)}
  `;
}

/** Première activation (§3) : explication → PIN → confirmation. Une
 *  confirmation différente n'active RIEN et laisse l'écran en place. */
function formulaireCreationPin(app: MovensoApp, intention: "modifications" | "suppressions", fermer: () => void): TemplateResult {
  const type = etatProtections.reveler ? "text" : "password";
  return html`<div class="suppression-discipline formulaire-pin" style="border-color:var(--trait); background:var(--papier)">
    <p class="details" style="line-height:1.5">${EXPLICATIONS[intention]}</p>
    <div class="ligne-atelier" style="flex-wrap:wrap">
      <input class="champ-mini" type=${type} inputmode="numeric" autocomplete="off"
             placeholder="PIN (6 à 12 chiffres)" aria-label="Nouveau PIN">
      <input class="champ-mini" type=${type} inputmode="numeric" autocomplete="off"
             placeholder="Confirme le PIN" aria-label="Confirmation du PIN">
      <button class="chip-filtre" @click=${() => { etatProtections.reveler = !etatProtections.reveler; app.requestUpdate(); }}>
        ${etatProtections.reveler ? "Masquer" : "Révéler"}</button>
    </div>
    ${etatProtections.erreur ? html`<p class="details erreur-pin" role="alert" style="color:var(--accent)">${etatProtections.erreur}</p>` : nothing}
    <div class="chips-filtres" style="padding:4px 0 0">
      <button class="chip-filtre" @click=${fermer}>Annuler</button>
      <button class="bouton principal" style="padding:7px 12px; font-size:12.5px"
        @click=${async (e: Event) => {
          const champs = (e.target as HTMLElement).closest(".formulaire-pin")!.querySelectorAll("input");
          const creation = { pin: champs[0]!.value, confirmation: champs[1]!.value };
          const erreur = await app.activerProtection(intention, creation);
          if (erreur) {
            etatProtections.erreur = erreur; // rien n'est activé, l'écran reste (§3)
            app.requestUpdate();
          } else fermer();
        }}>Activer</button>
    </div>
  </div>`;
}

/** Désactivation (§12) : exige le PIN actuel. */
function formulaireDesactivation(app: MovensoApp, quoi: "modifications" | "suppressions", fermer: () => void): TemplateResult {
  return html`<div class="suppression-discipline formulaire-pin">
    <div class="ligne-atelier" style="flex-wrap:wrap">
      <input class="champ-mini" type="password" inputmode="numeric" autocomplete="off"
             placeholder="PIN actuel" aria-label="PIN actuel">
      <button class="chip-filtre" @click=${fermer}>Annuler</button>
      <button class="action-danger" style="padding:6px 10px; font-size:12px"
        @click=${async (e: Event) => {
          const champ = (e.target as HTMLElement).closest(".formulaire-pin")!.querySelector("input")!;
          const erreur = await app.desactiverProtection(quoi, champ.value);
          if (erreur) {
            etatProtections.erreur = erreur;
            champ.value = "";
            app.requestUpdate();
          } else fermer();
        }}>Désactiver cette protection</button>
    </div>
    ${etatProtections.erreur ? html`<p class="details erreur-pin" role="alert" style="color:var(--accent)">${etatProtections.erreur}</p>` : nothing}
  </div>`;
}

/** Changement du PIN (§11) : l'ancien d'abord ; en cas d'échec ensuite,
 *  l'ancien PIN reste valable. */
function formulaireChangementPin(app: MovensoApp, fermer: () => void): TemplateResult {
  return html`<div class="suppression-discipline formulaire-pin" style="border-color:var(--trait); background:var(--papier)">
    <div class="ligne-atelier" style="flex-wrap:wrap">
      <input class="champ-mini" type="password" inputmode="numeric" autocomplete="off" placeholder="PIN actuel" aria-label="PIN actuel">
      <input class="champ-mini" type="password" inputmode="numeric" autocomplete="off" placeholder="Nouveau PIN" aria-label="Nouveau PIN">
      <input class="champ-mini" type="password" inputmode="numeric" autocomplete="off" placeholder="Confirme le nouveau" aria-label="Confirmation du nouveau PIN">
    </div>
    ${etatProtections.erreur ? html`<p class="details erreur-pin" role="alert" style="color:var(--accent)">${etatProtections.erreur}</p>` : nothing}
    <div class="chips-filtres" style="padding:4px 0 0">
      <button class="chip-filtre" @click=${fermer}>Annuler</button>
      <button class="bouton principal" style="padding:7px 12px; font-size:12.5px"
        @click=${async (e: Event) => {
          const champs = (e.target as HTMLElement).closest(".formulaire-pin")!.querySelectorAll("input");
          const erreur = await app.changerPin(champs[0]!.value, champs[1]!.value, champs[2]!.value);
          if (erreur) {
            etatProtections.erreur = erreur;
            app.requestUpdate();
          } else fermer();
        }}>Changer le PIN</button>
    </div>
  </div>`;
}

function sectionDemarrage(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const p = app.preferences.demarrage;
  // La Bibliothèque regroupe trois façons de l'ouvrir (Toutes / dernière /
  // une discipline) ; les disciplines ne sont donc proposées QUE sous elle.
  const destBiblio = p.mode === "bibliotheque" || p.mode === "derniere" || p.mode === "discipline";
  const relationsDispo = RELATIONS_VISUELLES && (app.preferences.vueRelationBeta ?? false);
  const compositionsDispo = app.preferences.compositionsBeta ?? false;
  return html`
    <div class="aide" style="font-size:12px; color:var(--sourdine)">L'écran ouvert au lancement de l'app.</div>
    <div class="chips-filtres" style="flex-wrap:wrap; padding:2px 0 0">
      <button class="chip-filtre ${destBiblio ? "actif" : ""}"
        @click=${() => app.changerDemarrage("bibliotheque")}>Bibliothèque</button>
      <button class="chip-filtre ${p.mode === "favoris" ? "actif" : ""}"
        @click=${() => app.changerDemarrage("favoris")}>Favoris</button>
      ${compositionsDispo
        ? html`<button class="chip-filtre ${p.mode === "compositions" ? "actif" : ""}"
            @click=${() => app.changerDemarrage("compositions")}>Compositions</button>`
        : nothing}
      ${relationsDispo
        ? html`<button class="chip-filtre ${p.mode === "relations" ? "actif" : ""}"
            @click=${() => app.changerDemarrage("relations")}>Relations</button>`
        : nothing}
    </div>
    ${destBiblio
      ? html`<div class="aide" style="font-size:12px; color:var(--sourdine); padding-top:6px">Ouvrir la Bibliothèque sur :</div>
          <div class="chips-filtres" style="flex-wrap:wrap; padding:2px 0 0">
            <button class="chip-filtre ${p.mode === "bibliotheque" ? "actif" : ""}"
              @click=${() => app.changerDemarrage("bibliotheque")}>Toutes</button>
            <button class="chip-filtre ${p.mode === "derniere" ? "actif" : ""}"
              @click=${() => app.changerDemarrage("derniere")}>Dernière consultée</button>
            ${b.disciplines.map(
              (d) => html`<button class="chip-filtre ${p.mode === "discipline" && p.disciplineId === d.id ? "actif" : ""}"
                @click=${() => app.changerDemarrage("discipline", d.id)}>${d.nom}</button>`,
            )}
          </div>`
      : nothing}
  `;
}
