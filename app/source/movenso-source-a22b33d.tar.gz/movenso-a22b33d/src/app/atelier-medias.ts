/**
 * ATELIER — MÉDIAS, À TRAITER, CORBEILLE, DOUBLONS, RELATIONS (S3.A3,
 * tranche 1 — écrans extraits d'atelier.ts, code déménagé tel quel) : la
 * médiathèque (KPI dépliables, renommage, aperçus), les captures à
 * rattacher, les vidéos manquantes et fichiers inutilisés (rattachement
 * D-168, suppression individuelle D-107 / groupée vérifiée D-171), la
 * corbeille, les doublons (fusion/défusion D-068) et l'arbitrage des
 * conflits de liaisons (D-157).
 */

/** Fichiers orphelins dont l'aperçu est ouvert — la suppression exige la
 *  prévisualisation (§13). */
import { html, nothing, type TemplateResult } from "lit";
import type { ConflitLiaison, Media, Technique } from "../domaine/modele.ts";
import { chercherTechniques } from "../domaine/recherche.ts";
import { clePaire, differencesDoublon, fusionnerDoublons, type CoteDoublon, type PaireDoublon } from "../domaine/doublons.ts";
import { urlSure, domaineDe } from "../securite/liens.ts";
import { vignetteTechnique } from "./vues.ts";
import { tailleLisible } from "./atelier-commun.ts";
import { sectionTypesRelation } from "./atelier-taxonomies.ts";
import { arbitrerConflitContribution } from "./services/edition-graphe.ts";
import type { MovensoApp } from "./racine.ts";

const orphelinesVerifiees = new Set<string>();

/** Sous-écran « Médias » (D-079/082, recentré D-107) — le PARC de fichiers :
 *  Vidéos locales et Médias en ligne, chaque KPI dépliant sa liste. Les
 *  diagnostics (à compléter, intégrité) ont migré vers « À traiter » (D-107). */
export function ecranMedias(app: MovensoApp): TemplateResult {
  const medias = [...collecterMedias(app).values()];
  const locaux = medias.filter((e) => e.media.type === "local");
  const enLigne = medias.filter((e) => e.media.type !== "local");
  return html`
    <div class="carte-atelier" style="gap:0">
      <div class="encart-entete" style="padding-bottom:4px"><span class="titre-atelier">Médiathèque</span></div>
      ${kpiListe(app, locaux.length, "Vidéos locales", "local")}
      ${mediathequeListe === "local" ? listeMedias(app, locaux) : nothing}
      ${kpiListe(app, enLigne.length, "Médias en ligne", "enligne")}
      ${mediathequeListe === "enligne" ? listeMedias(app, enLigne) : nothing}
      ${medias.length === 0 ? html`<p class="fil-vide" style="padding:6px 0 0">Aucun média pour l'instant.</p>` : nothing}
    </div>
  `;
}

/** Sous-écran « À traiter » (D-107) — le tableau de santé UNIQUE de la
 *  bibliothèque : tout ce qui demande une action, cliquable, au même endroit.
 *  Remplace les filtres « À compléter/Problèmes » de Gestion et les diagnostics
 *  de Médias (fin du doublon). */
export function ecranATraiter(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const aRattacher = b.contributions.filter((c) => c.techniqueId === null);
  const avecMedia = new Set<string>();
  for (const c of b.contributions) if (c.techniqueId && c.medias.length) avecMedia.add(c.techniqueId);
  const sansVideo = b.techniques.filter((t) => !avecMedia.has(t.id));
  const sansClasse = b.techniques.filter((t) => !t.familleId && t.niveauxIds.length === 0);
  const nbDoublons = app.doublonsPotentiels().length;
  const conflitsTextes = b.conflitsContributions ?? [];
  const total = aRattacher.length + sansVideo.length + sansClasse.length + app.mediasManquants.length + app.videosOrphelines.length + nbDoublons + conflitsTextes.length;
  return html`
    ${total === 0 ? html`<p class="fil-vide" style="padding:10px 2px 0">Rien à traiter — ta bibliothèque est en ordre. ✓</p>` : nothing}
    <div class="carte-atelier" style="gap:0">
      <div class="encart-entete" style="padding-bottom:4px"><span class="titre-atelier">À compléter</span></div>
      ${kpiListe(app, aRattacher.length, "Captures à rattacher", "rattacher")}
      ${mediathequeListe === "rattacher" ? listeRattacher(app, aRattacher) : nothing}
      ${kpiListe(app, sansVideo.length, "Techniques sans vidéo", "sansvideo")}
      ${mediathequeListe === "sansvideo" ? listeTechniques(app, sansVideo, "Ajouter une vidéo", "Toutes tes techniques ont une vidéo ou un lien.") : nothing}
      ${kpiListe(app, sansClasse.length, "Techniques sans classement", "aclasser")}
      ${mediathequeListe === "aclasser" ? listeTechniques(app, sansClasse, "Classer", "Toutes tes techniques ont une catégorie ou un niveau.") : nothing}
    </div>
    ${conflitsTextes.length
      ? html`<div class="carte-atelier">
          <div class="ligne-atelier">
            <span class="titre-atelier" style="font-size:14px">Textes de pack à arbitrer</span>
            <span class="kpi-nombre">${conflitsTextes.length}</span>
          </div>
          <p class="fil-vide" style="padding:0 2px 6px">La mise à jour d'un pack voulait remplacer un texte que tu as modifié.
            Ta version reste en place tant que tu n'as pas choisi.</p>
          ${conflitsTextes.map((cc) => {
            const contrib = b.contributions.find((x) => x.id === cc.contributionId);
            const tech = contrib?.techniqueId ? b.techniques.find((t) => t.id === contrib.techniqueId) : undefined;
            return html`<div class="conflit-liaison">
              <div class="conflit-liaison-titre"><b>${tech?.nom ?? "Technique disparue"}</b>
                ${contrib?.modifiePar ? html`<span class="conflit-liaison-type">modifié par ${contrib.modifiePar}</span>` : nothing}</div>
              <div class="conflit-liaison-versions">
                <div class="conflit-version"><div class="conflit-version-tete">La mienne</div>
                  <div class="conflit-version-note">${contrib?.description ?? html`<i>sans description</i>`}</div></div>
                <div class="conflit-version"><div class="conflit-version-tete">Celle du pack</div>
                  <div class="conflit-version-note">${cc.description ?? html`<i>sans description</i>`}</div></div>
              </div>
              <div class="conflit-liaison-actions">
                <button class="chip-filtre" @click=${() => void arbitrerConflitContribution(app, cc, "locale")}>La mienne</button>
                <button class="chip-filtre" @click=${() => void arbitrerConflitContribution(app, cc, "pack")}>Celle du pack</button>
              </div>
            </div>`;
          })}
        </div>`
      : nothing}
    <div class="carte-atelier" style="gap:0">
      <div class="encart-entete" style="padding-bottom:4px"><span class="titre-atelier">Intégrité des médias</span></div>
      ${kpiListe(app, app.mediasManquants.length, "Vidéos manquantes", "manquantes", "rouge")}
      ${mediathequeListe === "manquantes" ? listeManquantes(app) : nothing}
      ${kpiListe(app, app.videosOrphelines.length, "Fichiers inutilisés", "inutilises", "rouge")}
      ${mediathequeListe === "inutilises" ? listeInutilises(app) : nothing}
    </div>
    ${nbDoublons
      ? html`<div class="carte-atelier" style="gap:0">
          <div class="encart-entete" style="padding-bottom:4px"><span class="titre-atelier">À examiner</span></div>
          <button class="kpi kpi-filtre" @click=${() => app.ouvrirPlusSection("doublons")}>
            <span class="voyant neutre"></span>
            <span class="kpi-libelle">Doublons potentiels</span>
            <span class="kpi-nombre">${nbDoublons}</span>
            <span class="chevron" aria-hidden="true">›</span>
          </button>
        </div>`
      : nothing}
  `;
}

/** Détail « Vidéos manquantes » (D-104) — chaque technique concernée, cliquable
 *  vers sa fiche ; triée A→Z. */
function listeManquantes(app: MovensoApp): TemplateResult {
  const cibles = app.mediasManquants
    .filter((m) => m.techniqueId)
    .map((m) => ({ id: m.techniqueId!, nom: m.nom }))
    .sort((a, z) => a.nom.localeCompare(z.nom, "fr", { sensitivity: "base" }));
  return html`<div class="mediatheque-liste">
    <p class="details" style="padding:2px 2px 6px">Fichier absent — restaure une sauvegarde, ou retire la note.</p>
    ${cibles.length
      ? cibles.map((t) => html`<div class="ligne-atelier ligne-media">
          <span class="details" style="flex:1;min-width:0"><button class="lien-media-fiche" @click=${() => app.ouvrirFiche(t.id)}>${t.nom}</button></span>
        </div>`)
      : html`<p class="fil-vide" style="padding:6px 0 8px">Aucune vidéo manquante rattachée à une fiche.</p>`}
  </div>`;
}

/** Détail « Captures à rattacher » (D-104) — chaque capture orpheline, avec un
 *  accès direct au rattachement. */
function listeRattacher(app: MovensoApp, aRattacher: { id: string }[]): TemplateResult {
  return html`<div class="mediatheque-liste">
    <p class="details" style="padding:2px 2px 6px">Un savoir sans nom s'oublie — donne-lui une technique.</p>
    ${aRattacher.length
      ? aRattacher.map((c, i) => html`<div class="ligne-atelier ligne-media">
          <span class="details" style="flex:1;min-width:0">Capture ${i + 1}</span>
          <button class="chip-filtre" @click=${() => app.ouvrirRattachement(c.id)}>Rattacher</button>
        </div>`)
      : html`<p class="fil-vide" style="padding:6px 0 8px">Aucune capture à rattacher.</p>`}
  </div>`;
}

/** Sous-écran « Relations entre techniques » : les types de relations, chacun
 *  dépliable pour voir et éditer ses liens directement (D-080). Il n'y a plus
 *  de « liens cassés à réparer » : la suppression d'une fiche nettoie ses liens
 *  entrants au vidage de la corbeille (D-081), donc le cas ne survient plus. */
export function ecranRelations(app: MovensoApp): TemplateResult {
  return html`${sectionConflitsLiaisons(app)}${sectionTypesRelation(app)}`;
}

/** Retraits PROPOSÉS par une nouvelle version d'un pack (D-243) : les arêtes
 *  qu'il avait apportées et qu'il ne déclare plus. Rien n'est retiré d'office —
 *  une arête ne porte pas d'origine, donc un lien tracé à la main entre deux
 *  techniques du pack est indiscernable d'un lien du pack. L'action groupée est
 *  indispensable (une épuration éditoriale se compte en centaines d'arêtes) et
 *  c'est elle, pas les retraits un par un, qui porte l'avertissement. */
function sectionRetraitsProposes(
  app: MovensoApp,
  retraits: ConflitLiaison[],
  nomDe: (id: string) => string,
  libelleType: (id: string) => string,
): TemplateResult {
  if (retraits.length === 0) return nothing as unknown as TemplateResult;
  const parPack = new Map<string, ConflitLiaison[]>();
  for (const c of retraits) parPack.set(c.pack, [...(parPack.get(c.pack) ?? []), c]);
  return html`
    <div class="carte-atelier">
      <div class="ligne-atelier">
        <span class="titre-atelier" style="font-size:14px">Liens que le pack ne déclare plus</span>
        <span class="kpi-nombre">${retraits.length}</span>
      </div>
      <p class="fil-vide" style="padding:0 2px 6px">Une nouvelle version a retiré ces liens de son contenu.
        Les tiens restent en place tant que tu n'as pas choisi.</p>
      ${[...parPack].map(([pack, lot]) => html`
        <div class="ligne-atelier" style="padding-top:2px">
          <span class="sous-titre-atelier">${lot.length} lien${lot.length > 1 ? "s" : ""} — pack « ${pack} »</span>
          <button class="chip-filtre danger retirer-liens-lot"
            @click=${() => void app.retirerTousLesLiensProposes(pack)}>Tout retirer</button>
        </div>`)}
      ${retraits.slice(0, 40).map((c) => html`
        <div class="conflit-liaison retrait-propose">
          <div class="conflit-liaison-titre"><b>${nomDe(c.sourceId)}</b> <span class="fleche-instance">&#8594;</span> <b>${nomDe(c.cibleId)}</b>
            <span class="conflit-liaison-type">${libelleType(c.type)}</span></div>
          <div class="conflit-liaison-actions">
            <button class="chip-filtre" @click=${() => void app.arbitrerConflitLiaison(c, "local")}>Garder</button>
            <button class="chip-filtre danger" @click=${() => void app.arbitrerConflitLiaison(c, "retirer")}>Retirer</button>
          </div>
        </div>`)}
      ${retraits.length > 40
        ? html`<p class="fil-vide" style="padding:6px 2px 0">Les ${retraits.length - 40} autres apparaîtront ensuite —
            ou d'un coup avec « Tout retirer ».</p>`
        : nothing}
    </div>
  `;
}

/** Conflits de liaisons détectés à l'import (D-157, étendu D-243) : ce qu'un
 *  pack PROPOSE sur une arête, sans jamais l'appliquer seul. Deux sens, deux
 *  gestes — une raison différente s'arbitre « la mienne / celle du pack / les
 *  deux » ; un lien que le pack NE DÉCLARE PLUS s'arbitre « garder / retirer »
 *  (rendu par `sectionRetraitsProposes`). Jamais subi, jamais bloquant : tant
 *  que rien n'est tranché, l'arête locale reste telle quelle. Une entrée dont
 *  l'arête ou les techniques ont disparu est écartée à l'affichage. */
function sectionConflitsLiaisons(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const vivants = (b.conflitsLiaisons ?? []).filter((c) => {
    const source = b.techniques.find((t) => t.id === c.sourceId);
    return !!source?.relations.some((r) => r.type === c.type && r.cibleId === c.cibleId)
      && b.techniques.some((t) => t.id === c.cibleId);
  });
  const conflits = vivants.filter((c) => c.sens !== "retrait");
  const retraits = vivants.filter((c) => c.sens === "retrait");
  if (vivants.length === 0) return nothing as unknown as TemplateResult;
  const nomDe = (id: string) => b.techniques.find((t) => t.id === id)?.nom ?? "?";
  const libelleType = (id: string) => b.typesRelation.find((t) => t.id === id)?.libelle ?? id;
  if (conflits.length === 0) return sectionRetraitsProposes(app, retraits, nomDe, libelleType);
  return html`
    ${retraits.length ? sectionRetraitsProposes(app, retraits, nomDe, libelleType) : nothing}
    <div class="carte-atelier">
      <div class="ligne-atelier">
        <span class="titre-atelier" style="font-size:14px">Liaisons à arbitrer</span>
        <span class="kpi-nombre">${conflits.length}</span>
      </div>
      <p class="fil-vide" style="padding:0 2px 6px">Un pack propose une raison ou une priorité différente sur ces liens.
        Ta version reste en place tant que tu n'as pas choisi.</p>
      ${conflits.map((c) => {
        const r = b.techniques.find((t) => t.id === c.sourceId)!.relations.find((x) => x.type === c.type && x.cibleId === c.cibleId)!;
        return html`<div class="conflit-liaison">
          <div class="conflit-liaison-titre"><b>${nomDe(c.sourceId)}</b> <span class="fleche-instance">→</span> <b>${nomDe(c.cibleId)}</b>
            <span class="conflit-liaison-type">${libelleType(c.type)}</span></div>
          <div class="conflit-liaison-versions">
            <div class="conflit-version"><div class="conflit-version-tete">La mienne</div>
              <div class="conflit-version-note">${r.note ?? html`<i>sans raison</i>`}</div>
              ${r.priorite !== undefined ? html`<div class="conflit-version-prio">priorité ${r.priorite}</div>` : nothing}</div>
            <div class="conflit-version"><div class="conflit-version-tete">Celle du pack</div>
              <div class="conflit-version-note">${c.note ?? html`<i>sans raison</i>`}</div>
              ${c.priorite !== undefined ? html`<div class="conflit-version-prio">priorité ${c.priorite}</div>` : nothing}</div>
          </div>
          <div class="conflit-liaison-actions">
            <button class="chip-filtre" @click=${() => void app.arbitrerConflitLiaison(c, "local")}>La mienne</button>
            <button class="chip-filtre" @click=${() => void app.arbitrerConflitLiaison(c, "pack")}>Celle du pack</button>
            <button class="chip-filtre" @click=${() => void app.arbitrerConflitLiaison(c, "deux")} title="Une seule liaison, qui garde les deux textes — la tienne d'abord">Fusionner les deux</button>
          </div>
        </div>`;
      })}
    </div>
  `;
}

/** Sous-écran « Corbeille » (D-081) : les fiches retirées, restaurables tant
 *  qu'on ne vide pas. Le vidage est irréversible (snapshot pris avant) et c'est
 *  seulement à ce moment que les liens entrants sont nettoyés et les notes
 *  personnelles rendues « à rattacher ». */
export function ecranCorbeille(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const entrees = b.corbeille ?? [];
  if (entrees.length === 0)
    return html`<p class="fil-vide" style="padding-top:10px">La corbeille est vide. Une fiche mise à la corbeille arrive ici et reste restaurable sans limite de durée — rien n'expire tout seul, tant que tu ne vides pas.</p>`;
  return html`
    <div class="carte-atelier" style="gap:0">
      <div class="ligne-atelier">
        <span class="titre-atelier" style="font-size:14px;flex:1">${entrees.length} fiche${entrees.length > 1 ? "s" : ""} en corbeille</span>
        <button class="chip-filtre danger"
          @click=${() => app.demanderConfirmation({
            titre: `Vider la corbeille (${entrees.length} fiche${entrees.length > 1 ? "s" : ""}) ?`,
            corps: "Irréversible — un point de restauration sera conservé.",
            bouton: "Vider la corbeille",
            action: () => { void app.viderCorbeille(); },
          })}>
          Vider la corbeille</button>
      </div>
      <p class="fil-vide" style="padding:2px 2px 8px">Restaurer une fiche la remet à l'identique (notes, favori, liens). Le vidage nettoie les liens qui pointaient vers elle.</p>
      ${entrees.map((e) => {
        const disc = b.disciplines.find((d) => d.id === e.technique.disciplineId);
        const nbMedias = e.contributions.reduce((n, c) => n + c.medias.length, 0);
        const jour = e.supprimeeLe.slice(0, 10);
        return html`<div class="ligne-atelier ligne-corbeille" style="flex-wrap:wrap">
          <span class="ligne-menu-icone" style="background:#efe3d6" aria-hidden="true">🗑</span>
          <span class="details" style="flex:1;min-width:0">
            <b>${e.technique.nom}</b>
            <span style="opacity:.7"> · ${disc?.nom ?? "sans discipline"} · ${e.contributions.length} note${e.contributions.length > 1 ? "s" : ""}${nbMedias ? ` · ${nbMedias} média${nbMedias > 1 ? "s" : ""}` : ""} · retirée le ${jour}</span>
          </span>
          <button class="chip-filtre" @click=${() => void app.restaurerTechnique(e.technique.id)}>Restaurer</button>
          <button class="bouton-icone danger" aria-label=${`Supprimer définitivement ${e.technique.nom}`} title="Supprimer définitivement"
            @click=${() => app.demanderConfirmation({
              titre: `Supprimer définitivement « ${e.technique.nom} » ?`,
              corps: "Irréversible.",
              bouton: "Supprimer définitivement",
              action: () => { void app.supprimerDefinitivement(e.technique.id); },
            })}>✕</button>
        </div>`;
      })}
    </div>
  `;
}

/** Sous-écran « Doublons potentiels » : d'abord une LISTE COMPACTE (§3) ; la
 *  comparaison et la fusion détaillées n'apparaissent qu'après avoir choisi une
 *  paire. Jamais une fusion subie. */
export function ecranDoublons(app: MovensoApp): TemplateResult {
  // Liste triée par ordre alphabétique du nom (fiche A) — plus lisible qu'un
  // tri par id interne.
  const paires = [...app.doublonsPotentiels()].sort((p, q) =>
    (app.technique(p.aId)?.nom ?? "").localeCompare(app.technique(q.aId)?.nom ?? "", "fr", { sensitivity: "base" }),
  );
  const nbEcartes = (app.bibliotheque!.doublonsIgnores ?? []).length;
  // Rescan : réexamine tout, y compris les paires déjà écartées (« pas des
  // doublons » / conservées). Rien n'est fusionné — les paires reviennent juste
  // à l'arbitrage.
  const rescan = nbEcartes
    ? html`<button class="chip-filtre rescan-doublons" style="margin:8px 18px 0"
        @click=${() => void app.rescannerDoublons()}>
        ↻ Rescanner <span>retrouve les ${nbEcartes} paire${nbEcartes > 1 ? "s" : ""} déjà écartée${nbEcartes > 1 ? "s" : ""}</span>
      </button>`
    : nothing;
  // Fusions réversibles (D-101) : chaque fusion peut être défaite (bundle
  // pré-fusion conservé). Rien à voir avec les paires en attente d'arbitrage.
  const fusions = app.bibliotheque!.fusions ?? [];
  const fusionsBloc = fusions.length
    ? html`<div class="carte-atelier" style="margin-top:10px">
        <div class="titre-atelier" style="font-size:14px">Fusions réversibles</div>
        <p class="fil-vide" style="padding:2px 0 6px">Défusionner rétablit les deux fiches d'origine (les liens entrants restent sur la fiche fusionnée).</p>
        ${fusions.map(
          (f) => html`<div class="ligne-atelier">
            <span class="details" style="flex:1">🔀 « ${f.a.technique.nom} » + « ${f.b.technique.nom} »</span>
            <button class="chip-filtre" @click=${() => void app.defusionner(f.fusionneeId)}>Défuser</button>
          </div>`,
        )}
      </div>`
    : nothing;
  if (paires.length === 0)
    return html`
      <p class="fil-vide" style="padding-top:10px">Aucun doublon détecté. Deux fiches de nom identique ou proche, venant de sources différentes, s'afficheraient ici.</p>
      ${rescan}
      ${fusionsBloc}
    `;
  const ouverte = app.doublonOuvert ? paires.find((p) => clePaire(p.aId, p.bId) === app.doublonOuvert) : undefined;
  if (ouverte) {
    return html`
      <div class="actions-bibliotheque" style="padding-top:8px">
        <button class="chip-filtre" @click=${() => { app.doublonOuvert = null; app.fusionDoublon = null; app.requestUpdate(); }}>← Tous les doublons</button>
      </div>
      ${cartePaireDoublon(app, ouverte)}
    `;
  }
  return html`
    <p class="fil-vide" style="padding:8px 2px 6px">
      Deux fiches de nom identique ou proche, venant de sources différentes. Elles
      restent indépendantes tant que tu ne décides rien — choisis-en une pour comparer.
    </p>
    <div class="fil doublons-liste">
      ${paires.map((p) => ligneDoublon(app, p))}
    </div>
    ${rescan}
    ${fusionsBloc}
  `;
}

/** Ligne compacte d'une paire de doublons — ouvre le détail à la sélection. */
function ligneDoublon(app: MovensoApp, p: PaireDoublon): TemplateResult {
  const a = app.technique(p.aId);
  const z = app.technique(p.bId);
  if (!a || !z) return html``;
  return html`<button class="ligne-menu ligne-doublon" @click=${() => { app.doublonOuvert = clePaire(p.aId, p.bId); app.requestUpdate(); }}>
    <span class="ligne-menu-icone" style="background:#efe3d6" aria-hidden="true">🔀</span>
    <span class="ligne-menu-corps">
      <span class="ligne-menu-titre">${a.nom}</span>
      <span class="ligne-menu-etat">${a.nom === z.nom ? "même nom, deux sources" : `≈ « ${z.nom} »`}</span>
    </span>
    <span class="chevron">›</span>
  </button>`;
}

function coteDoublon(app: MovensoApp, cote: CoteDoublon, lettre: string): TemplateResult {
  return html`<div class="doublon-cote">
    <div class="doublon-apercu">
      ${vignetteTechnique(app, cote.technique, cote.source)}
    </div>
    <div class="doublon-titre">${lettre} · ${cote.technique.nom}</div>
    ${cote.description ? html`<div class="doublon-desc">${cote.description.slice(0, 140)}${cote.description.length > 140 ? "…" : ""}</div>` : nothing}
    <div class="doublon-chiffres">
      ${cote.medias.length} média${cote.medias.length > 1 ? "s" : ""} ·
      ${cote.pointsCles.length} point${cote.pointsCles.length > 1 ? "s" : ""} ·
      ${cote.niveaux.length} niveau${cote.niveaux.length > 1 ? "x" : ""} ·
      ${cote.relations} relation${cote.relations > 1 ? "s" : ""}
    </div>
  </div>`;
}

function cartePaireDoublon(app: MovensoApp, p: PaireDoublon): TemplateResult {
  const diff = differencesDoublon(app.bibliotheque!, p.aId, p.bId);
  if (!diff) return html``;
  const ouvertFusion =
    app.fusionDoublon !== null && app.fusionDoublon.aId === p.aId && app.fusionDoublon.bId === p.bId;
  return html`<div class="doublon">
    <div class="doublon-cotes">
      ${coteDoublon(app, diff.a, "A")}
      ${coteDoublon(app, diff.b, "B")}
    </div>
    ${ouvertFusion
      ? panneauFusion(app, p, diff)
      : html`<div class="doublon-decisions">
          <button class="chip-filtre" @click=${() => void app.classerDoublon(p.aId, p.bId, "Conservées toutes les deux ✓ — fiches indépendantes")}>
            Conserver les deux
          </button>
          <button class="chip-filtre" @click=${() => void app.resoudreDoublonGarder(p.aId, p.bId)}>
            Garder « ${diff.a.technique.nom} » (A)
          </button>
          <button class="chip-filtre" @click=${() => void app.resoudreDoublonGarder(p.bId, p.aId)}>
            Garder « ${diff.b.technique.nom} » (B)
          </button>
          <button class="chip-filtre" @click=${() => {
            app.fusionDoublon = {
              aId: p.aId, bId: p.bId,
              choix: { titre: "a", textes: "deux", medias: "deux", niveaux: "deux", relations: "deux" },
            };
            app.requestUpdate();
          }}>Fusionner…</button>
          <button class="chip-filtre" @click=${() => void app.classerDoublon(p.aId, p.bId, "Marquées « pas des doublons » — plus proposées")}>
            Ce ne sont pas des doublons
          </button>
        </div>`}
  </div>`;
}

/** Panneau de fusion sélective : chaque dimension arbitrée séparément, avec un
 *  aperçu calculé du résultat (jamais d'empilement, médias dédupliqués). */
function panneauFusion(app: MovensoApp, p: PaireDoublon, diff: { a: CoteDoublon; b: CoteDoublon }): TemplateResult {
  const etat = app.fusionDoublon!;
  const c = etat.choix;
  const set = (patch: Partial<typeof c>) => { app.fusionDoublon = { ...etat, choix: { ...c, ...patch } }; app.requestUpdate(); };
  const nomA = diff.a.technique.nom;
  const nomB = diff.b.technique.nom;
  const choixLigne = (
    libelle: string,
    cle: "titre" | "textes" | "medias" | "niveaux" | "relations",
    options: { valeur: string; texte: string }[],
  ) => html`<div class="fusion-ligne">
    <span class="fusion-libelle">${libelle}</span>
    <div class="chips-filtres" style="padding:0">
      ${options.map(
        (o) => html`<button class="chip-filtre ${c[cle] === o.valeur ? "actif" : ""}"
          @click=${() => set({ [cle]: o.valeur } as Partial<typeof c>)}>${o.texte}</button>`,
      )}
    </div>
  </div>`;
  // Aperçu : calcul réel de la fusion (fonction pure), sans rien persister.
  let apercu: TemplateResult = html``;
  try {
    const fusionnee = fusionnerDoublons(app.bibliotheque!, p.aId, p.bId, c);
    const t = fusionnee.techniques.find((x) => x.id === p.aId)!;
    const contribs = fusionnee.contributions.filter((x) => x.techniqueId === t.id && x.provenance !== "personnel");
    const nbMedias = contribs.reduce((n, x) => n + x.medias.length, 0);
    const desc = contribs.map((x) => x.description ?? "").filter(Boolean).join(" ").slice(0, 120);
    apercu = html`<div class="fusion-apercu">
      <div class="fusion-apercu-titre">Aperçu : « ${t.nom} »</div>
      <div class="doublon-chiffres">${nbMedias} média${nbMedias > 1 ? "s" : ""} · ${t.niveauxIds.length} niveau${t.niveauxIds.length > 1 ? "x" : ""} · ${t.relations.length} relation${t.relations.length > 1 ? "s" : ""}</div>
      ${desc ? html`<div class="doublon-desc">${desc}${desc.length >= 120 ? "…" : ""}</div>` : nothing}
    </div>`;
  } catch {
    apercu = html`<p class="fil-vide">Aperçu indisponible pour ce choix.</p>`;
  }
  return html`<div class="fusion-panneau">
    ${choixLigne("Titre et famille", "titre", [{ valeur: "a", texte: `A (${nomA})` }, { valeur: "b", texte: `B (${nomB})` }])}
    ${choixLigne("Textes", "textes", [{ valeur: "a", texte: "A" }, { valeur: "b", texte: "B" }, { valeur: "deux", texte: "Les deux" }])}
    ${choixLigne("Médias", "medias", [{ valeur: "a", texte: "A" }, { valeur: "b", texte: "B" }, { valeur: "deux", texte: "Les deux" }])}
    ${choixLigne("Niveaux", "niveaux", [{ valeur: "a", texte: "A" }, { valeur: "b", texte: "B" }, { valeur: "deux", texte: "Les deux" }])}
    ${choixLigne("Relations", "relations", [{ valeur: "a", texte: "A" }, { valeur: "b", texte: "B" }, { valeur: "deux", texte: "Les deux" }])}
    ${apercu}
    ${(() => {
      // S2.6 (D-168) : IMPACTS EXTERNES dits AVANT de fusionner — ce qui sera
      // réécrit de B vers la fiche fusionnée (redirigé, jamais perdu).
      const bib = app.bibliotheque!;
      const entrantes = bib.techniques.reduce((n, t) => n + (t.id === p.bId ? 0 : t.relations.filter((r) => r.cibleId === p.bId).length), 0);
      const blocs = bib.compositions.reduce((n, x) => n + x.blocs.filter((y) => y.type === "technique" && y.techniqueId === p.bId).length, 0);
      const favori = bib.favoris.includes(p.bId);
      const impacts = [
        entrantes ? `${entrantes} lien${entrantes > 1 ? "s" : ""} entrant${entrantes > 1 ? "s" : ""} redirigé${entrantes > 1 ? "s" : ""}` : null,
        blocs ? `${blocs} pas de composition redirigé${blocs > 1 ? "s" : ""}` : null,
        favori ? "le favori suit" : null,
      ].filter(Boolean);
      return html`<p class="fil-vide fusion-impacts" style="padding:4px 2px 0">
        ${impacts.length ? html`Ce qui pointait « B » suivra la fiche fusionnée : ${impacts.join(" · ")}.<br>` : nothing}
        Un point de restauration est créé avant la fusion — et la fusion reste défusionnable depuis « Doublons ».
      </p>`;
    })()}
    <div class="doublon-decisions">
      <button class="bouton principal" @click=${() => void app.fusionnerDoublonAvec(p.aId, p.bId, c)}>Fusionner en une fiche</button>
      <button class="chip-filtre" @click=${() => { app.fusionDoublon = null; app.requestUpdate(); }}>Annuler</button>
    </div>
  </div>`;
}

/** Recherche de rattachement d'un orphelin (S2.12) — état de session. */
let rattachementOrphelin: { id: string; texte: string } | null = null;

/** Un fichier orphelin (§13) : prévisualisation OBLIGATOIRE avant la
 *  suppression, un fichier à la fois — et RATTACHEMENT d'un média retrouvé
 *  (S2.12) : le fichier redevient référencé, rien ne bouge physiquement. */
function ligneOrpheline(app: MovensoApp, o: { id: string; taille: number }): TemplateResult {
  const verifiee = orphelinesVerifiees.has(o.id);
  return html`<div class="ligne-atelier ligne-orpheline" style="flex-wrap:wrap">
    <span class="details" style="flex:1">🎞 fichier de ${tailleLisible(o.taille)} — plus rien ne le référence</span>
    <button class="chip-filtre" @click=${() => { verifiee ? orphelinesVerifiees.delete(o.id) : orphelinesVerifiees.add(o.id); app.requestUpdate(); }}>
      ${verifiee ? "Replier" : "Vérifier"}</button>
    ${verifiee
      ? html`<div style="width:100%">
          <movenso-video-locale .app=${app} .mediaId=${o.id}></movenso-video-locale>
          ${(() => {
            // S2.12 : média RETROUVÉ → rattacher à une fiche (contribution
            // personnelle) plutôt que supprimer. Recherche courte, 5 résultats.
            const actif = rattachementOrphelin?.id === o.id;
            const resultats = actif && rattachementOrphelin!.texte.trim()
              ? chercherTechniques(app.bibliotheque!, rattachementOrphelin!.texte).slice(0, 5)
              : [];
            return html`<div style="margin-top:6px">
              <input class="champ-mini" style="width:100%" placeholder="🔗 Rattacher à une technique (nom)…"
                aria-label="Rattacher ce fichier à une technique"
                .value=${actif ? rattachementOrphelin!.texte : ""}
                @input=${(ev: Event) => { rattachementOrphelin = { id: o.id, texte: (ev.target as HTMLInputElement).value }; app.requestUpdate(); }}>
              ${resultats.length
                ? html`<div class="chips-filtres" style="padding-top:4px">
                    ${resultats.map((t) => html`<button class="chip-filtre"
                      @click=${() => { rattachementOrphelin = null; void app.rattacherOrphelin(o.id, t.id); }}>${t.nom}</button>`)}
                  </div>`
                : nothing}
            </div>`;
          })()}
          <button class="action-danger" style="margin-top:6px"
            @click=${() => {
              app.demanderConfirmation({
                titre: `Supprimer définitivement ce fichier inutilisé (${tailleLisible(o.taille)}) ?`,
                bouton: "Supprimer le fichier",
                action: () => { orphelinesVerifiees.delete(o.id); void app.supprimerVideoOrpheline(o.id); },
              });
            }}>Supprimer ce fichier inutilisé</button>
        </div>`
      : nothing}
  </div>`;
}

/** État léger de la médiathèque (D-079/082) : quel type de liste est déplié via
 *  son KPI, discipline filtrée, aperçus ouverts, média en cours de renommage. */
type CleListeMedias = "local" | "enligne" | "sansvideo" | "aclasser" | "manquantes" | "inutilises" | "rattacher";

let mediathequeListe: CleListeMedias | null = null;

/** Réinitialise l'état d'affichage de l'écran Médias (D-104) : à chaque arrivée
 *  fraîche, tous les KPI dépliables reviennent repliés. */
export function reinitialiserMediatheque(): void {
  mediathequeListe = null;
  mediathequeFiltreDisc = null;
}

let mediathequeFiltreDisc: string | null = null;

const apercusMedia = new Set<string>();

let renommageMedia: string | null = null;

interface EntreeMediatheque {
  media: Media;
  refs: { nom: string; techniqueId: string | null }[];
  disciplines: Set<string>;
}

/** Le parc de médias, tous types confondus (D-079) — une entrée par média,
 *  ses références et les disciplines auxquelles il se rattache. */
function collecterMedias(app: MovensoApp): Map<string, EntreeMediatheque> {
  const b = app.bibliotheque!;
  const parId = new Map<string, EntreeMediatheque>();
  const noter = (m: EntreeMediatheque["media"], ref: { nom: string; techniqueId: string | null }, disciplineId?: string) => {
    let e = parId.get(m.id);
    if (!e) { e = { media: m, refs: [], disciplines: new Set() }; parId.set(m.id, e); }
    e.refs.push(ref);
    if (disciplineId) e.disciplines.add(disciplineId);
  };
  for (const c of b.contributions) {
    const t = c.techniqueId ? app.technique(c.techniqueId) : undefined;
    for (const m of c.medias)
      noter(m, { nom: t ? t.nom : "capture à rattacher", techniqueId: c.techniqueId }, t?.disciplineId);
  }
  for (const co of b.compositions)
    for (const bl of co.blocs)
      for (const m of bl.medias) noter(m, { nom: `composition « ${co.nom} »`, techniqueId: null });
  return parId;
}

/** Libellé court d'un média (D-082) : le libellé choisi, sinon le nom d'origine,
 *  sinon un mot générique selon le type — jamais l'id/ref interne (inutile). */
function libelleMedia(m: Media): string {
  if (m.label?.trim()) return m.label.trim();
  if (m.nomOriginal?.trim()) return m.nomOriginal.trim();
  return m.type === "local" ? "vidéo" : m.type === "plateforme" ? m.service ?? "vidéo en ligne" : "lien";
}

/** URL affichable d'un média en ligne (D-119) : un média YouTube stocke l'ID de
 *  vidéo (ref), on le repromeut en URL éditable ; un lien nu s'affiche tel quel. */
function lienMediaAffichable(m: Media): string {
  if (m.type === "plateforme" && m.service === "youtube") return `https://www.youtube.com/watch?v=${m.ref}`;
  return m.ref;
}

/** KPI cliquable qui fait office de FILTRE (D-082) : voyant + libellé + nombre,
 *  toute la ligne déplie/replie la liste correspondante (jamais 160 d'un coup). */
function kpiListe(app: MovensoApp, n: number, libelle: string, cle: CleListeMedias, ton: "neutre" | "rouge" = "neutre"): TemplateResult {
  const ouvert = mediathequeListe === cle;
  return html`<button class="kpi kpi-filtre ${ouvert ? "actif" : ""}" aria-expanded=${ouvert}
    @click=${() => { mediathequeListe = ouvert ? null : cle; app.requestUpdate(); }}>
    <span class="voyant ${n ? ton : "vert"}"></span>
    <span class="kpi-libelle">${libelle}</span>
    <span class="kpi-nombre">${n}</span>
    <span class="chevron" aria-hidden="true">${ouvert ? "▾" : "▸"}</span>
  </button>`;
}

/** Une ligne de média (D-082) : nom de la technique (cliquable → fiche) + le
 *  libellé, puis la taille (local) ou « en ligne » — jamais l'id/ref. Aperçu et
 *  renommage sur place ; aucune suppression ici (les orphelins sont dans
 *  « Problèmes »). */
function ligneMediatheque(app: MovensoApp, e: EntreeMediatheque): TemplateResult {
  const m = e.media;
  const icone = m.type === "local" ? "🎞" : m.type === "plateforme" ? "▶" : "🔗";
  const presentLocal = m.type === "local" && app.taillesVideos.has(m.id);
  const taille = m.type === "local" ? app.taillesVideos.get(m.id) ?? m.taille : undefined;
  const detail =
    m.type === "local" ? (presentLocal ? tailleLisible(taille ?? 0) : "fichier absent") : "en ligne";
  const contexte = e.refs[0]?.nom ?? "média";
  const premiereRef = e.refs.find((r) => r.techniqueId);
  const enApercu = apercusMedia.has(m.id);
  const enRenommage = renommageMedia === m.id;
  return html`<div class="ligne-atelier ligne-media" style="flex-wrap:wrap">
    <span class="details" style="flex:1;min-width:0">
      <span aria-hidden="true">${icone}</span>
      ${premiereRef
        ? html`<button class="lien-media-fiche" @click=${() => app.ouvrirFiche(premiereRef.techniqueId!)}>${contexte}</button>`
        : html`<b>${contexte}</b>`}
      <span aria-hidden="true"> · </span>
      ${enRenommage
        ? html`<input class="champ-mini nom-media-champ" .value=${m.label ?? ""} placeholder=${libelleMedia(m)} aria-label="Libellé du média"
            @change=${(ev: Event) => void app.majMediaLabel(m.id, (ev.target as HTMLInputElement).value)}>`
        : html`<span>${libelleMedia(m)}</span>`}
      <span style="opacity:.7"> · ${detail}</span>
    </span>
    <button class="bouton-icone" aria-label="Modifier ce média" title=${m.type === "local" ? "Renommer" : "Modifier le nom et le lien"}
      @click=${() => { renommageMedia = enRenommage ? null : m.id; app.requestUpdate(); }}>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
    </button>
    ${m.type === "local"
      ? html`<button class="chip-filtre" ?disabled=${!presentLocal}
          @click=${() => { enApercu ? apercusMedia.delete(m.id) : apercusMedia.add(m.id); app.requestUpdate(); }}>
          ${enApercu ? "Replier" : "▶ Aperçu"}</button>`
      : premiereRef
        ? html`<button class="chip-filtre" @click=${() => app.ouvrirFiche(premiereRef.techniqueId!)}>Ouvrir la fiche</button>`
        : urlSure(m.ref)
          ? html`<a class="chip-filtre" href=${urlSure(m.ref)} target="_blank" rel="noopener noreferrer"
              title="Quitte Movenso — s'ouvre dans le navigateur">▶ Ouvrir le lien · ${domaineDe(m.ref)} ↗</a>`
          : html`<span class="chip-filtre" title="Lien non https — jamais ouvert" style="opacity:.6">🔗 lien non sûr</span>`}
    ${enRenommage && m.type !== "local"
      ? html`<input class="champ-mini" style="width:100%; margin-top:6px" inputmode="url" aria-label="Lien du média (YouTube ou autre)"
          placeholder="🔗 Lien (YouTube ou autre)" .value=${lienMediaAffichable(m)}
          @change=${(ev: Event) => void app.majMediaLien(m.id, (ev.target as HTMLInputElement).value)}>`
      : nothing}
    ${enApercu && presentLocal
      ? html`<div style="width:100%"><movenso-video-locale .app=${app} .mediaId=${m.id}></movenso-video-locale></div>`
      : nothing}
  </div>`;
}

/** Liste détaillée d'un type de média (D-082) — n'apparaît qu'au clic sur son
 *  KPI, filtrable par discipline (dès ≥ 2 disciplines). */
function listeMedias(app: MovensoApp, entrees: EntreeMediatheque[]): TemplateResult {
  const disciplines = app.bibliotheque!.disciplines;
  const filtre = mediathequeFiltreDisc && disciplines.some((d) => d.id === mediathequeFiltreDisc) ? mediathequeFiltreDisc : null;
  const affichees = (filtre ? entrees.filter((e) => e.disciplines.has(filtre)) : entrees)
    .slice()
    .sort((a, z) => (a.refs[0]?.nom ?? libelleMedia(a.media)).localeCompare(z.refs[0]?.nom ?? libelleMedia(z.media), "fr", { sensitivity: "base" }));
  return html`<div class="mediatheque-liste">
    ${disciplines.length >= 2
      ? html`<div class="chips-filtres" style="padding:2px 0 6px">
          <button class="chip-filtre ${filtre === null ? "actif" : ""}" @click=${() => { mediathequeFiltreDisc = null; app.requestUpdate(); }}>Toutes</button>
          ${disciplines.map((d) => html`<button class="chip-filtre ${filtre === d.id ? "actif" : ""}"
            @click=${() => { mediathequeFiltreDisc = d.id; app.requestUpdate(); }}>${d.nom}</button>`)}
        </div>`
      : nothing}
    ${affichees.length
      ? affichees.map((e) => ligneMediatheque(app, e))
      : html`<p class="fil-vide" style="padding:6px 0 8px">${entrees.length ? "Aucun média pour cette discipline." : "Aucun média de ce type pour l'instant."}</p>`}
  </div>`;
}

/** Liste navigable de techniques (D-102, généralisée D-107) — n'apparaît qu'au
 *  clic sur son KPI, filtrable par discipline (dès ≥ 2 disciplines). Chaque
 *  technique ouvre sa fiche ; `texteBouton` nomme l'action (ajouter une vidéo,
 *  classer…). `vide` = message quand il n'y a rien. */
function listeTechniques(app: MovensoApp, techniques: Technique[], texteBouton: string, vide: string): TemplateResult {
  const disciplines = app.bibliotheque!.disciplines;
  const filtre = mediathequeFiltreDisc && disciplines.some((d) => d.id === mediathequeFiltreDisc) ? mediathequeFiltreDisc : null;
  const affichees = (filtre ? techniques.filter((t) => t.disciplineId === filtre) : techniques)
    .slice()
    .sort((a, z) => a.nom.localeCompare(z.nom, "fr", { sensitivity: "base" }));
  return html`<div class="mediatheque-liste">
    ${disciplines.length >= 2
      ? html`<div class="chips-filtres" style="padding:2px 0 6px">
          <button class="chip-filtre ${filtre === null ? "actif" : ""}" @click=${() => { mediathequeFiltreDisc = null; app.requestUpdate(); }}>Toutes</button>
          ${disciplines.map((d) => html`<button class="chip-filtre ${filtre === d.id ? "actif" : ""}"
            @click=${() => { mediathequeFiltreDisc = d.id; app.requestUpdate(); }}>${d.nom}</button>`)}
        </div>`
      : nothing}
    ${affichees.length
      ? affichees.map((t) => {
          const disc = disciplines.find((d) => d.id === t.disciplineId);
          return html`<div class="ligne-atelier ligne-media">
            <span class="details" style="flex:1;min-width:0">
              <button class="lien-media-fiche" @click=${() => app.ouvrirFiche(t.id)}>${t.nom}</button>
              ${disc ? html`<span style="opacity:.7"> · ${disc.nom}</span>` : nothing}
            </span>
            <button class="chip-filtre" @click=${() => app.ouvrirFiche(t.id)}>${texteBouton}</button>
          </div>`;
        })
      : html`<p class="fil-vide" style="padding:6px 0 8px">${techniques.length ? "Aucune pour cette discipline." : vide}</p>`}
  </div>`;
}

/** Détail « Fichiers inutilisés » (D-107/D-171) — les orphelins,
 *  prévisualisation obligatoire avant suppression ; les fichiers VÉRIFIÉS
 *  peuvent ensuite partir ensemble (D-171 — chacun revérifié à l'instant T). */
function listeInutilises(app: MovensoApp): TemplateResult {
  const totalOctets = app.videosOrphelines.reduce((n, o) => n + o.taille, 0);
  const verifies = app.videosOrphelines.filter((o) => orphelinesVerifiees.has(o.id));
  const octetsVerifies = verifies.reduce((n, o) => n + o.taille, 0);
  return html`<div class="mediatheque-liste">
    <p class="details" style="padding:2px 2px 6px">Vérifie chaque fichier avant de le supprimer${totalOctets ? html` · total : ${tailleLisible(totalOctets)}` : nothing}. Un média retrouvé peut aussi être RATTACHÉ à une fiche.</p>
    ${verifies.length >= 2
      ? html`<button class="action-danger suppression-groupe-orphelins" style="margin:2px 0 8px"
          @click=${() => {
            app.demanderConfirmation({
              titre: `Supprimer les ${verifies.length} fichiers vérifiés — ${tailleLisible(octetsVerifies)} ?`,
              corps: "Chacun sera revérifié inutilisé à l'instant de supprimer.",
              bouton: `Supprimer les ${verifies.length} fichiers`,
              action: () => { verifies.forEach((o) => orphelinesVerifiees.delete(o.id)); void app.supprimerOrphelinsVerifies(verifies.map((o) => o.id)); },
            });
          }}>Supprimer les ${verifies.length} fichiers vérifiés — ${tailleLisible(octetsVerifies)}</button>`
      : nothing}
    ${app.videosOrphelines.length ? app.videosOrphelines.map((o) => ligneOrpheline(app, o)) : html`<p class="fil-vide" style="padding:6px 0 8px">Aucun fichier inutilisé.</p>`}
  </div>`;
}
