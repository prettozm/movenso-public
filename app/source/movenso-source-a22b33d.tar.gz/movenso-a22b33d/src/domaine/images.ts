/**
 * Images de la bibliothèque (schéma 6, D-269) — fonctions PURES, testables en
 * Node. Pendant du registre des médias : la question qu'on se pose ici est la
 * même que pour une vidéo — « qui la référence encore ? » — parce que c'est
 * elle qui décide ce qu'on a le droit d'effacer.
 */

import type { Bibliotheque } from "./modele.ts";

/**
 * Ids des images encore RÉFÉRENCÉES par une couverture, où qu'elle se trouve.
 *
 * Le parcours est générique, et c'est la même raison qu'à la migration : une
 * couverture ne vit pas seulement sur les techniques et les familles — la
 * CORBEILLE en garde une copie tant qu'une fiche est restaurable (D-081), et
 * les FUSIONS réversibles aussi (D-101). Énumérer ces lieux à la main, c'est
 * finir par supprimer l'illustration d'une fiche qu'on pouvait encore
 * restaurer. Ici, oublier un lieu supprimerait des octets : on ne l'énumère
 * donc pas, on cherche partout.
 */
function imagesReferencees(b: Bibliotheque): Set<string> {
  const refs = new Set<string>();
  const visiter = (noeud: unknown): void => {
    if (Array.isArray(noeud)) return noeud.forEach(visiter);
    if (!noeud || typeof noeud !== "object") return;
    const o = noeud as Record<string, unknown>;
    if (o["type"] === "fichier" && typeof o["imageId"] === "string") {
      refs.add(o["imageId"]);
      return;
    }
    for (const valeur of Object.values(o)) visiter(valeur);
  };
  // L'inventaire lui-même est exclu du parcours : il DÉCLARE les images, il ne
  // les référence pas. L'y inclure rendrait toute image éternellement vivante.
  const { images: _inventaire, ...reste } = b;
  visiter(reste);
  return refs;
}

/** L'inventaire réduit aux images encore référencées. Rien n'est supprimé sur
 *  le disque ici — le domaine ne fait pas d'E/S ; le balayage des fichiers est
 *  une opération SÉPARÉE, et volontairement plus prudente. */
export function inventaireEpure(b: Bibliotheque): NonNullable<Bibliotheque["images"]> {
  const vivantes = imagesReferencees(b);
  return (b.images ?? []).filter((i) => vivantes.has(i.id));
}
