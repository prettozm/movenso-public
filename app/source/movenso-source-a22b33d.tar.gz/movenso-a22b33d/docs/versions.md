# Versions — où vit chaque numéro (Movenso)

> **Type : vivant** · **Statut : carte des références, pas un registre de
> valeurs (D-253, 2026-08-09).**
>
> Ce fichier ne contient **aucun numéro de version**, et c'est délibéré. Un
> numéro recopié ici serait une **seconde copie** à tenir à jour — c'est
> exactement ce qui a produit D-250 : cinq packs publiés, un catalogue web
> resté en arrière, et ce registre encore à `0.1.0`. Trois endroits, trois
> états, aucun ne le signalant.
>
> **Une information, un lieu.** Ce document dit **où** chaque version vit et
> **comment** la propager. Pour LIRE les valeurs courantes :
>
> ```
> npm run versions
> ```
>
> La garde `verifier:references` (dans `npm run verifier` et en CI) échoue si
> un numéro de version réapparaît dans ce fichier.

## 1. Version du produit (application)

| Quoi | Où elle vit — source unique |
|---|---|
| **Movenso (app)** | `package.json` → injectée au build (`__APP_VERSION__`, `src/app/version.ts`) → affichée dans **Plus › À propos**. |

Convention : versionnage **sémantique 0.x** pour la phase pré-1.0. `-rc.N`
pour une release candidate. Le tag « bêta » (canal, pas version) reste un
propos éditorial du site public.

## 2. Versions des packs de contenu

Chaque pack porte sa **propre** version, indépendante de l'app.

| Quoi | Où elle vit — source unique |
|---|---|
| **Tous les packs publiés** | `publication/packs.json` (dépôt `movenso`) — la déclaration **amont**. `tools/publier.ts` en dérive le catalogue, recalculé depuis la **relecture** des conteneurs (D-264). |
| Copie publiée (dérivée) | `movenso-public/packs/index.json` — le **catalogue unique** en ligne, lu par la page web (`packs.html`) ET par l'écran « Packs officiels » de l'app (D-252). Déposé par `deposer`, jamais édité à la main. |

Convention pack : démarrage à **`0.1.0`**. On incrémente à chaque évolution du
contenu (patch = corrections, mineur = ajouts notables).

L'**histoire** d'un pack (ce qu'apporte chaque version, et pourquoi) vit dans
[DECISIONS.md](execution/DECISIONS.md), pas ici : un journal raconte, une
référence ne fait que dire la valeur courante.

## 3. Versions de FORMAT interne (⚠ ne sont PAS des versions produit)

Ces entiers pilotent la **compatibilité et les migrations** ; ils ne suivent
pas le versionnage 0.x et **ne doivent pas être renumérotés** à la légère
(les renuméroter casserait la chaîne de migrations et ferait rejeter les packs
existants).

| Format | Où il vit — source unique |
|---|---|
| Schéma de données | `src/domaine/modele.ts` (`VERSION_SCHEMA`) |
| Conteneur `.movpack` | `src/echange/movpack-contrat.ts` (`VERSION_MOVPACK`) |

L'outillage ne mémorise pas ces adresses : il les lit dans
`outils/lire-constantes.mjs` (`ADRESSES`), et `verifier:references` refuse que
cette table-ci les contredise (D-285/D-286) — une constante qui déménage casse
ses lecteurs, elle ne les fait plus mentir.

Ils ne sont plus affichés dans l'écran « À propos » (bruit pour l'utilisateur) ;
ils restent visibles dans **Plus › Diagnostic** pour le débogage.

## 4. Process d'évolution (propager PARTOUT, publication comprise)

Quand une version change, mettre à jour **dans le même lot** :

**App (`0.x`)** :
1. `package.json` (`version`) — l'À propos suit automatiquement.
2. Publier par la chaîne (ci-dessous) — l'app en ligne suit le dépôt, jamais
   une copie manuelle.
3. `docs/execution/STATE.md` (présent) + journal des décisions si arbitrage.

**Pack (`0.x`)** :
1. Contenu dans `donnees/<pack>.json`, version dans `publication/packs.json`.
2. Publier par la chaîne (ci-dessous) — le catalogue en ligne est **dérivé**,
   jamais édité à la main.
3. Journal des décisions (ce qu'apporte la version).

**La chaîne, dans l'ordre (D-281)** : `npm run publier` (PRODUIRE, dans
`dist-publication/`) → `npm run verifier:release` (VALIDER, `verifier` complet
compris) → le porteur AUTORISE → `npm run deposer -- --vers <site>` (DÉPOSER :
app + packs + source **ensemble**, garde du site rejouée après). Le commit et
la poussée du dépôt public restent des gestes humains.

**Format interne (rare, structurant)** : uniquement via une **migration**
(`migrations.ts`) + entrée au journal des décisions ; jamais un simple
changement de numéro.

Règle : un numéro de version a **un seul lieu d'écriture**. La publication
(`movenso-public`) fait partie de la propagation, pas d'une étape séparée
oubliable.

**Publication officielle (RC et releases — S1.1, D-162)** : seul un
**artefact CI** est publiable — le workflow `ci` publie `movenso-web-<sha>`
(le `dist/` contrôlé par `verifier:dist` + ses empreintes `SHA256SUMS`) ;
jamais un build local. En phase bêta, le redéploiement de
`movenso-public/app/` depuis un build local reste toléré **à condition**
que le commit soit poussé et que la CI soit verte sur ce commit — à la
première RC, cette tolérance disparaît.
