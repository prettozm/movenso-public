# STATE — tableau de bord de reprise

> **Type : vivant** · Ce fichier ne contient **que le présent**. Aucun
> historique : il vit dans Git, dans [DECISIONS.md](DECISIONS.md) et dans les
> fiches de [`lots/`](lots/). Un STATE qui raconte est un STATE qu'on ne lit
> plus (D-275).
>
> Le **commit** et la **branche** ne sont pas écrits ici, volontairement : ils
> seraient périmés par le commit même qui les écrit. `git log -1` fait foi.

## PHASE

**STABILISATION V1 → B4 (RC).** Référence : l'audit externe
[`audit-stabilisation-v1.md`](audit-stabilisation-v1.md), loti dans
[`lots/`](lots/). Lots S1, S2 et S4 clos ; S3 clos hors reliquats ci-dessous.

## BOUCLE COURANTE

**Correctifs de recette REC-B4-001 : série TERMINÉE** (D-291 → D-298) et
**R2-1 : TERMINÉE** (D-299 → D-302). **Finition éditoriale des six packs
INTÉGRÉE** (D-306, fournitures porteur, go du 2026-08-12) : sources
`donnees/` régénérées depuis les conteneurs (S4.8), preuve d'équivalence
`publier` ↔ fournitures, +10 couvertures de familles judo embarquées,
26 autres au parc sans embarquement (D-245) — republication en cours,
voir « En ligne ».

**PR** : `movenso` #6 et `movenso-public` #6 **fusionnées par le porteur**
(2026-08-12) — plus aucune PR ouverte.

**Relectures checker : DEUX verdicts, tous deux TRAITÉS** (D-303, D-304)
— `f4a467b..87071a0` puis le diff des correctifs (`851119a..e06aea4`,
preuves rouge→vert remesurées par le checker). Le résidu du second
verdict (branche v3 du lecteur flux) est corrigé, rouge→vert (D-304).
Relèvements de cliquet **confirmés par le porteur** (D-305).
**Reste** : les relectures du micro-diff D-304 (base `e06aea4`) et des
boucles D-307/D-308 (`validation.ts` touché, base `239dcf4`).

## GEL

**LEVÉ le 2026-08-13** (D-307, décision porteur : des corrections UX
arrivent). Les corrections UX des parcours existants sont recevables ;
une fonction nouvelle reste soumise au lot courant.

## P0

Aucun.

## P1

- **`REC-B4-001` : socle DÉROULÉ, bloc compositions suspendu** (2026-08-11,
  build `f8c51d6`). Verts : préambule, R0, R3, R4, R5, R6, R6bis, R7 hors
  compositions — résultats et constats dans la fiche. **Neuf entrées en file
  post-recette** (R3-1, R5-1, R6bis-1→4, R7-1, dossier bandeau ×2 —
  la scission Stockage/Sauvegardes est FAITE, D-308). **Reste** : R1/R2/R2bis + trame R4 +
  séance minutée R7, suspendus à l'arbitrage « recetter tel quel ou faire
  évoluer les compositions d'abord » (le porteur penche pour l'évolution).
- **Keystore de publication** : le perdre, c'est perdre définitivement la mise
  à jour de l'app sur Play. Aucune procédure de sauvegarde écrite.

## RESTE À FAIRE

Tout ce qui n'est pas fait — chemin critique v1, décisions humaines
attendues, chantiers post-v1, dette acceptée — vit dans
**[RESTE.md](RESTE.md)** : une ligne par chantier, chacune citant sa source
(D-288). Un chantier clos **sort** du fichier dans le commit qui le clôt —
le journal est la liste du terminé, pas une seconde liste ici. Seuls les
**P0/P1** restent dans ce tableau de bord.

## DERNIÈRE PREUVE

- `npm run verifier` : **vert** — il annonce lui-même ses compteurs.
- CI : **verte** depuis D-270 (elle était rouge six commits durant sans que le
  vérificateur local le voie — lire le run, pas seulement le local).
- **En ligne** : `movenso-public` @ `c437abe` — app build `a93b98c`
  (schéma 6, movpack v5, feuilles de mise à jour D-307), six packs D-306
  (judo 0.7.4, karaté 0.3.2, jujitsu 0.3.3, jjb 0.2.4, taïso 0.2.4,
  yoga 0.4.3) et source dans le même commit, garde du site verte après
  dépôt — verdict Pages à confirmer (contrôle armé).

## PROCHAINE ACTION EXACTE

Dérouler **`REC-B4-001` sur appareil**, en commençant par **R0**. Rien d'autre
n'est engagé côté code tant que la recette n'a pas parlé.

## FAITS GÉNÉRÉS

> Écrits par `npm run etat`, jamais à la main. `npm run verifier:etat` refuse
> l'écart (D-275) — ces nombres ont menti trop souvent (D-273).

<!-- FAITS:DÉBUT -->
Application : 0.9.0-rc.1
Schéma : 6
Movpack : 5
Tests : 276
Chapitres e2e : 24
Sources de packs : 6/6
Publication : dist-publication/
Fichiers TS (src/) : 64
racine.ts : 1548 lignes
movpack.ts : 666 lignes
<!-- FAITS:FIN -->

## PROCÉDURE DE REPRISE

1. **Git** : vérifier branche, commit, état. Dans `movenso`, **toujours une
   branche, jamais `main`, jamais de fusion**. Dans `movenso-public`, la
   publication directe sur `main` est permise sous conditions — « Deux dépôts,
   deux régimes » dans `CLAUDE.md` (D-267). Si une consigne de démarrage nomme
   la même branche pour les deux dépôts, le **signaler**.
2. **Lire** : ce fichier, [MASTER.md](MASTER.md), le lot courant dans
   [`lots/`](lots/), les sections concernées de [QUALITY.md](QUALITY.md). Du
   journal [DECISIONS.md](DECISIONS.md), **seulement** les décisions désignées
   par ce fichier et par le lot courant — plus la queue si le contexte récent
   manque (D-276). Le lire en entier fait remonter des raisonnements périmés.
3. **Vérifier** : `npm run verifier` (~2 min, tient dans un appel au premier
   plan — ne pas le lancer en tâche de fond pour l'attendre en boucle, D-237).
   Un chapitre seul : `npm run e2e:chapitre <nom>` (~4 s). Charge :
   `npm run campagne:charge`.
4. **Lire le run CI**, pas seulement le vérificateur local (D-270) : ils ne
   couvrent pas la même chose.
5. **Publier** : quatre conditions cumulatives (D-267) — commit `movenso`
   poussé, `npm run verifier` vert sur ce commit, `verifier-catalogues.mjs`
   vert **après** dépôt, et **app + packs + source dans le même commit**. Un
   `git push` n'est pas une publication : vérifier que Pages conclut `success`.
6. **Trois niveaux de vérification** (D-281) : `verifier:rapide` (~13 s, pour
   itérer — il dit ce qu'il ne regarde pas), `verifier` (~2 min, pour clore une
   boucle), `verifier:release` (avant de distribuer).
7. **Publier n'est pas déposer** : `npm run publier` produit dans
   `dist-publication/` et n'écrit nulle part ailleurs ; `npm run verifier:release`
   valide ; `npm run deposer -- --vers <site>` est le seul geste qui écrit dans
   le dépôt public. Contrôler un conteneur reçu : `tools/inspecter-movpack.ts`. Avant d'intégrer un pack
   fourni, TOUJOURS le comparer au publié — c'est ainsi qu'on a vu le karaté
   perdre ses 109 images (D-245) et l'identité du jujitsu dériver (D-247).
8. **Avant de committer** : `npm run etat` si un fait a bougé.
