# Lot S4 — Audit externe du 2026-08-09, arbitré point par point

> **Type : vivant** · Ouvert le 2026-08-09 (D-255/D-256). Source :
> l'audit externe du 2026-08-09, **qualifié dans le code avant tout arbitrage**
> (15 points sur 17 vérifiés, 2 déjà fermés le jour même par D-250/D-252).
> Le présent d'exécution vit dans [STATE.md](../STATE.md) ; le pourquoi de
> chaque arbitrage dans [DECISIONS.md](../DECISIONS.md).

## Ce que l'audit valait, mesuré

L'audit portait sur un instantané **antérieur** à la session du 2026-08-09
(dépôt encore nommé `movenso-v3`, catalogue web encore divergent). Son
`npm ci` avait échoué sur `zod@4.4.3` — dépendance **transitive de knip**,
absente de notre `package.json` : limite de son environnement, pas du dépôt.

Tout ce qu'il affirme a été **rejoué ici**. Rien n'a été pris pour argent
comptant, et deux de ses formulations ont été corrigées (voir D-256) :

- le contournement du manifeste v4 ne porte **que sur les médias** — le
  `bibliotheque.json` reste protégé par l'empreinte globale (mesuré : une
  fausse empreinte est refusée) ;
- `partagerComposition` charge bien tout en RAM, mais `exporterComposition`
  (téléchargement) **passe déjà par le flux** : seul le partage NATIF est en
  cause.

## Ordre acté

Intégrité d'abord (1, 2), puis le format v5 qu'elle rend sûr d'introduire,
puis la promesse produit, puis la publication. **Le v5 reste AVANT la v1** :
une migration de format coûte le moins cher maintenant, en bêta, avec une
population minuscule — c'est le raisonnement de D-247, appliqué au format.

| # | Chantier | État |
|---|---|---|
| 1 | Validation exhaustive des champs optionnels | ✅ **CLOS** (D-255) |
| 2 | Contrat de manifeste strict v3/v4 | ✅ **CLOS** (D-263) |
| 2bis | Boucle A ✅ **CLOS** (D-266) — schéma 5, la famille porte l'image · **Boucle B** (images en fichiers du ZIP) | reste à faire |
| 3 | Vignettes distantes : rien ne part sans geste | ✅ **CLOS** (D-260) |
| 4 | Restauration par le chemin transactionnel | ✅ **CLOS** (D-258) |
| 5 | Partage natif en flux | ✅ **CLOS** (D-262) |
| 6 | Licence `conditions` dans le conteneur | ✅ **CLOS** (D-264) |
| 7 | Conformité GPL : source publiée par release | ✅ **CLOS** (D-265) |
| 8 | Pack Yoga reproductible | ✅ **CLOS** (D-264) |
| 9 | Chaîne de publication depuis une source unique | ✅ **CLOS** (D-264) |
| 10 | Mentions, contact, confidentialité | ✅ **CLOS** (D-260) |
| 11 | Compatibilité navigateur ✅ (D-261) · bandeau de persistance | partiel — bandeau en session dédiée |
| 12 | CSP du site vitrine | ✅ **CLOS** (D-261) |
| 13 | Épinglage des Actions par SHA | ✅ **CLOS** (D-265) — 11 usages épinglés + garde |

## Détail des chantiers non clos

### 2 — Contrat de manifeste strict v3/v4

✅ **CLOS (D-263).** Une fonction `contratIntegrite` unique, consultée par les
DEUX lecteurs (mémoire et flux). À partir de v4 l'inventaire est obligatoire,
chaque entrée est validée et un algorithme inconnu est refusé plutôt que
supposé. Le repli n'est pas supprimé mais **réservé à v3**, où il exige une
empreinte globale bien formée ; un v3 qui apporte un inventaire est honoré.

Preuves : 7 tests unitaires (le conteneur qui passait est refusé, v3 reste
lisible), et les **six packs publiés** repassés par `lireMovpackFlux` — le
chemin d'import réel — tous acceptés. **La condition posée pour ouvrir le
movpack v5 est levée.**

### 2bis — movpack v5 : les images sortent du JSON

Deux décisions en une, mesurées avant d'être prises :

1. **Les images deviennent de vrais fichiers du ZIP**, comme les vidéos —
   intégrité par fichier, déduplication naturelle, fin de l'inflation base64
   (+33 %).
2. **La vignette est celle de la technique, sinon celle de sa FAMILLE** —
   la famille porte la couverture, la technique la dérive. C'est l'inverse de
   D-244, qui recopiait l'image de famille sur chaque technique.

Gain mesuré sur les packs publiés :

| pack | techniques | couvertures | images **distinctes** | base64 stocké | dont unique |
|---|---:|---:|---:|---:|---:|
| Jujitsu | 162 | 162 | **16** | 4,25 Mo | 0,42 Mo |
| JJB | 150 | 150 | **12** | 4,50 Mo | 0,36 Mo |
| Karaté | 109 | 109 | 109 | 4,78 Mo | 4,78 Mo |
| Taïso | 114 | 114 | 114 | 2,69 Mo | 2,69 Mo |
| Yoga | 72 | 72 | 72 | 3,10 Mo | 3,10 Mo |

Autrement dit : gain massif sur Jujitsu et JJB (images de famille recopiées),
**nul** sur Karaté, Taïso et Yoga, qui ont déjà une image par technique. Le
poids du fichier ZIP bouge peu (deflate absorbait déjà la répétition) — ce
qu'on récupère, c'est le **stockage OPFS et la mémoire** de l'utilisateur.

C'est le chantier le plus risqué de la liste : le seul qui **migre les
données déjà installées**. Il exige sa propre recette et un aller-retour
prouvé (installation existante → migration → bibliothèque identique).

### Découpage revu (2026-08-09) — le gain ne vient PAS du format

En préparant le plan, un constat change l'ordre des choses : **la totalité du
gain mesuré vient du MODÈLE, pas du conteneur.** Si la famille porte la
couverture et que la technique la dérive, le `bibliotheque.json` du jujitsu ne
contient plus 162 images mais 16 — 4,25 Mo → 0,42 Mo — **sans toucher au
format `.movpack`**. Sortir les images en fichiers du ZIP n'apporte, en plus,
que la fin de l'inflation base64 (+33 %) et l'intégrité par fichier.

D'où deux boucles au lieu d'une, la première portant tout le bénéfice :

**Boucle A — schéma 5 : la famille porte la couverture.**
`Famille.couverture` naît ; `Technique.couverture` reste et **prime toujours** ;
l'affichage dérive la vignette (technique → famille → initiale). Migration 4→5
des bibliothèques installées : une image partagée par plusieurs techniques
d'une même famille **remonte** sur la famille et disparaît des techniques ;
une image unique à une technique **ne bouge pas**. Le conteneur reste **v4** :
aucun changement de format, donc aucun risque de rejet par une app plus
ancienne. Preuves : migration idempotente, aller-retour prouvé sur les six
packs publiés, et l'affichage vérifié en e2e (une technique sans image propre
montre celle de sa famille).

**Boucle B — movpack v5 : les images deviennent des fichiers du ZIP.**
Intégrité par fichier, plus d'inflation base64. Se fait APRÈS la boucle A, sur
un modèle déjà dédupliqué — donc sur 16 images à déplacer, pas 162.

> ⚠️ **La justification de la boucle B était fausse, et la mesure l'a dit
> (D-268).** « Plus d'inflation base64 » est vrai du TEXTE et faux du
> CONTENEUR : un `.movpack` est un ZIP, et deflate récupère déjà presque toute
> l'inflation. Mesuré par `tools/peser-images.mjs` sur les six packs publiés,
> le conteneur v5 ne gagne que **1 à 3 %** (karaté : 3814 → 3704 Ko). Le gain
> réel est ailleurs — dans `bibliotheque.json`, que le stockage réécrit en
> trois passes à chaque sauvegarde. Voir D-268 pour l'arbitrage.

Cette découpe annule l'objection principale : la boucle A ne casse aucun
format public, et la boucle B ne migre plus de données (le modèle l'a déjà
été). Le risque se concentre sur une seule migration, testable hors ligne sur
les six packs réels.

### 3 — Vignettes distantes (arbitré)

**Aucune requête vers `img.youtube.com` tant que l'utilisateur n'a rien
demandé.** Un réglage « vignettes distantes » vit dans **Réglages avancés**
(et non dans Apparence : ce n'est pas une question de présentation mais de
trafic sortant), **désactivé par défaut**. Preuve : e2e vérifiant qu'aucune
requête ne part au chargement d'une bibliothèque Judo tant que le réglage
est off.

### 4 — Restauration par le chemin transactionnel

✅ **CLOS (D-258).** `restaurerSauvegarde` écrivait **directement** dans
`bibliotheque.json`, sans la bascule tmp → relecture → revalidation ni la
file de sérialisation : le **seul** chemin d'écriture de la bibliothèque sans
protection, et il s'exerce quand l'utilisateur récupère d'un problème.
Correctif d'une ligne (la restauration appelle `sauvegarder`).

**Preuve : une garde, pas un test de course.** Une preuve par entrelacement
aurait dépendu de la vitesse relative de deux chaînes asynchrones — le test
instable que D-249 a appris à ne pas fabriquer. `verifier-sources` refuse
désormais toute écriture directe de `bibliotheque.json` hors de
`sauvegarder`, la ligne légitime (la bascule) étant nommée dans le code.
Vérifiée dans les deux sens.

### 5 — Partage natif en flux

✅ **CLOS (D-262).** Les deux passent par `exporterEnFlux(..., false)` et
héritent du refus d'espace, du voile à progression, de l'annulation et de la
trace au diagnostic. **Témoin déterministe trouvé** : l'export en flux se
déclare comme opération longue, ce que le chemin en mémoire ne faisait
jamais — le chapitre `defusion-doublons` partage désormais **en gardant la
vidéo** (le cas coûteux, jusqu'ici jamais joué) et vérifie cette déclaration
plus la taille réelle de l'archive. La recette appareil reste requise pour
le partage natif lui-même.

### 6 — Licence dans le conteneur

`conditions: "CC BY-NC-SA 4.0"` dans l'emballage : le champ est **déjà
supporté** par le format, rien à changer au schéma. Republication des six
packs, `versionEditoriale` +1, simulation de mise à jour sans doublon.

### 7 — Conformité GPL (arbitré)

La **GPLv3 est conservée** pour le code. Voie retenue : **(b)** — la source
correspondant à chaque build publié est déposée dans `movenso-public` et
reliée au commit affiché dans **Plus › À propos**. Le dépôt de travail reste
privé.

Rappel utile, qui lève une inquiétude exprimée : la GPL couvre le **code**,
pas la **marque**. Vendre des écussons ou des vêtements Movenso est hors de
son champ — les mentions du site le disent déjà. Le point à surveiller est
ailleurs : les packs sont en **CC BY-NC-SA (non commercial)**, donc une
contribution de pack venue d'un tiers ne sera pas commercialisable sans son
accord. Si le contenu doit un jour être commercialisé, le levier est un
accord de contribution, pas la licence du code.

### 8 — Pack Yoga

Le fichier fourni par le porteur est **au bit près celui qui est publié**
(même SHA-256) : il n'existe pas de source plus fraîche. La source sera donc
**reconstruite depuis le conteneur** — 72 techniques, 8 familles, 3 niveaux,
12 compositions, 0 relation, 72 images distinctes — et republiée en schéma 4,
identité épinglée. Dit franchement : c'est une source **dérivée d'un
binaire**, pas l'originale. Le porteur enrichira ensuite en relations et
compositions.

### 9 — Chaîne de publication depuis une source unique

Prolongement direct de D-252/D-253 : un `publication/packs.json` porte id,
source, SemVer, `versionEditoriale`, auteur, licence, statut, résumé ; un
script de release construit, inspecte, **calcule les compteurs depuis le
fichier construit** (plus aucun compteur saisi à la main), génère
`packs/index.json` et refuse de publier en cas d'incohérence.

### 11 — Compatibilité et persistance (arbitré)

**Le site cesse de nommer des navigateurs et des versions.** L'app teste déjà
les capacités au démarrage et affiche un verdict honnête ; le site décrit
l'exigence et renvoie à ce verdict. C'est la contradiction ET la duplication
supprimées d'un coup (règle D-253).

APIs réellement exigées, mesurées : `getDirectory`, `getFileHandle`,
`createWritable`, `removeEntry`, `navigator.storage.persist/estimate`.
`createSyncAccessHandle` **n'est pas utilisé**.

**Bandeau de persistance — spécifié par le porteur (2026-08-09, D-257)**

| État | Bandeau |
|---|---|
| `refusee` | **rouge** — le navigateur peut évincer les données |
| `inconnue` | **jaune**, ton informatif — l'état est indécidable, pas anormal |
| `accordee` | aucun |
| `native` (APK) | **aucun, jamais** — le bac à sable de l'app ne s'évince pas |

Il est **actionnable** (le même `redemanderPersistance` que la carte Espace),
**refermable**, et **dérive de l'état existant** `app.persistanceStockage` :
même information, un seul lieu.

Précaution à tenir sur « inconnue » : c'est l'état **normal** sur certains
navigateurs, pas une anomalie — un bandeau alarmant y deviendrait permanent,
donc du papier peint. Le ton dit l'incertitude, il n'accuse pas.

**Fermeture consignée** : refermer le bandeau est une information de
diagnostic (elle explique un « je n'ai pas été prévenu »), donc l'événement
est journalisé — voir le journal d'actions ci-dessous.

**Le bandeau pousse vers DEUX actions, pas une** (D-259) : demander la
persistance **et** faire une sauvegarde. « Inconnue » ne veut pas dire « ça
marche » mais « aucune garantie » : les données s'écrivent et se relisent
normalement, en régime *best-effort* — le navigateur peut les évincer sous
pression de stockage, et certains moteurs après une longue inactivité. Ça
marche jusqu'au jour où ça ne marche plus, sans prévenir. Le vrai filet de
sécurité n'est donc pas le bandeau, c'est la sauvegarde, qui existe déjà.

**Emplacement de secours** — ÉTUDE, pas un go. Choisir un autre emplacement
de stockage selon l'appareil, c'est l'option 2/3 de D-167, repoussée post-v1
à l'époque. Elle engage le stockage Android (SAF, permissions), la
**migration des données déjà écrites** et le comportement des sauvegardes :
un chantier à part entière, à instruire avant tout engagement.

**Emplacement affiché au diagnostic** — sur navigateur, l'OPFS **n'a aucun
chemin visible**. On rapporte la NATURE du stockage (bac à sable OPFS de
l'origine, ou `Documents/Movenso` en natif) et, quand un chemin réel existe,
**le segment utilisateur est anonymisé** (`…/<utilisateur>/…`, arbitrage
porteur D-259) : lisible pour diagnostiquer, sans porter le nom de personne.
La garde de non-divulgation interdit déjà `/home/`, à raison.

**Dossier local « en dur » — pourquoi ce ne peut pas être le défaut**
(D-259). Écrire dans un répertoire choisi par l'utilisateur exige l'API de
sélection de répertoire : présente sur **Chromium desktop**, **absente de
Firefox** et des navigateurs mobiles. En faire le chemin par défaut
donnerait la sécurité aux seuls utilisateurs Chrome et laisserait les autres
dans le doute — l'inverse du but. Retenu : **option** sur Chromium desktop et
sur l'APK (où `Documents/Movenso` est un vrai dossier) ; pour tous les
autres, la **sauvegarde** reste la réponse.

**Fichiers visibles depuis l'extérieur** (D-259). Dès qu'on écrit hors du bac
à sable, les fichiers deviennent visibles depuis le gestionnaire de fichiers,
et sur Android peuvent être **indexés par le scanner média** (galeries,
applis de nettoyage). Parade : déposer un `.nomedia` dans le dossier. Elle ne
suffit pas à promettre l'invisibilité — certaines applications passent
outre —, donc le texte le **dit** au lieu de promettre.

**Complément de recette (R0, 2026-08-11)** — le cas s'est présenté sur
appareil : Opera Android affiche « persistance non garantie », visible
**seulement** dans Plus › Stockage — l'utilisateur qui n'y va pas ne le
saura jamais. Le porteur confirme le besoin du bandeau et y ajoute une
**orientation par plateforme** : sur Android, proposer l'APK ; sur PC,
orienter vers Chrome/Chromium ; macOS/iOS à définir (Safari a son propre
régime d'éviction). À intégrer à la session dédiée — l'orientation est un
TEXTE du bandeau, pas une détection de plus que ce que `navigator` sait
déjà dire.

### 11bis — Journal des dernières actions au diagnostic (arbitrage requis)

Demande du porteur : que le diagnostic porte les **X dernières actions** de
l'utilisateur, en signalant celles ayant produit un snapshot.

**Tension à trancher avant d'écrire.** Le diagnostic tient sa promesse par
CONSTRUCTION et non par filtrage : `construireDiagnostic` reçoit un type
d'entrée qui **ne peut pas porter** un nom de technique ou de composition —
le test s'appelle « le type d'entrée ne PEUT pas porter un secret ». C'est ce
qui rend crédible sa phrase finale (« aucun nom de technique ou de
composition, aucun contenu de média »). Or le diagnostic est fait pour être
**envoyé à quelqu'un**.

**Proposition** : le journal enregistre le **type** d'action et jamais son
objet — `import-pack`, `suppression-media`, `restauration`, `export`, avec
horodatage, résultat, et motif du snapshot quand il y en a un. La chronologie
utile au diagnostic est conservée (« importé, puis restauré, puis
supprimé »), le type d'entrée reste structurellement incapable de fuiter, et
une garde échoue si un libellé s'y glisse.

**ARBITRÉ (porteur, 2026-08-09)** : aucun libellé, **mais les identifiants
oui** — sans eux on ne peut pas savoir si deux lignes parlent du même objet,
et le journal perd l'essentiel de son pouvoir de diagnostic. Un ULID est
opaque : il ne dit rien du contenu, et la garantie tient toujours par le
TYPE. Forme retenue :

```
{ quand: ISO, action: TypeAction, cible?: ULID, resultat: "ok" | "refus" | "echec",
  snapshot?: MotifSnapshot }
```

`TypeAction` et `MotifSnapshot` sont des **énumérations fermées** ; `cible`
n'accepte qu'un ULID. Aucun champ de texte libre n'existe dans le type —
c'est ce qui rend l'impossibilité structurelle et non déclarative. Garde à
écrire : le journal refuse toute valeur hors énumération et tout `cible` qui
n'est pas un ULID.

### 13 — Secrets et épinglage (arbitré)

**Aucun secret de signature n'entrera dans GitHub.** L'APK de publication
sera signé **en local** (poste fixe, WSL) ; la CI ne produit que des APK de
test à signature éphémère. Conséquences à tenir :

- **la perte du keystore est irréversible** — sans lui, plus aucune mise à
  jour Play sous la même identité. Sauvegarde hors du poste, chiffrée, jamais
  dans git : à écrire comme une procédure, pas comme une note ;
- un APK signé en local n'est plus tracé par la CI : le **commit exact** de
  chaque build publié doit être noté (l'app affiche son SHA, c'est faisable) ;
- l'épinglage des Actions par SHA retombe en **P3** : sans secret, il ne
  protège plus que le jeton du dépôt. Optionnel.

## Hors périmètre v1 (acté)

- **Registre des packs installés**, câblé au diagnostic — c'est ce qui rendra
  diagnosticable un défaut comme D-222.
- **`racine.ts` découpé par famille d'actions** : l'état réactif reste dans la
  coquille, les actions partent en services, l'e2e sert de garde à chaque
  tranche.
- **PWA : abandonnée** (décision porteur, 2026-08-09) — l'APK couvre Android,
  iOS est hors support, et l'installation sur ordinateur relève de la question
  « version portable », à rouvrir séparément après la v1.
- **Version portable** (ZIP à navigateur embarqué) : rouverte seulement si
  elle est demandée. Le fond du choix est dit dans D-256.
