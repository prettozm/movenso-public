# DOSSIER — Compositions / séances (session dédiée réservée)

> **Type : vivant** · Dossier d'INSTRUCTION (patron S1-10) : rien ne se code
> tant que la session dédiée n'est pas ouverte par le porteur, et le gel
> D-240 tient. Ce dossier consolide : les maquettes fournies le 2026-08-11,
> les arbitrages du porteur (D-290), la proposition d'évolution qui les
> accompagne, et la **confrontation au modèle réel** (vérifiée dans le code,
> D-251 — jamais de mémoire).

## Le problème, tel que le porteur le formule

Le moteur Composition couvre déjà quasiment tous les usages (enchaînement,
Tori/Uke, kata, séance minutée, circuit, multi-rôles, simultanéité, lecture
guidée, voix/bips). Le défaut n'est pas la puissance, c'est son
**accessibilité** pour un non-initié. Principe directeur retenu :

> *ne pas ajouter de concepts métier là où les capacités existent déjà ;
> ajouter des niveaux d'UX qui rendent ces capacités évidentes.*

## Arbitrages posés (D-290)

1. **« Partager » = export/import `.movpack`** — le mot « inviter » est
   banni (pas de compte, pas de collaboration temps réel). Dire « pratiquer
   à plusieurs » ou « partager la composition ».
2. **Assistant de création 100 % local et déterministe** : des choix fermés
   qui préconfigurent le moteur existant. Jamais un second moteur, jamais
   d'IA.
3. **Navigation hors périmètre** : Favoris/Relations restent où ils sont.
   Les maquettes qui montrent une barre refondue ne font pas foi sur ce
   point.
4. **Un seul système de rôles** : Tori/Uke sont des **noms proposés par
   défaut** selon le contexte, strictement le même mécanisme que Toto/Tata.
5. **Simultanéité conservée** (`lien` = rejoint le temps précédent, D-235) ;
   le vocabulaire UX devient « En même temps que l'étape précédente ».
6. **Planification dans la cible ; notifications = chantier plateforme
   séparé** (Android, permissions, arrière-plan, PWA — rien de tout ça ici).

## Confrontation au modèle réel (vérifiée dans le code)

### Existe déjà, tel quel — l'écart est purement d'exposition

- **Blocs** : 9 types (`technique`, `etape` libre, `transition`, `consigne`,
  `objectif`, `duree`, `media`, `repere`, `pause`) — les trois des maquettes
  y sont, plus six (`modele.ts`, TYPES_BLOC).
- **Rôles** : `Acteur[]` nommés librement sur la composition (D-227),
  `acteurId` par bloc, absent = neutre/« les deux ». Exactement le modèle
  que l'arbitrage n° 4 demande.
- **Simultanéité** : `Bloc.lien` — « rejoint le temps du pas précédent »
  (D-235), avec lecture des valeurs héritées D-229. La bascule des maquettes
  existe ; seul le libellé change.
- **Durée facultative** : `dureeSec?` par bloc ; total de séance dérivé
  (somme des durées présentes, D-124).
- **Entonnoir de création** : `type` enchaînement / séance / kata choisi à
  la création (D-126), funnel existant (`ouvrirCreationCompo`,
  `creerCompositionFunnel`, `poserRolesFunnel`). L'« assistant » des
  maquettes est une extension de CET entonnoir, pas un objet neuf.
- **Lecteur** : chrono par pas, phase **préparation** (« Préparez-vous »,
  durée réglable, défaut 3 s — `preferences.transitionSec`), **quatre modes
  sonores** (voix + bips / voix / bips / muet), précédent/suivant/quitter,
  résumé de fin, suspension quand l'écran se cache. Le « Prépa 3 s » et le
  « Voix + bips » des maquettes existent déjà, au réglage près.
- **Recherche** : « une composition ou une technique qu'elle contient » +
  chips de discipline déduites du contenu (+ filtre mixte) — mot pour mot
  ce que la maquette dessine.
- **Duplication / partage** : `dupliquerComposition`,
  `exporterComposition`/`partagerComposition` en **pack jouable** — le
  « Partager » de l'arbitrage n° 1 existe.
- **Provenance** : `Composition.origine` (vient d'un pack) → la séparation
  « Mes compositions / Packs » est un **filtre UX** sur une donnée en place.

### N'existe pas — purement UX, aucune donnée nouvelle

- Onglets **Mes compositions / Packs** (filtre sur `origine`).
- **Fiche de consultation** d'une composition de pack (lecture avant
  édition : Démarrer / Dupliquer / Planifier) — aujourd'hui on tombe dans
  l'édition.
- **Timeline au centre de l'éditeur**, ajout d'étape progressif en
  bottom-sheet (type → puis seulement qui agit / durée / en même temps),
  réorganisation par glisser (primitive `glisser.ts` à évaluer).
- **Tri** (Récent) et hiérarchie de liste.
- Lecteur : **aperçu de l'étape suivante avec son rôle** (les données sont
  déjà dans les blocs).

### Données réellement nouvelles (le SEUL ajout métier : la planification)

- **Planification** : `{ compositionId, date, heure?, (rappel plus tard) }`
  — pas d'objet « Séance » (redondant, tranché par la proposition §9). Une
  composition planifiable N fois sans duplication. Impact : nouvelle
  collection persistée → **bump de schéma + migration additive** (triviale,
  mais c'est une migration — critère D-251 : qui l'écrit, où elle voyage).
- **Curseur de reprise** (« Continuer — dernière lecture il y a 2 j »,
  position 2/6) : l'état de séance actuel est en mémoire, non persisté. À
  qualifier : métadonnée **locale**, auto-écrite, ne s'exporte jamais dans
  un pack.
- **Suggestions de techniques** à l'ajout d'étape : dérivables localement
  (relations, famille, discipline) — un petit moteur, pas de donnée neuve.

### Suggéré par les maquettes et ÉCARTÉ (arbitrages + hors périmètre)

- « Inviter d'autres personnes », comptes, temps réel (n° 1).
- Assistant « générateur » IA ou distant (n° 2).
- Barre de navigation refondue — Favoris/Relations en onglets (n° 3).
- Système Tori/Uke parallèle (n° 4).
- Notifications/rappels système dans CE chantier (n° 6).
- Tags par étape et badge « niveau » : ne pas créer de champs — `consigne`
  et `description` existants les portent si le contenu en a besoin.
- **Undo d'éditeur** (icône des maquettes) : ne pas le promettre — à
  instruire séparément s'il devient nécessaire.

## Ordre d'évolution proposé (proposition §15, confirmé par la confrontation)

- **A — rendre Composition compréhensible** : split Mes/Packs, hiérarchie de
  liste, fiche de consultation pack, duplication (100 % UX).
- **B — simplifier la création** : entrée guidée sur l'entonnoir existant,
  préconfiguration solo/plusieurs (rôles proposés par contexte),
  timeline-centre, ajout d'étape progressif, vocabulaire utilisateur.
- **C — consolider le lecteur** : lisibilité et hiérarchie seulement
  (aperçu du suivant, rôle actif plus net) — le moteur ne bouge pas.
- **D — planification** : modèle minimal, planifier depuis une composition,
  **Liste d'abord**, Calendrier ensuite (même donnée, autre rendu — jamais
  un second stockage).
- **E — rappels** : chantier plateforme indépendant, après que D a servi.

## Questions encore ouvertes (à trancher avant ou pendant la session)

1. La **planification** part-elle dans la **sauvegarde complète** ?
   (probablement oui ; dans un pack : sûrement non). Cycle D-251 à écrire.
2. **Récurrence** (« tous les mardis ») : hors v1 ? La proposition planifie
   N fois à la main — c'est le plus simple, à confirmer.
3. **« Continuer »** : une seule entrée (dernière séance) ou un historique ?
   La v1 la plus simple : une entrée.
4. **Où vit l'Agenda** dans la navigation actuelle (Pratique ? Plus ? une
   vue de l'onglet existant ?) — explicitement laissé à challenger.
5. Les maquettes montrent des **photos par étape** dans les packs : le bloc
   `media` existant couvre-t-il le besoin de contenu, ou est-ce du travail
   éditorial de packs (hors moteur) ?

## Intention utilisateur (D-279) — à écrire par écran, AVANT le code

Chaque boucle d'écran de la session dédiée commencera par ses huit lignes ;
ce dossier n'en dispense aucune. Le verrou humain s'applique : parcours ou
maquette validés avant implémentation pour toute interaction nouvelle
importante (la matière maquette existe déjà — c'est sa force).
