# Recette sur appareil réel

> **Type : vivant** · **Statut : NON VALIDÉ (protocole proposé, D-010)**
> Principe (D-010) : court, centré sur ce que l'humain **fait spontanément**,
> pas sur ce que l'app demande de tester. Chaque constat est classé sur un des
> trois niveaux ci-dessous — ne jamais les confondre dans un compte rendu.

## Les trois niveaux (vocabulaire commun)

| Niveau | Question | Exemple de constat |
|---|---|---|
| **Technique** | Ça marche sur l'appareil ? | « la vidéo OPFS se joue » / « getUserMedia refuse » |
| **Utilisabilité** | Ça se fait sans friction ni explication ? | « j'ai trouvé le rattachement tout seul » / « le clavier cache le champ » |
| **Désirabilité** | Ai-je spontanément envie d'y revenir ? | « je l'ai rouverte le lendemain sans y penser » / « je n'y ai plus pensé de la semaine » |

Le spike ne mesure que le niveau **technique**. L'incrément 1 sera jugé sur
les trois — et c'est le troisième qui décide (D-009).

## Recette 1 — Spike S1/S2 (~5 minutes) — **TERMINÉE, validée (D-011)**

> Exécutée le 2026-07-11 (Samsung SM-A366B, Android 16, WebView 149) : tous
> tests OK, lecture vidéo confirmée image et son. Protocole conservé pour
> mémoire ; le spike ne sert plus.

APK : workflow GitHub `spike-apk` → artefact `movenso-spike-apk` (APK debug :
autoriser l'installation de sources inconnues).

1. Ouvrir l'app : les tests 1-5 se lancent seuls.
2. Test 6 : filmer 3-5 s, regarder la lecture, répondre par le bouton.
3. Test 7 : lancer l'aperçu caméra, accorder la permission si demandée.
4. **Fermer complètement l'app, la rouvrir** : le test 4 (persistance) doit passer à OK.
5. « Copier le rapport » et le coller dans la conversation.

Interprétation (contrat §4) : tests 1-4 et 6 OK → l'architecture « une seule
implémentation OPFS » est confirmée. Test 6 KO → fallback
`@capacitor/filesystem` pour les vidéos. Test 7 KO → la capture passe par la
caméra native (test 6), sans conséquence pour l'incrément 1.

## Recette 2 — la synthèse V2/V3 (Validation 4) — **CAMPAGNE PASSÉE**

> Compte rendu d'une campagne de 2026-07 : ses artefacts ont expiré, et
> l'artefact `packs-demo` qu'elle mentionne **n'existe plus** (D-272 — les
> packs s'installent désormais dans l'app, par « Packs officiels »). La
> recette VIVANTE est `REC-B4-001` dans
> [`execution/QUALITY.md`](execution/QUALITY.md). Conservé tel quel pour ce
> qu'il rapporte, pas pour être rejoué.

**Release candidate** : commit de référence `d3a0579`, run `apk`
[29181115999](https://github.com/prettozm/movenso/actions/runs/29181115999)
→ artefacts `movenso-apk` (APK debug, `fr.prettozm.movenso.v3` — cohabite
avec une V2 installée) et `packs-demo` (kodokan.json + club-judo.json),
disponibles jusqu'au **2026-08-11**. Périmètre fonctionnel **gelé** jusqu'au
retour de recette (D-022) : aucune correction sur les points observés, sauf
anomalie empêchant l'installation ou la recette elle-même.

**Aucun scénario imposé** (D-010) : installer l'app, l'emporter à
l'entraînement pendant 1-2 semaines, l'utiliser — ou pas — comme ça vient.
Le compte rendu tient en trois questions :

1. Qu'as-tu fait spontanément avec ? (et qu'est-ce qui t'a arrêté ?)
2. Qu'est-ce qui a manqué ou agacé ? (utilisabilité)
3. L'as-tu rouverte sans y penser ? Quand, pour quoi ? (désirabilité)

**Checklist technique** (une fois, à l'installation — pas à chaque usage) :

- [ ] Premier lancement : app vide de contenu mais jamais bloquée — les trois
      actions sont là (capturer / importer / créer sa discipline).
- [ ] Importer `kodokan.json` puis `club-judo.json` (artefact `packs-demo` du
      même run, copiés sur le téléphone) : une seule discipline Judo,
      « référentiel + enseignement », fiches à deux voix (ex. Harai-goshi).
- [ ] Recherche « o soto » → fiche ; vidéo en ligne lue après le geste explicite.
- [ ] Capture : filmer → note → rattacher ; la vidéo se rejoue depuis la fiche, hors ligne.
- [ ] Capture « plus tard » → visible « à rattacher » à l'accueil → rattachement en deux touches.
- [ ] Fermer complètement l'app, rouvrir : tout est encore là.
- [ ] Mode avion : consultation, capture et carnet fonctionnent (seules les vidéos en ligne échouent, proprement).
- [ ] Bouton retour Android : ferme la couche du dessus, ne tue pas l'app.
- [ ] Composition : créer « Ma spéciale », ajouter 2 techniques + 1 transition,
      réordonner, consulter ; depuis une fiche → « Utilisée dans ».
- [ ] Atelier : « Exporter tout » produit un `.movpack` ; le réimporter sur
      une installation vierge (autre appareil ou après réinstallation)
      restaure tout — c'est le filet R8, à éprouver une vraie fois.

**Points d'observation annoncés par Yahya (session 17 — ne rien corriger
avant son retour, D-022)** :

1. Comportement du **média principal** quand une identité possède plusieurs voix.
2. Pertinence de réserver le **rattachement différé** aux seules contributions personnelles.
3. Compréhension de la différence **publication d'un pack** / **sauvegarde intégrale**.
4. **Fluidité réelle** de création et d'utilisation d'une composition sur téléphone.
5. La **nouvelle direction graphique** (encre/washi, vermillon — D-021).
6. Usage sur **tablette collective** et sur **téléphone personnel** (deux contextes, un système).

**Complément (D-018)** : faire tester le **premier lancement vide par un œil
neuf** (quelqu'un qui n'a jamais vu Movenso) — comprend-il seul qu'il peut
capturer, importer ou créer sa discipline ?

Tout défaut reproductible devient correction + test/règle durable (mission,
Validation 4). Rappel D-011 : si le terrain contredit un parcours, un libellé
ou un comportement, **le produit s'adapte au terrain**.
