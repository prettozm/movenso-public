/**
 * Campagne GROSSE BIBLIOTHÈQUE (S2.16 / P1.16) — à la demande, hors du
 * parcours e2e (elle génère 2 000 techniques / 10 000 relations et mesure).
 * Prérequis : `npm run build`. Lancement : `node tests-navigateur/campagne-charge.mjs`.
 *
 * Jeu généré (audit P1.16) : 10 disciplines (2 catégories + 3 niveaux
 * chacune), 2 000 techniques, 10 000 relations (5/technique, types par
 * défaut), 500 contributions, 100 compositions de 10 pas. Les médias
 * multi-Go ne sont PAS simulés ici (allocation disque du conteneur) —
 * consigné : à mesurer sur appareil avec la recette porteur.
 *
 * Mesures : génération+persistance, DÉMARRAGE à froid sur le jeu, recherche
 * (première frappe → résultats), ouverture de fiche, explorateur, Mindmap,
 * Explorer, sauvegarde interne, mémoire JS.
 */
import { chromium } from "playwright";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { readFileSync, existsSync } from "node:fs";
import { join, extname } from "node:path";

const DIST = new URL("../dist", import.meta.url).pathname;
const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json" };
const serveur = createServer((req, res) => {
  const fichier = join(DIST, req.url.split("?")[0] === "/" ? "index.html" : req.url.split("?")[0]);
  if (!existsSync(fichier)) { res.statusCode = 404; return res.end("404"); }
  res.setHeader("content-type", MIME[extname(fichier)] ?? "application/octet-stream");
  res.end(readFileSync(fichier));
});
await new Promise((r) => serveur.listen(4521, r));

let navigateur;
try { navigateur = await chromium.launch(); } catch { navigateur = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" }); }
const erreurs = [];
const mesures = {};

const ctx = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
const page = await ctx.newPage();
page.on("pageerror", (e) => erreurs.push("pageerror: " + e.message));
page.on("console", (m) => { if (m.type() === "error" && !(m.location()?.url ?? "").includes("img.youtube.com")) erreurs.push("console: " + m.text()); });

await page.goto("http://127.0.0.1:4521/");
await page.waitForSelector(".action-douce");

/* ---- génération + persistance ---- */
{
  const t0 = Date.now();
  await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const b = app.bibliotheque;
    // ULID synthétique VALIDE (Crockford, 26 car.) — compteur encodé, zéro collision.
    const A = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
    let n = 0;
    const ulid = () => {
      let v = ++n, s = "";
      while (v > 0) { s = A[v % 32] + s; v = Math.floor(v / 32); }
      return s.padStart(26, "0");
    };
    const quand = "2026-08-02T12:00:00.000Z";
    for (let d = 0; d < 10; d++) {
      const familles = [{ id: ulid(), nom: `Famille ${d}A`, ordre: 1 }, { id: ulid(), nom: `Famille ${d}B`, ordre: 2 }];
      const niveaux = [1, 2, 3].map((k) => ({ id: ulid(), nom: `Niveau ${d}-${k}`, ordre: k }));
      b.disciplines.push({ id: ulid(), nom: `Discipline ${d + 1}`, familles, niveaux });
    }
    const techIds = [];
    for (let i = 0; i < 2000; i++) {
      const disc = b.disciplines[i % 10];
      techIds.push(ulid());
      b.techniques.push({
        id: techIds[i], disciplineId: disc.id, nom: `Technique ${i + 1}`,
        nomTraditionnel: i % 3 === 0 ? `Waza ${i + 1}` : undefined,
        familleId: disc.familles[i % 2].id, niveauxIds: [disc.niveaux[i % 3].id], relations: [],
      });
    }
    const types = ["prepare", "enchaine", "contre", "similaire", "enchaine"];
    for (let i = 0; i < 2000; i++)
      for (let r = 0; r < 5; r++)
        b.techniques[i].relations.push({
          type: types[r], cibleId: techIds[(i * 7 + r * 131 + 1) % 2000],
          note: r === 0 ? `ouvre la suite ${i}` : undefined, priorite: r + 1,
        });
    for (let c = 0; c < 500; c++)
      b.contributions.push({
        id: ulid(), techniqueId: techIds[c], provenance: "personnel",
        description: `Notes de travail ${c} — points d'appui, distance, timing.`,
        pointsCles: [`repère ${c}.1`, `repère ${c}.2`], creeLe: quand, medias: [],
      });
    for (let k = 0; k < 100; k++)
      b.compositions.push({
        id: ulid(), nom: `Composition ${k + 1}`, provenance: "personnel", creeLe: quand, type: "enchainement",
        blocs: Array.from({ length: 10 }, (_, j) => ({
          id: ulid(), type: "technique", techniqueId: techIds[(k * 10 + j) % 2000], texte: `Technique ${((k * 10 + j) % 2000) + 1}`, medias: [],
        })),
      });
    b.favoris.push(...techIds.slice(0, 50));
    await app.enregistrerReordre(); // persiste (validation complète comprise)
  });
  mesures["génération + validation + persistance"] = Date.now() - t0;
}

/* ---- démarrage à froid sur le jeu ---- */
{
  const t0 = Date.now();
  await page.reload();
  await page.waitForSelector(".chip-discipline, .barre-nav", { timeout: 60_000 });
  mesures["démarrage (reload → premier écran)"] = Date.now() - t0;
  const compte = await page.evaluate(() => {
    const b = document.querySelector("movenso-app").bibliotheque;
    return [b.disciplines.length, b.techniques.length, b.techniques.reduce((n, t) => n + t.relations.length, 0), b.contributions.length, b.compositions.length];
  });
  assert.deepEqual(compte, [10, 2000, 10000, 500, 100], "le jeu complet est rechargé : " + compte.join(" / "));
}

/* ---- recherche ---- */
{
  await page.waitForSelector(".recherche input");
  const t0 = Date.now();
  await page.fill(".recherche input", "Technique 1234");
  await page.waitForFunction(() => document.body.innerText.includes("Technique 1234"), null, { timeout: 15_000 });
  mesures["recherche (frappe → résultat affiché)"] = Date.now() - t0;
}

/* ---- ouverture de fiche ---- */
{
  const t0 = Date.now();
  await page.evaluate(() => {
    const app = document.querySelector("movenso-app");
    app.ouvrirFiche(app.bibliotheque.techniques[1233].id);
  });
  await page.waitForSelector(".fiche-entete h1");
  mesures["ouverture de fiche"] = Date.now() - t0;
}

/* ---- explorateur (liste chargée) ---- */
{
  const t0 = Date.now();
  await page.evaluate(() => {
    const app = document.querySelector("movenso-app");
    app.majFiltres({ ...app.filtres, texte: "" }); // la recherche de l'étape précédente ne doit pas filtrer l'explorateur
    app.ecran = { type: "discipline", disciplineId: app.bibliotheque.disciplines[0].id };
  });
  await page.waitForSelector(".carte-technique", { timeout: 15_000 });
  mesures["explorateur d'une discipline (200 techniques)"] = Date.now() - t0;
}

/* ---- Mindmap + Carte + Explorer (relations bêta) ---- */
{
  await page.evaluate(() => {
    const app = document.querySelector("movenso-app");
    if (!app.preferences.vueRelationBeta) app.basculerReglage("vueRelationBeta");
    app.ouvrirRelationsVisuelle(app.bibliotheque.techniques[0].id, "classique");
  });
  const t0 = Date.now();
  await page.waitForSelector(".mm-plein, .mm-scene, .rel-vue-onglet", { timeout: 20_000 });
  mesures["Mindmap (ouverture, centre à 10 relations)"] = Date.now() - t0;
  const t1 = Date.now();
  await page.evaluate(() => document.querySelector("movenso-app").definirVueRelations?.("carte"));
  await page.waitForTimeout(300);
  mesures["Carte (bascule de vue)"] = Date.now() - t1 - 300;
  const t2 = Date.now();
  await page.evaluate(() => document.querySelector("movenso-app").definirVueRelations?.("explorer"));
  await page.waitForTimeout(300);
  mesures["Explorer (bascule de vue)"] = Date.now() - t2 - 300;
}

/* ---- sauvegarde interne ---- */
{
  const t0 = Date.now();
  await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    await app.stockage.sauvegarder(app.bibliotheque);
  });
  mesures["persistance complète (2e écriture)"] = Date.now() - t0;
}

/* ---- ce que les IMAGES coûtent à chaque sauvegarde (S4.2bis boucle B) ----
   Les couvertures de pack vivent en base64 DANS `bibliotheque.json`. Le
   chemin protégé écrit le temporaire, le RELIT, puis bascule : trois passes
   sur la totalité du fichier, à chaque geste qui persiste. On mesure donc le
   coût réel d'une sauvegarde selon le poids des images embarquées — par le
   VRAI chemin d'écriture (`stockage.sauvegarder`), jamais par une sonde OPFS
   fabriquée à côté. Repères : karaté publié = 4,9 Mo d'images ; les six packs
   ensemble ≈ 12 Mo. */
for (const mo of [0, 5, 12]) {
  const ms = await page.evaluate(async (mo) => {
    const app = document.querySelector("movenso-app");
    const b = app.bibliotheque;
    // Une image de 24 Ko répétée : ce sont les OCTETS écrits qui sont mesurés,
    // pas leur contenu. Chaque technique porte la sienne (aucune déduplication
    // possible côté fichier — c'est précisément la situation d'un pack).
    const cible = mo * 1024 * 1024;
    const unite = "data:image/jpeg;base64," + "A".repeat(24 * 1024);
    let pose = 0;
    for (const t of b.techniques) {
      t.couverture = pose < cible ? { type: "image", dataUrl: unite } : undefined;
      if (pose < cible) pose += unite.length;
    }
    const t0 = performance.now();
    await app.stockage.sauvegarder(b);
    return Math.round(performance.now() - t0);
  }, mo);
  mesures[`sauvegarde avec ${mo} Mo d'images embarquées`] = ms;
}

/* ---- mémoire JS ---- */
{
  const m = await page.evaluate(() => performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : null);
  mesures["mémoire JS (usedJSHeapSize)"] = m === null ? "indisponible" : `${m} Mo`;
}

console.log("\n=== Campagne grosse bibliothèque (S2.16) ===");
for (const [k, v] of Object.entries(mesures)) console.log(`  ${k} : ${typeof v === "number" ? v + " ms" : v}`);
assert.deepEqual(erreurs, [], "erreurs JS : " + erreurs.join(" | "));
console.log("campagne charge : OK, zéro erreur JS");

await ctx.close();
await navigateur.close();
serveur.close();
