/**
 * PÈSE-IMAGES (S4.2bis boucle B) — outil LOCAL, lecture seule.
 *
 *   node tools/peser-images.mjs <fichier.movpack…>
 *
 * Répond à une question qu'on avait crue tranchée : que gagne-t-on vraiment à
 * sortir les images de `bibliotheque.json` ?
 *
 * Le plan de la boucle B annonçait « la fin de l'inflation base64 (+33 %) ».
 * C'est vrai du TEXTE, et faux du CONTENEUR : le `.movpack` est un ZIP, et
 * deflate récupère presque toute l'inflation d'un base64 — il ne reste que
 * quelques pour cent. L'outil le mesure au lieu de le supposer : il simule le
 * conteneur v5 (chaque `dataUrl` unique devient un fichier stocké tel quel,
 * les octets étant déjà compressés) et le compare au conteneur réel.
 *
 * La colonne qui compte n'est donc pas l'écart de conteneur, c'est la taille
 * de `bibliotheque.json` — le fichier que le stockage réécrit à CHAQUE
 * sauvegarde, en trois passes (temporaire, relecture, bascule).
 */
import { readFileSync } from "node:fs";
import { basename } from "node:path";
import { unzipSync, zipSync } from "fflate";

const fichiers = process.argv.slice(2);
if (!fichiers.length) {
  console.error("Usage : node tools/peser-images.mjs <fichier.movpack…>");
  process.exit(2);
}

const ko = (n) => (n / 1024).toFixed(0).padStart(6) + " Ko";

/** Remplace chaque `dataUrl` par une référence de fichier, en place, et rend
 *  les octets décodés — un même dataUrl ne donne qu'un seul fichier. */
function externaliser(noeud, images) {
  if (!noeud || typeof noeud !== "object") return;
  if (Array.isArray(noeud)) return noeud.forEach((n) => externaliser(n, images));
  if (noeud.type === "image" && typeof noeud.dataUrl === "string") {
    const url = noeud.dataUrl;
    if (!images.has(url)) images.set(url, Buffer.from(url.slice(url.indexOf(",") + 1), "base64"));
    noeud.type = "fichier";
    noeud.fichier = `images/${[...images.keys()].indexOf(url) + 1}`;
    delete noeud.dataUrl;
    return;
  }
  for (const valeur of Object.values(noeud)) externaliser(valeur, images);
}

console.log(
  "pack".padEnd(20), "conteneur v4".padStart(13), "v5 simulé".padStart(13), "écart".padStart(9),
  "  bibliotheque.json v4 → v5",
);

for (const chemin of fichiers) {
  const octets = new Uint8Array(readFileSync(chemin));
  const entrees = unzipSync(octets);
  const bibV4 = entrees["bibliotheque.json"];
  const bibliotheque = JSON.parse(new TextDecoder().decode(bibV4));

  const images = new Map();
  externaliser(bibliotheque, images);
  const bibV5 = new TextEncoder().encode(JSON.stringify(bibliotheque));

  // `level: 0` = stocké sans compression : une image JPEG/PNG/WebP est déjà
  // compressée, la repasser à deflate coûte du temps et ne gagne rien.
  const contenu = { "manifeste.json": entrees["manifeste.json"], "bibliotheque.json": bibV5 };
  let n = 0;
  for (const bloc of images.values()) contenu[`images/${++n}`] = [new Uint8Array(bloc), { level: 0 }];
  for (const [nom, bloc] of Object.entries(entrees))
    if (nom.startsWith("medias/") || nom.startsWith("videos/")) contenu[nom] = [bloc, { level: 0 }];

  const v5 = zipSync(contenu);
  const ecart = v5.length - octets.length;
  const facteur = (bibV4.length / bibV5.length).toFixed(0);
  console.log(
    basename(chemin, ".movpack").padEnd(20), ko(octets.length), ko(v5.length),
    ((ecart >= 0 ? "+" : "") + (ecart / 1024).toFixed(0) + " Ko").padStart(9),
    ` ${ko(bibV4.length)} → ${ko(bibV5.length)}  (${facteur}×, ${images.size} image(s))`,
  );
}
