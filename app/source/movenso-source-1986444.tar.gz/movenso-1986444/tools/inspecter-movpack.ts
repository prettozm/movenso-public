/**
 * Inspecteur `.movpack` (lot 8D §37/§43) — outil LOCAL, lecture seule, aucun
 * secret. Ouvre un conteneur et rapporte son manifeste et l'intégrité PAR
 * FICHIER (chemin, taille attendue vs réelle, empreinte attendue vs recalculée),
 * sans muter quoi que ce soit. Sert la reproductibilité : « inspecter un
 * `.movpack` » depuis une machine neuve.
 *
 * Usage : node --experimental-strip-types tools/inspecter-movpack.ts <fichier.movpack>
 */

import { readFileSync } from "node:fs";
import { unzipSync } from "fflate";
import { sha256Hex } from "../src/domaine/sha256.ts";
import { estZip, type ManifesteMovpack } from "../src/echange/movpack-contrat.ts";

const chemin = process.argv[2];
if (!chemin) {
  console.error("Usage : node --experimental-strip-types tools/inspecter-movpack.ts <fichier.movpack>");
  process.exit(2);
}

const octets = new Uint8Array(readFileSync(chemin));
if (!estZip(octets)) {
  console.error(`✗ ${chemin} n'est pas un conteneur ZIP (peut-être un JSON historique nu).`);
  process.exit(1);
}

const entrees = unzipSync(octets);
const manifesteBrut = entrees["manifeste.json"];
if (!manifesteBrut) {
  console.error("✗ Aucun manifeste.json — ce n'est pas un .movpack valide.");
  process.exit(1);
}
const m = JSON.parse(new TextDecoder().decode(manifesteBrut)) as ManifesteMovpack;

console.log(`Inspection de ${chemin}`);
console.log(`  format / version conteneur : ${m.format} v${m.version}`);
console.log(`  identité (stable) : ${m.id}`);
console.log(`  nom éditorial : ${m.nom}`);
console.log(`  portée (type d'objet) : ${m.portee}`);
console.log(`  version du schéma : ${m.versionSchema}`);
if (m.versionEditoriale !== undefined) console.log(`  version éditoriale : ${m.versionEditoriale}`);
if (m.auteur) console.log(`  auteur : ${m.auteur}`);
if (m.inclusions) console.log(`  inclusions : médias=${m.inclusions.medias}, contenu personnel=${m.inclusions.contenuPersonnel}`);
console.log(`  algorithme d'intégrité : ${m.algorithme ?? "(v3 : empreinte globale seule)"}`);

let ok = 0;
let ko = 0;
if (m.fichiers?.length) {
  console.log(`\nIntégrité par fichier (${m.fichiers.length}) :`);
  for (const f of m.fichiers) {
    const present = entrees[f.chemin];
    if (!present) {
      console.log(`  ✗ ${f.chemin} — MANQUANT`);
      ko++;
      continue;
    }
    const tailleOk = present.length === f.taille;
    const empreinteOk = sha256Hex(present) === f.sha256;
    if (tailleOk && empreinteOk) {
      console.log(`  ✓ ${f.chemin} (${present.length} o)`);
      ok++;
    } else {
      console.log(`  ✗ ${f.chemin} — ${!tailleOk ? `taille ${present.length}≠${f.taille}` : ""} ${!empreinteOk ? "empreinte différente" : ""}`.trim());
      ko++;
    }
  }
} else {
  console.log("\n(v3 : pas d'inventaire par fichier — seule l'empreinte globale de bibliotheque.json est portée)");
}

const inattendus = Object.keys(entrees).filter((n) => n !== "manifeste.json" && n !== "bibliotheque.json" && !(m.fichiers ?? []).some((f) => f.chemin === n));
if (inattendus.length) console.log(`\nFichiers hors inventaire (ignorés avec avertissement) : ${inattendus.join(", ")}`);

console.log(`\nRésultat : ${ko === 0 ? "INTÈGRE ✓" : `${ko} écart(s) ✗`}${m.fichiers?.length ? ` (${ok}/${m.fichiers.length} vérifiés)` : ""}`);
process.exit(ko === 0 ? 0 : 1);
