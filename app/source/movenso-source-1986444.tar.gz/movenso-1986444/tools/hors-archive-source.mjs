/**
 * CE QUI N'ENTRE PAS dans la source correspondante (D-353).
 *
 * La GPLv3 §1 demande « the source code needed to generate, install, and run
 * the object code » — pas la documentation du projet, ni ses maquettes, ni ses
 * journaux d'audit. Ce qui est écarté ici ne retire donc **aucune ligne** de ce
 * qui permet de rebâtir le binaire : `npm ci && npm run build` sur l'archive
 * produit le même `dist/`.
 *
 * L'ACCIDENT QUI A PRODUIT CE FICHIER. L'en-tête de `source-du-build.mjs`
 * affirmait que l'archive pesait « quelques centaines de Ko ». Mesurée le
 * 2026-08-17 : **3,86 Mo**, treize fois plus — `docs/` avait grossi pendant que
 * la phrase, elle, ne bougeait pas. Comme l'archive était produite à **chaque
 * poussée sur chaque branche** avec 7 jours de rétention, le quota de stockage
 * Actions (500 Mo) était consommé à 123 % par un palier de 613 Mo, sans que
 * personne suspecte ce poste : toute la mémoire du dépôt sur le quota (D-127,
 * D-197, D-230) désignait l'APK et les miniatures, déjà réglés.
 *
 * D'où la forme de ce module : la liste vit à **un seul endroit** (D-253), avec
 * la raison de chaque entrée, et `tests/source-archive.test.ts` la tient. Une
 * exclusion sans sa raison finit par être retirée par quelqu'un qui ne sait pas
 * pourquoi elle est là.
 */

/** Préfixes écartés de l'archive, chacun avec ce qui le justifie. */
export const HORS_ARCHIVE = [
  {
    prefixe: "donnees/images/",
    raison:
      "illustrations des packs — données de CONTENU, pas des entrées de build : "
      + "le `dist/` n'en contient rien (motif d'origine, S4.7/D-265).",
  },
  {
    prefixe: "docs/",
    raison:
      "documentation, maquettes et journaux d'audit — aucune étape de build ne "
      + "les lit. Poste le plus lourd de l'archive au moment de l'exclusion "
      + "(mesuré le 2026-08-17 : 1,76 Mo compressés sur 3,86 — D-353).",
  },
  {
    prefixe: "_provisoire-methode/",
    raison:
      "notes de méthode provisoires et leurs PNG — hors produit "
      + "(mesuré le 2026-08-17 : 0,66 Mo compressés — D-353).",
  },
];

/**
 * Les fichiers de l'archive, depuis la liste des fichiers SUIVIS par git.
 * Fonction pure : c'est elle que la garde éprouve, et c'est elle que
 * `source-du-build.mjs` applique — un seul chemin, pas deux (D-253).
 */
export function fichiersDeLArchive(suivis) {
  return suivis.filter((f) => f && !HORS_ARCHIVE.some(({ prefixe }) => f.startsWith(prefixe)));
}
