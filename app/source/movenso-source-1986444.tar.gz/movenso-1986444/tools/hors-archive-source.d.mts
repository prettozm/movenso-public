/** Types de `hors-archive-source.mjs` — pour les tests TypeScript uniquement. */
export declare const HORS_ARCHIVE: { prefixe: string; raison: string }[];
export declare function fichiersDeLArchive(suivis: string[]): string[];
