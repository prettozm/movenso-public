# `tools/` — ce qui est publié doit être reproductible

Ces outils produisent ce que reçoivent les autres. Un défaut ici sort du dépôt.

- **Rien ne se saisit à la main de ce qui peut se dériver.** `publier.ts`
  construit les conteneurs, les **relit par le lecteur réel**, et calcule
  compteurs et catalogue **depuis la relecture** — pas depuis l'intention
  (D-264). Un écart fait échouer la publication, il ne se corrige pas.
- **Un pack se reproduit depuis `donnees/`.** Une source hors dépôt est une
  dette, pas une méthode. Les illustrations vivent en **fichiers**
  (`donnees/images/`), jamais en base64 dans la source.
- **L'identité d'un pack vient de sa DISCIPLINE, jamais de son nom de
  fichier** (`idPackStable`, D-247). La changer fait voir une mise à jour
  comme une installation neuve et **duplique tout le contenu** chez qui l'a
  déjà. `tests/packs-identite.test.ts` épingle chaque identité.
- **La source correspondante voyage avec le binaire** (GPLv3) :
  `source-du-build.mjs` refuse un dépôt dont des fichiers **suivis** sont
  modifiés — l'archive est bâtie depuis `git ls-files` et lue dans l'arbre de
  travail. Les fichiers non suivis n'y entrent pas et ne sont pas un motif de
  refus (D-270).
- **Avant d'intégrer un pack fourni, TOUJOURS le comparer au publié** —
  techniques, images, compositions, identité. C'est ainsi qu'on a vu le karaté
  perdre ses 109 images (D-245) et l'identité du jujitsu dériver (D-247).
- **Mesurer avant d'optimiser.** La boucle « images en fichiers » promettait la
  fin de l'inflation base64 : mesurée, elle valait 1 à 3 % sur le conteneur, le
  gain réel étant ailleurs (D-268). Un outil de mesure vaut mieux qu'une
  intuition : `peser-images.mjs`, `campagne:charge`.
- **PRODUIRE n'est pas DÉPOSER** (D-281). `npm run publier` fabrique dans
  `dist-publication/` et n'écrit **nulle part ailleurs** ; `npm run deposer`
  est le seul geste qui écrit dans le dépôt public, et il rejoue
  `verifier:release` avant. Tant que les deux tenaient dans une option
  (`publier --vers`), une frappe distraite publiait.
- **Un APK ou une release ne se génère que sur demande explicite** (D-267).
