# donnees/ — rôle de chaque fichier (D-212, remis au réel S4.8/S4.9)

**Les six packs publiés sont désormais reproductibles depuis ce dossier.** Le
yoga était le dernier à ne pas l'être : sa source a été reconstruite depuis le
conteneur publié (S4.8) — dérivée d'un binaire, donc, faute d'original.

| Fichier | Rôle | Publiable ? |
|---|---|---|
| `kodokan.json` | **Source du pack public « Judo »** (⚠️ nom de fichier INTERNE — le mot « Kodokan » ne doit JAMAIS entrer dans l'identité publique du pack : nom, titre, auteur. Attribution descriptive des vidéos uniquement, D-213) → `packs/judo.movpack` | ✅ oui |
| `jujitsu.json` | Source du pack public « Jujitsu » (D-238) → `packs/jujitsu.movpack` | ✅ oui |
| `karate-shotokan.json` | Source du pack public « Karaté Shotokan » (D-245) | ✅ oui |
| `jjb.json` | Source du pack public « Jiu-jitsu brésilien » (D-246) | ✅ oui |
| `taiso.json` | Source du pack public « Taïso » (D-248) | ✅ oui |
| `yoga.json` | Source du pack public « Yoga Hatha ». **Reconstruite depuis le conteneur publié** (S4.8) : les libellés sont ceux du pack, pas d'un original. | ✅ oui |
| `club-judo.json` | **FIXTURE E2E INTERNE** — le pack « exigeant » des tests : niveaux de ceinture (O5), homonymes qui prouvent la dé-fusion (D-067), types réduits. | ❌ **jamais** — absent de `publication/packs.json` à dessein |
| `rapprochements-judo.json` | Fixture des tests de rapprochement (D-015). | ❌ jamais |

## Images

`donnees/images/<source>/` porte les illustrations, en **fichiers** — jamais en
base64 dans la source, qui doit rester lisible et légère :

- `techniques/<origine.element>.jpg` — l'illustration **propre** à une
  technique. Elle prime toujours.
- `<familleId>.jpg` — la **carte de famille**, posée à défaut sur chaque
  technique de la famille (D-244). Elle porte son titre générique : la fiche
  montre une carte de famille assumée, jamais une photo qui prétendrait être
  cette technique-là.

État actuel : karaté, taïso et yoga ont une image **par technique** ; jujitsu
et jjb sont couverts **par leurs familles** ; le **judo n'a aucune image** —
ses 111 fiches s'appuient sur les vidéos Kodokan, et 10 cartes de famille
suffiraient à les couvrir toutes.

## Sous-titre des techniques (R2-1, D-297)

Le champ `nomTraditionnel` d'une technique est affiché comme la **deuxième
ligne de sa carte** et le formulaire d'édition l'appelle déjà « Sous-titre ».
Convention (arbitrage porteur, 2026-08-11) — c'est un **sous-titre descriptif,
en français**, qui dit en quelques mots ce que FAIT la technique :

- ✅ « clé d'épaule avec contrôle du poignet », « hanche flottée »,
  « balayage du pied avancé » ;
- ❌ jamais un niveau ni une ceinture (la rangée de niveau existe à part) ;
- ❌ jamais une variante d'équipement (« Gi / No-Gi ») ;
- ❌ jamais le nom traditionnel SEUL — un nom japonais ou sanskrit n'y vit
  que **suivi de sa glose** (cas du yoga : « Trikonasana — posture du
  triangle »).

État des packs au 2026-08-11 : karaté et jujitsu suivent déjà l'esprit ;
judo (noms japonais seuls), jjb (Gi/No-Gi), taïso et yoga sont à repasser —
**pack par pack, diff relu par le porteur avant republication**. Le nom du
champ (`nomTraditionnel`) est un héritage : le renommer toucherait le format
public — assumé, le formulaire et cette convention font foi sur le sens.

## Publier

La liste des packs et leurs métadonnées vivent dans **`publication/packs.json`**
— source unique. Un seul script fait tout le chemin :

```
node --experimental-strip-types tools/publier.ts [--vers ../movenso-public]
```

Il valide la source, pose les illustrations, construit le conteneur avec sa
licence, **le relit par le lecteur réel**, calcule les compteurs **depuis le
conteneur relu** (jamais à la main), génère le catalogue, et refuse de publier
au moindre écart.

Règle inchangée : le circuit de publication ne contient QUE du publiable.
Ajouter un fichier à `publication/packs.json` est une **décision** (journal),
pas un réflexe.
