# `src/echange/` — frontière hostile

Ici arrivent des octets que **nous n'avons pas produits**. Tout ce qui suit est
né d'un défaut réel, pas d'un principe.

- **Tout JSON externe est `unknown` jusqu'à validation. Aucun `as` ne vaut
  contrôle.** `JSON.parse(...) as ManifesteMovpack` est une promesse faite au
  compilateur ; à l'exécution le fichier vient d'un tiers. `portee` décide
  d'écraser toute la bibliothèque, `id` distingue une mise à jour d'une
  installation neuve — `portee: {danger:true}` et `id: 42` passaient (D-271).
- **Un conteneur ne choisit pas la rigueur qu'on lui applique.** Le repli
  « empreinte globale » appartient à v3 ; v4+ EXIGE son inventaire (D-263).
- **movpack v5 — le nom d'une image EST son contenu.** `images/<sha256>` doit
  contenir les octets dont c'est l'empreinte, vérifié **séparément** de ce que
  le manifeste déclare : un conteneur peut être honnête sur ce qu'il
  transporte et le ranger sous le nom d'une AUTRE image, que l'écriture
  idempotente rendrait ensuite inécrasable (D-271).
- **Toute entrée est bornée AVANT allocation** (`LIMITES_MOVPACK`) : nombre
  d'entrées, taille par fichier, volume décompressé total, et une borne propre
  aux images — elles s'accumulent en mémoire, elles héritaient de 64 Mo
  chacune (D-271). Une borne se choisit sur une **mesure du réel**, pas au
  jugé : la plus grande image publiée fait 46 Ko.
- **Les médias volumineux vont au flux**, jamais au tas : `lireMovpackFlux` et
  `exporterMovpackFlux` sont les chemins réels de l'application.
- **Le CONTRAT ne connaît pas le CODEC.** `movpack-contrat.ts` n'importe pas
  `fflate` — une règle qui aurait besoin du codec pour s'énoncer prouverait
  que la frontière est mal placée. Garde exécutable dans `verifier:sources`.
- **Le format est public.** Une évolution exige une lecture rétro-compatible
  (v3 et v4 restent lisibles), ou une décision humaine.
- **Un pack en schéma N+1 est illisible par une app en schéma N** : app,
  packs et source partent dans le **même commit** (D-267).
