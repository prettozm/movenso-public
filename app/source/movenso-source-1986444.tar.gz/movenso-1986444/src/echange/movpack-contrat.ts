/**
 * CONTRAT d'un conteneur `.movpack` — ce qu'on EXIGE de lui, séparé de la
 * mécanique qui l'ouvre (D-274).
 *
 * Ce module ne connaît ni ZIP ni flux : **il n'importe pas `fflate`**, et
 * c'est le test de la coupure. Une règle qui aurait besoin du codec pour
 * s'énoncer prouverait que la frontière est mal placée ; aucune n'en a
 * besoin. Ce qui vit ici : la version du format, la forme du manifeste et sa
 * VALIDATION (jamais un cast — `portee` décide d'écraser la bibliothèque),
 * le contrat d'intégrité, les chemins reconnus, l'invariant du nom d'une
 * image, et les limites qui rendent une archive hostile fatale plutôt que
 * ruineuse.
 */
import type { Bibliotheque } from "../domaine/modele.ts";
import { sha256Hex } from "../domaine/sha256.ts";

export const VERSION_MOVPACK = 5;

/** Une entrée de l'inventaire d'intégrité (lot 8B §14) : un fichier du
 *  conteneur, son chemin canonique, sa taille en octets, son empreinte. */
export interface FichierManifeste {
  chemin: string;
  taille: number;
  sha256: string;
}

export interface ManifesteMovpack {
  format: "movpack";
  version: number;
  /** Identité stable du pack — clé d'idempotence au réimport (D-015). */
  id: string;
  nom: string;
  /** `complet` = export intégral restaurable (type d'objet : sauvegarde) ;
   *  `discipline` = pack publiable ; `composition` = une composition et les
   *  identités qu'elle référence. La portée EST le type d'objet (§13). */
  portee: "complet" | "discipline" | "composition";
  auteur?: string;
  conditions?: string;
  creeLe: string;
  versionSchema: number;
  /** SHA-256 (hex) de bibliotheque.json — l'intégrité se vérifie, ne se
   *  suppose pas. Conservé en v4 (repli et inspecteurs externes) ; en v4
   *  l'autorité est l'inventaire `fichiers`. */
  empreinte: string;
  videos: string[];
  /** v4 — version ÉDITORIALE du pack (défaut 1) : distincte des versions du
   *  conteneur, du schéma et de l'application (§28). */
  versionEditoriale?: number;
  /** v4 — algorithme des empreintes de l'inventaire. */
  algorithme?: string;
  /** v4 — ce que le conteneur inclut réellement, DIT (§13) : médias,
   *  contenu personnel (carnet, favoris). */
  inclusions?: { medias: boolean; contenuPersonnel: boolean };
  /** v4 — inventaire d'intégrité par fichier (bibliotheque.json + médias). */
  fichiers?: FichierManifeste[];
}

export class ErreurMovpack extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ErreurMovpack";
  }
}

/** Détection par contenu : un ZIP commence par « PK ». */
export function estZip(octets: Uint8Array): boolean {
  return octets.length > 3 && octets[0] === 0x50 && octets[1] === 0x4b;
}

/** Dossiers de médias reconnus dans un conteneur : `medias/` (canonique,
 *  lot 8B §12) et `videos/` (v3 et historiques, restés importables). */
export function estCheminMedia(chemin: string): boolean {
  return (chemin.startsWith("medias/") || chemin.startsWith("videos/")) && chemin.length > 7;
}

/** Chemin d'une IMAGE de couverture (v5, D-269) : `images/<sha256 hex>`. Le
 *  nom EST l'empreinte — un lecteur peut donc vérifier l'intégrité d'une image
 *  sans consulter le manifeste, et deux packs qui partagent une illustration
 *  la nomment pareil. */
export function estCheminImage(chemin: string): boolean {
  return /^images\/[0-9a-f]{64}$/.test(chemin);
}

/** Les octets des images d'une bibliothèque, par empreinte. */
export type OctetsImages = Map<string, Uint8Array>;

/**
 * L'INVARIANT DU NOM (D-271) : `images/<empreinte>` doit contenir exactement
 * les octets dont c'est l'empreinte.
 *
 * Vérifier l'empreinte DÉCLARÉE au manifeste ne suffit pas : un conteneur
 * hostile peut annoncer honnêtement le hash de ce qu'il transporte, tout en
 * le rangeant sous le nom d'une AUTRE image. Or le nom est ensuite l'identité
 * du contenu — dans OPFS, dans l'inventaire, dans les couvertures. Un pack
 * pourrait ainsi planter ses octets sous le nom d'une illustration légitime :
 * l'écriture étant idempotente (le fichier existe déjà), la vraie image ne
 * serait plus jamais écrite, et la fiche montrerait autre chose.
 *
 * Le nom EST donc revérifié contre le contenu, séparément du manifeste.
 */
export function exigerNomFidele(chemin: string, contenu: Uint8Array): void {
  const annonce = chemin.slice("images/".length);
  const reelle = sha256Hex(contenu);
  if (reelle !== annonce)
    throw new ErreurMovpack(
      `Image falsifiée : ${chemin} contient des octets d'empreinte ${reelle.slice(0, 12)}…`
      + ` — le nom d'une image EST son contenu, il ne peut pas désigner autre chose`,
    );
}

/** Refuse d'écrire un conteneur dont les images manquent : l'inventaire les
 *  déclare, le ZIP ne les porte pas — les fiches arriveraient nues chez qui
 *  l'importe, sans que rien ne le signale. Mieux vaut ne pas produire le
 *  conteneur que d'en produire un vide de ses illustrations. */
export function exigerImages(b: Bibliotheque, images: OctetsImages): void {
  const manquantes = (b.images ?? []).filter((i) => !images.has(i.id));
  if (manquantes.length)
    throw new ErreurMovpack(
      `Conteneur incomplet : ${manquantes.length} image(s) déclarée(s) dont les octets n'ont pas été fournis`
      + ` (première : ${manquantes[0]!.id.slice(0, 12)}…)`,
    );
}

/** Id LOGIQUE d'un média depuis son chemin : `medias/<id>.<ext>` ou
 *  `videos/<id>` → `<id>` (un ULID ne contient jamais de point). */
export function idMediaDepuisChemin(chemin: string): string {
  const apresDossier = chemin.slice(chemin.indexOf("/") + 1);
  const point = apresDossier.indexOf(".");
  return point === -1 ? apresDossier : apresDossier.slice(0, point);
}

const PORTEES = ["complet", "discipline", "composition"] as const;

function texte(v: unknown): v is string {
  return typeof v === "string";
}

/**
 * Le manifeste est VALIDÉ, pas casté (D-271).
 *
 * `JSON.parse(...) as ManifesteMovpack` est une promesse faite au compilateur,
 * pas un contrôle : à l'exécution, ces champs viennent d'un fichier fourni par
 * un tiers. Or ils DÉCIDENT — `portee: "complet"` route vers la
 * RESTAURATION (qui remplace toute la bibliothèque) plutôt que vers l'import
 * d'un pack, `id` est la clé d'idempotence qui distingue une mise à jour d'une
 * installation neuve, `nom` compose le nom de fichier proposé. Un `portee`
 * objet, un `id` numérique : le typage n'y voyait rien, et le comportement
 * partait au hasard.
 *
 * On refuse donc AVANT de rien décider. Les champs dont dépend une décision
 * sont exigés ; les autres sont contrôlés s'ils sont là.
 */
export function validerManifeste(brut: unknown): ManifesteMovpack {
  const refus = (m: string): never => {
    throw new ErreurMovpack(`Manifeste invalide : ${m}`);
  };
  if (typeof brut !== "object" || brut === null || Array.isArray(brut)) refus("un objet est attendu");
  const m = brut as Record<string, unknown>;

  if (m["format"] !== "movpack") throw new ErreurMovpack("Manifeste inconnu : pas un .movpack");
  if (typeof m["version"] !== "number" || !Number.isInteger(m["version"]) || m["version"] < 1)
    refus(`version de conteneur « ${String(m["version"])} » invalide`);
  if (!texte(m["id"]) || m["id"].trim() === "") refus("identité du pack manquante — c'est la clé qui distingue une mise à jour d'une installation neuve");
  if (!texte(m["nom"]) || m["nom"].trim() === "") refus("nom manquant");
  if (!texte(m["portee"]) || !(PORTEES as readonly string[]).includes(m["portee"]))
    refus(`portée « ${String(m["portee"])} » inconnue (${PORTEES.join(", ")}) — c'est elle qui décide entre importer un pack et REMPLACER la bibliothèque`);
  if (!texte(m["creeLe"]) || Number.isNaN(Date.parse(m["creeLe"]))) refus(`date de création « ${String(m["creeLe"])} » illisible`);
  if (typeof m["versionSchema"] !== "number" || !Number.isInteger(m["versionSchema"]))
    refus(`version de schéma « ${String(m["versionSchema"])} » invalide`);
  if (!texte(m["empreinte"])) refus("empreinte manquante");
  if (!Array.isArray(m["videos"]) || m["videos"].some((v) => !texte(v))) refus("« videos » : une liste d'identifiants est attendue");

  for (const [champ, valeur] of [["auteur", m["auteur"]], ["conditions", m["conditions"]], ["algorithme", m["algorithme"]]] as const)
    if (valeur !== undefined && !texte(valeur)) refus(`« ${champ} » : texte attendu`);
  if (m["versionEditoriale"] !== undefined
    && (typeof m["versionEditoriale"] !== "number" || !Number.isInteger(m["versionEditoriale"]) || m["versionEditoriale"] < 1))
    refus(`version éditoriale « ${String(m["versionEditoriale"])} » invalide`);
  if (m["inclusions"] !== undefined) {
    const i = m["inclusions"] as Record<string, unknown>;
    if (typeof i !== "object" || i === null || typeof i["medias"] !== "boolean" || typeof i["contenuPersonnel"] !== "boolean")
      refus("« inclusions » : { medias: booléen, contenuPersonnel: booléen } attendu — c'est ce que le conteneur DIT emporter");
  }
  // `fichiers` a son propre contrôle, plus fin, dans `contratIntegrite`.
  if (m["fichiers"] !== undefined && !Array.isArray(m["fichiers"])) refus("« fichiers » : une liste est attendue");
  return m as unknown as ManifesteMovpack;
}

/** CONTRAT D'INTÉGRITÉ d'un conteneur (S4.2/D-263).
 *
 *  Le repli « empreinte globale » appartient à v3. Il était choisi sur le seul
 *  fait que `fichiers` soit absent ou vide — **sans regarder la version
 *  déclarée**. Un conteneur annonçant `version: 4` pouvait donc omettre son
 *  inventaire et retomber en silence sur le contrôle le plus faible : le
 *  `bibliotheque.json` restait couvert par l'empreinte globale, mais **les
 *  médias voyageaient sans aucune empreinte**, et aucun avertissement ne le
 *  disait. Un conteneur choisissait lui-même la rigueur qu'on lui appliquait.
 *
 *  Désormais : v4 EXIGE son inventaire, et le repli est réservé à v3.
 */
export function contratIntegrite(manifeste: ManifesteMovpack): FichierManifeste[] | null {
  const aInventaire = Array.isArray(manifeste.fichiers) && manifeste.fichiers.length > 0;

  if (manifeste.version >= 4) {
    if (!aInventaire)
      throw new ErreurMovpack(
        "Conteneur v4 incomplet : l'inventaire d'intégrité « fichiers » est obligatoire à partir de la version 4"
        + " — un conteneur ne choisit pas la rigueur qu'on lui applique",
      );
    // L'algorithme est DIT : on refuse de vérifier avec autre chose que ce que
    // le conteneur annonce, plutôt que de supposer qu'il pensait SHA-256.
    if (manifeste.algorithme !== undefined && manifeste.algorithme !== "SHA-256")
      throw new ErreurMovpack(`Algorithme d'intégrité « ${manifeste.algorithme} » non supporté (SHA-256 attendu)`);
    for (const [i, f] of manifeste.fichiers!.entries()) {
      const ou = `Inventaire, entrée ${i + 1}`;
      if (!f || typeof f !== "object") throw new ErreurMovpack(`${ou} : objet attendu`);
      if (typeof f.chemin !== "string" || f.chemin.trim() === "") throw new ErreurMovpack(`${ou} : chemin manquant`);
      if (!Number.isInteger(f.taille) || f.taille < 0) throw new ErreurMovpack(`${ou} (${f.chemin}) : taille invalide`);
      if (typeof f.sha256 !== "string" || !/^[0-9a-f]{64}$/.test(f.sha256))
        throw new ErreurMovpack(`${ou} (${f.chemin}) : empreinte SHA-256 mal formée`);
    }
    return manifeste.fichiers!;
  }

  // v3 et antérieurs : l'inventaire n'existait pas. S'il est là malgré tout,
  // on l'honore (un conteneur qui en dit PLUS ne doit pas être puni) ; sinon
  // c'est l'empreinte globale, qui doit alors être présente et bien formée.
  if (aInventaire) return manifeste.fichiers!;
  if (typeof manifeste.empreinte !== "string" || !/^[0-9a-f]{64}$/.test(manifeste.empreinte))
    throw new ErreurMovpack("Manifeste incomplet : empreinte de bibliotheque.json manquante ou mal formée");
  return null;
}

export const LIMITES_MOVPACK = {
  /** `manifeste.json` / `bibliotheque.json` : accumulés en mémoire — bornés
   *  (une « zip bomb » vise précisément cette accumulation). */
  octetsPetitFichier: 64_000_000,
  /** Nombre d'entrées du ZIP (médias compris). */
  entreesMax: 4_096,
  /** Volume total DÉCOMPRESSÉ toléré, tous fichiers confondus. */
  octetsTotal: 8_000_000_000,
  /** Une IMAGE de couverture, seule (D-271). Les images ne passent pas par le
   *  puits des médias : elles s'ACCUMULENT en mémoire le temps de la lecture,
   *  parce qu'elles sont petites. Sans borne propre, elles héritaient de celle
   *  des « petits fichiers » (64 Mo chacune) — de quoi mettre un téléphone à
   *  genoux avec une archive hostile. Repère mesuré sur les six packs
   *  publiés : la plus grande image réelle fait **46 Ko**. */
  octetsImage: 4_000_000,
  /** Toutes les images d'un conteneur, cumulées en mémoire. Repère mesuré :
   *  le plus gros pack publié (karaté, 109 images) totalise **3,6 Mo**. */
  octetsImagesTotal: 32_000_000,
} as const;

/** Extensions de média acceptées dans une archive — la vidéo est le seul
 *  média-fichier du modèle ; « sans extension » = historique, accepté. */
export const EXTENSIONS_MEDIA_ARCHIVE = new Set(["webm", "mp4", "mov", "mkv", "3gp", "ogv", "avi"]);

/** Signatures d'EXÉCUTABLES — refusées quel que soit le nom du fichier
 *  (contrôle du type réel : une extension ne blanchit jamais le contenu). */
export function signatureExecutable(bloc: Uint8Array): string | null {
  if (bloc.length >= 2 && bloc[0] === 0x4d && bloc[1] === 0x5a) return "exécutable Windows (MZ)";
  if (bloc.length >= 4 && bloc[0] === 0x7f && bloc[1] === 0x45 && bloc[2] === 0x4c && bloc[3] === 0x46) return "exécutable ELF";
  if (bloc.length >= 2 && bloc[0] === 0x23 && bloc[1] === 0x21) return "script exécutable (#!)";
  return null;
}

/** Chemin d'entrée SÛR : relatif, segments non vides, sans `..`, sans
 *  antislash, sans caractère de contrôle, sans lecteur Windows. */
export function cheminEntreeSur(nom: string): boolean {
  if (!nom || nom.length > 512) return false;
  if (/[\u0000-\u001f\\]/.test(nom)) return false; // contrôle + antislash (chemin Windows)
  if (nom.startsWith("/") || /^[a-z]:/i.test(nom)) return false; // absolu / lecteur Windows
  return nom.split("/").every((s) => s.length > 0 && s !== "." && s !== "..");
}

/** Un média VÉRIFIÉ, déjà écrit dans le puits — jamais ses octets en mémoire. */
