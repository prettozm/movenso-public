/**
 * Migrations de schéma n → n+1, exécutées à l'ouverture (contrat §2.3).
 * Leçon V2 : un schéma versionné sans chemin de migration rejette ses propres
 * données futures. Le mécanisme existe donc dès la version 1, même vide.
 */

import type { Bibliotheque, Image } from "./modele.ts";
import { TYPES_RELATION_DEFAUT, VERSION_SCHEMA } from "./modele.ts";
import { sha256Hex } from "./sha256.ts";

/** Une image sortie de `bibliotheque.json` par la migration 5 → 6, octets
 *  compris. Le domaine ne fait aucune E/S : il rend les octets, et c'est
 *  l'appelant (stockage, import) qui décide où le fichier atterrit. */
export interface ImageDetachee extends Image {
  octets: Uint8Array;
}

export interface ResultatMigration {
  bibliotheque: Bibliotheque;
  /** Octets à écrire en fichiers `images/<id>` **avant** de persister la
   *  bibliothèque migrée : tant qu'ils ne sont pas posés, l'inventaire
   *  désigne des fichiers absents. Vide quand l'entrée est déjà en schéma 6. */
  imagesDetachees: ImageDetachee[];
}

type Migration = (donnees: Record<string, unknown>, detachees: ImageDetachee[]) => Record<string, unknown>;

/** Registre : MIGRATIONS[n] fait passer de la version n à n+1. */
const MIGRATIONS: Record<number, Migration> = {
  // 1 → 2 (D-020) : les types de relation deviennent des données (les quatre
  // types historiques sont semés — les relations existantes les référencent
  // déjà par id) ; les compositions apparaissent, vides.
  1: (d) => ({
    ...d,
    versionSchema: 2,
    typesRelation: TYPES_RELATION_DEFAUT.map((t) => ({ ...t })),
    compositions: [],
  }),
  // 2 -> 3 (lot 5 §4) : les favoris personnels apparaissent, vides — de purs
  // marque-pages vers des identités, rien d'autre ne change.
  2: (d) => ({
    ...d,
    versionSchema: 3,
    favoris: [],
  }),
  // 3 -> 4 (D-140) : les rôles sémantiques (D-136) sont rétro-appliqués aux
  // types de relation par défaut déjà persistés SANS rôle. Sans ça, l'écran
  // Relations les traite tous comme « peer » (placement Carte faussé, Explorer
  // réduit au seul « comparer », « Enchaîné depuis » jamais peuplé) sur les
  // installations antérieures à D-136. On ne touche qu'aux types par défaut, et
  // seulement quand le rôle manque — un choix éditorial explicite est préservé.
  3: (d) => ({
    ...d,
    versionSchema: 4,
    typesRelation: retroRolesDefaut(d["typesRelation"]),
  }),
  // 4 -> 5 (S4.2bis) : l'illustration de FAMILLE remonte sur la famille.
  //
  // Jusqu'ici le modèle ne connaissait d'image que par technique, donc une
  // carte de famille était RECOPIÉE sur chacune de ses techniques (D-244) :
  // 16 images du jujitsu occupaient 162 exemplaires, 12 du JJB en occupaient
  // 150. Une information a un lieu — la famille est ce lieu, la technique la
  // dérive à l'affichage.
  //
  // Règle de reconnaissance, volontairement conservatrice : une image est
  // « de famille » si elle est PARTAGÉE par au moins deux techniques d'une
  // MÊME famille. Une image unique à une technique n'est jamais déplacée —
  // c'est son illustration propre, et elle continue de primer.
  4: (d) => ({ ...d, versionSchema: 5, ...remonterImagesDeFamille(d) }),
  // 5 -> 6 (D-269) : les images quittent `bibliotheque.json` pour des FICHIERS.
  //
  // Jusqu'ici une couverture portait ses octets en base64, DANS l'état. Le
  // karaté y pesait 5,0 Mo pour 0,14 Mo de structure — or cet état est réécrit
  // en trois passes (temporaire, relecture, bascule) à CHAQUE sauvegarde :
  // 419 ms à vide, 3802 ms avec 12 Mo d'images (mesuré, D-268).
  //
  // Après migration, la couverture ne porte plus qu'une référence, et
  // l'inventaire `images` déclare chaque image une fois. Les octets sont
  // RENDUS à l'appelant : le domaine n'écrit aucun fichier.
  // `versionSchema` est posé APRÈS le détachement : celui-ci recopie tout
  // l'objet (parcours générique), donc il ramènerait l'ancienne version.
  5: (d, detachees) => ({ ...d, ...detacherImages(d, detachees), versionSchema: 6 }),
};

/** Préfixe d'une data-URL base64 : `data:<mime>;base64,`. Une couverture qui
 *  n'a pas cette forme n'est pas décodable — on ne devine pas son type. */
const PREFIXE_DATA_URL = /^data:([a-z]+\/[a-z0-9.+-]+);base64,/i;

/**
 * Sort chaque couverture `{ type: "image", dataUrl }` de l'état et la remplace
 * par `{ type: "fichier", imageId }`, en peuplant l'inventaire `images`.
 *
 * PARCOURS GÉNÉRIQUE, et c'est délibéré : une couverture ne vit pas qu'en
 * deux endroits — il y en a sur les techniques, sur les familles, et sur les
 * copies conservées par la CORBEILLE et par les FUSIONS réversibles. Énumérer
 * ces lieux à la main, c'est en oublier un le jour où un sixième apparaît, et
 * laisser derrière soi une couverture illisible. La reconnaissance est en
 * revanche stricte : `type === "image"` ET `dataUrl` de forme attendue.
 *
 * Une data-URL non décodable fait **disparaître** la couverture plutôt que de
 * produire un état invalide : ces octets-là n'étaient déjà pas affichables, et
 * la fiche retombe sur l'image de sa famille ou sur son initiale.
 */
function detacherImages(d: Record<string, unknown>, detachees: ImageDetachee[]): Record<string, unknown> {
  const inventaire = new Map<string, Image>();
  const parDataUrl = new Map<string, string | null>(); // dataUrl → imageId (null = indécodable)

  const identifier = (dataUrl: string): string | null => {
    const connu = parDataUrl.get(dataUrl);
    if (connu !== undefined) return connu;
    const entete = PREFIXE_DATA_URL.exec(dataUrl);
    let id: string | null = null;
    if (entete) {
      try {
        const binaire = atob(dataUrl.slice(entete[0].length));
        const octets = new Uint8Array(binaire.length);
        for (let i = 0; i < binaire.length; i++) octets[i] = binaire.charCodeAt(i);
        id = sha256Hex(octets); // l'identité EST le contenu : deux copies n'en font qu'une
        if (!inventaire.has(id)) {
          const image: Image = { id, mime: entete[1]!.toLowerCase(), taille: octets.length };
          inventaire.set(id, image);
          detachees.push({ ...image, octets });
        }
      } catch {
        id = null; // base64 corrompu — la couverture disparaît, l'état reste valide
      }
    }
    parDataUrl.set(dataUrl, id);
    return id;
  };

  const convertir = (noeud: unknown): unknown => {
    if (Array.isArray(noeud)) return noeud.map(convertir);
    if (!noeud || typeof noeud !== "object") return noeud;
    const o = noeud as Record<string, unknown>;
    if (o["type"] === "image" && typeof o["dataUrl"] === "string") {
      const id = identifier(o["dataUrl"]);
      return id === null ? undefined : { type: "fichier", imageId: id };
    }
    const copie: Record<string, unknown> = {};
    for (const [cle, valeur] of Object.entries(o)) {
      const converti = convertir(valeur);
      if (converti !== undefined) copie[cle] = converti;
    }
    return copie;
  };

  const converti = convertir(d) as Record<string, unknown>;
  // L'inventaire préexistant est conservé : une bibliothèque peut déjà porter
  // des images (import d'un pack en schéma 6 avant migration de l'état local).
  const deja = Array.isArray(d["images"]) ? (d["images"] as Image[]) : [];
  const fusionne = new Map(deja.filter((i) => i && typeof i.id === "string").map((i) => [i.id, i]));
  for (const [id, image] of inventaire) if (!fusionne.has(id)) fusionne.set(id, image);
  return { ...converti, images: [...fusionne.values()] };
}

/** Remonte sur chaque famille l'image que partagent au moins deux de ses
 *  techniques, et la retire de ces techniques. Défensif : les données migrées
 *  sont BRUTES (un pack tiers peut porter n'importe quoi), donc chaque forme
 *  inattendue est laissée telle quelle plutôt que corrigée au jugé. */
function remonterImagesDeFamille(d: Record<string, unknown>): Record<string, unknown> {
  const disciplines = d["disciplines"];
  const techniques = d["techniques"];
  if (!Array.isArray(disciplines) || !Array.isArray(techniques)) return {};

  const estObjet = (v: unknown): v is Record<string, unknown> =>
    typeof v === "object" && v !== null && !Array.isArray(v);
  const imageDe = (t: Record<string, unknown>): string | null => {
    const c = t["couverture"];
    return estObjet(c) && c["type"] === "image" && typeof c["dataUrl"] === "string" ? c["dataUrl"] : null;
  };

  // Combien de techniques partagent telle image, dans telle famille ?
  const parFamille = new Map<string, Map<string, number>>();
  for (const t of techniques) {
    if (!estObjet(t)) continue;
    const famille = t["familleId"];
    const image = imageDe(t);
    if (typeof famille !== "string" || !image) continue;
    if (!parFamille.has(famille)) parFamille.set(famille, new Map());
    const compte = parFamille.get(famille)!;
    compte.set(image, (compte.get(image) ?? 0) + 1);
  }

  // L'image de la famille est la plus partagée, à condition d'être partagée.
  const retenue = new Map<string, string>();
  for (const [famille, compte] of parFamille) {
    let gagnante: string | null = null;
    let max = 1; // strictement plus d'une technique
    for (const [image, n] of compte) if (n > max) { max = n; gagnante = image; }
    if (gagnante) retenue.set(famille, gagnante);
  }
  if (retenue.size === 0) return {};

  const disciplinesMaj = disciplines.map((disc) => {
    if (!estObjet(disc) || !Array.isArray(disc["familles"])) return disc;
    return {
      ...disc,
      familles: disc["familles"].map((f) => {
        if (!estObjet(f) || typeof f["id"] !== "string") return f;
        const image = retenue.get(f["id"]);
        // Une couverture déjà posée sur la famille n'est jamais écrasée.
        if (!image || f["couverture"] !== undefined) return f;
        return { ...f, couverture: { type: "image", dataUrl: image } };
      }),
    };
  });

  const techniquesMaj = techniques.map((t) => {
    if (!estObjet(t)) return t;
    const famille = t["familleId"];
    const image = imageDe(t);
    if (typeof famille !== "string" || !image || retenue.get(famille) !== image) return t;
    const { couverture: _retiree, ...reste } = t; // la technique dérive désormais de sa famille
    return reste;
  });

  return { disciplines: disciplinesMaj, techniques: techniquesMaj };
}

/** Rétro-applique `role` (et `ordre` si présent) aux types de relation par
 *  défaut dépourvus de rôle — par id stable, sans écraser un rôle déjà défini. */
function retroRolesDefaut(brut: unknown): unknown {
  if (!Array.isArray(brut)) return brut;
  const defauts = new Map(TYPES_RELATION_DEFAUT.map((t) => [t.id, t]));
  return brut.map((type) => {
    if (!type || typeof type !== "object" || Array.isArray(type)) return type;
    const t = type as Record<string, unknown>;
    const def = defauts.get(t["id"] as string);
    if (!def || t["role"] !== undefined) return type;
    return def.ordre !== undefined ? { ...t, role: def.role, ordre: def.ordre } : { ...t, role: def.role };
  });
}

export class ErreurMigration extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ErreurMigration";
  }
}

/**
 * Amène des données persistées à la version courante du schéma, et rend AVEC
 * elles les octets que la migration a sortis du JSON (schéma 6 : les images).
 * Ne valide pas les invariants métier : appeler validerBibliotheque ensuite.
 * `versionCible` n'est paramétrable que pour tester le mécanisme de chaîne.
 *
 * Deux entrées pour un seul mécanisme, et la distinction est volontaire :
 * `migrerBibliotheque` sert partout où les octets sont déjà là (une
 * revalidation, un rapport, un test) ; `migrerAvecImages` est OBLIGATOIRE
 * partout où l'état migré va être PERSISTÉ ou AFFICHÉ — sinon l'inventaire
 * désigne des fichiers que personne n'a écrits.
 */
export function migrerAvecImages(brut: unknown, versionCible: number = VERSION_SCHEMA): ResultatMigration {
  const imagesDetachees: ImageDetachee[] = [];
  const bibliotheque = migrer(brut, versionCible, imagesDetachees);
  return { bibliotheque, imagesDetachees };
}

/** Migration seule — les octets détachés sont ignorés. À n'employer que
 *  lorsqu'on ne persiste ni n'affiche le résultat (voir `migrerAvecImages`). */
export function migrerBibliotheque(brut: unknown, versionCible: number = VERSION_SCHEMA): Bibliotheque {
  return migrer(brut, versionCible, []);
}

function migrer(brut: unknown, versionCible: number, detachees: ImageDetachee[]): Bibliotheque {
  if (typeof brut !== "object" || brut === null) {
    throw new ErreurMigration("Données illisibles : la bibliothèque n'est pas un objet");
  }
  let donnees = brut as Record<string, unknown>;
  const versionLue = donnees["versionSchema"];
  if (typeof versionLue !== "number" || !Number.isInteger(versionLue) || versionLue < 1) {
    throw new ErreurMigration(`Version de schéma absente ou invalide : ${String(versionLue)}`);
  }
  let version: number = versionLue;
  if (version > versionCible) {
    throw new ErreurMigration(
      `Bibliothèque en version ${version}, plus récente que l'application (${versionCible}) — mettre à jour l'application plutôt que risquer une perte`,
    );
  }
  while (version < versionCible) {
    const migration = MIGRATIONS[version];
    if (!migration) {
      throw new ErreurMigration(`Aucune migration enregistrée depuis la version ${version}`);
    }
    donnees = migration(donnees, detachees);
    const suivante = donnees["versionSchema"];
    if (typeof suivante !== "number" || suivante !== version + 1) {
      throw new ErreurMigration(`La migration ${version} → ${version + 1} n'a pas incrémenté la version`);
    }
    version = suivante;
  }
  return donnees as unknown as Bibliotheque;
}

/** Visible pour les tests : permet d'enregistrer une migration factice. */
export function _enregistrerMigrationPourTests(depuis: number, m: Migration): () => void {
  MIGRATIONS[depuis] = m;
  return () => {
    delete MIGRATIONS[depuis];
  };
}
