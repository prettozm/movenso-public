/**
 * La bibliothèque est-elle VIERGE ? — l'état de première ouverture (D-328).
 *
 * Jusqu'ici l'écran de bienvenue se déclenchait sur « aucune discipline ET
 * aucune technique » (`vues.ts`), ce qui est plus faible que ce qu'il
 * prétend : une bibliothèque dont il ne reste qu'une composition, un favori,
 * une fiche en corbeille ou la trace d'un pack installé n'est pas neuve — et
 * elle recevait pourtant l'écran « bienvenue, choisis comment commencer ».
 *
 * Vierge veut dire ici : **rien n'est jamais arrivé**. Aucun pack installé,
 * aucune technique, aucune composition, aucun contenu importé ni restauré, et
 * aucune trace d'un contenu qui aurait existé (corbeille, fusions, conflits,
 * éditions de packs). L'écran de départ n'apparaît QUE là.
 *
 * La règle se lit sur la FORME de l'état plutôt que sur une liste de champs
 * recopiée ici : tout ce qui est une collection de la bibliothèque est du
 * contenu, sauf les exceptions nommées ci-dessous. Une liste recopiée aurait
 * été une seconde source de vérité — et une collection ajoutée demain y
 * aurait manqué en silence (D-253).
 */

import type { Bibliotheque } from "./modele.ts";

/** Les collections qui ne sont PAS du contenu. `typesRelation` est SEMÉ par
 *  `bibliothequeVide()` (quatre types par défaut) : il est là avant tout
 *  geste, il ne peut donc pas témoigner d'un contenu. Toute autre entrée
 *  ajoutée ici doit dire pourquoi elle n'est pas du contenu.
 *
 *  LIMITE DITE (D-339) : ce prédicat et sa garde ne connaissent que des
 *  COLLECTIONS. Une trace SCALAIRE — un futur `derniereRestaurationLe?:
 *  string` — témoignerait d'un contenu passé et échapperait aux deux. Ce n'est
 *  pas un défaut aujourd'hui, c'est la portée de ce que le fichier promet ;
 *  cela cessera de l'être le jour où une trace n'aura pas la forme d'une
 *  liste. Relevé par le checker, non construit (D-324). */
const COLLECTIONS_NEUTRES: ReadonlySet<string> = new Set(["typesRelation"]);

/** GARDE DE FORME (D-339) — la promesse ci-dessus est plus large que
 *  `Array.isArray` : une collection rangée demain en `Record` ou en `Map`
 *  sortirait du prédicat **en silence**, et une bibliothèque pleine passerait
 *  pour neuve. Rien dans le type ne l'interdisait ; ceci l'interdit.
 *
 *  Le jour où `Bibliotheque` gagne un champ objet qui n'est pas un tableau,
 *  `npm run typecheck` échoue en le NOMMANT — il faut alors étendre
 *  `bibliothequeVierge`, pas contourner la garde. Constat de relecture
 *  (D-280) : le code tenait une promesse plus étroite que son commentaire. */
type ChampsObjetNonTableau<T> = {
  [K in keyof T]-?: NonNullable<T[K]> extends object
    ? NonNullable<T[K]> extends readonly unknown[] ? never : K
    : never;
}[keyof T];
const _formeVerifiee: [ChampsObjetNonTableau<Bibliotheque>] extends [never] ? true
  : ["collection non tableau — étendre bibliothequeVierge", ChampsObjetNonTableau<Bibliotheque>] = true;
void _formeVerifiee;

/** true : rien n'a jamais été installé, créé, importé ni restauré ici. */
export function bibliothequeVierge(b: Bibliotheque): boolean {
  return Object.entries(b).every(
    ([cle, valeur]) => !Array.isArray(valeur) || COLLECTIONS_NEUTRES.has(cle) || valeur.length === 0,
  );
}
