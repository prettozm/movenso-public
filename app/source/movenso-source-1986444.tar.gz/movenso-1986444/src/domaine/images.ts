/**
 * Images de la bibliothèque (schéma 6, D-269) — fonctions PURES, testables en
 * Node. Pendant du registre des médias : la question qu'on se pose ici est la
 * même que pour une vidéo — « qui la référence encore ? » — parce que c'est
 * elle qui décide ce qu'on a le droit d'effacer.
 */

import type { Bibliotheque } from "./modele.ts";

/**
 * Ids des images encore RÉFÉRENCÉES par une couverture, où qu'elle se trouve.
 *
 * Le parcours est générique, et c'est la même raison qu'à la migration : une
 * couverture ne vit pas seulement sur les techniques et les familles — la
 * CORBEILLE en garde une copie tant qu'une fiche est restaurable (D-081), et
 * les FUSIONS réversibles aussi (D-101). Énumérer ces lieux à la main, c'est
 * finir par supprimer l'illustration d'une fiche qu'on pouvait encore
 * restaurer. Ici, oublier un lieu supprimerait des octets : on ne l'énumère
 * donc pas, on cherche partout.
 */
function imagesReferencees(b: Bibliotheque): Set<string> {
  const refs = new Set<string>();
  const visiter = (noeud: unknown): void => {
    if (Array.isArray(noeud)) return noeud.forEach(visiter);
    if (!noeud || typeof noeud !== "object") return;
    const o = noeud as Record<string, unknown>;
    if (o["type"] === "fichier" && typeof o["imageId"] === "string") {
      refs.add(o["imageId"]);
      return;
    }
    for (const valeur of Object.values(o)) visiter(valeur);
  };
  // L'inventaire lui-même est exclu du parcours : il DÉCLARE les images, il ne
  // les référence pas. L'y inclure rendrait toute image éternellement vivante.
  const { images: _inventaire, ...reste } = b;
  visiter(reste);
  return refs;
}

/** L'inventaire réduit aux images encore référencées. Rien n'est supprimé sur
 *  le disque ici — le domaine ne fait pas d'E/S ; le balayage des fichiers est
 *  une opération SÉPARÉE, et volontairement plus prudente. */
export function inventaireEpure(b: Bibliotheque): NonNullable<Bibliotheque["images"]> {
  const vivantes = imagesReferencees(b);
  return (b.images ?? []).filter((i) => vivantes.has(i.id));
}

/**
 * Fusionne l'inventaire d'un pack dans celui de `b` (MUTE `b`), épure, et rend
 * le nombre d'images RÉELLEMENT retenues.
 *
 * Deux packs qui publient la même illustration ne la déclarent qu'une fois :
 * l'entrée locale fait foi, elle décrit les mêmes octets (l'id EST l'empreinte).
 *
 * Le compte se lit APRÈS l'épuration, jamais à l'ajout — sinon il annonce des
 * images que l'épuration vient de retirer. Cas réel (D-306) : le judo réimporté
 * embarque 10 couvertures de familles ; la taxonomie rejoint les familles par
 * nom sans reprendre leur couverture, plus personne ne désigne ces images, et
 * les deux écrans d'import annonçaient « 10 image(s) ajoutée(s) » pour zéro
 * illustration nouvelle (verdict checker sur D-307).
 */
export function fusionnerInventaire(b: Bibliotheque, entrantes: Bibliotheque["images"]): number {
  const inventaire = new Map((b.images ?? []).map((i) => [i.id, i]));
  const neuves = new Set<string>();
  for (const i of entrantes ?? []) {
    if (!inventaire.has(i.id)) { inventaire.set(i.id, structuredClone(i)); neuves.add(i.id); }
  }
  b.images = inventaire.size ? [...inventaire.values()] : [];
  b.images = inventaireEpure(b);
  return b.images.filter((i) => neuves.has(i.id)).length;
}
