/**
 * Compositions (D-020.1) — « Ma spéciale », mes enchaînements, un programme…
 * Workflow vertical : créer → ajouter des blocs → réordonner → consulter →
 * modifier. Une composition référence les identités ; ses transitions sont
 * contextuelles, jamais des relations du graphe.
 */

import { html, nothing, type TemplateResult } from "lit";
import type { Bloc, Composition } from "../domaine/modele.ts";
import type { Temps } from "../domaine/composition.ts";
import {
  acteurDuBloc, acteurSuivantPropose, annonceCue, decouperEnTemps, dureeEnMots, dureeTotale, estLie,
  estJalon, formaterDuree, lectureEnTemps, nouveauBloc, reordonnerBloc, repartirTemps, retirerBloc, techniquesAPortee,
} from "../domaine/composition.ts";
import { chercherTechniques } from "../domaine/recherche.ts";
import { boutonsMonterDescendre, type ReordreParGlisser } from "./glisser.ts";
import type { MovensoApp } from "./racine.ts";
import { gabaritMedia, vignetteTechnique } from "./vues.ts";
import { apercuEtapes, barreActionsFiche, enteteFiche, origineLisible, statsCompo } from "./composition-fiche.ts";
import { anneauChrono, barreProgression, blocEnsuite, noterLecture, oublierLecture } from "./composition-lecteur.ts";
import { disciplinesPesees, listeCompositions, ouvrirOngletPacks } from "./compositions-liste.ts";

/* ---------- liste ---------- */

/** Recherche/filtres de la LISTE des compositions (retour porteur 2026-08-03,
 *  D-215) — état de session : requête (nom de compo OU nom de technique
 *  contenue) et filtre par NOM de discipline (déduit du contenu, dédupliqué
 *  par nom comme les niveaux D-127 ; « mixte » = plusieurs disciplines). */
const etatListeCompos: { requete: string; filtre: string | null } = { requete: "", filtre: null };

/** Normalisation tolérante (accents/traits/espaces) pour la loupe. */
function normaliser(s: string): string {
  return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

export function gabaritCompositions(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const toutes = [...b.compositions];
  // Loupe : le nom de la composition OU une technique qu'elle contient.
  const req = normaliser(etatListeCompos.requete.trim());
  const correspond = (c: Composition): boolean => {
    if (!req) return true;
    if (normaliser(c.nom).includes(req)) return true;
    return c.blocs.some((bloc) => {
      if (bloc.type !== "technique" || !bloc.techniqueId) return false;
      const t = app.technique(bloc.techniqueId);
      return !!t && (normaliser(t.nom).includes(req) || (t.nomTraditionnel ? normaliser(t.nomTraditionnel).includes(req) : false));
    });
  };
  // Une seule dérivation des disciplines d'une composition (D-253) : celle de
  // la liste, qui les PÈSE pour désigner la dominante — les chips n'en gardent
  // que les noms.
  const parCompo = new Map(toutes.map((c) => [c.id, disciplinesPesees(app, c).map((x) => x.nom)]));
  const filtre = (c: Composition): boolean => {
    if (!etatListeCompos.filtre) return true;
    const noms = parCompo.get(c.id) ?? [];
    if (etatListeCompos.filtre === "__mixte__") return noms.length > 1;
    return noms.includes(etatListeCompos.filtre);
  };
  const visibles = toutes.filter((c) => correspond(c) && filtre(c));
  // Chips = disciplines réellement représentées (par NOM), + « Mixte » si utile.
  const nomsDisc = [...new Set([...parCompo.values()].flat())].sort((a, z) => a.localeCompare(z, "fr"));
  const aMixte = [...parCompo.values()].some((n) => n.length > 1);
  // Recherche et chips portent sur LES DEUX onglets : ils passent en en-tête
  // de la liste (UI-1, D-320), qui décide ensuite du côté et de la densité.
  const entete = html`
    <label class="recherche compositions-recherche">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
      <input type="search" aria-label="Rechercher une composition ou une technique qu'elle contient"
        placeholder="Nom, ou technique contenue…" .value=${etatListeCompos.requete}
        @input=${(e: Event) => { etatListeCompos.requete = (e.target as HTMLInputElement).value; app.requestUpdate(); }}>
    </label>
    ${nomsDisc.length > 1 || aMixte
      ? html`<div class="chips-filtres compositions-chips" aria-label="Filtrer par discipline">
          ${nomsDisc.map((nom) => html`<button class="chip-filtre ${etatListeCompos.filtre === nom ? "actif" : ""}"
            @click=${() => { etatListeCompos.filtre = etatListeCompos.filtre === nom ? null : nom; app.requestUpdate(); }}>${nom}</button>`)}
          ${aMixte ? html`<button class="chip-filtre ${etatListeCompos.filtre === "__mixte__" ? "actif" : ""}"
            @click=${() => { etatListeCompos.filtre = etatListeCompos.filtre === "__mixte__" ? null : "__mixte__"; app.requestUpdate(); }}>Mixte</button>` : nothing}
        </div>`
      : nothing}`;
  const vide = html`<p class="fil-vide" style="padding-top:12px">Aucune composition ici${req ? html` pour « ${etatListeCompos.requete.trim()} »` : nothing} —
    <button class="lien-nu" @click=${() => { etatListeCompos.requete = ""; etatListeCompos.filtre = null; app.requestUpdate(); }}>tout réafficher</button>.</p>`;
  return html`
    <div class="ecran">
      ${toutes.length === 0
        ? html`<header class="marque"><div style="flex:1"><div class="nom">Compositions</div>
              <div class="devise">Tes enchaînements, programmes, séances…</div></div></header>
            <p class="fil-vide" style="padding-top:12px">
              Assemble et ordonne plusieurs techniques pour créer un enchaînement ou une séance.
              Touche <b>＋ Créer</b> en bas pour commencer.
            </p>`
        : listeCompositions(app, toutes, visibles, entete, vide)}
    </div>
  `;
}

/* ---------- création « en entonnoir » (D-126) : nom → ajout d'éléments ---------- */

export interface EtatCreationCompo {
  etape: "nom" | "roles" | "pas";
  nom: string;
  /** Renseigné dès l'étape « nom » validée : la composition existe alors en base. */
  compoId?: string;
  /** D-231 — noms des rôles EN COURS DE SAISIE (jamais proposés par l'app).
   *  Tableau vide = « Seul » ; les noms ne deviennent des acteurs qu'à la
   *  validation de l'étape, et seulement s'ils sont tous renseignés. */
  roles?: string[];
}

/** Sélecteur de durée façon CHRONO (D-126) : deux molettes minutes / secondes
 *  (des `<select>` natifs → défilement sur mobile, valeurs précises, sans
 *  plafond arbitraire) + un bouton « Aucune ». `set(undefined)` = aucune. */
function selecteurDuree(app: MovensoApp, sec: number | undefined, set: (s: number | undefined) => void): TemplateResult {
  const total = sec ?? 0;
  const mm = Math.floor(total / 60);
  const ss = total % 60;
  const options = (n: number, cur: number) =>
    Array.from({ length: n }, (_, i) => html`<option value=${i} ?selected=${i === cur}>${`${i}`.padStart(2, "0")}</option>`);
  const applique = (m: number, s: number) => { const t = m * 60 + s; set(t <= 0 ? undefined : t); app.requestUpdate(); };
  return html`
    <div class="duree-picker">
      <div class="duree-affiche">${sec === undefined ? "Aucune durée" : dureeEnMots(sec)}</div>
      <div class="duree-roues">
        <label class="duree-roue">min
          <select aria-label="Minutes" @change=${(e: Event) => applique(Number((e.target as HTMLSelectElement).value), ss)}>${options(61, mm)}</select>
        </label>
        <span class="duree-sep">:</span>
        <label class="duree-roue">s
          <select aria-label="Secondes" @change=${(e: Event) => applique(mm, Number((e.target as HTMLSelectElement).value))}>${options(60, ss)}</select>
        </label>
        <button type="button" class="duree-aucune ${sec === undefined ? "actif" : ""}" @click=${() => { set(undefined); app.requestUpdate(); }}>Aucune</button>
      </div>
    </div>`;
}

/** État de l'ajout d'un élément — TECHNIQUE ou SAISIE LIBRE (D-126). Partagé par
 *  l'entonnoir de création ET la feuille « Ajouter un élément » en lecture. */
const etatFunnel: {
  quoi: "technique" | "libre"; requete: string; techId: string | undefined; techNom: string;
  libre: string; dureeSec: number | undefined;
  /** D-227 — rôle choisi pour le PROCHAIN pas (`null` = neutre, « les deux »),
   *  et D-229 le lien avec le pas précédent. `acteurId` vaut `undefined` tant
   *  que l'utilisateur n'a pas choisi : la proposition alternée s'applique. */
  acteurId: string | null | undefined; lien: boolean;
} = {
  quoi: "technique", requete: "", techId: undefined, techNom: "", libre: "", dureeSec: undefined,
  acteurId: undefined, lien: false,
};
/** Quitte le mode édition d'une composition (UI-2, D-319) : ouvrir une
 *  composition, c'est la CONSULTER — le ✎ se redemande à chaque visite plutôt
 *  que de rester allumé en sourdine derrière une navigation. */
export function quitterEditionCompo(): void {
  compoEnEdition = null;
}

export function reinitFunnel(): void {
  etatFunnel.requete = ""; etatFunnel.techId = undefined; etatFunnel.techNom = "";
  etatFunnel.libre = ""; etatFunnel.dureeSec = undefined;
  etatFunnel.acteurId = undefined; etatFunnel.lien = false;
}

/** « Rejoint le temps précédent » (D-235) — la SEULE relation du modèle. Coché,
 *  le pas se joue EN MÊME TEMPS que le précédent ; décoché, il ouvre un temps.
 *  La simultanéité n'est plus une étiquette à lire : elle est le sens de
 *  partager un temps, et la mise en page la porte. La cause éventuelle
 *  (« en réponse au blocage ») se dit en consigne, en texte libre. */
function basculeLien(app: MovensoApp, coche: boolean, set: (v: boolean) => void, classe: string): TemplateResult {
  return html`
    <button class="chip-filtre bascule-lien ${classe} ${coche ? "actif" : ""}"
      role="switch" aria-checked=${coche} style="margin-top:10px"
      @click=${() => { set(!coche); app.requestUpdate(); }}>
      Rejoint le temps précédent
    </button>`;
}

/** Le libellé court d'un pas (pour les listes de l'entonnoir). */
function libellePas(app: MovensoApp, x: Bloc): string {
  if (x.type === "technique") return (x.techniqueId && app.technique(x.techniqueId)?.nom) || x.texte || "technique";
  if (x.type === "pause") return x.texte || "Pause";
  return x.texte || (x.dureeSec !== undefined ? formaterDuree(x.dureeSec) : "étape");
}

/** Corps d'ajout d'un élément (D-126) : le choix « une technique / une saisie
 *  libre », la recherche OU la zone de texte, la durée en PUCES rapides, et UN
 *  bouton « Ajouter » pour les deux. Réutilisé par l'entonnoir et la lecture. */
function corpsAjoutElement(app: MovensoApp, compoId: string): TemplateResult {
  const b = app.bibliotheque!;
  const compo = b.compositions.find((x) => x.id === compoId);
  const tech = etatFunnel.quoi === "technique";
  // UI-4 (D-322) : le champ vide n'est plus un cul-de-sac — à défaut de requête,
  // les techniques déjà sous la main (`techniquesAPortee`, dérivation PURE du
  // domaine, testée sans navigateur).
  const resultats = !tech ? [] : etatFunnel.requete.trim() ? chercherTechniques(b, etatFunnel.requete, 6) : techniquesAPortee(b, compo);
  const nomDiscipline = (id: string) => b.disciplines.find((d) => d.id === id)?.nom ?? "";
  const pret = tech ? etatFunnel.techId !== undefined : etatFunnel.libre.trim() !== "" || etatFunnel.dureeSec !== undefined;
  // Le contenu est POSÉ : une technique choisie, ou un texte saisi.
  const contenuChoisi = tech ? etatFunnel.techId !== undefined : etatFunnel.libre.trim() !== "";
  // D-227 : tant que l'utilisateur n'a rien choisi, on PROPOSE le rôle qui n'a
  // pas agi en dernier (une séquence à deux est alternée) — jamais imposé.
  const acteurs = compo?.acteurs ?? [];
  const acteurChoisi = etatFunnel.acteurId === undefined && compo ? acteurSuivantPropose(compo) ?? null : etatFunnel.acteurId ?? null;
  const ajouter = () => {
    const d = etatFunnel.dureeSec;
    // Le premier pas n'a rien à quoi se lier.
    const lien = (compo?.blocs.length ?? 0) > 0 && etatFunnel.lien;
    const roles = { ...(acteurChoisi ? { acteurId: acteurChoisi } : {}), ...(lien ? { lien: true } : {}) };
    if (tech) {
      if (!etatFunnel.techId) return;
      const id = etatFunnel.techId, nom = etatFunnel.techNom;
      void app.modifierComposition(compoId, (c) => c.blocs.push(nouveauBloc("technique", { techniqueId: id, texte: nom, ...(d !== undefined ? { dureeSec: d } : {}), ...roles })));
    } else {
      const texte = etatFunnel.libre.trim();
      if (!texte && d === undefined) return;
      // Une durée SEULE (sans texte) est une pause ; sinon une étape libre.
      const bloc = !texte && d !== undefined ? nouveauBloc("pause", { dureeSec: d, ...roles }) : nouveauBloc("etape", { ...(texte ? { texte } : {}), ...(d !== undefined ? { dureeSec: d } : {}), ...roles });
      void app.modifierComposition(compoId, (c) => c.blocs.push(bloc));
    }
    reinitFunnel();
    app.requestUpdate();
  };
  return html`
    <div class="toggle-quoi">
      <button class="chip-choix ${tech ? "actif" : ""}" @click=${() => { etatFunnel.quoi = "technique"; app.requestUpdate(); }}>Une technique</button>
      <button class="chip-choix ${!tech ? "actif" : ""}" @click=${() => { etatFunnel.quoi = "libre"; app.requestUpdate(); }}>Une saisie libre</button>
    </div>
    ${tech
      ? html`<div class="recherche" style="margin:8px 0 0">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
            <input placeholder="Chercher une technique…" aria-label="Chercher une technique" autocomplete="off" .value=${etatFunnel.requete}
                   @input=${(e: InputEvent) => { etatFunnel.requete = (e.target as HTMLInputElement).value; etatFunnel.techId = undefined; app.requestUpdate(); }}>
          </div>
          ${resultats.length
            ? html`<div class="resultats" style="padding:6px 0 0">
                ${resultats.map((t) => html`<button class="resultat ${etatFunnel.techId === t.id ? "actif" : ""}"
                    @click=${() => { etatFunnel.techId = t.id; etatFunnel.techNom = t.nom; etatFunnel.requete = t.nom; app.requestUpdate(); }}>
                    <span>${t.nom}</span><span class="jp">${t.nomTraditionnel ?? ""}</span><span class="fam">${nomDiscipline(t.disciplineId)}</span>
                  </button>`)}
              </div>`
            : nothing}`
      : html`<input class="champ-edition" style="margin-top:8px" placeholder="Décris l'étape (échauffement, transition, repère…)"
              .value=${etatFunnel.libre} aria-label="Saisie libre"
              @input=${(e: InputEvent) => { etatFunnel.libre = (e.target as HTMLInputElement).value; app.requestUpdate(); }}>`}
    ${acteurs.length && contenuChoisi
      ? html`<div class="section-titre" style="padding:12px 4px 4px">Qui agit</div>
          <div class="chips-filtres choix-acteur" style="flex-wrap:wrap; padding:0">
            ${acteurs.map(
              (a, i) => html`<button class="chip-filtre ${acteurChoisi === a.id ? "actif" : ""}" data-acteur-rang=${i + 1}
                @click=${() => { etatFunnel.acteurId = a.id; app.requestUpdate(); }}>${a.nom}</button>`,
            )}
            <button class="chip-filtre ${acteurChoisi === null ? "actif" : ""}"
              @click=${() => { etatFunnel.acteurId = null; app.requestUpdate(); }}>Tous</button>
          </div>`
      : nothing}
    ${(compo?.blocs.length ?? 0) > 0 && contenuChoisi
      ? basculeLien(app, etatFunnel.lien, (v) => { etatFunnel.lien = v; }, "choix-lien")
      : nothing}
    <!-- UI-4 (D-322) : les réglages n'arrivent QU'APRÈS le contenu — la feuille
         s'ouvrait sur deux molettes de durée avant qu'on ait choisi quoi ajouter.
         Exception assumée : en SAISIE LIBRE, une durée seule crée une pause — la
         durée y est un contenu, la masquer aurait retiré le seul chemin vers une
         pause. -->
    ${contenuChoisi || !tech
      ? html`<div class="section-titre" style="padding:12px 4px 4px">Durée (facultatif)</div>
          ${selecteurDuree(app, etatFunnel.dureeSec, (s) => { etatFunnel.dureeSec = s; app.requestUpdate(); })}`
      : nothing}
    <button class="bouton principal ajout-valider" ?disabled=${!pret} @click=${ajouter}>Ajouter</button>`;
}

export function gabaritCreationCompo(app: MovensoApp): TemplateResult {
  const etat = app.creationCompo!;
  return html`
    <div class="voile" @click=${() => { if (etat.etape === "pas") app.fermerCreationCompo(); else app.creationCompo = null; }}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Créer une composition">
      <div class="prise"></div>
      ${etat.etape === "nom" ? etapeNom(app, etat) : etat.etape === "roles" ? etapeRoles(app, etat) : etapePas(app, etat)}
    </div>`;
}

function etapeNom(app: MovensoApp, etat: EtatCreationCompo): TemplateResult {
  const pret = etat.nom.trim() !== "";
  const suivant = () => { if (pret) void app.creerCompositionFunnel(); };
  return html`
    <h2>Nouvelle composition</h2>
    <div class="geste">Donne-lui un nom — tu pourras tout changer ensuite.</div>
    <div class="creation-discipline" style="margin-top:8px">
      <input .value=${etat.nom} aria-label="Nom de la composition"
             @input=${(e: InputEvent) => (app.creationCompo = { ...etat, nom: (e.target as HTMLInputElement).value })}
             @keydown=${(e: KeyboardEvent) => { if (e.key === "Enter") suivant(); }}>
      <button class="bouton principal" ?disabled=${!pret} @click=${suivant}>Suivant</button>
    </div>
    <!-- UI-4 (D-322) : « partir d'une composition existante » n'était nommé
         nulle part — il fallait savoir aller sur l'onglet Packs. Aucune fonction
         nouvelle : dupliquer une composition ENTIÈRE existe (arbitrage porteur),
         on la rend trouvable depuis l'endroit où l'on crée. Et on ne l'offre que
         s'il y a vraiment une séance de pack au bout : proposer un chemin vide
         serait pire que de ne rien dire. -->
    ${app.bibliotheque!.compositions.some((c) => c.provenance !== "personnel")
      ? html`<button class="lien-nu depart-pack" @click=${() => { app.creationCompo = null; ouvrirOngletPacks(); app.ouvrirCompositions(); }}>
          Ou pars d'une séance de tes packs — duplique-la, puis adapte-la.
        </button>`
      : nothing}
    <div class="actions"><button class="bouton" @click=${() => (app.creationCompo = null)}>Annuler</button></div>`;
}

/** Étape « Qui pratique ? » de l'entonnoir (D-231, arbitrage porteur) : le
 *  choix se fait AVANT les pas, pour que chaque pas puisse dire qui agit dès sa
 *  création. « Seul » est le défaut et se passe d'un geste. Les noms sont
 *  SAISIS, jamais proposés : l'app ne connaît aucun vocabulaire de discipline. */
function etapeRoles(app: MovensoApp, etat: EtatCreationCompo): TemplateResult {
  const roles = etat.roles ?? [];
  const poser = (n: number) => { app.creationCompo = { ...etat, roles: Array.from({ length: n }, (_, i) => roles[i] ?? "") }; };
  const majNom = (i: number, v: string) => {
    const suite = [...roles]; suite[i] = v;
    app.creationCompo = { ...etat, roles: suite };
  };
  const pret = roles.length === 0 || (roles.length >= 2 && roles.every((n) => n.trim() !== ""));
  const choix = (libelle: string, actif: boolean, action: () => void) => html`
    <button class="chip-choix ${actif ? "actif" : ""}" @click=${() => { action(); app.requestUpdate(); }}>${libelle}</button>`;
  return html`
    <h2>Qui pratique ?</h2>
    <div class="geste">Tu pourras en ajouter ou en retirer plus tard.</div>
    <!-- Deux choix, pas trois (D-232) : « à plusieurs » commence à DEUX et
         « ＋ Ajouter un rôle » fait le reste — la troisième puce « Plus »
         n'ajoutait qu'un palier arbitraire. -->
    <div class="toggle-quoi choix-nombre-roles" style="margin-top:10px">
      ${choix("Seul", roles.length === 0, () => poser(0))}
      ${choix("À plusieurs", roles.length >= 2, () => poser(Math.max(2, roles.length)))}
    </div>
    ${roles.length
      ? html`<div class="acteurs-liste" style="margin-top:12px">
            ${roles.map((nom, i) => html`
              <div class="acteur-ligne">
                <span class="acteur-puce" data-acteur-rang=${i + 1} aria-hidden="true"></span>
                <input class="champ-mini nom-role" .value=${nom} placeholder="Nom du rôle" aria-label="Nom du rôle ${i + 1}"
                  @input=${(e: InputEvent) => majNom(i, (e.target as HTMLInputElement).value)}>
                ${roles.length > 2
                  ? html`<button class="bouton-icone" aria-label="Retirer ce rôle"
                      @click=${() => { app.creationCompo = { ...etat, roles: roles.filter((_, j) => j !== i) }; app.requestUpdate(); }}>✕</button>`
                  : nothing}
              </div>`)}
            ${roles.length >= 2
              ? html`<button class="chip-filtre acteur-ajouter"
                  @click=${() => { app.creationCompo = { ...etat, roles: [...roles, ""] }; app.requestUpdate(); }}>＋ Ajouter un rôle</button>`
              : nothing}
            ${roles.length > 2
              ? html`<div class="aide-largeur">Sur un écran étroit, la lecture se fait en une colonne — les temps restent.</div>`
              : nothing}
          </div>`
      : nothing}
    <div class="actions" style="margin-top:14px">
      <button class="bouton principal valider-roles" ?disabled=${!pret}
        @click=${() => void app.poserRolesFunnel(roles)}>Suivant</button>
    </div>`;
}

function etapePas(app: MovensoApp, etat: EtatCreationCompo): TemplateResult {
  const b = app.bibliotheque!;
  const compo = b.compositions.find((x) => x.id === etat.compoId);
  const pas = compo?.blocs ?? [];
  return html`
    <h2>${compo?.nom ?? "Composition"}</h2>
    <div class="geste">Ajoute tes éléments dans l'ordre.</div>
    ${pas.length
      ? html`<ol class="funnel-pas">${pas.map((x, i) => html`<li>${i + 1}. ${libellePas(app, x)}</li>`)}</ol>`
      : html`<p class="fil-vide" style="padding:6px 2px">Aucun élément pour l'instant.</p>`}
    ${corpsAjoutElement(app, etat.compoId!)}
    <div class="actions" style="margin-top:12px">
      <button class="bouton principal" @click=${() => app.fermerCreationCompo()}>Terminer</button>
    </div>`;
}

/* ---------- ajout d'un élément EN LECTURE (D-126) : feuille légère ---------- */

/** Feuille « Ajouter un élément » ouverte depuis la lecture d'une composition
 *  (sans passer par le crayon) : même corps que l'entonnoir — une technique ou
 *  une saisie libre, durée en puces. Chaque ajout reste dans la feuille. */
export function gabaritAjoutPas(app: MovensoApp): TemplateResult {
  const compoId = app.ajoutPas!;
  return html`
    <div class="voile" @click=${() => { app.ajoutPas = null; app.requestUpdate(); }}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Ajouter un élément">
      <div class="prise"></div>
      <h2>Ajouter un élément</h2>
      ${corpsAjoutElement(app, compoId)}
      <div class="actions" style="margin-top:12px">
        <button class="bouton" @click=${() => { app.ajoutPas = null; app.requestUpdate(); }}>Terminer</button>
      </div>
    </div>`;
}

/* ---------- édition UNITAIRE d'un pas (D-126) : mini-feuille par étape ---------- */

/** Mini-feuille d'édition d'UN pas, limitée à son type (D-126) : un pas
 *  technique → consigne + durée + remplacer ; une saisie libre → texte + durée.
 *  Objectif : rendre le crayon global inutile. Chaque champ persiste en direct. */
export function gabaritEditionPas(app: MovensoApp): TemplateResult {
  const { compoId, blocId } = app.editionPas!;
  const b = app.bibliotheque!;
  const bloc = b.compositions.find((x) => x.id === compoId)?.blocs.find((x) => x.id === blocId);
  const fermer = () => { app.editionPas = null; app.requestUpdate(); };
  if (!bloc) return html`<div class="voile" @click=${fermer}></div>`;
  const maj = (muter: (x: Bloc) => void) =>
    void app.modifierComposition(compoId, (c) => { const x = c.blocs.find((y) => y.id === blocId); if (x) muter(x); });
  const tech = bloc.type === "technique";
  const technique = tech && bloc.techniqueId ? app.technique(bloc.techniqueId) : undefined;
  const resultats = tech && etatFunnel.requete.trim() ? chercherTechniques(b, etatFunnel.requete, 6) : [];
  const nomDiscipline = (id: string) => b.disciplines.find((d) => d.id === id)?.nom ?? "";
  return html`
    <div class="voile" @click=${fermer}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Modifier le pas">
      <div class="prise"></div>
      <h2>${tech ? technique?.nom ?? "Technique" : bloc.type === "pause" ? "Pause" : "Étape"}</h2>
      ${tech
        ? html`<div class="section-titre" style="padding:4px 4px 2px">Consigne</div>
            <input class="champ-edition" placeholder="gauche et droite, sur le contre…" .value=${bloc.consigne ?? ""} aria-label="Consigne du pas"
              @change=${(e: Event) => maj((x) => { const v = (e.target as HTMLInputElement).value.trim(); if (v) x.consigne = v; else delete x.consigne; })}>
            <div class="section-titre" style="padding:10px 4px 2px">Remplacer la technique</div>
            <div class="recherche" style="margin:0">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
              <input placeholder="Chercher une technique…" aria-label="Chercher une technique" autocomplete="off" .value=${etatFunnel.requete}
                @input=${(e: InputEvent) => { etatFunnel.requete = (e.target as HTMLInputElement).value; app.requestUpdate(); }}>
            </div>
            ${resultats.length
              ? html`<div class="resultats" style="padding:6px 0 0">
                  ${resultats.map((t) => html`<button class="resultat" @click=${() => { etatFunnel.requete = ""; maj((x) => { x.techniqueId = t.id; x.texte = t.nom; }); }}>
                    <span>${t.nom}</span><span class="jp">${t.nomTraditionnel ?? ""}</span><span class="fam">${nomDiscipline(t.disciplineId)}</span>
                  </button>`)}
                </div>`
              : nothing}`
        : html`<div class="section-titre" style="padding:4px 4px 2px">Texte</div>
            <input class="champ-edition" placeholder="Décris l'étape…" .value=${bloc.texte ?? ""} aria-label="Texte du pas"
              @change=${(e: Event) => maj((x) => { const v = (e.target as HTMLInputElement).value.trim(); if (v) x.texte = v; else delete x.texte; })}>`}
      ${(app.bibliotheque!.compositions.find((x) => x.id === compoId)?.acteurs ?? []).length
        ? html`<div class="section-titre" style="padding:10px 4px 2px">Qui agit</div>
            <div class="chips-filtres edition-acteur" style="flex-wrap:wrap; padding:0">
              ${(app.bibliotheque!.compositions.find((x) => x.id === compoId)!.acteurs ?? []).map(
                (a, i) => html`<button class="chip-filtre ${bloc.acteurId === a.id ? "actif" : ""}" data-acteur-rang=${i + 1}
                  @click=${() => maj((x) => { x.acteurId = a.id; })}>${a.nom}</button>`,
              )}
              <button class="chip-filtre ${bloc.acteurId ? "" : "actif"}"
                @click=${() => maj((x) => { delete x.acteurId; })}>Tous</button>
            </div>`
        : nothing}
      ${(b.compositions.find((x) => x.id === compoId)?.blocs[0]?.id ?? blocId) !== blocId
        ? basculeLien(app, estLie(bloc), (v) => maj((x) => { if (v) x.lien = true; else delete x.lien; }), "edition-lien")
        : nothing}
      <div class="section-titre" style="padding:10px 4px 2px">Durée</div>
      ${selecteurDuree(app, bloc.dureeSec, (s) => maj((x) => { if (s === undefined) delete x.dureeSec; else x.dureeSec = s; }))}
      <div class="actions" style="margin-top:14px">
        <button class="action-danger" @click=${() => { fermer(); void app.modifierComposition(compoId, (c) => retirerBloc(c, blocId)); }}>Retirer ce pas</button>
        <button class="bouton principal" @click=${fermer}>Terminer</button>
      </div>
    </div>`;
}

/** Médias de PRÉSENTATION de la composition (D-124) — au niveau de l'objet,
 *  affichés en tête, jamais comme un pas de la séquence. */
function presentationComposition(app: MovensoApp, compo: Composition, edition: boolean): TemplateResult {
  const medias = compo.presentation?.medias ?? [];
  if (!medias.length) return html``;
  return html`
    <div class="composition-presentation">
      <div class="section-titre section-liste-titre" style="padding:8px 4px 2px">Présentation</div>
      <div class="presentation-medias">
        ${medias.map(
          (m) => html`<div class="presentation-media">
            ${gabaritMedia(app, m)}
            ${edition
              ? html`<button class="bouton-icone" aria-label="Retirer de la présentation" title="Retirer de la présentation"
                  @click=${() => void app.retirerMediaPresentation(compo.id, m.id)}>✕</button>`
              : nothing}
          </div>`,
        )}
      </div>
    </div>`;
}

/* ---------- une composition : consulter / modifier ---------- */

export function gabaritComposition(app: MovensoApp, compositionId: string): TemplateResult {
  const b = app.bibliotheque!;
  const compo = b.compositions.find((x) => x.id === compositionId);
  if (!compo) return html`<div class="ecran"><p class="fil-vide">Composition introuvable.</p></div>`;
  // Lire une AUTRE composition sort du mode édition : il ne suit jamais l'écran.
  if (compoEnEdition && compoEnEdition !== compositionId) compoEnEdition = null;
  const edition = compoEnEdition === compositionId;

  return html`
    <div class="ecran">
      <div class="barre fiche-barre">
        <button class="bouton-icone" aria-label="Retour" @click=${() => app.retour()}>
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M15 5l-7 7 7 7"/></svg>
        </button>
        <span class="contexte">Composition${origineLisible(compo) ? ` · ${origineLisible(compo)}` : ""}</span>
        <!-- Actions à DROITE, dans l'ordre d'une fiche technique : options (⋮) · (jouer) · partager.
             D-126 : plus de crayon — tout se modifie en place, le ⋮ ne garde QUE le hors-séquence
             (renommer, présentation d'ensemble, dupliquer, supprimer). -->
        <div class="fiche-actions">
          <!-- D-233 : édition GLOBALE. Le ✎ bascule tout l'écran — les outils
               de chaque pas et ses puces de rôle/lien apparaissent d'un coup,
               plutôt qu'une feuille par pas. En lecture, les cartes sont nues. -->
          <button class="bouton-icone basculer-edition ${edition ? "actif" : ""}"
            aria-label=${edition ? "Terminer l'édition" : "Modifier la composition"}
            aria-pressed=${edition} title=${edition ? "Terminer l'édition" : "Modifier la composition"}
            @click=${() => { compoEnEdition = edition ? null : compo.id; app.requestUpdate(); }}>${edition ? "✓" : "✎"}</button>
          <button class="bouton-icone menu-composition" aria-label="Options" title="Options de la composition"
            @click=${() => { app.menuComposition = compo.id; app.requestUpdate(); }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="5" r="1.9"/><circle cx="12" cy="12" r="1.9"/><circle cx="12" cy="19" r="1.9"/></svg>
          </button>
          <!-- Mode pas-à-pas (D-093) : lance le déroulé plein écran dès qu'il y a des blocs. -->
          ${compo.blocs.length > 0
            ? html`<button class="bouton-icone passer-en-revue" aria-label="Passer en revue" title="Passer en revue, pas à pas"
                @click=${() => app.demarrerEntrainement(compo.id)}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 5v14l12-7z"/></svg>
              </button>`
            : nothing}
          <!-- Partage natif du .movpack. -->
          <button class="bouton-icone partager-composition" aria-label="Partager" title="Partager la composition"
            @click=${() => void app.partagerComposition(compo.id)}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><circle cx="18" cy="5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="19" r="2.6"/><path d="M8.3 10.7l7.4-4.3M8.3 13.3l7.4 4.3"/></svg>
          </button>
        </div>
      </div>

      <!-- UI-2 (D-319) : en LECTURE, l'écran est une FICHE — identité, provenance,
           ce que ça dure, qui agit, aperçu des étapes, puis Démarrer / Dupliquer.
           En ÉDITION (✎), il redevient la surface de travail : c'est le geste
           explicite qui distingue consulter de modifier. -->
      ${!edition
        ? html`
            ${enteteFiche(app, compo)}
            ${presentationComposition(app, compo, false)}
            ${compo.blocs.length === 0
              ? html`<p class="fil-vide">Vide pour l'instant — touche <b>✎</b> puis <b>＋ Ajouter un élément</b>.</p>`
              : lectureEnTemps(compo)
                ? html`<h2 class="fiche-compo-section">Le déroulé</h2>${gabaritDialogue(app, compo, false)}`
                : apercuEtapes(app, compo)}
            ${barreActionsFiche(app, compo)}`
        : html`
            <div class="fiche-entete composition-titre-lecture"><h1>${compo.nom}</h1>
              ${compo.description ? html`<div class="jp" style="font-family:var(--ui)">${compo.description}</div>` : nothing}
              <!-- UI-3 (D-321) : ce résumé disait « 4 temps · Tori · Uke » juste
                   au-dessus du bandeau qui dit « 3 étapes · Tori · Uke ». Deux
                   lieux pour la même information, et deux chiffres qui se
                   contredisent à l'œil (un jalon fait un temps, pas une étape)
                   — exactement le piège de D-253. Les rôles vivent dans le
                   bandeau ; le nombre de TEMPS, qui n'est pas le nombre
                   d'étapes, le rejoint plutôt que de vivre à côté. -->
            </div>

            ${presentationComposition(app, compo, true)}

            <!-- UI-3 (D-321) : le bandeau de statistiques de la fiche, DÉRIVÉ,
                 remplace le solitaire « ⏱ Séance · 20 min » — l'éditeur ne
                 disait ni combien de pas ni qui agit. Même calcul, un seul
                 lieu (D-253), donc jamais deux chiffres qui divergent. -->
            ${statsCompo(compo)}

            ${compo.blocs.length === 0
              ? html`<p class="fil-vide">Vide pour l'instant — touche <b>＋ Ajouter un élément</b>.</p>`
              : nothing}

            ${lectureEnTemps(compo) && compo.blocs.length > 0
              ? gabaritDialogue(app, compo, edition)
              : html`<ol class="blocs blocs-timeline">
                  ${(() => {
                    // Numérotation CONTINUE (D-124 boucle 3) : chaque pas de la séquence
                    // porte son rang 1·2·3… (un segment minuté EST un pas). Les blocs média
                    // hérités (présentation d'avant D-124) ne sont pas numérotés.
                    // D-326 : un JALON ne consomme pas de rang — comme un bloc
                    // média. Sinon l'éditeur numérotait jusqu'à 26 là où la fiche
                    // annonce 21 étapes : un troisième compteur du même objet.
                    let pas = 0;
                    return compo.blocs.map((bloc) => gabaritBloc(app, compo, bloc, bloc.type === "media" || estJalon(bloc) ? 0 : ++pas, edition));
                  })()}
                </ol>`}

            <button class="bouton ajouter-pas-inline" @click=${() => { app.ajoutPas = compo.id; app.requestUpdate(); }}>
              ＋ Ajouter un élément
            </button>`}
    </div>
  `;
}

/** Menu « ⋮ » d'une composition (D-126) : le hors-séquence que l'édition inline
 *  ne couvre pas — renommer / décrire, présentation d'ensemble, dupliquer,
 *  supprimer. Remplace le crayon global. Tout persiste via `modifierComposition`
 *  (garde d'écriture PIN héritée). */
export function gabaritMenuComposition(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque;
  const compo = b?.compositions.find((x) => x.id === app.menuComposition);
  if (!compo) return html``;
  const fermer = () => { app.menuComposition = null; app.requestUpdate(); };
  return html`
    <div class="voile" @click=${fermer}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Options de la composition">
      <div class="prise"></div>
      <div class="section-titre" style="padding:4px 4px 2px">Renommer / décrire</div>
      <input class="champ-edition composition-titre" .value=${compo.nom} aria-label="Titre de la composition"
        @change=${(e: Event) => { const v = (e.target as HTMLInputElement).value.trim(); if (v) void app.modifierComposition(compo.id, (c) => (c.nom = v)); }}>
      <input class="champ-edition champ-description" .value=${compo.description ?? ""}
        placeholder="Description ou objectif (facultatif)" aria-label="Description"
        @change=${(e: Event) => { const v = (e.target as HTMLInputElement).value.trim(); void app.modifierComposition(compo.id, (c) => { if (v) c.description = v; else delete c.description; }); }}>
      ${sectionActeurs(app, compo)}
      ${presentationComposition(app, compo, true)}
      ${captureComposition(app, compo)}
      <div class="actions" style="margin-top:14px">
        <button class="bouton" @click=${() => { void app.dupliquerComposition(compo.id); fermer(); }}>Dupliquer</button>
        <button class="action-danger supprimer-composition"
          @click=${() =>
            // Lot 7 §2 : PIN d'abord, la confirmation destructive ENSUITE.
            app.autoriser("destruction_ou_sensible", `Saisis le PIN pour supprimer « ${compo.nom} ».`, () => {
              app.demanderConfirmation({
          titre: `Supprimer « ${compo.nom} » ?`,
          corps: "Tes techniques restent dans la bibliothèque — un point de restauration est conservé.",
          bouton: "Supprimer la composition",
          action: () => { void app.supprimerComposition(compo.id); },
        }); fermer();
            })}>Supprimer</button>
      </div>
      <button class="bouton principal" style="margin-top:10px" @click=${fermer}>Terminer</button>
    </div>`;
}

/** Nom du rôle EN COURS DE SAISIE dans le ⋮ (D-231) — état de session. L'app ne
 *  propose AUCUN nom : ni paire toute faite, ni « Rôle 3 » automatique. Un rôle
 *  n'existe qu'une fois nommé par l'utilisateur. */
let nouveauRole = "";

/** Rôles d'une composition à plusieurs (D-227/D-231), dans le menu ⋮ : le
 *  rattrapage d'une composition existante — la déclaration normale se fait dans
 *  l'entonnoir (« Qui pratique ? »), avant les pas. */
function sectionActeurs(app: MovensoApp, compo: Composition): TemplateResult {
  const acteurs = compo.acteurs ?? [];
  const ajouter = () => {
    const nom = nouveauRole.trim();
    if (!nom) return;
    nouveauRole = "";
    void app.modifierComposition(compo.id, (c) => {
      const rangs = (c.acteurs ?? []).map((a) => Number(a.id.replace(/\D/g, "")) || 0);
      (c.acteurs ??= []).push({ id: `r${Math.max(0, ...rangs) + 1}`, nom }); // jamais de collision après un retrait
    });
  };
  return html`
    <div class="section-titre" style="padding:12px 4px 2px">Rôles ${acteurs.length ? html`<span class="acteurs-compte">· ${acteurs.length}</span>` : nothing}</div>
    ${acteurs.length === 0
      ? html`<div class="aide" style="font-size:12px; color:var(--sourdine); padding:0 4px 6px">
            Une composition à plusieurs ? Nomme les rôles — chaque pas dira alors qui agit.
          </div>`
      : nothing}
      <div class="acteurs-liste">
            ${acteurs.map(
              (a, i) => html`<div class="acteur-ligne">
                <span class="acteur-puce" data-acteur-rang=${i + 1} aria-hidden="true"></span>
                <input class="champ-mini" .value=${a.nom} aria-label="Nom du rôle"
                  @change=${(e: Event) => {
                    const v = (e.target as HTMLInputElement).value.trim();
                    if (v) void app.modifierComposition(compo.id, (c) => { const x = c.acteurs?.find((y) => y.id === a.id); if (x) x.nom = v; });
                  }}>
                <button class="bouton-icone" aria-label="Retirer le rôle ${a.nom}" title="Retirer ce rôle"
                  @click=${() =>
                    app.demanderConfirmation({
                      titre: `Retirer le rôle « ${a.nom} » ?`,
                      corps: "Les pas qui lui étaient attribués redeviennent neutres — aucun pas n'est supprimé.",
                      bouton: "Retirer le rôle",
                      action: () => void app.modifierComposition(compo.id, (c) => {
                        c.acteurs = (c.acteurs ?? []).filter((y) => y.id !== a.id);
                        for (const bl of c.blocs) if (bl.acteurId === a.id) delete bl.acteurId;
                        if (c.acteurs.length === 0) delete c.acteurs;
                      }),
                    })}>✕</button>
              </div>`,
            )}
        <div class="acteur-ligne acteur-nouveau">
          <span class="acteur-puce" data-acteur-rang=${acteurs.length + 1} aria-hidden="true"></span>
          <input class="champ-mini nom-role" .value=${nouveauRole} placeholder="Nom du rôle" aria-label="Nom d'un nouveau rôle"
            @input=${(e: InputEvent) => { nouveauRole = (e.target as HTMLInputElement).value; app.requestUpdate(); }}
            @keydown=${(e: KeyboardEvent) => { if (e.key === "Enter") ajouter(); }}>
          <button class="chip-filtre acteur-ajouter" ?disabled=${nouveauRole.trim() === ""} @click=${ajouter}>＋ Ajouter</button>
        </div>
      </div>`;
}

/** Capturer une vidéo ou un lien qui PRÉSENTE la composition (D-124) — rangé au
 *  niveau de l'objet (`presentation`), jamais comme un pas de la séquence. */
function captureComposition(app: MovensoApp, compo: Composition): TemplateResult {
  return html`
    <div class="ajout-bloc capture-composition">
      <div class="section-titre" style="padding:12px 4px 2px">Présenter l'ensemble (démo complète, vidéo « moi »)</div>
      <div class="edition-actions">
        <button class="chip-filtre" @click=${() => {
          const champ = document.createElement("input");
          champ.type = "file"; champ.accept = "video/*";
          champ.onchange = () => { const f = champ.files?.[0]; if (f) void app.ajouterMediaPresentation(compo.id, { fichier: f }); };
          champ.click();
        }}>Vidéo de présentation</button>
        <button class="chip-filtre" @click=${() => {
          const lien = prompt("Coller un lien (YouTube ou autre) qui présente cette composition :");
          if (lien?.trim()) void app.ajouterMediaPresentation(compo.id, { lien });
        }}>Coller un lien</button>
      </div>
    </div>
  `;
}

/* ---------- mode entraînement (lot 5 §14-15) : pas-à-pas, lisible, sans administration ---------- */

export function gabaritEntrainement(app: MovensoApp, compositionId: string, index: number): TemplateResult {
  const b = app.bibliotheque!;
  const compo = b.compositions.find((x) => x.id === compositionId);
  if (!compo || compo.blocs.length === 0)
    return html`<div class="ecran"><p class="fil-vide">Composition introuvable.</p></div>`;
  // S2.2 : résumé de FIN de séance — durée réellement écoulée, fermeture nette.
  if (seance.resume && seance.compositionId === compositionId) {
    const r = seance.resume;
    return html`
      <div class="ecran entrainement entrainement-resume">
        <div class="entrainement-bloc" style="text-align:center">
          <div class="entrainement-prepa">Séance terminée ✓</div>
          <div class="entrainement-nom">${r.nom}</div>
          <div class="details" style="padding-top:8px">${r.blocs} pas parcourus · durée réalisée : ${formaterDuree(r.ecouleSec)}</div>
        </div>
        <div class="entrainement-actions" style="justify-content:center">
          <button class="bouton principal" @click=${() => { seance.resume = null; seance.compositionId = null; seance.debut = null; app.retour(); }}>Fermer</button>
        </div>
      </div>`;
  }
  // départ RÉEL de la séance : premier rendu de cette composition en pas-à-pas
  if (seance.compositionId !== compositionId) {
    seance.compositionId = compositionId;
    seance.debut = Date.now();
    seance.resume = null;
  }
  const i = Math.max(0, Math.min(index, compo.blocs.length - 1));
  const bloc = compo.blocs[i]!;
  const suivant = compo.blocs[i + 1];
  const technique = bloc.techniqueId ? app.technique(bloc.techniqueId) : undefined;
  const total = dureeTotale(compo);
  noterLecture(app, compositionId, i); // UI-6 (D-324) : où l'on en est, sans geste
  const aller = (vers: number) => {
    arreterChrono(); // navigation manuelle : on coupe le décompte du pas quitté
    app.ecran = { type: "entrainement", compositionId, index: vers }; // remplace, sans empiler
    window.scrollTo({ top: 0 });
  };
  const quitter = () => { stopperChrono(); seance.compositionId = null; seance.debut = null; app.retour(); }; // sortie anticipée : pas de résumé
  const consigne = bloc.type === "technique" && bloc.consigne ? html`<div class="entrainement-consigne">↳ ${bloc.consigne}</div>` : nothing;
  // Chrono de séance (D-125) : un pas minuté déroule sa durée puis passe seul au
  // suivant. Démarré/entretenu comme effet de rendu (garde par bloc.id), coupé à
  // la navigation manuelle et à « Quitter ». Un pas minuté est annoncé par le
  // chrono (préparation puis départ) ; un pas MANUEL est annoncé ici.
  const minute = bloc.dureeSec !== undefined;
  if (minute) assurerChrono(app, compo, bloc, i);
  else { if (chrono.blocId !== null) arreterChrono(); annoncerEntree(app, compo, bloc); }
  const enPrepa = minute && chrono.blocId === bloc.id && chrono.phase === "prepa";
  const transition = Math.max(0, Math.round(app.preferences.transitionSec ?? 3));
  // UI-5 (D-323) : l'anneau montre la part de la phase COURANTE qui reste. Ses
  // deux bornes se dérivent ici (préparation, ou durée du pas) — le chrono ne
  // gagne aucun champ, le moteur n'a pas bougé.
  const aMoi = chrono.blocId === bloc.id;
  const affichageChrono = minute
    ? enPrepa
      ? html`<div class="entrainement-prepa">Préparez-vous</div>
          ${anneauChrono(chrono.restant, transition,
            html`<div class="entrainement-chrono ${chrono.enMarche ? "" : "en-pause"}">${chrono.restant}</div>`)}`
      : anneauChrono(aMoi ? chrono.restant : bloc.dureeSec!, bloc.dureeSec!,
          html`<div class="entrainement-chrono ${chrono.enMarche ? "" : "en-pause"}">${mmss(aMoi ? chrono.restant : bloc.dureeSec!)}</div>`)
    : nothing;
  chrono.mode = app.preferences.sonSeance ?? "les-deux"; // le tic (setInterval) lit ce mode
  return html`
    <div class="ecran entrainement">
      <div class="entrainement-entete">
        <span class="entrainement-titre">${compo.nom}</span>
        <span class="entrainement-progression">${i + 1} / ${compo.blocs.length}${total > 0 ? html` · ⏱ ${formaterDuree(total)}` : nothing}</span>
      </div>
      ${barreProgression(i + 1, compo.blocs.length)}
      <div class="entrainement-bloc">
        <!-- D-227/D-229 : au bord du tatami, QUI agit se lit avant quoi. -->
        ${(() => {
          const a = acteurDuBloc(compo, bloc);
          const rang = a ? (compo.acteurs ?? []).findIndex((x) => x.id === a.id) + 1 : 0;
          return a || estLie(bloc)
            ? html`<div class="entrainement-roles">
                ${a ? html`<span class="bloc-acteur" data-acteur-rang=${rang}>${a.nom}</span>` : nothing}
                ${estLie(bloc) ? html`<span class="bloc-lien">en même temps que le pas précédent</span>` : nothing}
              </div>`
            : nothing;
        })()}
        ${bloc.type === "technique"
          ? technique
            ? html`<button class="entrainement-vignette-lien" title="Voir la fiche" @click=${() => app.ouvrirFiche(technique.id)}>
                  <div class="entrainement-vignette">${vignetteTechnique(app, technique)}</div>
                </button>
                <div class="entrainement-nom">${technique.nom}</div>
                ${technique.nomTraditionnel ? html`<div class="entrainement-jp">${technique.nomTraditionnel}</div>` : nothing}
                ${consigne}${affichageChrono}`
            : html`<div class="entrainement-nom sourdine">${bloc.texte ?? "Technique"} — indisponible</div>${affichageChrono}`
          : bloc.type === "media"
            ? html`<div class="entrainement-media">${bloc.medias.map((m) => gabaritMedia(app, m))}</div>`
            : html`<div class="entrainement-texte">${bloc.type === "pause" ? bloc.texte || "Pause" : bloc.texte || "Segment"}</div>${affichageChrono}`}
      </div>
      ${minute && !chrono.enMarche && chrono.pauseAuto && chrono.blocId === bloc.id
        ? html`<div class="entrainement-pause-auto">Séance mise en pause — l'app est passée en arrière-plan.</div>`
        : nothing}
      ${minute
        ? html`<div class="entrainement-chrono-controles">
            <button class="bouton" @click=${() => { chrono.enMarche = !chrono.enMarche; chrono.pauseAuto = false; app.requestUpdate(); }}>
              ${chrono.enMarche ? "⏸ Pause" : "▶ Reprendre"}
            </button>
            <button class="bouton entrainement-son" title="Retour sonore : voix + bips, voix seule, bips seuls, ou muet"
              @click=${() => { const m = ["les-deux", "voix", "bips", "muet"] as const; app.definirSonSeance(m[(m.indexOf(chrono.mode) + 1) % m.length]!); }}>
              ${chrono.mode === "les-deux" ? "🔊 Voix + bips" : chrono.mode === "voix" ? "🗣 Voix" : chrono.mode === "bips" ? "🔔 Bips" : "🔇 Muet"}
            </button>
            <button class="bouton" title="Transition de préparation avant chaque pas minuté"
              @click=${() => { const p = [0, 3, 5, 10]; app.definirTransition(p[(p.indexOf(transition) + 1) % p.length]!); }}>
              ${transition > 0 ? `⏳ Prépa ${transition}s` : "⏳ Prépa off"}
            </button>
          </div>`
        : nothing}
      ${suivant ? blocEnsuite(app, compo, bloc, suivant) : nothing}
      <div class="entrainement-actions">
        <button class="bouton" ?disabled=${i === 0} @click=${() => aller(i - 1)}>← Précédent</button>
        <button class="bouton" @click=${quitter}>Quitter</button>
        ${i === compo.blocs.length - 1
          ? html`<button class="bouton principal" @click=${() => terminerSeance(app, compo)}>Terminer</button>`
          : html`<button class="bouton principal" @click=${() => aller(i + 1)}>Suivant →</button>`}
      </div>
    </div>
  `;
}

/* ---------- chrono de séance (D-125) : décompte + passage auto + pause + son ---------- */

type SonMode = "les-deux" | "voix" | "bips" | "muet";
interface Chrono {
  blocId: string | null; // le pas actuellement minuté
  phase: "prepa" | "actif"; // préparation (« Préparez-vous ») puis décompte du pas
  restant: number; // secondes restantes dans la phase courante
  enMarche: boolean; // faux = en pause
  pauseAuto: boolean; // vrai = pause posée par le passage en arrière-plan (S2.3/D-170)
  mode: SonMode; // retour sonore : voix + bips / voix / bips / muet
  annonce: string | null; // dernier pas annoncé à l'entrée (garde anti-répétition)
  timer: number | null;
}
const chrono: Chrono = { blocId: null, phase: "actif", restant: 0, enMarche: true, pauseAuto: false, mode: "les-deux", annonce: null, timer: null };

/* ---------- arrière-plan (S2.3/D-170) : séance SUSPENDUE + écran maintenu ---------- */

/** Chrome bride les minuteurs d'un onglet caché (le décompte dérive « selon
 *  les cas », recette Samsung A36) : plutôt qu'une fausse promesse, l'app
 *  cachée ou verrouillée SUSPEND la séance — même pause que le bouton, voix
 *  coupée net, reprise d'un geste au retour. Appelé par la racine sur
 *  `visibilitychange` → hidden pendant l'entraînement. */
export function suspendreSeance(app: MovensoApp): void {
  if (chrono.blocId === null || !chrono.enMarche) return;
  chrono.enMarche = false;
  chrono.pauseAuto = true;
  arreterVoix();
  app.requestUpdate();
}

/** Verrou d'écran (Screen Wake Lock) posé pendant l'entraînement : l'écran ne
 *  s'éteint pas tout seul en pleine série — la suspension n'arrive que si
 *  l'utilisateur verrouille ou change d'app LUI-MÊME. Relâché par la racine à
 *  la sortie de l'écran ; le navigateur le relâche seul quand l'app se cache
 *  (on le redemande au retour). Silencieux si l'API manque (la séance reste
 *  utilisable, l'écran suit alors le réglage système). */
let verrouEcran: WakeLockSentinel | null = null;

export async function maintenirEcranSeance(): Promise<void> {
  if (!("wakeLock" in navigator)) return;
  if (verrouEcran && !verrouEcran.released) return;
  try { verrouEcran = await navigator.wakeLock.request("screen"); } catch { verrouEcran = null; }
}

export function relacherEcranSeance(): void {
  void verrouEcran?.release().catch(() => {});
  verrouEcran = null;
}

/** Séance en cours (S2.2/D-169) : départ RÉEL (horloge murale) et résumé de
 *  fin — le résumé ne récompense que la fin réelle, jamais une sortie. */
const seance: { compositionId: string | null; debut: number | null; resume: { nom: string; blocs: number; ecouleSec: number } | null } =
  { compositionId: null, debut: null, resume: null };

/** Réinitialise le suivi de séance (S2.2) — appelé au DÉMARRAGE d'une revue
 *  (racine.demarrerEntrainement) : la durée réalisée repart toujours de zéro,
 *  même après une sortie par le retour Android. */
export function reinitialiserSeance(): void {
  seance.compositionId = null;
  seance.debut = null;
  seance.resume = null;
}

/** Fin de séance (S2.2) : coupe TOUT (chrono, voix, bips à venir), annonce la
 *  fin, et bascule sur le résumé minimal — durée réellement écoulée. */
function terminerSeance(app: MovensoApp, compo: Composition): void {
  const ecouleSec = seance.debut ? Math.max(0, Math.round((Date.now() - seance.debut) / 1000)) : 0;
  stopperChrono();
  annoncer("Séance terminée");
  bip(660, 380);
  seance.resume = { nom: compo.nom, blocs: compo.blocs.length, ecouleSec };
  oublierLecture(app); // UI-6 (D-324) : terminée ≠ interrompue — rien à reprendre
  app.requestUpdate();
}
let audioCtx: AudioContext | null = null;
const voixActive = (): boolean => chrono.mode === "les-deux" || chrono.mode === "voix";
const bipsActifs = (): boolean => chrono.mode === "les-deux" || chrono.mode === "bips";

/** mm:ss d'un décompte. */
function mmss(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  return `${Math.floor(s / 60)}:${`${s % 60}`.padStart(2, "0")}`;
}

/** Bip court (Web Audio, hors-ligne, CSP-safe) — la couche sonore FIABLE, qui
 *  sonne même sans moteur vocal. Silencieux si le son est coupé ou si l'audio
 *  est indisponible (headless, refus). */
function bip(freq = 880, dureeMs = 120, volume = 0.18): void {
  if (!bipsActifs()) return;
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx ??= new AC();
    void audioCtx.resume?.();
    const t = audioCtx.currentTime;
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = "sine";
    o.frequency.value = freq;
    o.connect(g);
    g.connect(audioCtx.destination);
    g.gain.setValueAtTime(volume, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dureeMs / 1000);
    o.start(t);
    o.stop(t + dureeMs / 1000);
  } catch {
    /* pas d'audio : le chrono reste visuel */
  }
}

/** Le nom parlé d'un pas (D-125) : le nom de la technique, le libellé du segment,
 *  ou « Pause » par défaut pour un repos. Sur une composition à plusieurs, la
 *  voix dit d'abord le LIEN puis le RÔLE (D-227/D-229) — au bord du tatami,
 *  « en même temps, Uke, tai-sabaki » est ce qui manque le plus. */
function nomParle(app: MovensoApp, compo: Composition, bloc: Bloc): string {
  const nom =
    bloc.type === "technique" ? (bloc.techniqueId && app.technique(bloc.techniqueId)?.nom) || bloc.texte || "technique"
    : bloc.type === "pause" ? bloc.texte?.trim() || "Pause"
    : bloc.texte?.trim() || "segment";
  const acteur = acteurDuBloc(compo, bloc);
  const lien = estLie(bloc) ? "en même temps" : undefined;
  return [lien, acteur?.nom, nom].filter(Boolean).join(", ");
}

/** Prononce un texte (D-125). Sur Android (Capacitor), passe par le **TTS
 *  NATIF** (`@capacitor-community/text-to-speech`) — la WebView Android
 *  n'implémente pas l'API Web Speech, d'où le silence vocal malgré un moteur
 *  TTS système. Sur le web, repli sur `speechSynthesis`. Silencieux si rien
 *  n'est disponible (les bips assurent alors le retour sonore). */
async function parler(texte: string): Promise<void> {
  try {
    const cap = (window as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
    if (cap?.isNativePlatform?.()) {
      const { TextToSpeech } = await import("@capacitor-community/text-to-speech");
      await TextToSpeech.speak({ text: texte, lang: "fr-FR", rate: 1.0 });
      return;
    }
  } catch {
    /* plugin natif indisponible : on tente le web ci-dessous */
  }
  try {
    const synth = window.speechSynthesis;
    if (!synth) return;
    if (synth.paused) synth.resume();
    const u = new SpeechSynthesisUtterance(texte);
    u.lang = "fr-FR";
    synth.speak(u);
  } catch {
    /* pas de synthèse vocale : les bips assurent le retour sonore */
  }
}

/** Annonce vocale (D-125), silencieuse si la voix est désactivée. Journalise
 *  dans `window.__voix` quand ce tableau existe — vérification e2e DÉTERMINISTE
 *  sans dépendre d'un vrai rendu audio. */
function annoncer(texte: string): void {
  if (!voixActive() || !texte) return;
  const w = window as unknown as { __voix?: string[] };
  if (Array.isArray(w.__voix)) w.__voix.push(texte);
  void parler(texte);
}

/** Annonce l'ENTRÉE sur un pas (nom + durée éventuelle), une seule fois par pas.
 *  Utilisé pour les pas MANUELS (non minutés) ; les pas minutés sont annoncés
 *  par le chrono lui-même (préparation puis départ). */
function annoncerEntree(app: MovensoApp, compo: Composition, bloc: Bloc): void {
  if (chrono.annonce === bloc.id) return;
  chrono.annonce = bloc.id;
  annoncer(nomParle(app, compo, bloc));
}

function arreterChrono(): void {
  if (chrono.timer !== null) {
    clearInterval(chrono.timer);
    chrono.timer = null;
  }
  chrono.blocId = null;
}

/** Coupe toute voix en cours (web + TTS natif) — à la sortie du pas-à-pas. */
function arreterVoix(): void {
  try { window.speechSynthesis?.cancel(); } catch { /* pas de synthèse web */ }
  try {
    const cap = (window as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
    if (cap?.isNativePlatform?.())
      void import("@capacitor-community/text-to-speech").then((m) => m.TextToSpeech.stop()).catch(() => {});
  } catch { /* plugin natif absent */ }
}

/** Arrêt COMPLET du pas-à-pas (D-126) : décompte + voix. Appelé à toute sortie
 *  de l'écran d'entraînement (« Quitter », retour Android, changement d'onglet,
 *  ouverture d'une fiche…) — plus jamais de son ni de timer qui traîne. */
export function stopperChrono(): void {
  arreterChrono();
  chrono.annonce = null;
  arreterVoix();
}

/** Démarre (ou laisse tourner) le décompte du pas minuté courant. Idempotent :
 *  ne réarme pas tant qu'on reste sur le même pas. Une transition de
 *  PRÉPARATION (« Préparez-vous », décompte 3-2-1) précède le pas si le réglage
 *  `transitionSec` > 0 (défaut 3 s) — jamais sur un pas manuel. */
function assurerChrono(app: MovensoApp, compo: Composition, bloc: Bloc, index: number): void {
  if (bloc.dureeSec === undefined || chrono.blocId === bloc.id) return;
  arreterChrono();
  chrono.blocId = bloc.id;
  chrono.annonce = bloc.id; // le chrono possède l'annonce de ce pas
  chrono.enMarche = true;
  chrono.pauseAuto = false;
  const dureeSec = Math.max(1, Math.round(bloc.dureeSec));
  const prepa = Math.max(0, Math.round(app.preferences.transitionSec ?? 3));
  const nom = nomParle(app, compo, bloc);
  if (prepa > 0) {
    chrono.phase = "prepa";
    chrono.restant = prepa;
    annoncer(`Préparez-vous. ${nom}`);
    bip(520, 90);
  } else {
    chrono.phase = "actif";
    chrono.restant = dureeSec;
    annoncer(`${nom}, ${dureeEnMots(dureeSec)}`);
  }
  chrono.timer = window.setInterval(() => {
    // Sortie par n'importe quel chemin : on coupe TOUT (jamais d'auto-avance
    // qui ré-ouvrirait le player, ni de son résiduel).
    if (app.ecran.type !== "entrainement" || app.ecran.compositionId !== compo.id) { stopperChrono(); return; }
    if (chrono.blocId !== bloc.id || !chrono.enMarche) return; // pas quitté ou en pause
    chrono.restant -= 1;
    if (chrono.phase === "prepa") {
      if (chrono.restant > 0) { bip(520, 90); app.requestUpdate(); return; } // 3-2-1
      chrono.phase = "actif";
      chrono.restant = dureeSec;
      annoncer(`${nom}, ${dureeEnMots(dureeSec)}`);
      bip(720, 160); // départ
      app.requestUpdate();
      return;
    }
    if (chrono.restant > 0) {
      const cue = annonceCue(dureeSec, chrono.restant);
      if (cue) annoncer(cue);
      if (chrono.restant <= 3) bip(880, 90); // décompte final audible même sans voix
      app.requestUpdate();
      return;
    }
    bip(440, 380); // fin du pas
    arreterChrono();
    if (index + 1 < compo.blocs.length) app.ecran = { type: "entrainement", compositionId: compo.id, index: index + 1 };
    else terminerSeance(app, compo); // S2.2 : le dernier pas minuté conclut la séance
    app.requestUpdate();
  }, 1000);
}

/** Nom lisible d'un bloc — pour les libellés et annonces du réordonnancement (S2.9). */
function nomBloc(app: MovensoApp, compo: Composition, blocId: string): string {
  const x = compo.blocs.find((y) => y.id === blocId);
  if (!x) return "le pas";
  if (x.type === "technique") return (x.techniqueId ? app.technique(x.techniqueId)?.nom : undefined) ?? x.texte ?? "la technique";
  if (x.type === "pause") return x.texte || "la pause";
  if (x.type === "media") return "le média";
  return x.texte || "l'étape";
}

/** Alternatives au glisser pour les blocs (S2.9) : mêmes primitives que le
 *  glisser (réordonner en mémoire + persistance neutre via la transaction
 *  habituelle), consommées par les flèches clavier et les boutons ▲/▼. */
function optsReordreBloc(app: MovensoApp, compo: Composition): ReordreParGlisser {
  return {
    reordonner: (id, cible) => {
      const c = app.bibliotheque?.compositions.find((x) => x.id === compo.id);
      if (c) reordonnerBloc(c, id, cible);
    },
    enregistrer: () => void app.modifierComposition(compo.id, () => {}),
    ordre: () => compo.blocs.map((x) => x.id),
    nom: (id) => nomBloc(app, compo, id),
  };
}

/* ---------- lecture en TRAME PAR TEMPS (D-229, généralisée D-231) ---------- */

/** Une composition à rôles se lit comme une TRAME : l'axe de gauche numérote les
 *  TEMPS, et chaque rôle tient sa VOIE — nommé une seule fois, en tête de voie.
 *  Le nombre de voies affichées n'est pas décidé ici (arbitrage porteur D-231) :
 *  on en déclare autant qu'il y a de rôles et c'est la LARGEUR DISPONIBLE qui
 *  tranche, en CSS. Quand elles ne tiennent pas, tout se replie en une colonne
 *  et le nom du rôle réapparaît sur chaque carte — les temps, eux, restent. */
function gabaritDialogue(app: MovensoApp, compo: Composition, edition: boolean): TemplateResult {
  const acteurs = compo.acteurs ?? [];
  const temps = decouperEnTemps(compo);
  // Au-delà de six rôles, aucune largeur ne tient : une colonne, toujours.
  const voies = acteurs.length > 6 ? "max" : String(acteurs.length);
  return html`
    <div class="dialogue ${edition ? "edition" : ""}" data-roles=${voies} style=${`--voies:${Math.max(1, acteurs.length)}`}>
      ${acteurs.length
        ? html`<div class="dialogue-entete">
            <span aria-hidden="true"></span>
            ${acteurs.map((a, i) => html`<span class="dialogue-role" data-acteur-rang=${i + 1}>${a.nom}</span>`)}
          </div>`
        : nothing}
      <ol class="dialogue-temps">
        ${temps.map((t) => gabaritTemps(app, compo, t, edition))}
      </ol>
    </div>`;
}

/** Un TEMPS : son numéro sur l'axe, puis les cartes de chaque rôle dans sa voie.
 *  Un pas neutre (consigne, pause, « tous ») traverse toute la largeur. */
function gabaritTemps(app: MovensoApp, compo: Composition, temps: Temps, edition: boolean): TemplateResult {
  const { colonnes, neutres } = repartirTemps(compo, temps);
  return html`
    <li class="temps" data-temps=${temps.numero}>
      <div class="temps-grille">
        <span class="temps-numero" aria-label="Temps ${temps.numero}">${temps.numero}</span>
        ${colonnes.map((blocs, i) => html`
          <div class="temps-colonne" data-acteur-rang=${i + 1}>
            ${blocs.map((bloc) => carteDialogue(app, compo, bloc, i + 1, edition))}
          </div>`)}
        ${neutres.length
          ? html`<div class="temps-neutres">${neutres.map((bloc) => carteDialogue(app, compo, bloc, 0, edition))}</div>`
          : nothing}
      </div>
    </li>`;
}

/** Une carte de la trame. Le nom du rôle y est TOUJOURS présent (D-231) : lu par
 *  les lecteurs d'écran quand la voie l'affiche déjà, VISIBLE dès que la trame
 *  se replie en une colonne — la couleur ne porte jamais seule l'information
 *  (WCAG 1.4.1). Les outils d'édition inline (D-126) restent au complet. */
function carteDialogue(app: MovensoApp, compo: Composition, bloc: Bloc, rang: number, edition: boolean): TemplateResult {
  const technique = bloc.techniqueId ? app.technique(bloc.techniqueId) : undefined;
  const acteur = acteurDuBloc(compo, bloc);
  const corps =
    bloc.type === "technique"
      ? technique
        ? html`<button class="trame-technique" @click=${() => app.ouvrirFiche(technique.id)}>
            ${vignetteTechnique(app, technique)}<span class="bloc-nom">${technique.nom}</span>
          </button>`
        : html`<span class="puce-liaison absente">${bloc.texte ?? "technique"} — indisponible</span>`
      : bloc.type === "media"
        ? html`<span class="bloc-media-corps">${bloc.medias.map((m) => gabaritMedia(app, m))}</span>`
        : html`<span class="bloc-texte">${bloc.type === "pause" ? bloc.texte || "Pause" : bloc.texte}</span>`;
  return html`
    <div class="bloc carte-dialogue ${bloc.type}" data-bloc-id=${bloc.id} data-acteur-rang=${rang || nothing}>
      <!-- D-235 : aucun glyphe, aucun mot de liaison. La rangée dit le temps,
           la colonne dit qui. Le nom du rôle reste TOUJOURS dans le DOM. -->
      ${acteur ? html`<span class="carte-entete"><span class="carte-role">${acteur.nom}</span></span>` : nothing}
      ${corps}
      ${bloc.consigne ? html`<span class="bloc-consigne">↳ ${bloc.consigne}</span>` : nothing}
      ${bloc.dureeSec !== undefined ? html`<span class="bloc-duree">⏱ ${formaterDuree(bloc.dureeSec)}</span>` : nothing}
      ${edition ? reglagesDuPas(app, compo, bloc) : nothing}
    </div>`;
}

/** Réglages d'un pas EN MODE ÉDITION (D-233) : qui agit, le lien avec le pas
 *  précédent, l'ordre, la feuille détaillée et le retrait — tout sur une ligne,
 *  sur CHAQUE pas à la fois. C'est l'édition « globale » demandée : on corrige
 *  une composition entière sans ouvrir une feuille par pas. Les listes natives
 *  tiennent en une ligne là où des puces déborderaient d'une voie. */
function reglagesDuPas(app: MovensoApp, compo: Composition, bloc: Bloc): TemplateResult {
  const acteurs = compo.acteurs ?? [];
  const premier = compo.blocs[0]?.id === bloc.id;
  const maj = (muter: (x: Bloc) => void) =>
    void app.modifierComposition(compo.id, (c) => { const x = c.blocs.find((y) => y.id === bloc.id); if (x) muter(x); });
  return html`
    <div class="pas-reglages">
      ${acteurs.length
        ? html`<span class="reglage-champ">
            <select class="reglage-acteur" aria-label="Qui agit"
              @change=${(e: Event) => { const v = (e.target as HTMLSelectElement).value;
                maj((x) => { if (v) x.acteurId = v; else delete x.acteurId; }); }}>
              <option value="" ?selected=${!bloc.acteurId}>Tous</option>
              ${acteurs.map((a) => html`<option value=${a.id} ?selected=${bloc.acteurId === a.id}>${a.nom}</option>`)}
            </select></span>`
        : nothing}
      ${!premier
        ? html`<button class="chip-filtre reglage-lien ${estLie(bloc) ? "actif" : ""}"
            role="switch" aria-checked=${estLie(bloc)} aria-label="Rejoint le temps précédent"
            title="Rejoint le temps précédent — ce pas se joue en même temps"
            @click=${() => maj((x) => { if (estLie(bloc)) delete x.lien; else x.lien = true; })}>
            ${estLie(bloc) ? "⤿ même temps" : "temps à part"}
          </button>`
        : nothing}
      <span class="pas-outils">
        ${boutonsMonterDescendre(app, bloc.id, optsReordreBloc(app, compo))}
        ${bloc.type !== "media"
          ? html`<button class="bouton-icone" aria-label="Détails de ce pas" title="Consigne, durée, remplacer la technique"
              @click=${() => { reinitFunnel(); app.editionPas = { compoId: compo.id, blocId: bloc.id }; app.requestUpdate(); }}>⋯</button>`
          : nothing}
        <button class="bouton-icone" aria-label="Retirer ce pas" title="Retirer ce pas"
          @click=${() => void app.modifierComposition(compo.id, (c) => retirerBloc(c, bloc.id))}>✕</button>
      </span>
    </div>`;
}

function gabaritBloc(app: MovensoApp, compo: Composition, bloc: Bloc, numero: number, edition: boolean): TemplateResult {
  const technique = bloc.techniqueId ? app.technique(bloc.techniqueId) : undefined;
  const corps =
    bloc.type === "technique"
      ? technique
        ? html`<button class="bloc-technique-lecture" @click=${() => app.ouvrirFiche(technique.id)}>
            ${vignetteTechnique(app, technique)}<span class="bloc-nom">${technique.nom}</span>
          </button>`
        : html`<span class="puce-liaison absente">${bloc.texte ?? "technique"} — indisponible</span>`
      : bloc.type === "media"
        ? html`<span class="bloc-media-corps">${bloc.medias.map((m) => gabaritMedia(app, m))}</span>`
        : html`<span class="bloc-texte">${bloc.type === "pause" ? bloc.texte || "Pause" : bloc.texte}</span>`;

  // D-227 : QUI agit, en tête de la ligne — pastille + nom. Un bloc neutre
  // (consigne, pause) n'affiche rien : pas de bruit sur les compositions solo.
  const acteur = acteurDuBloc(compo, bloc);
  const rangActeur = acteur ? (compo.acteurs ?? []).findIndex((a) => a.id === acteur.id) + 1 : 0;
  const roles = acteur
    ? html`<span class="bloc-roles"><span class="bloc-acteur" data-acteur-rang=${rangActeur}>${acteur.nom}</span></span>`
    : nothing;

  const meta =
    bloc.type === "media"
      ? nothing
      : bloc.consigne || bloc.dureeSec !== undefined || roles !== nothing
        ? html`<div class="bloc-meta bloc-meta-lecture">
            ${roles}
            ${bloc.type === "technique" && bloc.consigne ? html`<span class="bloc-consigne">↳ ${bloc.consigne}</span>` : nothing}
            ${bloc.dureeSec !== undefined ? html`<span class="bloc-duree">⏱ ${formaterDuree(bloc.dureeSec)}</span>` : nothing}
          </div>`
        : nothing;
  return html`
    <li class="bloc ${bloc.type} lecture" data-bloc-id=${bloc.id}>
      <span class="bloc-nature">${numero === 0 ? nothing : `${numero}.`}</span>
      ${corps}
      ${meta}
      <!-- D-233 : les outils n'existent qu'en mode édition (✎ de la barre
           haute) — en lecture, la place revient au contenu. -->
      ${edition ? reglagesDuPas(app, compo, bloc) : nothing}
    </li>
  `;
}

/** Composition ouverte en MODE ÉDITION (D-233) — état de session, remis à zéro
 *  dès qu'on lit une AUTRE composition. En lecture, les cartes ne portent aucun
 *  outil : la place revient au contenu (arbitrage porteur). */
let compoEnEdition: string | null = null;
