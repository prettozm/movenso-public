/**
 * RELATIONS — VUE EXPLORER (S3.D3 — extraite de relations-visuelle.ts, code
 * déménagé tel quel avant les évolutions O4/O1/O5/O2 arbitrées en D-198) :
 * entrée guidée « que veux-tu faire ? », parcours court dont chaque flèche
 * porte la RAISON de l'arête (données réelles, jamais de curriculum inventé),
 * enregistrable comme composition (raison → consigne du bloc).
 */
import { html, nothing, type TemplateResult } from "lit";
import type { Bibliotheque, Technique } from "../domaine/modele.ts";
import { relationsPourFiche, type RelationAffichee } from "../domaine/relations.ts";
import type { MovensoApp } from "./racine.ts";
import { pastilleNiveau, vignetteTechnique } from "./vignette.ts";
import { etat, pousser, pastilleAlerte, iconeRole, classeRole, nomFamille, type IntentId } from "./relations-commun.ts";
import type { RoleRelation } from "../domaine/modele.ts";

/** Libellé court d'un rôle pour le badge d'étape (O1, D-198 : le mélange
 *  d'objectifs est ASSUMÉ et AFFICHÉ — chaque étape dit par quel type de lien
 *  elle a été atteinte). */
const ROLE_LIBELLE: Record<RoleRelation, string> = {
  after: "Enchaînement", before: "Préparation", peer: "Comparaison",
  opposition: "Contre", context: "Fondamental",
};

/** Signal de NIVEAU d'un candidat (O5, D-198) : les niveaux de la technique
 *  cible, pastille + nom — un débutant voit qu'une suite est avancée AVANT de
 *  la choisir. Données réelles (niveaux du pack), jamais un calcul inventé. */
function chipsNiveau(b: Bibliotheque, t: Technique | undefined): TemplateResult | typeof nothing {
  if (!t || t.niveauxIds.length === 0) return nothing;
  const d = b.disciplines.find((x) => x.id === t.disciplineId);
  const niveaux = t.niveauxIds.map((nid) => d?.niveaux.find((n) => n.id === nid)).filter((n) => !!n);
  if (niveaux.length === 0) return nothing;
  return html`<span class="rel-ex-cand-niv">${niveaux.map((n) => html`<span class="carte-niveau">${pastilleNiveau(n!)}${n!.nom}</span>`)}</span>`;
}

/** FACE-À-FACE de l'objectif « Comparer » (O2, D-198) : la position courante
 *  et la correspondance choisie côte à côte (vignette, famille, niveaux), la
 *  note de l'arête en vedette — c'est elle qui dit « ce qui les distingue »
 *  (données réelles D-136, souvent portées par les liens « À ne pas
 *  confondre »). Comparer n'avance PAS le parcours : on continue explicitement. */
function faceAFace(app: MovensoApp, b: Bibliotheque, ici: Technique, l: RelationAffichee): TemplateResult {
  const la = app.technique(l.techniqueId);
  const colonne = (t: Technique | undefined): TemplateResult => t
    ? html`<div class="rel-ex-face-col">
        <span class="rel-ex-face-media">${vignetteTechnique(app, t)}</span>
        <span class="rel-ex-face-nom">${t.nom}${pastilleAlerte(app, t.id)}</span>
        ${t.nomTraditionnel ? html`<span class="rel-ex-face-jp jp">${t.nomTraditionnel}</span>` : nothing}
        ${nomFamille(b, t) ? html`<span class="rel-ex-face-fam">${nomFamille(b, t)}</span>` : nothing}
        ${chipsNiveau(b, t)}
        <button class="rel-ex-ctrl" @click=${() => app.ouvrirFiche(t.id)}>Ouvrir la fiche</button>
      </div>`
    : html`<div class="rel-ex-face-col"><span class="rel-ex-face-nom">?</span></div>`;
  return html`
    <div class="rel-ex-face">
      <span class="rel-ex-face-lien ${classeRole(l.role)}">${iconeRole(l.role)}${l.libelle}</span>
      <div class="rel-ex-face-cols">${colonne(ici)}${colonne(la)}</div>
      ${l.note
        ? html`<p class="rel-ex-face-note"><b>Ce qui les distingue :</b> ${l.note}</p>`
        : html`<p class="rel-ex-face-note vide">Aucune note de distinction sur ce lien — ajoute-la depuis la fiche (feuille « Lien »).</p>`}
      <div class="rel-ex-actions">
        <button class="rel-ex-ctrl" @click=${() => { etat.exCompare = null; app.requestUpdate(); }}>← Autres correspondances</button>
        ${la ? html`<button class="rel-ex-ctrl principal" @click=${() => {
          etat.exCompare = null;
          etat.exChemin = [...etat.exChemin, l.note !== undefined ? { id: l.techniqueId, note: l.note, role: l.role } : { id: l.techniqueId, role: l.role }];
          pousser(app, l.techniqueId);
        }}>Continuer sur ${la.nom}</button>` : nothing}
      </div>
    </div>
  `;
}

/** Badge de rôle d'une étape (icône colorée du lien emprunté). */
function badgeEtape(role: RoleRelation | undefined): TemplateResult | typeof nothing {
  if (!role) return nothing;
  return html`<span class="rel-ex-badge ${classeRole(role)}" title="Étape atteinte par un lien « ${ROLE_LIBELLE[role]} »">${iconeRole(role)}</span>`;
}

/** Objectif d'exploration (Explorer) : un intitulé + un prédicat sur les liens
 *  du point courant (typeId + sens direct/inverse). Dérivé d'arêtes RÉELLES —
 *  aucune donnée inventée. */
interface Intent {
  id: IntentId;
  titre: string;
  invite: string;
  garde: (l: RelationAffichee) => boolean;
}
const INTENTS: Intent[] = [
  { id: "enchainer", titre: "Construire un enchaînement", invite: "Suite après la technique", garde: (l) => l.role === "after" },
  { id: "preparer", titre: "Trouver une préparation", invite: "Ce qui amène à cette technique", garde: (l) => l.role === "before" },
  { id: "comparer", titre: "Comparer / ne pas confondre", invite: "Variantes et distinctions", garde: (l) => l.role === "peer" },
  { id: "defendre", titre: "Voir les contres et réactions", invite: "Ce qui répond à la technique", garde: (l) => l.role === "opposition" },
];

/** ---- Vue EXPLORER (boucle 3) : entrée guidée « que veux-tu faire ? » puis
 *  construction d'un parcours court, chaque flèche portant la RAISON de l'arête
 *  (données réelles, jamais de curriculum inventé). Toucher un candidat l'ajoute
 *  au parcours (le point courant avance) ; on peut revenir, ouvrir une fiche, ou
 *  enregistrer le parcours comme composition (la raison → consigne du bloc). ---- */
const CAP_CANDIDATS = 6;

function candidatsExplorer(app: MovensoApp, b: Bibliotheque, tailId: string, intent: Intent, dejaVus: Set<string>): RelationAffichee[] {
  return relationsPourFiche(b, tailId)
    .filter((l) => intent.garde(l) && l.presente && !dejaVus.has(l.techniqueId))
    .sort((a, z) => (a.priorite ?? Infinity) - (z.priorite ?? Infinity))
    .slice(0, CAP_CANDIDATS);
}

export function vueExplorer(app: MovensoApp, b: Bibliotheque, centre: Technique): TemplateResult {
  // Le parcours Explorer avance EN recentrant (R4) : le centre suit la queue du
  // chemin. On ne repart d'un parcours neuf que si le centre a sauté AILLEURS
  // (recherche, fil d'Ariane) — ni la queue ni le départ du chemin courant.
  const queue = etat.exChemin[etat.exChemin.length - 1]?.id;
  if (etat.exChemin.length === 0 || (queue !== centre.id && etat.exChemin[0]!.id !== centre.id)) {
    etat.exChemin = [{ id: centre.id }];
    etat.exIntent = null;
    etat.exCompare = null;
  }
  const intent = INTENTS.find((i) => i.id === etat.exIntent);

  if (!intent) {
    const dejaVusChoix = new Set(etat.exChemin.map((e) => e.id));
    const dispo = INTENTS
      .map((i) => ({ i, n: candidatsExplorer(app, b, centre.id, i, dejaVusChoix).length }))
      .filter((x) => x.n > 0);
    // O1 (D-198) : le parcours en cours reste VISIBLE pendant le choix — le
    // mélange d'objectifs est permis et dit, chaque étape garde son badge.
    const enCours = etat.exChemin.length > 1;
    return html`
      <div class="rel-ex">
        ${enCours ? html`
          <ol class="rel-ex-chemin">
            ${etat.exChemin.map((e, idx) => html`
              ${idx > 0 ? html`<li class="rel-ex-pourquoi">${e.note ?? "—"}</li>` : nothing}
              <li class="rel-ex-etape ${idx === etat.exChemin.length - 1 ? "courant" : ""}">
                ${badgeEtape(e.role)}
                <button class="rel-ex-nom" @click=${() => app.ouvrirFiche(e.id)} title="Ouvrir la fiche">${app.technique(e.id)?.nom ?? "?"}</button>
              </li>
            `)}
          </ol>
          <p class="rel-ex-continue">Ton parcours continue — chaque objectif s'ajoute au chemin, le mélange est permis.</p>` : nothing}
        <p class="rel-ex-q">${enCours ? html`Et maintenant, que veux-tu faire avec <strong>${centre.nom}</strong> ?` : html`Que veux-tu faire avec <strong>${centre.nom}</strong> ?`}</p>
        ${dispo.length === 0
          ? html`<p class="fil-vide">Aucun lien exploitable pour l'instant sur cette technique.</p>`
          : html`<div class="rel-ex-intents">
              ${dispo.map(({ i, n }) => html`<button class="rel-ex-intent" @click=${() => {
                etat.exIntent = i.id;
                // O1 (D-198) : choisir l'objectif SUIVANT ne jette jamais le
                // parcours en cours — on ne repart à zéro que sans chemin.
                if (etat.exChemin[etat.exChemin.length - 1]?.id !== centre.id) etat.exChemin = [{ id: centre.id }];
                app.requestUpdate();
              }}>
                <span class="rel-ex-intent-t">${i.titre}</span>
                <span class="rel-ex-intent-s">${i.invite} · ${n}</span>
              </button>`)}
            </div>`}
      </div>
    `;
  }

  const dejaVus = new Set(etat.exChemin.map((e) => e.id));
  const tail = etat.exChemin[etat.exChemin.length - 1]!.id;
  const suivants = candidatsExplorer(app, b, tail, intent, dejaVus);

  // O2 (D-198) : sur « Comparer », un candidat choisi s'ouvre en FACE-À-FACE
  // (la liaison est relue au rendu — si elle a disparu, retour aux candidats).
  if (intent.id === "comparer" && etat.exCompare) {
    const liaison = suivants.find((l) => l.techniqueId === etat.exCompare);
    const ici = app.technique(tail);
    if (liaison && ici) {
      return html`
        <div class="rel-ex">
          <div class="rel-ex-tete">
            <span class="rel-ex-obj">${intent.titre}</span>
            <button class="rel-ex-changer" @click=${() => { etat.exIntent = null; etat.exCompare = null; app.requestUpdate(); }}>Changer d'objectif</button>
          </div>
          ${faceAFace(app, b, ici, liaison)}
        </div>
      `;
    }
    etat.exCompare = null;
  }

  return html`
    <div class="rel-ex">
      <div class="rel-ex-tete">
        <span class="rel-ex-obj">${intent.titre}</span>
        <button class="rel-ex-changer" title="Choisir un autre objectif pour la suite — le parcours déjà construit reste" @click=${() => { etat.exIntent = null; etat.exCompare = null; app.requestUpdate(); }}>Changer d'objectif</button>
      </div>

      <ol class="rel-ex-chemin">
        ${etat.exChemin.map((e, idx) => html`
          ${idx > 0 ? html`<li class="rel-ex-pourquoi">${e.note ?? "—"}</li>` : nothing}
          <li class="rel-ex-etape ${idx === etat.exChemin.length - 1 ? "courant" : ""}">
            ${badgeEtape(e.role)}
            <button class="rel-ex-nom" @click=${() => app.ouvrirFiche(e.id)} title="Ouvrir la fiche">${app.technique(e.id)?.nom ?? "?"}</button>
          </li>
        `)}
      </ol>

      <div class="rel-ex-actions">
        ${etat.exChemin.length > 1
          ? html`<button class="rel-ex-ctrl" @click=${() => { etat.exChemin = etat.exChemin.slice(0, -1); pousser(app, etat.exChemin[etat.exChemin.length - 1]!.id); }}>← Revenir</button>`
          : nothing}
        <button class="rel-ex-ctrl" @click=${() => { etat.exIntent = null; etat.exCompare = null; app.requestUpdate(); }}>Changer d'objectif</button>
      </div>

      ${suivants.length
        ? html`
            <p class="rel-ex-label">Étape suivante</p>
            <div class="rel-ex-suivants">
              ${suivants.map((l) => {
                const t = app.technique(l.techniqueId);
                return html`<button class="rel-ex-cand" @click=${() => {
                  if (intent.id === "comparer") { etat.exCompare = l.techniqueId; app.requestUpdate(); return; }
                  etat.exChemin = [...etat.exChemin, l.note !== undefined ? { id: l.techniqueId, note: l.note, role: l.role } : { id: l.techniqueId, role: l.role }];
                  pousser(app, l.techniqueId);
                }}>
                <span class="rel-ex-cand-nom">${t?.nom ?? "?"}${pastilleAlerte(app, l.techniqueId)}</span>
                ${chipsNiveau(b, t)}
                ${l.note ? html`<span class="rel-ex-cand-note">${l.note}</span>` : nothing}
              </button>`;
              })}
            </div>`
        : html`<p class="fil-vide rel-ex-fin">Fin de piste — aucune suite pour cet objectif. Reviens en arrière ou change d'objectif.</p>`}
    </div>
  `;
}

