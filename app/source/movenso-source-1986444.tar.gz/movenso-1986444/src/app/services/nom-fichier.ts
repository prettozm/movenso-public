/**
 * Noms des fichiers produits pour l'utilisateur (R5-1, REC-B4-001).
 *
 * L'incident : le nom d'une sauvegarde ne portait que la DATE — la seconde
 * sauvegarde du jour remplaçait la première dans `Documents/movenso`, sans un
 * mot. Une sauvegarde qui détruit une sauvegarde est l'inverse de sa raison
 * d'être. Le nom porte donc l'heure et la minute, en temps LOCAL : ce fichier
 * est destiné à un humain qui le lit dans son gestionnaire de fichiers, pas à
 * une machine (l'UTC de `toISOString` datait d'ailleurs la sauvegarde du
 * mauvais jour passé minuit locale).
 */

const pad = (n: number): string => String(n).padStart(2, "0");

/** `2026-08-11-22h41` — date et heure LOCALES, triables, sans caractère interdit. */
export function horodatage(quand: Date): string {
  return `${quand.getFullYear()}-${pad(quand.getMonth() + 1)}-${pad(quand.getDate())}-${pad(quand.getHours())}h${pad(quand.getMinutes())}`;
}

/** Nom d'une sauvegarde : complétude + horodatage à la MINUTE — deux
 *  sauvegardes dans la même minute portent donc le même nom et s'écrasent. */
export function nomDeSauvegarde(complete: boolean, quand: Date): string {
  return `movenso-${complete ? "complet" : "partiel"}-${horodatage(quand)}.movpack`;
}
