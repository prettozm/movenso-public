/**
 * Service CAPTURE (S3.A1, tranche T4 — extrait de racine.ts, code déménagé
 * tel quel) : situations « chaud » (capturer d'abord, structurer ensuite),
 * rattachement différé, terminer une capture (transaction propre, écrivain
 * unique de technique via app.pousserNouvelleTechnique — S2.1/D-169).
 */

import type { MovensoApp } from "../racine.ts";
import { ingererVideo, persisterAvecMediasNeufs, ecritureMedia, poserEcritureMedia, mediaDepuisLien } from "./medias-fiche.ts";
import { refusFichierVideo } from "../../domaine/ingestion.ts";
import { genererUlid } from "../../domaine/ulid.ts";
import type { Contribution, Media } from "../../domaine/modele.ts";

export function ouvrirCapture(app: MovensoApp): void {
  app.capture = {
    etape: "contenu",
    note: "",
    demarreA: Date.now(),
    // La capture connaît son contexte (lot 1 §7) : depuis une composition
    // elle peut devenir un repère ; depuis une discipline, une technique
    // créée à la volée y est présélectionnée.
    ...(app.ecran.type === "composition" ? { compositionCible: app.ecran.compositionId } : {}),
    ...(app.ecran.type === "discipline" ? { disciplineChoisieId: app.ecran.disciplineId } : {}),
  };
}

/** Termine une capture en REPÈRE d'une composition (bloc, pas contribution).
 *  Transaction média+métier (§17/§19), gardée par le PIN À L'ENTRÉE comme ses
 *  jumelles : si une protection est active et la session verrouillée, on sort
 *  AVANT d'écrire le moindre fichier — l'action différée rejoue la méthode
 *  ENTIÈRE (écriture + persistance atomiques), donc jamais un fichier écrit
 *  puis orphelin après reprise du PIN. Sur échec de persistance, le fichier
 *  NEUF est retiré ; la capture ne se ferme qu'au vrai succès ; anti
 *  double-appui (§concurrence). */
export async function terminerCaptureRepere(app: MovensoApp): Promise<void> {
  const capture = app.capture;
  const compositionId = capture?.compositionCible;
  const b = app.bibliotheque;
  if (!capture || !compositionId || !b) return;
  if (!app.garde("modification", "Saisis le PIN pour enregistrer ce repère.", () => void app.terminerCaptureRepere())) return;
  const compo = b.compositions.find((x) => x.id === compositionId);
  if (!compo) return;
  if (ecritureMedia()) return;
  poserEcritureMedia(true);
  try {
    const medias: Media[] = [];
    const fichiersEcrits: string[] = []; // seuls les fichiers NEUFS se retirent au rollback
    if (capture.video) {
      const refus = refusFichierVideo(capture.video);
      if (refus) {
        app.afficherToast(refus); // la capture reste ouverte, rien n'est écrit
        return;
      }
      const resu = await ingererVideo(app, b, capture.video, capture.camera ? "camera" : "fichier");
      if (!resu) return; // espace insuffisant — toast déjà posé, rien d'écrit
      if (resu.ecrit) fichiersEcrits.push(resu.media.id);
      medias.push(resu.media);
    }
    if (capture.lien?.trim()) {
      const lien = mediaDepuisLien(capture.lien.trim());
      if ("erreur" in lien) { app.afficherToast(lien.erreur); return; } // la capture reste ouverte
      medias.push(lien.media);
    }
    const texte = capture.note.trim();
    if (!texte && medias.length === 0) return;
    const idBloc = genererUlid();
    const modifieLeAvant = compo.modifieLe;
    compo.blocs.push({ id: idBloc, type: "repere", ...(texte ? { texte } : {}), medias });
    compo.modifieLe = new Date().toISOString();
    // §14/§19 : sur échec, le bloc ressort ET le fichier NEUF se retire
    // (jamais un dédupliqué) — la capture RESTE ouverte.
    const ok = await persisterAvecMediasNeufs(app, b, fichiersEcrits, () => {
      compo.blocs = compo.blocs.filter((x) => x.id !== idBloc);
      if (modifieLeAvant !== undefined) compo.modifieLe = modifieLeAvant;
      else delete compo.modifieLe;
    });
    if (!ok) return;
    app.capture = null;
    app.afficherToast("Repère ajouté à la composition ✓");
  } finally {
    poserEcritureMedia(false);
  }
}

export function ouvrirRattachement(app: MovensoApp, contributionId: string): void {
  if (!app.garde("modification", "Saisis le PIN pour reprendre cette capture.", () => void app.ouvrirRattachement(contributionId))) return;
  app.capture = { etape: "rattacher", note: "", demarreA: Date.now(), rattacherSeul: contributionId };
}

export function fermerCapture(app: MovensoApp): void {
  if (app.capture?.apercuUrl) URL.revokeObjectURL(app.capture.apercuUrl);
  app.capture = null;
}

/** Retour Android DANS la capture (lot 4 §16) : étape par étape — et si un
 *  contenu existe déjà, la question « Que faire de cette capture ? » avant
 *  toute perte. Sans contenu : quitter sans confirmation inutile. */
export function reculerCapture(app: MovensoApp): void {
  const c = app.capture;
  if (!c) return;
  if (c.question) {
    app.capture = { ...c, question: false }; // revenir = continuer
    return;
  }
  if (c.rattacherSeul) {
    app.fermerCapture(); // feuille à un seul geste
    return;
  }
  const aContenu = c.video !== undefined || (c.lien ?? "").trim() !== "" || c.note.trim() !== "";
  if (c.etape === "rattacher") {
    app.capture = { ...c, etape: "note" };
    return;
  }
  if (c.etape === "apercu" || c.etape === "note") {
    app.capture = aContenu ? { ...c, question: true } : { ...c, etape: "contenu" };
    return;
  }
  if (c.saisieLien) {
    app.capture = { ...c, saisieLien: false };
    return;
  }
  app.fermerCapture();
}

/** Termine une capture : techniqueId null = « à rattacher » (plus tard).
 *  `cible` désigne la discipline d'une technique créée à la volée — par id,
 *  ou par nom (créée au passage si aucune n'existe encore, D-017). */
export async function terminerCapture(app: MovensoApp, techniqueId: string | null,
  nouvelleTechnique?: string,
  cible?: { disciplineId?: string; disciplineNom?: string },): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour enregistrer cette capture.", () => void app.terminerCapture(techniqueId, nouvelleTechnique, cible))) return;
  const b = app.bibliotheque;
  const capture = app.capture;
  if (!b || !capture) return;
  const secondes = Math.max(1, Math.round((Date.now() - capture.demarreA) / 1000));

  if (nouvelleTechnique !== undefined) {
    let disciplineId =
      cible?.disciplineId ??
      (app.ecran.type === "fiche" ? app.technique(app.ecran.techniqueId)?.disciplineId : undefined) ??
      (b.disciplines.length === 1 ? b.disciplines[0]!.id : undefined);
    if (!disciplineId && cible?.disciplineNom?.trim()) {
      disciplineId = genererUlid();
      b.disciplines.push({ id: disciplineId, nom: cible.disciplineNom.trim(), familles: [], niveaux: [] });
    }
    if (!disciplineId) {
      app.afficherToast("Choisis ou nomme une discipline pour cette technique", "alerte");
      return;
    }
    // S2.1 (option V) : le MÊME écrivain que partout — trim et validations
    // compris. Jamais de question de doublon ici : le moment chaud de la
    // capture ne s'interrompt pas (choix documenté D-169).
    techniqueId = app.pousserNouvelleTechnique(b, disciplineId, nouvelleTechnique);
    if (!techniqueId) {
      app.afficherToast("Nom de technique vide — précise-le pour rattacher", "alerte");
      return;
    }
  }

  if (capture.rattacherSeul !== undefined) {
    const c = b.contributions.find((x) => x.id === capture.rattacherSeul);
    if (c && techniqueId) c.techniqueId = techniqueId;
    await app.persister(b);
    app.capture = null;
    if (techniqueId) {
      app.afficherToast(`Rattaché à ${app.technique(techniqueId)?.nom} ✓`);
      app.ouvrirFiche(techniqueId);
    }
    return;
  }

  // §concurrence : anti double-appui — un second appui pendant l'écriture ne
  // produit ni doublon de contribution ni doublon de fichier.
  if (ecritureMedia()) return;
  poserEcritureMedia(true);
  const medias: Media[] = [];
  const fichiersEcrits: string[] = []; // seuls les fichiers NEUFS se retirent au rollback
  try {
    if (capture.video) {
      // Ingestion unique (lot 8A §5) : validation type/taille AVANT tout,
      // puis identique déjà présent → id réutilisé, nouvelle référence,
      // AUCUNE réécriture physique.
      const refus = refusFichierVideo(capture.video);
      if (refus) {
        app.afficherToast(refus); // la capture reste ouverte
        return;
      }
      const resu = await ingererVideo(app, b, capture.video, capture.camera ? "camera" : "fichier");
      if (!resu) return; // espace insuffisant — toast déjà posé, rien d'écrit
      if (resu.ecrit) fichiersEcrits.push(resu.media.id);
      medias.push(resu.media);
    }
    if (capture.lien?.trim()) {
      const lien = mediaDepuisLien(capture.lien.trim());
      if ("erreur" in lien) { app.afficherToast(lien.erreur); return; } // la capture reste ouverte
      medias.push(lien.media);
    }
    const provenance = capture.provenance ?? "personnel";
    const contribution: Contribution = {
      id: genererUlid(),
      techniqueId,
      provenance,
      ...(capture.note.trim() ? { description: capture.note.trim() } : {}),
      ...(provenance !== "personnel" && capture.attribution?.trim() ? { attribution: capture.attribution.trim() } : {}),
      pointsCles: [],
      creeLe: new Date().toISOString(),
      medias,
    };
    b.contributions.push(contribution);
    // §14/§19 : jamais d'orphelin — sur échec, la contribution ressort et le
    // fichier NEUF se retire (jamais un dédupliqué), la capture RESTE ouverte.
    const ok = await persisterAvecMediasNeufs(app, b, fichiersEcrits, () => {
      b.contributions = b.contributions.filter((x) => x.id !== contribution.id);
    });
    if (!ok) return;
  } finally {
    poserEcritureMedia(false);
  }
  app.capture = null;
  if (techniqueId) {
    app.afficherToast(`Capturé ✓ rattaché à ${app.technique(techniqueId)?.nom} — ${secondes} s, hors ligne`);
    app.ouvrirFiche(techniqueId);
  } else {
    // Fin de parcours §21 : message court, destination explicite (D-107 :
    // « à rattacher » vit dans Plus › À vérifier). On y amène directement.
    app.afficherToast(`Conservé — à rattacher, dans Plus › À vérifier ✓ — ${secondes} s, hors ligne`);
    app.ouvrirPlusSection("atraiter");
  }
}
