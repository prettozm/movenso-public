/**
 * EXPORT DU DIAGNOSTIC TECHNIQUE (§38, D-234) — sorti de `export-pack.ts`
 * (D-372) parce qu'il n'y était que par accident d'histoire : ce module-ci
 * produit un RAPPORT lisible pour comprendre un souci, celui-là produit un
 * `.movpack` à partager. Rien de commun sinon le mot « export ».
 *
 * Un diagnostic ne contient JAMAIS de secret : ni PIN, ni contenu personnel,
 * ni octets média, ni nom de technique ou de discipline — seulement des
 * identifiants éditoriaux de packs et des compteurs.
 */

import { construireDiagnostic } from "../../domaine/diagnostic.ts";
import { VERSION_SCHEMA, sourceDe, type Bibliotheque } from "../../domaine/modele.ts";
import { VERSION_MOVPACK } from "../../echange/movpack-contrat.ts";
import { referencesVideosLocales } from "../../domaine/medias.ts";
import { enregistrerFichierLocal } from "./fichiers.ts";
import { horodatage } from "./nom-fichier.ts";
import { VERSION, COMMIT } from "../version.ts";
import type { MovensoApp } from "../racine.ts";

/** Contexte enrichi du diagnostic (D-234) : packs installés, sauvegardes,
 *  maillage, capacités réelles de la plateforme et réglages NON sensibles.
 *  Aucun nom de technique, de discipline ou de composition — seulement des
 *  identifiants éditoriaux de packs et des compteurs. */
async function contexteDiagnostic(app: MovensoApp, b: Bibliotheque) {
  // Réserve CONNUE : la bibliothèque ne retient PAS la version éditoriale d'un
  // pack installé, seulement son identifiant sur chaque élément. On rapporte
  // donc ce qu'on sait, sans l'inventer (cf. KNOWN_LIMITATIONS).
  const parPack = new Map<string, { id: string; techniques: number }>();
  for (const t of b.techniques) {
    const pack = sourceDe(t);
    const e = parPack.get(pack) ?? { id: pack, techniques: 0 };
    e.techniques += 1;
    parPack.set(pack, e);
  }
  const sauv = await app.stockage.listerSauvegardes().catch(() => [] as string[]);
  const nav = navigator as Navigator & { share?: unknown };
  const p = app.preferences;
  return {
    packs: [...parPack.values()].sort((x, z) => x.id.localeCompare(z.id)),
    sauvegardes: { nombre: sauv.length, derniere: sauv.length ? (sauv[sauv.length - 1] ?? null) : null },
    relations: b.techniques.reduce((n, t) => n + t.relations.length, 0),
    compositionsARoles: b.compositions.filter((c) => (c.acteurs?.length ?? 0) >= 2).length,
    capacites: {
      "stockage OPFS": typeof navigator.storage?.getDirectory === "function",
      "stockage persistant accordé": await navigator.storage?.persisted?.().catch(() => false) ?? false,
      "verrou d'écran (wake lock)": "wakeLock" in navigator,
      "partage natif": typeof nav.share === "function",
      "synthèse vocale web": typeof window.speechSynthesis !== "undefined",
      "requêtes de conteneur CSS": typeof CSS !== "undefined" && CSS.supports?.("container-type: inline-size"),
      langue: navigator.language,
    } as Record<string, boolean | string>,
    reglages: {
      "mode avancé": (p.modeAvance ?? false) ? "oui" : "non",
      "bêta Relations": (p.vueRelationBeta ?? false) ? "oui" : "non",
      "bêta Compositions": (p.compositionsBeta ?? false) ? "oui" : "non",
      thème: p.theme ?? "auto",
      "écran de démarrage": p.demarrage?.mode ?? "bibliotheque",
      "son des séances": p.sonSeance ?? "les-deux",
    } as Record<string, string>,
  };
}

/** Exporte un diagnostic technique (§38) — informations agrégées, JAMAIS de
 *  secret (le builder pur ne reçoit ni PIN, ni contenu personnel, ni octets
 *  média). Un simple fichier texte, pour comprendre un souci de stockage ou
 *  d'export sans exposer de données. */
export async function exporterDiagnostic(app: MovensoApp): Promise<void> {
  const b = app.bibliotheque;
  if (!b) return;
  const presents = await app.stockage.listerVideos();
  const refs = referencesVideosLocales(b);
  const capacitor = (window as { Capacitor?: { getPlatform?: () => string } }).Capacitor;
  const texte = construireDiagnostic({
    genereLe: new Date().toISOString(),
    plateforme: capacitor?.getPlatform?.() ?? "web",
    versionApp: `${VERSION}+${COMMIT}`,
    versionSchema: VERSION_SCHEMA,
    versionMovpack: VERSION_MOVPACK,
    disciplines: b.disciplines.length,
    techniques: b.techniques.length,
    contributions: b.contributions.length,
    compositions: b.compositions.length,
    favoris: b.favoris.length,
    mediasReferences: refs.size,
    mediasPresents: presents.size,
    mediasManquants: [...refs].filter((id) => !presents.has(id)).length,
    dernierEchec: app.dernierEchec,
    operationLongue: app.operationLongue,
    orphelins: [...presents].filter((id) => !refs.has(id)).length,
    espace: await app.stockage.estimerEspace(),
    ...(await contexteDiagnostic(app, b)),
  });
  const nomDiag = `movenso-diagnostic-${horodatage(new Date())}.txt`; // même classe de collision que R5-1
  // BOM + charset explicite (D-234) : sans eux, un éditeur Windows ou un
  // visionneur Android lit l'UTF-8 en Latin-1 et rend « Movenso â€” diagnostic ».
  // Le rapport d'un utilisateur doit être lisible tel quel, partout.
  const fichier = new File(["\uFEFF" + texte], nomDiag, { type: "text/plain;charset=utf-8" });
  const emplacement = await enregistrerFichierLocal(app, fichier);
  app.afficherToast(`Diagnostic enregistré dans ${emplacement} — informations techniques uniquement, aucun secret`);
}

