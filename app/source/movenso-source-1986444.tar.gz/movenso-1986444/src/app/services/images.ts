/**
 * URL d'AFFICHAGE des images de couverture (schéma 6, D-269).
 *
 * Depuis le schéma 6, une couverture ne porte plus ses octets : elle désigne
 * une image de l'inventaire, dont le fichier vit dans OPFS. Or un rendu Lit
 * est SYNCHRONE — il ne peut pas attendre une lecture de fichier. D'où ce
 * cache : les URL d'objet sont préparées une fois, quand la bibliothèque
 * arrive, et le rendu ne fait plus que les lire.
 *
 * `URL.createObjectURL` sur un `File` d'OPFS ne charge pas les octets en
 * mémoire — le navigateur les sert depuis le disque à la demande. Préparer
 * cent vignettes coûte donc cent poignées, pas cent images.
 *
 * Un seul lieu, et il se RÉVOQUE : une image retirée de l'inventaire voit son
 * URL libérée, sinon le cache retiendrait indéfiniment des fichiers que plus
 * personne n'affiche.
 */
import type { Bibliotheque } from "../../domaine/modele.ts";
import type { StockageOpfs } from "../../stockage/opfs.ts";

const urls = new Map<string, string>();

/** Met le cache au niveau de l'inventaire : prépare ce qui manque, libère ce
 *  qui a disparu. Idempotent — appelable après chaque persistance. */
export async function preparerImages(stockage: StockageOpfs, b: Bibliotheque): Promise<void> {
  const declarees = new Set((b.images ?? []).map((i) => i.id));
  for (const [id, url] of [...urls]) {
    if (declarees.has(id)) continue;
    URL.revokeObjectURL(url);
    urls.delete(id);
  }
  for (const id of declarees) {
    if (urls.has(id)) continue;
    const blob = await stockage.lireImage(id);
    // Fichier absent : la vignette se dégrade (famille, puis initiale). On ne
    // met rien en cache, pour qu'une réparation ultérieure soit prise en
    // compte au prochain passage.
    if (blob) urls.set(id, URL.createObjectURL(blob));
  }
}

/** URL affichable d'une image, `null` si son fichier manque. */
export function urlImage(id: string): string | null {
  return urls.get(id) ?? null;
}
