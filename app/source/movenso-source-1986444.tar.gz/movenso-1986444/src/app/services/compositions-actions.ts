/**
 * Service ACTIONS DE COMPOSITION (S3.A1, tranche T3 — extrait de racine.ts,
 * code déménagé tel quel) : créer (entonnoir compris), modifier sous garde,
 * dupliquer, exporter/partager en pack jouable, médias de présentation,
 * supprimer. Fonctions recevant `app` ; l'état d'écran (creationCompo,
 * menuComposition…) reste des propriétés réactives de la racine.
 */

import type { MovensoApp } from "../racine.ts";
import type { Composition } from "../../domaine/modele.ts";
import { idsMediasPresents, exporterEnFlux, extraireOuDire } from "./export-pack.ts";
import { remettreFichierPartage } from "./fichiers.ts";
import { extrairePackComposition, idDePack, idPackStable } from "../../echange/extraction-pack.ts";
import { referencesVideosLocales } from "../../domaine/medias.ts";
import { nouvelleComposition, nouveauBloc, normaliserTemps } from "../../domaine/composition.ts";
import { genererUlid } from "../../domaine/ulid.ts";
import { reinitFunnel } from "../compositions.ts";

/** Ouvre l'entonnoir de création (D-126) : nom → type → premiers pas.
 *  Remplace la création directe (grand tableau) — allège le premier écran. */
export function ouvrirCreationCompo(app: MovensoApp): void {
  if (!app.garde("modification", "Saisis le PIN pour créer une composition.", () => app.ouvrirCreationCompo())) return;
  reinitFunnel();
  app.creationCompo = { etape: "nom", nom: "" };
  app.requestUpdate();
}

/** Nom validé : la composition est créée (vide), puis on demande QUI PRATIQUE
 *  (D-231) — l'étape se saute d'un geste (« Seul »). D-126 pour le reste. */
export async function creerCompositionFunnel(app: MovensoApp): Promise<void> {
  const b = app.bibliotheque;
  const nom = app.creationCompo?.nom.trim();
  if (!b || !app.creationCompo || !nom) return;
  const compo = nouvelleComposition(nom);
  b.compositions.push(compo);
  await app.persister(b);
  reinitFunnel();
  app.creationCompo = { ...app.creationCompo, compoId: compo.id, etape: "roles", roles: [] };
  app.requestUpdate();
}

/** Rôles validés dans l'entonnoir (D-231) : les noms viennent de l'utilisateur,
 *  l'app n'en propose AUCUN. Une liste vide = composition à un seul exécutant,
 *  aucun acteur n'est écrit. On passe ensuite aux pas. */
export async function poserRolesFunnel(app: MovensoApp, noms: string[]): Promise<void> {
  const etat = app.creationCompo;
  if (!etat?.compoId) return;
  const propres = noms.map((n) => n.trim()).filter((n) => n !== "");
  if (propres.length >= 2)
    await app.modifierComposition(etat.compoId, (c) => {
      c.acteurs = propres.map((nom, i) => ({ id: `r${i + 1}`, nom }));
    });
  app.creationCompo = { ...etat, etape: "pas" };
  app.requestUpdate();
}

/** Termine l'entonnoir : ouvre la composition créée (en lecture). */
export function fermerCreationCompo(app: MovensoApp): void {
  const id = app.creationCompo?.compoId;
  app.creationCompo = null;
  if (id) app.ouvrirComposition(id);
  app.requestUpdate();
}

/** Retour Android dans l'entonnoir : pas → ouvrir la compo, nom → fermer. */
export function reculerCreationCompo(app: MovensoApp): void {
  const e = app.creationCompo;
  if (!e) return;
  // À « rôles » comme à « pas », la composition EXISTE déjà : on l'ouvre plutôt
  // que de la laisser derrière soi sans le dire.
  if (e.etape === "pas" || e.etape === "roles") app.fermerCreationCompo();
  else { app.creationCompo = null; app.requestUpdate(); }
}

/** Création DIRECTE (sans entonnoir) — ouvre la composition. Conservée pour les
 *  parcours programmatiques ; l'UI passe par l'entonnoir `ouvrirCreationCompo`. */
export async function creerComposition(app: MovensoApp, nom: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour créer une composition.", () => void app.creerComposition(nom))) return;
  const b = app.bibliotheque;
  const propre = nom.trim();
  if (!b || !propre) return;
  const compo = nouvelleComposition(propre);
  b.compositions.push(compo);
  await app.persister(b);
  app.ouvrirComposition(compo.id);
  app.requestUpdate();
}

// D-373 : `creerCompositionDepuisEtapes` (« enregistrer un parcours Explorer en
// composition », D-135) est RETIRÉ — capacité levée avec la vue Explorer
// (arbitrage porteur §7-Q5) : la compréhension d'un parcours depuis Relations
// était trop coûteuse. `enregistrerParcours`, son seul appelant, vivait dans
// relations-explorer.ts (supprimé). Piste évoquée d'un « mode composition par
// relation » côté Compositions — rien n'est engagé.

/** Applique une mutation à une composition puis persiste — retour arrière si
 *  invalide. Retourne `true` si persisté (les parcours qui écrivent un média
 *  avant l'appel s'en servent pour ne fermer/nettoyer qu'au vrai succès). */
export async function modifierComposition(app: MovensoApp, id: string, muter: (c: Composition) => void): Promise<boolean> {
  if (!app.garde("modification", "Saisis le PIN pour enregistrer cette composition.", () => void app.modifierComposition(id, muter))) return false;
  const b = app.bibliotheque;
  const compo = b?.compositions.find((x) => x.id === id);
  if (!b || !compo) return false;
  const avant = structuredClone(compo);
  muter(compo);
  // D-235 (garde-fou porteur) : le regroupement en temps est NORMALISÉ à chaque
  // écriture. Un seul chemin d'écriture couvre donc l'ajout, la suppression, le
  // déplacement, la duplication et l'import — aucun appelant n'a à y penser.
  normaliserTemps(compo);
  compo.modifieLe = new Date().toISOString();
  try {
    await app.persister(b);
    return true;
  } catch (e) {
    Object.assign(compo, avant);
    app.afficherToast(e instanceof Error ? e.message : "Modification refusée");
    return false;
  }
}

/** Exporte une composition avec les identités qu'elle référence (fermeture 4) :
 *  à l'import, le rapprochement les fait rejoindre — ou les crée. */
/** Duplication (lot 5 §18) : nouvelle composition, nouveaux blocs
 *  référençant les MÊMES identités — jamais de copie de technique ou média. */
export async function dupliquerComposition(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour dupliquer cette composition.", () => void app.dupliquerComposition(id))) return;
  const b = app.bibliotheque;
  const compo = b?.compositions.find((x) => x.id === id);
  if (!b || !compo) return;
  const copie: Composition = {
    ...structuredClone(compo),
    id: genererUlid(),
    nom: `${compo.nom} (copie)`,
    creeLe: new Date().toISOString(),
    modifieLe: new Date().toISOString(),
    blocs: compo.blocs.map((x) => ({ ...structuredClone(x), id: genererUlid() })),
  };
  // La copie est À TOI — et l'intention, écrite ici depuis le début, n'était
  // qu'à moitié tenue : `origine` partait bien, mais `provenance` restait
  // « enseignement » et l'attribution suivait. Dupliquer une séance de pack
  // produisait donc une copie qui restait rangée du côté des packs (rendu
  // visible par la bascule Mes | Packs, D-320) — alors que le pied de l'écran
  // promet le contraire. Une copie personnelle ne se publie plus dans un pack
  // de discipline sans opt-in explicite (D-127) : c'est le carnet, pas le
  // référentiel.
  delete copie.origine;
  copie.provenance = "personnel";
  delete copie.attribution;
  b.compositions.push(copie);
  await app.persister(b);
  app.ouvrirComposition(copie.id);
  app.afficherToast(`« ${copie.nom} » créée ✓ — l'originale n'a pas bougé`);
}

export async function exporterComposition(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour exporter cette composition.", () => void app.exporterComposition(id))) return;
  const b = app.bibliotheque;
  const compo = b?.compositions.find((x) => x.id === id);
  if (!b || !compo) return;
  // Rapport AVANT export (lot 5 §20) : dire exactement ce qui part.
  const nbTechniques = new Set(compo.blocs.filter((x) => x.type === "technique" && x.techniqueId).map((x) => x.techniqueId!)).size;
  const nbVideos = compo.blocs.flatMap((x) => x.medias).filter((m) => m.type === "local").length;
  if (
    !confirm(
      `Exporter « ${compo.nom} » (.movpack) ?\n` +
        `- la composition (${compo.blocs.length} bloc${compo.blocs.length > 1 ? "s" : ""})\n` +
        `- ${nbTechniques} technique${nbTechniques > 1 ? "s" : ""} référencée${nbTechniques > 1 ? "s" : ""} (identités seules, sans contenu)\n` +
        `- ${nbVideos ? `${nbVideos} vidéo(s) de repère incluse(s)` : "aucune vidéo locale"}\n` +
        `- ton carnet personnel : jamais inclus`,
    )
  )
    return;
  // Le pack embarque la composition ET les identités de technique qu'elle
  // enchaîne (extracteur partagé avec le partage — D-127) : jouable à l'import.
  // D-372 : un échec d'extraction se DIT ici comme ailleurs — il était muet.
  const extrait = extraireOuDire(app, "Export", () => extrairePackComposition(b, id));
  if (!extrait) return;
  const ids = await idsMediasPresents(app, extrait);
  const exp = await exporterEnFlux(app, 
    extrait,
    { id: idPackStable(compo.id), nom: compo.nom, portee: "composition" },
    ids,
    `${idDePack(compo.nom)}.movpack`,
  );
  if (exp === null) return;
  app.afficherToast(`Composition « ${compo.nom} » exportée ✓ — s'importe et rejoint la bibliothèque cible`);
}

/** Partage NATIF d'une composition (tuning post-V3) — miroir de
 *  `partagerTechnique` : produit le `.movpack` de la composition (identités
 *  référencées + vidéos présentes) et le remet au partage natif Android, repli
 *  téléchargement. Consultation → jamais de PIN. Le carnet reste exclu. */
export async function partagerComposition(app: MovensoApp, id: string, avecVideos = true): Promise<void> {
  const b = app.bibliotheque;
  const compo = b?.compositions.find((x) => x.id === id);
  if (!b || !compo) return;
  // Même extracteur que l'export (D-127) : le partage embarque les techniques
  // associées + leurs disciplines → la composition reste jouable chez le
  // destinataire même s'il n'a pas le pack d'origine.
  const extrait = extraireOuDire(app, "Partage", () => extrairePackComposition(b, id));
  if (!extrait) return; // D-372 : dit, plus silencieux — « rien ne se passe » était le défaut
  const refs = referencesVideosLocales(extrait);
  const presents = await app.stockage.listerVideos();
  const idsPresents = avecVideos ? [...refs].filter((vid) => presents.has(vid)) : [];
  const nomFichier = `${idDePack(compo.nom)}.movpack`;
  // EN FLUX (S4.5/D-262) — miroir exact de `partagerTechnique`, et du chemin
  // que `exporterComposition` empruntait déjà quinze lignes plus haut : les
  // vidéos transitent par blocs, jamais entièrement en mémoire.
  const exp = await exporterEnFlux(app, extrait, { id: idPackStable(compo.id), nom: compo.nom, portee: "composition" }, idsPresents, nomFichier, false);
  if (exp === null) return; // espace refusé ou export annulé : déjà dit à l'utilisateur
  await remettreFichierPartage(app, exp.fichier, compo.nom, `Composition « ${compo.nom} » — Movenso`);
}

/** Retire un média de présentation (D-124). Le fichier local éventuel reste
 *  dans le registre ; le nettoyage des orphelins est géré par l'Atelier. */
export async function retirerMediaPresentation(app: MovensoApp, compoId: string, mediaId: string): Promise<void> {
  await app.modifierComposition(compoId, (c) => {
    if (!c.presentation) return;
    const restants = c.presentation.medias.filter((m) => m.id !== mediaId);
    if (restants.length) c.presentation = { medias: restants };
    else delete c.presentation;
  });
}

export async function supprimerComposition(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer cette composition.", () => void app.supprimerComposition(id))) return;
  const b = app.bibliotheque;
  const compo = b?.compositions.find((x) => x.id === id);
  if (!b || !compo) return;
  await app.stockage.snapshot("avant-suppression-de-composition"); // action destructrice : snapshot d'abord
  b.compositions = b.compositions.filter((x) => x.id !== id);
  await app.persister(b);
  app.menuComposition = null;
  app.retour(); // revient d'où la composition avait été ouverte
  app.afficherToast(`Composition « ${compo.nom} » supprimée — point de restauration conservé`);
}
