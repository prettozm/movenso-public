/**
 * PROTECTIONS d'appareil (lot 7) — extrait de `racine.ts` (D-274, voie B).
 *
 * Pourquoi un OBJET et pas des fonctions de service, comme le reste : ce
 * domaine possède un état qui n'appartient à personne d'autre — l'heure de fin
 * de session déverrouillée, le compteur d'échecs, l'heure du prochain essai
 * autorisé. Sorti en fonctions `service(app, …)`, cet état aurait dû devenir
 * PUBLIC sur l'application, donc atteignable par toutes les vues : on aurait
 * échangé un problème de taille contre un problème d'encapsulation. Ici il a
 * un propriétaire, et il reste privé.
 *
 * L'application garde la surface que les vues appellent (`app.garde(…)`,
 * `app.autoriser(…)`) et la fait suivre. Comportement strictement inchangé.
 */
import { html, nothing, type TemplateResult } from "lit";
import { creerVerification, delaiApresEchecs, validerFormatPin, verifierPin } from "../../securite/pin.ts";
import { autorisation, sessionActive, type CategorieAction, type Protections as Reglages } from "../../securite/politique.ts";
import type { Preferences } from "../../stockage/opfs.ts";
import type { MovensoApp } from "../racine.ts";

export class Protections {
  #sessionDeverrouilleeA: number | null = null;
  #echecsPin = 0;
  #prochainEssaiPinA = 0;

  readonly #app: MovensoApp;

  constructor(app: MovensoApp) {
    this.#app = app;
  }

  get app(): MovensoApp {
    return this.#app;
  }


  /** État des deux protections (§2) — lu par la politique centralisée. */
  get reglagesProtections(): Reglages {
    const p = this.app.preferences.protections;
    return { modifications: p?.modifications ?? false, suppressions: p?.suppressions ?? false };
  }

  /** Un PIN est-il configuré sur cet appareil ? (une vérification n'existe que
   *  si au moins une protection est active, §12). Décision D-115 : le
   *  commentaire de fiche, éditable en lecture pour la note rapide (D-044),
   *  devient LECTURE SEULE dès qu'un PIN protège l'appareil — la consultation
   *  reste alors une pure consultation (aucune écriture furtive). */
  get pinConfigure(): boolean {
    return this.app.preferences.protections?.verification !== undefined;
  }

  async #persisterProtections(protections: NonNullable<Preferences["protections"]>): Promise<void> {
    this.app.preferences = { ...this.app.preferences, protections };
    await this.app.stockage.sauvegarderPreferences(this.app.preferences);
    this.app.requestUpdate();
  }

  /** Active une protection (§3). Première activation : `creation` porte le
   *  PIN et sa confirmation — rien n'est activé si elles diffèrent ou si
   *  le format est refusé ; jamais de PIN incomplet enregistré. Un PIN
   *  existant sert aux deux protections. Retourne l'erreur, ou null. */
  async activerProtection(
    quoi: "modifications" | "suppressions",
    creation?: { pin: string; confirmation: string },
  ): Promise<string | null> {
    const actuel = this.app.preferences.protections;
    let verification = actuel?.verification;
    if (!verification) {
      if (!creation) return "Crée d'abord un PIN";
      const erreur = validerFormatPin(creation.pin);
      if (erreur) return erreur;
      if (creation.pin !== creation.confirmation) return "Les deux saisies ne correspondent pas";
      verification = await creerVerification(creation.pin);
    }
    await this.#persisterProtections({
      modifications: quoi === "modifications" ? true : (actuel?.modifications ?? false),
      suppressions: quoi === "suppressions" ? true : (actuel?.suppressions ?? false),
      verrouillage: actuel?.verrouillage ?? "5min",
      verification,
    });
    this.#journaliser("protection activée");
    this.app.afficherToast(`Protection ${quoi === "modifications" ? "des modifications" : "des suppressions et opérations sensibles"} activée ✓`);
    return null;
  }

  /** Désactive une protection — exige le PIN actuel (§12). Quand plus
   *  aucune protection n'est active, le secret est SUPPRIMÉ. */
  async desactiverProtection(quoi: "modifications" | "suppressions", pin: string): Promise<string | null> {
    const actuel = this.app.preferences.protections;
    if (!actuel?.verification) return null;
    if (!(await verifierPin(pin, actuel.verification))) return "PIN incorrect";
    const suivant = {
      ...actuel,
      modifications: quoi === "modifications" ? false : actuel.modifications,
      suppressions: quoi === "suppressions" ? false : actuel.suppressions,
    };
    if (!suivant.modifications && !suivant.suppressions) {
      // §12 : aucun secret conservé par inertie — plus rien n'est protégé.
      await this.#persisterProtections({ modifications: false, suppressions: false });
      this.#journaliser("protections désactivées — secret supprimé");
      this.app.afficherToast("Plus aucune action n'est protégée — les données du PIN ont été supprimées");
    } else {
      await this.#persisterProtections(suivant);
      this.app.afficherToast("Protection désactivée ✓ — l'autre reste active");
    }
    return null;
  }

  /** Durée de la session curateur (§8) — appliquée par la boucle 7.3. */
  async choisirVerrouillage(mode: "5min" | "15min" | "arriere-plan"): Promise<void> {
    const actuel = this.app.preferences.protections;
    if (!actuel) return;
    await this.#persisterProtections({ ...actuel, verrouillage: mode });
  }

  /** Changement du PIN (§11) : vérifier l'actuel, dériver le nouveau avec
   *  un NOUVEAU sel ; en cas d'échec l'ancien reste valable — jamais
   *  d'installation sans vérification. */
  async changerPin(actuel: string, nouveau: string, confirmation: string): Promise<string | null> {
    const protections = this.app.preferences.protections;
    if (!protections?.verification) return "Aucun PIN à changer";
    if (!(await verifierPin(actuel, protections.verification))) return "PIN actuel incorrect";
    const erreur = validerFormatPin(nouveau);
    if (erreur) return erreur;
    if (nouveau !== confirmation) return "Les deux saisies ne correspondent pas — l'ancien PIN reste valable";
    await this.#persisterProtections({ ...protections, verification: await creerVerification(nouveau) });
    this.#sessionDeverrouilleeA = null; // §11 : toute session active se ferme
    this.#journaliser("PIN modifié");
    this.app.afficherToast("PIN changé ✓");
    return null;
  }

  /* ---------- sécurité (lot 7 §7-10) : déverrouillage au point d'action,
     session curateur — mémoire seulement, jamais persistée ni sauvegardée ---------- */

  /** Horodatage du dernier geste autorisé — null = verrouillée. */
  /** Demande de PIN contextuelle : la raison affichée et l'action à
   *  reprendre automatiquement après déverrouillage (§7). */

  /** Referme toute session et efface les compteurs d'essai — appelé par la
   *  remise à zéro complète de l'appareil. L'état reste privé : c'est un
   *  GESTE qu'on expose, pas les champs. */
  oublierSession(): void {
    this.#sessionDeverrouilleeA = null;
    this.#echecsPin = 0;
    this.#prochainEssaiPinA = 0;
  }

  get sessionDeverrouillee(): boolean {
    return sessionActive(this.#sessionDeverrouilleeA, this.app.preferences.protections?.verrouillage ?? "5min", Date.now());
  }

  /** Cœur de la garde (§17) : vrai si l'action est libre (l'activité
   *  prolonge la session) ; sinon ouvre le panneau PIN avec l'action à
   *  reprendre — les arguments capturés dans la fermeture font que rien
   *  n'est perdu (§19). */
  /** INTERNE aux services extraits (S3.A1) — pas une API produit. */
  garde(categorie: CategorieAction, raison: string, action: () => void | Promise<void>): boolean {
    if (autorisation(categorie, this.reglagesProtections, this.sessionDeverrouillee) === "libre") {
      if (this.#sessionDeverrouilleeA !== null && this.sessionDeverrouillee) this.#sessionDeverrouilleeA = Date.now();
      return true;
    }
    this.app.demandePin = { raison, action };
    this.app.requestUpdate();
    return false;
  }

  /** Point d'entrée UNIQUE des workflows protégés (§17) : exécute si
   *  autorisé, sinon ouvre le panneau PIN en conservant le contexte. */
  autoriser(categorie: CategorieAction, raison: string, action: () => void | Promise<void>): void {
    if (this.garde(categorie, raison, action)) void action();
  }

  /** Nombre agrégé d'échecs de PIN (§23) — jamais les valeurs tentées. */

  /** Verrouillage manuel (§8) — et automatique à l'arrière-plan. */
  verrouiller(silencieux = false): void {
    if (this.#sessionDeverrouilleeA !== null) this.#journaliser(silencieux ? "verrouillé à l'arrière-plan" : "verrouillage manuel");
    this.#sessionDeverrouilleeA = null;
    if (!silencieux) this.app.afficherToast("Verrouillé — le PIN sera demandé à la prochaine action protégée");
    this.app.requestUpdate();
  }

  annulerDemandePin(): void {
    // Annuler revient exactement au contexte précédent : rien n'a été
    // exécuté, rien n'est modifié (§7).
    this.app.demandePin = null;
    this.app.requestUpdate();
  }

  /** Vérifie le PIN saisi : succès = session ouverte + reprise AUTOMATIQUE
   *  de l'action ; échec = erreur sobre + temporisation progressive (§10). */
  async validerDemandePin(pin: string): Promise<void> {
    const demande = this.app.demandePin;
    const verification = this.app.preferences.protections?.verification;
    if (!demande || !verification) return;
    const attente = Math.ceil((this.#prochainEssaiPinA - Date.now()) / 1000);
    if (attente > 0) {
      this.app.demandePin = { ...demande, erreur: `Attends ${attente} s avant le prochain essai` };
      this.app.requestUpdate();
      return;
    }
    if (!(await verifierPin(pin, verification))) {
      this.#echecsPin++;
      this.app.echecsCumules++;
      const delai = delaiApresEchecs(this.#echecsPin);
      this.#prochainEssaiPinA = Date.now() + delai * 1000;
      this.app.demandePin = { ...demande, erreur: delai ? `PIN incorrect — prochain essai dans ${delai} s` : "PIN incorrect" };
      this.app.requestUpdate();
      return;
    }
    this.#echecsPin = 0;
    this.#prochainEssaiPinA = 0;
    this.#sessionDeverrouilleeA = Date.now();
    this.#journaliser("déverrouillage réussi");
    this.app.demandePin = null;
    this.app.requestUpdate();
    await demande.action(); // reprise automatique de l'action initiale (§7)
  }

  /** Panneau PIN contextuel (§7, §24) : titre, raison, erreur annoncée. */
  feuillePin() {
    const demande = this.app.demandePin!;
    return html`
      <div class="voile" @click=${() => this.annulerDemandePin()}></div>
      <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Action protégée">
        <div class="prise"></div>
        <h2>Action protégée</h2>
        <div class="geste">${demande.raison}</div>
        <div class="creation-discipline" style="margin-top:8px">
          <input type="password" inputmode="numeric" autocomplete="off" aria-label="PIN"
                 placeholder="PIN" class="champ-pin"
                 @keydown=${(e: KeyboardEvent) => {
                   if (e.key === "Enter") void this.validerDemandePin((e.target as HTMLInputElement).value);
                 }}>
          <button class="bouton principal"
            @click=${(e: Event) => {
              const champ = (e.target as HTMLElement).parentElement!.querySelector("input")!;
              void this.validerDemandePin(champ.value);
            }}>Déverrouiller</button>
        </div>
        ${demande.erreur ? html`<p class="details erreur-pin" role="alert" style="color:var(--accent); padding-top:6px">${demande.erreur}</p>` : nothing}
        <div class="actions">
          <button class="bouton" @click=${() => this.annulerDemandePin()}>Annuler</button>
        </div>
      </div>
    `;
  }

  /** Indication discrète de session ouverte (§16) — jamais un gros mode
   *  Admin ; propose le verrouillage manuel. */
  indicateurSession() {
    const p = this.reglagesProtections;
    if (!(p.modifications || p.suppressions) || !this.sessionDeverrouillee) return nothing;
    return html`<button class="session-curateur" title="Modifications temporairement déverrouillées"
      @click=${() => this.verrouiller()}>🔓 déverrouillé · <b>Verrouiller</b></button>`;
  }

  /** Journal minimal de sécurité (§23) — MÉMOIRE DE SESSION seulement :
   *  jamais persisté, jamais exporté, jamais de valeur secrète. */

  #journaliser(evenement: string): void {
    this.app.journalSecurite = [...this.app.journalSecurite.slice(-9), `${new Date().toTimeString().slice(0, 5)} · ${evenement}`];
  }
}
