/**
 * Sections de la FICHE technique qui n'ont pas besoin de `vues.ts` — extraites
 * parce que ce fichier est au cliquet (D-278) et ne remonte jamais.
 *
 * Conformément à D-204, rien ici ne reçoit `app` : une section reçoit ses
 * DONNÉES et ses RAPPELS. On peut donc les rendre sans application, ce qui est
 * exactement ce qu'un test unitaire veut.
 */

import { html, nothing, type TemplateResult } from "lit";
import type { Composition, Technique } from "../domaine/modele.ts";

/** Modifier vit en bas à droite, comme partout ailleurs (demande porteur) : le
 *  ✎ quitte la barre haute, où il partageait la place avec quatre autres icônes
 *  et se confondait avec elles. L'invariant « aucune action globale sur une
 *  fiche » (lot 1 §7) tombe donc, et c'est assumé : ce bouton-ci est l'action
 *  DE la fiche, jamais la capture globale de la Bibliothèque. */
export function boutonModifierFiche(onModifier: () => void): TemplateResult {
  return html`<button class="fab fab-fiche" aria-label="Modifier" title="Modifier" @click=${onModifier}>
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3z"/><path d="M13.5 6.5l3 3"/></svg>
  </button>`;
}

/** Une section VIDE se montre quand même, avec son invitation (demande porteur,
 *  écran fiche technique). Une section qui disparaît ne dit pas qu'il y a une
 *  place à remplir : elle laisse croire que la fiche est complète. */
export function sectionInvitation(titre: string, invitation: string): TemplateResult {
  return html`<section class="bloc-lecture">
    <h2 class="section-titre">${titre}</h2>
    <p class="section-vide">${invitation}</p>
  </section>`;
}

/** Ce qu'une composition EST, en un mot — jamais son identifiant de type brut.
 *  Repli sur le nombre de techniques quand le type n'a pas été choisi
 *  (compositions antérieures à D-126, imports). */
export function libelleTypeComposition(co: Composition): string {
  if (co.type === "kata") return "Kata (formes)";
  if (co.type === "seance") return "Séance";
  if (co.type === "enchainement") return "Enchaînement";
  const pas = co.blocs.filter((x) => x.type === "technique").length;
  return `${pas} technique${pas > 1 ? "s" : ""}`;
}

/** « Compositions » — celles qui emploient cette technique. Chacune se montre
 *  comme une relation (vignette, nom, ce qu'elle est, chevron) là où elle
 *  n'était qu'un bouton de texte nu portant son nom.
 *
 *  La vignette est DÉRIVÉE de la première technique de la composition (D-253 :
 *  on dérive, on ne recopie pas) — une composition ne porte pas de couverture à
 *  elle. C'est déjà ainsi que les écrans de composition se représentent
 *  eux-mêmes, vignette de technique par vignette de technique. */
export function sectionCompositions(
  utilisee: readonly Composition[],
  o: {
    technique: (id: string) => Technique | undefined;
    vignette: (t: Technique) => TemplateResult;
    ouvrir: (id: string) => void;
  },
): TemplateResult {
  return html`<section class="bloc-lecture liaisons-compo">
    <h2 class="section-titre">Compositions${utilisee.length ? html` · ${utilisee.length}` : nothing}</h2>
    ${utilisee.length
      ? utilisee.map((co) => {
          const premiere = co.blocs.find((x) => x.type === "technique")?.techniqueId;
          const tech = premiere ? o.technique(premiere) : undefined;
          return html`<button class="compo-ligne" @click=${() => o.ouvrir(co.id)}>
            <span class="compo-ligne-media">${tech ? o.vignette(tech) : nothing}</span>
            <span class="compo-ligne-corps">
              <span class="compo-ligne-nom">${co.nom}</span>
              <span class="compo-ligne-quoi">${libelleTypeComposition(co)}</span>
            </span>
            <span class="compo-ligne-fleche" aria-hidden="true">›</span>
          </button>`;
        })
      : html`<p class="section-vide">Cette technique n'est utilisée dans aucune composition.</p>`}
  </section>`;
}
