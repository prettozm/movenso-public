/**
 * Écran « Packs officiels » (B2, D-211 ; refondu D-333) — VUE À DONNÉES
 * CIBLÉES (conventions §13/D-204 : pas de MovensoApp ici) : le catalogue
 * publié sur le site, chaque pack installable via le circuit d'import normal.
 * États honnêtes : chargement, catalogue injoignable (hors ligne, dev, APK
 * avant ouverture du CSP), catalogue vide.
 *
 * D-333, sur maquettes du porteur : une illustration par pack, l'avertissement
 * « des bases pour commencer » en tête, le badge de maturité, l'état installé,
 * et les disciplines qui n'ont pas encore de pack.
 */
import { html, nothing, type TemplateResult } from "lit";
import type { PackOfficiel } from "./services/packs-officiels.ts";
import { illustrationDe } from "./services/packs-officiels.ts";
import { disciplinesSansPack } from "./disciplines-a-venir.ts";


/** L'encart de l'écran, SANS en-tête (D-335) : `carteSection` en pose un, et
 *  la barre de contexte dit déjà « Starter packs ». Deux fois le même titre à
 *  quinze pixels d'écart, c'est du bruit. */
const encart = (contenu: unknown): TemplateResult => html`<div class="carte-atelier">${contenu}</div>`;

/** Édition d'un pack telle qu'installée ici (D-307), réduite à ce dont
 *  l'écran a besoin : quelle édition, pour quelle identité de pack. */
export interface EditionInstallee { pack: string; versionEditoriale: number }

const ICONE_TELECHARGER = html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"/><path d="m7.5 10.5 4.5 4.5 4.5-4.5"/><path d="M4 18v1.5A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5V18"/></svg>`;
const ICONE_POSE = html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7"/></svg>`;

/** L'avertissement d'entrée : ce que ces packs sont, et ce qu'ils ne sont pas.
 *  Le lieu de pratique y vit avec le reste (D-333) plutôt que dans un second
 *  encart : c'est la même mise en garde, et deux encarts se lisent moins qu'un. */
const AVERTISSEMENT = html`
  <section class="pack-avert">
    <img class="pack-avert-ecusson" src="./img/depart-filet.webp" alt="" aria-hidden="true" width="192" height="192" decoding="async">
    <div>
      <h3>Des bases pour commencer</h3>
      <p>Ces starter packs sont des bases non exhaustives et ne remplacent pas
      <b>l'enseignement d'un professeur qualifié</b>.</p>
      <p class="pack-avert-lieu">Pratique dans un <b>cadre adapté</b>, à ton niveau et avec
      un partenaire consentant. Toute pratique physique comporte un risque de blessure.</p>
    </div>
  </section>`;

/** Ce qu'on sait de l'installation d'un pack : rien, à jour, ou en retard. */
function etatInstallation(p: PackOfficiel, editions: readonly EditionInstallee[]): "absent" | "ajour" | "retard" {
  const posee = p.packId ? editions.find((e) => e.pack === p.packId) : undefined;
  if (!posee) return "absent";
  return p.versionEditoriale !== undefined && p.versionEditoriale > posee.versionEditoriale ? "retard" : "ajour";
}

function cartePack(p: PackOfficiel, etat: ReturnType<typeof etatInstallation>, installer: () => void): TemplateResult {
  const url = illustrationDe(p.icon);
  return html`
    <article class="pack-officiel ${etat === "retard" ? "pack-maj" : ""}">
      <div class="pack-officiel-entete">
        <span class="pack-rond">${url ? html`<img src=${url} alt="" aria-hidden="true" decoding="async">` : nothing}</span>
        <span class="pack-officiel-titres">
          <span class="pack-officiel-nom">${p.title}</span>
          <span class="pack-officiel-version">v${p.version}${p.updatedAt ? ` · ${p.updatedAt}` : ""}${
            etat === "ajour" ? html`<span class="pack-pose">Installé</span>` : nothing}${
            etat === "retard" ? html` · <b>mise à jour disponible</b>` : nothing}</span>
        </span>
      </div>
      ${p.itemCount ? html`<div class="pack-officiel-meta">${p.itemCount}</div>` : nothing}
      ${p.summary ? html`<p class="pack-officiel-resume">${p.summary}</p>` : nothing}
      ${etat === "ajour"
        ? nothing
        : html`<button class="pack-officiel-installer" @click=${installer}>
            ${ICONE_TELECHARGER} ${etat === "retard" ? "Mettre à jour" : "Télécharger et importer"}
          </button>`}
    </article>`;
}

/** L'invitation à contribuer (D-335) : la grille ne porte plus de mention
 *  « à venir ». Personne ne fabrique ces packs — annoncer une échéance qu'on
 *  ne tient pas serait une promesse ; ce sont des IDÉES, et le texte le dit. */
function sectionContribuer(catalogue: readonly PackOfficiel[]): TemplateResult | typeof nothing {
  const idees = disciplinesSansPack(catalogue);
  if (idees.length === 0) return nothing;
  return html`
    <h3 class="pack-section-titre">Envie de contribuer ?</h3>
    <p class="details" style="padding:0 2px 4px">Tu pratiques ou enseignes une discipline ?
    Tu peux créer et partager ton propre pack Movenso.</p>
    <p class="details" style="padding:0 2px 8px">Voici quelques idées de contributions :</p>
    <div class="pack-venir">
      ${idees.map((d) => {
        const url = illustrationDe(d.icon);
        return html`<div class="pack-venir-c">
          <span class="pack-rond petit">${url ? html`<img src=${url} alt="" aria-hidden="true" decoding="async">` : nothing}</span>
          <span class="pack-venir-n">${d.nom}</span>
        </div>`;
      })}
    </div>`;
}

export function ecranPacksOfficiels(
  catalogue: PackOfficiel[] | "chargement" | "indisponible" | null,
  agir: { installer: (p: PackOfficiel) => void; recharger: () => void },
  editions: readonly EditionInstallee[] = [],
): TemplateResult {
  if (catalogue === null || catalogue === "chargement")
    return encart(html`<p class="fil-vide" style="padding:6px 0">Chargement du catalogue…</p>`);
  if (catalogue === "indisponible")
    return encart(html`
      <p class="fil-vide" style="padding:6px 0 10px">
        Catalogue injoignable : il vit sur le site public de Movenso et demande
        une connexion. Tu peux aussi importer un fichier .movpack à la main
        (Plus › Importer un pack).
      </p>
      <button class="action-douce" @click=${agir.recharger}>Réessayer</button>
    `);
  if (catalogue.length === 0)
    return encart(html`<p class="fil-vide" style="padding:6px 0">Aucun pack publié pour l'instant.</p>`);
  return encart(html`
    ${AVERTISSEMENT}
    <p class="details" style="padding:0 2px 8px">
      Avant installation, Movenso te présente un rapport d'import. Rien ne s'écrit
      sans ton accord et chaque pack peut être retiré.</p>
    ${catalogue.map((p) => cartePack(p, etatInstallation(p, editions), () => agir.installer(p)))}
    ${sectionContribuer(catalogue)}
  `);
}
