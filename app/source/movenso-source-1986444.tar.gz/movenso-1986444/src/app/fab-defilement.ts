/**
 * Le bouton flottant se RÉDUIT quand on descend, reprend sa forme quand on
 * remonte (D-336, demande du porteur).
 *
 * Pourquoi ici et pas dans `racine.ts` : ce fichier est une façade au cliquet,
 * il ne remonte jamais d'une ligne (D-278). Et pourquoi pas dans l'état de
 * lit : un état réactif redessinerait la grille entière à chaque pixel de
 * défilement. On pose donc une classe sur `<body>`, que le CSS lit — le
 * rendu de lit n'y touche jamais, donc la classe survit aux redessins.
 *
 * Le seuil de 4 px n'est pas décoratif : sans lui, le tremblement d'un doigt
 * posé sur l'écran fait osciller le bouton entre ses deux formes.
 */

const SEUIL = 4;
/** Sous cette hauteur, on est « en haut de page » : le bouton reste entier,
 *  quel que soit le sens du dernier geste. */
const HAUT = 40;

let dernier = 0;
let planifie = false;

function evaluer(): void {
  planifie = false;
  const y = window.scrollY;
  if (y < HAUT) document.body.classList.remove("fab-reduit");
  else if (y > dernier + SEUIL) document.body.classList.add("fab-reduit");
  else if (y < dernier - SEUIL) document.body.classList.remove("fab-reduit");
  dernier = y;
}

/** Branché une seule fois, à l'import de la vue qui porte le bouton.
 *  La garde sur `window` n'est pas de la prudence en l'air : `vues.ts` est
 *  chargé par deux tests unitaires en **Node pur** (`resume-discipline`,
 *  `source-editoriale`), où `window` n'existe pas — sans elle, deux tests
 *  rouges pour une écoute de défilement. Constaté, pas supposé. */
if (typeof window !== "undefined")
  window.addEventListener(
  "scroll",
  () => {
    // Une mesure par image, pas une par événement de défilement.
    if (planifie) return;
    planifie = true;
    requestAnimationFrame(evaluer);
  },
  { passive: true },
);
