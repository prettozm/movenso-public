/**
 * Les disciplines qui n'ont PAS encore de pack (D-333).
 *
 * Pourquoi cette liste vit dans l'APP et non dans le catalogue : le catalogue
 * distribue des packs, et sa garde (`verifier-catalogues.mjs`, côté site)
 * exige de chaque entrée un `href` et un `downloadName`. Y glisser des
 * entrées sans fichier aurait demandé de modifier cette garde, donc la
 * posture du site, donc une PR ; et un SECOND catalogue à côté aurait été
 * exactement la faute de D-250 (deux listes finissent par diverger).
 *
 * Le prix assumé : une discipline de plus demande une mise à jour de l'app.
 * C'est acceptable pour une INVITATION — ce n'est pas un canal de
 * distribution, et rien ici ne s'installe.
 *
 * La divergence est rendue impossible plutôt que surveillée : une entrée dont
 * la discipline existe déjà au catalogue est **retirée au rendu** (voir
 * `disciplinesSansPack`). Le jour où le pack d'aïkido paraît, la case
 * « Aïkido, à venir » disparaît toute seule.
 *
 * Les illustrations vivent sur le SITE (`packs/img/`), comme celles des packs.
 */

export interface DisciplineAVenir {
  /** Le nom montré, et la clé de comparaison avec la discipline d'un pack. */
  nom: string;
  /** Chemin de l'illustration, relatif au site (comme `href` d'un pack). */
  icon: string;
}

/** Seules les disciplines qui ont une illustration figurent ici : un nom sans
 *  image se lirait comme un défaut d'affichage, pas comme une invitation.
 *  Les vingt disciplines de la liste du porteur y sont, chacune avec la
 *  sienne : la règle n'a jamais eu à écarter personne. */
export const DISCIPLINES_A_VENIR: readonly DisciplineAVenir[] = [
  { nom: "Aïkido", icon: "packs/img/venir-aikido.webp" },
  { nom: "Boxe anglaise", icon: "packs/img/venir-boxe-anglaise.webp" },
  { nom: "Muay Thaï", icon: "packs/img/venir-muay-thai.webp" },
  { nom: "Kick-boxing", icon: "packs/img/venir-kickboxing.webp" },
  { nom: "MMA", icon: "packs/img/venir-mma.webp" },
  { nom: "Lutte libre", icon: "packs/img/venir-lutte-libre.webp" },
  { nom: "Lutte gréco-romaine", icon: "packs/img/venir-lutte-greco.webp" },
  { nom: "Sambo", icon: "packs/img/venir-sambo.webp" },
  { nom: "Savate", icon: "packs/img/venir-savate.webp" },
  { nom: "Taekwondo", icon: "packs/img/venir-taekwondo.webp" },
  { nom: "Capoeira", icon: "packs/img/venir-capoeira.webp" },
  { nom: "Kali / Eskrima", icon: "packs/img/venir-kali.webp" },
  { nom: "Krav Maga", icon: "packs/img/venir-krav-maga.webp" },
  { nom: "Mobilité", icon: "packs/img/venir-mobilite.webp" },
  { nom: "Musculation", icon: "packs/img/venir-musculation.webp" },
  { nom: "Préparation physique", icon: "packs/img/venir-prepa-physique.webp" },
  { nom: "Pilates", icon: "packs/img/venir-pilates.webp" },
  { nom: "Kendo", icon: "packs/img/venir-kendo.webp" },
  { nom: "Wing Chun", icon: "packs/img/venir-wing-chun.webp" },
  { nom: "Sumo", icon: "packs/img/venir-sumo.webp" },
];

const cle = (s: string) => s.trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");

/** Les disciplines à venir qui n'ont PAS déjà de pack au catalogue. */
export function disciplinesSansPack(
  catalogue: readonly { discipline?: string; title: string }[],
): readonly DisciplineAVenir[] {
  const publiees = new Set(catalogue.flatMap((p) => [cle(p.discipline ?? ""), cle(p.title)]));
  return DISCIPLINES_A_VENIR.filter((d) => !publiees.has(cle(d.nom)));
}
