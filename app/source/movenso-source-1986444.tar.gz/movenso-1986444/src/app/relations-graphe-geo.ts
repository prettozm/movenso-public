/**
 * RELATIONS — GÉOMÉTRIE DU GRAPHE (extraite de relations-carte.ts, D-375).
 * Placement par rôle, séparation sans chevauchement, courbes hub↔carte,
 * hauteur adaptée à la raison, boîte englobante. Fonctions PURES : elles
 * prennent leurs entrées, ne touchent ni au DOM ni à l'état de vue. La couche
 * de rendu (relations-carte.ts) était au plafond du cliquet ; sortir ce qui ne
 * dessine pas lui rend de la place pour la passe visuelle (médaillon, zones).
 */

import type { RoleRelation } from "../domaine/modele.ts";

// Géométrie de la scène (pixels « scène », avant transform). Cartes assez
// grandes pour une vignette 16/10 + nom + raison ; écarts pensés pour ne pas se
// chevaucher aux tailles usuelles. Le hub est un MÉDAILLON carré (D-375) : plus
// petit que les cartes, il laisse les techniques reliées porter le regard.
export const CARW = 176, CARH = 150, HUBW = 132, HUBH = 132;

// Grappe compacte (D-375) : les voisins se serrent autour du médaillon pour que
// TOUT le premier saut tienne à l'écran d'un téléphone, comme sur la maquette —
// le fit peut alors les montrer sans clipper les colonnes avant/après.
const COLX = 306, ROWY = 276, GAPV = 164, GAPH = 196; // écarts colonne / rangée (internes au placement)

export const CAP_CARTE = 3; // cartes par rôle avant regroupement « +N » (un-saut aéré, D-375)
export const MARGE = 48; // marge de scène autour du contenu

/** Ancres de placement par rôle (centre = origine 0,0). */
export const ANCRE_ROLE: Record<RoleRelation, { axe: "v" | "h"; ax: number; ay: number }> = {
  before: { axe: "v", ax: -COLX, ay: 0 },
  after: { axe: "v", ax: COLX, ay: 0 },
  peer: { axe: "h", ax: 0, ay: -ROWY }, // voisins : en haut
  opposition: { axe: "h", ax: 0, ay: ROWY },
  context: { axe: "v", ax: -COLX, ay: ROWY }, // « présente dans » : bas-gauche
};

// Dépliage multi-niveaux (D-158) : garde-fous anti « boule de poils ».
export const EXP_ENFANTS = 4; // enfants max ajoutés par dépliage (les plus prioritaires)
export const EXP_D = 265; // distance parent → enfants (dans l'axe opposé au hub)
export const MAX_NOEUDS = 40; // plafond global de cartes visibles

export type NoeudCarte = {
  x: number; y: number; w: number; h: number; // centre + taille, hub à l'origine
  nom: string; fam: string; role: RoleRelation | null;
  centre?: boolean; id?: string; plus?: number; absente?: boolean;
  note?: string; alerte?: string;
  /** Profondeur (D-158) : 0 = hub, 1 = relations directes, 2+ = déplié. */
  niveau?: number;
  /** Nombre de liens ENCORE INVISIBLES de ce nœud (badge « +n » de dépliage). */
  depl?: number;
  /** true : ce nœud est actuellement déplié (badge « − »). */
  deplie?: boolean;
};

export function placerNoeud(anc: { axe: "v" | "h"; ax: number; ay: number }, i: number, total: number): { x: number; y: number } {
  return anc.axe === "v"
    ? { x: anc.ax, y: anc.ay - ((total - 1) * GAPV) / 2 + i * GAPV }
    : { x: anc.ax - ((total - 1) * GAPH) / 2 + i * GAPH, y: anc.ay };
}

/** Courbe de Bézier hub↔carte ; horizontale pour avant/après (ligne de temps),
 *  verticale sinon. Coordonnées « scène » (déjà décalées, ≥ 0). */
export function courbeCarte(c: NoeudCarte, n: NoeudCarte, role: RoleRelation): string {
  if (role === "before" || role === "after") {
    const x1 = c.x + (n.x < c.x ? -c.w / 2 : c.w / 2), y1 = c.y;
    const x2 = n.x + (n.x < c.x ? n.w / 2 : -n.w / 2), y2 = n.y;
    const mx = (x1 + x2) / 2;
    return `M${x1} ${y1} C ${mx} ${y1} ${mx} ${y2} ${x2} ${y2}`;
  }
  const y1 = c.y + (n.y < c.y ? -c.h / 2 : c.h / 2), x1 = c.x;
  const y2 = n.y + (n.y < c.y ? n.h / 2 : -n.h / 2), x2 = n.x;
  const my = (y1 + y2) / 2;
  return `M${x1} ${y1} C ${x1} ${my} ${x2} ${my} ${x2} ${y2}`;
}

/** Hauteur d'une carte selon sa raison (D-159/D-160) : le texte ne se tronque
 *  JAMAIS — la carte grandit autant que nécessaire (estimation prudente :
 *  ≈22 caractères par ligne à cette largeur, plafond large à 8 lignes). */
export function hauteurCarte(note: string | undefined): number {
  if (!note) return CARH;
  return CARH + Math.min(8, Math.ceil(note.length / 22)) * 13;
}

/** Interdiction de chevauchement (D-159, durci D-160) : relaxation SYMÉTRIQUE —
 *  deux cartes qui se recouvrent s'écartent chacune de la moitié de la
 *  pénétration le long de l'axe de moindre recouvrement (seul le hub est fixe :
 *  l'autre carte prend alors tout l'écart). L'écartement symétrique converge là
 *  où « une seule bouge » oscillait entre deux voisins concurrents. */
export function separerNoeuds(noeuds: NoeudCarte[]): void {
  const M = 16; // marge minimale entre cartes
  for (let iter = 0; iter < 120; iter++) {
    let bouge = false;
    for (let i = 0; i < noeuds.length; i++) {
      for (let j = i + 1; j < noeuds.length; j++) {
        const a = noeuds[i]!, c = noeuds[j]!;
        const dx = c.x - a.x, dy = c.y - a.y;
        const px = (a.w + c.w) / 2 + M - Math.abs(dx);
        const py = (a.h + c.h) / 2 + M - Math.abs(dy);
        if (px <= 0 || py <= 0) continue;
        const axeX = px < py;
        const signe = axeX ? Math.sign(dx || 1) : Math.sign(dy || 1);
        const pen = axeX ? px : py;
        const depA = a.centre ? 0 : c.centre ? pen : pen / 2;
        const depC = c.centre ? 0 : a.centre ? pen : pen / 2;
        if (axeX) { a.x -= signe * depA; c.x += signe * depC; }
        else { a.y -= signe * depA; c.y += signe * depC; }
        bouge = true;
      }
    }
    if (!bouge) break;
  }
}
