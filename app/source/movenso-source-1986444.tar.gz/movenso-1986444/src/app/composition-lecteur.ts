/**
 * LECTEUR d'une composition (UI-5, D-323) — trois lectures d'un coup d'œil.
 *
 * Le moteur ne bouge pas : chrono, voix, préparation, suspension en
 * arrière-plan restent exactement ce qu'ils sont (D-125/D-170). Ce module
 * n'ajoute que de la LECTURE, et seulement à partir de ce qui existe déjà :
 *
 *  - **où j'en suis** : une barre de progression, là où il n'y avait qu'un
 *    « 2 / 6 » à lire ;
 *  - **combien il reste** : un anneau autour du décompte — au bord du tatami on
 *    ne lit pas un nombre, on voit une part qui se vide ;
 *  - **qui fait le pas suivant** : le bloc « Ensuite » portait le nom du pas et
 *    rien d'autre. À deux, savoir si c'est à soi ou à l'autre est l'information
 *    la plus utile de l'écran, et elle était dans les données depuis D-227.
 *
 * Ce que ce module NE fait pas, et pourquoi :
 *  - **la liste des rôles en en-tête** (« 2 temps · Tori · Uke ») : le rôle
 *    ACTIF est déjà sur la carte, et le suivant est dans « Ensuite ». Un
 *    troisième endroit qui dit les mêmes noms est le piège de D-253 ;
 *  - **la vignette en fond du cadran** : elle est au-dessus du nom, lisible ;
 *    en fond derrière un décompte, elle ne serait plus ni l'une ni l'autre.
 */

import { html, nothing, type TemplateResult } from "lit";
import type { Bloc, Composition } from "../domaine/modele.ts";
import { acteurDuBloc, formaterDuree } from "../domaine/composition.ts";
import type { MovensoApp } from "./racine.ts";

/** Note où l'on en est (UI-6, D-324) — écrit par le LECTEUR, sans geste de
 *  l'utilisateur, et **seulement quand la position change** : appelé au rendu,
 *  il ne doit ni écrire à chaque passe ni demander un rendu (ce serait une
 *  boucle). Une seule entrée : lire une autre composition remplace la
 *  précédente. */
export function noterLecture(app: MovensoApp, compositionId: string, index: number): void {
  const d = app.preferences.derniereLecture;
  if (d && d.compositionId === compositionId && d.index === index) return;
  app.preferences = { ...app.preferences, derniereLecture: { compositionId, index, quand: new Date().toISOString() } };
  void app.stockage.sauvegarderPreferences(app.preferences);
}

/** Efface la reprise (UI-6, D-324) : une séance TERMINÉE n'a rien à continuer.
 *  « Quitter » ne l'appelle pas — c'est justement le cas à reprendre. */
export function oublierLecture(app: MovensoApp): void {
  if (!app.preferences.derniereLecture) return;
  const { derniereLecture: _, ...reste } = app.preferences;
  app.preferences = reste;
  void app.stockage.sauvegarderPreferences(app.preferences);
}

/** Barre de progression de la séance — DÉRIVÉE du rang, jamais d'un compteur
 *  séparé. `aria-hidden` : le « N / M » voisin dit déjà la même chose à la voix,
 *  et deux annonces pour une information en font une de trop. */
export function barreProgression(rang: number, total: number): TemplateResult {
  const part = total > 0 ? Math.min(1, Math.max(0, rang / total)) : 0;
  return html`<div class="entrainement-jauge" aria-hidden="true">
    <span style=${`width:${(part * 100).toFixed(1)}%`}></span>
  </div>`;
}

/** Le rôle d'un bloc, prêt à afficher — teinte par RANG (D-227), jamais par nom. */
function pastilleRole(compo: Composition, bloc: Bloc): TemplateResult | typeof nothing {
  const a = acteurDuBloc(compo, bloc);
  if (!a) return nothing;
  const rang = (compo.acteurs ?? []).findIndex((x) => x.id === a.id) + 1;
  return html`<em class="badge-role" data-acteur-rang=${rang}>${a.nom}</em>`;
}

/** Bloc « Ensuite » : ce qui vient, et SURTOUT qui le fait. Quand le rôle
 *  change d'un pas à l'autre, la passation se lit littéralement (« Tori →
 *  Uke ») : c'est le moment où l'un se prépare et l'autre se retire, et aucun
 *  mot ne le dit mieux que les deux noms côte à côte. */
export function blocEnsuite(
  app: MovensoApp,
  compo: Composition,
  courant: Bloc,
  suivant: Bloc,
): TemplateResult {
  const nom =
    suivant.type === "technique"
      ? (suivant.techniqueId && app.technique(suivant.techniqueId)?.nom) || suivant.texte || "technique"
      : suivant.texte || (suivant.dureeSec !== undefined ? formaterDuree(suivant.dureeSec) : "Segment");
  const a = acteurDuBloc(compo, courant);
  const b = acteurDuBloc(compo, suivant);
  const passation = !!a && !!b && a.id !== b.id;
  return html`
    <div class="entrainement-suite">
      <span class="suite-libelle">Ensuite</span>
      <span class="suite-corps">
        ${passation
          ? html`<span class="suite-passation">${pastilleRole(compo, courant)}
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M4 12h14M13 7l5 5-5 5"/></svg>
              ${pastilleRole(compo, suivant)}</span>`
          : pastilleRole(compo, suivant)}
        <span class="suite-nom">${nom}</span>
        ${suivant.dureeSec !== undefined ? html`<span class="suite-duree">${formaterDuree(suivant.dureeSec)}</span>` : nothing}
      </span>
    </div>`;
}

/** Anneau du décompte : la part de la phase COURANTE qui reste. Les deux
 *  bornes se dérivent au rendu (durée du pas, ou durée de préparation) — le
 *  chrono ne gagne aucun champ, donc le moteur n'a pas bougé d'une ligne. */
export function anneauChrono(restant: number, total: number, contenu: TemplateResult): TemplateResult {
  const part = total > 0 ? Math.min(1, Math.max(0, restant / total)) : 0;
  return html`<div class="entrainement-anneau" style=${`--part:${part.toFixed(4)}`} aria-hidden="false">${contenu}</div>`;
}
