/**
 * FICHE DE CONSULTATION d'une composition (UI-2, D-319) — l'écran qui manquait.
 *
 * Avant, ouvrir une composition menait au même écran que la modifier : on
 * éditait le contenu d'un pack sans l'avoir voulu. La fiche intercale la
 * LECTURE — identité, provenance, ce que ça dure, qui agit, un aperçu des
 * étapes — et laisse l'édition derrière un geste explicite (le ✎).
 *
 * Trois règles tenues, chacune née d'une mesure sur les packs publiés :
 *  - la ligne de méta se compose de CE QUI EXISTE (aucun pack ne réunit rôles
 *    ET durées : le kata judo a Tori/Uke sans durée, la séance taïso l'inverse) ;
 *  - les séparateurs d'un kata (« — Te-waza — ») sont des JALONS, pas des
 *    étapes numérotées : ils ne comptent pas comme un geste à faire ;
 *  - une seule action forte (Démarrer) ; Dupliquer et Planifier au second rang.
 *
 * Ce que la fiche NE fait pas : aplatir une composition à plusieurs. Les
 * planches montraient une liste numérotée pour tout ; or la lecture « en temps »
 * (D-235) dit qui agit EN MÊME TEMPS que qui, ce qu'une liste plate ne sait pas
 * dire. Une fiche à plusieurs garde donc son déroulé — on n'échange pas une
 * capacité contre une esthétique.
 */

import { html, nothing, type TemplateResult } from "lit";
import type { Bloc, Composition } from "../domaine/modele.ts";
import { decouperEnTemps, dureeTotale, estJalon, formaterDuree, lectureEnTemps, nombreDePas, texteJalon } from "../domaine/composition.ts";
import { vignetteTechnique } from "./vues.ts";
import type { MovensoApp } from "./racine.ts";

/** Combien d'étapes l'aperçu montre avant de proposer la suite. */
const APERCU = 5;

/** Compositions dont l'aperçu est déplié — état de SESSION (jamais persisté :
 *  ce n'est pas une préférence, c'est un geste en cours). */
const apercuDeplie = new Set<string>();

/** Le nom affiché d'une étape : la technique référencée, sinon son texte. */
function nomEtape(app: MovensoApp, bloc: Bloc): string {
  const t = bloc.techniqueId ? app.technique(bloc.techniqueId) : undefined;
  return t?.nom ?? ((bloc.texte ?? "").trim() || "Étape");
}

/** La seconde ligne d'une étape : la consigne d'abord (elle qualifie CE pas),
 *  complétée du sous-titre de la technique quand il ajoute quelque chose. */
function sousEtape(app: MovensoApp, bloc: Bloc): string {
  const t = bloc.techniqueId ? app.technique(bloc.techniqueId) : undefined;
  const morceaux = [t?.nomTraditionnel, bloc.consigne].filter((x): x is string => !!x?.trim());
  return morceaux.join(" · ");
}

/** Le rôle d'un bloc, avec son RANG (la teinte suit le rang, D-227). */
function roleDe(compo: Composition, bloc: Bloc): { nom: string; rang: number } | null {
  const i = (compo.acteurs ?? []).findIndex((a) => a.id === bloc.acteurId);
  return i < 0 ? null : { nom: compo.acteurs![i]!.nom, rang: i + 1 };
}

/** Vignette de la composition : celle de sa première technique. Volontairement
 *  DISCRÈTE (54 px) — mesuré sur les packs, elle se répète beaucoup (taïso :
 *  16 séances pour 2 vignettes distinctes), donc elle ne peut pas porter
 *  l'identité de la composition (R1). */
function vignetteCompo(app: MovensoApp, compo: Composition): TemplateResult | typeof nothing {
  const premier = compo.blocs.find((x) => x.type === "technique" && x.techniqueId);
  const t = premier?.techniqueId ? app.technique(premier.techniqueId) : undefined;
  return t ? vignetteTechnique(app, t) : nothing;
}

/** D'où vient une composition, DIT À L'UTILISATEUR (D-320) — un seul lieu pour
 *  ce libellé (D-253), utilisé par la fiche et par le contexte de la barre.
 *  Trois cas et pas un de plus : à moi (rien à dire), attribuée (on cite
 *  l'auteur), venue d'un pack sans attribution (« Pack », et surtout pas
 *  `provenance` — « enseignement » est un mot du modèle, ni l'identité du pack,
 *  qui est un ULID). Aucun des six packs officiels n'attribue ses compositions :
 *  c'est donc le troisième cas qui s'affiche en vrai. */
export function origineLisible(compo: Composition): string | null {
  if (compo.provenance === "personnel") return null;
  return compo.attribution?.trim() || "Pack";
}

/** En-tête de la fiche : vignette, titre, provenance, description, et la ligne
 *  de statistiques — toutes DÉRIVÉES, aucune saisie. */
export function enteteFiche(app: MovensoApp, compo: Composition): TemplateResult {
  const source = origineLisible(compo);
  return html`
    <div class="fiche-compo-tete">
      <div class="fiche-compo-vignette">${vignetteCompo(app, compo)}</div>
      <div class="fiche-compo-identite">
        <h1>${compo.nom}</h1>
        ${source ? html`<span class="badge-source">${source}</span>` : nothing}
      </div>
    </div>
    ${compo.description ? html`<p class="fiche-compo-desc">${compo.description}</p>` : nothing}
    ${statsCompo(compo)}
  `;
}

/** Ce que la composition PÈSE : étapes (jalons exclus), durée totale si elle
 *  existe, rôles nommés ou « Seul ». Tout DÉRIVÉ, rien de saisi — et un seul
 *  lieu pour ce calcul (D-253), partagé par la fiche de lecture (UI-2) et par
 *  l'éditeur (UI-3), qui n'avait qu'un « ⏱ Séance · 20 min » et ne disait ni le
 *  nombre de pas ni qui agit. */
export function statsCompo(compo: Composition): TemplateResult {
  const pas = nombreDePas(compo);
  const total = dureeTotale(compo);
  const roles = compo.acteurs ?? [];
  // Le nombre de TEMPS n'est pas le nombre d'étapes (deux pas simultanés font un
  // seul temps) : il ne s'affiche donc que là où il veut dire quelque chose —
  // une composition qui se lit en temps — et dans LE MÊME bandeau, pour qu'on
  // puisse comparer les deux chiffres au lieu de les croire contradictoires.
  const temps = lectureEnTemps(compo) ? decouperEnTemps(compo).length : 0;
  return html`
    <div class="fiche-compo-stats">
      <span><b>${pas}</b> étape${pas > 1 ? "s" : ""}</span>
      ${temps > 0 ? html`<span><b>${temps}</b> temps</span>` : nothing}
      ${total > 0 ? html`<span><b>${formaterDuree(total)}</b></span>` : nothing}
      ${roles.length >= 2
        ? html`<span class="fiche-compo-roles">${roles.map(
            (a, i) => html`<em data-acteur-rang=${i + 1}>${a.nom}</em>`,
          )}</span>`
        : html`<span>Seul</span>`}
    </div>`;
}

/** Aperçu des étapes : les cinq premières, puis « Voir les N étapes » qui
 *  déplie sur place (jamais un second écran — la fiche reste une fiche). */
export function apercuEtapes(app: MovensoApp, compo: Composition): TemplateResult {
  const deplie = apercuDeplie.has(compo.id);
  const visibles = compo.blocs.filter((x) => x.type !== "media");
  const montres = deplie ? visibles : visibles.slice(0, APERCU);
  let rang = 0;
  return html`
    <h2 class="fiche-compo-section">Aperçu des étapes</h2>
    <ol class="apercu-etapes">
      ${montres.map((bloc) => {
        if (estJalon(bloc)) return html`<li class="apercu-jalon">${texteJalon(bloc)}</li>`;
        rang++;
        const role = roleDe(compo, bloc);
        const sous = sousEtape(app, bloc);
        const t = bloc.techniqueId ? app.technique(bloc.techniqueId) : undefined;
        return html`<li class="apercu-etape">
          <span class="apercu-no">${rang}</span>
          <span class="apercu-vignette">${t ? vignetteTechnique(app, t) : nothing}</span>
          <span class="apercu-texte">
            <span class="apercu-nom">${nomEtape(app, bloc)}${role
              ? html`<em class="badge-role" data-acteur-rang=${role.rang}>${role.nom}</em>`
              : nothing}</span>
            ${sous ? html`<span class="apercu-sous">${sous}</span>` : nothing}
          </span>
          ${bloc.dureeSec ? html`<span class="apercu-duree">${formaterDuree(bloc.dureeSec)}</span>` : nothing}
        </li>`;
      })}
    </ol>
    ${visibles.length > APERCU
      ? html`<button class="apercu-suite" @click=${() => {
          deplie ? apercuDeplie.delete(compo.id) : apercuDeplie.add(compo.id);
          app.requestUpdate();
        }}>${deplie ? "Replier l'aperçu" : `Voir les ${visibles.length} étapes`}</button>`
      : nothing}
  `;
}

/** Barre d'actions de la fiche : UNE action forte, deux au second rang (R9).
 *  « Planifier » est présent mais DÉSACTIVÉ et le dit — la planification
 *  n'existe pas encore (AG-1). Un bouton qui ne fait rien est un mensonge ;
 *  un bouton qui explique pourquoi il attend est une information. */
export function barreActionsFiche(app: MovensoApp, compo: Composition): TemplateResult {
  return html`
    <div class="fiche-compo-actions">
      ${compo.blocs.length
        ? html`<button class="action-forte" @click=${() => app.demarrerEntrainement(compo.id)}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 5v14l12-7z"/></svg>
            Démarrer</button>`
        : nothing}
      <button class="action-seconde" @click=${() => void app.dupliquerComposition(compo.id)}>Dupliquer</button>
      <button class="action-seconde" disabled title="La planification arrive avec l'Agenda">
        Planifier <small>bientôt</small>
      </button>
    </div>
  `;
}
