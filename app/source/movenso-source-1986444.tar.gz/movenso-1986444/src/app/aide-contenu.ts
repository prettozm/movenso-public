/**
 * CONTENU DE L'AIDE (D-362) — la liste ET les sous-écrans, à un seul endroit.
 *
 * Un tableau, deux rendus : la page d'aide en tire ses rangées, le sous-écran
 * en tire son contenu. Deux listes de la même chose divergent toujours
 * (D-252/D-253) — ici, ajouter une rubrique se fait en un seul point.
 *
 * RÈGLE DE RÉDACTION, et c'est la seule qui compte : chaque phrase se VÉRIFIE
 * dans le code avant d'être écrite. D-310 affirmait cette vérification faite ;
 * elle ne l'était pas, et un checker a trouvé six phrases fausses (D-346).
 * La confrontation de la refonte au code en a trouvé trois de plus, que
 * personne n'avait vues (D-358) :
 *
 *   - la recherche ne couvre PAS « le texte des fiches » : `recherche.ts:18-50`
 *     cherche le nom, le nom traditionnel et les notes personnelles, rien
 *     d'autre. Les descriptions des packs ne sont pas cherchées ;
 *   - « Plus › Médias » n'existe QU'EN MODE AVANCÉ (`plus.ts:170-177`) : le
 *     citer envoyait l'utilisateur par défaut vers une entrée absente ;
 *   - la section « Compositions » d'une fiche est conditionnée à la bêta
 *     (`vues.ts:598`) : l'annoncer sans le dire décrivait un écran que la
 *     plupart n'ont pas.
 *
 * Les deux textes des protections restent IMPORTÉS de l'écran Sécurité — celui
 * qui les fait activer. L'aide en avait une seconde version, plus courte, qui
 * avait déjà divergé au commit qui la créait (D-346).
 *
 * PAS DE CHEMIN DE MENU dans ces textes (consigne porteur) : « Plus › X » est
 * faux à la refonte suivante, et un renvoi mort dans l'écran qui sert à
 * s'orienter coûte plus cher qu'une phrase vague (D-236, D-346 ①).
 */

import { html, nothing, type TemplateResult } from "lit";
import { EXPLICATIONS } from "./atelier-reglages.ts";
import type { CleIllustration } from "./aide-illustrations.ts";
import type { MovensoApp } from "./racine.ts";

export type CleRubrique =
  | "demarrer" | "retrouver" | "fiche" | "medias" | "relations"
  | "partager" | "donnees" | "securite" | "limites";

/** Une réponse : un titre court, deux lignes au plus. L'aide doit donner
 *  l'impression qu'on trouve en vingt secondes, pas qu'on lit un manuel. */
interface Reponse { titre: string; corps: TemplateResult }

interface Rubrique {
  cle: CleRubrique;
  /** Titre de la rangée ET du sous-écran — un seul lieu. Fonction pour la
   *  seule rubrique dont le nom dépend de ce qui est activé. */
  titre: (app: MovensoApp) => string;
  resume: string;
  illustration: CleIllustration;
  /** Absente = toujours visible. Sinon, la rubrique n'existe que si la
   *  capacité qu'elle décrit existe : décrire à quelqu'un un produit qu'il
   *  n'a pas est le même défaut que décrire un produit qui n'existe pas. */
  visible?: (app: MovensoApp) => boolean;
  idee: string;
  sousIdee: string;
  reponses: (app: MovensoApp) => Reponse[];
  alerte?: TemplateResult;
}

const RUBRIQUES: readonly Rubrique[] = [
  {
    cle: "demarrer",
    titre: () => "Bien démarrer",
    resume: "Pack, fichier, sauvegarde, ou de zéro.",
    illustration: "demarrer",
    idee: "Rien ne s’écrit sans ton accord.",
    sousIdee: "Avant un import, Movenso te montre ce qui sera ajouté ou mis à jour.",
    reponses: () => [
      {
        titre: "Quatre façons de commencer",
        corps: html`Installer un <b>starter pack</b> pour partir d’une base déjà structurée, importer un
          <b>.movpack</b> qu’on t’a transmis, <b>restaurer une sauvegarde</b>, ou <b>partir de zéro</b>.`,
      },
      {
        titre: "Un pack s’annonce avant de s’installer",
        corps: html`Tu vois ce qu’il ajoute et ce qu’il met à jour, puis tu confirmes. Il se retire entièrement.`,
      },
      {
        titre: "Partir de zéro",
        corps: html`Crée ta discipline, ses catégories et ses niveaux, puis ajoute tes premières techniques
          depuis la Bibliothèque.`,
      },
    ],
  },
  {
    cle: "retrouver",
    titre: () => "Retrouver une technique",
    resume: "Rechercher, filtrer, retrouver ses favoris.",
    illustration: "retrouver",
    idee: "Cherche comme tu prononces.",
    sousIdee: "Accents, tirets et majuscules sont ignorés : « o soto » trouve « Ō-soto-gari ».",
    reponses: () => [
      {
        // `recherche.ts:18-50` — les TROIS champs cherchés, et rien d'autre.
        titre: "Ce que la recherche regarde",
        corps: html`Le <b>nom</b> de la technique, son <b>nom traditionnel</b>, et les <b>notes que tu as
          écrites toi</b>. Elle ne quitte jamais l’appareil.`,
      },
      {
        // `vues.ts:336-339` — le cœur bascule `favorisSeuls` (D-336).
        titre: "Le cœur n’affiche que tes favoris",
        corps: html`Il est dans la barre de recherche. Le ♥ d’une fiche l’y range.`,
      },
      {
        titre: "Les filtres se retirent un par un",
        corps: html`Discipline, catégorie et niveau. Les filtres posés reviennent en puces que tu peux retirer.`,
      },
    ],
  },
  {
    cle: "fiche",
    titre: () => "Lire une fiche",
    resume: "Image, points clés, relations et alertes.",
    illustration: "fiche",
    idee: "Une fiche dit ce que fait la technique, et ce qui l’entoure.",
    sousIdee: "Chaque section reste visible même vide, avec son invitation.",
    reponses: (app) => [
      {
        titre: "Ce qu’elle rassemble",
        corps: html`La <b>description</b>, les <b>points clés</b>, et les <b>relations</b> : ce qui prépare,
          suit, contre ou ressemble, <b>avec la raison du lien</b>.${
          // `vues.ts:598` : la section Compositions n'existe QUE sous la bêta.
          (app.preferences.compositionsBeta ?? false)
            ? html` Elle indique aussi les <b>compositions</b> qui l’utilisent.`
            : nothing}`,
      },
      {
        titre: "Ton commentaire est à toi",
        corps: html`C’est une note personnelle. Elle ne part <b>ni dans un pack</b>, ni ailleurs.`,
      },
      {
        titre: "Modifier",
        corps: html`Le bouton flottant en bas à droite passe la fiche en édition. La barre du haut garde le
          retour, le ♥ et le partage.`,
      },
    ],
    alerte: html`Certaines techniques portent une <b>alerte</b>. Lis-la avant de pratiquer.`,
  },
  {
    cle: "medias",
    titre: () => "Ajouter des médias",
    resume: "Illustration, vidéo locale ou lien vidéo.",
    illustration: "medias",
    idee: "Ce que tu filmes reste chez toi.",
    sousIdee: "Un lien reste un lien : la vidéo se lit chez son hébergeur, rien n’est copié.",
    reponses: () => [
      {
        titre: "Trois sources",
        corps: html`Une <b>illustration</b>, une <b>vidéo filmée ou choisie</b> sur l’appareil, ou un
          <b>lien</b> vers une vidéo en ligne.`,
      },
      {
        titre: "Changer ce qui représente la technique",
        corps: html`Touche l’image de la fiche : tu choisis une image, une vidéo, ou tu la retires.`,
      },
      {
        titre: "Filmer fonctionne hors ligne",
        corps: html`La vidéo est écrite sur l’appareil et n’est <b>jamais envoyée</b> nulle part.`,
      },
    ],
  },
  {
    cle: "relations",
    // Le titre suit ce qui est ACTIVÉ : annoncer les deux quand une seule
    // existe décrit un produit que l'utilisateur n'a pas.
    titre: (app) => {
      const compo = app.preferences.compositionsBeta ?? false;
      const rel = app.preferences.vueRelationBeta ?? false;
      return compo && rel ? "Relations & compositions" : compo ? "Compositions" : "Relations";
    },
    resume: "Relier des techniques, construire un parcours.",
    illustration: "relations",
    visible: (app) => (app.preferences.compositionsBeta ?? false) || (app.preferences.vueRelationBeta ?? false),
    idee: "Une technique n’est jamais seule.",
    sousIdee: "Chaque lien porte sa raison, jamais une flèche nue.",
    reponses: (app) => [
      ...((app.preferences.vueRelationBeta ?? false)
        ? [{
            titre: "Naviguer de proche en proche",
            corps: html`Depuis une technique, tu vois ce qui la prépare, l’enchaîne, la contre ou lui
              ressemble. Toucher une technique liée la place au centre.
              <button class="chip-filtre aide-decouvrir" @click=${() => app.ouvrirBienvenueRelations()}>
                Découvrir Relations
              </button>`,
          }]
        : []),
      ...((app.preferences.compositionsBeta ?? false)
        ? [{
            titre: "Assembler une composition",
            corps: html`Une composition met des techniques dans un ordre : séance, kata, progression,
              démonstration.`,
          },
          {
            titre: "La lire pas à pas",
            corps: html`En lecture, Movenso déroule les étapes une à une, avec le chronomètre quand la
              composition en porte un.`,
          }]
        : []),
    ],
  },
  {
    cle: "partager",
    titre: () => "Partager ou sauvegarder",
    resume: "Un pack transmet, une sauvegarde restitue.",
    illustration: "partager",
    idee: "Partager n’est pas sauvegarder.",
    sousIdee: "Un colis part chez quelqu’un. Un coffre te rend ton contenu.",
    reponses: () => [
      {
        titre: "Le pack transmet",
        corps: html`Un <b>.movpack</b> emporte une discipline vers quelqu’un d’autre. Tes notes personnelles
          et tes captures vidéo n’y montent pas.`,
      },
      {
        titre: "La sauvegarde restitue",
        corps: html`<b>Complète</b> : bibliothèque, notes et vidéos locales, de quoi repartir sur un autre
          appareil. <b>Légère</b> : tout sauf les vidéos.`,
      },
      {
        titre: "La corbeille ne remplace pas",
        corps: html`La corbeille et les points de restauration rattrapent une erreur récente, mais vivent sur
          <b>le même appareil</b> que tes données.`,
      },
    ],
  },
  {
    cle: "donnees",
    titre: () => "Protéger ses données",
    resume: "Local, stockage, PIN et restauration.",
    illustration: "donnees",
    idee: "Tout vit ici, et nulle part ailleurs.",
    sousIdee: "Aucun serveur, aucun compte, aucune synchronisation.",
    reponses: () => [
      {
        titre: "Où elles vivent",
        corps: html`Dans <b>l’espace privé de Movenso</b>, sur cet appareil. L’écran Stockage dit ce qu’elles
          occupent et si le navigateur en garantit la persistance.`,
      },
      {
        titre: "Ce qui peut les effacer",
        corps: html`Désinstaller l’application, ou effacer les données du site dans le navigateur,
          <b>efface tout</b>. C’est exactement ce contre quoi une sauvegarde protège.`,
      },
      {
        // D-253 : les deux protections se décrivent à un SEUL endroit.
        titre: "Le PIN est facultatif",
        corps: html`Deux protections indépendantes, et la <b>consultation n’est jamais bloquée</b>.
          <b>Modifications</b> — ${EXPLICATIONS.modifications} <b>Suppressions</b> —
          ${EXPLICATIONS.suppressions} Le PIN reste sur cet appareil : il ne part ni dans un pack, ni dans une
          sauvegarde.`,
      },
    ],
    alerte: html`<b>Un fichier de sauvegarde n’est pas chiffré.</b> Garde-le sur un appareil ou un espace de
      confiance.`,
  },
  {
    cle: "securite",
    titre: () => "Sécurité de la pratique",
    resume: "Pratiquer avec prudence et repères.",
    illustration: "securite",
    idee: "Des bases pour commencer, pas un professeur.",
    sousIdee: "Les starter packs sont des bases de travail, non exhaustives.",
    reponses: () => [
      {
        titre: "Ils ne remplacent pas un enseignement",
        corps: html`En cas d’écart, ce que dit <b>ton enseignant</b> prime.`,
      },
      {
        titre: "Un cadre adapté",
        corps: html`Pratique dans un espace adapté, avec un partenaire consentant, à un niveau qui convient à
          chacun.`,
      },
      {
        titre: "Les alertes se lisent avant",
        corps: html`Certaines techniques en portent une. Arrête en cas de <b>douleur aiguë</b>, de vertige ou
          de malaise.`,
      },
    ],
  },
  {
    cle: "limites",
    titre: () => "Limites connues",
    resume: "Ce que Movenso ne sait pas encore faire.",
    illustration: "limites",
    idee: "Movenso évolue encore.",
    sousIdee: "Trois limites sont connues, et il vaut mieux les savoir.",
    reponses: () => [
      {
        titre: "Export volumineux",
        corps: html`Au-delà d’environ <b>4 Go</b>, un export complet peut échouer. Préfère une sauvegarde
          légère, ou plusieurs packs.`,
      },
      {
        titre: "Version web",
        corps: html`Tes données restent locales, mais une connexion peut être nécessaire pour charger ou
          mettre à jour l’application et pour ouvrir une ressource externe.`,
      },
      {
        titre: "Lecteur d’écran",
        corps: html`La prise en charge continue d’être améliorée. Si un parcours coince, dis-le : les
          remontées font foi.`,
      },
    ],
  },
];

/** Les rubriques visibles pour CET utilisateur, dans l'ordre de l'écran. */
export function rubriquesVisibles(app: MovensoApp): readonly Rubrique[] {
  return RUBRIQUES.filter((r) => !r.visible || r.visible(app));
}

export function rubriqueParCle(cle: CleRubrique): Rubrique | undefined {
  return RUBRIQUES.find((r) => r.cle === cle);
}

/* ---------- rubrique ouverte : état de SESSION, hors `racine.ts` ----------
   `racine.ts` est au cliquet (D-278) : sa taille peut descendre, jamais
   remonter. Cet état n'appartient qu'à l'aide et ne survit pas au
   rechargement — il vit donc ici, comme `publierEtat` vit dans l'écran qui
   s'en sert. */
let sujetOuvert: CleRubrique | null = null;

export function ouvrirSujet(app: MovensoApp, cle: CleRubrique): void {
  sujetOuvert = cle;
  app.ouvrirPlusSection("aide-sujet");
}

export function sujetCourant(): CleRubrique | null {
  return sujetOuvert;
}

/** Titre de la barre haute pour le sous-écran ouvert (`plus.ts`). */
export function titreSujetCourant(app: MovensoApp): string {
  const r = sujetOuvert ? rubriqueParCle(sujetOuvert) : undefined;
  return r ? r.titre(app) : "Aide";
}

export type { Rubrique };
