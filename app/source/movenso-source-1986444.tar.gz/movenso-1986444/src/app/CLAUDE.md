# `src/app/` — l'interface, et surtout pas la logique

- **Aucune responsabilité nouvelle dans `racine.ts`.** Sa taille relève du
  **cliquet** (D-278) : elle peut descendre, jamais remonter — pas même d'une
  ligne. Le fichier est une **façade** : état réactif + délégation. La logique
  va dans `services/`. Après une réduction : `npm run cliquet`.
- **Deux formes d'extraction, et le choix se lit à l'état privé** :
  - pas d'état privé → `export function geste(app, …)` dans `services/` ;
  - état privé qui n'appartient qu'à ce domaine → un **objet propriétaire**
    (`Protections`), qui le garde privé et expose des **gestes**. Sortir cet
    état en fonctions de service obligerait à le rendre public : on échangerait
    un problème de taille contre un problème d'encapsulation (D-274).
- **Une vue neuve reçoit ses données et ses rappels, jamais `app` entière**
  (D-204). Conversion opportuniste, pas de refonte.
- **UI ≠ métier.** Aucune règle de domaine ici : elle se teste sans navigateur,
  donc elle vit dans `src/domaine/`.
- **Le rendu est SYNCHRONE.** Ce qui demande une lecture de fichier se prépare
  avant (`preparerImages`), sinon le premier rendu montre des fiches nues.
- **Qualifier l'objet avant de corriger** (D-251) : qui l'écrit et quand ? à
  qui appartient la donnée ? jusqu'où voyage-t-elle ? qu'a le droit de
  l'écraser ? Deux champs qui se ressemblent à l'écran peuvent n'avoir aucun
  rapport — le titre est validé en édition, le commentaire est une note
  personnelle auto-enregistrée hors édition. Les traiter pareil a produit une
  perte de saisie silencieuse.
- **Pas de glisser-déposer** (D-233, WCAG 2.5.7) : flèches ▲/▼.
- **Rien ne part sans geste** : aucune requête sortante que l'utilisateur n'a
  pas demandée (vignettes distantes off par défaut, D-260).
