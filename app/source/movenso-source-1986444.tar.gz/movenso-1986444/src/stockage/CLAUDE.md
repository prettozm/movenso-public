# `src/stockage/` — un seul écrivain, jamais d'état à moitié écrit

Ce dossier est le seul endroit où une donnée peut être **perdue**. D'où :

- **`bibliotheque.json` a UN seul écrivain : `sauvegarder()`.** Toute mutation
  persistante y passe. La restauration avait son propre chemin, sans bascule
  ni file — le seul chemin non protégé, et il s'exerçait quand l'utilisateur
  récupérait d'un problème (D-258). `verifier:sources` refuse désormais toute
  écriture directe hors de `sauvegarder`.
- **Écriture transactionnelle, dans cet ordre** : temporaire → **relecture** →
  revalidation → bascule. Un résidu `.tmp` au démarrage est un commit
  interrompu : on l'écarte, l'état courant reste la vérité.
- **Les écritures sont sérialisées** (`#chaineSauvegarde`) : deux persistances
  ne s'entrelacent jamais sur le temporaire.
- **Les octets AVANT l'état qui les déclare.** Les images se posent d'abord,
  la bascule ensuite. C'est sûr sans transaction multi-fichiers parce que le
  nom est l'empreinte : l'écriture est **idempotente**, une interruption
  laisse au pire des octets en trop (D-269).
- **Ne jamais recalculer une identité fournie — la vérifier.** `poserImages`
  recalcule l'empreinte avant d'écrire : ici le nom devient l'identité pour
  toute la suite, le stockage ne croit pas son appelant (D-271).
- **Supprimer est irréversible, pas écrire.** Le balayage des fichiers
  orphelins est une opération SÉPARÉE et plus prudente que l'épuration de
  l'inventaire : un fichier en trop coûte de la place, un fichier manquant
  coûte une illustration. La corbeille et les fusions réversibles gardent des
  références — les oublier efface ce qui était encore restaurable.
- **Rien de personnel ne voyage.** Carnet, favoris, préférences d'appareil ne
  sortent jamais dans un pack.
- **Un rollback ne reconstruit jamais partiellement l'état** : il rend l'état
  d'avant, entier, ou il échoue en le disant.
