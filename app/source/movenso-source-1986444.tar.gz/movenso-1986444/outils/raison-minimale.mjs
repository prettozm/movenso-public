/**
 * COMBIEN DE CARACTÈRES FONT UNE RAISON (D-356).
 *
 * Deux gardes exigent qu'un choix soit justifié par écrit, et pas d'un mot :
 * les dépendances (`outils/dependances.json`, D-282) et les exclusions de
 * l'archive de source (`tools/hors-archive-source.mjs`, D-353). Le seuil est le
 * même parce que la règle est la même — « une justification d'un mot n'en est
 * pas une » — donc il n'a **qu'un lieu d'écriture** (D-253).
 *
 * L'ACCIDENT, et il est de la famille de ceux qu'on répare ici. D-353 avait
 * écrit 60 dans le test tout en citant la garde des dépendances comme autorité,
 * qui exige 20 : deux nombres pour une règle, à deux endroits. D-354 les a
 * fait COÏNCIDER — donc deux littéraux `20`, aucune dérivation, et rien pour
 * signaler qu'ils divergent le jour où l'un bouge. C'était la lettre du défaut
 * que le même commit prétendait corriger, et le checker l'a relevé deux tours
 * d'affilée. Le partage de la constante rend l'alignement gratuit ; la copie
 * le rendait provisoire.
 *
 * Relever ce seuil se fait donc ICI, une fois, et les deux gardes suivent.
 */

/** En deçà, ce n'est pas une raison — c'est une étiquette. */
export const RAISON_MINIMALE = 20;
