/**
 * LES CONSTANTES DE FORMAT, LUES À UN SEUL ENDROIT (D-285).
 *
 * L'incident : au refactoring D-274, VERSION_MOVPACK a déménagé de
 * `movpack.ts` vers `movpack-contrat.ts`. Le code a suivi — mais chaque outil
 * gardait sa PROPRE copie de l'adresse et de la regex : `versions` affichait
 * « ? », `source-du-build` écrivait `versionMovpack: null` dans build.json
 * (`Number(undefined)` → NaN → null), et la garde du site l'acceptait. Quatre
 * vérificateurs verts, et la publication suivante aurait menti en ligne.
 *
 * Ces scripts ne peuvent pas importer du TypeScript, le parsing reste. Mais
 * l'adresse et la regex ne vivent plus qu'ICI : le prochain déménagement
 * casse tous les consommateurs d'un coup, à l'exécution, par un REFUS qui
 * nomme le lieu à corriger — jamais par une valeur (« ? », NaN, null) qui
 * continue son chemin.
 */
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const RACINE = join(dirname(fileURLToPath(import.meta.url)), "..");

/** Où vit chaque constante de format — l'UNIQUE endroit qui le sait. */
export const ADRESSES = {
  VERSION_SCHEMA: "src/domaine/modele.ts",
  VERSION_MOVPACK: "src/echange/movpack-contrat.ts",
};

/** Extrait `nom = <entier>` d'un texte. Refuse bruyamment — jamais NaN. */
export function extraire(texte, nom, origine) {
  const m = texte.match(new RegExp(`${nom}\\s*=\\s*(\\d+)`));
  if (!m) {
    throw new Error(
      `constante ${nom} introuvable dans ${origine} — si elle a déménagé, corriger ADRESSES (outils/lire-constantes.mjs)`,
    );
  }
  return Number(m[1]);
}

/** Lit une constante de format depuis sa source canonique. */
export function constante(nom) {
  const fichier = ADRESSES[nom];
  if (!fichier) throw new Error(`constante ${nom} inconnue — la déclarer dans ADRESSES (outils/lire-constantes.mjs)`);
  return extraire(readFileSync(join(RACINE, fichier), "utf8"), nom, fichier);
}
