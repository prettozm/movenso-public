/**
 * PRÉSENT À JOUR (D-014/D-128) — le produit ne change pas sans STATE.md.
 *
 * La règle vivait UNIQUEMENT dans `ci.yml` : elle a besoin d'un intervalle de
 * commits, et le vérificateur local n'en jouait aucune version — deux poussées
 * rouges le 2026-08-11 avant que la CI ne le dise (D-300). Elle vit désormais
 * ICI, seule (D-253) : la CI l'appelle avec l'intervalle de la poussée, et
 * `verifier:rapide` avec ce qui S'APPRÊTE à partir (`@{upstream}..HEAD`).
 *
 *   node outils/verifier-present.mjs [base] [head]
 *
 * Sans arguments : l'intervalle sortant ; s'il n'y a ni amont ni commit
 * d'avance, le contrôle est SAUTÉ et le dit — jamais en silence.
 */
import { execFileSync } from "node:child_process";
import { pathToFileURL } from "node:url";

/** La règle, pure : le message d'écart, ou null si rien à redire. */
export function controlerPresent(fichiers) {
  const produit = fichiers.some((f) => /^(src\/|donnees\/|tools\/|tests)/.test(f));
  const present = fichiers.includes("docs/execution/STATE.md");
  return produit && !present
    ? "Le produit a changé sans mise à jour du présent (docs/execution/STATE.md — D-014/D-128)."
    : null;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const git = (...args) => execFileSync("git", args, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
  let [base, head] = process.argv.slice(2).filter((a) => !a.startsWith("--")); // verifier-rapide ajoute --silent
  if (!base) {
    try {
      base = git("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{upstream}");
      head = "HEAD";
    } catch {
      console.log("  ⤬ présent à jour : sauté — aucune branche amont pour calculer l'intervalle sortant");
      process.exit(0);
    }
  }
  const fichiers = git("diff", "--name-only", base, head ?? "HEAD").split("\n").filter(Boolean);
  if (fichiers.length === 0) {
    console.log("  présent à jour : rien à pousser, rien à contrôler");
    process.exit(0);
  }
  const ecart = controlerPresent(fichiers);
  if (ecart) {
    console.error(`  ✕ ${ecart}`);
    process.exit(1);
  }
  console.log("  présent à jour : le changement de produit embarque STATE.md (ou n'en exige pas)");
}
