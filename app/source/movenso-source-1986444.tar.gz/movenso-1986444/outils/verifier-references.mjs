/**
 * Garde « une information, un lieu » (D-253).
 *
 * Le piège récurrent de ce projet n'est pas d'écrire un mauvais numéro, c'est
 * d'en écrire un BON à un second endroit : la copie survit à l'original et
 * personne ne le voit. D-250 en est l'exemple complet — cinq packs publiés,
 * un catalogue web resté en arrière, un registre encore à `0.1.0`, trois
 * états contradictoires et aucun signal.
 *
 * Cette garde refuse la recopie là où elle s'est déjà produite :
 *
 *  1. `docs/versions.md` est une CARTE des références, pas un registre de
 *     valeurs : aucun numéro de version ne doit y figurer.
 *  2. La version de l'app n'est écrite que dans `package.json` — aucun autre
 *     fichier suivi ne doit la porter en dur.
 *  3. L'adresse du dépôt est la BONNE : `movenso-v3` n'existe plus (D-254).
 *  4. Les versions de FORMAT ne sont écrites que dans leur constante de code.
 *
 * Ajouter un cas ici quand une information se met à vivre à deux endroits :
 * c'est le seul endroit où l'on peut le dire une fois pour toutes.
 */
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { execFileSync } from "node:child_process";
import { ADRESSES } from "./lire-constantes.mjs";
import { RAISON_MINIMALE } from "./raison-minimale.mjs";

const RACINE = join(dirname(fileURLToPath(import.meta.url)), "..");
const problemes = [];
const lire = (p) => readFile(join(RACINE, p), "utf8");
/** Un fichier SUIVI par git peut avoir été supprimé du disque sans que la
 *  suppression soit encore indexée — c'est un état normal en cours de travail,
 *  pas un défaut. La garde l'ignore au lieu de s'interrompre : une garde qui
 *  plante ne garde rien. */
const lireSiPresent = async (p) => { try { return await lire(p); } catch { return null; } };

/* ---------- 1. versions.md ne porte aucune valeur ---------- */

const versionsMd = await lire("docs/versions.md");
// On ignore le bloc de citation d'en-tête, qui EXPLIQUE la règle en citant
// l'incident (« encore à 0.1.0 ») — l'exemple n'est pas une déclaration.
const corps = versionsMd
  .split("\n")
  .filter((l) => !l.startsWith(">"))
  .join("\n");
const litteraux = [...corps.matchAll(/(?<![\w.-])\d+\.\d+\.\d+(?:-[\w.]+)?(?![\w.-])/g)].map((m) => m[0]);
// `0.1.0` est cité comme CONVENTION de démarrage, pas comme état d'un pack.
const interdits = litteraux.filter((v) => v !== "0.1.0");
if (interdits.length)
  problemes.push(
    `docs/versions.md porte ${interdits.length} numéro(s) de version : ${[...new Set(interdits)].join(", ")}.\n`
    + `    Ce fichier dit OÙ vivent les versions, il ne les recopie pas (D-253).\n`
    + `    La valeur courante se lit avec « npm run versions ».`,
  );

/* ---------- 2. la version de l'app n'est écrite qu'une fois ---------- */

const versionApp = JSON.parse(await lire("package.json")).version;
// Fichiers suivis par git, hors verrou npm (généré) et hors cet outil.
const suivis = execFileSync("git", ["ls-files"], { cwd: RACINE, encoding: "utf8" })
  .split("\n")
  .filter(Boolean)
  .filter((f) => !["package.json", "package-lock.json", "outils/verifier-references.mjs"].includes(f))
  .filter((f) => /\.(ts|mjs|js|json|md|html|ya?ml)$/.test(f))
  // Le journal des décisions et le présent RACONTENT l'histoire : « app 0.9.0-rc.1 »
  // y est un fait daté, pas une référence que l'on met à jour.
  .filter((f) => !["docs/execution/DECISIONS.md", "docs/execution/STATE.md"].includes(f))
  .filter((f) => !f.startsWith("docs/archives/"));

for (const f of suivis) {
  const contenu = await lireSiPresent(f);
  if (contenu?.includes(versionApp))
    problemes.push(`${f} porte la version de l'app en dur (« ${versionApp} ») — elle ne s'écrit que dans package.json.`);
}

/* ---------- 3. l'adresse du dépôt : une seule, la bonne (D-254) ---------- */

// Le dépôt de l'app a été renommé `movenso-v3` → `movenso` le 2026-08-09, et
// le prototype V2 `movenso` → `old.movenso`. GitHub redirige l'ancienne
// adresse, donc un lien périmé « marche » — c'est précisément ce qui le rend
// durable et faux. Pire : `prettozm/movenso` DÉSIGNAIT la V2 en lecture seule
// et désigne maintenant le dépôt de travail ; un document resté à l'ancienne
// lecture dit l'exact inverse de la règle qu'il énonce.
for (const f of suivis) {
  const contenu = await lireSiPresent(f);
  if (contenu?.includes("github.com/prettozm/movenso-v3"))
    problemes.push(`${f} pointe encore sur github.com/prettozm/movenso-v3 — le dépôt s'appelle « movenso » depuis le 2026-08-09 (D-254).`);
}

/* ---------- 4. les Actions sont épinglées par SHA (S4.13/D-265) ---------- */

// Un tag comme `@v4` est MUTABLE : qui contrôle le dépôt de l'action — ou qui
// en compromet le compte — peut le faire pointer vers du code différent, qui
// s'exécutera ensuite dans notre CI avec le jeton du dépôt. Un SHA complet est
// immuable. Le coût assumé : les mises à jour deviennent manuelles, et c'est
// justement ce qu'on veut d'une dépendance qui s'exécute chez nous.
for (const f of suivis.filter((f) => f.startsWith(".github/workflows/"))) {
  const contenu = (await lireSiPresent(f)) ?? "";
  for (const [i, ligne] of contenu.split("\n").entries()) {
    const m = ligne.match(/uses:\s*([^\s#]+)/);
    if (!m) continue;
    const ref = m[1];
    if (ref.startsWith("./")) continue; // action locale : pas de tiers, rien à épingler
    if (!/@[0-9a-f]{40}$/.test(ref))
      problemes.push(`${f}:${i + 1} : action « ${ref} » non épinglée — un tag est mutable, exiger un SHA complet (S4.13)`);
  }
}

/* ---------- 5. les versions de format ne vivent qu'en constante ---------- */

// Les adresses viennent de `lire-constantes.mjs` — l'outillage entier lit la
// même carte, un déménagement ne peut plus laisser un lecteur derrière (D-285).
const formats = Object.entries(ADRESSES).map(([nom, fichier]) => ({ nom, fichier }));
for (const { nom, fichier } of formats) {
  const src = await lire(fichier);
  const m = src.match(new RegExp(`${nom}\\s*=\\s*(\\d+)`));
  if (!m) problemes.push(`${fichier} : constante ${nom} introuvable — la garde ne peut plus vérifier son unicité.`);
}

// Les documents vivants, hors journaux et figés — la même liste sert aux
// trois contrôles qui suivent (citations de constantes, adresses de la carte,
// dossiers de sortie).
const journaux = ["docs/decisions.md", "docs/execution/DECISIONS.md", "docs/etat.md"];
const docsVivants = suivis.filter((f) =>
  f.startsWith("docs/") && f.endsWith(".md")
  && !f.startsWith("docs/archives/") && !f.startsWith("docs/v2/") && !journaux.includes(f));

/* ---------- 5bis-a. la CARTE des versions cite les adresses réelles ---------- */

// C'est la dérive exacte de D-286 : VERSION_MOVPACK déménagée en D-274, la
// carte (`docs/versions.md`) pointait toujours `movpack.ts`. Un lien
// sémantique périmé qu'aucun chiffre recopié ne trahit — la carte doit citer
// l'adresse qu'ADRESSES connaît, mot pour mot.
{
  const carte = await lire("docs/versions.md");
  for (const { nom, fichier } of formats) {
    if (!carte.includes(`\`${fichier}\` (\`${nom}\`)`))
      problemes.push(`docs/versions.md : ne cite pas \`${fichier}\` (\`${nom}\`) — la carte pointe une adresse périmée ou muette, corriger sa table des formats (D-286).`);
  }
}

/* ---------- 5bis-b. un dossier de sortie cité existe vraiment ---------- */

// README a annoncé `dist-packs/` longtemps après sa disparition (D-264) : un
// document vivant qui cite un dossier `dist-*` doit citer CELUI que
// `tools/publier.ts` écrit (SORTIE) — même source que le fait « Publication »
// du tableau de bord.
{
  const sortie = (await lire("tools/publier.ts")).match(/const SORTIE = "([^"]+)"/)?.[1];
  if (!sortie) {
    problemes.push("tools/publier.ts : constante SORTIE introuvable — impossible de vérifier les dossiers de sortie cités par les documents.");
  } else {
    for (const f of ["README.md", ...docsVivants]) {
      const contenu = (await lireSiPresent(f)) ?? "";
      if (/^>.*Type\s*:\s*\*{0,2}figé/m.test(contenu)) continue;
      for (const [i, ligne] of contenu.split("\n").entries())
        for (const m of ligne.matchAll(/\bdist-[a-z][a-z-]*/g))
          if (m[0] !== sortie)
            problemes.push(`${f}:${i + 1} : cite « ${m[0]} » — la chaîne de publication écrit dans ${sortie}/ (tools/publier.ts, SORTIE).`);
    }
  }
}

/* ---------- 5bis. une doc VIVANTE ne contredit pas les constantes ---------- */

// Les documents sont la mémoire opérationnelle : une session neuve les lit
// AVANT le code. `systeme.md` a annoncé « `VERSION_MOVPACK = 4` » et
// « `VERSION_SCHEMA = 4` » alors que le code était en 5 et en 6 (D-273) — une
// session repartant de là aurait travaillé sur un format qui n'existe plus.
//
// Ce qui est contrôlé : la CITATION d'une constante, `VERSION_X = n`. C'est
// le seul signal non ambigu — le document prétend alors répéter le code, donc
// il doit dire vrai. En prose, « schéma v3 » veut presque toujours dire « le
// champ est apparu au schéma 3 » : une phrase permanente, qu'il serait faux
// de refuser. LIMITE DITE : une prose qui affirme la version courante sans
// citer la constante (« conteneur .movpack v4 ») n'est PAS attrapée. C'est
// pourquoi `systeme.md`, qui fait autorité sur l'architecture, doit en plus
// ÉNONCER les deux constantes — il ne peut pas se taire pour passer.
//
// Exclus : les journaux et les archives (leurs entrées datent, et disent
// légitimement l'état d'alors) et tout document se déclarant « Type : figé ».
{
  const courantes = {};
  for (const { nom, fichier } of formats) {
    const src = await lire(fichier);
    courantes[nom] = Number(src.match(new RegExp(`${nom}\\s*=\\s*(\\d+)`))?.[1]);
  }

  const candidats = docsVivants;

  for (const f of candidats) {
    const contenu = (await lireSiPresent(f)) ?? "";
    if (/^>.*Type\s*:\s*\*{0,2}figé/m.test(contenu)) continue; // le document le dit lui-même
    for (const [i, ligne] of contenu.split("\n").entries()) {
      for (const [nom, valeur] of Object.entries(courantes))
        for (const m of ligne.matchAll(new RegExp(`${nom}\\s*=\\s*(\\d+)`, "g")))
          if (Number(m[1]) !== valeur)
            problemes.push(`${f}:${i + 1} : le document annonce ${nom} = ${m[1]}, le code dit ${valeur}.`);
    }
  }

  // `systeme.md` fait autorité sur l'architecture : il ÉNONCE les versions
  // courantes, sans quoi la garde ci-dessus se contenterait d'un silence.
  const architecture = (await lireSiPresent("docs/systeme.md")) ?? "";
  for (const [nom, valeur] of Object.entries(courantes))
    if (!new RegExp(`${nom}\\s*=\\s*${valeur}\\b`).test(architecture))
      problemes.push(`docs/systeme.md : n'énonce pas ${nom} = ${valeur} — la doc d'architecture doit DIRE la version courante du format.`);
}

/* ---------- 5ter. toute décision citée existe ---------- */

// Depuis D-276, une session ne lit plus le journal en entier : elle lit les
// décisions que `STATE.md` et le lot courant DÉSIGNENT. Cette liste devient
// donc un chemin d'accès — et un chemin qui mène dans le vide est pire qu'une
// absence de chemin : il envoie chercher un raisonnement qui n'existe pas.
{
  const journaux = ["docs/execution/DECISIONS.md", "docs/decisions.md"];
  const connues = new Set();
  // UN NUMÉRO DÉSIGNE UNE SEULE DÉCISION (D-357). La garde ci-dessous vérifiait
  // qu'une décision citée EXISTE ; elle ne disait rien de son UNICITÉ. Or deux
  // sessions qui numérotent depuis la queue du fichier choisissent le même
  // numéro sans jamais se croiser : c'est arrivé une première fois avec deux
  // entrées `327` (D-330), qui avait chiffré ce correctif à « ~5 lignes » et ne
  // l'avait pas construit. Deuxième morsure le 2026-08-17, en pire : deux
  // branches vivantes portaient chacune D-344 → D-347, quatre numéros pour huit
  // décisions, et rien n'aurait refusé la fusion des deux.
  //
  // Un numéro en double est pire qu'un numéro manquant : la référence AURAIT une
  // cible, et le lecteur tomberait sur la mauvaise moitié du temps, sans que
  // rien ne cloche. C'est le motif D-253 appliqué à l'identité des décisions.
  //
  // Elle se joue par journal — les deux segments se suivent (`docs/decisions.md`
  // porte D-001 → D-027, celui d'exécution la suite), donc un même numéro dans
  // les deux serait aussi une collision, et le décompte global l'attrape.
  const vus = new Map();
  for (const j of journaux)
    for (const m of ((await lireSiPresent(j)) ?? "").matchAll(/^(\d+)\.\s/gm)) {
      const n = Number(m[1]);
      vus.set(n, [...(vus.get(n) ?? []), j]);
    }
  for (const [n, ou] of [...vus].sort((a, b) => a[0] - b[0]))
    if (ou.length > 1)
      problemes.push(
        `D-${String(n).padStart(3, "0")} désigne ${ou.length} décisions à la fois (${[...new Set(ou)].join(", ")})`
        + ` — un numéro a UN titulaire. Renuméroter la plus récente, celle qui n'est pas encore sur main (précédent D-330).`,
      );

  for (const j of journaux)
    for (const m of ((await lireSiPresent(j)) ?? "").matchAll(/^(\d+)\.\s/gm)) connues.add(Number(m[1]));

  // Liste construite à part : `suivis` ÉCARTE STATE et DECISIONS pour la règle
  // des versions (ils racontent des faits datés). Les réutiliser ici aurait
  // donné une garde qui ne regarde rien — et qui passe donc toujours.
  const citants = execFileSync("git", ["ls-files"], { cwd: RACINE, encoding: "utf8" })
    .split("\n").filter(Boolean)
    // Tous les CLAUDE.md, racine comme LOCAUX (D-277) : ce sont eux qu'une
    // session lit au moment d'agir, donc ceux dont une référence morte coûte
    // le plus cher.
    .filter((f) => f === "docs/execution/STATE.md" || f === "CLAUDE.md" || f.endsWith("/CLAUDE.md")
      || f.startsWith("docs/execution/lots/"));
  for (const f of citants) {
    const contenu = (await lireSiPresent(f)) ?? "";
    for (const [i, ligne] of contenu.split("\n").entries())
      for (const m of ligne.matchAll(/\bD-(\d{3})\b/g))
        if (!connues.has(Number(m[1])))
          problemes.push(`${f}:${i + 1} : cite D-${m[1]}, qui n'existe dans aucun journal — une référence qui mène dans le vide.`);
  }
}

/* ---------- 5quater. toute dépendance est DÉCLARÉE avec sa raison ---------- */

// Un agent résout volontiers un problème en ajoutant un paquet. Une base
// durable doit parfois répondre « non, vingt-cinq lignes suffisent » (D-282).
// La garde n'interdit rien : elle rend la décision VISIBLE dans le diff, en
// exigeant qu'on écrive POURQUOI le paquet existe. On ne peut pas justifier
// distraitement.
{
  const pkg = JSON.parse(await lire("package.json"));
  const { paquets } = JSON.parse(await lire("outils/dependances.json"));
  const utilises = [...Object.keys(pkg.dependencies ?? {}), ...Object.keys(pkg.devDependencies ?? {})];

  for (const nom of utilises)
    if (!(nom in paquets))
      problemes.push(`package.json : « ${nom} » n'est pas déclaré dans outils/dependances.json — une dépendance est une DÉCISION : écrire pourquoi elle existe (D-282).`);
  for (const [nom, d] of Object.entries(paquets)) {
    if (!utilises.includes(nom))
      problemes.push(`outils/dependances.json : « ${nom} » est déclaré mais n'est plus dans package.json — retirer l'entrée.`);
    else if (typeof d?.raison !== "string" || d.raison.trim().length < RAISON_MINIMALE)
      problemes.push(`outils/dependances.json : « ${nom} » sans raison exploitable — une justification d'un mot n'en est pas une.`);
  }
}

/* ---------- 5quinquies. le nom d'un pack ne vit qu'à un endroit ---------- */

// `publication/packs.json` porte DEUX noms par pack, et ils partent à des
// endroits différents : `nomEditorial` entre dans le manifeste du conteneur
// (`tools/publier.ts`, c'est ce que lit la feuille d'IMPORT) et `title` entre
// au catalogue du site (c'est ce que lit l'écran « Starter packs »). Les deux
// SONT le nom du pack. D-302 a dû les réaligner à la main après que le yoga
// eut divergé — « Yoga Hatha » d'un côté, un titre éditorial de l'autre — et
// rien n'empêchait cet alignement de se défaire une seconde fois. Sans cette
// garde, l'utilisateur peut lire deux noms pour un seul pack selon qu'il
// regarde le site ou sa feuille d'import (D-253, verdict checker D-339).
{
  const packs = JSON.parse(await lire("publication/packs.json"));
  for (const p of packs) {
    // La PRÉSENCE d'abord : `undefined === undefined` passait en silence, donc
    // une entrée sans nom du tout satisfaisait une garde écrite pour les noms
    // (verdict checker, D-351). Non atteignable aujourd'hui — mais une garde
    // qui ne peut pas dire « il manque » n'est pas une garde.
    for (const champ of ["nomEditorial", "title"])
      if (typeof p[champ] !== "string" || !p[champ].trim())
        problemes.push(`publication/packs.json : « ${p.id} » n'a pas de ${champ} — c'est le nom du pack, il ne peut pas manquer.`);
    if (p.nomEditorial !== p.title)
      problemes.push(
        `publication/packs.json : « ${p.id} » porte nomEditorial « ${p.nomEditorial} » et title « ${p.title} ».\n`
        + `    Les deux SONT le nom du pack — l'un part dans le manifeste (import),\n`
        + `    l'autre au catalogue du site. Les aligner, ou décider qu'ils diffèrent (D-253).`,
      );
  }
}

/* ---------- 6. la CI joue TOUTE la chaîne de vérification ---------- */

// `npm run verifier` et le workflow `ci.yml` décrivent la même chose à deux
// endroits : ce que le projet considère comme vérifié. Ils ont divergé en
// silence — `verifier:references` n'a jamais tourné en CI (D-270). Une
// duplication qu'on ne peut pas supprimer (le workflow intercale des étapes
// d'artefact entre les vérifications) se rattache par une garde, jamais par
// une consigne.
{
  const pkg = JSON.parse(await lire("package.json"));
  const ci = (await lireSiPresent(".github/workflows/ci.yml")) ?? "";
  // Les commandes sont comparées TELLES QU'ÉCRITES (`npm test` et
  // `npm run build` cohabitent dans la chaîne) : normaliser inventerait une
  // forme que ni l'un ni l'autre n'emploie.
  const etapes = (pkg.scripts?.verifier ?? "").split("&&").map((c) => c.trim()).filter(Boolean);
  for (const etape of etapes) {
    if (!new RegExp(`${etape.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(\\s|$)`, "m").test(ci))
      problemes.push(`.github/workflows/ci.yml : « ${etape} » fait partie de \`npm run verifier\` mais la CI ne le joue pas — vérifié en local, pas à la poussée.`);
  }
}

/* ---------- 7. un workflow n'appelle que ce qui existe ---------- */

// `apk.yml` a appelé `tools/emballer-packs.ts` pendant des semaines après sa
// suppression (D-264 → D-272) : l'APK se construisait, s'uploadait, puis le
// workflow finissait rouge sur une étape sans rapport. Rien ne pouvait le
// dire — un workflow n'est joué qu'à la demande, et le vérificateur ne
// regardait pas dedans. Ce que le nom d'un script promet doit exister.
{
  const pkg = JSON.parse(await lire("package.json"));
  for (const f of suivis.filter((f) => f.startsWith(".github/workflows/"))) {
    const contenu = (await lireSiPresent(f)) ?? "";
    for (const [i, ligne] of contenu.split("\n").entries()) {
      const ou = `${f}:${i + 1}`;
      // `node [options] <chemin>` — un script du dépôt.
      const script = ligne.match(/\bnode\s+(?:--[\w-]+(?:=\S+)?\s+)*([\w./-]+\.(?:mjs|js|ts))/);
      if (script && !suivis.includes(script[1]))
        problemes.push(`${ou} : le workflow appelle « ${script[1]} », qui n'existe pas — l'étape échouera à chaque exécution.`);
      // `npm run <script>` — déclaré dans package.json.
      const npm = ligne.match(/\bnpm run ([\w:-]+)/);
      if (npm && !(npm[1] in (pkg.scripts ?? {})))
        problemes.push(`${ou} : le workflow appelle « npm run ${npm[1]} », absent de package.json.`);
    }
  }
}

/* ---------- 8. une PORTÉE DE RELECTURE se déclare en SHA ---------- */

// D-339, angle mort relevé par le checker : le constat « la portée était
// bornée par HEAD » avait été corrigé par une CONSIGNE. Or D-253 dit qu'une
// consigne que rien n'exécute est une consigne de plus, et `outils/checker.mjs`
// imprimait déjà les deux SHA correctement — le `HEAD` est apparu à la
// TRANSCRIPTION dans STATE.md, là où aucune machine ne regardait.
//
// `HEAD` n'est pas une valeur, c'est un pointeur : écrite le 14, la portée
// `dd98ef7..HEAD` désignait 2 commits ; lue le 16, elle en désignait 30, et le
// checker a dû reconstruire sa base depuis le graphe Git au lieu de la lire.
//
// Même refus pour un nom de branche : il bouge aussi. Seul un SHA (ou un tag,
// qui ne bouge qu'exprès) fige ce qui a été relu.
//
// Portée VOLONTAIREMENT limitée aux deux tableaux vivants : `DECISIONS.md`
// est un journal d'audit qui CITE le défaut (« la portée était bornée par
// HEAD ») — le scanner ferait refuser au dépôt le récit de sa propre
// correction.
{
  // LISTE BLANCHE, jamais liste noire — quatrième tour de relecture (D-341).
  // Ma première version énumérait ce qui BOUGE (`HEAD|origin/…|main|master`).
  // Or toutes les branches de ce dépôt s'appellent `claude/…` : la borne
  // mobile qu'on a le plus de chances de transcrire un jour était précisément
  // celle qui passait. La garde attrapait le cas qui avait mordu, pas celui
  // qu'elle revendiquait.
  //
  // On ne peut pas énumérer les noms de branche — on peut énumérer ce à quoi
  // ressemble une référence FIGÉE. Est acceptée une empreinte (7 à 40
  // hexadécimaux) ou une étiquette de version (`v1.2.3`), qui ne bouge
  // qu'exprès. Tout le reste est refusé, y compris ce que personne n'a prévu.
  const FIGEE = /^(?:[0-9a-f]{7,40}|v\d+\.\d+\.\d+[\w.-]*)$/;
  // Les portées écrites SANS accents graves comptent aussi : rien ne tenait la
  // convention d'écriture, et une garde qui dépend d'un style de rédaction
  // n'est pas une garde (constat du même tour).
  const PORTEE = /(?:^|[\s`([])([\w./+-]+)\.\.([\w./+-]+)(?=[\s`)\].,;:]|$)/g;
  for (const f of ["docs/execution/STATE.md", "docs/execution/RESTE.md"]) {
    const contenu = (await lireSiPresent(f)) ?? "";
    for (const [i, ligne] of contenu.split("\n").entries()) {
      for (const m of ligne.matchAll(PORTEE)) {
        const mobiles = [m[1], m[2]].filter((b) => !FIGEE.test(b));
        if (mobiles.length)
          problemes.push(
            `${f}:${i + 1} : la portée « ${m[1]}..${m[2]} » est bornée par « ${mobiles.join(" » et « ")} », `
            + "qui n'est pas une référence FIGÉE — une portée de relecture se déclare en empreinte (D-339/D-341).",
          );
      }
    }
  }
}

/* ---------- verdict ---------- */

if (problemes.length) {
  console.error(`verifier-references : ${problemes.length} information(s) recopiée(s)\n`);
  for (const p of problemes) console.error(`  ✕ ${p}`);
  console.error("\nUne information a UN lieu. Supprimer la copie, ou la dériver de sa source.");
  process.exit(1);
}

console.log("verifier-references : aucune information recopiée (versions.md est une carte, version d'app en un lieu, adresse de dépôt à jour, formats en constantes, nom de pack identique au manifeste et au catalogue, CI = chaîne complète, workflows sans appel mort, décisions citées existantes, un numéro par décision, dépendances déclarées, portées de relecture figées en empreinte).");
