/**
 * GARDE DE BRANCHE DU SITE (D-284) — un dépôt public ne reçoit que sur `main`.
 *
 * L'incident : à la reprise du 2026-08-10, le clone de `movenso-public` était
 * positionné sur une branche de travail, héritée d'une consigne de session
 * écrite pour le dépôt de TRAVAIL. `deposer` aurait écrit dessus sans un mot,
 * et le commit serait parti sur cette branche — une publication invisible
 * depuis `main`. « On ne dépose que sur main » (D-267) ne tenait que par
 * discipline, et une règle qu'aucune garde ne tient est une consigne de plus
 * (D-253).
 *
 * Ce module CONTRÔLE, il n'écrit rien dans le site. Il est rejoué par
 * `verifier:release` (§4), donc par `deposer` — et s'exécute seul :
 *
 *   node outils/garde-branche-site.mjs <dossier-site>
 *
 * Ce qu'il ne peut pas atteindre, il le DIT : sans réseau, l'alignement est
 * contrôlé contre la dernière réf locale de `origin/main`, et c'est annoncé
 * comme un contrôle dégradé, pas passé sous silence.
 */
import { execFileSync } from "node:child_process";
import { pathToFileURL } from "node:url";

const git = (site, ...args) =>
  execFileSync("git", ["-C", site, ...args], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();

/** @returns {{ ecarts: string[], sautes: string[], infos: string[] }} */
export function controlerBrancheSite(site) {
  const ecarts = [];
  const sautes = [];
  const infos = [];

  let branche;
  try {
    branche = git(site, "rev-parse", "--abbrev-ref", "HEAD");
  } catch {
    ecarts.push(`${site} n'est pas un clone git — impossible de garantir sur quelle branche un dépôt partirait`);
    return { ecarts, sautes, infos };
  }

  if (branche !== "main") {
    ecarts.push(
      `le clone public est sur « ${branche} » — un dépôt ne se fait que sur main (D-267) : git -C ${site} checkout main`,
    );
    return { ecarts, sautes, infos };
  }

  try {
    git(site, "fetch", "--quiet", "origin", "main");
  } catch {
    sautes.push("fetch de origin/main impossible — alignement contrôlé contre la dernière réf locale connue");
  }

  let retard, avance;
  try {
    retard = Number(git(site, "rev-list", "--count", "main..origin/main"));
    avance = Number(git(site, "rev-list", "--count", "origin/main..main"));
  } catch {
    ecarts.push("origin/main introuvable dans le clone public — ce clone ne suit pas le dépôt publié");
    return { ecarts, sautes, infos };
  }

  if (retard > 0) {
    ecarts.push(
      `main du clone public est en retard de ${retard} commit(s) sur origin/main — mettre le clone à jour avant de déposer`,
    );
  } else if (avance > 0) {
    // Un dépôt précédent commité, poussée humaine à venir : pas un motif de
    // refus, mais ça se dit — deux dépôts partiront dans la même poussée.
    infos.push(`clone public : sur main, ${avance} commit(s) non poussé(s) — un dépôt précédent attend sa poussée`);
  } else {
    infos.push("clone public : sur main, aligné sur origin/main");
  }
  return { ecarts, sautes, infos };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const site = process.argv[2] ?? "../movenso-public";
  const { ecarts, sautes, infos } = controlerBrancheSite(site);
  for (const m of infos) console.log(`  ${m}`);
  for (const m of sautes) console.log(`  ⤬ ${m}`);
  for (const m of ecarts) console.error(`  ✕ ${m}`);
  process.exit(ecarts.length ? 1 : 0);
}
