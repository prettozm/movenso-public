/** Types de `raison-minimale.mjs` — pour les tests TypeScript uniquement. */
export declare const RAISON_MINIMALE: number;
