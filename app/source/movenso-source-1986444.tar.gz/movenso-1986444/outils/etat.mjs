/**
 * FAITS de `STATE.md` — calculés, jamais écrits à la main (D-275).
 *
 *   node outils/etat.mjs              met le bloc à jour
 *   node outils/etat.mjs --verifier   échoue si le bloc ment
 *
 * Pourquoi une machine plutôt qu'une consigne : `STATE.md` a annoncé 224 tests
 * quand il y en avait 251, 21 chapitres e2e quand il y en avait 24, et cinq
 * packs reproductibles alors que les six l'étaient — la dette avait été levée
 * sans que personne le note (D-273). Chacun de ces nombres est une COPIE d'une
 * valeur qui vit dans le dépôt. On ne demande donc plus à personne de s'en
 * souvenir : on les dérive, et une garde refuse l'écart.
 *
 * Le compte des tests est obtenu en LES EXÉCUTANT. Le comptage statique était
 * tentant — il donne 244 au lieu de 251, parce que certains cas naissent d'une
 * boucle. Un chiffre approché dans un tableau de bord vaut moins que pas de
 * chiffre du tout.
 */
import { execFileSync } from "node:child_process";
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { constante } from "./lire-constantes.mjs";

const DEBUT = "<!-- FAITS:DÉBUT -->";
const FIN = "<!-- FAITS:FIN -->";
const STATE = "docs/execution/STATE.md";

const lire = (f) => readFileSync(f, "utf8");

function faits() {
  const pkg = JSON.parse(lire("package.json"));

  // Tests unitaires : exécutés. `node --test` sort en TAP, « # pass N » fait foi.
  const tap = execFileSync("npm", ["test"], { encoding: "utf8", maxBuffer: 1 << 26, stdio: ["ignore", "pipe", "ignore"] });
  const tests = Number(tap.match(/^# pass (\d+)$/m)?.[1]);
  const echecs = Number(tap.match(/^# fail (\d+)$/m)?.[1]);

  // Chapitres e2e : ceux que le parcours JOUE réellement. Un fichier présent
  // dans `parcours/` mais jamais appelé n'est pas un chapitre, c'est un fichier.
  const parcours = lire("tests-navigateur/parcours.mjs");
  const chapitres = (parcours.match(/^await chapitre\w+\(/gm) ?? []).length;
  const fichiersChapitres = readdirSync("tests-navigateur/parcours").filter((f) => f.endsWith(".mjs")).length;

  // Packs reproductibles : ceux dont la source vit dans le dépôt.
  const publies = JSON.parse(lire("publication/packs.json"));
  const reproductibles = publies.filter((p) => existsSync(`donnees/${p.source}.json`)).length;

  const compterTs = (dossier) =>
    readdirSync(dossier, { withFileTypes: true }).reduce(
      (n, e) => n + (e.isDirectory() ? compterTs(`${dossier}/${e.name}`) : e.name.endsWith(".ts") ? 1 : 0), 0);

  return {
    Application: pkg.version,
    "Schéma": String(constante("VERSION_SCHEMA")),
    Movpack: String(constante("VERSION_MOVPACK")),
    Tests: `${tests}${echecs ? ` (${echecs} EN ÉCHEC)` : ""}`,
    "Chapitres e2e": String(chapitres),
    "Sources de packs": `${reproductibles}/${publies.length}`,
    Publication: `${lire("tools/publier.ts").match(/const SORTIE = "([^"]+)"/)?.[1]}/`,
    "Fichiers TS (src/)": String(compterTs("src")),
    "racine.ts": `${lire("src/app/racine.ts").split("\n").length} lignes`,
    "movpack.ts": `${lire("src/echange/movpack.ts").split("\n").length} lignes`,
    ...(chapitres !== fichiersChapitres
      ? { "⚠ chapitres non joués": `${fichiersChapitres - chapitres} fichier(s) de parcours/ ne sont pas appelés` }
      : {}),
  };
}

const bloc = (f) => [DEBUT, ...Object.entries(f).map(([k, v]) => `${k} : ${v}`), FIN].join("\n");

const source = lire(STATE);
const i = source.indexOf(DEBUT);
const j = source.indexOf(FIN);
if (i < 0 || j < 0) {
  console.error(`etat : ${STATE} ne contient pas le bloc ${DEBUT} … ${FIN}.`);
  process.exit(2);
}
const actuel = source.slice(i, j + FIN.length);
const attendu = bloc(faits());

if (process.argv.includes("--verifier")) {
  if (actuel === attendu) {
    console.log("verifier:etat : le tableau de bord dit le réel.");
    process.exit(0);
  }
  console.error("verifier:etat : les FAITS de STATE.md ne correspondent plus au dépôt.\n");
  const a = actuel.split("\n"), b = attendu.split("\n");
  for (const ligne of new Set([...a, ...b])) {
    if (a.includes(ligne) && !b.includes(ligne)) console.error(`  ✕ écrit : ${ligne}`);
    if (!a.includes(ligne) && b.includes(ligne)) console.error(`  → réel  : ${ligne}`);
  }
  console.error("\nCes nombres ne s'écrivent pas à la main : `npm run etat`.");
  process.exit(1);
}

const { writeFileSync } = await import("node:fs");
writeFileSync(STATE, source.slice(0, i) + attendu + source.slice(j + FIN.length));
console.log(`etat : ${STATE} mis à jour.\n\n${attendu}`);
