/** Types de `lire-constantes.mjs` — pour les tests TypeScript uniquement. */
export declare const ADRESSES: {
  VERSION_SCHEMA: string;
  VERSION_MOVPACK: string;
};
export declare function extraire(texte: string, nom: string, origine: string): number;
export declare function constante(nom: keyof typeof ADRESSES): number;
