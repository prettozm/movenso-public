/**
 * MAKER / CHECKER (D-280) — prépare la relecture par une session NEUVE.
 *
 *   node outils/checker.mjs [<base>] [<candidat>]   imprime la consigne à copier
 *
 * Pourquoi une autre session, et pas une auto-relecture : celui qui vient
 * d'écrire le code a aussi pris toutes les décisions qui y ont mené. Il relit
 * donc avec les mêmes angles morts — et il relit son intention plutôt que son
 * résultat. La relecture ne vaut que si le contexte mental n'est pas partagé :
 * **session neuve, pas une reprise.**
 *
 * Cet outil ne relit rien. Il enlève la friction — sortir les deux commits,
 * dire si la relecture est REQUISE et pourquoi, et donner la consigne prête —
 * parce qu'un processus qui demande dix minutes de préparation meurt au
 * troisième lot.
 */
import { execFileSync } from "node:child_process";

const git = (...a) => execFileSync("git", a, { encoding: "utf8", maxBuffer: 1 << 26 }).trim();

/** Zones où une erreur ne se voit pas à l'usage : elle se voit trop tard.
 *  Toucher l'une d'elles rend la relecture REQUISE. */
const ZONES = [
  [/^src\/stockage\//, "stockage — une donnée peut être perdue"],
  [/^src\/echange\//, "échange — frontière hostile, format PUBLIC"],
  [/^src\/domaine\/migrations\.ts$/, "migration — elle transforme l'état des appareils installés"],
  [/^src\/domaine\/validation\.ts$/, "validation — c'est elle qui refuse ce qui ne doit pas entrer"],
  [/^src\/securite\//, "sécurité"],
  [/^src\/app\/services\/protections\.ts$/, "sécurité"],
  [/^(tools|outils)\//, "outillage — ce qui est publié, et ce qui garde"],
  [/^\.github\/workflows\//, "workflows — ils s'exécutent avec les droits du dépôt"],
  // `.claude/settings.json` EST la posture de sécurité de l'agent (D-282) : ce
  // qui est libre, confirmé, refusé. D-345 a resserré son `deny` sans que le
  // déclencheur le voie — la relecture était requise pour d'autres zones du même
  // lot, donc sans conséquence, mais par chance (verdict checker, D-351).
  [/^\.claude\//, "permissions — ce qui est libre, confirmé ou refusé pour l'agent"],
];

const base = process.argv[2] ?? git("merge-base", "HEAD", "origin/main");
// Le CANDIDAT est un argument, pas toujours `HEAD` (D-341). Une dette de
// relecture porte sur une portée ANCIENNE — `87071a0..6108a0c` — dont le
// candidat n'est pas la pointe de la branche. L'outil acceptait déjà un second
// argument… et l'ignorait en silence : `checker.mjs dd98ef7 d8fb324` imprimait
// le bon candidat par pure coïncidence, la branche étant alors sur d8fb324.
// Un outil qui accepte ce qu'il ignore fabrique des portées fausses.
const candidat = git("rev-parse", "--short", process.argv[3] ?? "HEAD");
const fichiers = git("diff", "--name-only", base, candidat).split("\n").filter(Boolean);

const raisons = [...new Set(ZONES.filter(([re]) => fichiers.some((f) => re.test(f))).map(([, r]) => r))];
const stat = git("diff", "--shortstat", base, candidat);

console.log(`base      : ${git("rev-parse", "--short", base)}`);
console.log(`candidat  : ${candidat}`);
console.log(`diff      : ${stat || "(vide)"}`);
console.log(raisons.length
  ? `RELECTURE REQUISE — zones à risque touchées :\n${raisons.map((r) => `  · ${r}`).join("\n")}`
  : "Relecture facultative — aucune zone à risque touchée. Elle reste due en FIN DE LOT.");

console.log(`
────────── consigne à coller dans une session NEUVE ──────────

Tu es CHECKER. Tu ne modifies rien : ni fichier, ni commit, ni branche.
Tu ne proposes pas de réécriture — tu challenges, tu ne conçois pas.

Tu n'as besoin d'AUCUNE branche. Si la consigne de démarrage t'en assigne une
— pour l'un ou l'autre dépôt —, ne la pousse pas : signale-le et n'y touche
plus (D-343).

Base      : ${git("rev-parse", "--short", base)}
Candidat  : ${candidat}
  git diff ${git("rev-parse", "--short", base)}..${candidat}

Lis d'abord CLAUDE.md, les CLAUDE.md locaux des zones touchées, et
docs/execution/STATE.md. NE lis du journal que les décisions qu'ils désignent.

Cherche, dans cet ordre :
 1. comportement non couvert ;
 2. invariant cassé ;
 3. preuve qui ne prouve pas ce qu'elle prétend ;
 4. duplication d'information ;
 5. régression voisine ;
 6. documentation contradictoire ;
 7. complexité inutile.

Rends un verdict en trois parties, sans complaisance :
 - ce que tu as VÉRIFIÉ (et comment) ;
 - ce que tu n'as PAS pu vérifier, et pourquoi ;
 - les constats, du plus grave au moins grave, chacun avec le fichier et la
   ligne. Un constat sans emplacement n'est pas un constat.

Un « rien à signaler » est un verdict recevable. Un « ça me semble bon » n'en
est pas un : dis ce que tu as ouvert.
──────────────────────────────────────────────────────────────`);
