/**
 * VÉRIFICATION RAPIDE (D-281) — le premier niveau, pour ITÉRER.
 *
 *   node outils/verifier-rapide.mjs
 *
 * `npm run verifier` prend ~2 min : c'est le bon prix pour clore une boucle,
 * c'est trop cher pour la dixième fois en une heure. Celui-ci tient en
 * quelques secondes : typecheck, gardes d'architecture, cliquet, tests
 * unitaires.
 *
 * Il finit en DISANT ce qu'il n'a pas regardé. C'est la seule chose qui
 * empêche un vert rapide de se faire passer pour un vert complet — et on a vu
 * ce que coûte un contrôle sauté en silence : la CI est restée rouge six
 * commits durant pendant que le vérificateur local était vert (D-270).
 */
import { execSync } from "node:child_process";

const ETAPES = [
  ["typecheck", "npm run typecheck"],
  ["gardes d'architecture", "npm run verifier:sources"],
  ["cliquet", "npm run verifier:cliquet"],
  // D-300 : la règle D-014 (produit → STATE.md) jouée sur l'intervalle
  // SORTANT — elle ne vivait qu'en CI, deux poussées ont rougi avant qu'elle
  // ne parle. Sauté (et dit) quand il n'y a pas d'amont.
  ["présent à jour", "node outils/verifier-present.mjs"],
  ["tests unitaires", "npm test"],
];

const debut = Date.now();
for (const [nom, cmd] of ETAPES) {
  try {
    execSync(`${cmd} --silent`, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], maxBuffer: 1 << 26 });
    console.log(`  ✓ ${nom}`);
  } catch (e) {
    console.error(`  ✕ ${nom}\n`);
    console.error(String(e.stdout ?? "") + String(e.stderr ?? ""));
    process.exit(1);
  }
}

console.log(`\nverifier:rapide : vert en ${((Date.now() - debut) / 1000).toFixed(0)} s.

NON VÉRIFIÉ ici — ne pas confondre avec « npm run verifier » :
  · le BUILD et la propreté de dist/        (verifier:dist)
  · les PARCOURS utilisateur                (e2e, 24 chapitres sur OPFS réel)
  · le code MORT                            (knip)
  · les informations RECOPIÉES              (verifier:references)
  · les FAITS du tableau de bord            (verifier:etat)

Une boucle ne se clôt pas sur ce vert-ci.`);
