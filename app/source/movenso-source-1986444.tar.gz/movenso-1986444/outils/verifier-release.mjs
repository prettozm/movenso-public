/**
 * VÉRIFICATION DE RELEASE (D-281) — le troisième niveau.
 *
 *   node outils/verifier-release.mjs [--site <dossier>]
 *
 * `verifier` répond à « le code est-il sain ? ». Celui-ci répond à une autre
 * question, que rien ne posait : **« ce qu'on s'apprête à distribuer est-il
 * cohérent ? »** — les packs se reconstruisent-ils, se relisent-ils par le
 * lecteur réel, le catalogue dit-il la vérité, les versions concordent-elles,
 * et la source correspondante accompagne-t-elle bien le binaire.
 *
 * Il ORCHESTRE, il ne réimplémente rien : `publier.ts` relit déjà chaque
 * conteneur et dérive les compteurs, `verifier-catalogues.mjs` garde le site.
 * Recoder ces contrôles ici en ferait une seconde vérité (D-253).
 *
 * **Ce qu'il ne peut pas atteindre, il le DIT.** Le dépôt public n'est pas
 * toujours là ; un contrôle sauté en silence se lirait comme un contrôle
 * réussi — c'est exactement le défaut qu'on a corrigé ailleurs.
 */
import { execFileSync, execSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { controlerBrancheSite } from "./garde-branche-site.mjs";
import { constante } from "./lire-constantes.mjs";

const ecarts = [];
const sautes = [];
const dit = (m) => console.log(`  ${m}`);

const iSite = process.argv.indexOf("--site");
const site = iSite >= 0 ? process.argv[iSite + 1] : "../movenso-public";

const versionApp = JSON.parse(readFileSync("package.json", "utf8")).version;
const schema = constante("VERSION_SCHEMA");
const movpack = constante("VERSION_MOVPACK");

console.log(`\n=== RELEASE — app ${versionApp}, schéma ${schema}, movpack v${movpack} ===\n`);

/* ---------- 1. les packs se reconstruisent depuis leurs sources ---------- */
console.log("1. Reconstruction des packs depuis `donnees/`");
try {
  const sortie = execSync("npm run publier --silent", { encoding: "utf8", maxBuffer: 1 << 26 });
  const construits = (sortie.match(/^✓ /gm) ?? []).length;
  const annonces = JSON.parse(readFileSync("publication/packs.json", "utf8")).length;
  dit(`${construits}/${annonces} packs construits, relus par le lecteur réel, compteurs dérivés`);
  if (construits !== annonces) ecarts.push(`${annonces - construits} pack(s) non reconstruit(s) — source absente ou refus de la chaîne`);
} catch (e) {
  ecarts.push(`la chaîne de publication a échoué : ${String(e.stdout ?? e.message).trim().split("\n").pop()}`);
}

/* ---------- 2. le catalogue produit dit le schéma courant ---------- */
console.log("\n2. Cohérence des versions annoncées");
try {
  const catalogue = JSON.parse(readFileSync("dist-publication/index.json", "utf8"));
  const mauvais = catalogue.filter((p) => p.versionSchema !== schema);
  dit(`${catalogue.length} entrées, toutes en schéma ${schema}` + (mauvais.length ? ` — SAUF ${mauvais.map((p) => p.id).join(", ")}` : ""));
  for (const p of mauvais) ecarts.push(`${p.id} : le catalogue annonce le schéma ${p.versionSchema}, le code est en ${schema}`);
} catch (e) {
  ecarts.push(`catalogue produit illisible : ${e.message}`);
}

/* ---------- 3. la source correspondante peut être produite ---------- */
console.log("\n3. Source correspondante (GPLv3)");
const sales = execFileSync("git", ["status", "--porcelain", "--untracked-files=no"], { encoding: "utf8" }).trim();
if (sales) {
  sautes.push("source correspondante — des fichiers SUIVIS sont modifiés : une release se fait sur un commit, pas sur un brouillon");
  dit("⤬ sauté : le dépôt n'est pas propre");
} else {
  try {
    const sortie = execSync("npm run source --silent", { encoding: "utf8" });
    dit(sortie.trim().split("\n").pop());
  } catch (e) {
    ecarts.push(`source correspondante impossible : ${e.message}`);
  }
}

/* ---------- 4. le dépôt public, s'il est atteignable ---------- */
console.log("\n4. Dépôt public");
if (!existsSync(site)) {
  sautes.push(`dépôt public introuvable (${site}) — l'état RÉELLEMENT en ligne n'a pas été contrôlé`);
  dit(`⤬ sauté : ${site} absent`);
} else {
  // On ne dépose que sur `main`, alignée (D-267/D-284) — refusé AVANT d'écrire.
  const branche = controlerBrancheSite(site);
  for (const m of branche.infos) dit(m);
  for (const m of branche.sautes) { dit(`⤬ ${m}`); sautes.push(m); }
  ecarts.push(...branche.ecarts);
  try {
    dit(execSync("node verifier-catalogues.mjs", { cwd: site, encoding: "utf8" }).trim());
  } catch (e) {
    ecarts.push(`garde du site en échec : ${String(e.stdout ?? e.message).trim().split("\n").slice(-3).join(" · ")}`);
  }
  const build = `${site}/app/build.json`;
  if (!existsSync(build)) {
    ecarts.push("app/ publié sans build.json — ni source correspondante, ni schéma lisible");
  } else {
    const b = JSON.parse(readFileSync(build, "utf8"));
    dit(`déployé : ${b.version}+${b.commit}, schéma ${b.versionSchema}, movpack v${b.versionMovpack}`);
    // Un build.json aux versions illisibles ne prouve rien : c'est le trou par
    // lequel `versionMovpack: null` serait parti en ligne (D-285).
    for (const champ of ["versionSchema", "versionMovpack"]) {
      if (!Number.isInteger(b[champ]) || b[champ] < 1)
        ecarts.push(`build.json déployé : ${champ} vaut ${JSON.stringify(b[champ])} — une version illisible ne permet plus de garantir la cohérence app/packs (D-285)`);
    }
    if (b.versionSchema < schema)
      ecarts.push(
        `l'app EN LIGNE lit le schéma ${b.versionSchema}, les packs qu'on s'apprête à publier sont en ${schema}`
        + " — déployer l'application AVANT ou AVEC les packs, jamais après (D-267)");
  }
}

/* ---------- verdict ---------- */
console.log("");
if (sautes.length) {
  console.log("CONTRÔLES SAUTÉS — un contrôle non fait n'est pas un contrôle réussi :");
  for (const s of sautes) console.log(`  ⤬ ${s}`);
  console.log("");
}
if (ecarts.length) {
  console.error(`verifier:release : ${ecarts.length} écart(s)\n`);
  for (const e of ecarts) console.error(`  ✕ ${e}`);
  console.error("\nRien ne se dépose tant qu'un écart subsiste.");
  process.exit(1);
}
console.log(sautes.length
  ? "verifier:release : aucun écart sur ce qui a PU être vérifié — lire la liste des contrôles sautés avant de déposer."
  : "verifier:release : tout est cohérent, dépôt public compris.");
