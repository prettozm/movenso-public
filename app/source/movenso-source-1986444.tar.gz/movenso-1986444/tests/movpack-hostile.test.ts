// Corpus d'archives HOSTILES (S1.4, audit P0.4 / D-165) — chaque refus est
// PROPRE : ErreurMovpack claire, puits abandonné (staging nettoyé), jamais de
// crash ni de saturation silencieuse. Les limites sont surchargées en test
// pour rester rapides ; les défauts (LIMITES_MOVPACK) sont larges.
import { test } from "node:test";
import assert from "node:assert/strict";
import { zipSync, Zip, ZipPassThrough } from "fflate";
import { lireMovpackFlux, type PuitsMediaFlux } from "../src/echange/movpack.ts";
import { ErreurMovpack } from "../src/echange/movpack-contrat.ts";
import { sha256Hex } from "../src/domaine/sha256.ts";
import { genererUlid } from "../src/domaine/ulid.ts";

function puitsMemoire() {
  let abandonne = false;
  let courant = false;
  const puits: PuitsMediaFlux = {
    async ouvrir() { courant = true; },
    async ecrire() { /* octets jetés : seuls les verdicts comptent ici */ },
    async fermer() { courant = false; },
    async abandonner() { abandonne = true; courant = false; },
  };
  return { puits, get abandonne() { return abandonne; }, get enCours() { return courant; } };
}

function fluxDe(octets: Uint8Array, tailleBloc = 512): ReadableStream<Uint8Array> {
  let pos = 0;
  return new ReadableStream<Uint8Array>({
    pull(ctrl) {
      if (pos >= octets.length) return ctrl.close();
      ctrl.enqueue(octets.slice(pos, Math.min(pos + tailleBloc, octets.length)));
      pos += tailleBloc;
    },
  });
}

/** ZIP en flux — contrairement à zipSync (clés d'objet), autorise les
 *  CHEMINS EN DOUBLE, exactement ce qu'une archive hostile ferait. */
function zipBrut(entrees: [string, Uint8Array][]): Promise<Uint8Array> {
  return new Promise((resolve, reject) => {
    const morceaux: Uint8Array[] = [];
    const z = new Zip((err, chunk, final) => {
      if (err) return reject(err);
      morceaux.push(chunk.slice());
      if (final) {
        let total = 0;
        for (const m of morceaux) total += m.length;
        const out = new Uint8Array(total);
        let p = 0;
        for (const m of morceaux) { out.set(m, p); p += m.length; }
        resolve(out);
      }
    });
    for (const [nom, data] of entrees) {
      const f = new ZipPassThrough(nom);
      z.add(f);
      f.push(data, true);
    }
    z.end();
  });
}

const refuse = async (octets: Uint8Array, motif: RegExp, limites?: Record<string, number>) => {
  const m = puitsMemoire();
  await assert.rejects(
    () => lireMovpackFlux(fluxDe(octets), m.puits, limites ? { limites } : {}),
    (e: unknown) => e instanceof ErreurMovpack && motif.test(e.message),
    `refus attendu (${motif})`,
  );
  assert.ok(m.abandonne, "le puits est TOUJOURS abandonné après un refus (staging nettoyé)");
  assert.ok(!m.enCours, "aucune écriture laissée ouverte");
};

test("hostile : trop d'entrées → refus net (borne du nombre d'entrées)", async () => {
  const entrees: Record<string, Uint8Array> = {};
  for (let i = 0; i < 6; i++) entrees[`note-${i}.txt`] = new Uint8Array([65 + i]);
  await refuse(zipSync(entrees), /entrées/, { entreesMax: 3 });
});

test("hostile : traversée de chemin ../ → refus explicite, rien d'écrit", async () => {
  await refuse(zipSync({ "medias/../evasion.webm": new Uint8Array(8) }), /chemin dangereux/);
});

test("hostile : chemin absolu et chemin Windows → refusés", async () => {
  await refuse(await zipBrut([["/etc/passwd", new Uint8Array(4)]]), /chemin dangereux/);
  await refuse(await zipBrut([["medias\\evasion.webm", new Uint8Array(4)]]), /chemin dangereux/);
  await refuse(await zipBrut([["c:/windows/evil", new Uint8Array(4)]]), /chemin dangereux/);
});

test("hostile : chemins en DOUBLE dans l'archive → refus (jamais d'écrasement)", async () => {
  const octets = await zipBrut([
    ["notes.txt", new Uint8Array([1])],
    ["notes.txt", new Uint8Array([2])],
  ]);
  await refuse(octets, /chemin en double/);
});

test("hostile : bibliotheque.json au-delà de sa borne mémoire → refus (zip bomb ciblée)", async () => {
  const gros = new TextEncoder().encode("[" + '"x",'.repeat(2000) + '"x"]');
  await refuse(zipSync({ "bibliotheque.json": gros }), /dépasse/, { octetsPetitFichier: 1_000 });
});

test("hostile : volume total décompressé au-delà de la borne → refus (zip bomb globale)", async () => {
  const bombe = new Uint8Array(1_000_000); // zéros : compression extrême
  await refuse(zipSync({ "bibliotheque.json": bombe }), /volume décompressé/, { octetsTotal: 10_000 });
});

test("hostile : exécutable déguisé en vidéo → refusé sur ses premiers octets", async () => {
  const mz = new Uint8Array(64);
  mz[0] = 0x4d; mz[1] = 0x5a; // MZ
  await refuse(zipSync({ [`medias/${genererUlid()}.webm`]: [mz, { level: 0 }] }), /exécutable Windows/);
  const elf = new Uint8Array([0x7f, 0x45, 0x4c, 0x46, 0, 0, 0, 0]);
  await refuse(zipSync({ [`medias/${genererUlid()}.mp4`]: [elf, { level: 0 }] }), /exécutable ELF/);
  const script = new TextEncoder().encode("#!/bin/sh\nrm -rf /\n");
  await refuse(zipSync({ [`videos/${genererUlid()}.mov`]: [script, { level: 0 }] }), /script exécutable/);
});

test("hostile : extension de média inattendue → refusée avant toute écriture", async () => {
  await refuse(zipSync({ [`medias/${genererUlid()}.exe`]: new Uint8Array(8) }), /type de média inattendu/);
  await refuse(zipSync({ [`medias/${genererUlid()}.html`]: new Uint8Array(8) }), /type de média inattendu/);
  await refuse(zipSync({ [`medias/${genererUlid()}.svg`]: new Uint8Array(8) }), /type de média inattendu/);
});

test("hostile : JSON pathologiquement profond → refus PROPRE, jamais un crash", async () => {
  const profondeur = 100_000;
  const json = new TextEncoder().encode("[".repeat(profondeur) + "]".repeat(profondeur));
  const manifeste = new TextEncoder().encode(JSON.stringify({
    format: "movpack", version: 3, id: "hostile", nom: "Hostile", portee: "discipline",
    creeLe: new Date().toISOString(), versionSchema: 4, empreinte: sha256Hex(json), videos: [],
  }));
  const m = puitsMemoire();
  await assert.rejects(
    () => lireMovpackFlux(fluxDe(zipSync({ "manifeste.json": manifeste, "bibliotheque.json": json })), m.puits),
    (e: unknown) => e instanceof ErreurMovpack,
    "un JSON profond est refusé comme illisible/invalide, sans faire tomber l'app",
  );
  assert.ok(m.abandonne);
});

test("hostile : archive interrompue (tronquée) → refus propre, staging nettoyé", async () => {
  const complet = zipSync({ "manifeste.json": new Uint8Array(64), "bibliotheque.json": new Uint8Array(64) });
  const tronque = complet.slice(0, Math.floor(complet.length / 2));
  await refuse(tronque, /illisible|incomplète/i);
});

test("hostile : manifeste MENSONGER (taille/empreinte fausses) → refus d'intégrité (NR 8B)", async () => {
  const bib = new TextEncoder().encode(JSON.stringify({ versionSchema: 4 }));
  const manifeste = new TextEncoder().encode(JSON.stringify({
    format: "movpack", version: 4, id: "menteur", nom: "Menteur", portee: "discipline",
    creeLe: new Date().toISOString(), versionSchema: 4, empreinte: "0".repeat(64), videos: [],
    algorithme: "SHA-256",
    fichiers: [{ chemin: "bibliotheque.json", taille: bib.length, sha256: "0".repeat(64) }],
  }));
  await refuse(zipSync({ "manifeste.json": manifeste, "bibliotheque.json": bib }), /Intégrité en échec/);
});

test("annulation d'une LECTURE en flux → abandon propre, staging nettoyé (S2.4)", async () => {
  const m = puitsMemoire();
  const octets = zipSync({ "manifeste.json": new Uint8Array(64), "bibliotheque.json": new Uint8Array(64) });
  await assert.rejects(
    () => lireMovpackFlux(fluxDe(octets, 32), m.puits, { estAnnule: () => true }),
    (e: unknown) => e instanceof ErreurMovpack && /annulé/i.test(e.message),
    "l'abandon volontaire est une ErreurMovpack claire",
  );
  assert.ok(m.abandonne, "le puits est abandonné — rien ne traîne en staging");
});

/* ---------- D-271 — les IMAGES s'accumulent en mémoire ----------
 *
 * Les médias vidéo partent au fil de l'eau vers le puits : ils ne pèsent
 * jamais sur le tas. Les images de couverture, elles, sont ACCUMULÉES —
 * choix assumé, elles sont petites (mesuré sur les six packs publiés : la
 * plus grande fait 46 Ko, le plus gros pack totalise 3,6 Mo).
 *
 * Mais elles héritaient de la borne des « petits fichiers » : 64 Mo CHACUNE.
 * Une archive hostile pouvait donc faire accumuler des centaines de Mo à un
 * téléphone. Elles ont désormais leur borne propre, par image et cumulée.
 */

/** Un conteneur v5 minimal portant `nb` images de `taille` octets. */
async function conteneurImages(nb: number, taille: number): Promise<Uint8Array> {
  const entrees: [string, Uint8Array][] = [];
  const fichiers: { chemin: string; taille: number; sha256: string }[] = [];
  const images: { id: string; mime: string; taille: number }[] = [];
  for (let i = 0; i < nb; i++) {
    const o = new Uint8Array(taille);
    o[0] = i & 0xff;
    o[1] = (i >> 8) & 0xff;
    const id = sha256Hex(o);
    images.push({ id, mime: "image/jpeg", taille });
    fichiers.push({ chemin: `images/${id}`, taille, sha256: id });
    entrees.push([`images/${id}`, o]);
  }
  const bib = new TextEncoder().encode(JSON.stringify({ ...bibliothequeMinimale(), images }));
  fichiers.unshift({ chemin: "bibliotheque.json", taille: bib.length, sha256: sha256Hex(bib) });
  const manifeste = new TextEncoder().encode(JSON.stringify({
    format: "movpack", version: 5, id: "essai", nom: "Essai", portee: "discipline",
    creeLe: new Date(0).toISOString(), versionSchema: 6, empreinte: sha256Hex(bib),
    videos: [], algorithme: "SHA-256", fichiers,
  }));
  return zipBrut([["bibliotheque.json", bib], ...entrees, ["manifeste.json", manifeste]]);
}

function bibliothequeMinimale() {
  return {
    versionSchema: 6, typesRelation: [], disciplines: [], techniques: [],
    contributions: [], compositions: [], favoris: [],
  };
}

test("images : une seule trop grosse est refusée", async () => {
  const octets = await conteneurImages(1, 40_000);
  await refuse(octets, /dépasse/, { octetsImage: 10_000 });
});

test("images : le CUMUL est borné — c'est lui qui met un téléphone à genoux", async () => {
  const octets = await conteneurImages(10, 20_000); // 200 Ko cumulés
  await refuse(octets, /images dépassent/, { octetsImagesTotal: 100_000 });
});

test("images : un volume LÉGITIME passe (repère réel : 109 images, 3,6 Mo)", async () => {
  const m = puitsMemoire();
  const lu = await lireMovpackFlux(fluxDe(await conteneurImages(20, 20_000)), m.puits, {});
  assert.equal(lu.images.length, 20, "les images légitimes sont bien remontées");
  assert.equal(m.abandonne, false, "aucun abandon sur un conteneur sain");
});
