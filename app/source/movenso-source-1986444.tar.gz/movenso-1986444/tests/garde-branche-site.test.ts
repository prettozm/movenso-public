/**
 * GARDE DE BRANCHE DU SITE (D-284) — un dépôt public ne reçoit que sur `main`.
 *
 * L'incident : à la reprise du 2026-08-10, le clone de `movenso-public` était
 * positionné sur une branche de travail héritée d'une consigne de session.
 * `deposer` aurait écrit dessus sans un mot. La garde s'exécute en
 * sous-processus : c'est le chemin réel de `verifier:release`, pas un chemin
 * inventé pour le test.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const GARDE = fileURLToPath(new URL("../outils/garde-branche-site.mjs", import.meta.url));

function git(cwd: string, ...args: string[]): string {
  return execFileSync(
    "git",
    ["-C", cwd, "-c", "user.email=test@test.invalide", "-c", "user.name=test", ...args],
    { encoding: "utf8" },
  ).trim();
}

function garde(site: string): { code: number; sortie: string } {
  try {
    const sortie = execFileSync(process.execPath, [GARDE, site], { encoding: "utf8" });
    return { code: 0, sortie };
  } catch (e) {
    const err = e as { status?: number | null; stdout?: string; stderr?: string };
    return { code: err.status ?? -1, sortie: `${err.stdout ?? ""}${err.stderr ?? ""}` };
  }
}

/** Un « GitHub » local (amont) et son clone (site) — aucun réseau. */
function fabriquerSite(): { amont: string; site: string; racine: string } {
  const racine = mkdtempSync(join(tmpdir(), "garde-branche-"));
  const amont = join(racine, "amont");
  mkdirSync(amont);
  git(amont, "init", "-b", "main");
  writeFileSync(join(amont, "index.html"), "<!doctype html>\n");
  git(amont, "add", "-A");
  git(amont, "commit", "-m", "site initial");
  const site = join(racine, "site");
  execFileSync("git", ["clone", "--quiet", amont, site], { encoding: "utf8" });
  return { amont, site, racine };
}

test("sur main, aligné sur origin/main : la garde laisse passer", () => {
  const { site, racine } = fabriquerSite();
  try {
    const r = garde(site);
    assert.equal(r.code, 0, r.sortie);
    assert.match(r.sortie, /aligné/);
  } finally {
    rmSync(racine, { recursive: true, force: true });
  }
});

test("sur une branche de travail : refus, qui nomme la branche et le geste", () => {
  const { site, racine } = fabriquerSite();
  try {
    git(site, "checkout", "-b", "claude/travail");
    const r = garde(site);
    assert.equal(r.code, 1, r.sortie);
    assert.match(r.sortie, /claude\/travail/);
    assert.match(r.sortie, /main/);
    assert.match(r.sortie, /D-267/);
  } finally {
    rmSync(racine, { recursive: true, force: true });
  }
});

test("main en retard sur origin/main : refus — la garde va chercher l'amont elle-même", () => {
  const { amont, site, racine } = fabriquerSite();
  try {
    writeFileSync(join(amont, "nouveau.html"), "<!doctype html>\n");
    git(amont, "add", "-A");
    git(amont, "commit", "-m", "dépôt fait ailleurs");
    // Pas de fetch ici : c'est à la garde de rafraîchir origin/main.
    const r = garde(site);
    assert.equal(r.code, 1, r.sortie);
    assert.match(r.sortie, /retard/);
  } finally {
    rmSync(racine, { recursive: true, force: true });
  }
});

test("un dossier qui n'est pas un clone git : refus explicite", () => {
  const racine = mkdtempSync(join(tmpdir(), "garde-branche-"));
  try {
    const r = garde(racine);
    assert.equal(r.code, 1, r.sortie);
    assert.match(r.sortie, /clone git/);
  } finally {
    rmSync(racine, { recursive: true, force: true });
  }
});

test("contrepartie : un dépôt précédent commité mais non poussé passe, et la garde le dit", () => {
  const { site, racine } = fabriquerSite();
  try {
    writeFileSync(join(site, "app.html"), "<!doctype html>\n");
    git(site, "add", "-A");
    git(site, "commit", "-m", "dépôt précédent, poussée humaine à venir");
    const r = garde(site);
    assert.equal(r.code, 0, r.sortie);
    assert.match(r.sortie, /non poussé/);
  } finally {
    rmSync(racine, { recursive: true, force: true });
  }
});
