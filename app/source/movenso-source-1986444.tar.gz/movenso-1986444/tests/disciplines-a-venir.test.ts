/** D-333 — les disciplines « à venir » ne peuvent pas contredire le catalogue :
 *  celle qui a reçu son pack sort de la liste toute seule. */

import { test } from "node:test";
import assert from "node:assert/strict";
import { DISCIPLINES_A_VENIR, disciplinesSansPack } from "../src/app/disciplines-a-venir.ts";

test("à venir : sans catalogue, toute la liste est proposée", () => {
  assert.equal(disciplinesSansPack([]).length, DISCIPLINES_A_VENIR.length);
  assert.ok(DISCIPLINES_A_VENIR.length > 0, "la liste ne serait qu'un décor si elle était vide");
});

test("à venir : une discipline PUBLIÉE disparaît de l'invitation", () => {
  const sans = disciplinesSansPack([{ discipline: "Aïkido", title: "Aïkido Aikikai" }]);
  assert.ok(!sans.some((d) => d.nom === "Aïkido"), "« Aïkido » ne peut pas être à venir ET publié");
  assert.equal(sans.length, DISCIPLINES_A_VENIR.length - 1, "les autres restent");
});

test("à venir : le rapprochement ignore accents et casse", () => {
  // Le catalogue est écrit à la main dans `publication/packs.json` : « aikido »
  // sans tréma, ou « AÏKIDO », ne doit pas rouvrir une case déjà servie.
  for (const ecrit of ["aikido", "AÏKIDO", "  Aikido  "])
    assert.ok(
      !disciplinesSansPack([{ discipline: ecrit, title: "x" }]).some((d) => d.nom === "Aïkido"),
      `« ${ecrit} » doit fermer la case « Aïkido »`,
    );
});

test("à venir : le TITRE du pack compte aussi, pas seulement sa discipline", () => {
  const sans = disciplinesSansPack([{ title: "Sumo" }]);
  assert.ok(!sans.some((d) => d.nom === "Sumo"));
});

test("à venir : aucune entrée sans illustration, et aucun doublon", () => {
  // Un nom sans image se lirait comme un défaut d'affichage, pas comme une
  // invitation ; deux fois la même discipline, comme un bug.
  const noms = new Set<string>();
  for (const d of DISCIPLINES_A_VENIR) {
    assert.match(d.icon, /^packs\/img\/venir-[a-z0-9-]+\.webp$/, `illustration attendue pour ${d.nom}`);
    assert.ok(!noms.has(d.nom), `doublon : ${d.nom}`);
    noms.add(d.nom);
  }
});
