import { test } from "node:test";
import assert from "node:assert/strict";
import { relationsPourFiche } from "../src/domaine/relations.ts";
import { genererUlid } from "../src/domaine/ulid.ts";
import { bibliotheque, disciplineJudo, technique } from "./aide.ts";

function monde() {
  const judo = disciplineJudo();
  const osoto = technique(judo.id, { nom: "O-soto-gari" });
  const kouchi = technique(judo.id, { nom: "Ko-uchi-gari" });
  const tsubame = technique(judo.id, { nom: "Tsubame-gaeshi" });
  // kouchi prépare osoto ; tsubame contre osoto ; osoto similaire à un absent
  kouchi.relations = [{ type: "prepare", cibleId: osoto.id }];
  tsubame.relations = [{ type: "contre", cibleId: osoto.id }];
  const absent = genererUlid();
  osoto.relations = [{ type: "similaire", cibleId: absent }];
  const b = bibliotheque({ techniques: [osoto, kouchi, tsubame], contributions: [], disciplines: [judo] });
  return { b, osoto, kouchi, tsubame, absent };
}

test("les inverses sont dérivés, jamais stockés — libellés issus des données", () => {
  const { b, osoto, kouchi, tsubame } = monde();
  const fiche = relationsPourFiche(b, osoto.id);
  assert.deepEqual(
    fiche.filter((r) => r.libelle === "Préparée par").map((r) => r.techniqueId),
    [kouchi.id],
  );
  assert.deepEqual(
    fiche.filter((r) => r.libelle === "Contrée par").map((r) => r.techniqueId),
    [tsubame.id],
  );
  // et côté source, le sens direct (marqué éditable)
  const ficheKouchi = relationsPourFiche(b, kouchi.id);
  const directe = ficheKouchi.find((r) => r.libelle === "Prépare");
  assert.ok(directe);
  assert.equal(directe.techniqueId, osoto.id);
  assert.equal(directe.directe, true);
});

test("un type de relation défini par les données produit ses propres libellés (H5 levée)", () => {
  const { b, osoto, kouchi } = monde();
  b.typesRelation.push({ id: "defend", libelle: "Défend contre", libelleInverse: "Défendue par" });
  kouchi.relations.push({ type: "defend", cibleId: osoto.id });
  const fiche = relationsPourFiche(b, osoto.id);
  const derivee = fiche.find((r) => r.libelle === "Défendue par");
  assert.ok(derivee);
  assert.equal(derivee.techniqueId, kouchi.id);
  assert.equal(derivee.directe, false);
});

test("une cible absente est affichée non présente, jamais une erreur", () => {
  const { b, osoto, absent } = monde();
  const fiche = relationsPourFiche(b, osoto.id);
  const similaire = fiche.find((r) => r.libelle === "Similaire à");
  assert.ok(similaire);
  assert.equal(similaire.techniqueId, absent);
  assert.equal(similaire.presente, false);
});

test("similaire déclaré des deux côtés n'apparaît qu'une fois", () => {
  const { b, osoto, kouchi } = monde();
  osoto.relations.push({ type: "similaire", cibleId: kouchi.id });
  kouchi.relations.push({ type: "similaire", cibleId: osoto.id });
  const fiche = relationsPourFiche(b, osoto.id);
  assert.equal(fiche.filter((r) => r.libelle === "Similaire à" && r.techniqueId === kouchi.id).length, 1);
});

test("une fiche sans aucune liaison rend une liste vide", () => {
  const b = bibliotheque();
  assert.deepEqual(relationsPourFiche(b, b.techniques[0]!.id), []);
});

test("repli d'un type SANS rôle : peer partout, un seul repli (D-253)", () => {
  const { b, osoto, kouchi } = monde();
  // Un type créé sans rôle (cas d'un type utilisateur d'avant la question « quel genre de lien ? »).
  b.typesRelation.push({ id: "libre", libelle: "Lien libre", symetrique: true });
  osoto.relations.push({ type: "libre", cibleId: kouchi.id });
  const lien = relationsPourFiche(b, osoto.id).find((r) => r.libelle === "Lien libre");
  assert.equal(lien?.role, "peer", "un type sans rôle retombe sur peer — le repli unique du domaine, jamais distinction ni context");
});
