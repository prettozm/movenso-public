/** Conteneur .movpack v3 (D-018.1) : aller-retour, intégrité, extraction de pack. */

import { test } from "node:test";
import assert from "node:assert/strict";
import { exporterMovpack, exporterMovpackFlux, lireMovpack } from "../src/echange/movpack.ts";
import { ErreurMovpack, estZip, VERSION_MOVPACK } from "../src/echange/movpack-contrat.ts";
import { extrairePackComposition, extrairePackDiscipline, extrairePackTechnique, idDePack, idPackStable } from "../src/echange/extraction-pack.ts";
import { sha256Hex } from "../src/domaine/sha256.ts";
import { genererUlid } from "../src/domaine/ulid.ts";
import { bibliotheque, composition, contribution, disciplineJudo, technique } from "./aide.ts";

test("aller-retour : exporter puis lire restitue la bibliothèque et les vidéos, à l'identique", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}` });
  b.compositions.push(composition());
  const video = new Uint8Array([1, 2, 3, 4, 5]);
  const octets = await exporterMovpack(
    b,
    { id: "movenso-export-complet", nom: "Export complet", portee: "complet", auteur: "Yahya" },
    new Map([[mediaId, video]]),
  );
  assert.ok(estZip(octets), "un .movpack est une archive ZIP");
  const relu = await lireMovpack(octets);
  assert.equal(relu.manifeste.portee, "complet");
  assert.equal(relu.manifeste.auteur, "Yahya");
  assert.deepEqual(relu.bibliotheque, b, "aucune perte : ids, contributions, compositions conservés");
  assert.deepEqual([...relu.videos.get(mediaId)!], [...video]);
  assert.deepEqual(relu.avertissements, [], "un conteneur sain n'émet aucun avertissement");
});

test("manifeste : inventaire par fichier {chemin, taille, SHA-256} + inclusions dites (§12 : medias/<id>.<ext>)", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}`, extension: "webm" });
  const video = new Uint8Array([7, 7, 7, 7]);
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "complet" }, new Map([[mediaId, video]]));
  const { unzipSync } = await import("fflate");
  const arch = unzipSync(octets);
  const m = JSON.parse(new TextDecoder().decode(arch["manifeste.json"]!));
  assert.equal(m.version, VERSION_MOVPACK);
  assert.equal(m.algorithme, "SHA-256");
  assert.equal(m.versionEditoriale, 1, "version éditoriale par défaut");
  assert.deepEqual(m.inclusions, { medias: true, contenuPersonnel: true }, "les inclusions sont DITES");
  const chemins = m.fichiers.map((f: { chemin: string }) => f.chemin).sort();
  assert.deepEqual(chemins, ["bibliotheque.json", `medias/${mediaId}.webm`], "structure canonique : medias/<id>.<extension>");
  assert.ok(arch[`medias/${mediaId}.webm`], "le média est bien rangé sous medias/ avec son extension");
  const entreeVideo = m.fichiers.find((f: { chemin: string }) => f.chemin === `medias/${mediaId}.webm`);
  assert.equal(entreeVideo.taille, 4, "la taille réelle du média est inventoriée");
  assert.ok(/^[0-9a-f]{64}$/.test(entreeVideo.sha256), "chaque fichier porte une empreinte SHA-256");
});

test("inclusions : un pack de discipline sans vidéos dit medias:false, contenuPersonnel:false", async () => {
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "discipline" }, new Map());
  const { unzipSync } = await import("fflate");
  const m = JSON.parse(new TextDecoder().decode(unzipSync(octets)["manifeste.json"]!));
  assert.deepEqual(m.inclusions, { medias: false, contenuPersonnel: false });
});

test("intégrité : bibliotheque.json altéré (à taille constante) est rejeté AVANT toute lecture", async () => {
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "complet" }, new Map());
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  const bib = fichiers["bibliotheque.json"]!;
  bib[10] = bib[10]! ^ 0xff; // un octet retourné : même taille, empreinte cassée
  await assert.rejects(
    () => lireMovpack(zipSync(fichiers)),
    (e: Error) => e instanceof ErreurMovpack && /[Ii]ntégrité/.test(e.message) && /bibliotheque\.json/.test(e.message),
  );
});

test("intégrité : un média corrompu est refusé, en nommant le fichier fautif (§14)", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}`, extension: "webm" });
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "complet" }, new Map([[mediaId, new Uint8Array([1, 2, 3, 4])]]));
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  fichiers[`medias/${mediaId}.webm`]![0] = 42; // même taille, contenu différent
  await assert.rejects(
    () => lireMovpack(zipSync(fichiers)),
    (e: Error) => e instanceof ErreurMovpack && /[Ii]ntégrité/.test(e.message) && e.message.includes(mediaId),
  );
});

test("intégrité : un média déclaré mais ABSENT de l'archive est refusé (fichier manquant)", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}`, extension: "webm" });
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "complet" }, new Map([[mediaId, new Uint8Array([1, 2, 3])]]));
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  delete fichiers[`medias/${mediaId}.webm`];
  await assert.rejects(
    () => lireMovpack(zipSync(fichiers)),
    (e: Error) => e instanceof ErreurMovpack && /manquant/.test(e.message),
  );
});

test("intégrité : une taille de fichier modifiée est refusée avant l'empreinte", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}`, extension: "webm" });
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "complet" }, new Map([[mediaId, new Uint8Array([1, 2, 3, 4])]]));
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  fichiers[`medias/${mediaId}.webm`] = new Uint8Array([1, 2, 3, 4, 5, 6]); // taille ≠ déclarée
  await assert.rejects(
    () => lireMovpack(zipSync(fichiers)),
    (e: Error) => e instanceof ErreurMovpack && /Taille/.test(e.message),
  );
});

test("fichier inattendu : IGNORÉ mais SIGNALÉ, l'import reste possible (§14)", async () => {
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "discipline" }, new Map());
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  fichiers["surprise.txt"] = new TextEncoder().encode("contenu étranger");
  const relu = await lireMovpack(zipSync(fichiers));
  assert.equal(relu.avertissements.length, 1, "le fichier inattendu est signalé");
  assert.ok(relu.avertissements[0]!.includes("surprise.txt"), "l'avertissement nomme le fichier");
  assert.ok(relu.bibliotheque, "l'import reste possible : le fichier étranger est simplement ignoré");
});

test("rétrocompat : un conteneur v3 (empreinte globale, médias sous videos/) reste lisible", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}` });
  const video = new Uint8Array([9, 8, 7]);
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "complet" }, new Map([[mediaId, video]]));
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  // reconstruit un VRAI conteneur v3 : médias sous videos/<id>, manifeste sans
  // inventaire (empreinte globale de bibliotheque.json seule)
  const cheminV4 = Object.keys(fichiers).find((k) => k.startsWith("medias/"))!;
  fichiers[`videos/${mediaId}`] = fichiers[cheminV4]!;
  delete fichiers[cheminV4];
  const m = JSON.parse(new TextDecoder().decode(fichiers["manifeste.json"]!));
  delete m.fichiers;
  delete m.inclusions;
  delete m.algorithme;
  m.version = 3;
  fichiers["manifeste.json"] = new TextEncoder().encode(JSON.stringify(m));
  const relu = await lireMovpack(zipSync(fichiers));
  assert.deepEqual(relu.bibliotheque, b, "un v3 se relit par repli sur l'empreinte globale");
  assert.deepEqual([...relu.videos.get(mediaId)!], [...video], "les vidéos d'un v3 (videos/<id>) sont retrouvées par préfixe");
});

test("un conteneur d'une version future est refusé avec un message actionnable", async () => {
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "discipline" }, new Map());
  // reconstruit une archive au manifeste bidouillé
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  const manifeste = JSON.parse(new TextDecoder().decode(fichiers["manifeste.json"]!));
  manifeste.version = 99;
  fichiers["manifeste.json"] = new TextEncoder().encode(JSON.stringify(manifeste));
  await assert.rejects(() => lireMovpack(zipSync(fichiers)), /mettre à jour l'application/);
});

test("extraction de pack : le carnet personnel ne se publie jamais, le sourcé voyage", () => {
  const b = bibliotheque();
  const t = b.techniques[0]!;
  b.contributions.push(contribution(t.id, { provenance: "enseignement", attribution: "Club" }));
  b.compositions.push(composition({ provenance: "enseignement", attribution: "Club", nom: "Programme jaune" }));
  b.compositions.push(composition({ nom: "Ma spéciale" })); // personnel
  const autre = technique(b.disciplines[0]!.id, { nom: "Autre" });
  b.techniques.push(autre);
  const { extrait } = extrairePackDiscipline(b, b.disciplines[0]!.id);
  assert.equal(extrait.contributions.length, 1, "la contribution personnelle est exclue");
  assert.equal(extrait.contributions[0]!.provenance, "enseignement");
  assert.deepEqual(extrait.compositions.map((c) => c.nom), ["Programme jaune"]);
  assert.equal(extrait.techniques.length, 2);
  assert.equal(idDePack("Judo Été"), "pack-judoete");
});

test("publication maîtrisée (D-023) : le contenu d'une source importée ne part jamais par défaut", () => {
  const b = bibliotheque();
  const t = b.techniques[0]!;
  // contribution importée d'un autre pack (le curateur ne la maîtrise pas)
  b.contributions.push(
    contribution(t.id, { provenance: "referentiel", attribution: "Kodokan", origine: { pack: "kodokan", element: "1" } }),
  );
  // contribution locale d'enseignement (la sienne)
  b.contributions.push(contribution(t.id, { provenance: "enseignement", attribution: "Mon club" }));
  const { extrait: parDefaut } = extrairePackDiscipline(b, b.disciplines[0]!.id);
  assert.deepEqual(parDefaut.contributions.map((c) => c.attribution), ["Mon club"], "seul le local part par défaut");
  const { extrait: optIn } = extrairePackDiscipline(b, b.disciplines[0]!.id, new Set(["local", "kodokan"]));
  assert.equal(optIn.contributions.length, 2, "la source cochée explicitement voyage");
});

/** Découpe un contenu en blocs de taille fixe, en enregistrant les tailles
 *  effectivement remises au flux (pour prouver que rien n'est chargé entier). */
function lecteurBlocs(contenus: Map<string, Uint8Array>, tailleBloc: number, journal: number[]) {
  return async function* (id: string) {
    const c = contenus.get(id);
    if (!c) return;
    for (let p = 0; p < c.length; p += tailleBloc) {
      const bloc = c.subarray(p, Math.min(p + tailleBloc, c.length));
      journal.push(bloc.length);
      yield bloc;
    }
  };
}

test("export en flux (8B.3) : ronde-trip identique, médias lus PAR BLOCS bornés", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}`, extension: "webm" });
  const media = new Uint8Array(25);
  for (let i = 0; i < media.length; i++) media[i] = (i * 7 + 3) & 0xff;
  const contenus = new Map([[mediaId, media]]);
  const tailleBloc = 8;
  const journalBlocs: number[] = [];
  const chunks: Uint8Array[] = [];
  const manifeste = await exporterMovpackFlux(
    b,
    { id: "x", nom: "X", portee: "complet" },
    [mediaId],
    lecteurBlocs(contenus, tailleBloc, journalBlocs),
    { ecrire: async (c) => void chunks.push(c.slice()) },
    { creeLe: "2026-07-13T00:00:00.000Z" },
  );
  // le média (25 o) a été remis en blocs de ≤ 8 o — jamais chargé en entier
  assert.deepEqual(journalBlocs, [8, 8, 8, 1], "média lu par blocs bornés, jamais d'un coup");
  // recompose l'archive et relit : identité parfaite
  const total = new Uint8Array(chunks.reduce((n, c) => n + c.length, 0));
  let o = 0;
  for (const c of chunks) { total.set(c, o); o += c.length; }
  assert.ok(estZip(total));
  const relu = await lireMovpack(total);
  assert.deepEqual(relu.bibliotheque, b, "aucune perte de données");
  assert.deepEqual([...relu.videos.get(mediaId)!], [...media], "octets du média conservés exactement");
  // l'empreinte du manifeste == SHA-256 indépendant du média (conservation d'octets)
  const entree = manifeste.fichiers!.find((f) => f.chemin.startsWith("medias/"))!;
  assert.equal(entree.sha256, sha256Hex(media), "l'empreinte inventoriée correspond aux octets réellement archivés");
  assert.equal(entree.taille, 25);
});

test("export en flux (8B.3) : deux exports successifs, empreintes stables", async () => {
  const b = bibliotheque();
  const id = genererUlid();
  b.contributions[0]!.medias.push({ id, type: "local", ref: `videos/${id}`, extension: "mp4" });
  const media = new Uint8Array([9, 9, 9, 9, 9, 9, 9]);
  const faire = async () => {
    const chunks: Uint8Array[] = [];
    const m = await exporterMovpackFlux(b, { id: "x", nom: "X", portee: "discipline" }, [id],
      lecteurBlocs(new Map([[id, media]]), 4, []),
      { ecrire: async (c) => void chunks.push(c.slice()) }, { creeLe: "2026-07-13T00:00:00.000Z" });
    return m.fichiers!.find((f) => f.chemin.startsWith("medias/"))!.sha256;
  };
  assert.equal(await faire(), await faire(), "deux exports du même contenu donnent la même empreinte");
});

test("export en flux (8B.3) : annulation à mi-parcours → aucune finalisation", async () => {
  const b = bibliotheque();
  const id1 = genererUlid();
  const id2 = genererUlid();
  b.contributions[0]!.medias.push({ id: id1, type: "local", ref: `videos/${id1}`, extension: "webm" });
  b.contributions[0]!.medias.push({ id: id2, type: "local", ref: `videos/${id2}`, extension: "webm" });
  const contenus = new Map([[id1, new Uint8Array(20)], [id2, new Uint8Array(20)]]);
  let blocsLus = 0;
  let annule = false;
  const lecteur = async function* (id: string) {
    for await (const bloc of lecteurBlocs(contenus, 8, [])(id)) {
      blocsLus++;
      if (blocsLus >= 2) annule = true; // l'utilisateur annule après 2 blocs
      yield bloc;
    }
  };
  let finalise = false;
  await assert.rejects(
    () =>
      exporterMovpackFlux(b, { id: "x", nom: "X", portee: "complet" }, [id1, id2], lecteur,
        { ecrire: async () => {} },
        { creeLe: "2026-07-13T00:00:00.000Z", estAnnule: () => annule, surProgression: (fait, total) => { if (fait === total) finalise = true; } }),
    (e: Error) => e instanceof ErreurMovpack && /annulé/.test(e.message),
  );
  assert.equal(finalise, false, "un export annulé ne finalise jamais tous les médias");
});

test("identité de pack stable (8B.1id) : dérivée de l'ULID de l'entité, jamais du nom", () => {
  const ulid = genererUlid();
  assert.equal(idPackStable(ulid), `pack-${ulid}`, "l'identité porte l'ULID stable");
  assert.equal(idPackStable(ulid), idPackStable(ulid), "identité invariante : le nom n'entre pas dans le calcul");
  assert.notEqual(idPackStable(ulid), idDePack("Judo du club"), "l'identité technique n'est pas le nom de fichier lisible");
});

test("lot 5 §4 — les favoris ne voyagent JAMAIS dans une publication de pack", () => {
  const b = bibliotheque();
  const judo = b.disciplines[0]!;
  b.favoris = [b.techniques[0]!.id];
  const { extrait } = extrairePackDiscipline(b, judo.id, new Set(["local"]));
  assert.deepEqual(extrait.favoris, [], "la publication n'emporte aucun marque-page personnel");
});

/* ===== Lot 10B (A1) — relations hors périmètre à la publication : une relation
   n'est exportée que si sa source ET sa cible sont dans le périmètre. ===== */
test("publication A1 : relation interne conservée, relation hors périmètre exclue, local intact", () => {
  const judo = disciplineJudo();
  const a = technique(judo.id, { nom: "A" });
  const cible = technique(judo.id, { nom: "B" });
  const horsId = genererUlid(); // identité NON incluse dans le pack
  a.relations = [
    { type: "enchaine", cibleId: cible.id }, // interne au périmètre
    { type: "contre", cibleId: horsId }, // cible hors périmètre
  ];
  const lib = bibliotheque({ disciplines: [judo], techniques: [a, cible], contributions: [] });
  const { extrait, relationsExclues } = extrairePackDiscipline(lib, judo.id, new Set(["local"]));
  const idsPack = new Set(extrait.techniques.map((t) => t.id));
  const aPub = extrait.techniques.find((t) => t.nom === "A")!;

  // 1 — relation interne conservée
  assert.ok(aPub.relations.some((r) => r.cibleId === cible.id), "relation interne au périmètre conservée");
  // 2 — relation vers cible hors périmètre exclue
  assert.ok(!aPub.relations.some((r) => r.cibleId === horsId), "relation vers cible hors périmètre exclue");
  // 5 — aperçu/rapport : nombre EXACT + raison identifiable
  assert.equal(relationsExclues.length, 1, "une exclusion, comptée exactement");
  assert.equal(relationsExclues[0]!.cibleId, horsId);
  assert.equal(relationsExclues[0]!.techniqueNom, "A");
  // 3 — la relation LOCALE originale n'est pas modifiée
  assert.equal(a.relations.length, 2, "relation locale inchangée après publication");
  assert.ok(a.relations.some((r) => r.cibleId === horsId), "la relation locale hors périmètre subsiste localement");
  // 4 — aucune identité cible ajoutée implicitement
  assert.ok(!idsPack.has(horsId), "la cible hors périmètre n'est jamais ajoutée au pack");
  // 6 — réimport sûr : aucune référence relationnelle invalide dans le pack
  for (const t of extrait.techniques) for (const r of t.relations) assert.ok(idsPack.has(r.cibleId), "aucun lien pendant publié (réimport sans référence invalide)");
});

test("publication A1 : zéro exclusion quand toutes les cibles sont dans le périmètre", () => {
  const judo = disciplineJudo();
  const a = technique(judo.id, { nom: "A" });
  const cible = technique(judo.id, { nom: "B" });
  a.relations = [{ type: "enchaine", cibleId: cible.id }];
  const lib = bibliotheque({ disciplines: [judo], techniques: [a, cible], contributions: [] });
  const { extrait, relationsExclues } = extrairePackDiscipline(lib, judo.id, new Set(["local"]));
  assert.equal(relationsExclues.length, 0, "aucune exclusion quand toutes les cibles sont présentes");
  assert.equal(extrait.techniques.find((t) => t.nom === "A")!.relations.length, 1, "la relation interne est conservée");
});

/* ===== Lecture EN FLUX (D-114) : mémoire bornée, mêmes garanties d'intégrité
   que lireMovpack. Le puits mémoire simule le staging OPFS de l'app. ===== */

import { lireMovpackFlux, type PuitsMediaFlux } from "../src/echange/movpack.ts";

/** Puits mémoire : collecte les octets par nom physique, en constatant le
 *  cycle ouvrir → écrire* → fermer et l'abandon (nettoyage). */
function puitsMemoire() {
  const medias = new Map<string, Uint8Array[]>();
  let courant: { nom: string; blocs: Uint8Array[] } | null = null;
  let abandonne = false;
  let ouverts = 0;
  const puits: PuitsMediaFlux = {
    async ouvrir(nom) {
      if (courant) throw new Error("média non clos avant l'ouverture d'un autre — le ZIP n'est pas séquentiel ?");
      courant = { nom, blocs: [] };
      ouverts++;
    },
    async ecrire(bloc) {
      courant!.blocs.push(bloc.slice()); // copie : le tampon fflate est réutilisé
    },
    async fermer() {
      const { nom, blocs } = courant!;
      let total = 0;
      for (const b of blocs) total += b.length;
      const out = new Uint8Array(total);
      let p = 0;
      for (const b of blocs) { out.set(b, p); p += b.length; }
      medias.set(nom, [out]);
      courant = null;
    },
    async abandonner() {
      abandonne = true;
      courant = null;
      medias.clear();
    },
  };
  return {
    puits,
    octets: (nom: string) => medias.get(nom)?.[0],
    get abandonne() { return abandonne; },
    get ouverts() { return ouverts; },
  };
}

/** Flux d'octets en petits blocs — exerce le réassemblage multi-chunks. */
function fluxDe(octets: Uint8Array, tailleBloc = 64): ReadableStream<Uint8Array> {
  let pos = 0;
  return new ReadableStream<Uint8Array>({
    pull(ctrl) {
      if (pos >= octets.length) return ctrl.close();
      ctrl.enqueue(octets.slice(pos, Math.min(pos + tailleBloc, octets.length)));
      pos += tailleBloc;
    },
  });
}

test("flux : aller-retour == lireMovpack, médias écrits par blocs dans le puits (jamais en RAM)", async () => {
  const b = bibliotheque();
  const idA = genererUlid();
  const idB = genererUlid();
  b.contributions[0]!.medias.push({ id: idA, type: "local", ref: `videos/${idA}`, extension: "webm" });
  b.contributions[0]!.medias.push({ id: idB, type: "local", ref: `videos/${idB}`, extension: "mp4" });
  const videoA = new Uint8Array(700_000);
  for (let i = 0; i < videoA.length; i++) videoA[i] = (i * 31 + 7) & 0xff; // > un bloc : multi-chunk
  const videoB = new Uint8Array([4, 2]);
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "discipline" }, new Map([[idA, videoA], [idB, videoB]]));

  const m = puitsMemoire();
  const contenu = await lireMovpackFlux(fluxDe(octets, 64), m.puits);
  const relu = await lireMovpack(octets);
  assert.deepEqual(contenu.bibliotheque, relu.bibliotheque, "même bibliothèque qu'en lecture mémoire");
  assert.equal(contenu.manifeste.id, relu.manifeste.id);
  assert.deepEqual(contenu.avertissements, []);
  assert.equal(contenu.medias.length, 2);
  // les octets exacts ont transité par le puits, hachés et dimensionnés justes
  assert.deepEqual([...m.octets(`${idA}.webm`)!], [...videoA], "gros média réassemblé à l'identique");
  assert.deepEqual([...m.octets(`${idB}.mp4`)!], [...videoB]);
  const mA = contenu.medias.find((x) => x.id === idA)!;
  assert.equal(mA.taille, videoA.length);
  assert.equal(mA.sha256, sha256Hex(videoA), "empreinte incrémentale == empreinte du contenu");
  assert.equal(mA.nomPhysique, `${idA}.webm`);
});

test("flux : un média corrompu est refusé (intégrité), le puits est abandonné (staging nettoyé)", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}`, extension: "webm" });
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "complet" }, new Map([[mediaId, new Uint8Array([1, 2, 3, 4])]]));
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  fichiers[`medias/${mediaId}.webm`]![0] = 42; // même taille, contenu différent
  const m = puitsMemoire();
  await assert.rejects(
    () => lireMovpackFlux(fluxDe(zipSync(fichiers)), m.puits),
    (e: Error) => e instanceof ErreurMovpack && /[Ii]ntégrité/.test(e.message) && e.message.includes(mediaId),
  );
  assert.equal(m.abandonne, true, "un conteneur douteux fait nettoyer le staging");
});

test("flux : un média déclaré mais ABSENT est refusé (fichier manquant)", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}`, extension: "webm" });
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "complet" }, new Map([[mediaId, new Uint8Array([1, 2, 3])]]));
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  delete fichiers[`medias/${mediaId}.webm`];
  const m = puitsMemoire();
  await assert.rejects(
    () => lireMovpackFlux(fluxDe(zipSync(fichiers)), m.puits),
    (e: Error) => e instanceof ErreurMovpack && /manquant/.test(e.message),
  );
  assert.equal(m.abandonne, true);
});

test("flux : un fichier inattendu est IGNORÉ mais SIGNALÉ, l'import reste possible", async () => {
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "discipline" }, new Map());
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  fichiers["surprise.txt"] = new TextEncoder().encode("contenu étranger");
  const m = puitsMemoire();
  const contenu = await lireMovpackFlux(fluxDe(zipSync(fichiers)), m.puits);
  assert.equal(contenu.avertissements.length, 1);
  assert.ok(contenu.avertissements[0]!.includes("surprise.txt"));
});

test("flux : une image ABSENTE de l'inventaire est réellement évincée — jamais promue par la bibliothèque (D-271)", async () => {
  // L'attaque que « Fichier inattendu ignoré » prétendait couvrir : une image
  // rangée sous le nom d'une AUTRE (nom ≠ empreinte du contenu), absente de
  // l'inventaire du manifeste — donc jamais confrontée à `exigerNomFidele` —
  // mais référencée par bibliotheque.json, que `reunirImages` promouvait.
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "discipline" }, new Map());
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  const fauxOctets = new TextEncoder().encode("des octets qui ne sont pas ceux du nom");
  const idVise = sha256Hex(new TextEncoder().encode("le contenu légitime de l'image visée"));
  const bib = JSON.parse(new TextDecoder().decode(fichiers["bibliotheque.json"]!));
  bib.images = [{ id: idVise, mime: "image/webp", taille: fauxOctets.length }];
  fichiers["bibliotheque.json"] = new TextEncoder().encode(JSON.stringify(bib));
  fichiers[`images/${idVise}`] = fauxOctets; // volontairement HORS inventaire
  const manifeste = JSON.parse(new TextDecoder().decode(fichiers["manifeste.json"]!));
  for (const f of manifeste.fichiers) {
    if (f.chemin !== "bibliotheque.json") continue;
    f.taille = fichiers["bibliotheque.json"]!.length;
    f.sha256 = sha256Hex(fichiers["bibliotheque.json"]!);
  }
  fichiers["manifeste.json"] = new TextEncoder().encode(JSON.stringify(manifeste));
  const m = puitsMemoire();
  const contenu = await lireMovpackFlux(fluxDe(zipSync(fichiers)), m.puits);
  assert.equal(
    contenu.images.find((i) => i.id === idVise),
    undefined,
    "des octets jamais confrontés à leur nom ne sont pas promus (D-271)",
  );
  assert.ok(contenu.avertissements.some((a) => a.includes(`images/${idVise}`)), "et l'éviction est signalée");
});

test("flux : un conteneur qui SE DIT v3 ne fait pas promouvoir ses images sans contrôle (D-263)", async () => {
  // Le même contournement que ci-dessus, par la branche de repli : v3 n'a pas
  // d'inventaire, donc aucune entrée ne rencontre `exigerNomFidele` — un
  // conteneur hostile choisirait la version FAIBLE pour ranger une image sous
  // le nom d'une autre. Le lecteur non-flux ne collecte jamais d'images en
  // v3 : même parité exigée ici.
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "discipline" }, new Map());
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  const fauxOctets = new TextEncoder().encode("des octets qui ne sont pas ceux du nom");
  const idVise = sha256Hex(new TextEncoder().encode("le contenu légitime de l'image visée"));
  const bib = JSON.parse(new TextDecoder().decode(fichiers["bibliotheque.json"]!));
  bib.images = [{ id: idVise, mime: "image/webp", taille: fauxOctets.length }];
  fichiers["bibliotheque.json"] = new TextEncoder().encode(JSON.stringify(bib));
  fichiers[`images/${idVise}`] = fauxOctets;
  const m3 = JSON.parse(new TextDecoder().decode(fichiers["manifeste.json"]!));
  delete m3.fichiers;
  delete m3.inclusions;
  delete m3.algorithme;
  m3.version = 3;
  m3.empreinte = sha256Hex(fichiers["bibliotheque.json"]!);
  fichiers["manifeste.json"] = new TextEncoder().encode(JSON.stringify(m3));
  const m = puitsMemoire();
  const contenu = await lireMovpackFlux(fluxDe(zipSync(fichiers)), m.puits);
  assert.equal(
    contenu.images.find((i) => i.id === idVise),
    undefined,
    "la branche de repli n'offre pas la rigueur au choix du conteneur (D-263)",
  );
  assert.ok(contenu.avertissements.some((a) => a.includes(`images/${idVise}`)), "et l'éviction est signalée");
});

test("non-flux : un conteneur qui SE DIT v3 voit ses images évincées ET signalées (D-345)", async () => {
  // Pendant NON-FLUX du test ci-dessus. L'éviction était déjà acquise — cette
  // branche ne collecte aucune image — mais elle se taisait, quand le lecteur
  // flux avertissait par fichier évincé. La parité tenait donc sur l'invariant
  // et pas sur ce que l'utilisateur voit : le même conteneur donnait deux
  // informations différentes selon le chemin de lecture (verdict checker).
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "discipline" }, new Map());
  const { unzipSync, zipSync } = await import("fflate");
  const fichiers = unzipSync(octets);
  const fauxOctets = new TextEncoder().encode("des octets qui ne sont pas ceux du nom");
  const idVise = sha256Hex(new TextEncoder().encode("le contenu légitime de l'image visée"));
  const bib = JSON.parse(new TextDecoder().decode(fichiers["bibliotheque.json"]!));
  bib.images = [{ id: idVise, mime: "image/webp", taille: fauxOctets.length }];
  fichiers["bibliotheque.json"] = new TextEncoder().encode(JSON.stringify(bib));
  fichiers[`images/${idVise}`] = fauxOctets;
  const m3 = JSON.parse(new TextDecoder().decode(fichiers["manifeste.json"]!));
  delete m3.fichiers;
  delete m3.inclusions;
  delete m3.algorithme;
  m3.version = 3;
  m3.empreinte = sha256Hex(fichiers["bibliotheque.json"]!);
  fichiers["manifeste.json"] = new TextEncoder().encode(JSON.stringify(m3));
  const relu = await lireMovpack(zipSync(fichiers));
  assert.equal(
    relu.images.find((i) => i.id === idVise),
    undefined,
    "la branche de repli n'offre pas la rigueur au choix du conteneur (D-263)",
  );
  assert.ok(
    relu.avertissements.some((a) => a.includes(`images/${idVise}`)),
    "et l'éviction est SIGNALÉE, comme sur le chemin flux",
  );
});

test("flux : un média vide reste une entrée valide (empreinte du vide)", async () => {
  const b = bibliotheque();
  const mediaId = genererUlid();
  b.contributions[0]!.medias.push({ id: mediaId, type: "local", ref: `videos/${mediaId}`, extension: "webm" });
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "complet" }, new Map([[mediaId, new Uint8Array(0)]]));
  const m = puitsMemoire();
  const contenu = await lireMovpackFlux(fluxDe(octets), m.puits);
  const media = contenu.medias.find((x) => x.id === mediaId)!;
  assert.equal(media.taille, 0);
  assert.equal(media.sha256, sha256Hex(new Uint8Array(0)), "empreinte du vide");
});

test("flux : un ZIP tronqué / illisible lève ErreurMovpack et abandonne le puits", async () => {
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "discipline" }, new Map());
  const tronque = octets.slice(0, Math.floor(octets.length / 2)); // archive coupée en deux
  const m = puitsMemoire();
  await assert.rejects(
    () => lireMovpackFlux(fluxDe(tronque), m.puits),
    (e: Error) => e instanceof ErreurMovpack,
  );
  assert.equal(m.abandonne, true);
});

test("D-127 — une composition jouable dans la discipline voyage AVEC son pack discipline (distribution)", () => {
  const b = bibliotheque(); // Judo + O-soto-gari (source « local »)
  const judo = b.disciplines[0]!;
  const t = b.techniques[0]!;
  // Une séance venue d'un AUTRE pack (source différente) mais qui n'enchaîne que
  // des techniques de CETTE discipline → doit être embarquée pour rester jouable.
  b.compositions.push(
    composition({
      nom: "Séance débutant",
      provenance: "enseignement",
      attribution: "taiso-12",
      origine: { pack: "taiso-12", element: "s0" },
      blocs: [{ id: genererUlid(), type: "technique", techniqueId: t.id, medias: [] }],
    }),
  );
  const { extrait } = extrairePackDiscipline(b, judo.id, new Set(["local"]));
  assert.ok(
    extrait.compositions.some((c) => c.nom === "Séance débutant"),
    "la séance jouable dans la discipline est embarquée même si sa source diffère",
  );
  // Mais une séance qui référence une technique HORS périmètre n'est PAS embarquée
  // (jouabilité garantie : jamais de référence pendante à l'import).
  b.compositions.push(
    composition({
      nom: "Séance mixte",
      provenance: "enseignement",
      attribution: "x",
      origine: { pack: "x", element: "s1" },
      blocs: [{ id: genererUlid(), type: "technique", techniqueId: "id-hors-perimetre", medias: [] }],
    }),
  );
  const { extrait: e2 } = extrairePackDiscipline(b, judo.id, new Set(["local"]));
  assert.ok(
    !e2.compositions.some((c) => c.nom === "Séance mixte"),
    "une séance à référence pendante n'est pas embarquée",
  );
});

test("D-127 — export/partage d'une composition : embarque ses techniques ET leurs disciplines, jamais le carnet", () => {
  const b = bibliotheque(); // Judo + O-soto-gari (+ sa contribution)
  const t = b.techniques[0]!;
  const seance = composition({
    nom: "Ma séance",
    provenance: "personnel",
    blocs: [{ id: genererUlid(), type: "technique", techniqueId: t.id, medias: [] }],
  });
  b.compositions.push(seance);
  const extrait = extrairePackComposition(b, seance.id);
  assert.equal(extrait.compositions.length, 1, "la composition part");
  assert.equal(extrait.techniques.length, 1, "la technique enchaînée est embarquée (jouable à l'import)");
  assert.equal(extrait.techniques[0]!.id, t.id);
  assert.equal(extrait.disciplines.length, 1, "sa discipline aussi");
  assert.equal(extrait.contributions.length, 0, "le carnet ne voyage jamais avec une composition");
});

test("D-127 — opt-in : une séance PERSONNELLE jouable n'est embarquée avec la discipline que sur demande", () => {
  const b = bibliotheque();
  const judo = b.disciplines[0]!;
  const t = b.techniques[0]!;
  b.compositions.push(
    composition({
      nom: "Ma séance perso",
      provenance: "personnel",
      blocs: [{ id: genererUlid(), type: "technique", techniqueId: t.id, medias: [] }],
    }),
  );
  // Par défaut : exclue (le carnet reste privé).
  const parDefaut = extrairePackDiscipline(b, judo.id, new Set(["local"]));
  assert.ok(!parDefaut.extrait.compositions.some((c) => c.nom === "Ma séance perso"), "perso exclue par défaut");
  // Opt-in explicite : incluse.
  const optIn = extrairePackDiscipline(b, judo.id, new Set(["local"]), undefined, { compositionsPersonnelles: true });
  assert.ok(optIn.extrait.compositions.some((c) => c.nom === "Ma séance perso"), "perso incluse sur opt-in");
});

/* ---- Reproductibilité du conteneur (D-338, constat D-325) ---- */

test("à entrées égales et date donnée, deux exports produisent les MÊMES octets", async () => {
  // C'est ce qui manquait à la publication : `creeLe` et l'horodatage des
  // entrées du zip étaient pris sur l'horloge, donc six conteneurs de 9 Mo
  // repartaient avec des octets neufs sans qu'une ligne de contenu ait bougé.
  const meta = { id: "essai", nom: "Essai", portee: "discipline" as const };
  const date = "2026-01-15T10:00:00.000Z";
  // La MÊME bibliothèque : le fixture tire des ULID neufs à chaque appel, donc
  // deux `bibliotheque()` ne sont pas les mêmes entrées.
  const b = bibliotheque();
  const un = await exporterMovpack(b, meta, new Map(), new Map(), date);
  const deux = await exporterMovpack(b, meta, new Map(), new Map(), date);
  assert.deepEqual([...un], [...deux], "le conteneur doit être une fonction de ses entrées");
});

test("la date fournie voyage jusqu'au manifeste, et deux dates donnent deux conteneurs", async () => {
  const meta = { id: "essai", nom: "Essai", portee: "discipline" as const };
  const b = bibliotheque();
  const tot = await exporterMovpack(b, meta, new Map(), new Map(), "2026-01-15T10:00:00.000Z");
  const tard = await exporterMovpack(b, meta, new Map(), new Map(), "2026-02-20T10:00:00.000Z");
  assert.equal((await lireMovpack(tot)).manifeste.creeLe, "2026-01-15T10:00:00.000Z");
  // Deux dates DOIVENT séparer les octets : sans quoi le test précédent
  // passerait aussi sur un conteneur qui ignore la date qu'on lui donne.
  assert.notDeepEqual([...tot], [...tard], "la date doit réellement entrer dans le conteneur");
});

/** Horodatage DOS de la PREMIÈRE entrée, lu dans l'en-tête local du zip
 *  (offset 10 : heure, offset 12 : date). Il ne vit pas dans les fichiers :
 *  en dézippant, on ne le voit pas — c'est précisément pour ça qu'il avait
 *  échappé à la première mesure. */
function horodatageEntree(zip: Uint8Array): number {
  const vue = new DataView(zip.buffer, zip.byteOffset, zip.byteLength);
  return (vue.getUint16(12, true) << 16) | vue.getUint16(10, true);
}

test("l'horodatage des ENTRÉES suit la date fournie, jamais l'horloge", async () => {
  // Sans cette épingle, remettre `mtime` sur l'horloge passait inaperçu : deux
  // exports lancés dans la même seconde tombent sur le même horodatage DOS
  // (résolution de 2 s). Un test qui ne peut pas échouer ne prouve rien.
  const b = bibliotheque();
  const meta = { id: "essai", nom: "Essai", portee: "discipline" as const };
  const janvier = await exporterMovpack(b, meta, new Map(), new Map(), "2026-01-15T10:00:00.000Z");
  const fevrier = await exporterMovpack(b, meta, new Map(), new Map(), "2026-02-20T10:00:00.000Z");
  assert.notEqual(horodatageEntree(janvier), horodatageEntree(fevrier), "l'en-tête du zip doit suivre `creeLe`");
  const rejoue = await exporterMovpack(b, meta, new Map(), new Map(), "2026-01-15T10:00:00.000Z");
  assert.equal(horodatageEntree(janvier), horodatageEntree(rejoue), "et rester stable à date égale");
});

test("sans date fournie, l'export garde l'instant présent — l'utilisateur vient de le fabriquer", async () => {
  const avant = Date.now();
  const octets = await exporterMovpack(bibliotheque(), { id: "x", nom: "X", portee: "discipline" }, new Map());
  const creeLe = Date.parse((await lireMovpack(octets)).manifeste.creeLe);
  assert.ok(creeLe >= avant - 1000 && creeLe <= Date.now() + 1000, "le défaut reste l'horloge");
});

/* --- Partage d'une fiche ou d'une composition ILLUSTRÉE (D-372) -------------
 * Constat porteur (2026-08-18, sur le build en ligne) : « le partage ne
 * fonctionne plus. Dans Bibliothèque, il me parle d'absence dans l'inventaire ;
 * dans Composition, rien ne se passe. »
 * Cause : les trois extracteurs construisaient un extrait SANS inventaire
 * d'images, alors que les couvertures qu'ils emportent le référencent. La
 * validation refuse — à raison. Depuis que les packs officiels sont illustrés
 * (114 techniques en judo), c'est le cas NORMAL, pas un cas limite. */

function bibliothequeIllustree() {
  const b = bibliotheque();
  const imageTech = { id: "a".repeat(64), mime: "image/webp", taille: 120 };
  const imageFamille = { id: "b".repeat(64), mime: "image/webp", taille: 90 };
  const horsPerimetre = { id: "c".repeat(64), mime: "image/webp", taille: 70 };
  b.images = [imageTech, imageFamille, horsPerimetre];
  b.techniques[0]!.couverture = { type: "fichier", imageId: imageTech.id };
  b.disciplines[0]!.familles[0]!.couverture = { type: "fichier", imageId: imageFamille.id };
  return { b, imageTech, imageFamille, horsPerimetre };
}

test("partage d'une fiche illustrée : l'extrait emporte l'inventaire de SES images", () => {
  const { b, imageTech, imageFamille, horsPerimetre } = bibliothequeIllustree();
  const { extrait } = extrairePackTechnique(b, b.techniques[0]!.id);
  const ids = (extrait.images ?? []).map((i) => i.id);
  assert.ok(ids.includes(imageTech.id), "la couverture de la fiche partagée voyage avec elle");
  assert.ok(ids.includes(imageFamille.id), "la couverture de la famille voyage : la discipline part entière");
  assert.ok(!ids.includes(horsPerimetre.id),
    "une image que rien du périmètre ne désigne ne part PAS — un pack n'emporte pas ce qu'on ne partage pas");
});

test("partage d'une composition illustrée : même règle, mêmes images", () => {
  const { b, imageTech, horsPerimetre } = bibliothequeIllustree();
  const compo = composition({ blocs: [{ id: genererUlid(), type: "technique", techniqueId: b.techniques[0]!.id, medias: [] }] });
  b.compositions.push(compo);
  const extrait = extrairePackComposition(b, compo.id);
  const ids = (extrait.images ?? []).map((i) => i.id);
  assert.ok(ids.includes(imageTech.id), "la technique enchaînée emporte sa couverture");
  assert.ok(!ids.includes(horsPerimetre.id), "rien d'autre ne part");
});

test("publication d'une discipline illustrée : l'inventaire suit le périmètre", () => {
  const { b, imageTech, imageFamille, horsPerimetre } = bibliothequeIllustree();
  const { extrait } = extrairePackDiscipline(b, b.disciplines[0]!.id, new Set(["local"]));
  const ids = (extrait.images ?? []).map((i) => i.id);
  assert.ok(ids.includes(imageTech.id) && ids.includes(imageFamille.id), "les couvertures du périmètre partent");
  assert.ok(!ids.includes(horsPerimetre.id), "celle que personne ne désigne reste");
});

test("une bibliothèque SANS image ne se met pas à déclarer un inventaire vide", () => {
  const b = bibliotheque();
  const { extrait } = extrairePackTechnique(b, b.techniques[0]!.id);
  assert.equal(extrait.images, undefined, "pas d'images → pas de champ, l'aller-retour reste identique");
});
