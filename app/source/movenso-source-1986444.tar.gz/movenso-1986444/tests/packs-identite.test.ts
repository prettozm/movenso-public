/**
 * IDENTITÉ DES PACKS PUBLIÉS (D-247) — garde de non-régression.
 *
 * L'app reconnaît un pack par l'id de son MANIFESTE. Si cet id change, une mise
 * à jour n'est plus reconnue comme telle : elle s'installe comme un pack neuf
 * et DUPLIQUE tout son contenu chez ceux qui l'avaient déjà. C'est arrivé deux
 * fois — au judo, puis au jujitsu — et à chaque fois en silence, parce que rien
 * ne comparait l'id produit à l'id publié.
 *
 * Ce test épingle les identités. Il échoue si :
 *  - l'ULID d'une discipline change dans `donnees/` (régénération de source) ;
 *  - un pack est ajouté sans que son identité soit inscrite ici ;
 *  - l'outil d'emballage repasse à une dérivation par nom de fichier.
 *
 * Une identité ne se change JAMAIS par accident. Modifier une valeur ci-dessous
 * est une décision : elle oblige les installations existantes à retirer la
 * discipline puis à réinstaller.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { idPackStable } from "../src/echange/extraction-pack.ts";
import type { Bibliotheque } from "../src/domaine/modele.ts";

/** Identités PUBLIÉES, relevées sur les conteneurs du site (D-247). */
const IDENTITES: Record<string, string> = {
  kodokan: "pack-01KX9CT5W7HQ9YVG00MA9M4C8G",
  jujitsu: "pack-01KY8EE8F8WKY718X9G1PB3TR6",
  "karate-shotokan": "pack-01KY8DX4EZBYNZE34J6DVXBW36",
  jjb: "pack-01KY8ERV8XKH7GSHEVEQ8KWCDX",
  taiso: "pack-01KY8F8AV3R8BW9MWRS74R13FE",
  // Le yoga n'avait pas de source versionnée jusqu'à S4.8 : il était donc le
  // seul pack publié dont l'identité n'était épinglée nulle part. Reconstruit
  // depuis le conteneur publié, il rejoint la garde — relevé sur le fichier en
  // ligne, pas recalculé depuis la source qu'on vient d'en tirer.
  yoga: "pack-01KYA0SRD09M7RBCQH1Q46K1J9",
};

const lire = (f: string) => JSON.parse(readFileSync(`donnees/${f}.json`, "utf8")) as Bibliotheque;

test("D-247 — l'identité d'un pack publié ne bouge pas", () => {
  for (const [fichier, attendu] of Object.entries(IDENTITES)) {
    const b = lire(fichier);
    assert.equal(b.disciplines.length, 1, `${fichier} : un pack de discipline en contient exactement une`);
    assert.equal(
      idPackStable(b.disciplines[0]!.id),
      attendu,
      `${fichier} : l'identité du conteneur a CHANGÉ — une mise à jour dupliquerait tout le contenu ` +
        `chez qui l'a déjà installé. Ne corriger ce test qu'en connaissance de cause.`,
    );
  }
});

test("D-247 — l'emballage dérive l'identité de la discipline, jamais du nom de fichier", () => {
  const outil = readFileSync("tools/publier.ts", "utf8");
  const code = outil.replace(/\/\*[\s\S]*?\*\/|\/\/.*$/gm, ""); // hors commentaires
  assert.match(code, /id:\s*idPackStable\(/, "l'emballage doit poser `idPackStable` comme identité");
  assert.doesNotMatch(
    code,
    /id:\s*[^,]*idDePack\(/,
    "`idDePack` dérive du NOM : l'employer comme identité casse la reconnaissance des mises à jour (D-247)",
  );
});

test("D-247 — chaque pack publié a son identité épinglée", () => {
  // La liste des packs est une DONNÉE depuis S4.9 : elle se lit, elle ne
  // s'extrait plus du code de l'outil à l'expression régulière.
  const packs: { source: string }[] = JSON.parse(readFileSync("publication/packs.json", "utf8"));
  assert.ok(packs.length > 0, "aucun pack dans la source de publication");
  for (const p of packs) {
    assert.ok(p.source in IDENTITES, `le pack « ${p.source} » est publié mais son identité n'est pas épinglée ici`);
  }
});

/**
 * DEUX MESURES QUI MENTAIENT, DEVENUES DES GARDES (verdict checker, D-347).
 *
 * D-312 annonce « zéro écart sur les 718 sous-titres » et D-318 annonce des
 * comptes d'illustrations — l'un et l'autre mesurés une fois, à la main, sans
 * rien laisser d'exécutable. Une mesure n'est pas une garde : la première
 * pouvait se défaire à la prochaine édition d'un pack, la seconde était
 * FAUSSE et a servi à écarter une demande du porteur.
 */
/** Les sources se DÉCOUVRENT, elles ne se recopient pas (D-351). La première
 *  version énumérait sept noms à la main — dans le fichier même dont le
 *  troisième test existe pour avoir cessé de le faire : un 8ᵉ pack serait entré
 *  dans `packs.json` et dans `IDENTITES`, et serait resté invisible de ces
 *  gardes. Un fichier de `donnees/` est une source s'il porte des techniques :
 *  les tables d'appoint (`rapprochements-judo.json`) n'en ont pas. */
const DONNEES = new URL("../donnees/", import.meta.url);
const lirePack = (s: string) => JSON.parse(readFileSync(new URL(`${s}.json`, DONNEES), "utf8"));
const SOURCES = readdirSync(DONNEES)
  .filter((f) => f.endsWith(".json"))
  .map((f) => f.slice(0, -5))
  .filter((s) => Array.isArray(lirePack(s).techniques) && lirePack(s).techniques.length > 0);

test("D-312 — tout sous-titre de pack commence par une capitale (garde, plus une mesure)", () => {
  const fautifs: string[] = [];
  let comptes = 0;
  for (const s of SOURCES) {
    for (const t of lirePack(s).techniques ?? []) {
      const st: string | undefined = t.nomTraditionnel;
      if (!st) continue;
      comptes++;
      // Une glose française commence par une capitale (D-312) ; les sous-titres
      // en écriture non latine (japonais, devanagari) n'ont pas de casse et ne
      // sont pas concernés — `toUpperCase` les laisse identiques à eux-mêmes.
      const p = st[0]!;
      if (p.toLowerCase() !== p.toUpperCase() && p !== p.toUpperCase()) fautifs.push(`${s} · ${t.nom} → « ${st} »`);
    }
  }
  // 760 sur les SEPT sources ; les 718 de D-312 sont les six packs PUBLIÉS,
  // club-judo en ajoute 42. Deux ensembles sous un seul nombre, c'est le défaut
  // même que ce lot corrige ailleurs (D-351). Le seuil suit les sources vues,
  // pour qu'un pack sorti de la liste rougisse au lieu de passer sous un plancher.
  assert.equal(SOURCES.length, 7, `sept sources portent des techniques (vues : ${SOURCES.length})`);
  assert.equal(comptes, 760, `760 sous-titres sur les sept sources — 718 pour les six packs publiés (vus : ${comptes})`);
  assert.deepEqual(fautifs, [], "un sous-titre en minuscule est revenu — D-312 les avait tous capitalisés");
});

test("D-318 — une illustration se mesure sur le pack PUBLIÉ, jamais sur sa source", () => {
  // Le piège, nommé : `donnees/*.json` ne porte AUCUNE couverture — elles sont
  // attachées par `poserIllustrations` au moment de publier. Mesurer les
  // vignettes sur la source revient donc à mesurer un pack sans images, et
  // c'est ce qui a produit « taïso 16 → 2 » et « karaté 14 → 8 » (D-318) là où
  // le pack installé donne 4 et 13. La garde fige l'invariant qui rend le
  // piège possible, pour que la prochaine mesure sache où regarder.
  for (const s of SOURCES) {
    const pack = lirePack(s);
    const tech = (pack.techniques ?? []).filter((t: { couverture?: unknown }) => t.couverture);
    assert.equal(tech.length, 0, `${s}.json : ${tech.length} technique(s) avec couverture — une source n'en porte pas, l'illustration est posée à la publication`);
    // Les FAMILLES aussi, et c'est même par elles que l'incident est passé :
    // D-306 embarquait 10 couvertures de familles, et le repli de
    // `vignetteTechnique` (propre → famille → miniature) les traverse. La
    // première version de cette garde ne filtrait que les techniques (D-351).
    const fam = (pack.disciplines ?? []).flatMap((d: { familles?: { couverture?: unknown }[] }) => d.familles ?? [])
      .filter((f: { couverture?: unknown }) => f.couverture);
    assert.equal(fam.length, 0, `${s}.json : ${fam.length} famille(s) avec couverture — même règle que les techniques`);
  }
});

test("D-312 — une glose partagée entre judo et jujitsu ne peut pas diverger en silence", () => {
  // D-312 invoque D-253 pour DÉRIVER les gloses de la table judo plutôt que de
  // les recopier. Le résultat au dépôt est pourtant une seconde copie physique,
  // et le script de dérivation n'est pas versionné : l'opération n'est pas
  // rejouable et les deux tables peuvent diverger sans que rien ne le dise
  // (verdict checker, D-348). Plutôt qu'un générateur qu'il faudrait ensuite
  // maintenir (D-324), on ferme le mode d'échec exact : la copie doit rester
  // identique à son original, sinon la garde le dit.
  const norm = (s: string) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const judo = new Map<string, string>(
    (lirePack("kodokan").techniques ?? [])
      .filter((t: { nomTraditionnel?: string }) => t.nomTraditionnel)
      .map((t: { nom: string; nomTraditionnel: string }) => [norm(t.nom), t.nomTraditionnel]),
  );
  const ecarts: string[] = [];
  let partagees = 0;
  for (const t of lirePack("jujitsu").techniques ?? []) {
    if (!t.nomTraditionnel) continue;
    const glose = judo.get(norm(t.nom));
    if (glose === undefined) continue;
    partagees++;
    if (glose !== t.nomTraditionnel) ecarts.push(`${t.nom} : judo « ${glose} » ≠ jujitsu « ${t.nomTraditionnel} »`);
  }
  assert.ok(partagees >= 70, `la garde doit voir les gloses partagées (vues : ${partagees})`);
  assert.deepEqual(ecarts, [], "une glose recopiée a dérivé de son original judo");
});
