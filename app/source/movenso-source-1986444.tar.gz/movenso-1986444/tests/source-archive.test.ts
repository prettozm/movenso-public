/**
 * GARDE DE LA SOURCE CORRESPONDANTE (D-353) — ce qui entre dans l'archive GPL.
 *
 * L'INCIDENT. L'archive de source était produite à chaque poussée sur chaque
 * branche, gardée 7 jours, et pesait 3,86 Mo alors que son propre en-tête
 * annonçait « quelques centaines de Ko ». Palier mesuré le 2026-08-17 :
 * **613 Mo pour un quota de 500 Mo**, dont 93 % pour ce seul artefact. Personne
 * ne suspectait ce poste, parce que la phrase qui le décrivait était fausse.
 *
 * Ce que cette garde tient, et qu'un commentaire ne tiendrait pas :
 *  - les exclusions ne se retirent pas par distraction ;
 *  - ce qui est nécessaire pour REBÂTIR le binaire ne sort pas de l'archive —
 *    c'est l'obligation GPLv3 §1, et c'est le vrai risque d'un allègement ;
 *  - chaque exclusion porte sa raison (leçon `outils/dependances.json` : une
 *    justification trop courte n'en est pas une).
 *
 * Elle s'applique à la liste RÉELLE des fichiers suivis, pas à une liste
 * fabriquée : une preuve obtenue sur un chemin inventé ne prouve rien du chemin
 * réel (D-231/D-251).
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { HORS_ARCHIVE, fichiersDeLArchive } from "../tools/hors-archive-source.mjs";
import { RAISON_MINIMALE } from "../outils/raison-minimale.mjs";

/** Les fichiers réellement suivis par git, tels que `source-du-build` les lit. */
const suivis: string[] = execFileSync("git", ["ls-files"], {
  encoding: "utf8",
  maxBuffer: 1 << 28,
}).trim().split("\n");

const archive = fichiersDeLArchive(suivis);

/**
 * Ce que la DÉCISION D-353 met hors archive, écrit ici en clair.
 *
 * Oui, c'est une seconde liste face à `HORS_ARCHIVE` — et c'est délibéré. Ma
 * première version bouclait sur `HORS_ARCHIVE` : retirer l'entrée `docs/` en
 * retirait aussi la vérification, et la garde restait **verte**. Mesuré, pas
 * supposé. Une garde qui ne lit que la liste qu'elle surveille ne garde rien ;
 * elle doit nommer ce qu'elle exige. La divergence entre les deux listes est
 * exactement ce que ce test détecte (D-253 : la duplication qu'on ne peut pas
 * supprimer se rattache par une garde exécutable).
 */
const EXIGÉS_HORS_ARCHIVE = ["donnees/images/", "docs/", "_provisoire-methode/"];

test("l'archive écarte la documentation, les maquettes et les images de packs", () => {
  for (const prefixe of EXIGÉS_HORS_ARCHIVE) {
    // Le dossier doit EXISTER dans le dépôt, sinon l'assertion suivante est
    // vraie sans rien démontrer — une exclusion devenue muette est un plafond
    // qui serait vert à jamais.
    assert.ok(
      suivis.some((f) => f.startsWith(prefixe)),
      `${prefixe} : plus aucun fichier suivi sous ce préfixe — l'exclusion ne garde plus rien, la retirer ou corriger le préfixe.`,
    );
    assert.deepEqual(
      archive.filter((f) => f.startsWith(prefixe)),
      [],
      `${prefixe} ne doit pas entrer dans l'archive de source (D-353).`,
    );
  }
});

test("la liste des exclusions et ce que la garde exige ne divergent pas", () => {
  assert.deepEqual(
    HORS_ARCHIVE.map(({ prefixe }) => prefixe).sort(),
    [...EXIGÉS_HORS_ARCHIVE].sort(),
    "`HORS_ARCHIVE` et EXIGÉS_HORS_ARCHIVE ne disent plus la même chose — "
      + "si l'écart est voulu, c'est une décision à inscrire au journal, pas un ajustement de test.",
  );
});

test("les entrées de build NOMMÉES ici restent dans l'archive (GPLv3 §1)", () => {
  // Le titre dit « nommées » et pas « tout ce qui permet de rebâtir », parce
  // que c'est ce que ce test mesure : une liste. Une exclusion ajoutée aux DEUX
  // listes de préfixes passerait sans un mot si sa cible n'est pas nommée
  // ci-dessous — c'est la limite de cette garde, et la revendiquer plus large
  // serait le défaut « promesse plus large que le code » (D-339, constat
  // checker ③ en D-354).
  //
  // Ce qui est vérifié : les entrées de build des DEUX binaires distribués —
  // le web et l'APK — plus la licence et les avis de tiers. `capacitor.config.json`
  // est là parce qu'`apk.yml` fait `npx cap add android` et qu'`android/` n'est
  // pas versionné ; `.nvmrc` parce que `REC-S1-001` en fait le dispositif de
  // reproductibilité.
  const indispensables = [
    "package.json",
    "package-lock.json",
    "tsconfig.json",
    "vite.config.ts",
    "index.html",
    "capacitor.config.json",
    ".nvmrc",
    "LICENSE",
    "THIRD_PARTY_NOTICES.md",
  ];
  for (const f of indispensables) {
    assert.ok(archive.includes(f), `${f} doit voyager avec le binaire (GPLv3).`);
  }
  // `donnees/` reste dans l'archive pour les SOURCES ÉDITORIALES des packs
  // (`donnees/<pack>.json`). Attention à ne pas en déduire plus : les
  // illustrations vivent sous `donnees/images/`, qui est hors archive depuis
  // D-265 — donc `npm run publier` sur l'archive extraite produit des packs
  // SANS images. Ce n'est pas le périmètre de la GPLv3, qui porte sur le
  // binaire, mais c'est exactement l'incident D-245 (le karaté perdant ses
  // 109 images) : ne pas écrire ici que les packs « se reproduisent » depuis
  // l'archive. Ils ne s'y reproduisent qu'en texte.
  for (const dossier of ["src/", "outils/", "tools/", "public/", "branding/", "donnees/"]) {
    assert.ok(
      archive.some((f) => f.startsWith(dossier)),
      `${dossier} doit rester dans l'archive : le binaire ne se rebâtit pas sans.`,
    );
  }
});

test("chaque exclusion porte une raison qui en est une", () => {
  for (const { prefixe, raison } of HORS_ARCHIVE) {
    assert.ok(prefixe.endsWith("/"), `${prefixe} : un préfixe de dossier se termine par « / ».`);
    // Le seuil est PARTAGÉ avec la garde des dépendances, il n'est pas recopié :
    // `outils/raison-minimale.mjs` en est le seul lieu d'écriture. D-353 avait
    // écrit 60 en citant l'autre garde comme autorité, D-354 les a fait
    // coïncider à 20 — deux littéraux que rien ne rattachait. Le checker l'a
    // relevé deux tours de suite ; c'est la troisième forme qui ferme (D-356).
    assert.ok(
      raison.trim().length >= RAISON_MINIMALE,
      `${prefixe} : la raison fait ${raison.trim().length} caractères — trop court pour dire pourquoi ce dossier est hors archive.`,
    );
  }
});
