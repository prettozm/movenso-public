/** D-328 — l'état VIERGE de la bibliothèque : rien n'a jamais été installé,
 *  créé, importé ni restauré. C'est le seul état qui donne droit à l'écran de
 *  première ouverture. */

import { test } from "node:test";
import assert from "node:assert/strict";
import { bibliothequeVide, type Bibliotheque } from "../src/domaine/modele.ts";
import { bibliothequeVierge } from "../src/domaine/vacuite.ts";

// La FORME des collections (« et si l'une n'était pas un tableau ? ») n'est PAS
// gardée ici : un test de ce fichier n'inspecte qu'une bibliothèque neuve, où
// les six collections optionnelles sont absentes par construction — il resterait
// donc vert sur le cas qui compte. La garde vit dans `vacuite.ts` et travaille au
// TYPE : `npm run typecheck` échoue en nommant le champ fautif (D-339).
import { bibliotheque, composition, disciplineJudo, technique } from "./aide.ts";

/** Une bibliothèque neuve, à laquelle on ajoute UNE collection non vide.
 *  Le prédicat ne regarde que la présence de contenu : le patch est donc
 *  volontairement structurel, pour couvrir toutes les collections sans
 *  fabriquer un objet métier par champ. */
const avec = (patch: Record<string, unknown[]>): Bibliotheque =>
  ({ ...bibliothequeVide(), ...patch }) as Bibliotheque;

test("vierge : une bibliothèque neuve l'est — les types de relation semés ne comptent pas", () => {
  const neuve = bibliothequeVide();
  assert.equal(neuve.typesRelation.length, 4, "quatre types sont semés par défaut");
  assert.equal(bibliothequeVierge(neuve), true);
});

test("vierge : un type de relation ajouté à la main ne fait pas un contenu", () => {
  const b = bibliothequeVide();
  b.typesRelation.push({ id: "prolonge", libelle: "Prolonge", symetrique: true });
  assert.equal(bibliothequeVierge(b), true);
});

test("PAS vierge : un pack installé (le mini-monde judo)", () => {
  assert.equal(bibliothequeVierge(bibliotheque()), false);
});

test("PAS vierge : une seule technique, sans rien d'autre", () => {
  const judo = disciplineJudo();
  assert.equal(bibliothequeVierge(avec({ disciplines: [judo], techniques: [technique(judo.id)] })), false);
});

test("PAS vierge : une composition seule — l'écran de départ ne doit pas revenir", () => {
  assert.equal(bibliothequeVierge(avec({ compositions: [composition()] })), false);
});

test("PAS vierge : chaque trace d'un contenu qui a existé compte", () => {
  // Corbeille, fusions, conflits, éditions de packs : tout cela raconte qu'un
  // contenu est passé par ici. Une bibliothèque qu'on a vidée n'est pas neuve.
  //
  // Deux sources, et la distinction n'est pas un détail : les collections
  // OBLIGATOIRES sont **dérivées** de la bibliothèque neuve (une collection
  // ajoutée demain entre ici d'elle-même, et `typesRelation` s'exclut sans
  // être nommé puisqu'il est semé) ; les collections OPTIONNELLES sont
  // absentes à la naissance, donc rien ne peut les dériver — elles restent
  // écrites. Dériver les deux aurait RÉTRÉCI la couverture de six collections
  // en silence, ce qui est pire que la liste qu'on voulait supprimer.
  const neuve = bibliothequeVide() as unknown as Record<string, unknown>;
  const obligatoires = Object.keys(neuve).filter((c) => Array.isArray(neuve[c]) && (neuve[c] as unknown[]).length === 0);
  const optionnelles = ["corbeille", "fusions", "conflitsLiaisons", "conflitsContributions", "typesAlerte", "editionsPacks"];
  for (const cle of [...obligatoires, ...optionnelles])
    assert.equal(bibliothequeVierge(avec({ [cle]: [{}] })), false, `« ${cle} » non vide doit rompre la virginité`);
  // CLIQUET de couverture (D-339, angle mort du checker) : un plancher `>= 12`
  // sur 13 collections tolérait exactement le recul qu'il devait interdire.
  // Le compte est EXACT — il monte quand une collection naît, ce qui est un
  // geste délibéré, et ne descend jamais par distraction.
  assert.equal(obligatoires.length + optionnelles.length, 13,
    "le nombre de collections a bougé : le faire monter est une décision, le laisser descendre est une perte de couverture");
});

test("vierge : les collections optionnelles ABSENTES ne changent rien", () => {
  const { images, doublonsIgnores, ...sansOptionnelles } = bibliothequeVide();
  void images;
  void doublonsIgnores;
  assert.equal(bibliothequeVierge(sansOptionnelles as Bibliotheque), true);
});
