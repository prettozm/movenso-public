/**
 * S4.2/D-263 — un conteneur ne choisit pas la rigueur qu'on lui applique.
 *
 * Le repli « empreinte globale » était sélectionné sur le seul fait que
 * `fichiers` soit absent, SANS regarder la version déclarée. Un conteneur
 * annonçant `version: 4` pouvait donc omettre son inventaire et retomber en
 * silence sur le contrôle le plus faible : le `bibliotheque.json` restait
 * couvert par l'empreinte globale, mais **les médias voyageaient sans aucune
 * empreinte**, et aucun avertissement ne le disait.
 *
 * Les deux lecteurs sont couverts — celui en mémoire ET celui en flux, qui
 * est le chemin d'import réel de l'application.
 */

import test from "node:test";
import assert from "node:assert/strict";
import { unzipSync, zipSync } from "fflate";
import { exporterMovpack, lireMovpack } from "../src/echange/movpack.ts";
import { ErreurMovpack, VERSION_MOVPACK } from "../src/echange/movpack-contrat.ts";
import { sha256Hex } from "../src/domaine/sha256.ts";
import { bibliotheque } from "./aide.ts";

const BIB = new TextEncoder().encode(JSON.stringify(bibliotheque()));
const MEDIA = new TextEncoder().encode("contenu de media");
const CHEMIN_MEDIA = "medias/01JZZZZZZZZZZZZZZZZZZZZZZZ.mp4";

function manifesteBase(surcharge: Record<string, unknown> = {}) {
  return {
    format: "movpack", version: VERSION_MOVPACK, id: "pack-essai", nom: "Essai",
    portee: "discipline", creeLe: new Date("2026-08-09T10:00:00Z").toISOString(),
    versionSchema: 4, versionEditoriale: 1, auteur: "essai",
    empreinte: sha256Hex(BIB), videos: [], algorithme: "SHA-256",
    ...surcharge,
  };
}

function conteneur(manifeste: Record<string, unknown>, avecMedia = true) {
  const entrees: Record<string, Uint8Array> = {
    "manifeste.json": new TextEncoder().encode(JSON.stringify(manifeste)),
    "bibliotheque.json": BIB,
  };
  if (avecMedia) entrees[CHEMIN_MEDIA] = MEDIA;
  return zipSync(entrees);
}

const inventaireComplet = () => [
  { chemin: "bibliotheque.json", taille: BIB.length, sha256: sha256Hex(BIB) },
  { chemin: CHEMIN_MEDIA, taille: MEDIA.length, sha256: sha256Hex(MEDIA) },
];

test("v4 sans inventaire : REFUSÉ (plus de repli silencieux vers le contrôle v3)", async () => {
  // Exactement le conteneur qui était accepté avant D-263 : v4 déclaré,
  // `fichiers` absent, média retenu sans qu'aucune empreinte le couvre.
  await assert.rejects(
    () => lireMovpack(conteneur(manifesteBase())),
    (e: Error) => {
      assert.ok(e instanceof ErreurMovpack, "un refus de conteneur, pas une erreur technique");
      assert.match(e.message, /v4 incomplet|inventaire/i, "le refus dit ce qui manque");
      return true;
    },
  );
});

test("v4 avec un inventaire complet : accepté, et le média est vérifié", async () => {
  const lu = await lireMovpack(conteneur(manifesteBase({ fichiers: inventaireComplet() })));
  assert.equal(lu.manifeste.version, VERSION_MOVPACK, "le manifeste est relu tel qu'écrit");
  assert.equal(lu.videos.size, 1, "le média déclaré et vérifié est retenu");
});

test("v4 : une entrée d'inventaire mal formée est refusée avant toute lecture", async () => {
  const cas: [string, unknown][] = [
    ["entrée non-objet", ["bibliotheque.json"]],
    ["chemin manquant", [{ taille: 1, sha256: "a".repeat(64) }]],
    ["taille négative", [{ chemin: "bibliotheque.json", taille: -1, sha256: "a".repeat(64) }]],
    ["empreinte tronquée", [{ chemin: "bibliotheque.json", taille: BIB.length, sha256: "abc" }]],
  ];
  for (const [quoi, fichiers] of cas) {
    await assert.rejects(
      () => lireMovpack(conteneur(manifesteBase({ fichiers }))),
      ErreurMovpack,
      `${quoi} doit être refusé`,
    );
  }
});

test("v4 : un algorithme d'intégrité inconnu est refusé, jamais supposé", async () => {
  await assert.rejects(
    () => lireMovpack(conteneur(manifesteBase({ fichiers: inventaireComplet(), algorithme: "MD5" }))),
    (e: Error) => {
      assert.match(e.message, /algorithme/i, "le refus nomme l'algorithme");
      return true;
    },
  );
});

test("v3 reste lisible : le repli n'est pas supprimé, il est RÉSERVÉ", async () => {
  const lu = await lireMovpack(conteneur(manifesteBase({ version: 3, algorithme: undefined }), false));
  assert.equal(lu.manifeste.version, 3, "un vrai v3 continue de s'importer");
});

test("v3 : une empreinte globale mal formée est refusée (elle est le seul contrôle)", async () => {
  await assert.rejects(
    () => lireMovpack(conteneur(manifesteBase({ version: 3, empreinte: "trop-court" }), false)),
    ErreurMovpack,
  );
});

test("v3 qui apporte un inventaire : honoré plutôt que puni", async () => {
  const lu = await lireMovpack(conteneur(manifesteBase({ version: 3, fichiers: inventaireComplet() })));
  assert.equal(lu.videos.size, 1, "un conteneur qui en dit plus est vérifié davantage");
});

/* ---------- D-271 — ce qu'un conteneur hostile pouvait encore faire ----------
 *
 * Audit porteur du 2026-08-10. Trois trous, tous ouverts APRÈS D-263 :
 * le nom d'une image ne prouvait rien, le manifeste était casté plutôt que
 * validé, et les images s'accumulaient en mémoire sans borne propre.
 */

/** Un conteneur v5 portant UNE image, avec la liberté de mentir sur son nom. */
async function conteneurImage(octets: Uint8Array, nomAnnonce: string) {
  const b = bibliotheque();
  b.images = [{ id: nomAnnonce, mime: "image/jpeg", taille: octets.length }];
  b.techniques[0]!.couverture = { type: "fichier", imageId: nomAnnonce };
  const brut = await exporterMovpack(
    b, { id: "essai", nom: "Essai", portee: "discipline" }, new Map(), new Map([[nomAnnonce, octets]]),
  );
  const arch = unzipSync(brut);
  // Le manifeste dit la VÉRITÉ sur ce qu'il transporte : c'est le nom qui ment.
  const m = JSON.parse(new TextDecoder().decode(arch["manifeste.json"]!));
  for (const f of m.fichiers) if (f.chemin.startsWith("images/")) f.sha256 = sha256Hex(octets);
  arch["manifeste.json"] = new TextEncoder().encode(JSON.stringify(m));
  return zipSync(arch);
}

test("v5 : le NOM d'une image est son contenu — un fichier rangé sous le nom d'un autre est refusé", async () => {
  const vrais = new Uint8Array([0xff, 0xd8, 0xff, 0xd9]);
  const autres = new Uint8Array([0x00, 0x01, 0x02, 0x03, 0x04]);

  // Le nom annonce l'empreinte de `vrais`, le fichier contient `autres`. Le
  // manifeste, lui, est honnête — donc le contrôle d'intégrité passe. Sans
  // l'invariant du nom, ces octets iraient s'écrire sous le nom d'une
  // illustration légitime, et l'écriture étant idempotente, la vraie image ne
  // serait plus JAMAIS posée.
  const falsifie = await conteneurImage(autres, sha256Hex(vrais));
  await assert.rejects(() => lireMovpack(falsifie), /Image falsifiée/);

  // Contrepartie : le même conteneur, honnête, passe.
  const fidele = await conteneurImage(autres, sha256Hex(autres));
  const lu = await lireMovpack(fidele);
  assert.equal(lu.images.length, 1);
  assert.equal(sha256Hex(lu.images[0]!.octets), lu.images[0]!.id, "le nom relu correspond bien au contenu");
});

test("le manifeste est VALIDÉ, pas casté — la portée décide d'écraser la bibliothèque", async () => {
  const sain = await exporterMovpack(bibliotheque(), { id: "essai", nom: "Essai", portee: "discipline" }, new Map());
  const avec = async (patch: Record<string, unknown>) => {
    const arch = unzipSync(sain);
    const m = { ...JSON.parse(new TextDecoder().decode(arch["manifeste.json"]!)), ...patch };
    for (const [k, v] of Object.entries(patch)) if (v === undefined) delete m[k];
    arch["manifeste.json"] = new TextEncoder().encode(JSON.stringify(m));
    return zipSync(arch);
  };

  // `portee` route entre « importer un pack » et « REMPLACER la bibliothèque ».
  await assert.rejects(lireMovpack(await avec({ portee: { danger: true } })), /portée/);
  await assert.rejects(lireMovpack(await avec({ portee: "totale" })), /portée/);
  // `id` est la clé d'idempotence : un id numérique ferait voir une mise à
  // jour comme une installation neuve, donc dupliquerait tout le contenu.
  await assert.rejects(lireMovpack(await avec({ id: 42 })), /identité/);
  await assert.rejects(lireMovpack(await avec({ nom: undefined })), /nom/);
  await assert.rejects(lireMovpack(await avec({ creeLe: [] })), /date/);
  await assert.rejects(lireMovpack(await avec({ versionSchema: "6" })), /schéma/);
  await assert.rejects(lireMovpack(await avec({ videos: "aucune" })), /videos/);
  await assert.rejects(lireMovpack(await avec({ versionEditoriale: 0 })), /éditoriale/);
  await assert.rejects(lireMovpack(await avec({ inclusions: { medias: "oui" } })), /inclusions/);

  // Contrepartie : le manifeste que notre propre chaîne produit reste lisible.
  const lu = await lireMovpack(sain);
  assert.equal(lu.manifeste.portee, "discipline");
});
