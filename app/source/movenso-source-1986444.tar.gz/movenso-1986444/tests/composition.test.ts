/** Compositions (D-020.1) : validation, référencement, migration 1 → 2, import. */

import { test } from "node:test";
import assert from "node:assert/strict";
import { acteurDuBloc, acteurSuivantPropose, annonceCue, compositionsUtilisant, decouperEnTemps, deplacerBloc, dureeEnMots, estLie, lectureEnTemps, normaliserTemps, nouveauBloc, reordonnerBloc, repartirTemps, retirerBloc, techniquesAPortee, estJalon, nombreDePas, texteJalon } from "../src/domaine/composition.ts";
import { migrerBibliotheque } from "../src/domaine/migrations.ts";
import { importerDansBibliotheque } from "../src/domaine/rapprochement.ts";
import { validerBibliotheque, ErreurValidation } from "../src/domaine/validation.ts";
import { genererUlid } from "../src/domaine/ulid.ts";
import type { Composition } from "../src/domaine/modele.ts";
import { VERSION_SCHEMA } from "../src/domaine/modele.ts";
import { bibliotheque, composition, contribution, disciplineJudo, technique } from "./aide.ts";

test("une composition valide référence des identités et porte des blocs libres", () => {
  const b = bibliotheque();
  const t = b.techniques[0]!;
  const compo = composition({
    blocs: [
      nouveauBloc("technique", { techniqueId: t.id }),
      nouveauBloc("transition", { texte: "pivot épaule gauche" }),
      nouveauBloc("technique", { techniqueId: genererUlid() }), // identité absente : tolérée
    ],
  });
  b.compositions.push(compo);
  validerBibliotheque(b); // ne lève pas
  assert.deepEqual(compositionsUtilisant(b, t.id).map((c) => c.id), [compo.id]);
});

test("un bloc non-technique sans texte ni média est rejeté ; un bloc technique sans référence aussi", () => {
  const b = bibliotheque();
  b.compositions.push(composition({ blocs: [nouveauBloc("transition")] }));
  assert.throws(() => validerBibliotheque(b), ErreurValidation);
  b.compositions = [composition({ blocs: [{ id: genererUlid(), type: "technique", medias: [] }] })];
  assert.throws(() => validerBibliotheque(b), ErreurValidation);
});

test("D-124 — champs additifs : consigne sur un bloc, durée sur un segment, présentation au niveau composition", () => {
  const b = bibliotheque();
  const t = b.techniques[0]!;
  const compo = composition({
    presentation: { medias: [{ id: genererUlid(), type: "lien", ref: "https://exemple.test/demo" }] },
    blocs: [
      nouveauBloc("technique", { techniqueId: t.id, consigne: "gauche puis droite" }),
      nouveauBloc("etape", { texte: "échauffement", dureeSec: 300 }),
      nouveauBloc("etape", { dureeSec: 120 }), // une durée seule suffit à porter le bloc
    ],
  });
  b.compositions.push(compo);
  validerBibliotheque(b); // ne lève pas
  assert.equal(compo.blocs[0]!.consigne, "gauche puis droite");
  assert.equal(compo.blocs[1]!.dureeSec, 300);
  assert.equal(compo.blocs[2]!.dureeSec, 120);
  assert.equal(compo.presentation!.medias.length, 1);
});

test("D-124 — une durée négative ou non finie est rejetée", () => {
  for (const mauvaise of [-1, Number.NaN, Number.POSITIVE_INFINITY]) {
    const b = bibliotheque();
    b.compositions.push(composition({ blocs: [nouveauBloc("etape", { texte: "x", dureeSec: mauvaise })] }));
    assert.throws(() => validerBibliotheque(b), /durée/, `dureeSec ${mauvaise} doit être rejetée`);
  }
});

test("D-125 — un bloc pause (repos minuté) est valide avec sa seule durée", () => {
  const b = bibliotheque();
  b.compositions.push(composition({ blocs: [nouveauBloc("pause", { dureeSec: 30 })] }));
  validerBibliotheque(b); // ne lève pas : la durée seule porte la pause
  b.compositions = [composition({ blocs: [nouveauBloc("pause")] })]; // pause sans durée : rejetée
  assert.throws(() => validerBibliotheque(b), ErreurValidation);
});

test("D-125 — dureeEnMots : secondes, minutes, minutes+secondes", () => {
  assert.equal(dureeEnMots(30), "30 secondes");
  assert.equal(dureeEnMots(1), "1 seconde");
  assert.equal(dureeEnMots(60), "1 minute");
  assert.equal(dureeEnMots(300), "5 minutes");
  assert.equal(dureeEnMots(90), "1 minute 30");
});

test("D-125 — annonceCue : mi-temps, 30 s, 10 s selon la durée initiale", () => {
  assert.equal(annonceCue(300, 150), "mi-temps"); // moitié d'un segment ≥ 60 s
  assert.equal(annonceCue(300, 30), "30 secondes");
  assert.equal(annonceCue(300, 10), "10 secondes");
  assert.equal(annonceCue(42, 30), "30 secondes"); // > 40 s
  assert.equal(annonceCue(300, 42), null); // pas un jalon
  assert.equal(annonceCue(20, 10), "10 secondes"); // > 12 s : le décompte des 10 dernières a du sens
  assert.equal(annonceCue(12, 10), null); // ≤ 12 s : pas de « 10 secondes » qui doublerait l'entrée
  assert.equal(annonceCue(40, 30), null); // 30 s seulement si > 40 s
  assert.equal(annonceCue(30, 15), null); // < 60 s : pas de mi-temps
});

test("D-124 — une composition héritée sans aucun champ additif reste valide (purement additif)", () => {
  const b = bibliotheque();
  const t = b.techniques[0]!;
  b.compositions.push(
    composition({
      blocs: [
        { id: genererUlid(), type: "technique", techniqueId: t.id, medias: [] },
        { id: genererUlid(), type: "consigne", texte: "kuzushi", medias: [] },
      ],
    }),
  );
  validerBibliotheque(b); // ne lève pas : les anciennes données valident inchangées
});

test("une composition sourcée exige une attribution (même règle que les contributions)", () => {
  const b = bibliotheque();
  b.compositions.push(composition({ provenance: "referentiel" }));
  assert.throws(() => validerBibliotheque(b), /attribution/);
  b.compositions = [composition({ provenance: "referentiel", attribution: "Kodokan" })];
  validerBibliotheque(b);
});

test("réordonner : deplacerBloc déplace d'un cran et ignore les bords", () => {
  const compo = composition({
    blocs: [nouveauBloc("etape", { texte: "a" }), nouveauBloc("etape", { texte: "b" }), nouveauBloc("etape", { texte: "c" })],
  });
  const [a, bB, c] = compo.blocs.map((x) => x.id);
  deplacerBloc(compo, c!, -1);
  assert.deepEqual(compo.blocs.map((x) => x.id), [a, c, bB]);
  deplacerBloc(compo, a!, -1); // bord : sans effet
  assert.deepEqual(compo.blocs.map((x) => x.id), [a, c, bB]);
});

test("migration depuis le schéma 1 : types de relation semés (avec rôles), compositions vides, favoris vides, données conservées", () => {
  const avant = bibliotheque() as unknown as Record<string, unknown>;
  avant["versionSchema"] = 1;
  delete avant["typesRelation"];
  delete avant["compositions"];
  delete avant["favoris"];
  const apres = migrerBibliotheque(avant);
  validerBibliotheque(apres);
  // La chaîne mène à la version COURANTE, quelle qu'elle soit : recopier « 4 »
  // ici faisait de ce test une seconde source de vérité, à corriger à chaque
  // migration (elle a rougi au passage en schéma 5 — D-253).
  assert.equal(apres.versionSchema, VERSION_SCHEMA);
  assert.deepEqual(apres.typesRelation.map((t) => t.id), ["prepare", "enchaine", "contre", "similaire"]);
  // D-140 : les rôles sémantiques sont présents dès la migration (semés en v2, rétro-appliqués en v4).
  assert.deepEqual(apres.typesRelation.map((t) => t.role), ["before", "after", "opposition", "peer"]);
  assert.deepEqual(apres.compositions, []);
  assert.deepEqual(apres.favoris, []); // lot 5 §4
  assert.equal(apres.techniques.length, 1); // rien perdu
});

test("migration 3 → 4 (D-140) : les rôles absents des types par défaut déjà persistés sont rétro-appliqués", () => {
  const avant = bibliotheque() as unknown as Record<string, unknown>;
  avant["versionSchema"] = 3;
  // Simule une bibliothèque d'avant D-136 : types par défaut SANS rôle + un type
  // éditorial dont le rôle a été choisi explicitement (à ne pas écraser).
  avant["typesRelation"] = [
    { id: "prepare", libelle: "Prépare", libelleInverse: "Préparée par" },
    { id: "enchaine", libelle: "Enchaîne vers", libelleInverse: "Enchaînée depuis" },
    { id: "contre", libelle: "Contre", libelleInverse: "Contrée par" },
    { id: "similaire", libelle: "Similaire à", symetrique: true },
    { id: "kata", libelle: "Fait partie de", libelleInverse: "Contient", role: "context" },
  ];
  const apres = migrerBibliotheque(avant);
  const parId = new Map(apres.typesRelation.map((t) => [t.id, t]));
  assert.equal(parId.get("prepare")?.role, "before");
  assert.equal(parId.get("enchaine")?.role, "after");
  assert.equal(parId.get("contre")?.role, "opposition");
  assert.equal(parId.get("similaire")?.role, "peer");
  assert.equal(parId.get("kata")?.role, "context"); // choix éditorial préservé
});

test("import (D-067) : les blocs technique d'une composition de pack pointent l'identité DU PACK, jamais fusionnée, réimport idempotent", () => {
  const b = bibliotheque();
  const identite = b.techniques[0]!; // O-soto-gari existant (local)
  const packJudo = disciplineJudo({ nom: "Judo" });
  const tPack = technique(packJudo.id, { nom: "O-soto-gari", familleId: undefined as never, niveauxIds: [] });
  delete (tPack as { familleId?: string }).familleId;
  const pack = bibliotheque({
    disciplines: [packJudo],
    techniques: [tPack],
    contributions: [contribution(tPack.id, { provenance: "enseignement", attribution: "Club" })],
    compositions: [
      composition({
        nom: "Nage-no-kata — 1er groupe",
        provenance: "enseignement",
        blocs: [nouveauBloc("technique", { techniqueId: tPack.id }), nouveauBloc("consigne", { texte: "kuzushi avant tout" })],
      }),
    ],
  });
  const un = importerDansBibliotheque(b, pack, { packId: "club" });
  // D-067 : le pack crée SA propre identité, distincte de l'existante.
  const nouvelle = un.bibliotheque.techniques.find((t) => t.nom === "O-soto-gari" && t.origine?.pack === "club")!;
  assert.ok(nouvelle && nouvelle.id !== identite.id, "aucune fusion : l'identité du pack est distincte");
  const compo = un.bibliotheque.compositions[0]!;
  assert.equal(compo.blocs[0]!.techniqueId, nouvelle.id, "le bloc pointe l'identité du pack"); // réécrit vers l'identité du pack
  assert.equal(compo.origine?.pack, "club");
  const deux = importerDansBibliotheque(un.bibliotheque, pack, { packId: "club" });
  assert.equal(deux.bibliotheque.compositions.length, 1); // idempotent
  assert.equal(deux.bibliotheque.compositions[0]!.id, compo.id); // id conservé
});

test("import : un type de relation inconnu du pack est ajouté avec son origine, l'existant fait foi", () => {
  const b = bibliotheque();
  const packJudo = disciplineJudo({ nom: "Judo" });
  const pack = bibliotheque({
    typesRelation: [
      { id: "prepare", libelle: "Ouvre sur", libelleInverse: "Ouverte par" }, // conflit : l'existant gagne
      { id: "defend", libelle: "Défend contre", libelleInverse: "Défendue par" },
    ],
    disciplines: [packJudo],
    techniques: [],
    contributions: [],
  });
  const { bibliotheque: apres } = importerDansBibliotheque(b, pack, { packId: "club" });
  assert.equal(apres.typesRelation.find((t) => t.id === "prepare")!.libelle, "Prépare");
  const defend = apres.typesRelation.find((t) => t.id === "defend")!;
  assert.equal(defend.libelle, "Défend contre");
  assert.equal(defend.origine?.pack, "club");
});

test("import multi-disciplines (D-067) : une composition qui traverse les disciplines crée ses propres identités, distinctes", () => {
  const b = bibliotheque(); // Judo avec O-soto-gari
  const identiteJudo = b.techniques[0]!;
  const judoPack = disciplineJudo({ nom: "Judo", familles: [], niveaux: [] });
  const boxe = disciplineJudo({ nom: "Boxe", familles: [], niveaux: [] });
  const tJudo = technique(judoPack.id, { nom: "O-soto-gari", niveauxIds: [] });
  delete (tJudo as { familleId?: string }).familleId;
  const tBoxe = technique(boxe.id, { nom: "Crochet gauche", niveauxIds: [] });
  delete (tBoxe as { familleId?: string }).familleId;
  const pack = bibliotheque({
    disciplines: [judoPack, boxe],
    techniques: [tJudo, tBoxe],
    contributions: [],
    compositions: [
      composition({
        nom: "Ma spéciale",
        blocs: [nouveauBloc("technique", { techniqueId: tJudo.id }), nouveauBloc("technique", { techniqueId: tBoxe.id })],
      }),
    ],
  });
  const { bibliotheque: apres, rapport } = importerDansBibliotheque(b, pack, { packId: "ma-speciale" });
  assert.equal(apres.disciplines.length, 2, "la Boxe est créée, le Judo rejoint par nom");
  const compo = apres.compositions[0]!;
  // D-067 : aucune fusion — le pack crée sa propre identité judo, distincte.
  const nouvelleJudo = apres.techniques.find((t) => t.nom === "O-soto-gari" && t.origine?.pack === "ma-speciale")!;
  assert.ok(nouvelleJudo.id !== identiteJudo.id, "l'identité judo du pack est distincte (D-067)");
  assert.equal(compo.blocs[0]!.techniqueId, nouvelleJudo.id, "le bloc judo pointe l'identité du pack");
  const crochet = apres.techniques.find((t) => t.nom === "Crochet gauche")!;
  assert.equal(compo.blocs[1]!.techniqueId, crochet.id, "le bloc boxe pointe l'identité créée");
  assert.deepEqual(rapport.rejointes, [], "aucune fusion automatique (D-067)");
  assert.ok(rapport.creees.includes("O-soto-gari") && rapport.creees.includes("Crochet gauche"));
  // réimport idempotent, toutes disciplines confondues
  const encore = importerDansBibliotheque(apres, pack, { packId: "ma-speciale" });
  assert.equal(encore.bibliotheque.compositions.length, 1);
  assert.equal(encore.bibliotheque.techniques.length, apres.techniques.length);
});

test("lot 5 §8 — les anciens types de blocs (transition, consigne, durée) survivent intacts à l'import/réimport", () => {
  const b = bibliotheque();
  const identite = b.techniques[0]!;
  const packJudo = disciplineJudo({ nom: "Judo" });
  const tPack = technique(packJudo.id, { nom: identite.nom, niveauxIds: [] });
  delete (tPack as { familleId?: string }).familleId;
  const ancienne = composition({
    nom: "Séance héritée",
    provenance: "enseignement",
    attribution: "Club",
    origine: { pack: "club", element: "seance-1" },
    blocs: [
      { id: genererUlid(), type: "technique", techniqueId: tPack.id, medias: [] },
      { id: genererUlid(), type: "transition", texte: "passage au sol", medias: [] },
      { id: genererUlid(), type: "consigne", texte: "lentement", medias: [] },
      { id: genererUlid(), type: "duree", texte: "3 min", medias: [] },
    ],
  });
  const pack = bibliotheque({
    disciplines: [packJudo],
    techniques: [tPack],
    contributions: [contribution(tPack.id, { provenance: "enseignement", attribution: "Club" })],
    compositions: [ancienne],
  });
  let apres = importerDansBibliotheque(b, structuredClone(pack), { packId: "club" }).bibliotheque;
  apres = importerDansBibliotheque(apres, structuredClone(pack), { packId: "club" }).bibliotheque; // réimport idempotent
  assert.equal(
    apres.compositions.filter((c) => c.origine?.pack === "club").length,
    1,
    "réimport idempotent (§25) : la composition n'est jamais dupliquée",
  );
  const importee = apres.compositions.find((c) => c.origine?.pack === "club")!;
  assert.deepEqual(
    importee.blocs.map((x) => x.type),
    ["technique", "transition", "consigne", "duree"],
    "les types internes ne sont jamais détruits ni migrés de force",
  );
  assert.deepEqual(
    importee.blocs.slice(1).map((x) => x.texte),
    ["passage au sol", "lentement", "3 min"],
    "les textes des anciens blocs restent lisibles",
  );
});

/* ---------- Compositions à plusieurs (D-227) ---------- */

test("D-227 — un bloc dit QUI agit ; sans acteurs, rien ne change", () => {
  const b = bibliotheque();
  const tech = b.techniques[0]!;
  const co = composition({ nom: "Randori codifié" });
  co.acteurs = [{ id: "r1", nom: "Tori" }, { id: "r2", nom: "Uke" }];
  const attaque = nouveauBloc("technique", { techniqueId: tech.id, acteurId: "r2" });
  const contre = nouveauBloc("technique", { techniqueId: tech.id, acteurId: "r1" });
  const chute = nouveauBloc("technique", { techniqueId: tech.id, acteurId: "r2", lien: true });
  const neutre = nouveauBloc("etape", { texte: "reprise de garde" });
  co.blocs = [attaque, contre, chute, neutre];
  b.compositions.push(co);
  validerBibliotheque(b);

  assert.equal(acteurDuBloc(co, attaque)?.nom, "Uke");
  assert.equal(acteurDuBloc(co, neutre), undefined, "un bloc sans acteur est neutre (« les deux »)");
  assert.equal(chute.lien, true, "le lien avec le pas précédent est porté par le bloc");
  assert.equal(contre.lien, undefined, "il reste l'EXCEPTION : absent par défaut");

  // Une composition SANS acteurs se comporte exactement comme avant.
  const solo = composition({ nom: "Ma spéciale" });
  solo.blocs = [nouveauBloc("technique", { techniqueId: tech.id })];
  assert.equal(acteurDuBloc(solo, solo.blocs[0]!), undefined);
  assert.equal(acteurSuivantPropose(solo), undefined, "sans acteurs, aucune proposition");
});

test("D-227 — le rôle proposé ALTERNE (une séquence à deux l'est presque toujours)", () => {
  const co = composition({ nom: "Kata" });
  co.acteurs = [{ id: "r1", nom: "Tori" }, { id: "r2", nom: "Uke" }];
  assert.equal(acteurSuivantPropose(co), "r1", "premier pas : le premier rôle");
  co.blocs = [nouveauBloc("etape", { texte: "a", acteurId: "r1" })];
  assert.equal(acteurSuivantPropose(co), "r2", "après Tori, on propose Uke");
  co.blocs.push(nouveauBloc("etape", { texte: "b", acteurId: "r2" }));
  assert.equal(acteurSuivantPropose(co), "r1", "puis Tori de nouveau");
  // Un bloc NEUTRE intercalé ne casse pas l'alternance (on regarde le dernier bloc JOUÉ).
  co.blocs.push(nouveauBloc("etape", { texte: "pause" }));
  assert.equal(acteurSuivantPropose(co), "r1");
});

test("D-227 — acteurs : unicité exigée, ULID NON exigé, référence orpheline tolérée", () => {
  const b = bibliotheque();
  const co = composition({ nom: "Duo" });
  co.acteurs = [{ id: "r1", nom: "Tori" }, { id: "r2", nom: "Uke" }];
  co.blocs = [nouveauBloc("etape", { texte: "a", acteurId: "r1" })];
  b.compositions.push(co);
  validerBibliotheque(b); // « r1 » n'est pas un ULID : c'est un emplacement local, c'est valide

  const doublon = structuredClone(b);
  doublon.compositions[0]!.acteurs = [{ id: "r1", nom: "Tori" }, { id: "r1", nom: "Uke" }];
  assert.throws(() => validerBibliotheque(doublon), ErreurValidation, "deux acteurs de même id sont refusés");

  const sansNom = structuredClone(b);
  sansNom.compositions[0]!.acteurs = [{ id: "r1", nom: "  " }];
  assert.throws(() => validerBibliotheque(sansNom), ErreurValidation, "un acteur sans nom est refusé");

  // Acteur retiré alors qu'un bloc le référence : la bibliothèque reste VALIDE,
  // le bloc redevient neutre à l'affichage (même tolérance que les relations).
  const orphelin = structuredClone(b);
  orphelin.compositions[0]!.acteurs = [{ id: "r2", nom: "Uke" }];
  validerBibliotheque(orphelin);
  const co2 = orphelin.compositions[0]!;
  assert.equal(acteurDuBloc(co2, co2.blocs[0]!), undefined, "référence orpheline → neutre, jamais une erreur");
});

/* ---------- Temps et dialogue à deux colonnes (D-229) ---------- */

/** La séquence arbitrée par le porteur : Tori attaque, Uke esquive PUIS
 *  contre-attaque dans le MÊME temps, Tori bloque en réaction, puis finalise. */
function sequenceDuel() {
  const co = composition({ nom: "Attaque, contre-attaque, contre" });
  co.acteurs = [{ id: "r1", nom: "Tori" }, { id: "r2", nom: "Uke" }];
  co.blocs = [
    nouveauBloc("etape", { texte: "O-soto-gari", acteurId: "r1" }),
    nouveauBloc("etape", { texte: "Tai-sabaki", acteurId: "r2", lien: true }),
    nouveauBloc("etape", { texte: "O-goshi", acteurId: "r2" }),
    nouveauBloc("etape", { texte: "Blocage de hanches", acteurId: "r1" }),
    nouveauBloc("etape", { texte: "Ura-nage", acteurId: "r1" }),
    nouveauBloc("etape", { texte: "Chute arriere", acteurId: "r2", lien: true }),
  ];
  return co;
}

test("D-229 — un lien RASSEMBLE dans le temps du précédent ; son absence ouvre un temps", () => {
  const co = sequenceDuel();
  const temps = decouperEnTemps(co);
  assert.deepEqual(temps.map((t) => t.blocs.length), [2, 1, 1, 2], "ce qui partage un temps se joue ensemble ; sinon, temps suivant");
  assert.deepEqual(temps.map((t) => t.numero), [1, 2, 3, 4]);

  // Sans aucun lien, on retrouve exactement le comportement historique : un pas = un temps.
  const solo = composition({ nom: "Ma spéciale" });
  solo.blocs = [nouveauBloc("etape", { texte: "a" }), nouveauBloc("etape", { texte: "b" })];
  assert.equal(decouperEnTemps(solo).length, 2, "sans lien, chaque pas est son propre temps");
  assert.equal(lectureEnTemps(solo), false, "sans rôles ni lien, la lecture reste la liste historique");

  // Un bloc média hérité (présentation d'avant D-124) n'est pas un pas.
  solo.blocs.push(nouveauBloc("media", {}));
  assert.equal(decouperEnTemps(solo).length, 2, "un bloc média n'ouvre pas de temps");
});

test("D-229 — chaque temps se répartit en colonnes, et son lien qualifie l'échange", () => {
  const co = sequenceDuel();
  const [t1] = decouperEnTemps(co);
  const r1 = repartirTemps(co, t1!);
  assert.deepEqual(r1.colonnes.map((c) => c.map((x) => x.texte)),
    [["O-soto-gari"], ["Tai-sabaki"]],
    "chaque rôle empile ses actions dans SA colonne, dans l'ordre de saisie");
  assert.deepEqual(r1.neutres, [], "aucun pas neutre ici");
  assert.equal(lectureEnTemps(co), true, "deux rôles suffisent à passer en trame par temps");

  // Un pas neutre (consigne, pause) se lit en pleine largeur, jamais dans une colonne.
  const neutre = { numero: 9, blocs: [nouveauBloc("etape", { texte: "reprise de garde" })] };
  assert.deepEqual(repartirTemps(co, neutre).neutres.map((x) => x.texte), ["reprise de garde"]);

  // Rôle disparu : le pas redevient neutre, il ne disparaît JAMAIS (même tolérance que D-227).
  const orphelin = { numero: 10, blocs: [nouveauBloc("etape", { texte: "x", acteurId: "r9" })] };
  assert.deepEqual(repartirTemps(co, orphelin).neutres.map((x) => x.texte), ["x"]);

  // Une composition SOLO qui lie deux pas passe elle aussi en trame (D-231) :
  // « en même temps » a un sens sans aucun rôle (respiration + posture).
  const solo = composition({ nom: "Yoga" });
  solo.blocs = [nouveauBloc("etape", { texte: "posture" }), nouveauBloc("etape", { texte: "respiration", lien: true })];
  assert.equal(lectureEnTemps(solo), true, "un lien suffit, même sans rôle");
  assert.equal(decouperEnTemps(solo).length, 1);
  assert.deepEqual(repartirTemps(solo, decouperEnTemps(solo)[0]!).neutres.map((x) => x.texte), ["posture", "respiration"]);
});

test("D-229/D-235 — un lien inconnu est refusé ; sur le premier pas il est toléré et ignoré", () => {
  const b = bibliotheque();
  b.compositions.push(sequenceDuel());
  validerBibliotheque(b); // la séquence arbitrée est valide

  const inconnu = structuredClone(b);
  (inconnu.compositions[0]!.blocs[1] as { lien: unknown }).lien = "pendant";
  assert.throws(() => validerBibliotheque(inconnu), ErreurValidation, "un lien hors vocabulaire est refusé");

  // Un lien posé sur le PREMIER pas est toléré (et ignoré) : supprimer un pas
  // ne doit jamais rendre une bibliothèque invalide (garde-fou porteur D-235).
  const premier = structuredClone(b);
  premier.compositions[0]!.blocs[0]!.lien = true;
  validerBibliotheque(premier);
  assert.equal(decouperEnTemps(premier.compositions[0]!).length, 4, "le lien du premier pas est sans effet");
});

/* ---------- Stabilité du regroupement (D-235, garde-fou porteur) ---------- */

/** [A][B C][D] — trois temps, dont un de deux pas. */
function troisTemps() {
  const co = composition({ nom: "Trame" });
  co.blocs = [
    nouveauBloc("etape", { texte: "A" }),
    nouveauBloc("etape", { texte: "B" }),
    nouveauBloc("etape", { texte: "C", lien: true }),
    nouveauBloc("etape", { texte: "D" }),
  ];
  return co;
}
const formes = (c: Composition) => decouperEnTemps(c).map((t) => t.blocs.map((b) => b.texte).join("+"));

test("D-235 — SUPPRIMER un pas ne déplace pas le regroupement", () => {
  // Retirer l'OUVREUR d'un temps : le temps survit amputé, il n'est pas absorbé.
  const co = troisTemps();
  retirerBloc(co, co.blocs[1]!.id); // B ouvrait le temps [B C]
  assert.deepEqual(formes(co), ["A", "C", "D"], "C reste son propre temps, il ne rejoint pas A");

  // Retirer un pas LIÉ : le temps rétrécit, rien d'autre ne bouge.
  const co2 = troisTemps();
  retirerBloc(co2, co2.blocs[2]!.id);
  assert.deepEqual(formes(co2), ["A", "B", "D"]);

  // Retirer le TOUT PREMIER pas : la bibliothèque reste valide (le suivant
  // n'hérite pas d'un lien orphelin) — c'est le cas qui cassait avant D-235.
  const co3 = troisTemps();
  co3.blocs[1]!.lien = true; // [A B C][D]
  retirerBloc(co3, co3.blocs[0]!.id);
  assert.equal(co3.blocs[0]!.lien, undefined, "le nouveau premier pas n'a plus de lien");
  assert.deepEqual(formes(co3), ["B+C", "D"]);
});

test("D-235 — DÉPLACER un pas d'un cran ne scinde jamais son temps", () => {
  // Échange DANS un temps : [A][B C][D] → on descend B d'un cran.
  const co = troisTemps();
  deplacerBloc(co, co.blocs[1]!.id, 1);
  assert.deepEqual(formes(co), ["A", "C+B", "D"], "le temps garde ses deux pas, dans l'autre ordre");

  // Franchir une frontière : monter C au-dessus de B le fait changer de temps.
  const co2 = troisTemps();
  deplacerBloc(co2, co2.blocs[2]!.id, -1);
  assert.deepEqual(formes(co2), ["A", "C+B", "D"]);

  // Le glisser générique (réordonner sur une cible) suit la même règle.
  const co3 = troisTemps();
  reordonnerBloc(co3, co3.blocs[3]!.id, co3.blocs[0]!.id); // D en tête
  assert.equal(co3.blocs[0]!.lien, undefined, "le pas amené en tête n'a jamais de lien");
  assert.equal(formes(co3).length, 3, "toujours trois temps");
});

test("D-235 — INSÉRER et DUPLIQUER conservent le regroupement", () => {
  const co = troisTemps();
  co.blocs.push(nouveauBloc("etape", { texte: "E", lien: true })); // E rejoint le temps de D
  normaliserTemps(co);
  assert.deepEqual(formes(co), ["A", "B+C", "D+E"]);

  // Duplication : mêmes blocs dans le même ordre → même trame.
  const copie = { ...co, blocs: co.blocs.map((b) => ({ ...b, id: b.id })) };
  assert.deepEqual(formes(copie), formes(co));
});

test("D-235 — la normalisation est idempotente et nettoie les cas impossibles", () => {
  const co = troisTemps();
  co.blocs[0]!.lien = true;                       // lien sur le premier pas
  co.blocs.push({ ...nouveauBloc("media", {}), lien: true }); // un média n'est pas un pas
  normaliserTemps(co);
  const apres = JSON.stringify(co.blocs);
  normaliserTemps(co);
  assert.equal(JSON.stringify(co.blocs), apres, "deux passages donnent le même résultat");
  assert.equal(co.blocs[0]!.lien, undefined);
  assert.equal(co.blocs.at(-1)!.lien, undefined);
});

test("D-235 — les liens hérités de D-229 se lisent sans rien réécrire", () => {
  const co = composition({ nom: "Ancienne" });
  co.blocs = [
    nouveauBloc("etape", { texte: "A" }),
    { ...nouveauBloc("etape", { texte: "B" }), lien: "simultane" as const },
    { ...nouveauBloc("etape", { texte: "C" }), lien: "puis" as const },
    { ...nouveauBloc("etape", { texte: "D" }), lien: "reaction" as const },
  ];
  assert.equal(estLie(co.blocs[1]!), true, "« simultané » rejoignait le temps");
  assert.equal(estLie(co.blocs[2]!), false, "« puis » disait une suite : nouveau temps");
  assert.equal(estLie(co.blocs[3]!), false, "« réaction » aussi");
  assert.deepEqual(formes(co), ["A+B", "C", "D"]);
  // Rien n'est réécrit tant qu'on ne modifie pas : la donnée d'origine est intacte.
  assert.equal(co.blocs[2]!.lien, "puis");
  normaliserTemps(co);
  assert.equal(co.blocs[2]!.lien, undefined, "à la première écriture, elle devient le booléen");
  assert.deepEqual(formes(co), ["A+B", "C", "D"], "et la trame ne bouge pas");
});

// UI-4 (D-322) : la recherche d'ajout d'étape ne doit pas s'ouvrir sur un vide.
// `techniquesAPortee` dérive ce qui est DÉJÀ sous la main — rien d'inventé.
test("techniquesAPortee : la discipline du dernier pas technique fait la proposition", () => {
  const judo = disciplineJudo();
  const yoga = disciplineJudo({ nom: "Yoga" });
  const tJudo = [technique(judo.id, { nom: "O-soto-gari" }), technique(judo.id, { nom: "Harai-goshi" })];
  const tYoga = [technique(yoga.id, { nom: "Chien tête en bas" })];
  const b = { techniques: [...tJudo, ...tYoga], disciplines: [judo, yoga] };
  // Une composition dont le dernier pas technique est du YOGA propose du yoga,
  // même si le judo est plus fourni : c'est le contexte qui décide, pas le volume.
  const compo = composition({
    blocs: [
      nouveauBloc("technique", { techniqueId: tJudo[0]!.id }),
      nouveauBloc("technique", { techniqueId: tYoga[0]!.id }),
      nouveauBloc("etape", { texte: "respiration" }),
    ],
  });
  assert.deepEqual(techniquesAPortee(b, compo).map((t) => t.nom), ["Chien tête en bas"]);
  // Une composition VIDE et deux disciplines : rien à proposer plutôt qu'un choix
  // arbitraire — proposer le judo « parce qu'il est premier » serait une invention.
  assert.deepEqual(techniquesAPortee(b, composition({ blocs: [] })), []);
  // …sauf s'il n'y a qu'une discipline installée : là, il n'y a pas d'arbitraire.
  const seule = { techniques: tJudo, disciplines: [judo] };
  assert.deepEqual(techniquesAPortee(seule, composition({ blocs: [] })).map((t) => t.nom), ["O-soto-gari", "Harai-goshi"]);
  // La limite est respectée (la feuille n'a pas la place d'une bibliothèque).
  assert.equal(techniquesAPortee(seule, composition({ blocs: [] }), 1).length, 1);
});

// D-326 (verdict checker) : « combien de pas » a UN seul lieu de calcul. La
// liste comptait les jalons, la fiche non — le Nage-no-kata publié annonçait
// 26 étapes sur sa carte et 21 sur sa fiche.
test("nombreDePas : un jalon n'est pas un pas, et c'est vrai partout", () => {
  const judo = disciplineJudo();
  const t = technique(judo.id);
  const jalon = nouveauBloc("etape", { texte: "— Te-waza —" });
  const compo = composition({
    blocs: [
      jalon,
      nouveauBloc("technique", { techniqueId: t.id }),
      nouveauBloc("technique", { techniqueId: t.id }),
      nouveauBloc("etape", { texte: "— Koshi-waza —" }),
      nouveauBloc("technique", { techniqueId: t.id }),
    ],
  });
  assert.equal(estJalon(jalon), true, "un intertitre encadré de tirets, sans durée, est un jalon");
  assert.equal(nombreDePas(compo), 3, "cinq blocs, deux jalons → trois pas");
  assert.equal(texteJalon(jalon), "Te-waza", "le texte d'un jalon se lit sans ses tirets");
  // Ce qui RESSEMBLE à un jalon mais n'en est pas : une étape minutée garde son
  // rang (une durée en fait un geste), et un texte sans tirets aussi.
  const minute = nouveauBloc("etape", { texte: "— échauffement —", dureeSec: 300 });
  const libre = nouveauBloc("etape", { texte: "transition au sol" });
  assert.equal(estJalon(minute), false, "une étape MINUTÉE est un geste, jamais un intertitre");
  assert.equal(estJalon(libre), false, "un texte sans tirets d'encadrement n'est pas un jalon");
  assert.equal(nombreDePas(composition({ blocs: [minute, libre] })), 2, "les deux comptent");
  // Un bloc média n'a jamais compté (D-124) : la règle ne change pas.
  assert.equal(nombreDePas(composition({ blocs: [nouveauBloc("media", {}), jalon, libre] })), 1, "ni média ni jalon");
});
