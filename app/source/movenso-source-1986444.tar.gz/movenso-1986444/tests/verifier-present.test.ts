/**
 * PRÉSENT À JOUR (D-014, sorti de la CI en D-300) : la règle qui refusait en
 * CI seulement — deux poussées rouges le 2026-08-11 avant qu'elle ne parle —
 * s'exécute désormais localement, depuis un lieu unique.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const SCRIPT = fileURLToPath(new URL("../outils/verifier-present.mjs", import.meta.url));

function git(cwd: string, ...args: string[]): string {
  return execFileSync(
    "git",
    ["-C", cwd, "-c", "user.email=t@t.invalide", "-c", "user.name=t", ...args],
    { encoding: "utf8" },
  ).trim();
}

/** Un dépôt jetable : commit initial, puis un commit par lot de fichiers. */
function depot(...lots: string[][]): { cwd: string; base: string; head: string } {
  const cwd = mkdtempSync(join(tmpdir(), "present-"));
  git(cwd, "init", "-b", "main");
  writeFileSync(join(cwd, "racine.txt"), "0");
  git(cwd, "add", "-A");
  git(cwd, "commit", "-qm", "base");
  const base = git(cwd, "rev-parse", "HEAD");
  for (const [i, fichiers] of lots.entries()) {
    for (const f of fichiers) {
      mkdirSync(join(cwd, f, ".."), { recursive: true });
      writeFileSync(join(cwd, f), String(i));
    }
    git(cwd, "add", "-A");
    git(cwd, "commit", "-qm", `lot ${i}`);
  }
  return { cwd, base, head: git(cwd, "rev-parse", "HEAD") };
}

function lancer(cwd: string, base: string, head: string): { code: number; sortie: string } {
  try {
    const sortie = execFileSync(process.execPath, [SCRIPT, base, head], { cwd, encoding: "utf8" });
    return { code: 0, sortie };
  } catch (e) {
    const err = e as { status?: number | null; stdout?: string; stderr?: string };
    return { code: err.status ?? -1, sortie: `${err.stdout ?? ""}${err.stderr ?? ""}` };
  }
}

test("le produit change sans STATE.md : refus — le cas exact des deux poussées rouges", () => {
  const { cwd, base, head } = depot(["donnees/kodokan.json", "tests/x.test.ts"]);
  try {
    const r = lancer(cwd, base, head);
    assert.equal(r.code, 1, r.sortie);
    assert.match(r.sortie, /D-014/);
  } finally {
    rmSync(cwd, { recursive: true, force: true });
  }
});

test("le produit change AVEC STATE.md quelque part dans l'intervalle : passe", () => {
  const { cwd, base, head } = depot(["src/a.ts"], ["docs/execution/STATE.md"]);
  try {
    assert.equal(lancer(cwd, base, head).code, 0);
  } finally {
    rmSync(cwd, { recursive: true, force: true });
  }
});

test("contrepartie : un changement hors produit (doc seule) n'exige rien", () => {
  const { cwd, base, head } = depot(["docs/execution/DECISIONS.md", "README.md"]);
  try {
    assert.equal(lancer(cwd, base, head).code, 0);
  } finally {
    rmSync(cwd, { recursive: true, force: true });
  }
});
