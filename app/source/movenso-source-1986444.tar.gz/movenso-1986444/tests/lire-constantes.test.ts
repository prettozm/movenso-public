/**
 * LES CONSTANTES DE FORMAT, LUES À UN SEUL ENDROIT (D-285).
 *
 * L'incident : au refactoring D-274, VERSION_MOVPACK a déménagé de
 * `movpack.ts` vers `movpack-contrat.ts`. Deux outils gardaient l'ancienne
 * adresse en dur : `versions` affichait « ? », `source-du-build` écrivait
 * `versionMovpack: null` dans build.json — et quatre vérificateurs restaient
 * verts. Le cas décisif ici : un fichier qui MENTIONNE la constante sans la
 * définir (un import, exactement l'état de movpack.ts après D-274) doit
 * produire un refus bruyant, jamais une valeur qui continue son chemin.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { ADRESSES, constante, extraire } from "../outils/lire-constantes.mjs";

test("les deux constantes de format se lisent depuis leur source canonique", () => {
  for (const nom of ["VERSION_SCHEMA", "VERSION_MOVPACK"] as const) {
    const v = constante(nom);
    assert.ok(Number.isInteger(v) && v >= 1, `${nom} : ${v}`);
  }
});

test("le scénario D-274 : une mention sans définition (import) est un refus, pas NaN", () => {
  const texte = 'import {\n  VERSION_MOVPACK, ErreurMovpack,\n} from "./movpack-contrat.ts";\n';
  assert.throws(
    () => extraire(texte, "VERSION_MOVPACK", "src/echange/movpack.ts"),
    /VERSION_MOVPACK.*src\/echange\/movpack\.ts/,
  );
});

test("contrepartie : une définition se lit, et en nombre", () => {
  assert.equal(extraire("export const VERSION_MOVPACK = 5;", "VERSION_MOVPACK", "x"), 5);
});

test("une constante non déclarée dans ADRESSES est un refus qui nomme le lieu à corriger", () => {
  assert.throws(() => constante("VERSION_INVENTEE" as never), /ADRESSES/);
});

test("les adresses canoniques restent celles que les gardes connaissent", () => {
  assert.equal(ADRESSES.VERSION_SCHEMA, "src/domaine/modele.ts");
  assert.equal(ADRESSES.VERSION_MOVPACK, "src/echange/movpack-contrat.ts");
});
