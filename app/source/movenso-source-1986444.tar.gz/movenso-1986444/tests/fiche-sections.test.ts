/**
 * Ce qu'une composition DIT d'elle-même sur la fiche technique (D-337).
 *
 * Sur l'ancienne fiche, « Utilisée dans » n'affichait qu'un nom : rien ne
 * disait si « Ma spéciale » était un kata, une séance de dix minutes ou trois
 * mouvements enchaînés. Ce libellé est la réponse, et il ne doit jamais laisser
 * remonter l'identifiant de type brut jusqu'à l'écran.
 *
 * Ces tests tournent en Node pur : la fonction ne touche ni au DOM ni à `app`.
 * Le RENDU des sections vides, lui, se démontre dans le parcours e2e — c'est
 * là qu'il est réellement observable.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { libelleTypeComposition } from "../src/app/fiche-sections.ts";
import type { Composition } from "../src/domaine/modele.ts";

function compo(p: Partial<Composition>): Composition {
  return {
    id: "01",
    nom: "Ma spéciale",
    provenance: "personnel",
    creeLe: "2026-01-01T00:00:00.000Z",
    blocs: [],
    ...p,
  } as Composition;
}

test("le type d'une composition se lit en clair, jamais en identifiant", () => {
  assert.equal(libelleTypeComposition(compo({ type: "kata" })), "Kata (formes)");
  assert.equal(libelleTypeComposition(compo({ type: "seance" })), "Séance");
  assert.equal(libelleTypeComposition(compo({ type: "enchainement" })), "Enchaînement");
});

test("sans type choisi, le repli compte les TECHNIQUES et rien d'autre", () => {
  // Une composition d'avant D-126, ou venue d'un import, n'a pas de type. La
  // fiche ne doit pas pour autant afficher une ligne vide sous le nom.
  const sansType = compo({
    blocs: [
      { id: "a", type: "technique", techniqueId: "t1", medias: [] },
      { id: "b", type: "technique", techniqueId: "t2", medias: [] },
      { id: "c", type: "etape", texte: "souffler", medias: [] },
    ],
  } as Partial<Composition>);
  assert.equal(libelleTypeComposition(sansType), "2 techniques");
});

test("le repli s'accorde au singulier", () => {
  const une = compo({ blocs: [{ id: "a", type: "technique", techniqueId: "t1", medias: [] }] } as Partial<Composition>);
  assert.equal(libelleTypeComposition(une), "1 technique");
});

test("une composition vide reste dicible : zéro technique, pas une ligne muette", () => {
  assert.equal(libelleTypeComposition(compo({})), "0 technique");
});
