/**
 * R5-1 (REC-B4-001, 2026-08-11) : deux sauvegardes le même jour portaient le
 * MÊME nom (`movenso-complet-AAAA-MM-JJ.movpack`) et s'écrasaient entre elles
 * dans `Documents/movenso` — une sauvegarde qui détruit une sauvegarde,
 * silencieusement. Le nom porte désormais l'heure et la minute, en temps
 * LOCAL (le fichier est destiné à l'utilisateur, pas à un serveur).
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { horodatage, nomDeSauvegarde } from "../src/app/services/nom-fichier.ts";

test("deux sauvegardes le même jour, à des minutes différentes, portent des noms DIFFÉRENTS", () => {
  const matin = new Date(2026, 7, 11, 9, 5);
  const soir = new Date(2026, 7, 11, 22, 41);
  assert.notEqual(nomDeSauvegarde(true, matin), nomDeSauvegarde(true, soir));
});

test("le nom dit la complétude, la date et l'heure locales, zéro-paddées", () => {
  const quand = new Date(2026, 7, 11, 9, 5); // 11 août 2026, 09:05 locale
  assert.equal(nomDeSauvegarde(true, quand), "movenso-complet-2026-08-11-09h05.movpack");
  assert.equal(nomDeSauvegarde(false, quand), "movenso-partiel-2026-08-11-09h05.movpack");
});

test("l'horodatage est réutilisable tel quel (diagnostic — même classe de collision)", () => {
  assert.match(horodatage(new Date(2026, 11, 3, 23, 59)), /^2026-12-03-23h59$/);
});
