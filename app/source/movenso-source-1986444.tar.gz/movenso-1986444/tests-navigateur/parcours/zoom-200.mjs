/**
 * CHAPITRE e2e (S3.A7) — S2.10 tranche 3 — zoom 200 % (proxy viewport 320 px).
 * Contexte(s) Playwright propre(s) : OPFS isolé, lançable après tout chapitre.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { surveiller, lent, ouvrirPlus, navigateur, rendu } from "../harnais.mjs";

export async function run() {
/* ===== S2.10 tranche 3 — zoom 200 % (proxy : viewport 320 px ≈ une fenêtre
   640 px zoomée ×2) : les écrans principaux restent utilisables SANS
   défilement horizontal. ===== */
{
  const ctxZ = await navigateur.newContext({ viewport: { width: 320, height: 568 } });
  const pZ = await ctxZ.newPage();
  surveiller(pZ);
  await pZ.goto("http://localhost:4517/");
  await pZ.waitForSelector(".action-douce");
  const sansDefilementH = async (ecran) => {
    const [large, fenetre] = await pZ.evaluate(() => [document.scrollingElement.scrollWidth, window.innerWidth]);
    assert.ok(large <= fenetre + 1, `zoom 200 % (${ecran}) : pas de défilement horizontal (${large} > ${fenetre})`);
  };
  await sansDefilementH("accueil vide");
  await pZ.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
  await rendu(pZ);
  await sansDefilementH("menu Plus");
  await ouvrirPlus(pZ, "Aide & à propos");
  await rendu(pZ);
  await sansDefilementH("À propos");
  await ctxZ.close();
}
}
