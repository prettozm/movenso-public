/**
 * CHAPITRE e2e (S3.A7) — S1.6 (D-162) — certification sauvegarde/restauration sur corpus de référence.
 * Contexte(s) Playwright propre(s) : OPFS isolé, lançable après tout chapitre.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { unzipSync } from "fflate";
import { surveiller, lent, gesteCapture, navigateur, rendu } from "../harnais.mjs";

export async function run() {
/* ===== S1.6 (D-162, REC-S1-006) — CERTIFICATION sauvegarde/restauration sur
   corpus de RÉFÉRENCE : bibliothèque riche (Unicode, relation avec raison et
   priorité, favori, compositions, vidéo locale, capture « à traiter ») →
   sauvegarde complète → restauration sur installation VIERGE → comparaison
   OBJET PAR OBJET + empreinte SHA-256 de la vidéo ; sauvegarde légère →
   mêmes données, zéro vidéo physique ; archive tronquée → refus propre. ===== */
{
  const shaVideosPage = `(async () => {
    const sortie = {};
    try {
      const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos");
      for await (const [nom, h] of d) {
        if (h.kind !== "file") continue;
        const octets = await (await h.getFile()).arrayBuffer();
        const hash = await crypto.subtle.digest("SHA-256", octets);
        sortie[nom] = Array.from(new Uint8Array(hash)).map((x) => x.toString(16).padStart(2, "0")).join("");
      }
    } catch { /* aucune vidéo */ }
    return sortie;
  })()`;
  const ctxF = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageF = await ctxF.newPage();
  surveiller(pageF);
  await pageF.goto("http://localhost:4517/");
  await pageF.waitForSelector(".action-douce");
  // 1) corpus de référence — Unicode partout, toutes les natures de données
  await pageF.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const d1 = await app.creerDiscipline("Aïkido 合気道");
    const d2 = await app.creerDiscipline("Judo-Éprouvette");
    await app.creerTechnique(d1, "Ō-soto-gari éprouvée", { nomTraditionnel: "大外刈 éprouvé" });
    await app.creerTechnique(d2, "Ushiro-geri 後ろ蹴り");
    const [tA, tB] = app.bibliotheque.techniques;
    const octets = new Uint8Array(4096);
    for (let i = 0; i < octets.length; i++) octets[i] = (i * 7 + 3) & 0xff;
    await app.ajouterMediaFiche(tA.id, { fichier: new File([octets], "réf.webm", { type: "video/webm" }) });
    await app.ajouterMediaFiche(tB.id, { lien: "https://youtu.be/dQw4w9WgXcQ" }, { provenance: "enseignement", attribution: "Sensei Épreuve" });
    await app.ajouterRelation(tA.id, { type: "enchaine", cibleId: tB.id, note: "précède naturellement — éprouvé ✓", priorite: 2 });
    await app.basculerFavori(tB.id);
    // D-373 : `creerCompositionDepuisEtapes` retiré avec la vue Explorer — on
    // monte la composition par le chemin normal (créer + ajouter des blocs).
    await app.creerComposition("Séance d'épreuve 稽古");
    const compo = app.bibliotheque.compositions.find((c) => c.nom === "Séance d'épreuve 稽古");
    await app.modifierComposition(compo.id, (c) => {
      c.blocs.push({ id: crypto.randomUUID(), type: "technique", techniqueId: tA.id, consigne: "souffle régulier", medias: [] });
      c.blocs.push({ id: crypto.randomUUID(), type: "technique", techniqueId: tB.id, medias: [] });
    });
  });
  // capture « à traiter » (Garder pour plus tard) — par l'UI, comme un humain.
  // Recharge d'abord : tout est persisté, l'UI repart d'un état propre.
  await pageF.reload();
  await pageF.waitForSelector(".chip-discipline");
  await pageF.locator(".chip-discipline", { hasText: "Judo-Éprouvette" }).click();
  await pageF.waitForSelector(".carte-technique");
  await pageF.locator(".fab", { hasText: "Ajouter" }).click();
  await gesteCapture(pageF, "note");
  await pageF.fill(".champ-note", "à reclasser : garde ouverte 構え");
  await pageF.click(".feuille .actions .bouton.principal"); // Rattacher →
  await pageF.locator(".feuille .actions .bouton", { hasText: "Garder pour plus tard" }).click();
  await rendu(pageF);
  const reference = await pageF.evaluate(() => {
    const app = document.querySelector("movenso-app");
    return JSON.stringify(app.bibliotheque);
  });
  const refBib = JSON.parse(reference);
  assert.ok(refBib.contributions.some((c) => c.techniqueId === null), "le corpus contient bien un élément « à traiter »");
  assert.equal(refBib.favoris.length, 1, "le corpus contient un favori");
  const shaAvant = await pageF.evaluate(shaVideosPage);
  assert.equal(Object.keys(shaAvant).length, 1, "le corpus contient une vidéo physique");
  // donnée d'APPAREIL plantée avant l'export : elle ne doit JAMAIS voyager
  await pageF.evaluate(() => document.querySelector("movenso-app").changerPseudo("PSEUDO-SENTINELLE-88"));
  // 2) sauvegarde complète + sauvegarde légère (téléchargements réels)
  const [dlComplet] = await Promise.all([pageF.waitForEvent("download"), pageF.evaluate(() => document.querySelector("movenso-app").exporterTout(true))]);
  const fichierCertif = join(tmpdir(), "movenso-e2e-certif-complet.movpack");
  await dlComplet.saveAs(fichierCertif);
  const [dlLeger] = await Promise.all([pageF.waitForEvent("download"), pageF.evaluate(() => document.querySelector("movenso-app").exporterTout(false))]);
  const fichierCertifLeger = join(tmpdir(), "movenso-e2e-certif-leger.movpack");
  await dlLeger.saveAs(fichierCertifLeger);
  await ctxF.close();
  // S1.7 : non-divulgation sur le FICHIER RÉEL — on dézippe chaque entrée et
  // on cherche la sentinelle d'appareil (pseudo). preferences.json ne doit
  // jamais être une entrée de l'archive.
  {
    const { unzipSync } = await import("fflate");
    for (const fichier of [fichierCertif, fichierCertifLeger]) {
      const entrees = unzipSync(new Uint8Array(readFileSync(fichier)));
      assert.ok(!Object.keys(entrees).includes("preferences.json"), "preferences.json (appareil) n'est jamais une entrée de l'archive");
      for (const [nom, contenu] of Object.entries(entrees)) {
        if (!/\.json$/.test(nom)) continue;
        const texte = new TextDecoder().decode(contenu);
        assert.ok(!texte.includes("PSEUDO-SENTINELLE-88"), `donnée d'appareil fuitée dans ${nom} (${fichier})`);
        assert.ok(!/pbkdf2|"protections"/i.test(texte), `trace de protection/PIN dans ${nom}`);
      }
    }
  }

  // 3) restauration COMPLÈTE sur installation vierge → identité objet par objet
  const restaurer = async (fichier) => {
    const ctx = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
    const p = await ctx.newPage();
    surveiller(p);
    await p.goto("http://localhost:4517/");
    await p.waitForSelector(".action-douce");
    const [sel] = await Promise.all([p.waitForEvent("filechooser"), p.locator(".action-douce", { hasText: "Importer" }).click()]);
    await sel.setFiles(fichier);
    await p.waitForSelector('.feuille[aria-label="Restauration complète"]');
    await p.locator(".feuille .actions .bouton.principal", { hasText: "Restaurer" }).click();
    await p.waitForTimeout(lent(400));
    return { ctx, p };
  };
  {
    const { ctx, p } = await restaurer(fichierCertif);
    const apres = await p.evaluate(() => JSON.stringify(document.querySelector("movenso-app").bibliotheque));
    assert.deepEqual(JSON.parse(apres), refBib, "restauration complète : la bibliothèque restaurée est IDENTIQUE objet par objet (ids, relations avec raison/priorité, favoris, compositions, à-traiter, Unicode)");
    const shaApres = await p.evaluate(shaVideosPage);
    assert.deepEqual(shaApres, shaAvant, "restauration complète : la vidéo physique revient à l'EMPREINTE près (SHA-256)");
    await ctx.close();
  }
  // 4) restauration LÉGÈRE : mêmes données métier, AUCUNE vidéo physique —
  //    la référence au média reste (le fichier est dit absent, jamais perdu en silence)
  {
    const { ctx, p } = await restaurer(fichierCertifLeger);
    const apres = await p.evaluate(() => JSON.stringify(document.querySelector("movenso-app").bibliotheque));
    assert.deepEqual(JSON.parse(apres), refBib, "restauration légère : les DONNÉES sont identiques (les références de médias restent)");
    const shaApres = await p.evaluate(shaVideosPage);
    assert.deepEqual(shaApres, {}, "restauration légère : zéro vidéo physique restaurée — l'absence est structurelle, pas une perte silencieuse");
    await ctx.close();
  }
  // 5) archive TRONQUÉE → refus propre au niveau UI, rien de proposé
  {
    const octets = readFileSync(fichierCertif);
    const fichierTronque = join(tmpdir(), "movenso-e2e-certif-tronque.movpack");
    writeFileSync(fichierTronque, octets.slice(0, Math.floor(octets.length / 3)));
    const ctx = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
    const p = await ctx.newPage();
    surveiller(p);
    await p.goto("http://localhost:4517/");
    await p.waitForSelector(".action-douce");
    const [sel] = await Promise.all([p.waitForEvent("filechooser"), p.locator(".action-douce", { hasText: "Importer" }).click()]);
    await sel.setFiles(fichierTronque);
    await p.locator(".toast").waitFor();
    assert.match(await p.locator(".toast").innerText(), /illisible|incomplète|impossible/i, "une sauvegarde tronquée est refusée avec un message clair");
    assert.equal(await p.locator('.feuille[aria-label="Restauration complète"]').count(), 0, "rien n'est proposé sur une archive tronquée");
    await ctx.close();
  }
}
}
