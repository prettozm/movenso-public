/**
 * CHAPITRE e2e (S4.2bis boucle B / D-269) — les images sont des FICHIERS.
 *
 * Le gain de ce chantier n'est pas dans le conteneur (mesuré : 1 à 3 %,
 * D-268), il est dans `bibliotheque.json` — l'état que le stockage réécrit en
 * trois passes à chaque sauvegarde. Ce chapitre le vérifie là où ça compte :
 * sur OPFS réel, par le vrai chemin d'écriture.
 *
 * Trois choses, et les trois sur le chemin de l'utilisateur :
 *  1. une bibliothèque en schéma 5, telle qu'un appareil déjà installé en
 *     porte une, MIGRE à l'ouverture : les octets deviennent un fichier et
 *     l'état maigrit ;
 *  2. la vignette reste AFFICHÉE après migration — un gain de poids qui
 *     ferait disparaître les illustrations serait une régression, pas une
 *     optimisation ;
 *  3. une seconde ouverture ne refait pas le travail (l'état sur disque est
 *     bien passé en schéma 6).
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu } from "../harnais.mjs";

/** Un JPEG minuscule mais RÉEL (1×1) : la migration décode le base64 et en
 *  calcule l'empreinte — un jeton fantaisiste ne prouverait pas le chemin. */
const JPEG_1PX =
  "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0a"
  + "HBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAA"
  + "AAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q==";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 800 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");

  // On écrit à la main un `bibliotheque.json` en SCHÉMA 5, avec sa couverture
  // en base64 — l'état exact d'un appareil installé avant ce lot. On n'invente
  // pas un chemin : c'est le fichier que l'application relira au démarrage.
  const avant = await p.evaluate(async ([jpeg]) => {
    const app = document.querySelector("movenso-app");
    const d = await app.creerDiscipline("Judo");
    await app.creerTechnique(d, "O-soto-gari");
    app.validerEditionFiche();
    const b = structuredClone(app.bibliotheque);
    b.versionSchema = 5;
    delete b.images;
    b.techniques[0].couverture = { type: "image", dataUrl: `data:image/jpeg;base64,${jpeg}` };
    const racine = await navigator.storage.getDirectory();
    const h = await racine.getFileHandle("bibliotheque.json", { create: true });
    const w = await h.createWritable();
    await w.write(JSON.stringify(b));
    await w.close();
    return (await h.getFile()).size;
  }, [JPEG_1PX]);

  // Ouverture : c'est `charger()` qui migre, pose le fichier et persiste.
  await p.reload();
  await p.waitForSelector(".carte-technique");
  await rendu(p);

  const apres = await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const racine = await navigator.storage.getDirectory();
    const etat = await (await racine.getFileHandle("bibliotheque.json")).getFile();
    const brut = JSON.parse(await etat.text());
    let fichiersImages = 0;
    let octetsImages = 0;
    try {
      const dossier = await racine.getDirectoryHandle("images");
      for await (const [, h] of dossier) {
        fichiersImages++;
        octetsImages += (await h.getFile()).size;
      }
    } catch { /* pas de dossier */ }
    const t = app.bibliotheque.techniques[0];
    return {
      taille: etat.size,
      versionSchema: brut.versionSchema,
      inventaire: (brut.images ?? []).length,
      couverture: t.couverture,
      contientBase64: JSON.stringify(brut).includes("base64"),
      fichiersImages,
      octetsImages,
      // Ce que l'utilisateur VOIT : la balise d'image de la carte.
      vignetteAffichee: !!document.querySelector(".carte-technique img")?.getAttribute("src"),
    };
  });

  assert.equal(apres.versionSchema, 6, "l'état sur disque est passé en schéma 6");
  assert.equal(apres.inventaire, 1, "l'image est déclarée une fois à l'inventaire");
  assert.equal(apres.couverture?.type, "fichier", "la couverture ne porte plus d'octets, mais un renvoi");
  assert.equal(apres.couverture?.imageId?.length, 64, "elle désigne l'image par son empreinte");
  assert.equal(apres.contientBase64, false, "plus un seul octet d'image dans l'état");
  assert.equal(apres.fichiersImages, 1, "un fichier image, et un seul");
  assert.ok(apres.octetsImages > 0, "le fichier porte réellement les octets");
  assert.ok(apres.taille < avant, `l'état a maigri (${avant} → ${apres.taille} octets)`);
  assert.ok(apres.vignetteAffichee, "la vignette est TOUJOURS affichée après migration");

  // Le fichier de l'image porte bien son empreinte pour nom — c'est ce qui
  // rend l'écriture idempotente, donc sûre.
  const nomEstEmpreinte = await p.evaluate(async (id) => {
    const dossier = await (await navigator.storage.getDirectory()).getDirectoryHandle("images");
    try {
      await dossier.getFileHandle(id);
      return true;
    } catch {
      return false;
    }
  }, apres.couverture.imageId);
  assert.ok(nomEstEmpreinte, "le fichier est nommé par l'empreinte que la couverture désigne");

  // Seconde ouverture : rien à refaire, et surtout rien de perdu.
  await p.reload();
  await p.waitForSelector(".carte-technique");
  await rendu(p);
  const stable = await p.evaluate(async () => {
    const racine = await navigator.storage.getDirectory();
    const brut = JSON.parse(await (await racine.getFileHandle("bibliotheque.json")).getFile().then((f) => f.text()));
    return {
      versionSchema: brut.versionSchema,
      inventaire: (brut.images ?? []).length,
      vignetteAffichee: !!document.querySelector(".carte-technique img")?.getAttribute("src"),
    };
  });
  assert.equal(stable.versionSchema, 6, "la seconde ouverture ne rejoue pas la migration");
  assert.equal(stable.inventaire, 1, "l'inventaire n'a pas doublé");
  assert.ok(stable.vignetteAffichee, "la vignette survit à une réouverture");

  // AUDIT 2026-08-13, P1-1 : « Tout supprimer définitivement » promet que rien
  // ne survit — et `images/` manquait à la primitive d'effacement. Une
  // CATÉGORIE DE STOCKAGE neuve (schéma 6, D-269) n'avait pas été rattachée à
  // « efface tout » : les gardes étaient vertes et la promesse fausse. La
  // preuve se place ICI, seul endroit du parcours où des images existent
  // vraiment — ailleurs, elle aurait été vide (mesuré : dossier absent).
  const compterImages = () => p.evaluate(async () => {
    try {
      const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("images");
      let n = 0;
      for await (const _ of d.keys()) n++;
      return n;
    } catch { return -1; } // dossier absent
  });
  const avantEffacement = await compterImages();
  assert.ok(avantEffacement > 0, `le test serait vide sans image à effacer (compté ${avantEffacement})`);
  await p.evaluate(async () => {
    await document.querySelector("movenso-app").stockage.reinitialiser();
  });
  assert.ok((await compterImages()) <= 0,
    `la réinitialisation doit emporter les octets des couvertures (${avantEffacement} avant, reste ${await compterImages()})`);

  await ctx.close();
}
