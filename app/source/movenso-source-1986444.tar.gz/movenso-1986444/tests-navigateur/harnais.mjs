/**
 * HARNAIS e2e (S3.A7, tranche 1 — extrait de parcours.mjs tel quel) :
 * serveur statique de dist/, lancement Chromium, surveillance des erreurs JS,
 * calibration des temporisations (D-103) et aides de navigation PARAMÉTRÉES
 * par la page (`p`) — réutilisables par tout fichier de parcours.
 * L'import de ce module DÉMARRE le serveur et le navigateur (top-level await).
 */
import { chromium } from "playwright";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { readFileSync, existsSync } from "node:fs";
import { join, extname } from "node:path";

const DIST = new URL("../dist", import.meta.url).pathname;
const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json" };
export const serveur = createServer((req, res) => {
  const chemin = req.url.split("?")[0];
  const fichier = join(DIST, chemin === "/" ? "index.html" : chemin);
  if (!existsSync(fichier)) {
    res.statusCode = 404;
    return res.end("404");
  }
  res.setHeader("content-type", MIME[extname(fichier)] ?? "application/octet-stream");
  res.end(readFileSync(fichier));
});
await new Promise((r) => serveur.listen(4517, r));

export let navigateur;
try {
  navigateur = await chromium.launch();
} catch {
  navigateur = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
}
export const erreurs = [];
export function surveiller(page) {
  page.on("pageerror", (e) => erreurs.push("pageerror: " + e.message));
  page.on("console", (m) => {
    if (m.type() !== "error") return;
    // Les vignettes en ligne peuvent échouer (hors ligne / réseau filtré) :
    // c'est la dégradation prévue (placeholder), pas une erreur de l'app.
    if ((m.location()?.url ?? "").includes("img.youtube.com")) return;
    // Le catalogue des packs officiels vit sur le site public (B2, D-213) :
    // hors du site (dev/e2e), son 404 est la dégradation PRÉVUE (écran
    // « catalogue injoignable »), pas une erreur de l'app.
    if ((m.location()?.url ?? "").includes("/packs/")) return;
    // Bruit du Chromium CI (run 29239251831) : sonde compute-pressure du
    // navigateur lui-même — l'application n'utilise pas cette API.
    if (m.text().includes("compute-pressure")) return;
    erreurs.push("console: " + m.text());
  });
}

/* ===== Calibration des temporisations (D-103) — anti-flaky. Ce conteneur peut
   rendre 3× plus lentement selon la charge (démarrage mesuré 136→468 ms). Les
   `waitForTimeout` fixes étaient calibrés à froid ; quand le rendu ralentit,
   l'assertion mono-coup qui suit tombe. On mesure UNE fois le coût réel d'un
   chargement d'app, et toutes les temporisations passent par `lent(ms)` qui les
   met à l'échelle de cette lenteur : machine rapide → ×1 (comportement
   identique) ; conteneur lent → fenêtres élargies d'autant, le ratio
   sleep/rendu reste constant et la course de timing disparaît. Aucune variable
   d'environnement ; l'échelle est bornée à [1, 4] et surchargée par E2E_ECHELLE
   si besoin. ===== */
let ECHELLE = Number(process.env.E2E_ECHELLE) || 1;
if (!process.env.E2E_ECHELLE) {
  const ctxCal = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageCal = await ctxCal.newPage();
  const t0 = Date.now();
  await pageCal.goto("http://localhost:4517/");
  await pageCal.waitForSelector(".action-douce", { timeout: 30000 });
  const cout = Date.now() - t0;
  await ctxCal.close();
  ECHELLE = Math.max(1, Math.min(4, cout / 150));
  console.log(`calibration : chargement à vide ${cout} ms → temporisations ×${ECHELLE.toFixed(2)}`);
}
export const lent = (ms) => Math.round(ms * ECHELLE);

/** Attend un ÉTAT STABLE du rendu (S3.A8) : la mise à jour Lit en cours est
 *  terminée (updateComplete) puis deux frames d'affichage — remplace les
 *  petites temporisations « laisse l'app re-rendre » (dette D-103). Sur une
 *  page sans l'app (garde plateforme), retombe sur les deux frames seules. */
export async function rendu(p) {
  await p.evaluate(async () => {
    await document.querySelector("movenso-app")?.updateComplete;
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  });
}

/** Réessaie une LECTURE+ASSERTION jusqu'à ce qu'elle passe (S3.A8) : pour les
 *  états qui se matérialisent de façon ASYNCHRONE (persistance OPFS, recalculs
 *  après un clic) — borné par `lent(delaiMax)`, sondé toutes les 40 ms ; le
 *  dernier échec réel est relancé tel quel. Remplace les sommeils aveugles. */
export async function finit(fn, delaiMax = 2000) {
  const fin = Date.now() + lent(delaiMax);
  for (;;) {
    try { return await fn(); }
    catch (e) {
      if (Date.now() > fin) throw e;
      await new Promise((r) => setTimeout(r, 40));
    }
  }
}

/** Médias › « Captures à rattacher » est un KPI dépliable (D-104) : on l'ouvre
 *  au besoin, puis on clique « Rattacher ». */
export async function traiterRattacher(pg) {
  const chip = () => pg.locator(".mediatheque-liste .chip-filtre", { hasText: "Rattacher" }).first();
  if (!(await chip().isVisible().catch(() => false))) {
    await pg.locator(".kpi-filtre").filter({ has: pg.locator(".kpi-libelle", { hasText: "Captures à rattacher" }) }).click();
    await rendu(pg);
  }
  await chip().click();
}

/** Va au MENU « Plus » (D-071) — robuste : si un sous-écran est mémorisé pour
 *  l'onglet, le second appui sur l'onglet actif ramène au menu racine. */
export async function allerMenuPlus(p) {
  const onglet = p.locator(".barre-nav .nav-onglet", { hasText: "Plus" });
  await onglet.click();
  await rendu(p);
  if ((await p.locator(".ecran.plus").count()) === 0) {
    await onglet.click();
    await rendu(p);
  }
  await p.waitForSelector(".ecran.plus");
  // D-084/086 : le parcours exerce les écrans de curation (Médias, Doublons,
  // Diagnostic → mode avancé) ET les relations (fiche + éditeur → vue relation
  // bêta). On active les deux (persistés) pour qu'ils soient accessibles ; les
  // valeurs par défaut (masqué) sont vérifiées à part.
  await p.evaluate(() => {
    const app = document.querySelector("movenso-app");
    if (app && !app.preferences.modeAvance) app.basculerReglage("modeAvance");
    if (app && !app.preferences.vueRelationBeta) app.basculerReglage("vueRelationBeta");
  });
  await rendu(p);
}

/** Ouvre un sous-écran de « Plus » par le titre de sa ligne de menu (D-071).
 *  Titre EXACT (via .ligne-menu-titre) : « Techniques » ne doit pas matcher
 *  « Gérer les relations » (hasText string = sous-chaîne insensible à la
 *  casse — piège post-V3 depuis que « Techniques » est une entrée à part). */
/** S2.10 (accessibilité) : aucun champ visible sans NOM accessible —
 *  aria-label, aria-labelledby ou <label> associé. Balayé aux points de
 *  passage denses (le placeholder seul disparaît à la saisie). */
export async function champsTousNommes(p, contexte) {
  const anonymes = await p.evaluate(() =>
    [...document.querySelectorAll("input:not([type=hidden]):not([type=file]), textarea, select")]
      .filter((el) => el.offsetParent !== null)
      .filter((el) => !el.getAttribute("aria-label") && !el.labels?.length && !el.getAttribute("aria-labelledby"))
      .map((el) => el.outerHTML.slice(0, 90)),
  );
  assert.deepEqual(anonymes, [], `S2.10 : champ(s) sans nom accessible (${contexte}) : ` + anonymes.join(" | "));
}

export async function ouvrirPlus(p, titre) {
  await allerMenuPlus(p);
  const exact = new RegExp(`^${titre.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`);
  await p.locator(".ligne-menu", { has: p.locator(".ligne-menu-titre", { hasText: exact }) }).click();
  await p.waitForSelector(".barre .contexte");
}

/** Glisser-déposer tactile (tuning post-V3) : réordonnancement par pointeur sur
 *  la poignée ⠿ (remplace les flèches Monter/Descendre). Même technique souris
 *  que pour les blocs de composition. `poignee` est déplacée SUR `cible`. */
export async function glisser(p, poignee, cible) {
  const b = await poignee.boundingBox();
  const c = await cible.boundingBox();
  await p.mouse.move(b.x + b.width / 2, b.y + b.height / 2);
  await p.mouse.down();
  await p.mouse.move(c.x + c.width / 2, c.y + c.height / 2, { steps: 12 });
  await p.mouse.up();
}

/** Révèle un petit formulaire de création (post-V3 : la saisie vit derrière un
 *  bouton ＋). Idempotent : ne re-clique pas ＋ si le champ est déjà ouvert (le
 *  ＋ est une bascule et l'état persiste pendant la session). */
export async function revelerCreation(p, ariaLabelPlus, selChamp) {
  if ((await p.locator(selChamp).count()) === 0) {
    await p.locator(`[aria-label="${ariaLabelPlus}"]`).click();
    await p.waitForSelector(selChamp);
  }
}

/** Ouvre une section repliable (Catégories/Niveaux, D-104). Idempotent — le
 *  <details> revient replié à chaque re-render de l'écran. */
export async function ouvrirSection(p, titre) {
  const details = p.locator("details.sous-volet").filter({ has: p.locator("summary .titre-atelier", { hasText: titre }) });
  if (!(await details.evaluate((d) => d.open).catch(() => false))) {
    await details.locator("summary").click();
    await rendu(p);
  }
  return details;
}

/** Ouvre une section repliable puis sa création — le ＋ rouge du volet
 *  (D-308 : uniformisé avec les Disciplines, l'ancien chip texte a disparu). */
export async function ouvrirCreationSection(p, titre, chipTexte, selChamp) {
  const details = await ouvrirSection(p, titre);
  if ((await p.locator(selChamp).count()) === 0) {
    await details.locator(`summary .bouton-plus[aria-label="${chipTexte}"]`).click();
    await p.waitForSelector(selChamp);
  }
}

/** Racine Bibliothèque (deux appuis si l'onglet restaure une sous-destination). */
export async function allerBiblio(p) {
  const onglet = p.locator(".barre-nav .nav-onglet", { hasText: "Bibliothèque" });
  await onglet.click();
  await rendu(p);
  if ((await p.locator(".marque").count()) === 0) {
    await onglet.click();
    await rendu(p);
  }
  await p.waitForSelector(".marque");
}

/** Ouvre l'écran DÉDIÉ d'une discipline. Depuis D-292 sa SEULE porte produit
 *  est la préférence de démarrage (le rapport d'import mène désormais à la
 *  Bibliothèque filtrée) — le harnais emprunte donc le même chemin qu'elle :
 *  poser l'écran, exactement comme le fait le démarrage. */
export async function ouvrirDisc(p, nom) {
  await p.evaluate((n) => {
    const app = document.querySelector("movenso-app");
    const d = app.bibliotheque.disciplines.find((x) => x.nom === n);
    if (d) app.ecran = { type: "discipline", disciplineId: d.id };
  }, nom);
  await p.waitForSelector(".barre .contexte");
}

/** Depuis le panneau « Ajouter » ouvert (tuning post-V3) : le panneau n'offre
 *  plus que « Créer une technique » et « Capture rapide » ; les gestes de
 *  capture (filmer, vidéo, lien, noter) vivent dans la feuille de capture. */
export async function gesteCapture(p, quoi) {
  await p.locator(".option-ajouter", { hasText: "Capture rapide" }).click();
  await p.waitForSelector(".choix-double");
  if (quoi === "note") await p.locator(".choix-double button", { hasText: "Noter" }).click();
  else if (quoi === "lien") await p.locator(".choix-secondaire .action-douce", { hasText: "Coller un lien" }).click();
}
