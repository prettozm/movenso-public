/** Résumé « À vérifier » (D-371) : le pluriel des libellés multi-mots.
 *  Constat checker (D-405) : « texte à arbitrer » se pluralise en tête, pas par
 *  suffixe ; « à classer » est invariable. */

import { test } from "node:test";
import assert from "node:assert/strict";
import { resumeAVerifier } from "../src/app/services/a-verifier.ts";
import type { PostesAVerifier } from "../src/app/services/a-verifier.ts";

/** Construit un `PostesAVerifier` où seuls les compteurs nommés sont non nuls
 *  (le résumé ne lit que les longueurs et `nbDoublons`). */
function postes(o: Partial<Record<"aRattacher" | "sansClasse" | "nbDoublons" | "conflits" | "mediasManquants" | "videosOrphelines", number>>): PostesAVerifier {
  const tab = (n = 0) => new Array(n).fill(0);
  return {
    aRattacher: tab(o.aRattacher),
    sansVideo: [],
    sansClasse: tab(o.sansClasse),
    mediasManquants: tab(o.mediasManquants),
    videosOrphelines: tab(o.videosOrphelines),
    nbDoublons: o.nbDoublons ?? 0,
    conflits: tab(o.conflits),
  } as unknown as PostesAVerifier;
}

test("pluriel : les libellés multi-mots se pluralisent au bon endroit (constat 4)", () => {
  assert.equal(resumeAVerifier(postes({ mediasManquants: 3 })), "3 médias manquants");
  assert.equal(resumeAVerifier(postes({ videosOrphelines: 4 })), "4 vidéos orphelines");
  assert.equal(resumeAVerifier(postes({ conflits: 2 })), "2 textes à arbitrer");
  assert.equal(resumeAVerifier(postes({ nbDoublons: 5 })), "5 doublons");
});

test("singulier : un seul élément garde la forme singulière", () => {
  assert.equal(resumeAVerifier(postes({ mediasManquants: 1 })), "1 média manquant");
  assert.equal(resumeAVerifier(postes({ conflits: 1 })), "1 texte à arbitrer");
  assert.equal(resumeAVerifier(postes({ nbDoublons: 1 })), "1 doublon");
});

test("invariables : « à classer » / « à rattacher » ne prennent pas de s", () => {
  assert.equal(resumeAVerifier(postes({ sansClasse: 3 })), "3 à classer");
  assert.equal(resumeAVerifier(postes({ aRattacher: 2 })), "2 à rattacher");
});

test("les deux postes les plus lourds, séparés par « · », le vide dit « Rien à vérifier »", () => {
  assert.equal(resumeAVerifier(postes({})), "Rien à vérifier");
  // Trois postes non nuls : seuls les deux plus lourds sont retenus, triés décroissant.
  assert.equal(resumeAVerifier(postes({ mediasManquants: 5, conflits: 3, nbDoublons: 1 })), "5 médias manquants · 3 textes à arbitrer");
});
