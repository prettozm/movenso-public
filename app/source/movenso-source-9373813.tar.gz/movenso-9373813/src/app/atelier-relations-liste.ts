/**
 * « Relations existantes » (Plus › Entretenir, D-403) — l'ADMINISTRATION du stock
 * réel de liens, qui manquait. La répartition des rôles est enfin nette :
 * « Types de relations » DÉFINIT le vocabulaire, la Carte / le Parcours EXPLORENT,
 * et ICI on ENTRETIENT — on cherche une technique par son nom, on voit tous ses
 * liens (les deux sens, groupés par rôle), et le ✎ ouvre l'éditeur de lien PARTAGÉ
 * (changer le type, la raison, la priorité, ou « Retirer ce lien »).
 *
 * Aucune logique neuve : détection (`relationsPourFiche`), rendu d'une ligne
 * (`ligneRelation`) et édition (`editerDepuisLigne`) sont ceux de la fiche et de
 * la vue Liste — un seul lieu pour chacun (D-253).
 */
import { html, nothing, type TemplateResult } from "lit";
import type { Bibliotheque, Technique } from "../domaine/modele.ts";
import { relationsPourFiche } from "../domaine/relations.ts";
import { chercherTechniques } from "../domaine/recherche.ts";
import { grouper, trier, iconeRole, classeRole } from "./relations-commun.ts";
import { ligneRelation, editerDepuisLigne } from "./relations-visuelle.ts";
import type { MovensoApp } from "./racine.ts";

/** Recherche en cours — état de SESSION (un geste, pas une préférence). */
let rechercheRelations = "";

/** Combien de techniques reliées l'écran montre avant de demander de préciser. */
const MAX_RESULTATS = 12;

/** Un bloc « technique + ses liens » : en-tête cliquable (→ fiche) puis les
 *  liens groupés par rôle, chacun éditable par le ✎ (D-403). */
function blocTechnique(app: MovensoApp, b: Bibliotheque, t: Technique): TemplateResult {
  const liaisons = relationsPourFiche(b, t.id);
  const disc = b.disciplines.find((d) => d.id === t.disciplineId);
  const groupe = (g: { libelle: string; role: ReturnType<typeof grouper>[number]["role"]; liste: typeof liaisons }) => html`
    <section class="rel-groupe ${classeRole(g.role)}">
      <header class="rel-groupe-tete">${iconeRole(g.role)}<span>${g.libelle}</span><span class="rel-groupe-n">${g.liste.length}</span></header>
      ${trier(app, g.liste).map((l) => ligneRelation(app, b, l, (id) => app.ouvrirFiche(id), () => editerDepuisLigne(app, t.id, l)))}
    </section>`;
  return html`
    <div class="rel-existantes-bloc">
      <button class="rel-existantes-tete" @click=${() => app.ouvrirFiche(t.id)}>
        <span class="rel-existantes-nom">${t.nom}</span>
        <span class="details">${disc?.nom ?? ""} · ${liaisons.length} lien${liaisons.length > 1 ? "s" : ""}</span>
        <span class="chevron" aria-hidden="true">›</span>
      </button>
      <div class="rel-fiche-listes">${grouper(liaisons).map(groupe)}</div>
    </div>`;
}

/** Sous-écran « Relations existantes » : chercher une technique → voir et corriger
 *  ses liens. Réservé aux techniques QUI PORTENT au moins un lien (les autres
 *  n'ont rien à entretenir ici — on crée un lien depuis la fiche, D-156). */
export function ecranRelationsExistantes(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const q = rechercheRelations.trim();
  const nbRel = b.techniques.reduce((n, t) => n + t.relations.length, 0);
  const nbTypes = b.typesRelation.length;
  const trouvees = q ? chercherTechniques(b, q).filter((t) => relationsPourFiche(b, t.id).length > 0) : [];
  return html`
    <div class="carte-atelier" style="gap:0">
      <div class="recherche" style="margin:0 0 8px">
        <input placeholder="Chercher une technique…" aria-label="Chercher une technique"
          .value=${rechercheRelations}
          @input=${(e: InputEvent) => { rechercheRelations = (e.target as HTMLInputElement).value; app.requestUpdate(); }}>
      </div>
      ${!q
        ? html`<p class="fil-vide" style="padding:6px 2px; line-height:1.6">Cherche une technique pour voir et modifier ses liens.
            <br>${nbRel} lien${nbRel > 1 ? "s" : ""} en tout · ${nbTypes} type${nbTypes > 1 ? "s" : ""} de relations.</p>`
        : trouvees.length === 0
          ? html`<p class="fil-vide" style="padding:6px 2px">Aucune technique reliée ne correspond à « ${q} ».</p>`
          : trouvees.slice(0, MAX_RESULTATS).map((t) => blocTechnique(app, b, t))}
      ${q && trouvees.length > MAX_RESULTATS
        ? html`<p class="fil-vide" style="padding:6px 2px">${trouvees.length - MAX_RESULTATS} autre${trouvees.length - MAX_RESULTATS > 1 ? "s" : ""} — précise ta recherche.</p>`
        : nothing}
    </div>`;
}
