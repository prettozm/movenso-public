/**
 * CE QUI DEMANDE UNE ACTION dans la bibliothèque — un seul lieu de calcul
 * (D-253, D-371).
 *
 * Les sept postes de D-107 étaient comptés DEUX FOIS, à l'identique : dans
 * `plus.ts` pour le total du menu, et dans `atelier-medias.ts` pour l'écran.
 * Deux copies de la même règle finissent toujours par diverger — et personne
 * ne le voit, puisqu'elles s'accordent le jour où on les écrit. Le menu et
 * l'écran DÉRIVENT désormais d'ici.
 *
 * Ce que ces postes ne sont PAS : une liste de choses « à compléter ».
 * Certains sont des ARBITRAGES ou des ANOMALIES DE FICHIERS — on ne complète pas
 * un doublon, une vidéo orpheline ou un conflit de texte. C'est pourquoi l'entrée
 * s'appelle « À vérifier » et non « À compléter » (D-371) : le nom d'un agrégat
 * doit être vrai de TOUS ses membres.
 *
 * `sansVideo` est à part (D-379, constat porteur) : une technique sans média
 * n'est PAS incomplète — une fiche texte, une illustration ou un lien suffisent.
 * C'est une SUGGESTION d'enrichissement, jamais une anomalie : elle ne compte
 * donc PAS dans `totalAVerifier` (le badge du menu) ni dans le résumé, pour ne
 * pas fabriquer des centaines de fausses tâches.
 */

import type { Contribution, ConflitContribution, Technique } from "../../domaine/modele.ts";
import type { MovensoApp } from "../racine.ts";

export interface PostesAVerifier {
  aRattacher: Contribution[];
  sansVideo: Technique[];
  sansClasse: Technique[];
  mediasManquants: MovensoApp["mediasManquants"];
  videosOrphelines: MovensoApp["videosOrphelines"];
  nbDoublons: number;
  conflits: ConflitContribution[];
}

export function postesAVerifier(app: MovensoApp): PostesAVerifier {
  const b = app.bibliotheque!;
  const avecMedia = new Set<string>();
  for (const c of b.contributions) if (c.techniqueId && c.medias.length) avecMedia.add(c.techniqueId);
  return {
    aRattacher: b.contributions.filter((c) => c.techniqueId === null),
    sansVideo: b.techniques.filter((t) => !avecMedia.has(t.id)),
    sansClasse: b.techniques.filter((t) => !t.familleId && t.niveauxIds.length === 0),
    mediasManquants: app.mediasManquants,
    videosOrphelines: app.videosOrphelines,
    nbDoublons: app.doublonsPotentiels().length,
    conflits: b.conflitsContributions ?? [],
  };
}

/** Le badge du menu et le résumé ne comptent QUE les vraies anomalies/arbitrages
 *  (D-379) : `sansVideo` est une suggestion d'enrichissement, hors total. */
export function totalAVerifier(p: PostesAVerifier): number {
  return p.aRattacher.length + p.sansClasse.length
    + p.mediasManquants.length + p.videosOrphelines.length + p.nbDoublons + p.conflits.length;
}

/** Le sous-titre du menu (D-371). « 187 à traiter » ne dit pas CE QUI est à
 *  traiter — constat du porteur : « ça ressemble presque à une anomalie
 *  système ». On nomme donc les deux postes les plus lourds, dans leurs mots à
 *  eux, plutôt que d'afficher un total nu. */
export function resumeAVerifier(p: PostesAVerifier): string {
  // Constat checker (D-405) : le pluriel ne s'ajoute PAS par suffixe — « texte à
  // arbitrer » se pluralise en tête (« textes à arbitrer »), « à classer » est
  // invariable. Chaque poste porte donc ses DEUX formes, singulier et pluriel.
  const postes: [number, string, string][] = [
    [p.sansClasse.length, "à classer", "à classer"],
    [p.aRattacher.length, "à rattacher", "à rattacher"],
    [p.nbDoublons, "doublon", "doublons"],
    [p.conflits.length, "texte à arbitrer", "textes à arbitrer"],
    [p.mediasManquants.length, "média manquant", "médias manquants"],
    [p.videosOrphelines.length, "vidéo orpheline", "vidéos orphelines"],
  ];
  const retenus = postes.filter(([n]) => n > 0).sort((a, b) => b[0] - a[0]).slice(0, 2);
  if (retenus.length === 0) return "Rien à vérifier";
  return retenus.map(([n, sing, plur]) => `${n} ${n > 1 ? plur : sing}`).join(" · ");
}
