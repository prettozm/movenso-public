/**
 * Écran « Relations » — navigation par liens techniques (refonte D-135, D-383).
 * TROIS onglets d'UN MÊME graphe, sélectionnables en haut :
 *   • Liste    — chaque lien + sa raison, groupé par type, par priorité (D-134).
 *   • Graphe   — id interne « mindmap » (persistance R3) ; porte DEUX dispositions
 *                du même réseau (D-383) : « structure » (radial, ex-Mind map) et
 *                « reseau » (pan/zoom, D-140), bouton + défaut responsive mémorisé.
 *   • Parcours — entrée guidée par objectif (`explorer`, D-374).
 *
 * Une technique est au CENTRE ; toucher un lien la remplace (recentrage,
 * `relationCentre`) ; la carte centrale ouvre la fiche. L'ÉCRITURE du graphe
 * passe par la feuille « Lien » (D-156, `gabaritEditionLien`) — créer/éditer/
 * retirer une arête avec sa raison et sa priorité — accessible depuis la fiche,
 * la Liste, l'état vide et Plus › Gérer les relations.
 * L'inverse d'un lien est TOUJOURS dérivé (relations.ts) ; la note/priorité de
 * l'arête est réutilisée dans les deux sens.
 */

import { html, nothing, svg, type TemplateResult } from "lit";
import { ref } from "lit/directives/ref.js";
import type { Bibliotheque, Technique, RoleRelation } from "../domaine/modele.ts";
import { relationsPourFiche, type RelationAffichee } from "../domaine/relations.ts";
import { chercherTechniques } from "../domaine/recherche.ts";
import type { MovensoApp } from "./racine.ts";
import { vignetteTechnique } from "./vignette.ts";
import { etat, pousser, historique, reculer, synchroniserHistorique, nomFamille, classeRole, pastilleAlerte, iconeRole, ORDRE_ROLE, grouper, trier, barreDisposition, techniquesReliees, defTypeLien, type Vue, type Tri } from "./relations-commun.ts";
import { vueCarte } from "./relations-carte.ts";
import { vueMindmap } from "./relations-mindmap.ts";
import { vueExplorer } from "./relations-explorer.ts";

/** Fixe le centre de Relations depuis l'écran « point de départ » (R1) : réinit
 *  la recherche puis recentre (persiste, R3 ; l'historique R4 s'y raccorde en
 *  boucle 3). */
function demarrerSur(app: MovensoApp, id: string): void {
  etat.recherche = "";
  etat.bienvenue = false; // choisir un départ referme la bienvenue (D-180)
  pousser(app, id);
}

/** Rouvre l'écran de bienvenue de Relations (D-180) — appelé depuis l'aide
 *  (Plus › À propos). Il se referme en choisissant un départ, ou par
 *  « Reprendre » si un centre existe déjà. */
export function afficherBienvenueRelations(): void {
  etat.bienvenue = true;
}

/** Hydratations une-fois par chargement (R3, D-137/D-383) : onglet et — à part —
 *  disposition du Graphe (séparées : `definirVueRelations` fige l'onglet seul). */
let vueHydratee = false;
let dispoHydratee = false;

/** Fixe l'ONGLET vivant de l'écran (D-138) — appelé par `ouvrirRelationsVisuelle`
 *  depuis la fiche ; fige l'hydratation de l'onglet (jamais celle de la disposition). */
export function definirVueRelations(vue: Vue): void {
  vueHydratee = true;
  etat.vue = vue;
}

export function gabaritRelationsVisuelle(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const vpref = app.preferences.relationsVue as string | undefined;
  if (!vueHydratee) {
    vueHydratee = true;
    // Repli LECTURE (D-373/D-383) : un ancien « classique » se replie sur Graphe/structure ; id inconnu → Liste.
    if (vpref === "liste" || vpref === "mindmap" || vpref === "explorer") etat.vue = vpref;
    else if (vpref === "classique") etat.vue = "mindmap";
  }
  if (!dispoHydratee) {
    dispoHydratee = true;
    // Disposition Graphe : pref d'appareil, sinon défaut responsive (tel → structure, tablette/PC → réseau), D-383.
    const d = app.preferences.relationsDisposition;
    etat.disposition = d === "structure" || d === "reseau" ? d
      : vpref === "classique" ? "structure"
      : window.matchMedia("(min-width: 700px)").matches ? "reseau" : "structure";
  }
  const centreId = app.techniqueCentreRelations();
  const centre = centreId ? app.technique(centreId) : undefined;

  // En-tête ALLÉGÉ (D-384, revue porteur) : titre + la seule loupe (centrer sur
  // une technique cherchée). Les flèches ← / → PERMANENTES sont retirées — le
  // retour devient CONTEXTUEL (chip « ← <précédent> » plus bas) — et le 🎲
  // déménage dans Parcours, où « Surprends-moi » a plus de sens.
  const tete = html`
    <header class="rel-tete">
      <div>
        <div class="rel-titre">Relations</div>
        <div class="rel-sous">Navigation par liens techniques</div>
      </div>
      <div class="rel-tete-actions">
        ${centre
          ? html`<button class="rel-tete-bt ${etat.mmCherche ? "actif" : ""}" @click=${() => { etat.mmCherche = !etat.mmCherche; if (!etat.mmCherche) etat.recherche = ""; app.requestUpdate(); }} aria-label="Rechercher une technique à centrer" title="Rechercher">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
              </button>`
          : nothing}
      </div>
    </header>`;

  // Contrat de navigation déterministe (R1, D-137) : sans centre résolu, on ne
  // renvoie JAMAIS vers la Bibliothèque. Bibliothèque vide → message d'amorce ;
  // sinon → écran de BIENVENUE rendu ICI, dans l'onglet. D-179/D-180 : cet
  // écran ne sert que la toute première visite (ensuite loupe et 🎲
  // recentrent SUR PLACE) — mais il s'explique désormais (règles du jeu,
  // rôle de chaque vue) et se ROUVRE depuis l'aide (Plus › À propos).
  if (!centre || etat.bienvenue) {
    return html`<div class="ecran ecran-relations">
      ${tete}
      ${b.techniques.length === 0
        ? html`<p class="fil-vide" style="padding-top:10px">Aucune technique pour l'instant — ajoute-en d'abord.</p>`
        : html`${centre
            ? html`<button class="chip-filtre rel-bienvenue-reprendre" style="margin:8px 18px 0"
                @click=${() => { etat.bienvenue = false; app.requestUpdate(); }}>← Reprendre sur ${centre.nom}</button>`
            : nothing}
          ${ecranPointDepart(app, b)}`}
    </div>`;
  }

  synchroniserHistorique(centre.id);
  const liaisons = relationsPourFiche(b, centre.id);
  // TROIS onglets (D-383) : Liste · Graphe · Parcours. Le Graphe porte deux
  // dispositions — structure (radial, prend l'écran `mm-plein`) et reseau (pan/zoom).
  const graphe = etat.vue === "mindmap";
  const structure = graphe && etat.disposition === "structure";
  return html`
    <div class="ecran ecran-relations ${structure ? "mm-plein" : ""}">
      ${tete}
      ${barreVues(app)}
      ${graphe ? barreDisposition(app) : nothing}
      ${panneauCentrer(app, b, centre)}
      ${historique.length > 1
        ? html`<button class="rel-retour-ctx" @click=${() => reculer(app)} title="Revenir à la technique précédente">
            ← ${app.technique(historique[historique.length - 2]!)?.nom ?? "Précédente"}</button>`
        : nothing}

      ${etat.vue === "liste" ? carteCentre(app, b, centre, liaisons) : nothing}
      ${etat.vue === "explorer"
        ? vueExplorer(app, b, centre)
        : liaisons.length === 0
          ? html`<div class="rel-vide">
              <p class="fil-vide">Aucun lien pour l'instant.</p>
              <button class="action-douce" @click=${() => app.ouvrirEditionLien(centre.id)}>
                ＋ Créer le premier lien <span>depuis « ${centre.nom} »</span>
              </button>
            </div>`
          : graphe
            ? (structure ? vueMindmap(app, b, centre, liaisons) : vueCarte(app, b, centre, liaisons))
            : vueListe(app, b, liaisons)}
    </div>
  `;
}

/** Écran « Choisis un point de départ » (R1, D-137) : rendu DANS l'onglet
 *  Relations quand aucun centre n'est résolu (jamais de redirection). Recherche
 *  de technique + techniques récemment visitées (si dispo) + favoris + un
 *  départ au hasard sur une technique reliée. Chaque choix fixe le centre. */
function ecranPointDepart(app: MovensoApp, b: Bibliotheque): TemplateResult {
  const req = etat.recherche.trim();
  const resultats = req ? chercherTechniques(b, req, 8) : [];
  const existe = (id: string) => b.techniques.some((t) => t.id === id);

  // Récents : historique de session (R4, du plus récent) puis dernière technique
  // ouverte — dédupliqué, ne garde que les existantes.
  const recents = [...historique.slice().reverse(), ...(app.derniereTechniqueVue ? [app.derniereTechniqueVue] : [])]
    .filter((id, i, arr) => existe(id) && arr.indexOf(id) === i)
    .slice(0, 6);
  const favoris = b.favoris.filter(existe);
  // Départ au hasard : une technique QUI A des liens (sortants ou entrants).
  const reliees = techniquesReliees(b);
  const auHasard = () => {
    if (reliees.length === 0) return;
    const t = reliees[Math.floor(Math.random() * reliees.length)]!;
    demarrerSur(app, t.id);
  };

  const carte = (id: string) => {
    const t = app.technique(id);
    if (!t) return nothing;
    const fam = nomFamille(b, t);
    return html`<button class="rel-depart-item" @click=${() => demarrerSur(app, id)}>
      <span class="rel-depart-media">${vignetteTechnique(app, t)}</span>
      <span class="rel-depart-corps">
        <span class="rel-depart-nom">${t.nom}${pastilleAlerte(app, t.id)}</span>
        ${fam ? html`<span class="rel-depart-fam">${fam}</span>` : nothing}
      </span>
    </button>`;
  };

  return html`
    <div class="rel-depart">
      <!-- D-374 : état SANS centre — simple et invitant (demande porteur), pas la
           longue page « règles du jeu » (déplacée dans l'aide, rubrique Relations).
           Une question, un champ, un dé, quelques récents. -->
      <h2 class="rel-depart-titre">Explore les liens entre tes techniques</h2>
      <p class="rel-depart-sous">Quelle technique veux-tu explorer&nbsp;?</p>

      <h3 class="rel-depart-sec-titre" style="margin-top:14px">Choisis un point de départ</h3>

      <div class="recherche" style="margin:12px 0 0">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
        <input type="search" placeholder="Chercher une technique…" .value=${etat.recherche}
               aria-label="Chercher une technique de départ"
               @input=${(e: InputEvent) => { etat.recherche = (e.target as HTMLInputElement).value; app.requestUpdate(); }}>
      </div>
      ${req
        ? resultats.length
          ? html`<div class="rel-depart-liste">${resultats.map((t) => carte(t.id))}</div>`
          : html`<p class="fil-vide" style="padding-top:10px">Aucune technique ne correspond.</p>`
        : nothing}

      ${!req && recents.length
        ? html`<section class="rel-depart-sec">
            <h3 class="rel-depart-sec-titre">Récemment consultées</h3>
            <div class="rel-depart-liste">${recents.map((id) => carte(id))}</div>
          </section>`
        : nothing}

      ${!req && favoris.length
        ? html`<section class="rel-depart-sec">
            <h3 class="rel-depart-sec-titre">Favoris</h3>
            <div class="rel-depart-chips">${favoris.map((id) => chipFavori(app, id))}</div>
          </section>`
        : nothing}

      ${reliees.length
        ? html`<button class="rel-depart-hasard" @click=${auHasard}>🎲 Surprends-moi</button>`
        : nothing}
    </div>
  `;
}

/** Chip d'un favori sur l'écran « point de départ » (R2, D-138) : plus léger
 *  qu'une carte, conforme à la maquette. Démarre le centre sur la technique. */
function chipFavori(app: MovensoApp, id: string): TemplateResult {
  const t = app.technique(id);
  if (!t) return nothing as unknown as TemplateResult;
  return html`<button class="rel-depart-chip" @click=${() => demarrerSur(app, id)}>${t.nom}${pastilleAlerte(app, id)}</button>`;
}

/** Sélecteur d'onglets (segmenté) — TROIS lectures d'un même graphe (D-383). */
function barreVues(app: MovensoApp): TemplateResult {
  // « Graphe » garde l'id « mindmap » (persistance R3) ; la Mind map radiale n'est plus un onglet mais une disposition (barreDisposition).
  const onglets: { id: Vue; nom: string }[] = [
    { id: "liste", nom: "Liste" },
    { id: "mindmap", nom: "Graphe" },
    { id: "explorer", nom: "Parcours" },
  ];
  return html`
    <div class="rel-vues" role="tablist" aria-label="Vue des relations">
      ${onglets.map(
        (o) => html`<button role="tab" aria-selected=${etat.vue === o.id} class="rel-vue-onglet ${etat.vue === o.id ? "actif" : ""}"
          @click=${() => { etat.vue = o.id; etat.plein = false; app.enregistrerRelationsUi({ relationsVue: o.id }); app.requestUpdate(); }}>${o.nom}</button>`,
      )}
    </div>
  `;
}

/** Panneau « Centrer sur… » PARTAGÉ par les trois onglets (S3.D1/D-179) —
 *  ouvert par la loupe de l'en-tête, compact, résultats en chips ; remplace
 *  l'ancienne barre inline propre aux vues Liste/Carte/Explorer. */
function panneauCentrer(app: MovensoApp, b: Bibliotheque, centre: Technique): TemplateResult | typeof nothing {
  if (!etat.mmCherche) return nothing;
  const req = etat.recherche.trim();
  const resultats = req ? chercherTechniques(b, req, 8).filter((t) => t.id !== centre.id) : [];
  return html`<div class="rel-mm-cherche">
    <div class="rel-mm-recherche">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
      <input type="search" placeholder="Centrer sur une technique…" .value=${etat.recherche} autofocus
             aria-label="Centrer sur une autre technique"
             @input=${(e: InputEvent) => { etat.recherche = (e.target as HTMLInputElement).value; app.requestUpdate(); }}>
    </div>
    ${resultats.length
      ? html`<div class="rel-mm-res">${resultats.map(
          (t) => html`<button class="chip-filtre" @click=${() => { etat.recherche = ""; etat.mmCherche = false; etat.filtre = null; pousser(app, t.id); }}>${t.nom}</button>`,
        )}</div>`
      : nothing}
  </div>`;
}

/** Compaction au défilement (R14, D-138) : après un premier scroll, la carte
 *  centrale (collante) se réduit en bandeau compact. Le listener global est posé
 *  une seule fois ; il agit sur `.rel-centre` présent, no-op sinon. */
let compactionInstallee = false;
function installerCompaction(el?: Element): void {
  if (!el) return;
  const maj = () => { document.querySelector(".rel-centre")?.classList.toggle("compacte", window.scrollY > 48); };
  maj();
  if (!compactionInstallee) { compactionInstallee = true; window.addEventListener("scroll", maj, { passive: true }); }
}

/** Carte de la technique centrale : image + nom + compte. Ouvre la fiche.
 *  Collante en tête (R14) ; se compacte au défilement. */
function carteCentre(app: MovensoApp, b: Bibliotheque, centre: Technique, liaisons: RelationAffichee[]): TemplateResult {
  const fam = nomFamille(b, centre);
  const nbRelies = new Set(liaisons.map((l) => l.techniqueId)).size;
  return html`
    <button class="rel-centre" ${ref(installerCompaction)} @click=${() => app.ouvrirFiche(centre.id)} title="Voir la fiche">
      <span class="rel-centre-media">${vignetteTechnique(app, centre)}</span>
      <span class="rel-centre-txt">
        <span class="rel-centre-nom">${centre.nom}${pastilleAlerte(app, centre.id)}</span>
        ${fam ? html`<span class="rel-centre-fam">${fam}</span>` : nothing}
        <span class="rel-centre-compte">${nbRelies ? `${nbRelies} technique${nbRelies > 1 ? "s" : ""} reliée${nbRelies > 1 ? "s" : ""}` : "aucun lien"}</span>
        <span class="rel-centre-voir">Voir la fiche ›</span>
      </span>
    </button>
  `;
}

/** ---- Vue LISTE (boucle 1) : groupes filtrables + raisons + tri pertinence. ---- */
function vueListe(app: MovensoApp, b: Bibliotheque, liaisons: RelationAffichee[]): TemplateResult {
  const groupes = grouper(liaisons);
  const filtreValide = etat.filtre && groupes.some((g) => g.libelle === etat.filtre) ? etat.filtre : null;
  const visibles = filtreValide ? groupes.filter((g) => g.libelle === filtreValide) : groupes;

  // R14 : à la sélection, ramène le filtre actif dans la vue (défilement horizontal
  //  sans barre grise permanente — cf. CSS). Posé sur tous les chips ; ne défile que
  //  celui qui porte « actif » (classe appliquée avant le ref dans le même rendu).
  const versActif = (el?: Element) => {
    const e = el as HTMLElement | undefined;
    if (e?.classList.contains("actif")) e.scrollIntoView({ inline: "center", block: "nearest" });
  };
  return html`
    <div class="rel-filtres">
      <button class="rel-chip ${filtreValide === null ? "actif" : ""}" ${ref(versActif)}
        @click=${() => { etat.filtre = null; app.requestUpdate(); }}>
        Toutes <span class="rel-chip-n">${liaisons.length}</span>
      </button>
      ${groupes.map(
        (g) => html`<button class="rel-chip ${classeRole(g.role)} ${filtreValide === g.libelle ? "actif" : ""}" ${ref(versActif)}
          @click=${() => { etat.filtre = filtreValide === g.libelle ? null : g.libelle; app.requestUpdate(); }}>
          ${g.libelle} <span class="rel-chip-n">${g.liste.length}</span>
        </button>`,
      )}
    </div>

    <div class="rel-tri">
      <!-- D-385 : le libellé « Tri · Priorité » disparaît — le tri par priorité EST
           le fonctionnement normal (D-374), une information non actionnable n'a pas
           à occuper l'écran (demande porteur). Reste la seule action : ＋ Ajouter. -->
      <button class="rel-tri-ajouter" @click=${() => { const c = app.techniqueCentreRelations(); if (c) app.ouvrirEditionLien(c); }}
        title="Créer un lien depuis la technique centrale">＋ Ajouter un lien</button>
    </div>

    <div class="rel-listes">
      ${visibles.map(
        (g) => html`<section class="rel-groupe ${classeRole(g.role)}">
          <header class="rel-groupe-tete">${iconeRole(g.role)}<span>${g.libelle}</span><span class="rel-groupe-n">${g.liste.length}</span></header>
          ${trier(app, g.liste).map((l) => ligneListe(app, b, l))}
        </section>`,
      )}
    </div>
  `;
}

/* ---------- Feuille « Lien » (D-156) : créer / éditer une relation ---------- */

/** Formulaire vivant de la feuille (état module, réinitialisé à l'ouverture). */
const lienForm: {
  hydrate: boolean; typeId: string;
  sourceId: string | null; sourceRequete: string;
  cibleId: string | null; cibleRequete: string;
  note: string; priorite: number | undefined;
} = { hydrate: false, typeId: "", sourceId: null, sourceRequete: "", cibleId: null, cibleRequete: "", note: "", priorite: undefined };

/** Réinitialise le formulaire (appelé par `ouvrirEditionLien` avant ouverture). */
export function reinitEditionLien(): void {
  lienForm.hydrate = false;
}

/** Feuille bas d'écran « Lien » : source (fixe ou à chercher) → type (chips) →
 *  cible (recherche) → raison → priorité. En édition : champs pré-remplis +
 *  « Retirer ce lien ». L'inverse n'est jamais saisi (dérivé, contrat §2.1). */
export function gabaritEditionLien(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const e = app.editionLien!;
  const edition = e.cibleId !== undefined && e.typeId !== undefined;

  if (!lienForm.hydrate) {
    lienForm.hydrate = true;
    lienForm.sourceId = e.sourceId;
    lienForm.sourceRequete = "";
    lienForm.cibleId = e.cibleId ?? null;
    lienForm.cibleRequete = "";
    lienForm.typeId = e.typeId ?? e.typePrefere ?? b.typesRelation[0]?.id ?? "";
    const r = edition
      ? b.techniques.find((t) => t.id === e.sourceId)?.relations.find((x) => x.type === e.typeId && x.cibleId === e.cibleId)
      : undefined;
    lienForm.note = r?.note ?? "";
    lienForm.priorite = r?.priorite;
  }

  const fermer = () => { app.editionLien = null; app.requestUpdate(); };
  const source = lienForm.sourceId ? app.technique(lienForm.sourceId) : undefined;
  const cible = lienForm.cibleId ? app.technique(lienForm.cibleId) : undefined;
  const pret = !!source && !!cible && lienForm.typeId !== "" && source.id !== cible.id;

  const enregistrer = async () => {
    if (!pret || !source || !cible) return;
    const note = lienForm.note.trim();
    let ok: boolean;
    if (edition) {
      ok = await app.modifierRelation(e.sourceId!, e.cibleId!, e.typeId!, {
        type: lienForm.typeId, note: note === "" ? null : note, priorite: lienForm.priorite ?? null,
      });
    } else {
      ok = await app.ajouterRelation(source.id, {
        type: lienForm.typeId, cibleId: cible.id,
        ...(note !== "" ? { note } : {}),
        ...(lienForm.priorite !== undefined ? { priorite: lienForm.priorite } : {}),
      });
    }
    if (ok) fermer();
  };
  const retirer = () => {
    app.demanderConfirmation({
      titre: "Retirer ce lien ?",
      corps: "Les deux lectures (directe et inverse) disparaissent.",
      bouton: "Retirer le lien",
      action: () => { void app.retirerRelation(e.sourceId!, e.cibleId!, e.typeId!).then(() => fermer()); },
    });
  };

  /** Bloc de choix d'une technique (source ou cible) : soit fixée (résumé),
   *  soit recherche + résultats. */
  const choixTechnique = (
    role: "source" | "cible",
    fixe: Technique | undefined,
    requete: string,
    surRequete: (v: string) => void,
    surChoix: (t: Technique) => void,
    verrouille: boolean,
  ): TemplateResult => {
    if (fixe && verrouille) {
      return html`<div class="lien-fixe"><b>${fixe.nom}</b>${nomFamille(b, fixe) ? html` <span class="lien-fixe-fam">· ${nomFamille(b, fixe)}</span>` : nothing}</div>`;
    }
    if (fixe) {
      return html`<div class="lien-fixe">
        <b>${fixe.nom}</b>${nomFamille(b, fixe) ? html` <span class="lien-fixe-fam">· ${nomFamille(b, fixe)}</span>` : nothing}
        <button class="chip-filtre" style="margin-left:auto" @click=${() => { surChoix(undefined as unknown as Technique); }}>changer</button>
      </div>`;
    }
    const resultats = requete.trim() ? chercherTechniques(b, requete, 6).filter((t) => t.id !== (role === "cible" ? lienForm.sourceId : lienForm.cibleId)) : [];
    return html`
      <div class="recherche" style="margin:4px 0 0">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>
        <input type="search" placeholder=${role === "source" ? "Technique de départ…" : "Technique liée…"} .value=${requete}
               aria-label=${role === "source" ? "Chercher la technique de départ" : "Chercher la technique liée"}
               @input=${(ev: InputEvent) => { surRequete((ev.target as HTMLInputElement).value); app.requestUpdate(); }}>
      </div>
      ${resultats.length
        ? html`<div class="chips-filtres" style="padding:6px 0 0">
            ${resultats.map((t) => html`<button class="chip-filtre" @click=${() => { surChoix(t); app.requestUpdate(); }}>${t.nom}</button>`)}
          </div>`
        : nothing}
    `;
  };

  return html`
    <div class="voile" @click=${fermer}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label=${edition ? "Modifier le lien" : "Nouveau lien"}>
      <div class="prise"></div>
      <h2>${edition ? "Modifier le lien" : "Nouveau lien"}</h2>

      <div class="section-titre" style="padding:10px 0 4px">Depuis</div>
      ${choixTechnique("source", source, lienForm.sourceRequete,
        (v) => { lienForm.sourceRequete = v; },
        (t) => { lienForm.sourceId = t ? t.id : null; lienForm.sourceRequete = ""; },
        edition || e.sourceId !== null)}

      <div class="section-titre" style="padding:12px 0 4px">Type de lien</div>
      <div class="chips-filtres" style="padding:0">
        ${b.typesRelation.map((t) => html`<button class="chip-filtre ${lienForm.typeId === t.id ? "actif" : ""}"
          @click=${() => { lienForm.typeId = t.id; app.requestUpdate(); }}>${t.libelle}${t.symetrique ? " ⇄" : ""}</button>`)}
      </div>
      ${defTypeLien(b.typesRelation.find((x) => x.id === lienForm.typeId))}

      <div class="section-titre" style="padding:12px 0 4px">Vers</div>
      ${choixTechnique("cible", cible, lienForm.cibleRequete,
        (v) => { lienForm.cibleRequete = v; },
        (t) => { lienForm.cibleId = t ? t.id : null; lienForm.cibleRequete = ""; },
        edition)}

      <div class="section-titre" style="padding:12px 0 4px">Raison <span style="font-weight:400;opacity:.7">(facultatif)</span></div>
      <textarea class="champ-note" style="min-height:64px" placeholder="Pourquoi ce lien ? (ex. : continuation directe lorsque le fauchage reste engagé…)"
        .value=${lienForm.note} aria-label="Raison du lien"
        @input=${(ev: InputEvent) => { lienForm.note = (ev.target as HTMLTextAreaElement).value; }}></textarea>

      <div class="section-titre" style="padding:12px 0 4px">Ordre d'affichage <span style="font-weight:400;opacity:.7">(facultatif)</span></div>
      <div class="chips-filtres" style="padding:0">
        ${[1, 2, 3, 4, 5].map((n) => html`<button class="chip-filtre ${lienForm.priorite === n ? "actif" : ""}"
          @click=${() => { lienForm.priorite = lienForm.priorite === n ? undefined : n; app.requestUpdate(); }}>${n}</button>`)}
        <button class="chip-filtre ${lienForm.priorite === undefined ? "actif" : ""}"
          @click=${() => { lienForm.priorite = undefined; app.requestUpdate(); }}>aucune</button>
      </div>

      <div class="actions" style="margin-top:14px">
        ${edition ? html`<button class="bouton danger-lien" @click=${retirer}>Retirer ce lien</button>` : nothing}
        <button class="bouton" @click=${fermer}>Annuler</button>
        <button class="bouton principal" ?disabled=${!pret} @click=${() => void enregistrer()}>${edition ? "Enregistrer" : "Ajouter"}</button>
      </div>
    </div>
  `;
}

/** Ouvre la feuille « Lien » en ÉDITION depuis une ligne affichée (D-156) : si
 *  la ligne est un sens DÉRIVÉ, on édite l'arête stockée chez l'autre technique
 *  (la raison est partagée par les deux sens — c'est l'arête qui la porte). */
export function editerDepuisLigne(app: MovensoApp, ficheId: string, l: RelationAffichee): void {
  const sourceId = l.directe ? ficheId : l.techniqueId;
  const cibleId = l.directe ? l.techniqueId : ficheId;
  app.ouvrirEditionLien(sourceId, cibleId, l.typeId);
}

/** Rendu PARTAGÉ d'une ligne de relation (D-138 R5/R19) : vignette + nom/famille
 *  + raison + chevron. `onActiver` décide de l'action au clic : dans la Liste,
 *  recentrer ; dans la fiche, ouvrir la fiche cible. `onEditer` (D-156) ajoute
 *  un crayon ✎ discret qui ouvre la feuille « Lien ». */
export function ligneRelation(
  app: MovensoApp,
  b: Bibliotheque,
  l: RelationAffichee,
  onActiver: (id: string) => void,
  onEditer?: () => void,
): TemplateResult {
  const t = app.technique(l.techniqueId);
  if (!l.presente || !t) {
    return html`<div class="rel-ligne absente"><span class="rel-ligne-nom">absente de la bibliothèque</span></div>`;
  }
  const fam = nomFamille(b, t);
  return html`
    <div class="rel-ligne-conteneur">
      <button class="rel-ligne" @click=${() => onActiver(t.id)}>
        <span class="rel-ligne-media">${vignetteTechnique(app, t)}</span>
        <span class="rel-ligne-corps">
          <span class="rel-ligne-nom">${t.nom}${pastilleAlerte(app, t.id)}</span>
          ${fam ? html`<span class="rel-ligne-fam">${fam}</span>` : nothing}
        </span>
        ${l.note ? html`<span class="rel-ligne-note">${l.note}</span>` : nothing}
        <span class="rel-ligne-fleche">›</span>
      </button>
      ${onEditer
        ? html`<button class="rel-ligne-editer" aria-label="Modifier ce lien" title="Modifier ce lien"
            @click=${(ev: Event) => { ev.stopPropagation(); onEditer(); }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
          </button>`
        : nothing}
    </div>
  `;
}

/** Une ligne de la vue Liste : recentre au clic ; ✎ édite l'arête (D-156). */
function ligneListe(app: MovensoApp, b: Bibliotheque, l: RelationAffichee): TemplateResult {
  const centreId = app.techniqueCentreRelations();
  return ligneRelation(app, b, l, (id) => { etat.filtre = null; pousser(app, id); },
    centreId ? () => editerDepuisLigne(app, centreId, l) : undefined);
}

/** Section « Relations » de la FICHE (D-138 R5/R19) — réutilise la logique de la
 *  vue Liste (groupée par rôle, couleur/icône par rôle, raison de chaque lien)
 *  en APERÇU compact (≈2 liens par rôle). Une ligne ouvre la fiche cible. Le rôle
 *  `context` (« Présente dans ») est présenté à part. Deux sorties distinctes :
 *  l'icône réseau de la barre du haut ouvre la Carte ; « Voir toutes les
 *  relations » ouvre l'écran Relations en Liste, centré sur la technique. */
const APERCU_FICHE = 2; // liens montrés par rôle dans la fiche
export function sectionRelationsFiche(app: MovensoApp, b: Bibliotheque, t: Technique): TemplateResult {
  const liaisons = relationsPourFiche(b, t.id);
  // Même sans lien, la fiche offre la CRÉATION (D-156) — sinon l'éditeur n'aurait aucune porte d'entrée sur une technique isolée.
  if (liaisons.length === 0)
    return html`
      <section class="bloc-lecture relations-fiche">
        <h2 class="section-titre">Relations</h2>
        <p class="section-vide">Cette technique n'est liée à aucune autre.</p>
        <button class="action-douce rel-fiche-lien" @click=${() => app.ouvrirEditionLien(t.id)}>＋ Ajouter un lien <span>relie cette technique à une autre</span></button>
      </section>`;
  const groupes = grouper(liaisons);
  const principaux = groupes.filter((g) => g.role !== "context");
  const contexte = groupes.filter((g) => g.role === "context");

  const groupe = (g: { libelle: string; role: RoleRelation; liste: RelationAffichee[] }) => html`
    <section class="rel-groupe ${classeRole(g.role)}">
      <header class="rel-groupe-tete">${iconeRole(g.role)}<span>${g.libelle}</span><span class="rel-groupe-n">${g.liste.length}</span></header>
      ${trier(app, g.liste).slice(0, APERCU_FICHE).map((l) => ligneRelation(app, b, l, (id) => app.ouvrirFiche(id), () => editerDepuisLigne(app, t.id, l)))}
    </section>`;

  return html`
    <section class="bloc-lecture relations-fiche">
      <h2 class="section-titre">Relations · ${liaisons.length}</h2>
      <div class="rel-fiche-listes">
        ${principaux.map(groupe)}
      </div>
      ${contexte.length
        ? html`<div class="rel-fiche-contexte">
            <!-- Chapeau omis quand l'unique groupe porte déjà ce nom : l'écrire deux fois ne range rien, ça bégaie. -->
            ${contexte.length === 1 && contexte[0]!.libelle.toLowerCase() === "présente dans" ? nothing : html`<div class="rel-fiche-contexte-titre">Présente dans</div>`}
            ${contexte.map(groupe)}
          </div>`
        : nothing}
      <button class="action-douce rel-fiche-lien" @click=${() => app.ouvrirEditionLien(t.id)}>
        ＋ Ajouter un lien <span>type, technique liée, raison, priorité</span>
      </button>
      <button class="action-douce rel-fiche-toutes" @click=${() => app.ouvrirRelationsVisuelle(t.id, "liste")}>
        Voir toutes les relations <span>(${liaisons.length})</span>
      </button>
    </section>
  `;
}
