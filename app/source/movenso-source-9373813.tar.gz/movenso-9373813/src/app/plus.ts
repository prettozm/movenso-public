/**
 * « Plus » (D-071) — remplace l'Atelier : un MENU simple de réglages et de
 * gestion, sans accordéons ni tableau de bord. Chaque ligne (icône + titre +
 * état court + chevron) ouvre un sous-écran spécialisé. Aucun vocabulaire
 * technique interne ; les explications vivent dans les sous-écrans, jamais ici.
 */

import { html, nothing, type TemplateResult } from "lit";
import type { MovensoApp, SectionPlus } from "./racine.ts";
import { ecranPacksOfficiels } from "./packs-officiels-vue.ts";
import { titreSujetCourant } from "./aide-contenu.ts";
import { sourceDe } from "../domaine/modele.ts";
import { ecranRelationsExistantes } from "./atelier-relations-liste.ts";
import { postesAVerifier, resumeAVerifier } from "./services/a-verifier.ts";
import { VERSION } from "./version.ts";
import {
  ecranApparence,
  ecranAide,
  ecranAideSujet,
  ecranAvance,
  ecranApropos,
  ecranATraiter,
  ecranCorbeille,
  ecranDiagnostic,
  ecranDoublons,
  ecranMedias,
  ecranPacksDisciplines,
  ecranPublier,
  ecranRelations,
  ecranSauvegardes,
  ecranStockage,
  ecranSecurite,
  ecranTechniques,
} from "./atelier.ts";

const TITRES: Record<SectionPlus, string> = {
  packs: "Disciplines & classement",
  techniques: "Techniques",
  atraiter: "À vérifier",
  doublons: "Doublons potentiels",
  medias: "Médias",
  relations: "Types de relations",
  "relations-existantes": "Relations existantes",
  corbeille: "Corbeille",
  "packs-officiels": "Starter packs",
  publier: "Créer / exporter un pack",
  sauvegardes: "Sauvegardes",
  stockage: "Stockage",
  securite: "Sécurité",
  apparence: "Apparence",
  avance: "Fonctions avancées",
  diagnostic: "Diagnostic et maintenance",
  apropos: "Aide & à propos",
  aide: "Aide",
  // Titre DYNAMIQUE : il suit la rubrique ouverte (`titreSujetCourant`).
  "aide-sujet": "",
};

function contenuSection(app: MovensoApp, section: SectionPlus): TemplateResult {
  switch (section) {
    case "packs": return ecranPacksDisciplines(app);
    case "stockage": return ecranStockage(app);
    case "aide": return ecranAide(app);
    case "aide-sujet": return ecranAideSujet(app);
    case "techniques": return ecranTechniques(app);
    case "atraiter": return ecranATraiter(app);
    case "doublons": return ecranDoublons(app);
    case "medias": return ecranMedias(app);
    case "relations": return ecranRelations(app);
    case "relations-existantes": return ecranRelationsExistantes(app);
    case "corbeille": return ecranCorbeille(app);
    case "packs-officiels":
      // D-333 : les éditions POSÉES sur cet appareil (D-307) décident de
      // « Installé » et de « Mise à jour disponible ».
      return ecranPacksOfficiels(app.catalogueOfficiel, {
        installer: (e) => void app.installerPackOfficiel(e),
        recharger: () => app.rechargerCataloguePacks(),
      }, app.bibliotheque?.editionsPacks ?? []);
    case "publier": return ecranPublier(app);
    case "sauvegardes": return ecranSauvegardes(app);
    case "securite": return ecranSecurite(app);
    case "apparence": return ecranApparence(app);
    case "avance": return ecranAvance(app);
    case "diagnostic": return ecranDiagnostic(app);
    case "apropos": return ecranApropos(app);
  }
}

/** Sous-écran d'une entrée de « Plus » : titre simple, retour, ses seules
 *  fonctions. */
export function gabaritPlusSection(app: MovensoApp, section: SectionPlus): TemplateResult {
  return html`
    <div class="ecran">
      <div class="barre">
        <button class="bouton-icone" aria-label="Retour" @click=${() => app.retour()}>
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M15 5l-7 7 7 7"/></svg>
        </button>
        <span class="contexte">${section === "aide-sujet" ? titreSujetCourant(app) : TITRES[section]}</span>
      </div>
      ${contenuSection(app, section)}
    </div>
  `;
}

/* ---------- le menu ---------- */

/** Les objets de la série « Plus » (D-371). Quatorze illustrations du même
 *  atelier que celles de l'aide et des départs — même angle, mêmes matières,
 *  même palette. Elles remplacent quinze emoji de provenances visuelles
 *  différentes (fonds blancs, pastel, bleu sombre, emoji 3D, pictogrammes
 *  plats), qui donnaient au menu un air de bricolage Android que le reste du
 *  produit n'a plus. */
type CleIcone =
  | "disciplines" | "techniques" | "relations" | "verifier" | "corbeille"
  | "starter-packs" | "importer" | "exporter"
  | "sauvegardes" | "stockage" | "securite" | "medias" | "doublons" | "diagnostic"
  | "apparence" | "avance" | "apropos";

/** 192 px suffisent ici, et c'est MESURÉ, pas repris d'une convention : une
 *  icône se rend à 44 px CSS, soit 132 px physiques sur un téléphone DPR 3.
 *  Les héros de l'aide, eux, demandaient 640 px (D-367) — le nombre suit
 *  l'usage, jamais l'inverse. */
function icone(cle: CleIcone): TemplateResult {
  return html`<img class="ligne-menu-icone" src="./img/plus-${cle}.webp" alt="" aria-hidden="true"
    width="192" height="192" decoding="async">`;
}

/** Date de sauvegarde en langue humaine (D-371) : l'ISO est parfait dans un
 *  nom de fichier, illisible dans un menu. Le nom porte l'horodatage UTC avec
 *  les « : » remplacés par des « - » (`opfs.ts:388`) — on les remet pour que
 *  `Date` le lise, et l'affichage repasse en heure LOCALE. */
function dateHumaine(nomFichier: string): string {
  const brut = nomFichier.replace(".json", "").split("__")[0] ?? "";
  const iso = brut.replace(/T(\d{2})-(\d{2})-(\d{2})/, "T$1:$2:$3");
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return brut.slice(0, 10);
  const heure = d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  const jour = new Date(d); jour.setHours(0, 0, 0, 0);
  const aujourdhui = new Date(); aujourdhui.setHours(0, 0, 0, 0);
  const ecart = Math.round((aujourdhui.getTime() - jour.getTime()) / 86_400_000);
  if (ecart === 0) return `aujourd’hui, ${heure}`;
  if (ecart === 1) return `hier, ${heure}`;
  return `${d.toLocaleDateString("fr-FR", { day: "numeric", month: "long" })}, ${heure}`;
}

interface EntreeMenu {
  section?: SectionPlus;
  action?: (app: MovensoApp) => void;
  icone: CleIcone;
  titre: string;
  etat?: string;
}

/** Les CINQ groupes de « Plus » (D-371). Ils ne rangent plus par « ce qui
 *  restait à ranger » mais par TROIS CONCEPTS, puis le confort :
 *  ce que je possède · ce qui entre et sort · ce qui me protège — puis les
 *  préférences, puis Movenso. Sauvegardes et Sécurité quittent respectivement
 *  l'échange et les préférences : elles parlent de la CONSERVATION des données,
 *  pas de leur circulation ni du confort. */
function etatsMenu(app: MovensoApp): {
  organiser: EntreeMenu[];
  entretenir: EntreeMenu[];
  partage: EntreeMenu[];
  donnees: EntreeMenu[];
  preferences: EntreeMenu[];
  movenso: EntreeMenu[];
} {
  const b = app.bibliotheque!;
  const sources = new Set<string>();
  for (const t of b.techniques) if (sourceDe(t) !== "local") sources.add(sourceDe(t));
  for (const c of b.contributions) if (sourceDe(c) !== "local") sources.add(sourceDe(c));
  const nbPacks = sources.size;
  const nbDisc = b.disciplines.length;
  const nbTech = b.techniques.length;
  const nbCat = b.disciplines.reduce((n, d) => n + d.familles.length, 0);
  const nbNiv = b.disciplines.reduce((n, d) => n + d.niveaux.length, 0);

  const nbDoublons = app.doublonsPotentiels().length;

  const nbFichiers = app.taillesVideos.size;
  // « À vérifier » (D-107, D-371) : les sept postes se comptent dans
  // `services/a-verifier.ts` — ici on ne fait qu'en dériver le résumé.
  const postes = postesAVerifier(app);

  const nbTypes = b.typesRelation.length;
  const nbRel = b.techniques.reduce((n, t) => n + t.relations.length, 0);
  const nbCorbeille = (b.corbeille ?? []).length;

  const dernier = app.sauvegardes[0];
  const dateSauv = dernier ? dateHumaine(dernier) : "";

  const info = app.infoEspace;
  const espaceUtilise = info
    ? info.usage >= 1_000_000 ? `${(info.usage / 1_000_000).toFixed(1)} Mo utilisés` : `${Math.max(1, Math.round(info.usage / 1000))} Ko utilisés`
    : "";
  const p = app.preferences.protections;
  const secu = p && (p.modifications || p.suppressions) ? "PIN actif · modifications protégées" : "PIN désactivé · modifications libres";
  const theme = app.preferences.theme ?? "auto";
  const themeLisible = theme === "auto" ? "Auto · système" : theme === "clair" ? "Jour" : "Nuit";

  // Mode avancé (D-084) : les outils de curation/maintenance ne s'affichent que
  // s'il est activé — surface du pratiquant sobre par défaut.
  const av = app.preferences.modeAvance ?? false;
  const actives = [
    av ? "Mode avancé" : null,
    (app.preferences.vueRelationBeta ?? false) ? "Relations" : null,
    (app.preferences.compositionsBeta ?? false) ? "Compositions" : null,
  ].filter(Boolean);
  const etatAvance = actives.length ? actives.join(" · ") : "Rien d'activé";
  // Relations : les VUES visuelles restent sous « Vue relation (bêta) »
  // (D-086), mais la GESTION — arbitrages de liaisons, retraits proposés —
  // est toujours accessible (D-296) : le rapport d'installation y pointe,
  // elle est le complément obligatoire de D-243, pas une expérimentation.
  return {
    // D-399 : deux blocs distincts (revue porteur, passe Plus §1). « Organiser »
    // répond à « comment ma bibliothèque est-elle structurée ? » — « Entretenir »
    // à « qu'est-ce qui existe dedans et réclame une intervention ? ». La ligne
    // de partage : la STRUCTURE d'un côté, l'ADMINISTRATION du stock réel de
    // l'autre. Médias (le parc) est de l'organisation ; Doublons et Corbeille
    // sont de l'entretien.
    organiser: [
      { section: "packs", icone: "disciplines", titre: "Disciplines & classement",
        etat: `${nbDisc} discipline${nbDisc > 1 ? "s" : ""} · ${nbCat} catégorie${nbCat > 1 ? "s" : ""} · ${nbNiv} niveau${nbNiv > 1 ? "x" : ""}` },
      { section: "techniques", icone: "techniques", titre: "Techniques",
        etat: `${nbTech} technique${nbTech > 1 ? "s" : ""}` },
      // « Types de relations » (D-399) : cet écran DÉFINIT le vocabulaire des
      // liens (Prépare / Contre / Enchaîne…), il n'administre pas le stock réel
      // — c'est « Relations existantes », dans Entretenir, qui le fait. On compte
      // donc les TYPES, plus les relations.
      { section: "relations", icone: "relations", titre: "Types de relations",
        etat: `${nbTypes} type${nbTypes > 1 ? "s" : ""}` },
      ...(av
        ? [{ section: "medias" as const, icone: "medias" as const, titre: "Médias",
             etat: nbFichiers ? `${nbFichiers} vidéo${nbFichiers > 1 ? "s" : ""} locale${nbFichiers > 1 ? "s" : ""}` : "Parc de médias" }]
        : []),
    ],
    // « Entretenir » : ce qui existe vraiment et réclame une intervention.
    // « Relations existantes » (D-403) est l'admin du STOCK réel de liens —
    // à distinguer de « Types de relations » (le vocabulaire, dans Organiser).
    // Gated avancé, comme Doublons/Médias (outil de curation). Icône partagée
    // avec « Types de relations » faute d'illustration dédiée — à fournir.
    entretenir: [
      ...(av
        ? [{ section: "relations-existantes" as const, icone: "relations" as const, titre: "Relations existantes",
             etat: `${nbRel} lien${nbRel > 1 ? "s" : ""}` }]
        : []),
      { section: "atraiter", icone: "verifier", titre: "À vérifier",
        etat: resumeAVerifier(postes) },
      ...(av
        ? [{ section: "doublons" as const, icone: "doublons" as const, titre: "Doublons potentiels",
             etat: postes.nbDoublons ? `${postes.nbDoublons} à examiner` : "Aucun doublon détecté" }]
        : []),
      { section: "corbeille", icone: "corbeille", titre: "Corbeille",
        etat: nbCorbeille ? `${nbCorbeille} fiche${nbCorbeille > 1 ? "s" : ""} restaurable${nbCorbeille > 1 ? "s" : ""}` : "Vide" },
    ],
    partage: [
      { section: "packs-officiels", icone: "starter-packs", titre: "Starter packs",
        etat: "Découvrir et installer des packs" },
      { action: (a) => a.choisirPackAImporter(), icone: "importer", titre: "Importer un pack",
        etat: "Depuis un fichier .movpack" },
      { section: "publier", icone: "exporter", titre: "Créer / exporter un pack",
        etat: "Créer un fichier à partager" },
    ],
    // D-308 : Stockage et Sauvegardes sont deux questions — ce qu'on occupe,
    // et quand on a mis à l'abri. D-371 les réunit avec Sécurité : les trois
    // parlent de la CONSERVATION, pas de la circulation ni du confort.
    donnees: [
      { section: "sauvegardes", icone: "sauvegardes", titre: "Sauvegardes",
        etat: dateSauv ? `Dernière sauvegarde · ${dateSauv}` : "Aucune sauvegarde" },
      { section: "stockage", icone: "stockage", titre: "Stockage",
        etat: espaceUtilise || "Espace occupé et persistance" },
      { section: "securite", icone: "securite", titre: "Sécurité", etat: secu },
      ...(av
        ? [{ section: "diagnostic" as const, icone: "diagnostic" as const, titre: "Diagnostic et maintenance",
             etat: "État technique de l'appareil" }]
        : []),
    ],
    preferences: [
      { section: "apparence", icone: "apparence", titre: "Apparence", etat: themeLisible },
      // D-234 : ce sont des choix de PÉRIMÈTRE, pas de présentation. D-371 les
      // renomme « Fonctions avancées » — Relations et Compositions sont des
      // CAPACITÉS de Movenso, pas des réglages.
      { section: "avance", icone: "avance", titre: "Fonctions avancées", etat: etatAvance },
    ],
    // D-362 : UNE entrée pour deux pages — À propos dit qui est Movenso et
    // porte la porte vers l'Aide. D-371 la sort des préférences : ce n'est pas
    // un réglage, et son nom dit désormais qu'on y trouve l'aide.
    movenso: [
      { section: "apropos", icone: "apropos", titre: "Aide & à propos",
        etat: "Guides · version · licences · crédits" },
    ],
  };
}

function ligneMenu(app: MovensoApp, e: EntreeMenu): TemplateResult {
  const ouvrir = () => (e.section ? app.ouvrirPlusSection(e.section) : e.action?.(app));
  return html`<button class="ligne-menu" @click=${ouvrir}>
    ${icone(e.icone)}
    <span class="ligne-menu-corps">
      <span class="ligne-menu-titre">${e.titre}</span>
      ${e.etat ? html`<span class="ligne-menu-etat">${e.etat}</span>` : nothing}
    </span>
    <span class="chevron" aria-hidden="true">›</span>
  </button>`;
}

/** Écran « Plus » : un menu court et compréhensible (D-071). */
export function gabaritPlus(app: MovensoApp): TemplateResult {
  const groupes = etatsMenu(app);
  const groupe = (titre: string, entrees: EntreeMenu[]) => html`
    <div class="menu-section-titre">${titre}</div>
    <div class="menu-groupe">${entrees.map((e) => ligneMenu(app, e))}</div>`;
  return html`
    <div class="ecran plus">
      <header class="marque"><div style="flex:1"><div class="nom">Plus</div>
        <div class="devise">Gérer ta bibliothèque, tes données et Movenso.</div></div></header>
      ${groupe("Organiser ma bibliothèque", groupes.organiser)}
      ${groupe("Entretenir ma bibliothèque", groupes.entretenir)}
      ${groupe("Packs & partage", groupes.partage)}
      ${groupe("Données & sécurité", groupes.donnees)}
      ${groupe("Préférences", groupes.preferences)}
      ${groupe("Movenso", groupes.movenso)}
    </div>
  `;
}
