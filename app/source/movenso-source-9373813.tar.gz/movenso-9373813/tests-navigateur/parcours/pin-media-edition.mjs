/**
 * CHAPITRE e2e (constat checker, D-404) — édition d'un média avec PIN demandé
 * PENDANT l'enregistrement : Source ET lien doivent survivre à la saisie du PIN.
 *
 * L'accident : `enregistrer()` enchaînait deux écritures gardées (`majMediaLabel`
 * puis `majMediaLien`). La garde n'a QU'UN slot de reprise (`demandePin`) — la
 * seconde écrasait la première, donc après le PIN seul le lien s'appliquait, le
 * libellé était perdu en silence. Le correctif enveloppe les deux dans UNE seule
 * `autoriser` : une reprise combinée est armée, et les deux passent après le PIN.
 *
 * Test par le VRAI chemin (D-231/D-251) : on ouvre la feuille, on change les deux
 * champs, on clique « Enregistrer », on saisit le PIN, on vérifie les DEUX valeurs.
 * Contexte Playwright propre : OPFS isolé.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
{
  const ctx = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");

  // Setup : une technique avec un média EN LIGNE (deux champs : Source + URL),
  // puis protection des modifications active + session verrouillée.
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    await app.creerDiscipline("MediaPin");
    const did = app.bibliotheque.disciplines.at(-1).id;
    await app.creerTechnique(did, "Tech");
    const t = app.bibliotheque.techniques.at(-1);
    await app.ajouterMediaFiche(t.id, { lien: "https://www.youtube.com/watch?v=AAAAAAAAAAA" }, { label: "Source A" });
    await app.activerProtection("modifications", { pin: "246813", confirmation: "246813" });
    app.verrouiller(true);
  });

  // Ouvrir Médias › « Médias en ligne » › ✎, changer LES DEUX champs.
  await p.evaluate(() => document.querySelector("movenso-app").ouvrirPlusSection("medias"));
  await p.locator(".kpi-filtre", { hasText: "Médias en ligne" }).click();
  await p.waitForSelector(".mediatheque-liste .ligne-media");
  await p.locator('.ligne-media .bouton-icone[aria-label^="Modifier"]').first().click();
  await p.waitForSelector('.feuille[aria-label="Modifier le média"]');
  await p.fill('.feuille input[aria-label="Source"]', "Source B");
  await p.fill('.feuille input[aria-label="URL"]', "https://www.youtube.com/watch?v=BBBBBBBBBBB");
  await p.locator('.feuille .bouton', { hasText: "Enregistrer" }).click();

  // Le PIN est demandé AVANT toute écriture (garde à l'entrée) ; rien n'a bougé.
  const pendant = await p.evaluate(() => {
    const app = document.querySelector("movenso-app");
    const m = app.bibliotheque.contributions.flatMap((c) => c.medias)[0];
    return { pin: app.demandePin !== null, label: m.label, ref: m.ref };
  });
  assert.ok(pendant.pin, "le PIN est demandé avant d'écrire");
  assert.equal(pendant.label, "Source A", "rien n'est écrit avant le PIN");

  // Saisir le PIN → la reprise combinée rejoue les DEUX écritures.
  await p.evaluate(() => document.querySelector("movenso-app").validerDemandePin("246813"));
  await p.waitForFunction(() => document.querySelector("movenso-app").demandePin === null);
  const apres = await p.evaluate(() => {
    const m = document.querySelector("movenso-app").bibliotheque.contributions.flatMap((c) => c.medias)[0];
    return { label: m.label, ref: m.ref };
  });
  // Le cœur du constat : SANS le correctif, `label` resterait « Source A » (perdu).
  assert.equal(apres.label, "Source B", "après le PIN, la Source est appliquée — pas perdue (constat 1)");
  assert.ok(apres.ref.includes("BBBBBBBBBBB"), "après le PIN, le lien est appliqué");

  await ctx.close();
}
}
