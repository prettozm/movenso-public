# STATE — tableau de bord de reprise

> **Type : vivant** · Ce fichier ne contient **que le présent**. Aucun
> historique : il vit dans Git, dans [DECISIONS.md](DECISIONS.md) et dans les
> fiches de [`lots/`](lots/). Un STATE qui raconte est un STATE qu'on ne lit
> plus (D-275).
>
> Le **commit** et la **branche** ne sont pas écrits ici, volontairement : ils
> seraient périmés par le commit même qui les écrit. `git log -1` fait foi.

## PHASE

**STABILISATION V1 → B4 (RC).** Référence : l'audit externe
[`audit-stabilisation-v1.md`](audit-stabilisation-v1.md), loti dans
[`lots/`](lots/). Lots S1, S2 et S4 clos ; S3 clos hors reliquats ci-dessous.

## BOUCLE COURANTE

**Ajustements VUE PAR VUE ouverts** (demande porteur du 2026-08-14, ligne dans
[RESTE.md](RESTE.md)) : reprise de chaque écran, un à la fois, sur consigne.
**Vue 1 — état bibliothèque vierge : FAITE** (D-328). L'écran ne se déclenche
plus sur « ni discipline ni technique » mais sur un vrai état du domaine,
`bibliothequeVierge` (`src/domaine/vacuite.ts`) : aucun pack, technique,
composition, contenu importé ou restauré, ni trace d'un contenu qui aurait
existé. Six ajustements à l'écran (départ recommandé, deux textes, « connexion
requise pour le téléchargement », FAB masqué, pictogrammes, contraste des
textes secondaires ; l'apparence des pictos est reprise en D-331) ; l'écran sort de `vues.ts` dans
`src/app/bibliotheque-vierge.ts` (plafond 930 → 901, `racine.ts` inchangé).
Les **gouttières de 18 px** manquaient à cet écran seul de toute l'app :
corrigées sur arbitrage porteur (D-329), avec une épingle qui mesure le
CONTENU — la première mesurait le conteneur et aurait été verte à jamais.
**Collision de numéros résolue** (D-330) : deux entrées `327` ont coexisté,
l'audit gardant le sien puisqu'il est déjà sur `main`.
**Direction visuelle des maquettes du porteur INTÉGRÉE** (D-331) : vignettes
illustrées en couleurs (écrites à la main en SVG, elles approchent les rendus
3D sans les reproduire), chevron par carte, carte recommandée à dégradé et
halo, filet en encart, texture d'arc. Textes du prompt, et **tiret cadratin
retiré de tout le texte visible de cet écran**, tenu par une garde e2e. Le
balayage des AUTRES écrans est une boucle à part, en attente dans RESTE.md.
**Illustrations du porteur INTÉGRÉES** (D-332) : cinq WebP à 192 px dans
`public/img/` (68 Ko), citées par leur chemin comme le logo. `dist/` à 845 Ko
sur 900. La garde du build accepte désormais `.webp` et le dossier `img/`,
chaque exception nommée avec sa raison.
**Vue 2 — packs officiels : FAITE** (D-333), maquette validée avant le code
(`docs/prototypes/packs-officiels.html`). Avertissement « des bases pour
commencer » avec le **lieu de pratique**, illustration par pack, badge de
maturité, date, états installé et mise à jour, et **16 disciplines sans pack**
en invitation (**20 depuis D-334**, la liste complète du porteur).
**Dégraissé D-335** : l'écran s'appelle « Starter packs », le titre en double
et les badges Alpha/Bêta quittent l'écran (la maturité reste au catalogue),
« Installé » devient une pastille et non un bouton, la grille cesse de dire
« à venir » et devient « Envie de contribuer ? ». Les six résumés de packs
sont réécrits dans `publication/packs.json`. Les
illustrations vivent sur le SITE (`packs/img/`, 26 fichiers) et
sont récupérées par `fetch` puis servies en `blob:` : **la CSP n'est pas
touchée** (ouvrir `img-src` vers le site aurait imposé une PR). Zéro octet
ajouté à l'app. Non démontré e2e, à recetter sur appareil : « Installé » et
« Mise à jour disponible ».

**Vue 3 — Bibliothèque : FAITE** (D-336), maquette validée avant le code
(`docs/prototypes/bibliotheque-favoris-filtre.html`). **L'écran Favoris est
supprimé** : le cœur de la barre de recherche bascule `favorisSeuls`, qui
existait déjà dans le moteur sans que rien ne l'allume. Nav par défaut :
**Bibliothèque · Plus** (les deux bêtas restent opt-in, arbitrage porteur).
Le réglage « démarrer sur Favoris » est supprimé et sa préférence **migrée**.
Catégories et niveaux passent dans une feuille « Filtres » ; les filtres posés
reviennent en puces retirables, et le bouton porte leur compte. Le bouton
flottant se réduit au défilement (`src/app/fab-defilement.ts`). Cliquets à la
baisse : `racine.ts` 1548 → 1529, `vues.ts` 901 → 875. Non démontré e2e, à
recetter sur appareil : la réduction du bouton flottant.

**Vue 4 — fiche technique : FAITE** (D-337), maquette discutée puis validée
avant le code (`docs/prototypes/fiche-technique.html`, deux passes : la
première remplaçait les Relations par une liste plate et perdait ce que
l'écran faisait déjà). Chaque section de lecture prend un **cadre** ; une
section **vide reste affichée avec son invitation** ; les onglets de médias et
« ＋ Ajouter » passent **sous l'image**, sans passer en édition ; **Modifier
quitte la barre haute** pour le bouton flottant en bas à droite (la barre garde
‹ retour · ♥ · graphe · partager, et redevient ✓ / ✕ en édition) ; les
compositions se montrent **comme des relations** (vignette dérivée de leur
première technique, nom, et ce qu'elles SONT). Les Relations gardent tout ce
qu'elles avaient : groupement par rôle, « Présente dans », « Voir toutes ».
Sections extraites dans `src/app/fiche-sections.ts` — les deux fichiers touchés
sont au cliquet, resserré ensuite (`vues.ts` 875 → 874,
`relations-visuelle.ts` 638 → 637). **Un invariant e2e est tombé** : « aucune
action globale sur une fiche » devient « un seul bouton flottant, et c'est
Modifier ». **Reste à faire sur cet écran** : l'avertissement éditable au ✎
(validé en maquette, non implémenté — aucun éditeur d'alerte n'existe
aujourd'hui, et `majTechnique` n'accepte pas ce champ).

**Publication REPRODUCTIBLE** (D-338, sur demande du porteur) : deux
`npm run publier` d'affilée donnent des conteneurs et un catalogue aux octets
identiques. Deux horloges l'empêchaient, pas une — `creeLe` du manifeste **et**
l'horodatage des entrées du zip, que le dézippage ne montre pas. Les dates
dérivent du dernier commit de la source du pack. **Au prochain dépôt, les six
packs changent une dernière fois**, puis ne bougent plus sans changement de
contenu. `app/source/` ne garde plus que l'archive du binaire servi — l'arbre
servi cesse de croître, le `.git` du dépôt public (135 Mo) ne maigrit pas.

**Relecture checker : LANCÉE en session neuve** le 2026-08-14, verdict
attendu — sur `dd98ef7..HEAD` (D-280). Déclencheur : `outils/plafonds.json`
(zone « outillage »), resserré par `npm run cliquet` après la sortie de
l'écran hors de `vues.ts`. Le verdict s'inscrit au journal, corrigé ou
argumenté ; sans trace, la relecture n'a pas eu lieu.

**La branche porte une fusion de `main`** (`5dc1854`) — geste du porteur,
**par erreur** (2026-08-14). Elle reste en place : la défaire demanderait de
réécrire l'historique, ce qui est interdit ici, et elle n'est pas nuisible —
la branche est simplement à jour de `main`, ce qu'une PR exigerait de toute
façon. Rien à réparer ; ce qu'elle a cassé au passage l'a été (D-330).

**Correctifs de recette REC-B4-001 : série TERMINÉE** (D-291 → D-298) et
**R2-1 : TERMINÉE** (D-299 → D-302). **Finition éditoriale des six packs
INTÉGRÉE** (D-306, fournitures porteur, go du 2026-08-12) : sources
`donnees/` régénérées depuis les conteneurs (S4.8), preuve d'équivalence
`publier` ↔ fournitures, +10 couvertures de familles judo embarquées,
26 autres au parc sans embarquement (D-245) — republication en cours,
voir « En ligne ».

**PR `movenso` #7 FUSIONNÉE** par le porteur (2026-08-13, 21:13) : `main` porte
D-302 → **D-326**. Elle a été fusionnée sur `96800bd`, **avant** les correctifs
d'audit — ceux-ci vivent donc sur une branche NEUVE partie de `main`
(`claude/audit-p1-2026-08-13`, D-327), avec sa propre PR : une PR fusionnée ne
se rouvre pas, et on n'empile pas sur de l'historique déjà entré.

**Restent ouvertes, pour le porteur** : la PR d'audit ci-dessus (les trois P1) et
`movenso-public` **#8** (`claude/audit-2026-08-13` : Actions épinglées par SHA,
promesse « hors ligne » précisée — posture de sécurité et texte engageant, donc
jamais en dépôt direct, D-267).

**La revue UI/UX, c'est CE chantier** (confirmé par le porteur le 2026-08-14) :
les « ajustements vue par vue » ci-dessus **sont** cette revue — il n'y a pas de
session parallèle qui produirait des constats à attendre. L'attente que ce
tableau prescrivait (« ne pas ouvrir de chantier d'interface ») est donc
**levée** : les constats arrivent écran par écran, dictés en séance, et chacun
se traite dans sa boucle.

**Chantier COMPOSITIONS ouvert** (dossier
[`lots/compositions-seances.md`](lots/compositions-seances.md), spécification UI
D-314) : maquette soumise et arbitrée (D-315 → D-318, couleurs conservées,
grammaire des planches, huit recommandations). **INTÉGRÉES** : **UI-2 — fiche de
consultation** (D-319 : ouvrir = lire, l'édition passe par le ✎), **UI-1 — liste
Mes | Packs** (D-320 : liseré = discipline dominante), **UI-3 — éditeur**
(D-321 : bandeau dérivé partagé, timeline), **UI-4 — ajout d'étape progressif**
(D-322 : le contenu d'abord ; deux demandes des planches annulées par le journal),
**UI-5 — lecteur** (D-323 : jauge, anneau, « Ensuite » avec le rôle suivant ;
moteur intouché) et **UI-6 — « Continuer »** (D-324 : une entrée, dans les
préférences, donc sans migration). Regarder l'écran avec les vrais packs
y a trouvé **quatre défauts** — identifiant ULID affiché, mot `provenance`
affiché, duplication qui ne rendait pas la copie personnelle, et deux compteurs
contradictoires côte à côte — tous corrigés. **Reste DEUX passes** : **AG-1** (Agenda — le seul ajout métier :
`Planification`, bump de schéma, migration additive, **relecture checker
requise**) et **AG-2** (Calendrier, même donnée, autre rendu). Le lot **E**
(rappels système) reste hors chantier (arbitrage D-290 n° 6).

**Relectures checker : TROIS verdicts rendus et traités** (D-303, D-304, D-326).
Le dernier couvre la série compositions (`6108a0c..96d1225`) : un constat,
accepté et corrigé — le nombre d'étapes divergeait entre la liste et la fiche
(kata publié : 26 contre 21). **RESTE À RELIRE — 34 commits jamais lus par un
checker** : `87071a0..6108a0c`, soit le micro-diff du résidu D-304 puis
D-305 → D-318. Zones sensibles dedans : `validation.ts` (D-307),
`rapprochement.ts`, `tools/publier.ts` (D-306). Cette dette avait **disparu de
ce tableau** en réécrivant le paragraphe pour D-326 — l'audit du 2026-08-13 a
lu STATE, l'a cru, et en a conclu que RESTE.md était périmé : c'était
l'inverse (D-327).
Relèvements de cliquet **confirmés par le porteur** (D-305, puis 2026-08-13).

**Dépôt du 2026-08-13** : la première tentative a été **refusée par la garde**
(rien n'a été déposé) — une épingle e2e pariait sur le tirage de « Centrer au
hasard », second piège du même dé après D-313. Corrigée (D-325), sans toucher
au produit. Le **redépôt** du 2026-08-13 (20:42Z) porte le correctif D-326.

## GEL

**LEVÉ le 2026-08-13** (D-307, décision porteur : des corrections UX
arrivent). Les corrections UX des parcours existants sont recevables ;
une fonction nouvelle reste soumise au lot courant.

## P0

Aucun.

## P1

- **`REC-B4-001` : socle DÉROULÉ, bloc compositions suspendu** (2026-08-11,
  build `f8c51d6`). Verts : préambule, R0, R3, R4, R5, R6, R6bis, R7 hors
  compositions — résultats et constats dans la fiche. **Neuf entrées en file
  post-recette** (R3-1, R5-1, R6bis-1→4, R7-1, dossier bandeau ×2 —
  la scission Stockage/Sauvegardes est FAITE, D-308). **Reste** : R1/R2/R2bis +
  trame R4 + séance minutée R7 — **plus suspendus** : l'arbitrage « recetter tel
  quel ou faire évoluer les compositions d'abord » est levé, les compositions
  ont évolué (D-319 → D-326) et sont en ligne.
- **Keystore de publication** : le perdre, c'est perdre définitivement la mise
  à jour de l'app sur Play. Aucune procédure de sauvegarde écrite.

## RESTE À FAIRE

Tout ce qui n'est pas fait — chemin critique v1, décisions humaines
attendues, chantiers post-v1, dette acceptée — vit dans
**[RESTE.md](RESTE.md)** : une ligne par chantier, chacune citant sa source
(D-288). Un chantier clos **sort** du fichier dans le commit qui le clôt —
le journal est la liste du terminé, pas une seconde liste ici. Seuls les
**P0/P1** restent dans ce tableau de bord.

## DERNIÈRE PREUVE

- `npm run verifier` : **vert** — il annonce lui-même ses compteurs.
- CI : **verte** depuis D-270 (elle était rouge six commits durant sans que le
  vérificateur local le voie — lire le run, pas seulement le local).
- **En ligne** : `movenso-public` @ `e2e0682` — app build `2877eeb`
  (schéma 6, movpack v5, **écran de première ouverture illustré** D-328 →
  D-332 et **écran des packs officiels refondu** D-333), six packs
  **inchangés** en contenu, **22 illustrations** dans `packs/img/`, source
  dans le même commit, `verifier:release` vert avant dépôt et
  `verifier-catalogues` vert après. **C'est la version à recetter.**
  À vérifier en priorité sur appareil, non démontré e2e : « Installé » et
  « Mise à jour disponible » sur un pack déjà posé.

- *(précédent)* `movenso-public` @ `b83a1ab` — app build `a95c1f4`
  (schéma 6, movpack v5, **refonte UX des compositions D-319 → D-326**,
  correctif du verdict checker compris), six packs **inchangés**
  (judo 0.7.6, karaté 0.3.2, jujitsu 0.3.4, jjb 0.2.4, taïso 0.2.4,
  yoga 0.4.4) et source dans le même commit, garde du site verte après
  dépôt, `catalogues` et Pages `success` (20:42Z). Le catalogue
  `packs/index.json` n'a pas bougé : aucun contenu n'a changé, seule
  l'interface. **C'est la version à recetter.**

## PROCHAINE ACTION EXACTE

**1. Les deux PR restantes** — l'audit sur `movenso` (trois P1) et
`movenso-public` #8. **2.** La relecture de `87071a0..6108a0c` (34 commits jamais
lus, dont `validation.ts` et `rapprochement.ts`) **n'a pas eu lieu avant la
fusion de #7** : elle porte donc sur du code déjà dans `main`, ce qui ne
l'annule pas — un constat s'y corrigerait par une boucle de plus. **3.** Lire les
constats de la revue UI/UX avant tout chantier d'interface.

Puis : **dérouler `REC-B4-001` sur appareil**, sur la version en ligne ci-dessus,
en commençant par **R0**. R1/R2/R2bis, la trame R4 et la séance minutée R7 ne sont
plus suspendus : l'arbitrage « recetter tel quel ou faire évoluer les
compositions d'abord » est levé — les compositions ont évolué (D-319 → D-326).

Ensuite seulement, et **si un besoin terrain le réclame** (D-324) : **AG-1 —
l'Agenda** (dossier `lots/compositions-seances.md` §8), le **seul ajout métier**
du chantier. `Planification { compositionId, date, heure? }` → **bump de schéma
+ migration additive**, donc **relecture checker REQUISE** (D-280). Écrire son
CYCLE avant le code (D-251), notamment : part-elle dans la sauvegarde complète
(question ouverte n° 1) ? Vue **Liste d'abord** ; l'Agenda est une **vue de
l'onglet Compositions**, pas un sixième onglet (D-314).

## FAITS GÉNÉRÉS

> Écrits par `npm run etat`, jamais à la main. `npm run verifier:etat` refuse
> l'écart (D-275) — ces nombres ont menti trop souvent (D-273).

<!-- FAITS:DÉBUT -->
Application : 0.9.0-rc.1
Schéma : 6
Movpack : 5
Tests : 300
Chapitres e2e : 24
Sources de packs : 6/6
Publication : dist-publication/
Fichiers TS (src/) : 73
racine.ts : 1529 lignes
movpack.ts : 666 lignes
<!-- FAITS:FIN -->

## PROCÉDURE DE REPRISE

1. **Git** : vérifier branche, commit, état. Dans `movenso`, **toujours une
   branche, jamais `main`, jamais de fusion**. Dans `movenso-public`, la
   publication directe sur `main` est permise sous conditions — « Deux dépôts,
   deux régimes » dans `CLAUDE.md` (D-267). Si une consigne de démarrage nomme
   la même branche pour les deux dépôts, le **signaler**.
2. **Lire** : ce fichier, [MASTER.md](MASTER.md), le lot courant dans
   [`lots/`](lots/), les sections concernées de [QUALITY.md](QUALITY.md). Du
   journal [DECISIONS.md](DECISIONS.md), **seulement** les décisions désignées
   par ce fichier et par le lot courant — plus la queue si le contexte récent
   manque (D-276). Le lire en entier fait remonter des raisonnements périmés.
3. **Vérifier** : `npm run verifier` (~2 min, tient dans un appel au premier
   plan — ne pas le lancer en tâche de fond pour l'attendre en boucle, D-237).
   Un chapitre seul : `npm run e2e:chapitre <nom>` (~4 s). Charge :
   `npm run campagne:charge`.
4. **Lire le run CI**, pas seulement le vérificateur local (D-270) : ils ne
   couvrent pas la même chose.
5. **Publier** : quatre conditions cumulatives (D-267) — commit `movenso`
   poussé, `npm run verifier` vert sur ce commit, `verifier-catalogues.mjs`
   vert **après** dépôt, et **app + packs + source dans le même commit**. Un
   `git push` n'est pas une publication : vérifier que Pages conclut `success`.
6. **Trois niveaux de vérification** (D-281) : `verifier:rapide` (~13 s, pour
   itérer — il dit ce qu'il ne regarde pas), `verifier` (~2 min, pour clore une
   boucle), `verifier:release` (avant de distribuer).
7. **Publier n'est pas déposer** : `npm run publier` produit dans
   `dist-publication/` et n'écrit nulle part ailleurs ; `npm run verifier:release`
   valide ; `npm run deposer -- --vers <site>` est le seul geste qui écrit dans
   le dépôt public. Contrôler un conteneur reçu : `tools/inspecter-movpack.ts`. Avant d'intégrer un pack
   fourni, TOUJOURS le comparer au publié — c'est ainsi qu'on a vu le karaté
   perdre ses 109 images (D-245) et l'identité du jujitsu dériver (D-247).
8. **Avant de committer** : `npm run etat` si un fait a bougé.
