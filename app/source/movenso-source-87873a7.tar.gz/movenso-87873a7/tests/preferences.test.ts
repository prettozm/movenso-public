/** Migration des préférences d'appareil (lot 1 §2-3) : l'ancienne valeur
 *  de démarrage « accueil » désigne un écran supprimé — elle devient
 *  « bibliotheque » ; tout contenu illisible vaut défauts. */

import { test } from "node:test";
import assert from "node:assert/strict";
import { migrerPreferences, preferencesDefaut } from "../src/stockage/opfs.ts";

test("une ancienne préférence « accueil » est migrée vers la Bibliothèque", () => {
  const migrees = migrerPreferences({ version: 1, demarrage: { mode: "accueil" } });

test("D-336 : « favoris » est migrée vers la Bibliothèque, l'écran n'existe plus", () => {
  // Les favoris sont devenus un FILTRE de la Bibliothèque. Une préférence qui
  // pointe vers l'écran supprimé ouvrirait l'application sur du vide.
  const migrees = migrerPreferences({ version: 1, demarrage: { mode: "favoris" } });
  assert.equal(migrees.demarrage.mode, "bibliotheque");
});
  assert.equal(migrees.demarrage.mode, "bibliotheque");
});

test("la migration « accueil » ne perd pas les autres préférences", () => {
  // `repriseMasquees` : champ RETIRÉ du modèle (S3.A12 — reliquat « Reprendre »
  // purgé) ; un fichier ancien qui le porte encore migre sans casser.
  const migrees = migrerPreferences({
    version: 1,
    demarrage: { mode: "accueil" },
    theme: "sombre",
    tonalite: "indigo",
    derniereDisciplineId: "01ABC",
    repriseMasquees: ["x"],
  } as never);
  assert.equal(migrees.demarrage.mode, "bibliotheque");
  assert.equal(migrees.theme, "sombre");
  assert.equal(migrees.tonalite, "indigo");
  assert.equal(migrees.derniereDisciplineId, "01ABC");
});

test("les modes valides restent inchangés", () => {
  for (const demarrage of [
    { mode: "bibliotheque" as const },
    { mode: "derniere" as const },
    { mode: "discipline" as const, disciplineId: "01XYZ" },
  ]) {
    const p = migrerPreferences({ version: 1, demarrage });
    assert.deepEqual(p.demarrage, demarrage);
  }
});

test("les réglages Relations (centre + vue, D-137) traversent la migration intacts", () => {
  const migrees = migrerPreferences({
    version: 1,
    demarrage: { mode: "bibliotheque" },
    relationsCentreId: "01SEOI",
    relationsVue: "mindmap",
  });
  assert.equal(migrees.relationsCentreId, "01SEOI");
  assert.equal(migrees.relationsVue, "mindmap");
  // Ils ne font PAS partie des défauts (aucun contexte mémorisé au premier lancement).
  assert.equal(preferencesDefaut().relationsCentreId, undefined);
  assert.equal(preferencesDefaut().relationsVue, undefined);
});

test("un contenu illisible ou inconnu vaut défauts (démarrage Bibliothèque)", () => {
  for (const brut of [null, 42, "x", {}, { version: 2, demarrage: { mode: "bibliotheque" } }, { version: 1 }]) {
    assert.deepEqual(migrerPreferences(brut), preferencesDefaut());
  }
  assert.equal(preferencesDefaut().demarrage.mode, "bibliotheque");
});
