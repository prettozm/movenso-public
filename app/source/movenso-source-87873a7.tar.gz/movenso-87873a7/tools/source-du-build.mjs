/**
 * SOURCE CORRESPONDANTE du build publié (S4.7/D-265).
 *
 *   node tools/source-du-build.mjs [--vers <dossier-site>]
 *
 * La GPLv3 n'oblige pas à ouvrir le dépôt de travail : elle oblige à fournir,
 * à qui reçoit le binaire, **la source qui correspond à CE binaire**. Le site
 * déclare l'application sous GPL v3 et distribue une version web plus une APK ;
 * la source doit donc voyager avec elles.
 *
 * D'où le nom du fichier : il porte le **SHA du commit**, celui-là même que
 * l'application affiche dans Plus › À propos. On peut ainsi vérifier de
 * l'extérieur que la source proposée est bien celle du binaire servi — une
 * archive « dernière version » ne le permettrait pas.
 *
 * Contenu : tout ce que git suit, SAUF `donnees/images/` — ce sont les
 * illustrations des packs, des données de contenu qui n'entrent pas dans la
 * construction de l'application (le `dist/` n'en contient rien). Les exclure
 * fait passer l'archive de ~10 Mo à quelques centaines de Ko sans retirer une
 * ligne de ce qui est nécessaire pour rebâtir le binaire.
 */
import { execFileSync } from "node:child_process";
import { mkdirSync, writeFileSync, readFileSync, readdirSync, rmSync } from "node:fs";
import { join } from "node:path";
import { constante } from "../outils/lire-constantes.mjs";

const git = (...args) => execFileSync("git", args, { encoding: "utf8", maxBuffer: 1 << 28 }).trim();
const cible = process.argv.includes("--vers") ? process.argv[process.argv.indexOf("--vers") + 1] : null;

const RACINE = git("rev-parse", "--show-toplevel");
const sha = git("rev-parse", "--short", "HEAD");
// Ce qui compte, c'est que l'archive corresponde à HEAD. Or elle est bâtie
// depuis `git ls-files` — donc des fichiers SUIVIS, lus dans l'arbre de
// travail : une modification non committée d'un fichier suivi partirait dans
// l'archive sans correspondre au commit annoncé. C'est CELA qu'on refuse.
//
// Un fichier NON suivi, lui, n'entre jamais dans l'archive. Le refuser était
// une sévérité mal placée, et elle a coûté cher : la CI écrit `SHA256SUMS` à
// la racine avant cette étape, donc l'étape échouait à chaque poussée — six
// commits durant, sans que rien d'autre ne le dise (D-270).
const sales = git("status", "--porcelain", "--untracked-files=no");
if (sales !== "") {
  console.error("source-du-build : des fichiers SUIVIS sont modifiés — une source qui ne correspond à AUCUN");
  console.error("commit n'est pas une source correspondante. Committer d'abord.\n");
  console.error(sales);
  process.exit(1);
}

// `git archive` produit l'arbre EXACT du commit : pas de fichier oublié, pas
// de fichier local en trop. Les images de packs sont écartées par attribut.
const fichiers = git("ls-files").split("\n").filter((f) => f && !f.startsWith("donnees/images/"));
const tar = execFileSync("tar", ["-czf", "-", "--transform", `s|^|movenso-${sha}/|`, "--", ...fichiers],
  { maxBuffer: 1 << 28 });

mkdirSync("dist-publication/source", { recursive: true });
const nom = `movenso-source-${sha}.tar.gz`;
writeFileSync(`dist-publication/source/${nom}`, tar);
console.log(`dist-publication/source/${nom} — ${(tar.length / 1024).toFixed(0)} Ko, ${fichiers.length} fichiers, commit ${sha}`);

if (cible) {
  const dossierSource = join(cible, "app", "source");
  mkdirSync(dossierSource, { recursive: true });
  writeFileSync(join(dossierSource, nom), tar);

  // UNE archive à la fois, celle du binaire servi (D-338). Elles
  // s'accumulaient : dix-huit fichiers, 42 Mo, une par dépôt, et rien ne les
  // retirait — alors qu'à tout instant le site ne distribue QU'UN binaire.
  //
  // Ce n'est pas un renoncement à la GPLv3, et la page Mentions le dit déjà
  // mot pour mot : « la source correspondant à la version que tu utilises est
  // déposée à côté de l'application », et « la source de toute version
  // distribuée sera fournie » sur demande. Les versions antérieures restent
  // dans l'historique Git du dépôt public, publiquement clonable — elles ne
  // deviennent pas indisponibles, elles cessent d'encombrer l'arbre servi.
  //
  // Ce que ça NE fait PAS, et qu'il faut dire : l'historique Git conserve les
  // blobs. Le `.git` ne maigrit pas ; c'est la copie de travail — donc ce que
  // récupère qui clone ou visite — qui cesse de croître à chaque dépôt.
  const perimees = readdirSync(dossierSource)
    .filter((f) => /^movenso-source-[0-9a-f]+\.tar\.gz$/.test(f) && f !== nom);
  for (const f of perimees) rmSync(join(dossierSource, f));
  if (perimees.length) console.log(`  ${perimees.length} archive(s) de source périmée(s) retirée(s) — l'historique Git les garde`);

  // CARTE D'IDENTITÉ DU DÉPLOIEMENT (D-267) — ce que la garde du site lit pour
  // refuser une publication incohérente. Elle remplace l'ancien fichier
  // `COMMIT`, qui ne disait qu'une chose : un seul fichier, pas deux.
  //
  // Le SCHÉMA est ce qui compte le plus ici. Publier des packs en schéma N+1
  // devant une app restée en schéma N rend le catalogue INUTILISABLE — l'app
  // refuse les packs qu'on lui propose. La règle « app et packs partent
  // ensemble » cesse d'être une discipline et devient un refus mesurable.
  // Les adresses des constantes vivent dans `lire-constantes.mjs`, qui REFUSE
  // au lieu de produire NaN : c'est ce chemin-ci qui a écrit
  // `versionMovpack: null` quand la constante a déménagé (D-274 → D-285).
  const build = {
    version: JSON.parse(readFileSync(join(RACINE, "package.json"), "utf8")).version,
    commit: sha,
    versionSchema: constante("VERSION_SCHEMA"),
    versionMovpack: constante("VERSION_MOVPACK"),
    source: `source/${nom}`,
  };
  writeFileSync(join(cible, "app", "build.json"), JSON.stringify(build, null, 1) + "\n");
  console.log(`déposé dans ${cible}/app/ — build.json : ${JSON.stringify(build)}`);
}
