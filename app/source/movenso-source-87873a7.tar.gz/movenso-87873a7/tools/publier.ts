/**
 * CHAÎNE DE PUBLICATION (S4.9/D-264) — une source, un script, zéro compteur
 * saisi à la main.
 *
 *   npm run publier      → dist-publication/ (produit, ne dépose RIEN)
 *
 * Remplace `emballer-packs.ts`, qui ne faisait que la moitié du chemin : il
 * produisait les conteneurs, et le catalogue restait tenu à la main, ailleurs.
 * C'est cette moitié manquante qui a produit D-250 — cinq packs publiés, une
 * page web restée aux versions d'avant, et rien pour le signaler.
 *
 * La seule source est `publication/packs.json`. Le script :
 *   1. lit et MIGRE la bibliothèque source, la VALIDE avant tout ;
 *   2. pose les illustrations (propre à la technique, sinon carte de famille) ;
 *   3. construit le `.movpack`, licence comprise (`conditions`) ;
 *   4. le RELIT par le lecteur réel — un conteneur qu'on ne sait pas relire
 *      n'est pas publiable, quoi qu'en dise l'écriture ;
 *   5. COMPTE depuis le conteneur relu, jamais depuis la source ni à la main ;
 *   6. génère `index.json`, le catalogue unique que lisent la page ET l'app ;
 *   7. refuse de publier au moindre écart.
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync, rmSync, cpSync, readdirSync } from "node:fs";
import { execFileSync } from "node:child_process";
import type { Bibliotheque, Image } from "../src/domaine/modele.ts";
import { migrerBibliotheque } from "../src/domaine/migrations.ts";
import { validerBibliotheque } from "../src/domaine/validation.ts";
import { sha256Hex } from "../src/domaine/sha256.ts";
import { exporterMovpack, lireMovpack } from "../src/echange/movpack.ts";
import { idPackStable } from "../src/echange/extraction-pack.ts";

interface EntreePublication {
  id: string; source: string; fichier: string;
  nomEditorial: string; auteur: string; licence: string;
  version: string; versionEditoriale: number;
  title: string; discipline: string; type: string; statusLabel: string;
  language: string; maintainer: string; features: string[]; summary: string; note: string;
}

const PACKS: EntreePublication[] = JSON.parse(readFileSync("publication/packs.json", "utf8"));
const SORTIE = "dist-publication";
// PRODUIRE n'est pas DÉPOSER (D-281). `publier` fabrique dans `dist-publication/`
// et n'écrit nulle part ailleurs ; le dépôt vers le site est un geste SÉPARÉ
// (`npm run deposer`), qui exige d'abord `npm run verifier:release`. Tant que
// les deux tenaient dans une option, une frappe distraite publiait.
if (process.argv.includes("--vers")) {
  console.error("publier : « --vers » n'existe plus — produire et déposer sont deux gestes (D-281).");
  console.error("  1. npm run publier            → dist-publication/");
  console.error("  2. npm run verifier:release   → tout est-il cohérent ?");
  console.error("  3. npm run deposer -- --vers <site>");
  process.exit(2);
}

/**
 * Illustrations (D-244/D-245) : `donnees/images/<source>/techniques/<element>.jpg`
 * prime toujours ; à défaut `donnees/images/<source>/<familleId>.jpg`, la carte
 * de famille — le filet qui évite une fiche nue. L'image de famille porte son
 * titre générique : la fiche montre une carte de famille assumée, jamais une
 * photo qui prétendrait être cette technique-là.
 */
function poserIllustrations(
  b: Bibliotheque,
  source: string,
  octets: Map<string, Uint8Array>,
): { propres: number; familles: number; nues: number; famillesIllustrees: number } {
  const cache = new Map<string, Image | undefined>();
  // Schéma 6 (D-269) : on inscrit l'image à l'inventaire et on garde ses
  // OCTETS pour le conteneur — plus aucun base64 dans la chaîne. L'identité
  // étant l'empreinte, deux fiches illustrées par le même fichier ne
  // produisent qu'une entrée et qu'un fichier dans le pack.
  const lire = (chemin: string): Image | undefined => {
    if (!cache.has(chemin)) {
      let image: Image | undefined;
      if (existsSync(chemin)) {
        const contenu = new Uint8Array(readFileSync(chemin));
        image = { id: sha256Hex(contenu), mime: "image/jpeg", taille: contenu.length };
        octets.set(image.id, contenu);
      }
      cache.set(chemin, image);
    }
    return cache.get(chemin);
  };
  const inscrire = (image: Image) => {
    if (!(b.images ?? []).some((i) => i.id === image.id)) b.images = [...(b.images ?? []), image];
    return { type: "fichier", imageId: image.id } as const;
  };
  // 1. L'illustration PROPRE d'abord — elle prime toujours.
  let propres = 0;
  for (const t of b.techniques) {
    if (t.couverture) { propres++; continue; }
    const propre = t.origine?.element ? lire(`donnees/images/${source}/techniques/${t.origine.element}.jpg`) : undefined;
    if (propre) { t.couverture = inscrire(propre); propres++; }
  }

  // 2. La carte de famille n'est embarquée QUE si elle sert : une famille dont
  //    toutes les techniques ont leur propre image n'a besoin d'aucun repli.
  //    Sans ce filtre, le karaté embarquait 8 cartes que rien n'aurait
  //    affichées — 152 Ko de poids mort chez chaque utilisateur.
  const aBesoin = new Set(b.techniques.filter((t) => !t.couverture && t.familleId).map((t) => t.familleId!));
  let famillesIllustrees = 0;
  for (const d of b.disciplines) {
    for (const f of d.familles) {
      if (f.couverture || !aBesoin.has(f.id)) continue;
      const image = lire(`donnees/images/${source}/${f.id}.jpg`);
      if (image) { f.couverture = inscrire(image); famillesIllustrees++; }
    }
  }

  // 3. Ce que ça donne : la technique DÉRIVE l'image de sa famille, sans copie.
  const familleA = new Map(b.disciplines.flatMap((d) => d.familles).map((f) => [f.id, !!f.couverture]));
  let familles = 0, nues = 0;
  for (const t of b.techniques) {
    if (t.couverture) continue;
    if (t.familleId && familleA.get(t.familleId)) familles++;
    else nues++;
  }
  return { propres, familles, nues, famillesIllustrees };
}

/** Compteurs CALCULÉS depuis le conteneur relu (S4.9) — jamais saisis.
 *
 *  AUDIT 2026-08-13, P2-2 : « 111 techniques illustrées » était vrai à l'écran
 *  et faux au fond — aucune des 111 techniques du judo n'a d'image propre, elles
 *  héritent des 10 cartes de FAMILLE (D-245). Le catalogue vendait donc une
 *  richesse qu'il n'avait pas. Un compteur calculé ne doit pas seulement être
 *  exact, il doit être compris de la même façon par qui le lit. */
function compteurs(b: Bibliotheque): string {
  const techniques = b.techniques.length;
  const familles = b.disciplines.flatMap((d) => d.familles);
  const familleA = new Map(familles.map((f) => [f.id, !!f.couverture]));
  const propres = b.techniques.filter((t) => t.couverture).length;
  const famillesIllustrees = familles.filter((f) => f.couverture).length;
  const liens = b.techniques.reduce((s, t) => s + t.relations.length, 0);
  const compositions = b.compositions.length;
  const morceaux = [
    propres === techniques && techniques > 0
      ? `${techniques} techniques illustrées` // chacune a SON image
      : famillesIllustrees > 0
        ? `${techniques} techniques · ${famillesIllustrees} famille${famillesIllustrees > 1 ? "s" : ""} illustrée${famillesIllustrees > 1 ? "s" : ""}`
        : `${techniques} techniques`,
  ];
  if (liens) morceaux.push(`${liens} liens expliqués`);
  // « composition » est le mot du produit et il est vrai pour tous les packs ;
  // « séances », « katas » ou « séries » sont des nuances ÉDITORIALES, qui
  // vivent dans le résumé — un compteur calculé ne doit pas les deviner.
  if (compositions) morceaux.push(`${compositions} composition${compositions > 1 ? "s" : ""}`);
  return morceaux.join(" · ");
}

rmSync(SORTIE, { recursive: true, force: true });
mkdirSync(`${SORTIE}/packs`, { recursive: true });
// ILLUSTRATIONS (D-333) : elles vivent sur le SITE, pas dans l'app. Six pour
// les packs, seize pour les disciplines qui n'en ont pas encore. Recopiées
// telles quelles depuis `publication/img/` — produites une fois, jamais
// retouchées ici : ce qui est publié doit être reproductible (tools/CLAUDE.md).
cpSync("publication/img", `${SORTIE}/packs/img`, { recursive: true });
console.log(`illustrations : ${readdirSync("publication/img").length} recopiées vers packs/img/`);

const catalogue: Record<string, unknown>[] = [];
const ecarts: string[] = [];

/** DATE du pack : celle du dernier commit qui a touché sa source, jamais
 *  l'horloge de la publication (D-325). Sans elle, `creeLe` changeait à chaque
 *  passage et les six conteneurs — 9 Mo — repartaient avec des octets neufs
 *  alors qu'aucune ligne de contenu n'avait bougé : le diff d'une publication
 *  devenait illisible et l'historique du dépôt public enflait pour rien.
 *
 *  Ce qu'elle NE couvre pas, et c'est dit : une illustration de
 *  `donnees/images/` qui change SANS que la source JSON bouge produit bien un
 *  conteneur différent, mais la date ne suit pas. C'est un vrai changement de
 *  contenu, donc un vrai diff — la date se contente de ne pas le nommer.
 *
 *  Repli sur l'époque UNIX si le fichier n'a pas d'historique (source neuve,
 *  arbre exporté) : une date fixe, plutôt qu'une horloge qui casserait la
 *  reproductibilité au premier cas particulier. */
function dateDeLaSource(chemin: string): string {
  try {
    const iso = execFileSync("git", ["log", "-1", "--format=%cI", "--", chemin], { encoding: "utf8" }).trim();
    if (iso) return new Date(iso).toISOString();
  } catch { /* pas de git : on tombe sur le repli */ }
  return new Date(0).toISOString();
}

for (const p of PACKS) {
  const chemin = `donnees/${p.source}.json`;
  if (!existsSync(chemin)) { ecarts.push(`${p.id} : source ${chemin} absente — pack non reproductible`); continue; }

  const b = migrerBibliotheque(JSON.parse(readFileSync(chemin, "utf8")));
  validerBibliotheque(b); // la source AVANT d'emballer : jamais un conteneur bâti sur un état invalide
  const octetsImages = new Map<string, Uint8Array>();
  const ill = poserIllustrations(b, p.source, octetsImages);

  const dateSource = dateDeLaSource(chemin);
  const octets = await exporterMovpack(b, {
    id: idPackStable(b.disciplines[0]!.id), // D-247 : identité dérivée de la DISCIPLINE, jamais du nom de fichier
    nom: p.nomEditorial, portee: "discipline", auteur: p.auteur,
    conditions: p.licence,                  // S4.6 : la licence voyage AVEC le pack
    versionEditoriale: p.versionEditoriale,
  }, new Map(), octetsImages, dateSource);

  // Relecture par le lecteur RÉEL : intégrité, manifeste strict, validation.
  const relu = await lireMovpack(octets);
  if (relu.manifeste.conditions !== p.licence) ecarts.push(`${p.id} : licence absente du manifeste relu`);
  if (relu.bibliotheque.techniques.length !== b.techniques.length) ecarts.push(`${p.id} : techniques perdues à l'emballage`);

  writeFileSync(`${SORTIE}/packs/${p.fichier}`, octets);
  catalogue.push({
    id: p.id, title: p.title, discipline: p.discipline, summary: p.summary,
    type: p.type, statusLabel: p.statusLabel, version: p.version,
    // La date MONTRÉE au visiteur DÉRIVE de celle du manifeste — un seul lieu
    // (D-253). Elle disait « aujourd'hui » à chaque publication, y compris
    // quand le pack n'avait pas changé depuis trois semaines.
    updatedAt: new Date(dateSource).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }),
    itemCount: compteurs(relu.bibliotheque), // ← calculé, jamais recopié
    // Le SCHÉMA du conteneur relu (D-267) : la garde du site s'en sert pour
    // refuser des packs qu'une app plus ancienne ne saurait pas lire. Dérivé
    // du fichier construit, jamais déclaré à la main.
    versionSchema: relu.bibliotheque.versionSchema,
    language: p.language, maintainer: p.maintainer, license: p.licence,
    features: p.features, href: `packs/${p.fichier}`, downloadName: p.fichier, note: p.note,
    // Le chemin de l'illustration, RELATIF au site comme `href` : l'app la
    // récupère par le canal déjà ouvert pour le catalogue (D-333).
    icon: `packs/img/${p.id}.webp`,
    // De quoi reconnaître un pack DÉJÀ INSTALLÉ (D-333) : l'app retient
    // l'identité du manifeste et l'édition posée (`editionsPacks`, D-307).
    // L'id du catalogue (`judo-kodokan`) n'est pas cette identité-là, il ne
    // permettait aucun rapprochement. Les deux valeurs sont RELUES du
    // conteneur construit, jamais déclarées à la main.
    packId: relu.manifeste.id, versionEditoriale: p.versionEditoriale,
  });

  const ko = (octets.length / 1024).toFixed(0);
  console.log(
    `✓ ${p.fichier.padEnd(24)} ${p.version.padEnd(7)} vEd ${String(p.versionEditoriale).padEnd(3)} ${ko.padStart(5)} Ko`
    + `  ${relu.manifeste.id}`
    + `\n    ${compteurs(relu.bibliotheque)}`
    + `\n    illustrations : ${ill.propres} propres, ${ill.familles} dérivées de ${ill.famillesIllustrees} famille(s)`
    + (ill.nues ? `, ${ill.nues} FICHES NUES` : ""),
  );
}

if (ecarts.length) {
  console.error(`\npublier : ${ecarts.length} écart(s) — RIEN n'est publié\n`);
  for (const e of ecarts) console.error(`  ✕ ${e}`);
  process.exit(1);
}

writeFileSync(`${SORTIE}/index.json`, JSON.stringify(catalogue, null, 1) + "\n");
console.log(`\n${SORTIE}/index.json — catalogue de ${catalogue.length} packs, compteurs calculés depuis les conteneurs.`);


