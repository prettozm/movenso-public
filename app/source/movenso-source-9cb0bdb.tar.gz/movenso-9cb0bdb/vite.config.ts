import { readFileSync } from "node:fs";
import { execSync } from "node:child_process";
import { defineConfig } from "vite";

// Version affichée dans l'app (écran « À propos ») : dérivée de package.json,
// injectée au build. En dev/test (constante non définie), version.ts retombe
// sur "dev".
const pkg = JSON.parse(readFileSync(new URL("./package.json", import.meta.url), "utf8"));

// Commit court du build (D-212) : rattache la version affichée dans
// Plus › À propos à un commit GitHub précis (« 0.9.0-rc.1+a44cc04 »).
// Hors dépôt git (archive nue), repli honnête sur "local".
let commit = "local";
try { commit = execSync("git rev-parse --short HEAD", { encoding: "utf8" }).trim(); } catch { /* hors git */ }

export default defineConfig({
  // Aucun contenu disciplinaire n'est embarqué dans l'application (D-017) :
  // les packs (donnees/) sont des fixtures de test et des contenus distribués
  // séparément, installés volontairement par l'utilisateur.
  base: "./",
  build: { target: "es2022" },
  define: { __APP_VERSION__: JSON.stringify(pkg.version), __APP_COMMIT__: JSON.stringify(commit) },
});
