/**
 * Diagnostic technique (lot 8D §38) — PUR, sans E/S ni secret.
 *
 * Objectif : rendre une opération de stockage/export/import compréhensible sans
 * jamais exposer PIN, empreinte de PIN, contenu personnel, octets média ou URL
 * sensible. Le builder ne REÇOIT que des informations techniques agrégées : il
 * ne peut structurellement pas fuiter un secret.
 */

/** Codes d'erreur STABLES (P2.14/D-217) : un code publié ne change JAMAIS de
 *  sens ni de libellé d'opération — un rapport utilisateur reste interprétable
 *  d'une version à l'autre. On AJOUTE des codes, on n'en recycle pas. */
export const CODES_ECHEC = {
  "MOV-E01": "export .movpack",
  "MOV-E02": "lecture d'un pack",
  "MOV-E03": "installation d'un pack",
  "MOV-E04": "restauration complète",
  "MOV-E05": "restauration de sauvegarde interne",
  "MOV-E06": "téléchargement de pack officiel",
  "MOV-E98": "promesse non gérée",
  "MOV-E99": "erreur non gérée",
} as const;
export type CodeEchec = keyof typeof CODES_ECHEC;

export interface EntreeDiagnostic {
  /** Horodatage ISO fourni par l'appelant (le domaine pur n'appelle pas l'horloge). */
  genereLe: string;
  plateforme: string;
  /** Version applicative complète (SemVer + sha de build, ex. `0.9.0-rc.1+abc1234`). */
  versionApp: string;
  versionSchema: number;
  versionMovpack: number;
  disciplines: number;
  techniques: number;
  contributions: number;
  compositions: number;
  favoris: number;
  /** Médias locaux référencés / réellement présents sur le stockage. */
  mediasReferences: number;
  mediasPresents: number;
  mediasManquants: number;
  orphelins: number;
  /** Estimation d'espace, ou null si le navigateur ne sait pas répondre. */
  espace: { usage: number; quota: number } | null;
  /** Dernier échec d'une opération critique (S1.12) : code stable + opération
   *  + message éditorial tronqué — JAMAIS une stack ni un contenu personnel. */
  dernierEchec?: { quand: string; code: CodeEchec; operation: string; message: string } | null;
  /** Dernière opération LONGUE (voile ou export) de la session (P2.14) :
   *  `fin` null = elle courait ENCORE au moment du diagnostic (blocage probable). */
  operationLongue?: { libelle: string; debut: string; fin: string | null } | null;
  /** SOURCES du contenu (D-234) — identifiant de pack (ou « local ») et nombre
   *  de techniques qui en viennent. Identifiants éditoriaux, jamais de contenu.
   *  La version éditoriale N'EST PAS retenue par la bibliothèque : on ne la
   *  rapporte donc pas plutôt que de l'inventer. */
  packs?: { id: string; techniques: number }[];
  /** Sauvegardes internes : combien, et la plus récente. */
  sauvegardes?: { nombre: number; derniere: string | null };
  /** Détail du maillage et des compositions — pour situer un souci de volume. */
  relations?: number;
  compositionsARoles?: number;
  /** Capacités RÉELLES de la plateforme (D-234) : la moitié des soucis
   *  d'appareil vient de là (voix muette, écran qui s'éteint, stockage évincé). */
  capacites?: Record<string, boolean | string>;
  /** Réglages NON SENSIBLES actifs. Jamais les protections : ni PIN, ni
   *  empreinte, ni quel geste est verrouillé. */
  reglages?: Record<string, string>;
}

function mo(octets: number): string {
  return `${(octets / (1 << 20)).toFixed(1)} Mo`;
}

/** Produit un diagnostic texte lisible, exportable, sans aucun secret (§38). */
export function construireDiagnostic(e: EntreeDiagnostic): string {
  const lignes = [
    "Movenso — diagnostic technique",
    `généré : ${e.genereLe}`,
    `plateforme : ${e.plateforme}`,
    `version de l'application : ${e.versionApp}`,
    `version du schéma : ${e.versionSchema}`,
    `version du conteneur .movpack : ${e.versionMovpack}`,
    "",
    "Contenu :",
    `  disciplines : ${e.disciplines}`,
    `  techniques : ${e.techniques}`,
    `  contributions : ${e.contributions}`,
    `  compositions : ${e.compositions}${e.compositionsARoles ? ` (dont ${e.compositionsARoles} à plusieurs rôles)` : ""}`,
    `  favoris : ${e.favoris}`,
    ...(e.relations !== undefined ? [`  relations entre techniques : ${e.relations}`] : []),
    "",
    "Médias :",
    `  références locales : ${e.mediasReferences}`,
    `  fichiers présents : ${e.mediasPresents}`,
    `  vidéos manquantes (référencées, fichier absent) : ${e.mediasManquants}`,
    `  fichiers orphelins (présents, plus référencés) : ${e.orphelins}`,
    "",
    "Stockage :",
    e.espace ? `  utilisé : ${mo(e.espace.usage)} / quota estimé : ${mo(e.espace.quota)}` : "  estimation indisponible sur cet appareil",
    ...(e.sauvegardes
      ? [`  sauvegardes internes : ${e.sauvegardes.nombre}${e.sauvegardes.derniere ? ` (dernière : ${e.sauvegardes.derniere})` : ""}`]
      : []),
    "",
    ...(e.packs
      ? [
          "Sources du contenu (« local » = créé sur l'appareil) :",
          ...(e.packs.length
            ? e.packs.map((p) => `  ${p.id} : ${p.techniques} technique${p.techniques > 1 ? "s" : ""}`)
            : ["  aucune"]),
          "",
        ]
      : []),
    ...(e.capacites
      ? ["Capacités de la plateforme :",
         ...Object.entries(e.capacites).map(([k, v]) => `  ${k} : ${typeof v === "boolean" ? (v ? "oui" : "non") : v}`),
         ""]
      : []),
    ...(e.reglages
      ? ["Réglages actifs (hors protections) :",
         ...Object.entries(e.reglages).map(([k, v]) => `  ${k} : ${v}`),
         ""]
      : []),
    "Opération longue :",
    e.operationLongue
      ? e.operationLongue.fin
        ? `  ${e.operationLongue.libelle} — terminée (${e.operationLongue.debut} → ${e.operationLongue.fin})`
        : `  ${e.operationLongue.libelle} — ENCORE EN COURS au moment du diagnostic (démarrée ${e.operationLongue.debut})`
      : "  aucune depuis le démarrage",
    "",
    "Dernier échec :",
    e.dernierEchec
      ? `  [${e.dernierEchec.code}] ${e.dernierEchec.operation} — ${e.dernierEchec.message} (${e.dernierEchec.quand})`
      : "  aucun depuis le démarrage",
    "",
    // La garde unitaire « aucun secret » interdit d'écrire ici les mots des
    // protections, même pour dire qu'on ne les rapporte pas : une garde stricte
    // vaut mieux qu'une énumération rassurante.
    "Ce diagnostic ne rapporte que des informations techniques agrégées et les",
    "identifiants éditoriaux des packs installés : aucune donnée personnelle,",
    "aucun réglage de protection, aucun nom de technique ou de composition,",
    "aucun contenu de média, aucune adresse privée.",
  ];
  return lignes.join("\n");
}
