/**
 * Modèle métier de Movenso V3 — cf. docs/contrat-construction.md §2 (VALIDÉ).
 *
 * Deux idées structurantes :
 * - une Technique est une IDENTITÉ (nœud du graphe) ; le savoir vit dans des
 *   Contributions attachées, chacune qualifiée par sa Provenance (§2.2) ;
 * - aucune notion d'utilisateur ni de rôle dans les données (vision §7.1).
 */

export const VERSION_SCHEMA = 4;

/** Provenances du savoir — vocabulaire fermé (contrat §2.2). */
export const PROVENANCES = ["referentiel", "enseignement", "ressource", "personnel"] as const;
export type Provenance = (typeof PROVENANCES)[number];

/**
 * Un type de relation est une DONNÉE de la bibliothèque (D-020.2 — lève H5) :
 * le moteur ne fige plus un vocabulaire judo, il exige seulement de chaque
 * type ce qui rend le graphe affichable et validable — un libellé, un libellé
 * inverse (ou la symétrie), une origine éventuelle. Les relations restent
 * stockées dans UN seul sens ; l'inverse est toujours dérivé (contrat §2.1).
 */
/** Rôle SÉMANTIQUE d'un type de relation, indépendant du libellé français
 *  (D-136) : l'UI place les liens d'après le rôle, jamais en devinant depuis le
 *  texte. `after` a pour inverse dérivé le rôle `before` (avant/après = ligne de
 *  temps) ; `peer` = variante/distinction ; `opposition` = contre/défense ;
 *  `context` = kata/appartenance. Optionnel (repli : traité comme neutre). */
export type RoleRelation = "before" | "after" | "peer" | "opposition" | "context";

export interface TypeRelationDef {
  id: string; // slug stable, référencé par Relation.type
  libelle: string; // « Prépare »
  /** Libellé du sens dérivé (« Préparée par »). Inutile si `symetrique`. */
  libelleInverse?: string;
  /** true : la relation se lit pareil dans les deux sens (« Similaire à »). */
  symetrique?: boolean;
  /** Rôle sémantique pour le placement (D-136). */
  role?: RoleRelation;
  /** Ordre d'affichage préférentiel (D-136). */
  ordre?: number;
  /** Présent si le type vient d'un pack. */
  origine?: Origine;
}

/** Type d'alerte déclaré par la bibliothèque (D-136) — ex. « interdit en
 *  compétition ». Une alerte n'est JAMAIS une arête du graphe : c'est une
 *  métadonnée d'avertissement portée par une technique. */
interface TypeAlerteDef {
  id: string; // slug stable, référencé par Alerte.type
  libelle: string;
  niveau: "info" | "warning" | "danger";
  icone?: string;
}

/** Alerte portée par une technique (D-136) — réglementaire ou de sécurité. */
interface Alerte {
  type: string; // référence un TypeAlerteDef
  niveau: "info" | "warning" | "danger";
  icone?: string;
  libelle: string;
  detail?: string;
  /** true : l'alerte doit empêcher certaines propositions (ex. chemin de compétition). */
  bloquante?: boolean;
  reference?: { organisation?: string; article?: string; url?: string; verifieLe?: string };
}

/** Les quatre types historiques — semés par défaut, modifiables comme toute donnée. */
export const TYPES_RELATION_DEFAUT: readonly TypeRelationDef[] = [
  { id: "prepare", libelle: "Prépare", libelleInverse: "Préparée par", role: "before" },
  { id: "enchaine", libelle: "Enchaîne vers", libelleInverse: "Enchaînée depuis", role: "after" },
  { id: "contre", libelle: "Contre", libelleInverse: "Contrée par", role: "opposition" },
  { id: "similaire", libelle: "Similaire à", symetrique: true, role: "peer" },
];

/** Types de source d'un média — explicites (contrat §5). */
export const TYPES_MEDIA = ["local", "lien", "plateforme"] as const;
type TypeMedia = (typeof TYPES_MEDIA)[number];

/** Services de plateforme vidéo reconnus — explicite plutôt qu'implicite
 *  (D-017 : YouTube est un service parmi d'autres, pas une hypothèse du cœur). */
export const SERVICES_MEDIA = ["youtube"] as const;
type ServiceMedia = (typeof SERVICES_MEDIA)[number];

/** Trace vers le pack et l'élément d'origine — traçabilité, idempotence de
 *  réimport et réversibilité des rapprochements (D-013/D-015). */
interface Origine {
  pack: string;
  element: string;
}

/** La SOURCE d'un objet portant une origine de pack : l'identité du pack,
 *  sinon « local » (contenu créé sur l'appareil). Dérivation PURE du modèle —
 *  vivait historiquement dans src/echange (S3.A6/D-176 : remontée ici, le
 *  domaine ne dépend d'aucune couche). */
export function sourceDe(x: { origine?: { pack: string } }): string {
  return x.origine?.pack ?? "local";
}

export interface Famille {
  id: string;
  nom: string;
  ordre?: number;
}

export interface Niveau {
  id: string;
  nom: string;
  ordre?: number;
  /** Couleur(s) de ceinture — identité visuelle des niveaux (exploration). */
  couleur?: string;
  couleur2?: string;
}

export interface Discipline {
  id: string; // ULID
  nom: string;
  familles: Famille[];
  niveaux: Niveau[];
}

/**
 * Relation portée par la technique source, sens « source → type → cible ».
 * `type` référence un TypeRelationDef de la bibliothèque.
 * Une cible absente de la bibliothèque est tolérée (jamais bloquante).
 */
export interface Relation {
  type: string;
  cibleId: string;
  /** Explication pédagogique du lien, portée par le sens DIRECT (D-134) —
   *  ex. « le balayage avant ouvre l'arrière pour O-soto-gari ». Optionnelle,
   *  affichée telle quelle ; l'inverse dérivé la réutilise (elle décrit l'arête). */
  note?: string;
  /** Priorité éditoriale (1 = essentielle … plus grand = secondaire, D-134) :
   *  ordonne l'affichage des liens d'un même rôle. Optionnelle. */
  priorite?: number;
}

/** Couverture (vignette) personnalisée d'une technique (D-083). Deux formes :
 *  une image importée (réduite en petite vignette, stockée en data-URL — elle
 *  voyage donc avec la bibliothèque, les sauvegardes et les packs, sans toucher
 *  au stockage des vidéos), ou un renvoi vers un média déjà présent dont on
 *  réutilise la miniature (ex. vidéo YouTube). Absente = vignette par défaut. */
export type Couverture =
  | { type: "image"; dataUrl: string }
  | { type: "media"; mediaId: string };

/** Identité d'une technique. Minimal viable : id + disciplineId + nom
 *  (une technique créée à la volée pendant une capture n'a rien d'autre). */
export interface Technique {
  id: string; // ULID
  disciplineId: string;
  nom: string;
  nomTraditionnel?: string;
  familleId?: string;
  niveauxIds: string[];
  relations: Relation[];
  /** Média mis en avant sur la fiche (id d'un média d'une contribution
   *  attachée) — référence tolérante : si le média disparaît, la fiche
   *  retombe sur le premier média sourcé (jamais bloquant). */
  mediaPrincipalId?: string;
  /** Vignette personnalisée (D-083) — sinon miniature dérivée / initiale. */
  couverture?: Couverture;
  /** Alertes réglementaires / de sécurité (D-136) — jamais des arêtes du graphe. */
  alertes?: Alerte[];
  /** Présent si l'identité a été créée par l'import d'un pack. */
  origine?: Origine;
}

/** Origine d'un média LOCAL (lot 8A §2) — d'où vient le fichier. */
const ORIGINES_MEDIA = ["camera", "fichier", "import"] as const;
export type OrigineMedia = (typeof ORIGINES_MEDIA)[number];

/** Un média porté par une contribution.
 *  `ref` : chemin relatif du fichier (local), URL (lien), ou id de vidéo (plateforme).
 *  Les métadonnées (lot 8A §2) sont OPTIONNELLES : rien d'obligatoire
 *  qu'on ne sait pas obtenir de façon fiable ; un média lien/plateforme
 *  ne porte jamais de fausse taille locale. */
export interface Media {
  id: string; // ULID
  type: TypeMedia;
  ref: string;
  /** Obligatoire pour type "plateforme" : quel service héberge la vidéo. */
  service?: ServiceMedia;
  sha256?: string; // fichiers locaux : dédup (contrat §5, calculée au 8A)
  label?: string;
  /** MIME réel du fichier local (ex. video/webm). */
  mime?: string;
  /** Extension canonique dérivée du MIME — le nom physique en dépend (§6). */
  extension?: string;
  /** Nom fourni par l'utilisateur ou l'appareil — jamais le nom physique. */
  nomOriginal?: string;
  /** Taille en octets du fichier LOCAL. */
  taille?: number;
  ajouteLe?: string; // ISO 8601
  origineMedia?: OrigineMedia;
}

/**
 * Unité de savoir attachée à une technique.
 * `techniqueId: null` = capture « à rattacher » (moment chaud, nom inconnu) —
 * possible uniquement en provenance `personnel` (increment-1.md §2).
 * `attribution` obligatoire pour `referentiel` et `ressource` : un savoir de
 * référence est toujours sourcé (vision §7.2).
 */
export interface Contribution {
  id: string; // ULID
  techniqueId: string | null;
  provenance: Provenance;
  description?: string;
  pointsCles: string[];
  variantes?: string;
  attribution?: string;
  creeLe: string; // ISO 8601
  medias: Media[];
  /** Présent si la contribution vient d'un pack (clé d'idempotence au réimport). */
  origine?: Origine;
  /** Signature locale d'une édition (arbitrage humain, tuning post-V3) : quand
   *  l'utilisateur modifie une contribution issue d'un pack, on garde intacte
   *  son `origine` mais on note ici QUI a édité (le pseudo d'appareil, sinon
   *  « moi »), pour l'afficher « Modifié par … ». Optionnel, sans migration. */
  modifiePar?: string;
}

/**
 * Natures de bloc d'une composition (D-020.1). Vocabulaire du moteur car
 * l'affichage en dépend — mais volontairement large : un bloc « etape » avec
 * texte libre couvre tout ce que la liste ne nomme pas. La séquence ordonnée
 * est UNE forme de composition, pas sa définition universelle (D-019).
 */
export const TYPES_BLOC = [
  "technique", // référence vers une identité (jamais une duplication)
  "etape", // étape libre
  "transition", // contextuelle à la composition — PAS une relation du graphe (D-016/D-020)
  "consigne",
  "objectif",
  "duree", // durée ou répétitions (texte libre : « 3 min », « ×10 »)
  "media",
  "repere", // commentaire ou repère personnel
  "pause", // repos minuté d'une séance (D-125) : temps de pose en secondes, dans le déroulé
] as const;
export type TypeBloc = (typeof TYPES_BLOC)[number];

/**
 * Un ACTEUR d'une composition à plusieurs (D-227) : « Tori », « Uke »,
 * « Attaquant », « Leader »… Nommé LIBREMENT — aucun vocabulaire de discipline
 * en dur. Vit sur la composition et non sur la discipline : une composition
 * peut être mixte (D-215), et aucune taxonomie de plus n'est à gouverner.
 */
export interface Acteur {
  id: string; // court, local à la composition
  nom: string;
}

/** Anciennes valeurs de `Bloc.lien` (D-229, abandonnées en D-235) : elles
 *  mélangeaient le temps et la cause. Conservées pour LIRE les compositions
 *  écrites avant — `simultane` rejoint le temps, les deux autres en ouvrent un.
 *  Rien n'est réécrit sur disque tant que l'utilisateur ne modifie pas. */
export const LIENS_HERITES = ["simultane", "reaction", "puis"] as const;

/** Un bloc ordonné d'une composition. */
export interface Bloc {
  id: string; // ULID
  type: TypeBloc;
  /** Pour type "technique" : identité référencée (absence tolérée, comme les relations). */
  techniqueId?: string;
  /** QUI exécute ce bloc (D-227) — référence un `Acteur` de la composition.
   *  Absent = neutre (consigne, pause, transition : « les deux »). Une
   *  référence orpheline est tolérée : le bloc redevient neutre à l'affichage. */
  acteurId?: string;
  /** Ce pas REJOINT LE TEMPS du pas précédent (D-235) — il se joue donc EN MÊME
   *  TEMPS que lui. Absent ou faux = il ouvre un nouveau temps. C'est la seule
   *  relation du modèle : la simultanéité n'est pas une étiquette, c'est le
   *  SENS de partager un temps ; la cause (« en réponse à… ») se dit en
   *  `consigne`, en texte libre. Le type `string` couvre les valeurs héritées
   *  de D-229, réinterprétées à la lecture (`LIENS_HERITES`). */
  lien?: boolean | (typeof LIENS_HERITES)[number];
  texte?: string;
  medias: Media[];
  /** CONSIGNE attachée à une étape (D-124) : une note qui QUALIFIE le bloc
   *  (« gauche et droite », « sur le contre », « dans la foulée ») — jamais une
   *  étape à part. Portée surtout par un bloc `technique`, mais tolérée partout. */
  consigne?: string;
  /** Durée/temps du bloc en SECONDES (D-124) : pour une SÉANCE minutée
   *  (« échauffement 5 min »). Optionnel ; absent = pas de durée. */
  dureeSec?: number;
}

/**
 * Composition : matériau réutilisé — « Ma spéciale », un programme de grade,
 * un cours, une prestation… Ces exemples sont des FINALITÉS, pas des
 * provenances (D-019) : la provenance qualifie qui affirme, comme partout.
 */
export interface Composition {
  id: string; // ULID
  nom: string;
  description?: string;
  provenance: Provenance;
  attribution?: string;
  creeLe: string; // ISO 8601
  modifieLe?: string;
  /** Intention de la composition (D-126) — choisie à la création « en entonnoir » :
   *  un enchaînement (techniques + consignes), une séance minutée (segments +
   *  durées), ou un kata (techniques + présentation). Informatif ; adapte les
   *  défauts de saisie. Optionnel (compositions antérieures, imports). */
  type?: "enchainement" | "seance" | "kata";
  /** Composition à PLUSIEURS (D-227) : les rôles en présence, nommés par
   *  l'utilisateur. Absent ou vide = un seul exécutant — comportement
   *  historique, strictement inchangé. */
  acteurs?: Acteur[];
  blocs: Bloc[];
  /** PRÉSENTATION de la composition (D-124) : vidéo/lien qui décrit L'ENSEMBLE
   *  (démo complète du kata, vidéo « moi ») — au niveau de l'objet, JAMAIS une
   *  étape de la séquence. Optionnel. */
  presentation?: { medias: Media[] };
  /** Présent si la composition vient d'un pack. */
  origine?: Origine;
}

/**
 * Une fiche mise EN CORBEILLE (D-081) : réversible tant que la corbeille n'est
 * pas vidée. On y garde tout ce qu'il faut pour une restauration fidèle — la
 * technique, ses contributions (savoir personnel et sourcé) et le fait qu'elle
 * était en favori. Les liens ENTRANTS (portés par d'autres fiches) ne sont pas
 * copiés ici : ils restent en place, simplement masqués (leur cible ne résout
 * plus), et ne sont nettoyés qu'au vidage. Métadonnée locale — jamais publiée.
 */
export interface EntreeCorbeille {
  supprimeeLe: string; // ISO 8601
  technique: Technique;
  contributions: Contribution[];
  etaitFavori: boolean;
}

/**
 * Une FUSION réversible de deux quasi-doublons (D-101, voie H). On garde l'état
 * PRÉ-fusion des deux fiches (technique + contributions + favori) pour pouvoir
 * les RÉTABLIR (défusion). Limite assumée : les liens ENTRANTS (relations
 * d'autres fiches, blocs de composition) redirigés vers la fiche fusionnée
 * restent sur elle à la défusion — comme la corbeille ne restaure pas les liens
 * entrants. Métadonnée locale — jamais publiée.
 */
interface EntreeFusion {
  fusionneeLe: string; // ISO 8601
  /** Id de la fiche résultante (celle de A, conservée). */
  fusionneeId: string;
  a: { technique: Technique; contributions: Contribution[]; etaitFavori: boolean };
  b: { technique: Technique; contributions: Contribution[]; etaitFavori: boolean };
}

/** La bibliothèque : l'unique document racine persisté. */
export interface Bibliotheque {
  versionSchema: number;
  typesRelation: TypeRelationDef[];
  /** Types d'alerte déclarés (D-136) — voyagent dans les packs. Optionnel
   *  (absent = aucune alerte), donc rétro-compatible sans migration. */
  typesAlerte?: TypeAlerteDef[];
  disciplines: Discipline[];
  techniques: Technique[];
  contributions: Contribution[];
  compositions: Composition[];
  /** Favoris personnels (lot 5 §4) : marque-pages vers des identités de
   *  techniques — jamais une copie, jamais publiés, toujours sauvegardés. */
  favoris: string[];
  /** Paires de fiches marquées « ce ne sont pas des doublons » (D-068) : clés
   *  stables (`clePaire`) écartées de la détection des doublons potentiels.
   *  Métadonnée locale — jamais publiée dans un pack. Optionnel (absent =
   *  aucune paire ignorée), donc sans migration de schéma. */
  doublonsIgnores?: string[];
  /** Fiches mises en corbeille (D-081) : réversibles jusqu'au vidage. Optionnel
   *  (absent = corbeille vide), donc rétro-compatible avec les .movpack/états
   *  antérieurs — jamais publié dans un pack. */
  corbeille?: EntreeCorbeille[];
  /** Fusions réversibles (D-101) : de quoi défusionner deux quasi-doublons
   *  fusionnés. Optionnel (absent = aucune fusion défaisable) — jamais publié
   *  dans un pack. */
  fusions?: EntreeFusion[];
  /** Conflits de liaisons détectés à l'import (D-157) : le pack proposait une
   *  raison/priorité DIFFÉRENTE sur une arête existante. Jamais appliqué ni
   *  écarté en silence — arbitré par l'humain (la mienne / celle du pack / les
   *  deux). Métadonnée locale, jamais publiée dans un pack. Optionnel. */
  conflitsLiaisons?: ConflitLiaison[];
}

/** Un conflit de liaison à arbitrer (D-157, étendu D-243) : ce qu'un pack
 *  PROPOSE sur une arête, sans jamais l'appliquer seul. Deux sens :
 *
 *  - `contenu` (défaut, D-157) — le pack donne une raison ou une priorité
 *    différente d'une arête que la bibliothèque possède déjà ;
 *  - `retrait` (D-243) — une nouvelle version du pack **ne déclare plus** une
 *    arête qu'il avait apportée. Sans ce sens, une mise à jour n'ajoutait que
 *    des liens et n'en retirait jamais : une épuration éditoriale n'atteignait
 *    que les installations neuves.
 *
 *  Dans les deux cas la version locale reste en place tant que l'humain n'a pas
 *  tranché — elle n'est pas recopiée ici, elle vit sur l'arête. Le champ est
 *  OPTIONNEL et son absence vaut `contenu` : les conflits déjà enregistrés se
 *  relisent sans migration. */
export interface ConflitLiaison {
  pack: string; // packId d'origine de la proposition
  sourceId: string;
  cibleId: string;
  type: string; // id du type de relation
  sens?: "contenu" | "retrait"; // absent = "contenu" (D-243)
  note?: string; // raison proposée par le pack (sens « contenu » seulement)
  priorite?: number; // priorité proposée par le pack (idem)
  detecteLe: string; // ISO — date de détection (dernier import)
}

export function bibliothequeVide(): Bibliotheque {
  return {
    versionSchema: VERSION_SCHEMA,
    typesRelation: TYPES_RELATION_DEFAUT.map((t) => ({ ...t })),
    disciplines: [],
    techniques: [],
    contributions: [],
    compositions: [],
    favoris: [],
    doublonsIgnores: [],
  };
}
