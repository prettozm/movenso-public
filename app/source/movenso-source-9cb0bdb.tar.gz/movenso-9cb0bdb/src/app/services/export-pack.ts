/**
 * Service EXPORT / PUBLICATION (S3.A1, tranche T2 — extrait de racine.ts,
 * code déménagé tel quel) : export .movpack en flux (annulable, progression),
 * sauvegarde complète/diagnostic, préparation puis remise d'une publication.
 * Fonctions recevant `app` ; le drapeau d'annulation d'export vit ici.
 */

import type { MovensoApp } from "../racine.ts";
import { extrairePackDiscipline, extrairePackTechnique, exporterMovpack, exporterMovpackFlux, idDePack, idPackStable, VERSION_MOVPACK, type MetaExport } from "../../echange/movpack.ts";
import { referencesVideosLocales } from "../../domaine/medias.ts";
import { decrireSauvegarde } from "../../domaine/sauvegarde.ts";
import { telechargerFichier } from "./fichiers.ts";
import { construireDiagnostic } from "../../domaine/diagnostic.ts";
import { VERSION, COMMIT } from "../version.ts";
import { VERSION_SCHEMA, sourceDe, type Bibliotheque } from "../../domaine/modele.ts";
import { tailleEnClair } from "../../domaine/espace.ts";
import { espaceSuffisant, octetsMedias, estimationEspace } from "./espace.ts";
import { enregistrerFichierLocal, remettreFichierPartage } from "./fichiers.ts";

/** Export annulé par l'utilisateur (S2.4) — état de module. */
let exportAnnule = false;

/** Taille de bloc de lecture des médias à l'export (mémoire bornée, lot 8B §15). */
const TAILLE_BLOC_EXPORT = 1 << 20; // 1 Mio

/** Annule l'export en cours : consulté entre les blocs, il fait abandonner
 *  le fichier temporaire sans produire de conteneur partiel. */
export function annulerExport(app: MovensoApp): void {
  exportAnnule = true;
}

/** Ids des médias locaux RÉELLEMENT présents sur disque et référencés par
 *  `b` — un média absent n'entre pas dans l'export (diagnostiqué à
 *  l'Atelier), jamais transformé en entrée vide. */
export async function idsMediasPresents(app: MovensoApp, b: Bibliotheque): Promise<string[]> {
  const presents = await app.stockage.listerVideos();
  return [...referencesVideosLocales(b)].filter((id) => presents.has(id));
}

/** Export `.movpack` à MÉMOIRE BORNÉE (lot 8B §15) : le conteneur s'écrit
 *  PROGRESSIVEMENT dans un fichier temporaire OPFS (médias lus et hachés
 *  par blocs, jamais chargés en entier), puis le téléchargement se fait
 *  DEPUIS ce fichier adossé au disque — l'archive entière ne réside jamais
 *  dans le tas JS. Refus borné si le stockage temporaire est indisponible.
 *  Retourne la taille produite en octets, ou null si refusé/annulé/échoué. */
export async function exporterEnFlux(app: MovensoApp, b: Bibliotheque, meta: MetaExport, ids: string[], nomFichier: string, telecharger = true): Promise<{ taille: number; fichier: File } | null> {
  await app.stockage.nettoyerArchivesTemp(); // balaie un éventuel temporaire d'un export précédent
  // S1.9 (D-163) : la taille à écrire est CONNUE d'avance (médias présents,
  // le JSON est marginal sous la marge) — refus AVANT d'ouvrir le temporaire
  // quand l'espace fiable manque, plutôt qu'un échec en cours d'écriture.
  // L'archive temporaire est transitoire : elle se mesure au quota SYSTÈME
  // réel, jamais à la limite volontaire D-097 (sinon l'export deviendrait
  // impossible dès la limite atteinte — l'inverse de son but).
  const taillesPresentes = await app.stockage.taillesVideos();
  const aEcrire = ids.reduce((s, id) => s + (taillesPresentes.get(id) ?? 0), 0);
  if (!espaceSuffisant(app, aEcrire, await app.stockage.estimerEspace())) return null;
  const nomTemp = `export-${Date.now()}.movpack`;
  let writable: FileSystemWritableFileStream;
  try {
    writable = await app.stockage.ouvrirArchiveTemp(nomTemp);
  } catch {
    app.afficherToast("Export impossible : stockage temporaire indisponible sur cet appareil", "alerte");
    return null;
  }
  exportAnnule = false;
  app.progressionExport = { fait: 0, total: ids.length };
  app.annulationOccupe = { libelle: "Annuler", executer: () => app.annulerExport() };
  // L'export en flux est l'opération longue par excellence (P2.14/D-217) —
  // il ne passe pas par occuperPendant (voile à progression + annulation).
  app.operationLongue = { libelle: `Export de ${nomFichier}`, debut: new Date().toISOString(), fin: null };
  app.requestUpdate();
  try {
    await exporterMovpackFlux(
      b,
      meta,
      ids,
      (id) => app.stockage.lireMediaParBlocs(id, TAILLE_BLOC_EXPORT),
      { ecrire: (chunk) => writable.write(chunk as BufferSource) },
      {
        creeLe: new Date().toISOString(),
        estAnnule: () => exportAnnule,
        surProgression: (fait: number, total: number) => {
          app.progressionExport = { fait, total };
          app.requestUpdate();
        },
      },
    );
    await writable.close();
  } catch (e) {
    try {
      await writable.close();
    } catch {
      /* déjà fermé */
    }
    await app.stockage.supprimerArchiveTemp(nomTemp); // jamais de .movpack partiel conservé
    app.progressionExport = null;
    app.annulationOccupe = null;
    if (app.operationLongue && app.operationLongue.fin === null)
      app.operationLongue = { ...app.operationLongue, fin: new Date().toISOString() };
    app.requestUpdate();
    if (!exportAnnule) app.consignerEchec("MOV-E01", e);
    if (exportAnnule) app.afficherToast("Export annulé — rien n'a été téléchargé");
    else app.afficherToast(e instanceof Error ? e.message : "Export échoué", "alerte");
    return null;
  }
  // Téléchargement DEPUIS le fichier temporaire (Blob adossé au disque, pas
  // de copie en mémoire). Le temporaire est balayé au prochain export ou au
  // démarrage (nettoyerStaging) — jamais supprimé pendant que le
  // téléchargement peut encore le lire.
  const fichier = await app.stockage.fichierArchiveTemp(nomTemp);
  const taille = fichier.size;
  if (telecharger) telechargerFichier(fichier, nomFichier);
  app.progressionExport = null;
  app.annulationOccupe = null;
  if (app.operationLongue && app.operationLongue.fin === null)
    app.operationLongue = { ...app.operationLongue, fin: new Date().toISOString() };
  app.requestUpdate();
  return { taille, fichier: new File([fichier], nomFichier, { type: "application/octet-stream" }) };
}

/** Export intégral .movpack — la fondation de la propriété des données (D-018.2, R8).
 *  `avecVideos: false` = fichier léger (les vidéos restent sur l'appareil). */
export async function exporterTout(app: MovensoApp, avecVideos = true): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour créer une sauvegarde.", () => void app.exporterTout(avecVideos))) return;
  const b = app.bibliotheque;
  if (!b) return;
  // §20 : « complète » UNIQUEMENT si les vidéos sont incluses ET aucune ne
  // manque au stockage. Sinon c'est une sauvegarde PARTIELLE, exclusions
  // nommées — jamais l'étiquette « complète » sur un contenu amputé.
  const refsLocales = referencesVideosLocales(b);
  const presents = await app.stockage.listerVideos();
  const manquants = [...refsLocales].filter((id) => !presents.has(id));
  const ids = avecVideos ? [...refsLocales].filter((id) => presents.has(id)) : [];
  const desc = decrireSauvegarde({ avecVideos, nbManquants: manquants.length });
  const nom = `movenso-${desc.complete ? "complet" : "partiel"}-${new Date().toISOString().slice(0, 10)}.movpack`;
  const exp = await exporterEnFlux(app, 
    b,
    { id: "movenso-export-complet", nom: desc.complete ? "Sauvegarde complète Movenso" : "Sauvegarde partielle Movenso", portee: "complet" },
    ids,
    nom,
    false, // pas de téléchargement direct : on enregistre localement (D-106)
  );
  if (exp === null) return; // refusé, annulé ou échoué (déjà signalé)
  const taille = exp.taille;
  const emplacement = await enregistrerFichierLocal(app, exp.fichier);
  const contenu = `${b.disciplines.length} discipline${b.disciplines.length > 1 ? "s" : ""}, ${b.techniques.length} techniques, ${b.contributions.length} contenus, ${b.compositions.length} composition${b.compositions.length > 1 ? "s" : ""}, ${b.favoris.length} favori${b.favoris.length > 1 ? "s" : ""}, ${ids.length} vidéo${ids.length > 1 ? "s" : ""}`;
  app.dernierFichier = {
    role: desc.role,
    nom,
    taille,
    resume: `${contenu} — EXCLUS : ${desc.exclusions.join(" ; ")}`,
  };
  app.afficherToast(
    desc.complete
      ? `Sauvegarde complète ✓ — enregistrée dans ${emplacement}`
      : `Sauvegarde PARTIELLE ✓ (exclut ${desc.exclusions[0]}) — dans ${emplacement}`,
  );
}

/** Contexte enrichi du diagnostic (D-234) : packs installés, sauvegardes,
 *  maillage, capacités réelles de la plateforme et réglages NON sensibles.
 *  Aucun nom de technique, de discipline ou de composition — seulement des
 *  identifiants éditoriaux de packs et des compteurs. */
async function contexteDiagnostic(app: MovensoApp, b: Bibliotheque) {
  // Réserve CONNUE : la bibliothèque ne retient PAS la version éditoriale d'un
  // pack installé, seulement son identifiant sur chaque élément. On rapporte
  // donc ce qu'on sait, sans l'inventer (cf. KNOWN_LIMITATIONS).
  const parPack = new Map<string, { id: string; techniques: number }>();
  for (const t of b.techniques) {
    const pack = sourceDe(t);
    const e = parPack.get(pack) ?? { id: pack, techniques: 0 };
    e.techniques += 1;
    parPack.set(pack, e);
  }
  const sauv = await app.stockage.listerSauvegardes().catch(() => [] as string[]);
  const nav = navigator as Navigator & { share?: unknown };
  const p = app.preferences;
  return {
    packs: [...parPack.values()].sort((x, z) => x.id.localeCompare(z.id)),
    sauvegardes: { nombre: sauv.length, derniere: sauv.length ? (sauv[sauv.length - 1] ?? null) : null },
    relations: b.techniques.reduce((n, t) => n + t.relations.length, 0),
    compositionsARoles: b.compositions.filter((c) => (c.acteurs?.length ?? 0) >= 2).length,
    capacites: {
      "stockage OPFS": typeof navigator.storage?.getDirectory === "function",
      "stockage persistant accordé": await navigator.storage?.persisted?.().catch(() => false) ?? false,
      "verrou d'écran (wake lock)": "wakeLock" in navigator,
      "partage natif": typeof nav.share === "function",
      "synthèse vocale web": typeof window.speechSynthesis !== "undefined",
      "requêtes de conteneur CSS": typeof CSS !== "undefined" && CSS.supports?.("container-type: inline-size"),
      langue: navigator.language,
    } as Record<string, boolean | string>,
    reglages: {
      "mode avancé": (p.modeAvance ?? false) ? "oui" : "non",
      "bêta Relations": (p.vueRelationBeta ?? false) ? "oui" : "non",
      "bêta Compositions": (p.compositionsBeta ?? false) ? "oui" : "non",
      thème: p.theme ?? "auto",
      "écran de démarrage": p.demarrage?.mode ?? "bibliotheque",
      "son des séances": p.sonSeance ?? "les-deux",
    } as Record<string, string>,
  };
}

/** Exporte un diagnostic technique (§38) — informations agrégées, JAMAIS de
 *  secret (le builder pur ne reçoit ni PIN, ni contenu personnel, ni octets
 *  média). Un simple fichier texte, pour comprendre un souci de stockage ou
 *  d'export sans exposer de données. */
export async function exporterDiagnostic(app: MovensoApp): Promise<void> {
  const b = app.bibliotheque;
  if (!b) return;
  const presents = await app.stockage.listerVideos();
  const refs = referencesVideosLocales(b);
  const capacitor = (window as { Capacitor?: { getPlatform?: () => string } }).Capacitor;
  const texte = construireDiagnostic({
    genereLe: new Date().toISOString(),
    plateforme: capacitor?.getPlatform?.() ?? "web",
    versionApp: `${VERSION}+${COMMIT}`,
    versionSchema: VERSION_SCHEMA,
    versionMovpack: VERSION_MOVPACK,
    disciplines: b.disciplines.length,
    techniques: b.techniques.length,
    contributions: b.contributions.length,
    compositions: b.compositions.length,
    favoris: b.favoris.length,
    mediasReferences: refs.size,
    mediasPresents: presents.size,
    mediasManquants: [...refs].filter((id) => !presents.has(id)).length,
    dernierEchec: app.dernierEchec,
    operationLongue: app.operationLongue,
    orphelins: [...presents].filter((id) => !refs.has(id)).length,
    espace: await app.stockage.estimerEspace(),
    ...(await contexteDiagnostic(app, b)),
  });
  const nomDiag = `movenso-diagnostic-${new Date().toISOString().slice(0, 10)}.txt`;
  // BOM + charset explicite (D-234) : sans eux, un éditeur Windows ou un
  // visionneur Android lit l'UTF-8 en Latin-1 et rend « Movenso â€” diagnostic ».
  // Le rapport d'un utilisateur doit être lisible tel quel, partout.
  const fichier = new File(["\uFEFF" + texte], nomDiag, { type: "text/plain;charset=utf-8" });
  const emplacement = await enregistrerFichierLocal(app, fichier);
  app.afficherToast(`Diagnostic enregistré dans ${emplacement} — informations techniques uniquement, aucun secret`);
}

/** Produit le `.movpack` d'une discipline (tout ou sous-ensemble de techniques,
 *  avec/sans vidéos, auteur, note de diffusion) SANS le remettre encore : on
 *  affiche ensuite la taille et le choix enregistrer local / partager. Le
 *  carnet personnel, les favoris et les captures ne partent jamais. */
export async function preparerPublication(app: MovensoApp, disciplineId: string,
  opts: { techniques?: ReadonlySet<string>; avecVideos: boolean; auteur?: string; note?: string; nom?: string; compositionsPersonnelles?: boolean },): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour préparer ce pack.", () => void app.preparerPublication(disciplineId, opts))) return;
  const b = app.bibliotheque;
  const d = b?.disciplines.find((x) => x.id === disciplineId);
  if (!b || !d) return;
  // Toutes les sources de la discipline (plus de choix de source : D-078).
  const sources = new Set<string>(["local"]);
  for (const t of b.techniques) if (t.disciplineId === disciplineId && t.origine) sources.add(t.origine.pack);
  for (const c of b.contributions) {
    const t = c.techniqueId ? b.techniques.find((x) => x.id === c.techniqueId) : undefined;
    if (t?.disciplineId === disciplineId && c.origine) sources.add(c.origine.pack);
  }
  let extrait: Bibliotheque;
  let relationsExclues: unknown[] = [];
  try {
    ({ extrait, relationsExclues } = extrairePackDiscipline(b, disciplineId, sources, opts.techniques, {
      compositionsPersonnelles: opts.compositionsPersonnelles ?? false,
    }));
  } catch (e) {
    app.afficherToast(`Publication impossible : ${e instanceof Error ? e.message : "état inattendu"}`, "alerte");
    return;
  }
  if (extrait.techniques.length === 0) {
    app.afficherToast("Rien à publier — sélectionne au moins une technique", "alerte");
    return;
  }
  const nomPack = opts.nom?.trim() || d.nom;
  const ids = opts.avecVideos ? await idsMediasPresents(app, extrait) : [];
  const nomFichier = `${idDePack(nomPack)}.movpack`;
  const exp = await exporterEnFlux(app, 
    extrait,
    {
      id: idPackStable(d.id),
      nom: nomPack,
      portee: "discipline",
      ...(opts.auteur?.trim() ? { auteur: opts.auteur.trim() } : {}),
      ...(opts.note?.trim() ? { conditions: opts.note.trim() } : {}),
    },
    ids,
    nomFichier,
    false, // ne pas télécharger tout de suite : on laisse choisir
  );
  if (exp === null) return;
  app.publicationPrete = {
    fichier: exp.fichier,
    nomFichier,
    taille: exp.taille,
    nomPack,
    resume: `${extrait.techniques.length} technique${extrait.techniques.length > 1 ? "s" : ""}${ids.length ? `, ${ids.length} vidéo${ids.length > 1 ? "s" : ""}` : " (sans vidéo)"} — sans carnet ni favoris${relationsExclues.length ? ` ; ${relationsExclues.length} relation${relationsExclues.length > 1 ? "s" : ""} hors périmètre exclue${relationsExclues.length > 1 ? "s" : ""}` : ""}`,
  };
  app.requestUpdate();
}

/** Enregistre localement le pack préparé, à un endroit retrouvable (D-106). */
export async function enregistrerPublicationLocale(app: MovensoApp): Promise<void> {
  const p = app.publicationPrete;
  if (!p) return;
  const emplacement = await enregistrerFichierLocal(app, p.fichier);
  app.afficherToast(`« ${p.nomPack} » enregistré (${tailleEnClair(p.taille)}) dans ${emplacement}`);
  app.publicationPrete = null;
  app.requestUpdate();
}

/** Partage le pack préparé (feuille native Android, repli téléchargement). */
export async function partagerPublication(app: MovensoApp): Promise<void> {
  const p = app.publicationPrete;
  if (!p) return;
  await remettreFichierPartage(app, p.fichier, p.nomPack, `Pack « ${p.nomPack} » — Movenso`);
}

/** Abandonne le pack préparé (revient au formulaire). */
export function fermerPublication(app: MovensoApp): void {
  app.publicationPrete = null;
  app.requestUpdate();
}

/* ---------- partage d'une TECHNIQUE (T5 — rangé avec sa famille export/partage) ---------- */

/** Point d'entrée du bouton « Partager » d'une fiche (D-092) : ne montre une
 *  feuille de pré-partage QUE s'il y a un choix à faire — c.-à-d. des vidéos
 *  locales présentes qu'on peut inclure ou non (au poids parfois lourd). Sinon
 *  (que des liens en ligne, ou aucune vidéo locale sur l'appareil), le partage
 *  reste immédiat, un seul geste, comme avant. */
export async function demanderPartageTechnique(app: MovensoApp, techniqueId: string): Promise<void> {
  const b = app.bibliotheque;
  const t = b?.techniques.find((x) => x.id === techniqueId);
  if (!b || !t) return;
  let extrait: Bibliotheque;
  try {
    ({ extrait } = extrairePackTechnique(b, techniqueId));
  } catch {
    void app.partagerTechnique(techniqueId); // laisse partagerTechnique rapporter l'erreur
    return;
  }
  const presents = await app.stockage.listerVideos();
  const localesPresentes = [...referencesVideosLocales(extrait)].filter((id) => presents.has(id));
  // Rien à décider → chemin rapide, un seul geste.
  if (localesPresentes.length === 0) {
    void app.partagerTechnique(techniqueId);
    return;
  }
  const enLigne = extrait.contributions
    .flatMap((c) => c.medias)
    .filter((m) => m.type === "lien" || m.type === "plateforme").length;
  const tailles = await app.stockage.taillesVideos();
  const octetsLocaux = localesPresentes.reduce((s, id) => s + (tailles.get(id) ?? 0), 0);
  app.partagePreparation = {
    techniqueId,
    nom: t.nom,
    avecVideos: true,
    nbLiens: enLigne,
    nbLocales: localesPresentes.length,
    octetsLocaux,
  };
}

/** Confirme la feuille de pré-partage : partage avec le choix vidéos retenu. */
export async function confirmerPartage(app: MovensoApp): Promise<void> {
  const p = app.partagePreparation;
  if (!p) return;
  app.partagePreparation = null;
  await app.partagerTechnique(p.techniqueId, p.avecVideos);
}

/** Partage d'UNE technique (D-067) : produit un `.movpack` individuel de la
 *  fiche (avec ou sans sa vidéo locale) et le remet au mécanisme de partage
 *  NATIF quand il existe (Web Share API niveau 2 — disponible dans la WebView
 *  Android), avec un repli propre par téléchargement sinon. La consultation
 *  ne demande jamais de PIN (§38) — partager n'est pas une action sensible :
 *  le pack exclut par construction le carnet et tout secret. */
export async function partagerTechnique(app: MovensoApp, techniqueId: string, avecVideos = true): Promise<void> {
  const b = app.bibliotheque;
  const t = b?.techniques.find((x) => x.id === techniqueId);
  if (!b || !t) return;
  let extrait: Bibliotheque;
  try {
    ({ extrait } = extrairePackTechnique(b, techniqueId));
  } catch (e) {
    app.afficherToast(`Partage impossible : ${e instanceof Error ? e.message : "fiche illisible"}`, "alerte");
    return;
  }
  // Vidéos locales de CETTE fiche réellement présentes sur l'appareil.
  const refs = referencesVideosLocales(extrait);
  const presents = await app.stockage.listerVideos();
  const idsPresents = avecVideos ? [...refs].filter((id) => presents.has(id)) : [];
  const videos = new Map<string, Uint8Array>();
  for (const id of idsPresents) videos.set(id, await app.lireMediaComplet(id));
  const nomFichier = `${idDePack(t.nom)}.movpack`;
  let octets: Uint8Array;
  try {
    octets = await exporterMovpack(extrait, { id: `technique-${t.id}`, nom: t.nom, portee: "discipline" }, videos);
  } catch (e) {
    app.afficherToast(`Partage impossible : ${e instanceof Error ? e.message : "export échoué"}`, "alerte");
    return;
  }
  const fichier = new File([octets as BlobPart], nomFichier, { type: "application/octet-stream" });
  await remettreFichierPartage(app, fichier, t.nom, `Technique « ${t.nom} » — Movenso`);
}
