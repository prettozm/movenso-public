/**
 * PACKS OFFICIELS (S3 volet B, D-211/B2) : catalogue des packs publiés sur le
 * site public, consultable et installable depuis l'app — le pack transite par
 * le circuit d'import EXISTANT (proposition → confirmation → rapport, D-166) :
 * rien ne s'écrit sans accord, comme pour un fichier choisi à la main.
 *
 * Le catalogue vit dans `packs/index.json` À CÔTÉ de l'app sur le site public
 * (même origine → le CSP `connect-src 'self'` suffit, en web). Dans l'APK
 * (D-219), l'app n'est PAS servie par le site : les ressources se résolvent en
 * ABSOLU vers `SITE_PUBLIC` (CSP `connect-src` ouvert vers ce seul domaine).
 * Servie ailleurs (dev, e2e sans route), la requête échoue proprement →
 * état « catalogue injoignable », jamais un écran cassé.
 */
import type { MovensoApp } from "../racine.ts";

/** Racine du site public — les packs officiels y vivent (`packs/`). Le dépôt
 *  de l'app sera renommé à terme (D-212) ; movenso-public, lui, RESTE. */
const SITE_PUBLIC = "https://prettozm.github.io/movenso-public/";

export interface PackOfficiel {
  id: string;
  title: string;
  version: string;
  itemCount?: string;
  summary?: string;
  href: string;
  downloadName: string;
}

/** URL d'une ressource du site public. En WEB, relative à l'emplacement de
 *  l'app (`app/` sur le site → `../packs/…`) — même origine, e2e routable.
 *  En NATIF (Capacitor), absolue vers `SITE_PUBLIC` : l'app y est servie
 *  depuis l'appareil, le relatif ne mènerait nulle part (D-219). */
function urlSite(chemin: string): string {
  const capacitor = (window as { Capacitor?: { getPlatform?: () => string } }).Capacitor;
  const natif = (capacitor?.getPlatform?.() ?? "web") !== "web";
  return natif ? new URL(chemin, SITE_PUBLIC).toString() : new URL(`../${chemin}`, location.href).toString();
}

/** Charge (une fois) le catalogue des packs officiels. */
export async function chargerCataloguePacks(app: MovensoApp): Promise<void> {
  app.catalogueOfficiel = "chargement";
  app.requestUpdate();
  try {
    const rep = await fetch(urlSite("packs/index.json"), { cache: "no-cache" });
    if (!rep.ok) throw new Error(`HTTP ${rep.status}`);
    const brut: unknown = await rep.json();
    if (!Array.isArray(brut)) throw new Error("catalogue illisible");
    app.catalogueOfficiel = brut.filter(
      (p): p is PackOfficiel =>
        !!p && typeof p === "object"
        && typeof (p as PackOfficiel).id === "string"
        && typeof (p as PackOfficiel).title === "string"
        && typeof (p as PackOfficiel).href === "string"
        && typeof (p as PackOfficiel).downloadName === "string"
        && typeof (p as PackOfficiel).version === "string",
    );
  } catch {
    app.catalogueOfficiel = "indisponible";
  }
  app.requestUpdate();
}

/** Télécharge un pack officiel puis le remet au circuit d'import normal —
 *  la proposition chiffrée s'affiche, l'utilisateur confirme ou annule. */
export async function installerPackOfficiel(app: MovensoApp, p: PackOfficiel): Promise<void> {
  try {
    const fichier = await app.occuperPendant(`Téléchargement de « ${p.title} »…`, async () => {
      const rep = await fetch(urlSite(p.href), { cache: "no-cache" });
      if (!rep.ok) throw new Error(`HTTP ${rep.status}`);
      const blob = await rep.blob();
      return new File([blob], p.downloadName, { type: "application/octet-stream" });
    });
    await app.importerPack(fichier);
  } catch (e) {
    app.consignerEchec("MOV-E06", e);
    app.afficherToast(`Téléchargement impossible : ${e instanceof Error ? e.message : "réseau indisponible"}`, "alerte");
  }
}
