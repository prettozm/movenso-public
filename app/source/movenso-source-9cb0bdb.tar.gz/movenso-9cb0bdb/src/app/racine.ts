/**
 * <movenso-app> — racine de l'application : état, démarrage, navigation,
 * actions. Les gabarits d'écran vivent dans vues.ts et capture.ts.
 * Composants Lit en light DOM, styles globaux (src/styles/app.css).
 */

import { LitElement, html, nothing, type TemplateResult } from "lit";
import type { Bibliotheque, Composition, ConflitLiaison, Contribution, Couverture, EntreeCorbeille, Media, Provenance, Relation, Technique } from "../domaine/modele.ts";
import { bibliothequeVide } from "../domaine/modele.ts";
import { referencesVideosLocales } from "../domaine/medias.ts";
import { empreinteSha256 } from "../domaine/ingestion.ts";
import { tailleEnClair } from "../domaine/espace.ts";
import { espaceSuffisant, octetsMedias, estimationEspace, espaceInsuffisantPour, limiteEspaceOctets, changerLimiteEspace } from "./services/espace.ts";
import { choisirPackAImporter, importerPack, confirmerImport, fermerRapportImport, annulerImport, confirmerRestauration, annulerRestauration, retirerLiensProposes } from "./services/import-pack.ts";
import { chargerCataloguePacks, installerPackOfficiel, type PackOfficiel } from "./services/packs-officiels.ts";
import { annulerExport, exporterTout, exporterDiagnostic, preparerPublication, enregistrerPublicationLocale, partagerPublication, fermerPublication, idsMediasPresents, exporterEnFlux } from "./services/export-pack.ts";
import { enregistrerFichierLocal, remettreFichierPartage } from "./services/fichiers.ts";
import { ouvrirCreationCompo, creerCompositionFunnel, poserRolesFunnel, fermerCreationCompo, reculerCreationCompo, creerComposition, creerCompositionDepuisEtapes, modifierComposition, dupliquerComposition, exporterComposition, partagerComposition, retirerMediaPresentation, supprimerComposition } from "./services/compositions-actions.ts";
import { ajouterNote, ajouterMediaFiche, ajouterMediaPresentation, amenderContribution, majMediaLabel, majMediaLien, definirCouvertureImage, definirCouvertureMedia, retirerCouverture, retirerMedia, annulerIngestionVideo } from "./services/medias-fiche.ts";
import { ouvrirCapture, terminerCaptureRepere, ouvrirRattachement, fermerCapture, reculerCapture, terminerCapture } from "./services/capture.ts";
import { estFavori, basculerFavori, techniquesFavorites, doublonsPotentiels, rescannerDoublons, classerDoublon, resoudreDoublonGarder, fusionnerDoublonAvec, defusionner, creerAdaptationLocale } from "./services/favoris-doublons.ts";
import { voileOccupe, feuilleImport, feuilleRapportImport, feuilleRestauration, feuillePartage, feuilleEnregistrement, feuilleConfirmation } from "./feuilles.ts";
import { demanderPartageTechnique, confirmerPartage, partagerTechnique } from "./services/export-pack.ts";
import { majNomDiscipline, ajouterTaxonomie, majTaxonomie, usagesTaxonomie, reordonnerTaxonomie, supprimerTaxonomie, ajouterTypeRelation, majTypeRelation, basculerSymetrieTypeRelation } from "./services/taxonomies.ts";
import { evaluerPersistance, redemanderPersistance, referencesVideos, rafraichirAtelier, rattacherOrphelin, supprimerVideoOrpheline, supprimerOrphelinsVerifies, restaurerSauvegarde } from "./services/atelier-etat.ts";
import { analyserLien } from "../securite/liens.ts";
import { genererUlid } from "../domaine/ulid.ts";
import { normaliserPourRecherche } from "../domaine/recherche.ts";
import { migrerBibliotheque } from "../domaine/migrations.ts";
import { validerBibliotheque } from "../domaine/validation.ts";
import { importerDansBibliotheque, arbitrerConflitLiaison as arbitrerConflitLiaisonDomaine, type RapportImport } from "../domaine/rapprochement.ts";
import {
  estZip,
  exporterMovpack,
  exporterMovpackFlux,
  extrairePackComposition,
  extrairePackDiscipline,
  extrairePackTechnique,
  idDePack,
  idPackStable,
  lireMovpackFlux,
  VERSION_MOVPACK,
  type ContenuMovpackFlux,
  type ManifesteMovpack,
  type MediaStreame,
  type MetaExport,
} from "../echange/movpack.ts";
import { StockageOpfs, preferencesDefaut, type Preferences } from "../stockage/opfs.ts";
import { creerVerification, delaiApresEchecs, validerFormatPin, verifierPin } from "../securite/pin.ts";
import { autorisation, sessionActive, type CategorieAction, type Protections } from "../securite/politique.ts";
import { gabaritBibliotheques, gabaritDiscipline, gabaritFavoris, gabaritFiche, nomEditorialSource } from "./vues.ts";
import { gabaritPlus, gabaritPlusSection } from "./plus.ts";
import { gabaritRelationsVisuelle, definirVueRelations, gabaritEditionLien, reinitEditionLien, afficherBienvenueRelations } from "./relations-visuelle.ts";
import { RELATIONS_VISUELLES } from "./fonctionnalites.ts";
import { gabaritAjoutPas, gabaritComposition, gabaritCompositions, gabaritCreationCompo, gabaritEditionPas, gabaritEntrainement, gabaritMenuComposition, maintenirEcranSeance, reinitFunnel, relacherEcranSeance, stopperChrono, suspendreSeance, type EtatCreationCompo, reinitialiserSeance } from "./compositions.ts";
import { reinitialiserMediatheque } from "./atelier.ts";
import { nouvelleComposition, nouveauBloc } from "../domaine/composition.ts";
import { clePaire, detecterDoublons, defusionnerDoublons, fusionnerDoublons, type ChoixFusion, type PaireDoublon } from "../domaine/doublons.ts";
import { decrireSauvegarde } from "../domaine/sauvegarde.ts";
import { CODES_ECHEC, type CodeEchec } from "../domaine/diagnostic.ts";
import { VERSION_SCHEMA } from "../domaine/modele.ts";
import { gabaritCapture, type EtatCapture } from "./capture.ts";
import { gabaritAjoutMedia, type EtatAjoutMedia } from "./ajout-media.ts";
import { gabaritAjouter, type EtatAjouter } from "./ajouter.ts";
import "./video-locale.ts";

/** Sous-écrans de « Plus » (D-071) — chacun spécialisé, ouvert depuis le menu. */
export type SectionPlus =
  | "avance"
  | "packs"
  | "packs-officiels"
  | "techniques"
  | "atraiter"
  | "doublons"
  | "medias"
  | "relations"
  | "corbeille"
  | "publier"
  | "sauvegardes"
  | "securite"
  | "apparence"
  | "diagnostic"
  | "apropos";

export type Ecran =
  | { type: "bibliotheques" }
  | { type: "discipline"; disciplineId: string }
  | { type: "fiche"; techniqueId: string }
  | { type: "favoris" }
  | { type: "compositions" }
  | { type: "composition"; compositionId: string }
  /** Mode entraînement (lot 5 §14-15) : pas-à-pas plein écran — l'index vit
   *  dans l'écran, donc la pile restaure LE MÊME bloc au retour d'une fiche. */
  | { type: "entrainement"; compositionId: string; index: number }
  /** Vue visuelle des relations (« carte mentale ») — le centre vit dans l'app
   *  (`relationCentre`), pas dans l'écran, pour survivre au recentrage. */
  | { type: "relations" }
  /** « Plus » (D-071) : `section: null` = le menu ; sinon un sous-écran. */
  | { type: "plus"; section: SectionPlus | null };

/** Onglets de la barre basse (D-071 ; « relations » ajouté, drapeau RELATIONS_VISUELLES). */
export type Zone = "bibliotheque" | "favoris" | "relations" | "compositions" | "plus";

export class MovensoApp extends LitElement {
  static properties = {
    bibliotheque: { state: true },
    ecran: { state: true },
    capture: { state: true },
    ajoutMedia: { state: true },
    ajouter: { state: true },
    creationCompo: { state: true },
    ajoutPas: { state: true },
    editionPas: { state: true },
    editionLien: { state: true },
    menuComposition: { state: true },
    partagePreparation: { state: true },
    enregistrementMedia: { state: true },
    toast: { state: true },
    toastAlerte: { state: true },
    confirmation: { state: true },
    catalogueOfficiel: { state: true },
    occupe: { state: true },
    preferences: { state: true },
    erreurDemarrage: { state: true },
  };

  // Propriétés réactives : déclarées puis initialisées dans le constructeur —
  // un champ de classe natif (ES2022) masquerait les accesseurs créés par Lit.
  declare bibliotheque: Bibliotheque | null;
  declare ecran: Ecran;
  declare capture: EtatCapture | null;
  /** Feuille « Ajouter un média » de la fiche (lot 3 §5). */
  declare ajoutMedia: EtatAjoutMedia | null;
  /** Panneau contextuel « Ajouter » (lot 4 §2-3). */
  declare ajouter: EtatAjouter | null;
  /** Entonnoir de création d'une composition (D-126) : nom → type → premiers pas. */
  declare creationCompo: EtatCreationCompo | null;
  /** Feuille « Ajouter un élément » en lecture d'une composition (D-126) — porte l'id de la compo cible. */
  declare ajoutPas: string | null;
  /** Mini-feuille d'édition d'un pas (D-126) : composition + bloc ciblés. */
  declare editionPas: { compoId: string; blocId: string } | null;
  /** Feuille « Lien » (D-156) : créer/éditer une relation entre techniques.
   *  `cibleId`+`typeId` présents = édition d'une arête existante ; sinon
   *  création (source connue ; `sourceId` null = source à choisir, entrée
   *  Plus › Relations). `typePrefere` présélectionne le type. */
  declare editionLien: { sourceId: string | null; cibleId?: string; typeId?: string; typePrefere?: string } | null;
  /** Menu « ⋮ » d'une composition (D-126) — porte l'id de la compo ; remplace le crayon global. */
  declare menuComposition: string | null;
  /** Feuille de pré-partage d'une fiche (D-092) — n'existe que s'il y a un choix
   *  à faire (des vidéos locales à inclure ou non). */
  declare partagePreparation:
    | { techniqueId: string; nom: string; avecVideos: boolean; nbLiens: number; nbLocales: number; octetsLocaux: number }
    | null;
  /** Progression de l'écriture d'un média local (D-098) — panneau bloquant :
   *  phase « analyse » (empreinte, indéterminé) puis « écriture » (% réel +
   *  durée restante mesurée). null hors écriture. */
  declare enregistrementMedia:
    | { phase: "analyse" | "ecriture"; fraction: number; octets: number; etaSec: number | null }
    | null;
  declare toast: string | null;
  declare toastAlerte: boolean;
  /** C2 (D-204) : demande de confirmation NOMMÉE en cours (feuille maison). */
  declare confirmation: { titre: string; corps?: string; bouton: string; action: () => void } | null;
  /** Catalogue des packs officiels du site public (B2, D-211) — null = jamais chargé. */
  declare catalogueOfficiel: import("./services/packs-officiels.ts").PackOfficiel[] | "chargement" | "indisponible" | null;
  /** Annulation offerte par le voile (S2.4/D-168) — null quand l'opération en
   *  cours n'est pas annulable (transactions courtes : installation,
   *  restauration — la cohérence passe avant le confort). */
  annulationOccupe: { libelle: string; executer: () => void } | null = null;
  /** Lecture de pack en cours : l'utilisateur a demandé l'abandon (S2.4). */
  #lectureAnnulee = false;

  /** Opération longue en cours (D-127) — message affiché dans un voile bloquant
   *  « … en cours » ; empêche le sentiment d'app figée (import/restauration). */
  declare occupe: string | null;
  declare preferences: Preferences;
  /** Message d'échec de démarrage (D-110) — stockage indisponible (vieux WebView
   *  sans OPFS) ou état illisible/incompatible : on montre un message plutôt
   *  qu'un écran blanc. */
  declare erreurDemarrage: string | null;

  /** État d'affichage léger (non réactif, non persisté). */
  rechercheGlobale = "";
  /** Sections de Pratique dépliées (« Voir tout », lot 5 §2) — session. */
  pratiqueDeplie: { reprendre: boolean; favoris: boolean } = { reprendre: false, favoris: false };
  mediasDeplies = new Set<string>();
  creationDiscipline = false;
  /** Filtres de la Bibliothèque — cumulables (qualité V2, D-012). Depuis
   *  D-067, la racine est une grille unifiée de TOUTES les disciplines : la
   *  discipline devient un filtre compact (comme la source, la famille, le
   *  niveau), et les favoris se filtrent d'un geste. */
  filtres: {
    disciplineId: string | null;
    niveauId: string | null;
    familleId: string | null;
    source: string | null;
    favorisSeuls: boolean;
    texte: string;
  } = {
    disciplineId: null,
    niveauId: null,
    familleId: null,
    source: null,
    favorisSeuls: false,
    texte: "",
  };

  /** Panneau de fusion sélective d'une paire de doublons potentiels (D-068) —
   *  état de session, non persisté. */
  fusionDoublon: { aId: string; bId: string; choix: ChoixFusion } | null = null;
  /** Paire de doublons ouverte en détail dans l'écran « Doublons » (D-071) —
   *  clé stable (`clePaire`) ; null = liste compacte. */
  doublonOuvert: string | null = null;
  /** Discipline sélectionnée dans « Packs et disciplines » (D-072) — une seule
   *  fiche de gestion affichée à la fois (jamais un empilement). */
  disciplineGestion: string | null = null;

  stockage = new StockageOpfs();
  #minuteurToast: ReturnType<typeof setTimeout> | undefined;
  /** Heure de péremption du toast — garde si le minuteur est gelé (WebView). */
  #toastExpireA = 0;

  constructor() {
    super();
    this.bibliotheque = null;
    this.ecran = { type: "bibliotheques" };
    this.capture = null;
    this.ajoutMedia = null;
    this.ajouter = null;
    this.creationCompo = null;
    this.ajoutPas = null;
    this.editionPas = null;
    this.editionLien = null;
    this.menuComposition = null;
    this.partagePreparation = null;
    this.enregistrementMedia = null;
    this.toast = null;
    this.toastAlerte = false;
    this.confirmation = null;
    this.catalogueOfficiel = null;
    this.occupe = null;
    this.preferences = preferencesDefaut();
    this.erreurDemarrage = null;
  }

  override createRenderRoot() {
    return this; // light DOM : styles globaux, pas de Shadow DOM
  }

  override connectedCallback(): void {
    super.connectedCallback();
    void this.#demarrer();
    // §8/§20 : en mode « jusqu'à l'arrière-plan », quitter l'écran
    // verrouille immédiatement — jamais d'apparition furtive déverrouillée ;
    // pour 5/15 min, l'horodatage d'inactivité s'applique de lui-même au retour.
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden" && (this.preferences.protections?.verrouillage ?? "5min") === "arriere-plan")
        this.verrouiller(true);
      // S2.3 (D-170) : l'arrière-plan SUSPEND la séance (les minuteurs d'un
      // onglet caché dérivent — recette appareil) ; au retour, on redemande le
      // verrou d'écran que le navigateur a relâché en cachant l'app.
      if (this.ecran.type !== "entrainement") return;
      if (document.visibilityState === "hidden") suspendreSeance(this);
      else void maintenirEcranSeance();
    });
    // S2.10 (tranche 2) : Échap ferme la modale du dessus — chaque voile sait
    // déjà fermer proprement sa feuille (même chemin que le toucher hors
    // feuille). Le voile OCCUPÉ (`.voile-occupe`) n'est pas concerné : une
    // opération en cours ne s'abandonne que par son bouton Annuler explicite.
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      const voiles = document.querySelectorAll<HTMLElement>(".voile");
      const dessus = voiles[voiles.length - 1];
      if (dessus) { e.preventDefault(); dessus.click(); }
    });
  }

  async #demarrer(): Promise<void> {
    // Aucun contenu n'est embarqué (D-017) : l'application démarre vide de
    // contenu mais jamais vide d'action — importer un pack, créer sa
    // discipline, ou capturer tout de suite et structurer plus tard.
    // S1.12 (D-166) : toute erreur NON GÉRÉE est consignée pour le diagnostic
    // (opération + message, jamais de stack) — sans preventDefault : la
    // console et le harnais e2e continuent de la voir.
    window.addEventListener("error", (ev) => this.consignerEchec("MOV-E99", ev.error ?? ev.message));
    window.addEventListener("unhandledrejection", (ev) => this.consignerEchec("MOV-E98", ev.reason));
    // PC (D-228) : une rangée de filtres déborde HORIZONTALEMENT et sa barre est
    // masquée (conçue pour le pouce). À la souris, la molette VERTICALE défilait
    // donc la page et la rangée restait inatteignable. On traduit la molette en
    // défilement horizontal quand le pointeur est au-dessus d'une rangée qui
    // déborde — écouteur unique et délégué (toutes les rangées, un seul endroit).
    window.addEventListener(
      "wheel",
      (ev: WheelEvent) => {
        if (ev.ctrlKey || ev.shiftKey) return; // zoom et défilement horizontal natif : intouchés
        const rangee = (ev.target as Element | null)?.closest?.(".chips-filtres");
        if (!(rangee instanceof HTMLElement)) return;
        if (rangee.scrollWidth <= rangee.clientWidth + 1) return; // ne déborde pas : la page défile
        const pas = Math.abs(ev.deltaY) > Math.abs(ev.deltaX) ? ev.deltaY : ev.deltaX;
        if (pas === 0) return;
        const avant = rangee.scrollLeft;
        rangee.scrollLeft += pas;
        if (rangee.scrollLeft !== avant) ev.preventDefault(); // aux bornes, la page reprend la main
      },
      { passive: false },
    );
    // Web : demander la persistance pour limiter l'éviction du stockage par
    // le navigateur (contrat §4 — sans effet dans la WebView Android) et
    // LIRE le résultat pour l'afficher (S1.9) : une donnée locale qui peut
    // être purgée en silence n'est pas une promesse tenue.
    void evaluerPersistance(this, true);
    // Lot 8A §7 : un résidu de staging est un débris d'écriture interrompue.
    void this.stockage.nettoyerStaging();
    let b: Bibliotheque | null;
    try {
      // Garde de démarrage (D-110, généralisée S1.10/D-167) : si le stockage
      // est indisponible ou l'état illisible/incompatible, un message clair
      // PAR PLATEFORME s'affiche au lieu d'un écran blanc. Deux capacités
      // testées : `getDirectory` (OPFS) ET `createWritable` (nos écritures) —
      // Safari expose la première sans la seconde et cassait plus loin.
      const aOpfs = !!navigator.storage?.getDirectory;
      const aEcriture = typeof FileSystemFileHandle !== "undefined" && "createWritable" in FileSystemFileHandle.prototype;
      if (!aOpfs || !aEcriture) {
        const capacitor = (window as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
        throw new Error(
          capacitor?.isNativePlatform?.()
            ? "Le stockage local n'est pas disponible sur cette version d'Android. Mets à jour Android System WebView (Play Store), puis rouvre Movenso."
            : "Le stockage local n'est pas disponible sur ce navigateur. Movenso fonctionne sur Chrome, Edge et Firefox récents (Safari n'est pas encore supporté). Tes données d'un autre appareil restent transportables : une sauvegarde .movpack s'importe sur n'importe quel navigateur supporté.",
        );
      }
      b = await this.stockage.charger();
      if (b === null) {
        b = bibliothequeVide();
        await this.stockage.sauvegarder(b);
      }
    } catch (e) {
      this.erreurDemarrage =
        e instanceof Error && e.message.startsWith("Le stockage")
          ? e.message
          : "Movenso n'a pas pu lire ses données sur cet appareil. Si tu viens d'installer une version plus ANCIENNE par-dessus une récente, réinstalle la dernière version — tes données ne sont pas perdues.";
      this.requestUpdate();
      return;
    }
    this.preferences = await this.stockage.chargerPreferences();
    this.#appliquerApparence();
    this.bibliotheque = b;
    // S1.5 (D-166, option C) : réconciliation SIGNALÉE — un crash entre
    // promotion et persistance peut laisser des fichiers orphelins ; on les
    // détecte au démarrage et on le DIT. Jamais de suppression automatique
    // (« proposé, jamais subi ») : le nettoyage se décide dans Plus › Médias.
    void this.#signalerOrphelins(b);
    // Comportement de démarrage (lot 1 §3) : la Bibliothèque par défaut ;
    // sinon la dernière discipline consultée, ou une discipline choisie.
    const { mode, disciplineId } = this.preferences.demarrage;
    const cible = mode === "discipline" ? disciplineId : mode === "derniere" ? this.preferences.derniereDisciplineId : undefined;
    if ((mode === "discipline" || mode === "derniere") && cible && b.disciplines.some((d) => d.id === cible)) {
      this.ecran = { type: "discipline", disciplineId: cible };
    } else if (mode === "discipline" && disciplineId) {
      // Lot 6 §26 : la discipline choisie a disparu — retour automatique à
      // la Bibliothèque, information DISCRÈTE, jamais de blocage.
      this.afficherToast("La discipline choisie au démarrage n'existe plus — ouverture sur la Bibliothèque");
    } else if (mode === "favoris") {
      this.ecran = { type: "favoris" };
    } else if (mode === "compositions" && (this.preferences.compositionsBeta ?? false)) {
      this.ecran = { type: "compositions" };
    } else if (mode === "relations" && RELATIONS_VISUELLES && this.preferences.vueRelationBeta) {
      this.ouvrirRelationsVisuelle();
    }
    // sinon : la Bibliothèque, déjà l'écran par défaut.
    await this.#brancherBoutonRetour();
  }

  /** Balayage d'orphelins au démarrage (S1.5/D-166, option C) : des fichiers
   *  vidéo présents qu'aucune donnée ne référence — séquelle possible d'un
   *  crash entre promotion et persistance. Signalé discrètement, jamais
   *  supprimé d'office ; sans effet et sans blocage en cas d'erreur. */
  async #signalerOrphelins(b: Bibliotheque): Promise<void> {
    try {
      const presents = await this.stockage.listerVideos();
      const refs = referencesVideos(this, b);
      let n = 0;
      for (const id of presents) if (!refs.has(id)) n++;
      if (n > 0)
        this.afficherToast(
          `${n} fichier${n > 1 ? "s" : ""} vidéo orphelin${n > 1 ? "s" : ""} détecté${n > 1 ? "s" : ""} — vérifie et nettoie dans Plus › Médias`,
        );
    } catch {
      /* jamais bloquant au démarrage */
    }
  }

  /** Dernier échec d'une opération critique (S1.12/D-166) — pour le
   *  diagnostic uniquement : jamais de stack, message tronqué à 200
   *  caractères, aucune donnée personnelle (nos messages sont éditoriaux). */
  dernierEchec: { quand: string; code: CodeEchec; operation: string; message: string } | null = null;

  /** Dernière opération LONGUE de la session (voile ou export, P2.14/D-217) —
   *  pour le diagnostic : `fin` null = elle court encore (blocage probable). */
  operationLongue: { libelle: string; debut: string; fin: string | null } | null = null;

  /** INTERNE aux services extraits (S3.A1) — pas une API produit. Le code
   *  STABLE vient de `CODES_ECHEC` (D-217) : le libellé d'opération en dérive. */
  consignerEchec(code: CodeEchec, e: unknown): void {
    const message = (e instanceof Error ? e.message : String(e)).slice(0, 200);
    this.dernierEchec = { quand: new Date().toISOString(), code, operation: CODES_ECHEC[code], message };
  }

  /** Jour/nuit et tonalité (D-025) — appliqués via attributs sur <html>. */
  #appliquerApparence(): void {
    const racine = document.documentElement;
    const theme = this.preferences.theme ?? "auto";
    if (theme === "auto") delete racine.dataset["theme"];
    else racine.dataset["theme"] = theme;
    const tonalite = this.preferences.tonalite ?? "vermillon";
    if (tonalite === "vermillon") delete racine.dataset["tonalite"];
    else racine.dataset["tonalite"] = tonalite;
  }

  changerApparence(patch: { theme?: Preferences["theme"]; tonalite?: Preferences["tonalite"] }): void {
    this.preferences = {
      ...this.preferences,
      ...(patch.theme !== undefined ? { theme: patch.theme } : {}),
      ...(patch.tonalite !== undefined ? { tonalite: patch.tonalite } : {}),
    };
    this.#appliquerApparence();
    void this.stockage.sauvegarderPreferences(this.preferences);
  }

  /** Densité de la grille Bibliothèque (D-087) : 1 à 4 colonnes, borné, persisté.
   *  Réglage d'appareil ; s'applique à la seule Bibliothèque. */
  /** Densité de la grille Bibliothèque (D-090). `null` = Auto (réactif à la
   *  taille de l'écran, défaut) ; sinon 1..6 colonnes forcées. Persiste entre
   *  les lancements (réglage d'appareil, jamais exporté). */
  changerDensite(n: number | null): void {
    if (n === null) {
      const { densiteBibliotheque: _retire, ...reste } = this.preferences;
      this.preferences = reste;
    } else {
      const borne = Math.max(1, Math.min(6, Math.round(n)));
      this.preferences = { ...this.preferences, densiteBibliotheque: borne };
    }
    void this.stockage.sauvegarderPreferences(this.preferences);
    this.requestUpdate();
  }

  /** Transition de préparation avant un pas minuté (D-125), en secondes —
   *  réglage d'appareil, appliqué et persisté immédiatement. */
  definirTransition(sec: number): void {
    this.preferences = { ...this.preferences, transitionSec: Math.max(0, Math.round(sec)) };
    void this.stockage.sauvegarderPreferences(this.preferences);
    this.requestUpdate();
  }

  /** Retour sonore du pas-à-pas (D-125) — voix + bips / voix / bips / muet. */
  definirSonSeance(mode: "les-deux" | "voix" | "bips" | "muet"): void {
    this.preferences = { ...this.preferences, sonSeance: mode };
    void this.stockage.sauvegarderPreferences(this.preferences);
    this.requestUpdate();
  }

  /** Bascule un réglage booléen d'appareil (D-084 : mode avancé, vue relation
   *  bêta) — jamais exporté, appliqué et persisté immédiatement. */
  basculerReglage(cle: "modeAvance" | "vueRelationBeta" | "compositionsBeta"): void {
    this.preferences = { ...this.preferences, [cle]: !this.preferences[cle] };
    void this.stockage.sauvegarderPreferences(this.preferences);
    this.requestUpdate();
  }

  /** Pseudo local (D-072) — signe le contenu créé sur cet appareil. Réglage
   *  d'appareil, jamais exporté. Vide = « Mon contenu ». */
  changerPseudo(pseudo: string): void {
    const propre = pseudo.trim().slice(0, 40);
    this.preferences = { ...this.preferences, pseudo: propre };
    void this.stockage.sauvegarderPreferences(this.preferences);
    this.requestUpdate();
  }

  changerDemarrage(mode: Preferences["demarrage"]["mode"], disciplineId?: string): void {
    this.preferences = {
      ...this.preferences,
      demarrage: { mode, ...(disciplineId !== undefined ? { disciplineId } : {}) },
    };
    void this.stockage.sauvegarderPreferences(this.preferences);
  }

  /** Bouton retour Android : ferme la couche du dessus, sinon met en veille. */
  async #brancherBoutonRetour(): Promise<void> {
    const capacitor = (window as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
    if (!capacitor?.isNativePlatform?.()) return;
    const { App } = await import("@capacitor/app");
    // Ordre déterministe (lot 1 §9) : 1. clavier (système) → 2. feuille ou
    // panneau → 3. quitter l'édition (sauvegardée au fil de l'eau : rien de
    // non enregistré à perdre) → 4-5. pile (fiche → liste, sous-destination →
    // racine) → 6. racine Pratique/Atelier → Bibliothèque → 7. système.
    await App.addListener("backButton", () => {
      const estRacine =
        this.ecran.type === "bibliotheques" ||
        this.ecran.type === "favoris" ||
        this.ecran.type === "compositions" ||
        (this.ecran.type === "plus" && this.ecran.section === null);
      if (this.demandePin) this.annulerDemandePin(); // ferme SANS exécuter l'action protégée (§20)
      else if (this.capture) this.reculerCapture();
      else if (this.ajoutMedia) this.ajoutMedia = null;
      else if (this.partagePreparation) this.partagePreparation = null;
      else if (this.ajouter) this.ajouter = null;
      else if (this.editionPas) this.editionPas = null;
      else if (this.editionLien) this.editionLien = null;
      else if (this.ajoutPas) this.ajoutPas = null;
      else if (this.menuComposition) this.menuComposition = null;
      else if (this.creationCompo) reculerCreationCompo(this);
      else if (this.importEnAttente) void this.annulerImport();
      else if (this.rapportApresImport) this.fermerRapportImport();
      else if (this.restaurationEnAttente) void this.annulerRestauration();
      else if (this.menuFiche) {
        this.menuFiche = false;
        this.requestUpdate();
      } else if (this.editionFiche) {
        // Bouton retour = quitter en gardant les changements (auto-enregistrés) ;
        // seule la croix ✕ annule (D-105). On oublie l'instantané sans restaurer.
        this.#instantaneEdition = null;
        this.editionFiche = false;
        this.requestUpdate();
      } else if (this.#pile.length) this.retour();
      else if (!estRacine) {
        this.#effacerToast();
        this.ecran = this.#racineZone(); // sous-destination → racine de son onglet
        window.scrollTo({ top: 0 });
      } else if (this.ecran.type !== "bibliotheques") this.ouvrirBibliotheque();
      else void App.minimizeApp();
    });
  }

  /* ---------- lectures ---------- */

  technique(id: string): Technique | undefined {
    return this.bibliotheque?.techniques.find((t) => t.id === id);
  }

  /* ---------- navigation : pile (retour = d'où l'on vient, D-023.0) +
     mémoire par onglet (lot 1 §8 : changer d'onglet ne réinitialise pas) ---------- */

  #pile: { ecran: Ecran; defilement: number }[] = [];
  /** État conservé par onglet pendant la session (écran, pile, défilement). */
  #memoireOnglets: Partial<
    Record<Zone, { ecran: Ecran; pile: { ecran: Ecran; defilement: number }[]; defilement: number }>
  > = {};

  /** Navigation empilée : le retour ramène à l'écran d'origine (fiche ↔ composition compris). */
  #aller(ecran: Ecran): void {
    this.#effacerToast(); // un toast n'accompagne jamais un changement d'écran (5.7)
    this.#pile.push({ ecran: this.ecran, defilement: window.scrollY });
    if (this.#pile.length > 24) this.#pile.shift();
    this.ecran = ecran;
    window.scrollTo({ top: 0 });
  }

  /** Bascule d'onglet (lot 1 §8) : l'onglet quitté garde son état pendant la
   *  session ; un second appui sur l'onglet actif revient à sa racine. */
  #allerRacine(racine: Ecran): void {
    const cible: Zone =
      racine.type === "favoris" ? "favoris"
        : racine.type === "relations" ? "relations"
          : racine.type === "compositions" ? "compositions"
            : racine.type === "plus" ? "plus"
              : "bibliotheque";
    const quittee = this.zoneCourante();
    this.#effacerToast(); // un toast n'accompagne jamais un changement d'écran (5.7)
    this.#memoriserEtatFiche(); // une fiche quittée garde sa voix/son média (§19)
    if (quittee === cible) {
      // second appui sur l'onglet déjà actif : retour à sa racine (comportement constant, documenté)
      this.#pile = [];
      this.ecran = racine;
      window.scrollTo({ top: 0 });
      return;
    }
    this.#memoireOnglets[quittee] = { ecran: this.ecran, pile: [...this.#pile], defilement: window.scrollY };
    const memo = this.#memoireOnglets[cible];
    if (memo) {
      this.#pile = [...memo.pile];
      this.ecran = memo.ecran;
      this.#restaurerEtatFiche(); // l'onglet peut restaurer une fiche (§19)
      void this.updateComplete.then(() => window.scrollTo({ top: memo.defilement }));
    } else {
      this.#pile = [];
      this.ecran = racine;
      window.scrollTo({ top: 0 });
    }
  }

  retour(): void {
    this.#effacerToast(); // un toast n'accompagne jamais un changement d'écran (5.7)
    this.menuFiche = false;
    this.#memoriserEtatFiche();
    const precedent = this.#pile.pop();
    if (precedent) {
      this.ecran = precedent.ecran;
      void this.updateComplete.then(() => window.scrollTo({ top: precedent.defilement }));
    } else {
      this.ecran = this.#racineZone();
      window.scrollTo({ top: 0 });
    }
    this.#restaurerEtatFiche();
  }

  /** Racine de la zone courante — le repli du retour quand la pile est vide. */
  #racineZone(): Ecran {
    const zone = this.zoneCourante();
    return zone === "favoris"
      ? { type: "favoris" }
      : zone === "relations"
        ? { type: "relations" }
        : zone === "compositions"
          ? { type: "compositions" }
          : zone === "plus"
            ? { type: "plus", section: null }
            : { type: "bibliotheques" };
  }

  /** Dernière technique consultée — centre par défaut de la vue visuelle des
   *  relations (session ; jamais persisté). */
  derniereTechniqueVue: string | null = null;
  /** Centre courant de la vue visuelle des relations (recentrage au clic). */
  relationCentre: string | null = null;

  ouvrirFiche(techniqueId: string): void {
    this.editionFiche = false;
    this.#instantaneEdition = null;
    this.menuFiche = false;
    this.ajoutMedia = null;
    this.derniereTechniqueVue = techniqueId;
    this.#memoriserEtatFiche();
    this.#aller({ type: "fiche", techniqueId });
    this.#restaurerEtatFiche();
  }

  /** Ouvre la vue visuelle des relations (onglet « Relations » / bouton fiche).
   *  `centre` fixe la technique au centre (et devient le centre mémorisé, R3) ;
   *  sinon on garde le centre courant / le dernier mémorisé. `vue` (D-138 R5/R19)
   *  fixe le mode de lecture — l'icône réseau de la fiche ouvre la **Carte**, le
   *  lien « Voir toutes les relations » ouvre la **Liste** ; on persiste ce mode
   *  ET on l'applique à l'état vivant de l'écran (`definirVueRelations`), sinon
   *  l'hydratation « une seule fois » ne le prendrait pas en compte. */
  /** Rouvre la BIENVENUE de Relations depuis l'aide (D-180) : les règles du
   *  jeu et le rôle de chaque vue, puis le choix d'un point de départ. */
  ouvrirBienvenueRelations(): void {
    afficherBienvenueRelations();
    this.#allerRacine({ type: "relations" });
  }

  ouvrirRelationsVisuelle(centre?: string, vue?: "liste" | "mindmap" | "classique" | "explorer"): void {
    if (centre) {
      this.relationCentre = centre;
      this.preferences = { ...this.preferences, relationsCentreId: centre };
      void this.stockage.sauvegarderPreferences(this.preferences);
    }
    if (vue) {
      this.enregistrerVueRelations(vue);
      definirVueRelations(vue);
    }
    this.#allerRacine({ type: "relations" });
  }

  /** Recentre la vue Relations sur une technique (D-137) : met à jour le centre
   *  courant ET le mémorise (réglage d'appareil, jamais exporté) pour retrouver
   *  exactement ce centre en rouvrant l'onglet. Point de passage UNIQUE du
   *  recentrage (l'historique de session, lui, vit dans l'écran). */
  recentrerRelations(id: string): void {
    this.relationCentre = id;
    this.preferences = { ...this.preferences, relationsCentreId: id };
    void this.stockage.sauvegarderPreferences(this.preferences);
    this.requestUpdate();
  }

  /** Mémorise le mode de lecture de Relations (D-137) — Liste / Mindmap /
   *  Explorer ; réglage d'appareil, jamais exporté. */
  enregistrerVueRelations(vue: "liste" | "mindmap" | "classique" | "explorer"): void {
    this.preferences = { ...this.preferences, relationsVue: vue };
    void this.stockage.sauvegarderPreferences(this.preferences);
  }

  /** Technique au centre de la vue visuelle (D-137, contrat de navigation
   *  déterministe R1). Ordre STRICT : centre explicite (transmis par une fiche)
   *  → centre mémorisé (R3) → dernière technique ouverte en Bibliothèque →
   *  sinon `null`. Un `null` ne redirige JAMAIS vers la Bibliothèque : l'écran
   *  Relations affiche « Choisis un point de départ ». Aucun choix arbitraire
   *  (fini l'ancien repli « première technique avec des liens »). `null` aussi
   *  quand la bibliothèque est vide (message « ajoute-en d'abord »). */
  techniqueCentreRelations(): string | null {
    const b = this.bibliotheque;
    if (!b || b.techniques.length === 0) return null;
    const valide = (id: string | null | undefined): id is string => !!id && b.techniques.some((t) => t.id === id);
    if (valide(this.relationCentre)) return this.relationCentre;
    if (valide(this.preferences.relationsCentreId)) return this.preferences.relationsCentreId;
    if (valide(this.derniereTechniqueVue)) return this.derniereTechniqueVue;
    return null;
  }

  /** État de consultation conservé PAR fiche pendant la session (lot 3 §19) :
   *  naviguer vers une technique liée puis revenir retrouve la voix ouverte,
   *  le média affiché et l'état des relations. */
  #etatFiches = new Map<string, { mediaAffiche: string | null; voixOuverte: string | null; relationsDepliees: boolean }>();

  #memoriserEtatFiche(): void {
    if (this.ecran.type !== "fiche") return;
    this.#etatFiches.set(this.ecran.techniqueId, {
      mediaAffiche: this.mediaAffiche,
      voixOuverte: this.voixOuverte,
      relationsDepliees: this.relationsDepliees,
    });
  }

  #restaurerEtatFiche(): void {
    if (this.ecran.type !== "fiche") return;
    const memo = this.#etatFiches.get(this.ecran.techniqueId);
    this.mediaAffiche = memo?.mediaAffiche ?? null;
    this.voixOuverte = memo?.voixOuverte ?? null;
    this.relationsDepliees = memo?.relationsDepliees ?? false;
  }

  /** Filtres conservés PAR discipline pendant la session (lot 2 §13). */
  #filtresParDiscipline = new Map<string, MovensoApp["filtres"]>();

  /** Met à jour les filtres de l'explorateur courant — et leur mémoire par discipline. */
  majFiltres(filtres: MovensoApp["filtres"]): void {
    this.filtres = filtres;
    if (this.ecran.type === "discipline") this.#filtresParDiscipline.set(this.ecran.disciplineId, filtres);
    this.requestUpdate();
  }

  ouvrirDiscipline(disciplineId: string): void {
    this.filtres =
      this.#filtresParDiscipline.get(disciplineId) ??
      { disciplineId: null, niveauId: null, familleId: null, source: null, favorisSeuls: false, texte: "" };
    this.#aller({ type: "discipline", disciplineId });
    // Mémorise la « dernière bibliothèque consultée » pour le démarrage.
    if (this.preferences.derniereDisciplineId !== disciplineId) {
      this.preferences = { ...this.preferences, derniereDisciplineId: disciplineId };
      void this.stockage.sauvegarderPreferences(this.preferences);
    }
  }

  /** Onglet « Bibliothèque » : toujours la racine (liste des disciplines,
   *  recherche globale, état vide actionnable) — jamais de saut opaque (lot 1 §3-4). */
  ouvrirBibliotheque(): void {
    this.#allerRacine({ type: "bibliotheques" });
  }

  /* ---------- Atelier : état calculé (asynchrone, rafraîchi à l'ouverture) ---------- */
  /* ---------- taxonomies + état de l'Atelier — DÉLÉGUÉS (S3.A1 T6) ----------
     La logique vit dans services/taxonomies.ts et services/atelier-etat.ts. */

  async majNomDiscipline(id: string, nom: string): Promise<void> { return majNomDiscipline(this, id, nom); }
  async ajouterTaxonomie(...args: Parameters<typeof ajouterTaxonomie> extends [unknown, ...infer R] ? R : never): Promise<void> { return ajouterTaxonomie(this, ...args); }
  async majTaxonomie(...args: Parameters<typeof majTaxonomie> extends [unknown, ...infer R] ? R : never): Promise<void> { return majTaxonomie(this, ...args); }
  usagesTaxonomie(...args: Parameters<typeof usagesTaxonomie> extends [unknown, ...infer R] ? R : never): Technique[] { return usagesTaxonomie(this, ...args); }
  reordonnerTaxonomie(...args: Parameters<typeof reordonnerTaxonomie> extends [unknown, ...infer R] ? R : never): void { return reordonnerTaxonomie(this, ...args); }
  async supprimerTaxonomie(...args: Parameters<typeof supprimerTaxonomie> extends [unknown, ...infer R] ? R : never): Promise<void> { return supprimerTaxonomie(this, ...args); }
  async ajouterTypeRelation(libelle: string, libelleInverse: string): Promise<void> { return ajouterTypeRelation(this, libelle, libelleInverse); }
  async majTypeRelation(...args: Parameters<typeof majTypeRelation> extends [unknown, ...infer R] ? R : never): Promise<void> { return majTypeRelation(this, ...args); }
  async basculerSymetrieTypeRelation(id: string): Promise<void> { return basculerSymetrieTypeRelation(this, id); }
  async redemanderPersistance(): Promise<void> { return redemanderPersistance(this); }
  async rattacherOrphelin(fichierId: string, techniqueId: string): Promise<void> { return rattacherOrphelin(this, fichierId, techniqueId); }
  async supprimerVideoOrpheline(id: string): Promise<void> { return supprimerVideoOrpheline(this, id); }
  async supprimerOrphelinsVerifies(ids: string[]): Promise<void> { return supprimerOrphelinsVerifies(this, ids); }
  async restaurerSauvegarde(nom: string): Promise<void> { return restaurerSauvegarde(this, nom); }

  /** Vidéos locales référencées mais absentes de l'appareil (diagnostic actionnable). */
  mediasManquants: { techniqueId: string | null; nom: string }[] = [];
  /** Fichiers vidéo présents mais que plus rien ne référence (lot 6 §13). */
  videosOrphelines: { id: string; taille: number }[] = [];
  /** Tailles des fichiers vidéo présents (médiathèque, lot 6 §14). */
  taillesVideos: Map<string, number> = new Map();
  /** Estimation système d'espace (usage/quota) rafraîchie avec l'atelier —
   *  sert l'affichage de la carte « Espace » (D-097). */
  infoEspace: { usage: number; quota: number } | null = null;
  sauvegardes: string[] = [];
  /** État de persistance du stockage (S1.9) : évalué au démarrage, affiché
   *  dans la carte « Espace » — `native` = bac à sable applicatif (Android),
   *  `inconnue` = le navigateur ne sait pas répondre (honnêteté §10). */
  persistanceStockage: "accordee" | "refusee" | "native" | "inconnue" = "inconnue";

  /** Onglet « Plus » (D-071) — le menu de gestion/réglages ; les compteurs
   *  d'état des lignes sont rafraîchis à l'ouverture. */
  ouvrirPlus(): void {
    this.#allerRacine({ type: "plus", section: null });
    void rafraichirAtelier(this);
  }

  /** Ouvre un sous-écran de « Plus » (empilé — le retour ramène au menu). */
  ouvrirPlusSection(section: SectionPlus): void {
    // Packs officiels (B2) : le catalogue se charge à la première ouverture.
    if (section === "packs-officiels" && this.catalogueOfficiel === null) void chargerCataloguePacks(this);
    this.doublonOuvert = null;
    if (section === "medias" || section === "atraiter") reinitialiserMediatheque(); // KPI repliés à chaque arrivée (D-104/107)
    if (this.zoneCourante() !== "plus") this.#allerRacine({ type: "plus", section: null });
    this.#aller({ type: "plus", section });
    void rafraichirAtelier(this);
  }

  /** Onglet « Favoris » (D-071) : les techniques favorites, accès direct. */
  ouvrirFavoris(): void {
    this.#allerRacine({ type: "favoris" });
  }

  /* ---------- Atelier : taxonomies et types de relation (données, D-017/D-020) ---------- */

  /** Onglet « Compositions » (D-071) — racine de son onglet. */
  ouvrirCompositions(): void {
    this.#allerRacine({ type: "compositions" });
  }

  ouvrirComposition(compositionId: string): void {
    this.menuComposition = null;
    this.#aller({ type: "composition", compositionId });
  }

  /** Notification TRANSITOIRE (lot 5 §5.7) : remplace la précédente,
   *  disparaît seule après une durée courte, est effacée par tout
   *  changement d'écran et ne se rend jamais sur l'écran d'entraînement. */
  afficherToast(message: string, niveau: "neutre" | "alerte" = "neutre"): void {
    // C2 (D-204) : deux niveaux SEULEMENT — « alerte » (refus, échec, garde)
    // change la couleur et passe en annonce assertive ; tout le reste inchangé.
    this.toast = message;
    this.toastAlerte = niveau === "alerte";
    this.#toastExpireA = Date.now() + 3400;
    clearTimeout(this.#minuteurToast);
    this.#minuteurToast = setTimeout(() => (this.toast = null), 3400);
  }

  /** C2 (D-204) : remplace le confirm() natif sur les chemins DESTRUCTIFS —
   *  une feuille thémable au verbe NOMMÉ (« Supprimer <nom> »), fermée par le
   *  voile/Échap sans effet ; l'action ne part que par son bouton. */
  demanderConfirmation(demande: { titre: string; corps?: string; bouton: string; action: () => void }): void {
    this.confirmation = demande;
  }

  #effacerToast(): void {
    clearTimeout(this.#minuteurToast);
    this.toast = null;
  }

  /** Exécute un travail LONG en affichant un voile « … en cours » (D-127) :
   *  l'app ne paraît jamais figée pendant un import/une restauration/un export.
   *  Le voile se retire quoi qu'il arrive (succès, erreur, annulation). */
  async occuperPendant<T>(message: string, travail: () => Promise<T>): Promise<T> {
    this.occupe = message;
    this.operationLongue = { libelle: message, debut: new Date().toISOString(), fin: null };
    this.requestUpdate();
    try {
      return await travail();
    } finally {
      this.occupe = null;
      // Opérations imbriquées : la plus récente a déjà clos la sienne — on ne
      // réécrit jamais une fin déjà posée.
      if (this.operationLongue && this.operationLongue.fin === null)
        this.operationLongue = { ...this.operationLongue, fin: new Date().toISOString() };
      this.requestUpdate();
    }
  }

  override willUpdate(changed: Map<PropertyKey, unknown>): void {
    super.willUpdate(changed);
    // Une plateforme peut geler les minuteurs (WebView en retrait) : au
    // premier rendu suivant, un toast périmé disparaît quand même.
    if (this.toast && Date.now() >= this.#toastExpireA) this.#effacerToast();
    // Sortie du pas-à-pas par N'IMPORTE QUEL chemin (retour, onglet, fiche…) :
    // on coupe le chrono + la voix immédiatement — jamais de son ni de timer
    // qui traîne, jamais d'auto-avance qui ré-ouvrirait le player (D-126).
    if (changed.has("ecran") && this.ecran.type !== "entrainement") { stopperChrono(); relacherEcranSeance(); }
    // S2.3 (D-170) : pendant l'entraînement, l'écran ne s'éteint pas tout seul
    // (Screen Wake Lock) — idempotent, redemandé à chaque pas sans effet.
    if (changed.has("ecran") && this.ecran.type === "entrainement") void maintenirEcranSeance();
  }

  /* S2.10 (tranche 2) : gestion CENTRALE du focus des modales — à l'ouverture
   * d'une feuille, le focus entre dedans (le champ `autofocus` s'il existe,
   * sinon la feuille elle-même, `tabindex="-1"` — pas de clavier virtuel
   * surprise) ; à la fermeture, il REVIENT à l'élément qui l'avait. */
  #ouvreurFeuille: HTMLElement | null = null;
  #feuilleOuverte = false;

  override updated(): void {
    const feuille = document.querySelector<HTMLElement>('.feuille[role="dialog"]');
    if (feuille && !this.#feuilleOuverte) {
      this.#feuilleOuverte = true;
      const actif = document.activeElement;
      this.#ouvreurFeuille = actif instanceof HTMLElement && actif !== document.body ? actif : null;
      if (!feuille.contains(actif)) (feuille.querySelector<HTMLElement>("[autofocus]") ?? feuille).focus();
    } else if (!feuille && this.#feuilleOuverte) {
      this.#feuilleOuverte = false;
      if (this.#ouvreurFeuille?.isConnected) this.#ouvreurFeuille.focus();
      this.#ouvreurFeuille = null;
    }
  }

  /* ---------- sécurité (lot 7) : protections facultatives d'appareil ---------- */

  /** État des deux protections (§2) — lu par la politique centralisée. */
  get reglagesProtections(): Protections {
    const p = this.preferences.protections;
    return { modifications: p?.modifications ?? false, suppressions: p?.suppressions ?? false };
  }

  /** Un PIN est-il configuré sur cet appareil ? (une vérification n'existe que
   *  si au moins une protection est active, §12). Décision D-115 : le
   *  commentaire de fiche, éditable en lecture pour la note rapide (D-044),
   *  devient LECTURE SEULE dès qu'un PIN protège l'appareil — la consultation
   *  reste alors une pure consultation (aucune écriture furtive). */
  get pinConfigure(): boolean {
    return this.preferences.protections?.verification !== undefined;
  }

  async #persisterProtections(protections: NonNullable<Preferences["protections"]>): Promise<void> {
    this.preferences = { ...this.preferences, protections };
    await this.stockage.sauvegarderPreferences(this.preferences);
    this.requestUpdate();
  }

  /** Active une protection (§3). Première activation : `creation` porte le
   *  PIN et sa confirmation — rien n'est activé si elles diffèrent ou si
   *  le format est refusé ; jamais de PIN incomplet enregistré. Un PIN
   *  existant sert aux deux protections. Retourne l'erreur, ou null. */
  async activerProtection(
    quoi: "modifications" | "suppressions",
    creation?: { pin: string; confirmation: string },
  ): Promise<string | null> {
    const actuel = this.preferences.protections;
    let verification = actuel?.verification;
    if (!verification) {
      if (!creation) return "Crée d'abord un PIN";
      const erreur = validerFormatPin(creation.pin);
      if (erreur) return erreur;
      if (creation.pin !== creation.confirmation) return "Les deux saisies ne correspondent pas";
      verification = await creerVerification(creation.pin);
    }
    await this.#persisterProtections({
      modifications: quoi === "modifications" ? true : (actuel?.modifications ?? false),
      suppressions: quoi === "suppressions" ? true : (actuel?.suppressions ?? false),
      verrouillage: actuel?.verrouillage ?? "5min",
      verification,
    });
    this.#journaliser("protection activée");
    this.afficherToast(`Protection ${quoi === "modifications" ? "des modifications" : "des suppressions et opérations sensibles"} activée ✓`);
    return null;
  }

  /** Désactive une protection — exige le PIN actuel (§12). Quand plus
   *  aucune protection n'est active, le secret est SUPPRIMÉ. */
  async desactiverProtection(quoi: "modifications" | "suppressions", pin: string): Promise<string | null> {
    const actuel = this.preferences.protections;
    if (!actuel?.verification) return null;
    if (!(await verifierPin(pin, actuel.verification))) return "PIN incorrect";
    const suivant = {
      ...actuel,
      modifications: quoi === "modifications" ? false : actuel.modifications,
      suppressions: quoi === "suppressions" ? false : actuel.suppressions,
    };
    if (!suivant.modifications && !suivant.suppressions) {
      // §12 : aucun secret conservé par inertie — plus rien n'est protégé.
      await this.#persisterProtections({ modifications: false, suppressions: false });
      this.#journaliser("protections désactivées — secret supprimé");
      this.afficherToast("Plus aucune action n'est protégée — les données du PIN ont été supprimées");
    } else {
      await this.#persisterProtections(suivant);
      this.afficherToast("Protection désactivée ✓ — l'autre reste active");
    }
    return null;
  }

  /** Durée de la session curateur (§8) — appliquée par la boucle 7.3. */
  async choisirVerrouillage(mode: "5min" | "15min" | "arriere-plan"): Promise<void> {
    const actuel = this.preferences.protections;
    if (!actuel) return;
    await this.#persisterProtections({ ...actuel, verrouillage: mode });
  }

  /** Changement du PIN (§11) : vérifier l'actuel, dériver le nouveau avec
   *  un NOUVEAU sel ; en cas d'échec l'ancien reste valable — jamais
   *  d'installation sans vérification. */
  async changerPin(actuel: string, nouveau: string, confirmation: string): Promise<string | null> {
    const protections = this.preferences.protections;
    if (!protections?.verification) return "Aucun PIN à changer";
    if (!(await verifierPin(actuel, protections.verification))) return "PIN actuel incorrect";
    const erreur = validerFormatPin(nouveau);
    if (erreur) return erreur;
    if (nouveau !== confirmation) return "Les deux saisies ne correspondent pas — l'ancien PIN reste valable";
    await this.#persisterProtections({ ...protections, verification: await creerVerification(nouveau) });
    this.#sessionDeverrouilleeA = null; // §11 : toute session active se ferme
    this.#journaliser("PIN modifié");
    this.afficherToast("PIN changé ✓");
    return null;
  }

  /* ---------- sécurité (lot 7 §7-10) : déverrouillage au point d'action,
     session curateur — mémoire seulement, jamais persistée ni sauvegardée ---------- */

  /** Horodatage du dernier geste autorisé — null = verrouillée. */
  #sessionDeverrouilleeA: number | null = null;
  #echecsPin = 0;
  #prochainEssaiPinA = 0;
  /** Demande de PIN contextuelle : la raison affichée et l'action à
   *  reprendre automatiquement après déverrouillage (§7). */
  demandePin: { raison: string; action: () => void | Promise<void>; erreur?: string } | null = null;

  get sessionDeverrouillee(): boolean {
    return sessionActive(this.#sessionDeverrouilleeA, this.preferences.protections?.verrouillage ?? "5min", Date.now());
  }

  /** Cœur de la garde (§17) : vrai si l'action est libre (l'activité
   *  prolonge la session) ; sinon ouvre le panneau PIN avec l'action à
   *  reprendre — les arguments capturés dans la fermeture font que rien
   *  n'est perdu (§19). */
  /** INTERNE aux services extraits (S3.A1) — pas une API produit. */
  garde(categorie: CategorieAction, raison: string, action: () => void | Promise<void>): boolean {
    if (autorisation(categorie, this.reglagesProtections, this.sessionDeverrouillee) === "libre") {
      if (this.#sessionDeverrouilleeA !== null && this.sessionDeverrouillee) this.#sessionDeverrouilleeA = Date.now();
      return true;
    }
    this.demandePin = { raison, action };
    this.requestUpdate();
    return false;
  }

  /** Point d'entrée UNIQUE des workflows protégés (§17) : exécute si
   *  autorisé, sinon ouvre le panneau PIN en conservant le contexte. */
  autoriser(categorie: CategorieAction, raison: string, action: () => void | Promise<void>): void {
    if (this.garde(categorie, raison, action)) void action();
  }

  /** Nombre agrégé d'échecs de PIN (§23) — jamais les valeurs tentées. */
  echecsCumules = 0;

  /** Verrouillage manuel (§8) — et automatique à l'arrière-plan. */
  verrouiller(silencieux = false): void {
    if (this.#sessionDeverrouilleeA !== null) this.#journaliser(silencieux ? "verrouillé à l'arrière-plan" : "verrouillage manuel");
    this.#sessionDeverrouilleeA = null;
    if (!silencieux) this.afficherToast("Verrouillé — le PIN sera demandé à la prochaine action protégée");
    this.requestUpdate();
  }

  annulerDemandePin(): void {
    // Annuler revient exactement au contexte précédent : rien n'a été
    // exécuté, rien n'est modifié (§7).
    this.demandePin = null;
    this.requestUpdate();
  }

  /** Vérifie le PIN saisi : succès = session ouverte + reprise AUTOMATIQUE
   *  de l'action ; échec = erreur sobre + temporisation progressive (§10). */
  async validerDemandePin(pin: string): Promise<void> {
    const demande = this.demandePin;
    const verification = this.preferences.protections?.verification;
    if (!demande || !verification) return;
    const attente = Math.ceil((this.#prochainEssaiPinA - Date.now()) / 1000);
    if (attente > 0) {
      this.demandePin = { ...demande, erreur: `Attends ${attente} s avant le prochain essai` };
      this.requestUpdate();
      return;
    }
    if (!(await verifierPin(pin, verification))) {
      this.#echecsPin++;
      this.echecsCumules++;
      const delai = delaiApresEchecs(this.#echecsPin);
      this.#prochainEssaiPinA = Date.now() + delai * 1000;
      this.demandePin = { ...demande, erreur: delai ? `PIN incorrect — prochain essai dans ${delai} s` : "PIN incorrect" };
      this.requestUpdate();
      return;
    }
    this.#echecsPin = 0;
    this.#prochainEssaiPinA = 0;
    this.#sessionDeverrouilleeA = Date.now();
    this.#journaliser("déverrouillage réussi");
    this.demandePin = null;
    this.requestUpdate();
    await demande.action(); // reprise automatique de l'action initiale (§7)
  }

  /** Panneau PIN contextuel (§7, §24) : titre, raison, erreur annoncée. */
  #feuillePin() {
    const demande = this.demandePin!;
    return html`
      <div class="voile" @click=${() => this.annulerDemandePin()}></div>
      <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Action protégée">
        <div class="prise"></div>
        <h2>Action protégée</h2>
        <div class="geste">${demande.raison}</div>
        <div class="creation-discipline" style="margin-top:8px">
          <input type="password" inputmode="numeric" autocomplete="off" aria-label="PIN"
                 placeholder="PIN" class="champ-pin"
                 @keydown=${(e: KeyboardEvent) => {
                   if (e.key === "Enter") void this.validerDemandePin((e.target as HTMLInputElement).value);
                 }}>
          <button class="bouton principal"
            @click=${(e: Event) => {
              const champ = (e.target as HTMLElement).parentElement!.querySelector("input")!;
              void this.validerDemandePin(champ.value);
            }}>Déverrouiller</button>
        </div>
        ${demande.erreur ? html`<p class="details erreur-pin" role="alert" style="color:var(--accent); padding-top:6px">${demande.erreur}</p>` : nothing}
        <div class="actions">
          <button class="bouton" @click=${() => this.annulerDemandePin()}>Annuler</button>
        </div>
      </div>
    `;
  }

  /** Indication discrète de session ouverte (§16) — jamais un gros mode
   *  Admin ; propose le verrouillage manuel. */
  #indicateurSession() {
    const p = this.reglagesProtections;
    if (!(p.modifications || p.suppressions) || !this.sessionDeverrouillee) return nothing;
    return html`<button class="session-curateur" title="Modifications temporairement déverrouillées"
      @click=${() => this.verrouiller()}>🔓 déverrouillé · <b>Verrouiller</b></button>`;
  }

  /** Journal minimal de sécurité (§23) — MÉMOIRE DE SESSION seulement :
   *  jamais persisté, jamais exporté, jamais de valeur secrète. */
  journalSecurite: string[] = [];

  #journaliser(evenement: string): void {
    this.journalSecurite = [...this.journalSecurite.slice(-9), `${new Date().toTimeString().slice(0, 5)} · ${evenement}`];
  }

  /** Remise à zéro complète (§22) : opération SENSIBLE — le PIN si protégé
   *  arrive à l'entrée du panneau (UI), la confirmation renforcée reste
   *  due ; ni hash ni session ne survivent. Jamais appelée « Déconnexion ». */
  async reinitialiserTout(): Promise<void> {
    await this.stockage.reinitialiser();
    this.bibliotheque = bibliothequeVide();
    await this.stockage.sauvegarder(this.bibliotheque);
    this.preferences = preferencesDefaut();
    await this.stockage.sauvegarderPreferences(this.preferences);
    this.#sessionDeverrouilleeA = null;
    this.#echecsPin = 0;
    this.#prochainEssaiPinA = 0;
    this.journalSecurite = [];
    this.#appliquerApparence();
    this.#pile = [];
    this.#memoireOnglets = {};
    this.ecran = { type: "bibliotheques" };
    this.mediasManquants = [];
    this.videosOrphelines = [];
    this.taillesVideos = new Map();
    this.sauvegardes = [];
    this.dernierFichier = null;
    window.scrollTo({ top: 0 });
    this.afficherToast("Movenso réinitialisé — bibliothèque vide, aucune protection, aucun PIN");
  }

  /* ---------- échanger : importer un pack (geste utilisateur, D-017) ---------- */
  /* ---------- échanger : importer un pack — DÉLÉGUÉS (S3.A1 T1) ----------
     La logique vit dans services/import-pack.ts ; la racine garde l'état
     réactif (importEnAttente, restaurationEnAttente, rapportApresImport) et
     une ligne par point d'entrée public (vues + e2e). */

  choisirPackAImporter(): void { return choisirPackAImporter(this); }
  async importerPack(fichier: File): Promise<void> { return importerPack(this, fichier); }
  async installerPackOfficiel(p: PackOfficiel): Promise<void> { return installerPackOfficiel(this, p); }
  rechargerCataloguePacks(): void { void chargerCataloguePacks(this); }
  async confirmerImport(): Promise<void> { return confirmerImport(this); }
  fermerRapportImport(): void { return fermerRapportImport(this); }
  async annulerImport(): Promise<void> { return annulerImport(this); }
  async confirmerRestauration(): Promise<void> { return confirmerRestauration(this); }
  async annulerRestauration(): Promise<void> { return annulerRestauration(this); }

  /** Proposition d'import en attente de confirmation humaine. */
  importEnAttente: {
    bibliotheque: Bibliotheque;
    rapport: RapportImport;
    packId: string;
    /** Médias déjà écrits en staging (D-114), promus vers `videos/` à la
     *  confirmation seulement — jamais leurs octets en mémoire. */
    medias: MediaStreame[];
    /** Ce pack est déjà installé (réimport = mise à jour, D-118). */
    dejaInstalle: boolean;
    /** Manifeste du conteneur (.movpack) — absent pour un JSON nu. */
    manifeste?: ManifesteMovpack;
    /** Taille du fichier importé, en octets. */
    volume: number;
    /** Contenu brut annoncé par le pack (avant fusion). */
    contenus: { techniques: number; contributions: number };
    /** Fichiers inattendus signalés par la lecture du conteneur (§14). */
    avertissements: string[];
  } | null = null;

  /** Rapport APRÈS import (lot 6 §18) — jamais un simple « Import réussi ». */
  rapportApresImport: {
    discipline: string;
    disciplineId: string | null;
    rejointes: number;
    creees: number;
    suggestions: { nom: string; candidats: string[] }[];
    videos: number;
    conflitsLiaisons: number;
    retraitsProposes: number;
  } | null = null;

  /** Ingestion d'un fichier vidéo (D-098) : empreinte (phase « analyse ») puis,
   *  si le fichier est neuf et que l'espace suffit, écriture avec **panneau de
   *  progression** (% réel + durée restante mesurée). Retourne le média et s'il
   *  a fallu écrire ; `null` si refusé (espace — toast déjà posé). Le panneau est
   *  toujours nettoyé (finally). */
  /** L'utilisateur a demandé l'abandon de l'ingestion en cours (S2.4). */

  /** Bouton « Annuler » de la feuille de progression (S2.4/D-168) — l'abandon
   *  est vérifié entre les blocs (analyse ET écriture), rien de définitif. */
  /** Délégué (S3.A1 T1) : la logique vit dans services/espace.ts. */
  async changerLimiteEspace(mo: number): Promise<void> {
    return changerLimiteEspace(this, mo);
  }

  /** Restauration intégrale (R8) proposée AVANT toute écriture (lot 6 §23) —
   *  uniquement sur une installation vierge : les ids sont conservés tels
   *  quels, rien n'est rapproché ni réécrit. */
  restaurationEnAttente: ContenuMovpackFlux | null = null;

  /** Taille des blocs de lecture/écriture de l'export à mémoire bornée (§15). */

  /** Progression d'un export en cours (média courant / total) — §15. */
  progressionExport: { fait: number; total: number } | null = null;

  /** Dernier fichier produit (pack publié ou sauvegarde) — la sortie dit son
   *  nom réel, sa taille et son contenu (lot 6 §20-21), jamais un faux succès. */
  dernierFichier: { role: string; nom: string; taille: number; resume: string } | null = null;

  /* ---------- export / publication — DÉLÉGUÉS (S3.A1 T2) ----------
     La logique vit dans services/export-pack.ts (et services/fichiers.ts
     pour l'enregistrement local / le partage natif). */

  annulerExport(): void { return annulerExport(this); }
  async exporterTout(avecVideos = true): Promise<void> { return exporterTout(this, avecVideos); }
  async exporterDiagnostic(): Promise<void> { return exporterDiagnostic(this); }
  async preparerPublication(...args: Parameters<typeof preparerPublication> extends [unknown, ...infer R] ? R : never): Promise<void> { return preparerPublication(this, ...args); }
  async enregistrerPublicationLocale(): Promise<void> { return enregistrerPublicationLocale(this); }
  async partagerPublication(): Promise<void> { return partagerPublication(this); }
  fermerPublication(): void { return fermerPublication(this); }

  /* ---------- Publication reprise (tuning post-V3) : préparer PUIS choisir
     enregistrer localement OU partager, avec la taille réelle ---------- */

  /** Pack produit, en attente d'une remise (enregistrement local ou partage). */
  publicationPrete: { fichier: File; nomFichier: string; taille: number; nomPack: string; resume: string } | null = null;

  /** Fermeture 1 (D-023) : une bibliothèque se peuple aussi SANS capture —
   *  discipline → première technique → fiche, sans impasse. Le minimum
   *  suffit (lot 4 §4) ; appellation et classification restent facultatives. */
  /** SEUL écrivain d'une nouvelle technique (S2.1/D-169, option V) : trim,
   *  discipline vérifiée, forme canonique. Ne persiste PAS et n'ouvre rien —
   *  chaque appelant garde sa transaction et son UX (la capture n'ouvre pas
   *  la fiche, l'explorateur si). Retourne l'id, ou null si refusé. */
  /** INTERNE aux services extraits (S3.A1) — pas une API produit. */
  pousserNouvelleTechnique(
    b: Bibliotheque,
    disciplineId: string,
    nom: string,
    extras?: { nomTraditionnel?: string; familleId?: string; niveauxIds?: string[] },
  ): string | null {
    const propre = nom.trim();
    if (!propre || !b.disciplines.some((d) => d.id === disciplineId)) return null;
    const id = genererUlid();
    b.techniques.push({
      id,
      disciplineId,
      nom: propre,
      ...(extras?.nomTraditionnel?.trim() ? { nomTraditionnel: extras.nomTraditionnel.trim() } : {}),
      ...(extras?.familleId ? { familleId: extras.familleId } : {}),
      niveauxIds: extras?.niveauxIds ?? [],
      relations: [],
    });
    return id;
  }

  async creerTechnique(
    disciplineId: string,
    nom: string,
    extras?: { nomTraditionnel?: string; familleId?: string; niveauxIds?: string[] },
  ): Promise<void> {
    if (!this.garde("modification", "Saisis le PIN pour créer une technique.", () => void this.creerTechnique(disciplineId, nom, extras))) return;
    const b = this.bibliotheque;
    if (!b) return;
    const id = this.pousserNouvelleTechnique(b, disciplineId, nom, extras);
    if (!id) return;
    const propre = nom.trim();
    await this.persister(b);
    this.ouvrirFiche(id);
    this.editionFiche = true; // prête à recevoir famille, niveau, appellation…
    this.afficherToast(`« ${propre} » créée ✓ — complète-la, ou capture dessus`);
  }

  async creerDiscipline(nom: string): Promise<string | null> {
    if (!this.garde("modification", "Saisis le PIN pour créer une discipline.", () => void this.creerDiscipline(nom))) return null;
    const b = this.bibliotheque;
    const propre = nom.trim();
    if (!b || !propre) return null;
    const existante = b.disciplines.find((d) => normaliserPourRecherche(d.nom) === normaliserPourRecherche(propre));
    if (existante) {
      this.afficherToast(`« ${existante.nom} » existe déjà`);
      return existante.id;
    }
    const id = genererUlid();
    b.disciplines.push({ id, nom: propre, familles: [], niveaux: [] });
    await this.persister(b);
    this.afficherToast(`Discipline « ${propre} » créée ✓ — capture ou importe, elle se remplira`);
    return id;
  }

  /** Compte les relations qui seraient rompues par la suppression d'un type. */
  usagesTypeRelation(id: string): number {
    return (this.bibliotheque?.techniques ?? []).reduce(
      (n, t) => n + t.relations.filter((r) => r.type === id).length,
      0,
    );
  }

  /** Retire UN lien précis (source → type → cible) depuis l'écran des relations
   *  (D-080) : on enlève la relation STOCKÉE sur la source ; l'inverse étant
   *  dérivé, les deux lectures disparaissent d'un coup. */
  async retirerRelation(sourceId: string, cibleId: string, typeId: string): Promise<void> {
    if (!this.garde("modification", "Saisis le PIN pour retirer ce lien.", () => void this.retirerRelation(sourceId, cibleId, typeId))) return;
    const b = this.bibliotheque;
    const source = b?.techniques.find((t) => t.id === sourceId);
    if (!b || !source) return;
    source.relations = source.relations.filter((r) => !(r.type === typeId && r.cibleId === cibleId));
    await this.persister(b);
    this.afficherToast("Lien retiré ✓");
  }

  /** Arbitre UN conflit de liaison détecté à l'import (D-157/D-243) : la
   *  mienne / celle du pack / les deux, ou — pour un retrait proposé — garder
   *  ou retirer. Jamais silencieux. */
  async arbitrerConflitLiaison(conflit: ConflitLiaison, choix: "local" | "pack" | "deux" | "retirer"): Promise<void> {
    if (!this.garde("modification", "Saisis le PIN pour arbitrer ce conflit.", () => void this.arbitrerConflitLiaison(conflit, choix))) return;
    const b = this.bibliotheque;
    if (!b) return;
    arbitrerConflitLiaisonDomaine(b, conflit, choix);
    await this.persister(b);
    this.afficherToast(
      choix === "retirer" ? "Lien retiré ✓"
        : choix === "local" ? "Ton lien conservé ✓"
        : choix === "pack" ? "Version du pack appliquée ✓"
        : "Les deux raisons conservées ✓",
    );
  }

  /** Accepte EN BLOC les retraits proposés par un pack (D-243) — le détail vit
   *  au service (`services/import-pack.ts`), racine ne fait que déléguer. */
  async retirerTousLesLiensProposes(packId: string): Promise<void> {
    if (!this.garde("destruction_ou_sensible", "Saisis le PIN pour retirer ces liens.", () => void this.retirerTousLesLiensProposes(packId))) return;
    retirerLiensProposes(this, packId);
  }

  /** Ouvre la feuille « Lien » (D-156) — création (cible/type absents) ou
   *  édition d'une arête existante. `sourceId` null = source à choisir aussi
   *  (entrée Plus › Relations, avec un type présélectionné). */
  ouvrirEditionLien(sourceId: string | null, cibleId?: string, typeId?: string, typePrefere?: string): void {
    if (!this.garde("modification", "Saisis le PIN pour modifier les liens.", () => this.ouvrirEditionLien(sourceId, cibleId, typeId, typePrefere))) return;
    reinitEditionLien();
    this.editionLien = {
      sourceId,
      ...(cibleId !== undefined ? { cibleId } : {}),
      ...(typeId !== undefined ? { typeId } : {}),
      ...(typePrefere !== undefined ? { typePrefere } : {}),
    };
    this.requestUpdate();
  }

  /** Crée UN lien (source → type → cible) avec sa raison/priorité (D-156).
   *  Refus actionnables : cible absente, auto-lien, doublon (même type + même
   *  cible). L'inverse n'est JAMAIS stocké (dérivé, contrat §2.1). */
  async ajouterRelation(sourceId: string, rel: Relation): Promise<boolean> {
    if (!this.garde("modification", "Saisis le PIN pour créer un lien.", () => void this.ajouterRelation(sourceId, rel))) return false;
    const b = this.bibliotheque;
    const source = b?.techniques.find((t) => t.id === sourceId);
    if (!b || !source) return false;
    if (rel.cibleId === sourceId) { this.afficherToast("Une technique ne peut pas être liée à elle-même", "alerte"); return false; }
    if (!b.techniques.some((t) => t.id === rel.cibleId)) { this.afficherToast("Technique cible introuvable", "alerte"); return false; }
    if (source.relations.some((r) => r.type === rel.type && r.cibleId === rel.cibleId)) {
      this.afficherToast("Ce lien existe déjà", "alerte"); return false;
    }
    source.relations.push({
      type: rel.type, cibleId: rel.cibleId,
      ...(rel.note !== undefined ? { note: rel.note } : {}),
      ...(rel.priorite !== undefined ? { priorite: rel.priorite } : {}),
    });
    await this.persister(b);
    this.afficherToast("Lien ajouté ✓");
    return true;
  }

  /** Modifie une arête existante (D-156) : raison, priorité, type. `null`
   *  efface le champ (la raison/priorité redeviennent absentes). */
  async modifierRelation(
    sourceId: string, cibleId: string, typeId: string,
    patch: { type?: string; note?: string | null; priorite?: number | null },
  ): Promise<boolean> {
    if (!this.garde("modification", "Saisis le PIN pour modifier ce lien.", () => void this.modifierRelation(sourceId, cibleId, typeId, patch))) return false;
    const b = this.bibliotheque;
    const source = b?.techniques.find((t) => t.id === sourceId);
    const r = source?.relations.find((x) => x.type === typeId && x.cibleId === cibleId);
    if (!b || !source || !r) return false;
    if (patch.type !== undefined && patch.type !== r.type) {
      if (source.relations.some((x) => x !== r && x.type === patch.type && x.cibleId === cibleId)) {
        this.afficherToast("Un lien de ce type vers cette technique existe déjà", "alerte"); return false;
      }
      r.type = patch.type;
    }
    if (patch.note !== undefined) { if (patch.note === null || patch.note.trim() === "") delete r.note; else r.note = patch.note.trim(); }
    if (patch.priorite !== undefined) { if (patch.priorite === null) delete r.priorite; else r.priorite = patch.priorite; }
    await this.persister(b);
    this.afficherToast("Lien modifié ✓");
    return true;
  }

  /** Supprime un type de lien — UNIQUEMENT s'il est inutilisé (lot 6 §10,
   *  remplace la rupture consentie : retirer d'abord les relations sur les
   *  fiches concernées, jamais de suppression en masse depuis l'Atelier). */
  async supprimerTypeRelation(id: string): Promise<void> {
    if (!this.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer ce type de lien.", () => void this.supprimerTypeRelation(id))) return;
    const b = this.bibliotheque;
    const type = b?.typesRelation.find((t) => t.id === id);
    if (!b || !type) return;
    const rompues = this.usagesTypeRelation(id);
    if (rompues) {
      this.afficherToast(`« ${type.libelle} » est utilisé par ${rompues} relation${rompues > 1 ? "s" : ""} — retire-les d'abord des fiches concernées`, "alerte");
      return;
    }
    b.typesRelation = b.typesRelation.filter((t) => t.id !== id);
    await this.persister(b);
    this.afficherToast(`Lien « ${type.libelle} » supprimé ✓`);
  }

  /** Retire une identité (analyse D-023 : aucune impasse — l'erreur se corrige).
   *  Les notes personnelles redeviennent « à rattacher » ; le savoir sourcé
   *  attaché part avec elle ; les références (relations, blocs) restent
   *  tolérées absentes et diagnostiquées à l'Atelier. */
  /** Retire une technique en la plaçant EN CORBEILLE (D-081) : geste réversible
   *  tant que la corbeille n'est pas vidée. La fiche et ses contributions quittent
   *  les listes vivantes (donc disparaissent partout : biblio, favoris, filtres,
   *  compteurs, relations dérivées) mais rien n'est détruit ni nettoyé — les liens
   *  ENTRANTS restent en place, simplement masqués (leur cible ne résout plus). */
  async supprimerTechnique(id: string): Promise<void> {
    if (!this.garde("destruction_ou_sensible", "Saisis le PIN pour retirer cette technique.", () => void this.supprimerTechnique(id))) return;
    const b = this.bibliotheque;
    const t = b?.techniques.find((x) => x.id === id);
    if (!b || !t) return;
    const contributions = b.contributions.filter((c) => c.techniqueId === id);
    const entree: EntreeCorbeille = {
      supprimeeLe: new Date().toISOString(),
      technique: t,
      contributions,
      etaitFavori: b.favoris.includes(id),
    };
    b.corbeille = [entree, ...(b.corbeille ?? [])];
    b.techniques = b.techniques.filter((x) => x.id !== id);
    b.contributions = b.contributions.filter((c) => c.techniqueId !== id);
    b.favoris = b.favoris.filter((x) => x !== id); // le marque-page suit l'identité (lot 5 §6)
    await this.persister(b);
    this.editionFiche = false;
    this.retour();
    this.afficherToast(`« ${t.nom} » mise en corbeille ✓ — restaurable depuis Plus › Corbeille`);
  }

  /** Restaure une fiche depuis la corbeille (D-081) : elle et ses contributions
   *  reviennent à l'identique, le favori est rétabli, ses liens entrants (jamais
   *  touchés) se rallument. */
  async restaurerTechnique(id: string): Promise<void> {
    if (!this.garde("modification", "Saisis le PIN pour restaurer cette fiche.", () => void this.restaurerTechnique(id))) return;
    const b = this.bibliotheque;
    const e = b?.corbeille?.find((x) => x.technique.id === id);
    if (!b || !e) return;
    b.corbeille = (b.corbeille ?? []).filter((x) => x.technique.id !== id);
    b.techniques = [...b.techniques, e.technique];
    b.contributions = [...b.contributions, ...e.contributions];
    if (e.etaitFavori && !b.favoris.includes(id)) b.favoris = [...b.favoris, id];
    await this.persister(b);
    this.afficherToast(`« ${e.technique.nom} » restaurée ✓`);
  }

  /** Purge DÉFINITIVEMENT une entrée de corbeille (D-081) — irréversible.
   *  C'est ICI que la cascade s'exécute enfin : les liens entrants qui pointaient
   *  vers la fiche sont nettoyés (les deux lectures d'un coup, l'inverse étant
   *  dérivé), les notes personnelles reviennent « à rattacher », le savoir sourcé
   *  disparaît. Les compositions utilisatrices ne gardent qu'un repère « absente ».
   *  Un snapshot est pris avant tout vidage (filet général). */
  async #purger(b: Bibliotheque, ids: string[]): Promise<void> {
    const cible = new Set(ids);
    const entrees = (b.corbeille ?? []).filter((e) => cible.has(e.technique.id));
    if (entrees.length === 0) return;
    for (const t of b.techniques) t.relations = t.relations.filter((r) => !cible.has(r.cibleId));
    for (const e of entrees) {
      const perso = e.contributions
        .filter((c) => c.provenance === "personnel")
        .map((c) => ({ ...c, techniqueId: null }));
      b.contributions = [...b.contributions, ...perso]; // le savoir sourcé n'existe pas sans son identité
    }
    b.corbeille = (b.corbeille ?? []).filter((e) => !cible.has(e.technique.id));
    await this.persister(b);
  }

  /** Supprime définitivement UNE fiche de la corbeille (avec confirmation en amont). */
  async supprimerDefinitivement(id: string): Promise<void> {
    if (!this.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer définitivement.", () => void this.supprimerDefinitivement(id))) return;
    const b = this.bibliotheque;
    const e = b?.corbeille?.find((x) => x.technique.id === id);
    if (!b || !e) return;
    await this.stockage.snapshot(`avant-purge-${e.technique.nom}`);
    await this.#purger(b, [id]);
    this.afficherToast(`« ${e.technique.nom} » supprimée définitivement ✓ — point de restauration conservé`);
  }

  /** Vide TOUTE la corbeille (D-081) — irréversible, snapshot pris avant. */
  async viderCorbeille(): Promise<void> {
    if (!this.garde("destruction_ou_sensible", "Saisis le PIN pour vider la corbeille.", () => void this.viderCorbeille())) return;
    const b = this.bibliotheque;
    if (!b || !(b.corbeille ?? []).length) return;
    const n = b.corbeille!.length;
    await this.stockage.snapshot("avant-vidage-corbeille");
    await this.#purger(b, b.corbeille!.map((e) => e.technique.id));
    this.afficherToast(`Corbeille vidée ✓ — ${n} fiche${n > 1 ? "s" : ""} supprimée${n > 1 ? "s" : ""}, point de restauration conservé`);
  }

  /** Retire une discipline VIDE (sinon message actionnable — jamais de perte en masse silencieuse). */
  async supprimerDiscipline(id: string): Promise<void> {
    if (!this.garde("destruction_ou_sensible", "Saisis le PIN pour retirer cette discipline.", () => void this.supprimerDiscipline(id))) return;
    const b = this.bibliotheque;
    const d = b?.disciplines.find((x) => x.id === id);
    if (!b || !d) return;
    const restantes = b.techniques.filter((t) => t.disciplineId === id).length;
    if (restantes) {
      this.afficherToast(`« ${d.nom} » contient encore ${restantes} technique${restantes > 1 ? "s" : ""} — retire-les d'abord (fiche → crayon → Retirer)`, "alerte");
      return;
    }
    await this.stockage.snapshot(`avant-retrait-${d.nom}`);
    b.disciplines = b.disciplines.filter((x) => x.id !== id);
    await this.persister(b);
    this.afficherToast(`Discipline « ${d.nom} » retirée ✓`);
  }

  /** Déplace une discipline d'un cran dans l'ordre de la racine (lot 6 §6). */
  reordonnerDiscipline(id: string, delta: -1 | 1): void {
    if (!this.garde("modification", "Saisis le PIN pour réordonner les disciplines.", () => void this.reordonnerDiscipline(id, delta))) return;
    const b = this.bibliotheque;
    if (!b) return;
    const i = b.disciplines.findIndex((d) => d.id === id);
    const j = i + delta;
    if (i < 0 || j < 0 || j >= b.disciplines.length) return;
    const [d] = b.disciplines.splice(i, 1);
    b.disciplines.splice(j, 0, d!);
    void this.persister(b);
  }

  /* ---------- réordonnancement par glisser-déposer (tuning post-V3) ---------- */

  /** Élément en cours de glisser (discipline/catégorie/niveau) — état de session. */

  /** Déplace une discipline à l'emplacement d'une autre — EN MÉMOIRE, sans
   *  persister (l'aperçu suit le doigt) ; `enregistrerReordre` persiste au
   *  relâcher. */
  deplacerDisciplineVers(id: string, cibleId: string): void {
    const b = this.bibliotheque;
    if (!b || id === cibleId) return;
    const i = b.disciplines.findIndex((d) => d.id === id);
    if (i < 0) return;
    const [d] = b.disciplines.splice(i, 1);
    const j = b.disciplines.findIndex((x) => x.id === cibleId);
    b.disciplines.splice(j < 0 ? i : j, 0, d!);
    this.requestUpdate();
  }

  /** Déplace une catégorie/un niveau à l'emplacement d'un(e) autre — EN MÉMOIRE
   *  (ordre recalculé) ; persisté au relâcher via `enregistrerReordre`. */
  deplacerTaxonomieVers(disciplineId: string, quoi: "familles" | "niveaux", id: string, cibleId: string): void {
    const b = this.bibliotheque;
    const d = b?.disciplines.find((x) => x.id === disciplineId);
    if (!b || !d || id === cibleId) return;
    const liste = d[quoi];
    const i = liste.findIndex((x) => x.id === id);
    if (i < 0) return;
    const [entree] = liste.splice(i, 1);
    const j = liste.findIndex((x) => x.id === cibleId);
    liste.splice(j < 0 ? i : j, 0, entree as never);
    liste.forEach((x, n) => (x.ordre = n + 1));
    this.requestUpdate();
  }

  /** Persiste l'ordre courant après un glisser — PIN d'abord ; l'ordre est déjà
   *  appliqué en mémoire, rien d'autre n'est muté. */
  async enregistrerReordre(): Promise<void> {
    if (!this.garde("modification", "Saisis le PIN pour enregistrer l'ordre.", () => void this.enregistrerReordre())) return;
    const b = this.bibliotheque;
    if (!b) return;
    await this.persister(b);
  }

  /** Suppression SÉCURISÉE d'une discipline non vide (lot 6 §7) : snapshot
   *  motivé d'abord, puis mêmes règles que le retrait d'une identité —
   *  les notes personnelles reviennent « à rattacher », le savoir sourcé
   *  part avec ses identités, les références restantes sont tolérées
   *  absentes (compositions : libellé de secours ; diagnostics). */
  async supprimerDisciplineEtContenu(id: string): Promise<void> {
    if (!this.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer cette discipline et son contenu.", () => void this.supprimerDisciplineEtContenu(id))) return;
    const b = this.bibliotheque;
    const d = b?.disciplines.find((x) => x.id === id);
    if (!b || !d) return;
    await this.stockage.snapshot(`avant-suppression-discipline-${d.nom}`);
    const ids = new Set(b.techniques.filter((t) => t.disciplineId === id).map((t) => t.id));
    b.techniques = b.techniques.filter((t) => t.disciplineId !== id);
    b.favoris = b.favoris.filter((x) => !ids.has(x));
    b.contributions = b.contributions.flatMap((c) => {
      if (!c.techniqueId || !ids.has(c.techniqueId)) return [c];
      if (c.provenance === "personnel") return [{ ...c, techniqueId: null }];
      return []; // le savoir sourcé n'existe pas sans son identité
    });
    b.disciplines = b.disciplines.filter((x) => x.id !== id);
    await this.persister(b);
    this.afficherToast(`Discipline « ${d.nom} » supprimée — tes notes sont revenues « à rattacher », point de restauration conservé`);
  }

  /* ---------- édition contextuelle (D-020 : jamais de formulaire administratif) ---------- */

  /** Mode édition de la fiche courante (léger, non persisté). */
  editionFiche = false;
  /** Instantané pré-édition (D-105) : capturé à l'entrée en édition d'une fiche
   *  EXISTANTE ; la croix ✕ le restaure (les auto-enregistrements sont défaits).
   *  Nul pour une fiche fraîchement créée (rien à quoi revenir). */
  #instantaneEdition: { techniqueId: string; technique: Technique; contributions: Contribution[]; favori: boolean } | null = null;

  /** Entre en édition d'une fiche existante en capturant un instantané
   *  restaurable (technique + ses contributions). */
  entrerEditionFiche(techniqueId: string): void {
    const b = this.bibliotheque;
    const t = b?.techniques.find((x) => x.id === techniqueId);
    if (!b || !t) return;
    this.#instantaneEdition = {
      techniqueId,
      technique: structuredClone(t),
      contributions: b.contributions.filter((c) => c.techniqueId === techniqueId).map((c) => structuredClone(c)),
      favori: b.favoris.includes(techniqueId),
    };
    this.editionFiche = true;
    this.requestUpdate();
  }

  /** Le ✓ : enregistre et ferme (les changements sont déjà persistés en auto). */
  validerEditionFiche(): void {
    this.#instantaneEdition = null;
    this.editionFiche = false;
    this.afficherToast("Modifications enregistrées ✓");
    this.requestUpdate();
  }

  /** La croix ✕ : restaure l'instantané pris à l'entrée → les modifications
   *  auto-enregistrées sont défaites. Sans instantané (fiche neuve), ferme
   *  simplement l'édition. */
  async annulerEditionFiche(): Promise<void> {
    const snap = this.#instantaneEdition;
    const b = this.bibliotheque;
    this.editionFiche = false;
    this.#instantaneEdition = null;
    if (!snap || !b) { this.requestUpdate(); return; }
    const i = b.techniques.findIndex((t) => t.id === snap.techniqueId);
    if (i >= 0) b.techniques[i] = structuredClone(snap.technique);
    b.contributions = b.contributions.filter((c) => c.techniqueId !== snap.techniqueId);
    b.contributions.push(...snap.contributions.map((c) => structuredClone(c)));
    // Le favori est aussi restauré (le cœur reste cliquable en édition, D-105).
    const estFavori = b.favoris.includes(snap.techniqueId);
    if (snap.favori && !estFavori) b.favoris.push(snap.techniqueId);
    else if (!snap.favori && estFavori) b.favoris = b.favoris.filter((id) => id !== snap.techniqueId);
    await this.persister(b);
    this.afficherToast("Modifications annulées");
    this.requestUpdate();
  }
  /** Menu secondaire ⋮ de la fiche (lot 3 §2) — léger, non persisté. */
  menuFiche = false;
  /** Média AFFICHÉ en tête de fiche (lot 3 §4) — un choix de session,
   *  jamais une modification du média principal global. */
  mediaAffiche: string | null = null;
  /** Voix ouverte sur la fiche (lot 3 §7 : une seule à la fois) — choix de
   *  session ; null = la première par défaut, "" = toutes repliées. */
  voixOuverte: string | null = null;
  /** Relations dépliées sur la fiche (lot 3 §11) — aperçu compact par défaut. */
  relationsDepliees = false;

  async majTechnique(
    id: string,
    patch: Partial<Pick<Technique, "nom" | "nomTraditionnel" | "disciplineId" | "familleId" | "niveauxIds" | "mediaPrincipalId">>,
  ): Promise<void> {
    if (!this.garde("modification", "Saisis le PIN pour enregistrer cette modification.", () => void this.majTechnique(id, patch))) return;
    const b = this.bibliotheque;
    const t = b?.techniques.find((x) => x.id === id);
    if (!b || !t) return;
    const avant = structuredClone(t);
    // Changer de discipline dénoue famille et niveaux (ils appartiennent à
    // l'ancienne discipline) — jamais de référence croisée invalide.
    if (patch.disciplineId && patch.disciplineId !== t.disciplineId) {
      delete t.familleId;
      t.niveauxIds = [];
    }
    Object.assign(t, patch);
    // exactOptionalPropertyTypes : un champ effacé se retire, ne devient pas undefined
    for (const cle of ["nomTraditionnel", "familleId", "mediaPrincipalId"] as const) {
      if (cle in patch && (patch[cle] === undefined || patch[cle] === "")) delete t[cle];
    }
    try {
      await this.persister(b);
    } catch (e) {
      Object.assign(t, avant); // jamais d'état invalide affiché
      this.afficherToast(e instanceof Error ? e.message : "Modification refusée");
    }
  }

  async majContribution(id: string, description: string): Promise<void> {
    if (!this.garde("modification", "Saisis le PIN pour modifier cette contribution.", () => void this.majContribution(id, description))) return;
    const b = this.bibliotheque;
    const c = b?.contributions.find((x) => x.id === id);
    if (!b || !c) return;
    if (description.trim()) c.description = description.trim();
    else delete c.description;
    await this.persister(b);
  }

  /** Suppression d'une contribution personnelle — snapshot d'abord (contrat §4).
   *  Le fichier physique n'est JAMAIS supprimé ici (lot 8A §4) : retirer une
   *  référence, c'est recalculer les usages — partagé (déduplication), le
   *  fichier reste utilisé ailleurs ; sans plus aucune référence, il devient
   *  orphelin, diagnostiqué dans l'Atelier et supprimable UNIQUEMENT après
   *  prévisualisation + confirmation. Le snapshot « avant-retrait » reste
   *  ainsi restaurable, vidéo comprise. */
  async supprimerContribution(id: string): Promise<void> {
    if (!this.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer cette contribution.", () => void this.supprimerContribution(id))) return;
    const b = this.bibliotheque;
    const c = b?.contributions.find((x) => x.id === id);
    if (!b || !c) return;
    await this.stockage.snapshot("avant-retrait-d-une-note");
    b.contributions = b.contributions.filter((x) => x.id !== id);
    await this.persister(b);
    this.afficherToast("Contribution retirée — point de restauration conservé dans les sauvegardes");
  }

  /* ---------- compositions (D-020.1 : le savoir se réutilise) ---------- */
  /* ---------- compositions — DÉLÉGUÉS (S3.A1 T3) ----------
     La logique vit dans services/compositions-actions.ts. */

  ouvrirCreationCompo(): void { return ouvrirCreationCompo(this); }
  async creerCompositionFunnel(): Promise<void> { return creerCompositionFunnel(this); }
  async poserRolesFunnel(noms: string[]): Promise<void> { return poserRolesFunnel(this, noms); }
  fermerCreationCompo(): void { return fermerCreationCompo(this); }
  async creerComposition(nom: string): Promise<void> { return creerComposition(this, nom); }
  async creerCompositionDepuisEtapes(...args: Parameters<typeof creerCompositionDepuisEtapes> extends [unknown, ...infer R] ? R : never): Promise<void> { return creerCompositionDepuisEtapes(this, ...args); }
  async modifierComposition(id: string, muter: (c: Composition) => void): Promise<boolean> { return modifierComposition(this, id, muter); }
  async dupliquerComposition(id: string): Promise<void> { return dupliquerComposition(this, id); }
  async exporterComposition(id: string): Promise<void> { return exporterComposition(this, id); }
  async partagerComposition(id: string, avecVideos = true): Promise<void> { return partagerComposition(this, id, avecVideos); }
  async retirerMediaPresentation(compoId: string, mediaId: string): Promise<void> { return retirerMediaPresentation(this, compoId, mediaId); }
  async supprimerComposition(id: string): Promise<void> { return supprimerComposition(this, id); }

  /** Mode entraînement (lot 5 §14) : pas-à-pas plein écran, empilé — le
   *  retour (Quitter, Android) revient à la composition. */
  demarrerEntrainement(compositionId: string): void {
    reinitialiserSeance(); // S2.2 : la durée réalisée repart de zéro à chaque revue
    this.menuComposition = null;
    this.#aller({ type: "entrainement", compositionId, index: 0 });
  }

  /* ---------- favoris (lot 5 §4-5) : de purs marque-pages, immédiats, réversibles ---------- */
  /* ---------- favoris + doublons — DÉLÉGUÉS (S3.A1 T5) ----------
     La logique vit dans services/favoris-doublons.ts ; le partage d'une
     technique a rejoint services/export-pack.ts (sa famille). */

  estFavori(techniqueId: string): boolean { return estFavori(this, techniqueId); }
  async basculerFavori(techniqueId: string): Promise<void> { return basculerFavori(this, techniqueId); }
  techniquesFavorites(): Technique[] { return techniquesFavorites(this); }
  async demanderPartageTechnique(techniqueId: string): Promise<void> { return demanderPartageTechnique(this, techniqueId); }
  async confirmerPartage(): Promise<void> { return confirmerPartage(this); }
  async partagerTechnique(techniqueId: string, avecVideos = true): Promise<void> { return partagerTechnique(this, techniqueId, avecVideos); }
  doublonsPotentiels(): PaireDoublon[] { return doublonsPotentiels(this); }
  async rescannerDoublons(): Promise<void> { return rescannerDoublons(this); }
  async classerDoublon(aId: string, bId: string, message: string): Promise<void> { return classerDoublon(this, aId, bId, message); }
  async resoudreDoublonGarder(gardeId: string, retireId: string): Promise<void> { return resoudreDoublonGarder(this, gardeId, retireId); }
  async fusionnerDoublonAvec(aId: string, bId: string, choix: ChoixFusion): Promise<void> { return fusionnerDoublonAvec(this, aId, bId, choix); }
  async defusionner(fusionneeId: string): Promise<void> { return defusionner(this, fusionneeId); }
  async creerAdaptationLocale(contributionId: string): Promise<void> { return creerAdaptationLocale(this, contributionId); }

  /** Lit un média local ENTIER en mémoire (par blocs) — réservé aux petits
   *  paquets (partage d'une fiche) ; l'export complet reste à mémoire bornée. */
  /** INTERNE aux services extraits (S3.A1) — pas une API produit. */
  async lireMediaComplet(id: string): Promise<Uint8Array> {
    const blocs: Uint8Array[] = [];
    for await (const bloc of this.stockage.lireMediaParBlocs(id, 1 << 20)) blocs.push(bloc);
    const total = blocs.reduce((n, x) => n + x.length, 0);
    const out = new Uint8Array(total);
    let pos = 0;
    for (const x of blocs) { out.set(x, pos); pos += x.length; }
    return out;
  }

  /* ---------- Doublons potentiels (D-068) : aide non bloquante ---------- */

  /* ---------- capture (situations « chaud » et rattachement différé) ---------- */
  /* ---------- capture + médias de fiche — DÉLÉGUÉS (S3.A1 T4) ----------
     La logique vit dans services/capture.ts et services/medias-fiche.ts. */

  ouvrirCapture(): void { return ouvrirCapture(this); }
  async terminerCaptureRepere(): Promise<void> { return terminerCaptureRepere(this); }
  ouvrirRattachement(contributionId: string): void { return ouvrirRattachement(this, contributionId); }
  fermerCapture(): void { return fermerCapture(this); }
  reculerCapture(): void { return reculerCapture(this); }
  async terminerCapture(...args: Parameters<typeof terminerCapture> extends [unknown, ...infer R] ? R : never): Promise<void> { return terminerCapture(this, ...args); }
  async ajouterNote(techniqueId: string, texte: string): Promise<void> { return ajouterNote(this, techniqueId, texte); }
  async ajouterMediaFiche(...args: Parameters<typeof ajouterMediaFiche> extends [unknown, ...infer R] ? R : never): Promise<void> { return ajouterMediaFiche(this, ...args); }
  async ajouterMediaPresentation(...args: Parameters<typeof ajouterMediaPresentation> extends [unknown, ...infer R] ? R : never): Promise<void> { return ajouterMediaPresentation(this, ...args); }
  async amenderContribution(...args: Parameters<typeof amenderContribution> extends [unknown, ...infer R] ? R : never): Promise<void> { return amenderContribution(this, ...args); }
  async majMediaLabel(mediaId: string, label: string): Promise<void> { return majMediaLabel(this, mediaId, label); }
  async majMediaLien(mediaId: string, url: string): Promise<void> { return majMediaLien(this, mediaId, url); }
  async definirCouvertureImage(techniqueId: string, fichier: File): Promise<void> { return definirCouvertureImage(this, techniqueId, fichier); }
  async definirCouvertureMedia(techniqueId: string, mediaId: string): Promise<void> { return definirCouvertureMedia(this, techniqueId, mediaId); }
  async retirerCouverture(techniqueId: string): Promise<void> { return retirerCouverture(this, techniqueId); }
  async retirerMedia(techniqueId: string, mediaId: string): Promise<void> { return retirerMedia(this, techniqueId, mediaId); }
  annulerIngestionVideo(): void { return annulerIngestionVideo(this); }

  /** INTERNE aux services extraits (S3.A1) — pas une API produit. */
  async persister(b: Bibliotheque): Promise<void> {
    await this.stockage.sauvegarder(b);
    this.bibliotheque = { ...b }; // nouvelle référence → rendu
  }

  /** Vrai pendant l'écriture d'une contribution/repère (§concurrence) — une
   *  garde unique pour TOUS les parcours d'écriture média+métier : un second
   *  geste (double appui) pendant l'écriture ne produit ni contribution ni
   *  fichier en double. Posée SYNCHRONEMENT à l'entrée, avant le premier await. */

  /* ---------- rendu ---------- */

  override render() {
    if (this.erreurDemarrage)
      // Écran d'environnement non supporté (S1.10/D-167) : jamais une
      // interface partiellement fonctionnelle — le message, les navigateurs
      // supportés et l'échappatoire (sauvegarde portable), rien d'autre.
      return html`<div class="ecran erreur-demarrage" style="padding:24px 18px"><div class="carte-atelier">
        <div class="encart-entete"><span class="titre-atelier">Movenso n'a pas pu démarrer</span></div>
        <p class="details" style="line-height:1.6">${this.erreurDemarrage}</p>
        <p class="details" style="line-height:1.6; opacity:.75; font-size:12.5px">
          Navigateurs supportés : Chrome, Edge et Firefox récents — sur téléphone,
          tablette et ordinateur. Rien n'a été modifié sur cet appareil.
        </p>
      </div></div>`;
    if (!this.bibliotheque) return nothing; // démarrage (< 150 ms : pas d'écran d'attente)
    const ecranCourant =
      this.ecran.type === "fiche"
        ? gabaritFiche(this, this.ecran.techniqueId)
        : this.ecran.type === "discipline"
          ? gabaritDiscipline(this, this.ecran.disciplineId)
          : this.ecran.type === "bibliotheques"
            ? gabaritBibliotheques(this)
          : this.ecran.type === "plus"
            ? (this.ecran.section ? gabaritPlusSection(this, this.ecran.section) : gabaritPlus(this))
            : this.ecran.type === "relations"
              ? gabaritRelationsVisuelle(this)
            : this.ecran.type === "favoris"
              ? gabaritFavoris(this)
            : this.ecran.type === "compositions"
              ? gabaritCompositions(this)
              : this.ecran.type === "composition"
                ? gabaritComposition(this, this.ecran.compositionId)
                : this.ecran.type === "entrainement"
                  ? gabaritEntrainement(this, this.ecran.compositionId, this.ecran.index)
                  : gabaritBibliotheques(this);
    // Une feuille (capture, import) recouvre tout : ni action contextuelle ni
    // barre basse en dessous (lot 1 §10) ; le mode entraînement non plus (§14).
    const feuilleOuverte =
      this.capture !== null ||
      this.importEnAttente !== null ||
      this.rapportApresImport !== null ||
      this.restaurationEnAttente !== null ||
      this.demandePin !== null ||
      this.ajoutMedia !== null ||
      this.ajouter !== null ||
      this.partagePreparation !== null ||
      this.enregistrementMedia !== null ||
      this.ecran.type === "entrainement";
    return html`
      ${ecranCourant}
      ${feuilleOuverte ? nothing : this.#actionContextuelle()}
      ${feuilleOuverte ? nothing : this.#barreNavigation()}
      ${feuilleOuverte || this.ecran.type === "entrainement" ? nothing : this.#indicateurSession()}
      ${this.importEnAttente ? feuilleImport(this) : nothing}
      ${this.rapportApresImport ? feuilleRapportImport(this) : nothing}
      ${this.restaurationEnAttente ? feuilleRestauration(this) : nothing}
      ${this.demandePin ? this.#feuillePin() : nothing}
      ${this.capture ? gabaritCapture(this) : nothing}
      ${this.ajoutMedia ? gabaritAjoutMedia(this) : nothing}
      ${this.partagePreparation ? feuillePartage(this) : nothing}
      ${this.enregistrementMedia ? feuilleEnregistrement(this) : nothing}
      ${this.ajouter ? gabaritAjouter(this) : nothing}
      ${this.creationCompo ? gabaritCreationCompo(this) : nothing}
      ${this.ajoutPas ? gabaritAjoutPas(this) : nothing}
      ${this.editionPas ? gabaritEditionPas(this) : nothing}
      ${this.editionLien ? gabaritEditionLien(this) : nothing}
      ${this.menuComposition ? gabaritMenuComposition(this) : nothing}
      ${this.confirmation ? feuilleConfirmation(this) : nothing}
      ${this.toast && this.ecran.type !== "entrainement"
        ? html`<div class="toast ${this.toastAlerte ? "alerte" : ""}" role=${this.toastAlerte ? "alert" : "status"}>${this.toast}</div>`
        : nothing}
      ${voileOccupe(this)}
    `;
  }

  /** Action contextuelle du shell (lot 1 §7, lot 4 §2) : définie par l'écran
   *  courant — plus jamais de bouton global « Capturer ». Racine Bibliothèque
   *  et discipline ouverte : « Ajouter » ouvre le panneau court par gestes
   *  (discipline présélectionnée quand elle est connue). */
  #actionContextuelle() {
    // Lot 7 §16 : l'action reste VISIBLE — le PIN arrive à l'usage.
    const ouvrir = (ajouter: NonNullable<MovensoApp["ajouter"]>) =>
      // le point d'entrée EXÉCUTEUR (`autoriser`), pas la garde booléenne :
      // si l'action est libre elle part tout de suite, sinon le PIN la reprend.
      this.autoriser("modification", "Saisis le PIN pour ajouter ou capturer.", () => {
        this.ajouter = ajouter;
        this.requestUpdate();
      });
    if (this.ecran.type === "discipline") {
      const disciplineId = this.ecran.disciplineId;
      return html`<button class="fab" @click=${() => ouvrir({ disciplineId })}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M12 5v14M5 12h14"/></svg>
        Ajouter
      </button>`;
    }
    if (this.ecran.type === "bibliotheques" && this.bibliotheque)
      return html`<button class="fab" @click=${() => ouvrir({})}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M12 5v14M5 12h14"/></svg>
        Ajouter
      </button>`;
    // Compositions : le « Créer » descend en bouton flottant, comme la
    // Bibliothèque ; un clic lance directement l'atelier de composition
    // (nom modifiable dans l'éditeur). Le champ en haut de l'écran est retiré.
    if (this.ecran.type === "compositions" && this.bibliotheque)
      return html`<button class="fab" @click=${() => this.ouvrirCreationCompo()}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M12 5v14M5 12h14"/></svg>
        Créer
      </button>`;
    return nothing;
  }

  /** Zone de la barre basse à laquelle appartient l'écran courant (D-071). */
  zoneCourante(): Zone {
    switch (this.ecran.type) {
      case "plus":
        return "plus";
      case "relations":
        return "relations";
      case "favoris":
        return "favoris";
      case "compositions":
      case "composition":
      case "entrainement":
        return "compositions";
      default:
        return "bibliotheque";
    }
  }

  /** Barre de navigation basse (lot 1 §1) — pile remise à zéro par destination. */
  #barreNavigation() {
    const zone = this.zoneCourante();
    const onglet = (id: string, libelle: string, icone: unknown, action: () => void) => html`
      <button class="nav-onglet ${zone === id ? "actif" : ""}" @click=${action}
              aria-label=${libelle} aria-current=${zone === id ? "page" : nothing}>
        ${icone}<span>${libelle}</span>
      </button>`;
    return html`<nav class="barre-nav">
      ${onglet("bibliotheque", "Bibliothèque",
        html`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2Z"/><path d="M4 17.5A2.5 2.5 0 0 1 6.5 15H19"/></svg>`,
        () => this.ouvrirBibliotheque())}
      ${onglet("favoris", "Favoris",
        html`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20s-7-4.35-9.3-8.5C1.2 8.7 2.6 5.5 5.7 5.5c1.9 0 3.1 1 4.3 2.5 1.2-1.5 2.4-2.5 4.3-2.5 3.1 0 4.5 3.2 3 6-2.3 4.15-9.3 8.5-9.3 8.5Z"/></svg>`,
        () => this.ouvrirFavoris())}
      ${RELATIONS_VISUELLES && this.preferences.vueRelationBeta
        ? onglet("relations", "Relations",
            html`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="6" r="2.4"/><circle cx="5" cy="18" r="2.4"/><circle cx="19" cy="18" r="2.4"/><path d="M12 8.4 6.6 15.8M12 8.4l5.4 7.4M7.4 18h9.2"/></svg>`,
            () => this.ouvrirRelationsVisuelle())
        : nothing}
      ${this.preferences.compositionsBeta
        ? onglet("compositions", "Compositions",
            html`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="5" rx="1.5"/><rect x="4" y="12" width="16" height="5" rx="1.5"/></svg>`,
            () => this.ouvrirCompositions())
        : nothing}
      ${onglet("plus", "Plus",
        html`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>`,
        () => this.ouvrirPlus())}
    </nav>`;
  }
}


customElements.define("movenso-app", MovensoApp);
