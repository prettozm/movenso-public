/** Version de l'application, injectée au build par Vite (`define`
 *  `__APP_VERSION__`, dérivée de package.json). Hors build (tests unitaires,
 *  exécution directe), la constante n'est pas définie → repli sur "dev". */
declare const __APP_VERSION__: string;

export const VERSION: string =
  typeof __APP_VERSION__ !== "undefined" ? __APP_VERSION__ : "dev";

/** Commit court du build (D-212) — le « où » exact dans GitHub. Le dépôt sera
 *  renommé `movenso` à terme : on affiche le SHA (stable au renommage), pas
 *  une URL. Hors build : "local". */
declare const __APP_COMMIT__: string;

export const COMMIT: string =
  typeof __APP_COMMIT__ !== "undefined" ? __APP_COMMIT__ : "local";
