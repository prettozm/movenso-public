# Movenso V3 — Instructions permanentes

## Au début de chaque session

1. Vérifier la branche, le commit et l’état Git.
2. Lire `docs/execution/MASTER.md`.
3. Lire `docs/execution/STATE.md`.
4. Lire `docs/execution/DECISIONS.md`.
5. Lire uniquement le lot courant indiqué dans `STATE.md`.
6. Lire les sections concernées de `docs/execution/QUALITY.md`.
7. Exécuter la vérification rapide disponible.

La mémoire opérationnelle est dans le dépôt. Ne pas se fier à une mémoire conversationnelle qui contredit ces fichiers.

## Mode de travail

Travailler en autonomie par boucles verticales courtes. Une boucle traite un seul comportement utilisateur, le vérifie, le documente, puis se termine par un commit vert et une mise à jour de `STATE.md`.

Enchaîner les boucles et les lots tant qu’aucune condition d’arrêt de `MASTER.md` n’est rencontrée.

## Interdictions

- Ne jamais travailler sur `main`.
- Ne jamais fusionner, force-push ou réécrire l’historique.
- Ne jamais modifier Movenso V2.
- Ne jamais commencer deux lots en parallèle.
- Ne jamais ajouter une fonction hors du lot courant.
- Ne jamais supprimer une capacité sans décision explicite.
- Ne jamais committer un secret, un PIN ou un keystore.
- Ne jamais déclarer démontré ce qui ne l’est que partiellement.

## Fin d’une boucle

Une boucle est terminée seulement si :

- le comportement fonctionne de bout en bout ;
- le test ciblé est vert ;
- les non-régressions voisines sont vérifiées ;
- la **doc est amendée au fil de l’eau, dans le même commit** (règle
  `docs/conventions.md` §12) : `docs/systeme.md` si l’architecture ou un
  comportement change, `docs/workflows.md` si un parcours change,
  `docs/execution/QUALITY.md` pour la recette et les capacités ;
- `docs/execution/STATE.md` est à jour (le **présent** ne vit que là) ;
- la décision éventuelle est inscrite au journal (`docs/execution/DECISIONS.md`) ;
- un commit local vert existe.

Ne jamais laisser la doc « propre » (architecture, parcours) prendre du retard
sur le code : une boucle qui change le produit sans mettre à jour la doc qui
fait autorité sur ce sujet n’est pas verte.

## Fin d’un lot

Un lot est terminé seulement si ses critères obligatoires sont couverts, `npm run verifier` est vert, **les documents décrivent le réel** (aucun écart connu entre `docs/systeme.md`/`docs/workflows.md` et le code) et un checkpoint de lot est inscrit dans `STATE.md`.
