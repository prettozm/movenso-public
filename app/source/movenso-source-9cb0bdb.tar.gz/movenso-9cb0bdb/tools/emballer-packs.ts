/**
 * Emballe les packs de démonstration en VRAIS conteneurs .movpack (D-023 :
 * « le movpack est un JSON actuellement ») — manifeste, intégrité, portée.
 * Usage : node --experimental-strip-types tools/emballer-packs.ts
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import type { Bibliotheque } from "../src/domaine/modele.ts";
import { migrerBibliotheque } from "../src/domaine/migrations.ts";
import { exporterMovpack, idPackStable } from "../src/echange/movpack.ts";

// GARDE (D-212) : seul le PUBLIABLE s'emballe. `club-judo.json` est une
// FIXTURE E2E INTERNE (niveaux, homonymes pour la défusion D-067) — jamais
// emballée, jamais publiée. L'ajouter ici serait une décision, pas un réflexe.
/**
 * IDENTITÉ DU CONTENEUR (D-247) — dérivée de la DISCIPLINE, JAMAIS du nom de
 * fichier. L'app reconnaît un pack par l'id de son manifeste : en changer fait
 * voir une mise à jour comme un pack NEUF et duplique tout le contenu chez qui
 * l'a déjà installé. `idPackStable` est la règle du produit (invariante au
 * renommage) et c'est elle qui a produit les six identités d'ORIGINE ; cet
 * outil s'en écartait avec `idDePack(fichier)`, ce qui a cassé le judo puis le
 * jujitsu. Une seule règle désormais, sans exception ni drapeau — et un test
 * épingle chaque identité produite (`tests/packs-identite.test.ts`).
 */
const PACKS: { fichier: string; nom: string; auteur: string; versionEditoriale?: number }[] = [
  // ⚠️ « Kodokan » ne doit JAMAIS entrer dans l'identité publique d'un pack
  // (nom, auteur, titre) — usage descriptif d'attribution des vidéos seulement
  // (D-213). versionEditoriale : +1 à chaque republication de contenu.
  { fichier: "kodokan", nom: "Judo", auteur: "Movenso", versionEditoriale: 9 },
  // D-238 : le pack Jujitsu n'avait AUCUNE source versionnée — il n'existait
  // que comme conteneur publié, donc non reproductible et non relisible. Sa
  // bibliothèque est désormais dans donnees/, comme le judo.
  { fichier: "jujitsu", nom: "Jujitsu", auteur: "Movenso", versionEditoriale: 6 },
  // D-245 : le karaté n'avait pas non plus de source versionnée. Son identité
  // publiée vient de sa discipline, pas de son nom de fichier — d'où le drapeau.
  { fichier: "karate-shotokan", nom: "Karaté Shotokan", auteur: "Movenso", versionEditoriale: 4 },
  { fichier: "jjb", nom: "Jiu-jitsu brésilien", auteur: "Movenso", versionEditoriale: 3 },
  { fichier: "taiso", nom: "Taïso", auteur: "Movenso", versionEditoriale: 3 },
];

/**
 * Illustrations de FAMILLE (D-244) : `donnees/images/<pack>/<familleId>.jpg`
 * est posé en couverture sur CHAQUE technique de cette famille.
 *
 * Pourquoi à l'emballage et pas dans la source : le modèle ne connaît
 * d'illustration que par technique (`Technique.couverture`, une data-URL), donc
 * une image de famille s'y recopie autant de fois qu'elle a de techniques —
 * 162 fois pour le jujitsu. Garder les vignettes en FICHIERS dans `donnees/`
 * laisse le dépôt lisible et la source légère ; la duplication n'existe que
 * dans le conteneur produit, là où elle est inévitable.
 *
 * L'image porte son TITRE générique en clair (« Clés de contrôle ») : la fiche
 * d'une technique montre donc une carte de famille assumée, et non une photo
 * qui prétendrait être cette technique-là (arbitrage porteur, D-244).
 */
function poserIllustrations(b: Bibliotheque, pack: string): { propres: number; familles: number } {
  let propres = 0, familles = 0;
  const cache = new Map<string, string>();
  const lire = (chemin: string) => {
    if (!cache.has(chemin)) {
      if (!existsSync(chemin)) return undefined;
      cache.set(chemin, `data:image/jpeg;base64,${readFileSync(chemin).toString("base64")}`);
    }
    return cache.get(chemin);
  };
  for (const t of b.techniques) {
    if (t.couverture) continue;
    // 1. L'image PROPRE de la technique prime toujours (D-245) : une carte de
    //    famille ne remplace jamais une illustration spécifique — Heisoku-dachi
    //    montre les pieds joints, la carte « Dachi » ne montrerait qu'une posture.
    const propre = t.origine?.element ? lire(`donnees/images/${pack}/techniques/${t.origine.element}.jpg`) : undefined;
    if (propre) { t.couverture = { type: "image", dataUrl: propre }; propres++; continue; }
    // 2. À défaut, la carte de sa FAMILLE (D-244) — le filet qui évite une fiche nue.
    const famille = t.familleId ? lire(`donnees/images/${pack}/${t.familleId}.jpg`) : undefined;
    if (famille) { t.couverture = { type: "image", dataUrl: famille }; familles++; }
  }
  return { propres, familles };
}

mkdirSync("dist-packs", { recursive: true });
for (const p of PACKS) {
  const b = migrerBibliotheque(JSON.parse(readFileSync(`donnees/${p.fichier}.json`, "utf8")));
  const ill = poserIllustrations(b, p.fichier);
  const octets = await exporterMovpack(b, { id: idPackStable(b.disciplines[0]!.id), nom: p.nom, portee: "discipline", auteur: p.auteur, ...(p.versionEditoriale ? { versionEditoriale: p.versionEditoriale } : {}) }, new Map());
  writeFileSync(`dist-packs/${p.fichier}.movpack`, octets);
  console.log(`dist-packs/${p.fichier}.movpack (${(octets.length / 1024).toFixed(0)} Ko)` + (ill.propres || ill.familles ? ` — ${ill.propres} illustrations propres, ${ill.familles} par la famille` : ""));
}
