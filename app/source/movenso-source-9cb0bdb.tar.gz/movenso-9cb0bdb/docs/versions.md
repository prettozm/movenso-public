# Versions — registre central (Movenso)

> **Type : vivant** · **Statut : source de vérité des versions (D-132, 2026-07-25).**
> Toute évolution de version se déclare **ici d'abord**, puis se propage aux
> emplacements listés (§4). On ne fait pas vivre un numéro de version à un seul
> endroit sans le refléter dans ce registre.

## 1. Version du produit (application)

| Quoi | Version | Où elle vit |
|---|---|---|
| **Movenso (app)** | **`0.9.0-rc.1`** | `package.json` → injectée au build (`__APP_VERSION__`, `src/app/version.ts`) → affichée dans **Plus › À propos**. |

Convention : versionnage **sémantique 0.x** pour la phase pré-1.0. `-rc.N`
pour une release candidate. Le tag « bêta » (canal, pas version) reste un
propos éditorial du site public.

## 2. Versions des packs de contenu

Chaque pack porte sa **propre** version, indépendante de l'app. Registre :

| Pack (discipline) | Statut | Version | Fichier publié |
|---|---|---|---|
| Judo (Kodokan) | Bêta | `0.4.0` | `movenso-public/packs/judo.movpack` (0.3.0 : raison+priorité, D-134 ; 0.4.0 : graphe nettoyé 275 liens + rôles sémantiques + « à ne pas confondre » + alertes IJF, D-136) |
| Karaté Shotokan | Alpha | `0.1.0` | `packs/karate-shotokan.movpack` |
| Jujitsu (France Judo) | Alpha | `0.1.0` | `packs/jujitsu.movpack` |
| Jiu-jitsu brésilien (Gi & No-Gi) | Alpha | `0.1.0` | `packs/jjb.movpack` |
| Taïso (+ 12 séances) | Alpha | `0.1.0` | `packs/taiso.movpack` |
| Yoga Hatha (+ 12 séances) | Alpha | `0.1.0` | `packs/yoga.movpack` |

Convention pack : démarrage à **`0.1.0`**. On incrémente à chaque évolution du
contenu (patch = corrections, mineur = ajouts notables). La version est
déclarée dans **`movenso-public/packs.js`** (champ `version`) et sert
l'affichage du catalogue.

## 3. Versions de FORMAT interne (⚠ ne sont PAS des versions produit)

Ces entiers pilotent la **compatibilité et les migrations** ; ils ne suivent
pas le versionnage 0.x et **ne doivent pas être renumérotés** à la légère
(les renuméroter casserait la chaîne de migrations et ferait rejeter les packs
existants).

| Format | Valeur | Défini dans |
|---|---|---|
| Schéma de données | `4` (entier ; 3→4 = rôles rétro-appliqués, D-140) | `src/domaine/modele.ts` (`VERSION_SCHEMA`) |
| Conteneur `.movpack` | `4` (entier) | `src/echange/movpack.ts` (`VERSION_MOVPACK`) |

Ils ne sont plus affichés dans l'écran « À propos » (bruit pour l'utilisateur) ;
ils restent visibles dans **Plus › Diagnostic** pour le débogage.

## 4. Process d'évolution (propager PARTOUT, publication comprise)

Quand une version change, mettre à jour **dans le même lot** :

**App (`0.x`)** :
1. `package.json` (`version`) — l'À propos suit automatiquement.
2. Ce registre (§1).
3. Rebâtir la **version web** (`npm run build`) et redéployer `movenso-public/app/`
   (sinon l'app en ligne affiche l'ancienne version).
4. `docs/execution/STATE.md` (présent) + journal des décisions si arbitrage.

**Pack (`0.x`)** :
1. Régénérer le `.movpack` (contenu à jour) et le déposer dans
   `movenso-public/packs/`.
2. Incrémenter `version` (et `updatedAt`) dans `movenso-public/packs.js`.
3. Ce registre (§2).
4. (Optionnel) noter le changement dans les notes de version du pack.

**Format interne (rare, structurant)** : uniquement via une **migration**
(`migrations.ts`) + entrée au journal des décisions ; jamais un simple
changement de numéro.

Règle : aucune version ne bouge « à un seul endroit ». Ce fichier est le
point de contrôle ; la publication (`movenso-public`) fait partie de la
propagation, pas d'une étape séparée oubliable.

**Publication officielle (RC et releases — S1.1, D-162)** : seul un
**artefact CI** est publiable — le workflow `ci` publie `movenso-web-<sha>`
(le `dist/` contrôlé par `verifier:dist` + ses empreintes `SHA256SUMS`) ;
jamais un build local. En phase bêta, le redéploiement de
`movenso-public/app/` depuis un build local reste toléré **à condition**
que le commit soit poussé et que la CI soit verte sur ce commit — à la
première RC, cette tolérance disparaît.
