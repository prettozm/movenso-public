# donnees/ — rôle de chaque fichier (D-212)

| Fichier | Rôle | Publiable ? |
|---|---|---|
| `kodokan.json` | **Source du pack public « Judo »** (⚠️ le nom de fichier est interne — le mot « Kodokan » ne doit JAMAIS entrer dans l'identité publique du pack : nom, titre, auteur. Attribution descriptive des vidéos uniquement, D-213) (movenso-public/packs/judo.movpack). Toute évolution ici appelle une republication (version éditoriale +1). | ✅ oui — via `tools/emballer-packs.ts` |
| `club-judo.json` | **FIXTURE E2E INTERNE** — le pack « exigeant » des tests : niveaux de ceinture (O5), homonymes qui prouvent la dé-fusion (D-067), types réduits. | ❌ **jamais** — retiré du circuit public ; absent d'`emballer-packs.ts` à dessein |
| `rapprochements-judo.json` | Fixture des tests de rapprochement (D-015). | ❌ jamais |

Règle : le circuit de publication (`emballer-packs.ts` → site public) ne
contient QUE du publiable. Ajouter un fichier à ce circuit est une **décision**
(journal), pas un réflexe.
