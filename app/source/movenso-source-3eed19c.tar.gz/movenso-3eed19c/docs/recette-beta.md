# Movenso — Check-list de recette bêta

Merci de tester Movenso 🙏 Cette liste te guide pas à pas. Pour chaque étape :
coche si **le résultat attendu** se produit, sinon note ce qui s'est passé
(voir « Remonter un souci » en bas).

> **Appareil :** Android · **Version APK :** ……… · **Testeur :** ………

---

## 0. ⚠️ À lire avant toute mise à jour

Pendant la bêta, **une nouvelle version ne s'installe pas par-dessus l'ancienne** :
il faut désinstaller puis réinstaller, ce qui **efface les données de l'app**.

➡️ **Avant CHAQUE mise à jour : fais une sauvegarde** (étape 5) et garde le fichier
au chaud. Tu la restaureras après (étape 6). C'est le geste le plus important de
la bêta.

---

## 1. Installation & démarrage

- [ ] L'app s'installe et s'ouvre sans écran blanc ni plantage.
- [ ] Au **premier lancement**, l'écran est vide et propose **« Créer ta première
      technique »** et **« Importer un pack »**.
- [ ] Fermer puis rouvrir l'app : on **retrouve son contenu** (rien n'a disparu).

## 2. Prise en main (consultation)

- [ ] Créer une technique (ou en ouvrir une) : la fiche s'affiche.
- [ ] Naviguer entre les onglets du bas et revenir en arrière : **pas de blocage,
      pas d'empilement d'écrans**, le bouton retour se comporte normalement.
- [ ] Rechercher une technique : les résultats correspondent.

## 3. Importer un pack

- [ ] Depuis l'écran vide (**« Importer »**) ou **Plus › Importer un pack**,
      choisir un fichier `.movpack`.
- [ ] Un **aperçu s'affiche AVANT toute écriture** (ce qui va être ajouté).
- [ ] **Annuler** : rien n'est ajouté, la bibliothèque est inchangée.
- [ ] Recommencer et **Installer** : un **rapport** dit ce qui a été ajouté ;
      les techniques et leurs vidéos sont bien là.
- [ ] Réimporter **le même pack** une 2ᵉ fois : **pas de doublons** en cascade
      (le contenu déjà présent est reconnu).

## 4. Vidéo locale ⭐ (le point clé de cette bêta)

- [ ] **Filmer / ajouter une vidéo** sur une fiche (Ajouter un média › filmer ou
      choisir un fichier). La vidéo apparaît et **se lit** sur la fiche.
- [ ] **Ajouter une GROSSE vidéo** (par ex. **200 Mo à 1 Go**) : l'ajout va au bout
      **sans que l'app plante ni « rame » jusqu'au crash**. Une progression
      s'affiche pendant l'écriture.
- [ ] Fermer/rouvrir l'app : la grosse vidéo est **toujours là et lisible**.

## 5. Sauvegarde & où la retrouver ⭐

- [ ] **Plus › Sauvegardes › fichier avec les vidéos** : un message confirme la
      sauvegarde **et indique où le fichier est enregistré**.
- [ ] Ouvrir l'appli **Fichiers** du téléphone : le fichier `.movpack` est bien
      **présent à l'emplacement annoncé** (dossier *Documents/Movenso*, ou l'endroit
      indiqué / la feuille de partage proposée).
- [ ] Le message annonce une **taille cohérente** (≈ la taille des vidéos incluses).

## 6. Restauration d'une sauvegarde ⭐ (le second point clé)

> Idéalement sur une **installation vierge** (après une désinstallation/réinstallation),
> pour reproduire le vrai geste « je change de version / de téléphone ».

- [ ] Importer le fichier de sauvegarde (étape 5). Un écran **« Restaurer cette
      sauvegarde complète ? »** décrit le contenu (techniques, vidéos…).
- [ ] **Confirmer** : même avec une **grosse sauvegarde (plusieurs centaines de
      Mo / plusieurs vidéos)**, la restauration va au bout **sans plantage**.
- [ ] Après restauration : **le savoir est revenu intégralement** (réglages d'appareil et PIN à reconfigurer, c'est normal) — techniques,
      classements, favoris, **et les vidéos se lisent**.
- [ ] (Un fichier de sauvegarde **abîmé/corrompu** est **refusé** proprement avec
      un message, sans rien écrire — si tu as de quoi tester.)

## 7. Sécurité (PIN) & commentaire

- [ ] **Plus › Sécurité** : activer la **protection des modifications** avec un PIN.
- [ ] La **consultation reste libre** (on peut toujours regarder les fiches).
- [ ] Tenter une **modification** : le **PIN est demandé** ; bon PIN → l'action se
      fait ; mauvais PIN → rien ne se passe.
- [ ] Sur une fiche, la zone **Commentaire** est en **lecture seule** avec la
      mention « 🔒 Lecture seule — un PIN protège cet appareil » (elle reste visible).
- [ ] **Désactiver** toutes les protections : la zone **Commentaire redevient
      éditable** directement sur la fiche.

## 8. Édition d'une fiche

- [ ] Ouvrir **Modifier**, changer un titre / mettre en favori, puis **valider (✓)** :
      les changements sont enregistrés.
- [ ] Rouvrir **Modifier**, changer des choses, puis **annuler (✕)** : **rien n'est
      enregistré** — le texte **et** l'état favori reviennent comme avant.

## 9. Partage

- [ ] Partager une technique ou un pack : la **feuille de partage** du téléphone
      s'ouvre ; le fichier envoyé est correct.
- [ ] Un pack partagé **n'emporte pas** ton **commentaire personnel** ni tes
      **favoris** (contenu perso privé).

---

## Points connus (pas la peine de les remonter)

- **Mise à jour = désinstaller/réinstaller** (signature de bêta) → d'où la
  sauvegarde avant chaque MAJ. Voir étape 0.
- Certains **boutons/puces peuvent sembler un peu petits** au doigt : ajustement
  visuel prévu — signale-le seulement s'il t'empêche vraiment d'appuyer.

## Remonter un souci

Pour chaque anomalie, note si possible :

1. **L'étape** de cette liste (ex. « 6 — Restauration »).
2. **Ce que tu as fait**, **ce qui s'est passé**, **ce que tu attendais**.
3. **Modèle de téléphone + version d'Android**, et **taille** approximative des
   vidéos/sauvegardes en jeu (surtout pour les étapes ⭐).
4. Une **capture d'écran** si l'écran affiche un message.

Merci ! Chaque retour rend la version finale plus solide. 🥋
