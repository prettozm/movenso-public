# Journal des décisions — Movenso V3 (segment CONCEPTION : D-001 → D-027)

> **Type : append-only (segment clos)** · **Statut : les entrées portent leur statut individuel**
> Ce fichier est le **premier segment** du journal : la phase **conception**
> (`D-001 → D-027`). La suite (`D-028 → D-127+`, finition) vit dans
> **[execution/DECISIONS.md](execution/DECISIONS.md)** — un seul journal, deux
> fichiers, jamais renuméroté (règles : [conventions.md](conventions.md) §5 ;
> on ajoute, on ne réécrit pas ; annuler = nouvelle entrée référençant
> l'ancienne). Pour la **vérité courante** du produit, lire
> [systeme.md](systeme.md) et [execution/STATE.md](execution/STATE.md).

---

## D-001 — Architecture documentaire initiale du dépôt V3

- **Date** : 2026-07-10 · **Statut : Autonome** (réversible, cadre de la première mission)
- **Contexte** : la mission demande de concevoir le système documentaire sans structure imposée, optimisé pour la reprise à faible coût en tokens et la séparation présent / historique / hypothèses / décisions.
- **Décision** : structure minimale à 8 documents (cf. [conventions.md](conventions.md) §2) organisée autour de trois pivots : `docs/etat.md` (le présent, seul document toujours relu), `docs/decisions.md` (les choix, append-only), `docs/conventions.md` (les règles stables). Les analyses V2 sont isolées dans `docs/v2/` (destinées à être figées). Aucun document créé vide « pour plus tard ».
- **Justification** : la reprise de session ne doit exiger que la lecture d'`etat.md` (~1 page) ; tout le reste est adressé par référence. Créer plus de documents maintenant serait de la structure spéculative — la mission privilégie la justification de chaque document par un besoin réel.
- **Portée** : réversible (la structure peut évoluer ; toute évolution sera tracée ici).

## D-002 — Statuts documentaires et marqueurs épistémiques

- **Date** : 2026-07-10 · **Statut : Autonome** (réversible)
- **Contexte** : la mission exige qu'un contenu non validé ne puisse jamais être lu comme une décision, et que fait / décision historique / déduction / hypothèse / recommandation soient distingués.
- **Décision** : en-tête de statut obligatoire sur chaque document (`VALIDÉ` / `NON VALIDÉ` + `vivant` / `figé` / `append-only`) et vocabulaire épistémique fermé `[FAIT] [DÉCISION V2] [DÉCISION] [DÉDUCTION] [HYPOTHÈSE] [RECO]` (cf. [conventions.md](conventions.md) §3-4). Seul l'humain fait passer un statut à VALIDÉ.
- **Justification** : mécanisme déterministe plutôt que discipline implicite ; un futur agent n'a aucun jugement à exercer pour savoir ce qui est engagé.
- **Portée** : réversible.

## D-003 — La V2 est une source d'enseignement, pas un socle de code

- **Date** : 2026-07-10 · **Statut : Autonome** (découle directement de la mission, qui l'impose)
- **Contexte** : la mission interdit la copie mécanique de code ou d'architecture V2 et impose de repartir du besoin.
- **Décision** : aucun code V2 n'est copié dans V3. La V2 est analysée une fois pour toutes dans `docs/v2/` (compréhension produit + analyse technique) ; la V3 se construit à partir de ces enseignements et des décisions validées. Tout emprunt conceptuel à la V2 devra être justifié par sa valeur dans le document où il est repris.
- **Portée** : structurante (mais imposée par la mission — enregistrée ici pour être retrouvable).

## D-004 — Validation 1 acquise ; faits terrain fournis par l'humain

- **Date** : 2026-07-10 · **Statut : Validée humain** (Yahya, session 2)
- **Décision** : la compréhension du produit ([v2/comprehension-produit.md](v2/comprehension-produit.md) et [v2/analyse-technique.md](v2/analyse-technique.md)) est **validée**. Les deux documents passent VALIDÉ et sont figés (addendum de faits inclus).
- **Faits nouveaux fournis à cette occasion** (lèvent une partie des hypothèses §7) :
  - **[FAIT]** Movenso n'a **jamais été diffusé publiquement** et n'a **pas de base d'utilisateurs actifs**.
  - **[FAIT]** La V2 est un **prototype très avancé** ayant servi à explorer le domaine, valider des choix techniques et apprendre.
- **Portée** : structurante (fonde la Phase 2).

## D-005 — La compatibilité fonctionnelle avec la V2 n'est pas un objectif

- **Date** : 2026-07-10 · **Statut : Validée humain** (Yahya, session 2)
- **Décision** : la valeur de la V3 prime sur la reconduction des fonctionnalités existantes. Un concept, modèle de données ou format V2 ne peut être conservé que pour sa **valeur démontrée**, jamais par souci de compatibilité historique. La Validation 2 ne doit pas raisonner à partir des fonctionnalités V2 mais des **utilisateurs potentiels et de leurs besoins**.
- **Portée** : structurante. Renforce D-003.

## D-006 — Validation 2 acquise : Vision A comme base de travail

- **Date** : 2026-07-10 · **Statut : Validée humain** (Yahya, session 3)
- **Décision** : la **Vision A** (« compagnon d'entraînement du pratiquant », [vision-v3.md](vision-v3.md)) est validée comme base de travail de la Phase 3, **sous réserve** de deux analyses complémentaires (menées en §7 de vision-v3.md) : (a) vérifier si le cœur du modèle doit s'organiser autour de **rôles** ou de **situations d'usage** ; (b) déterminer si la représentation explicite de **niveaux de connaissance/confiance** autour d'une même technique (référentiel officiel / enseignement de club / ressource sélectionnée / connaissance personnelle) appartient au cœur du modèle V3.
- **Arbitrages associés** :
  - Préparation de grade : pas nécessairement le cœur du premier incrément — l'agent détermine si elle est indispensable au flux vertical minimal ou si elle est un second incrément.
  - **Retrait de la gouvernance multi-utilisateurs : validé.** Si elle revient un jour, ce sera pour un **usage observé**, jamais anticipé.
  - **Téléphone = cible primaire : validé.** Les autres plateformes sont arbitrées à la Validation 3.
  - Ni conservation ni suppression « parce que V2 » : chaque décision guidée par la valeur (confirme D-005).
- **Faits nouveaux** : **[FAIT — humain]** des démonstrations de la V2 ont été réalisées auprès de pratiquants et d'enseignants de plusieurs clubs et disciplines ; retours encourageants, mais **ne constituant pas une validation d'usage**.
- **Portée** : structurante.

## D-007 — Validation 3 acquise : contrat de construction validé, avec exigences permanentes

- **Date** : 2026-07-10 · **Statut : Validée humain** (Yahya, session 4)
- **Décision** : le [contrat de construction](contrat-construction.md) est **validé** (passe VALIDÉ, figé), ainsi que les conclusions de [vision-v3.md](vision-v3.md) §7 (situations d'usage ; provenance au cœur du modèle métier, qualifiant le savoir et non les utilisateurs). Validés explicitement : retrait de la gouvernance, migration V2 payée une fois par outillage, spikes S1/S2 avant implémentation importante, principe d'une seule implémentation des règles métier, report du grade à l'incrément 2.
- **Exigences permanentes attachées (Phase 4)** :
  - **Valeur d'abord** : chaque choix important doit répondre explicitement à « quelle valeur nouvelle cette décision apporte-t-elle au premier utilisateur ? ». Autant d'énergie à démontrer la valeur créée qu'à supprimer la complexité. Pas plus de fonctionnalités : une meilleure expérience.
  - **Remise en question jusqu'à la Validation 4** : la vision validée n'est pas figée ; toute hypothèse importante infirmée par un prototype ou une recette est remise en cause immédiatement, jamais préservée par inertie.
  - **Android primaire** : direction validée, mais la décision doit rester justifiée par la **valeur produit** (pas seulement la réduction de dette) ; tout élément nouveau qui la questionne est documenté, pas ignoré.
  - **Périmètre incrément 1** : le report du grade est conditionné à la capacité de l'incrément à démontrer une valeur réelle ; si le grade devient indispensable à cette démonstration, proposer une évolution du périmètre plutôt que suivre le plan.
- **Faits** : **[FAIT — humain]** toujours aucun utilisateur actif ; intérêt réel suscité par les démonstrations, sans valeur de validation d'usage.
- **Portée** : structurante.

## D-008 — Convention : communication visuelle des décisions

- **Date** : 2026-07-10 · **Statut : Validée humain** (règle demandée par Yahya ; intégration permanente aux conventions décidée par l'agent)
- **Décision** : quand une décision est plus facile à comprendre visuellement qu'en texte, produire spontanément la représentation qui **réduit le plus le coût de compréhension et de validation humaine** : Mermaid pour workflows, modèle métier, architecture, navigation (rendu nativement par GitHub) ; **prototype HTML interactif** pour interfaces et parcours quand cela réduit le coût des itérations avant développement. Aucun format privilégié par principe. Les prototypes vivent dans `docs/prototypes/` et sont des **artefacts de communication**, jamais du code de production.
- **Justification** : règle stable qui économise des allers-retours de validation — exactement le type de connaissance que la mission demande de rendre déterministe.
- **Portée** : réversible. Intégrée à [conventions.md](conventions.md) §9.

## D-009 — Révision incrément 1 validée ; exigence de désirabilité ; question-fil-conducteur

- **Date** : 2026-07-10 · **Statut : Validée humain** (Yahya, session 6)
- **Décision** : les évolutions de la session 5 sont **validées** — M1 comme principe (« jamais vide de sens à l'ouverture », le Kodokan en est une démonstration) et parcours re-centré sur « Reprendre » avec rattachement optionnel.
- **Exigences permanentes ajoutées** :
  - **Désirabilité** : la V3 est démontrée plus *cohérente* que la V2 ; il reste à la rendre plus *désirable* — « l'application que j'aurais envie d'ouvrir après un entraînement ». Y répondre par **le parcours, les interactions, le rythme, la simplicité et l'expérience**, jamais par davantage de fonctionnalités. Les prochaines démonstrations doivent **faire ressentir** la valeur, pas l'expliquer.
  - **Question-fil-conducteur** (sans réponse exigée) : *« Si, dans dix ans, Movenso devenait une référence mondiale pour les arts martiaux, qu'aurait-il apporté que les autres n'avaient pas vu ? »* — à garder présente pendant toute la conception ; si une réponse émerge naturellement du travail, la faire découvrir à ce moment-là, ne pas la fabriquer artificiellement.
- **Portée** : structurante pour la conduite de la Phase 4.

## D-010 — Boucle de recette validée ; « ne pas gêner » n'est pas « être désirable »

- **Date** : 2026-07-10 · **Statut : Validée humain** (Yahya, session 7)
- **Décision** : passage au code validé ; la réponse se cherche dans l'**usage réel**, pas dans un nouveau prototype. Boucle attendue : (1) APK de spike (OPFS + caméra sur appareil réel) → (2) premier APK utilisable de l'incrément → (3) protocole de recette **très court, centré sur ce que l'humain fait spontanément** (pas sur ce que l'app demande de tester) → (4) résultats distingués en trois niveaux : **validation technique / utilisabilité / désirabilité**.
- **Nuance actée** : ouverture instantanée, zéro configuration et capture sans temps mort sont des conditions **nécessaires** de désirabilité mais prouvent seulement que l'app *ne gêne pas*. La recette doit montrer qu'elle apporte assez de valeur pour donner **spontanément envie de la rouvrir**.
- **Méthode** : ne pas résoudre par avance des défauts supposés ; livrer le chemin le plus court vers une vraie utilisation et laisser la recette produire les prochaines décisions.
- **Portée** : structurante pour la fin de la Phase 4.

## D-011 — Spikes S1/S2 validés ; le Kodokan reste fidèle à sa source ; pack club en `enseignement`

- **Date** : 2026-07-11 · **Statut : Validée humain** (Yahya, session 8)
- **Spikes** : **[FAIT — appareil réel]** S1/S2 validés sur Samsung SM-A366B (Android 16, WebView 149) : OPFS (141/458 Mo/s, persistance, quota 10,8 Go), vidéo filmée → OPFS → **lecture confirmée image et son**, caméra in-app. L'hypothèse du contrat §4 est levée : **architecture de stockage unique OPFS confirmée, fallback abandonné**.
- **Relations / provenances** : les données du pack club ne sont **pas** fusionnées dans le référentiel Kodokan (provenances et autorités différentes ; le Kodokan reste fidèle à sa source, même sans relations). Le pack club est converti **séparément** en provenance **`enseignement`** (`donnees/club-judo.json` : 49 techniques, 26 avec relations, 11 niveaux) — premier cas réel du modèle multi-provenance.
- **Réversibilité** : niveau de réversibilité élevé exigé jusqu'à la première vraie recette sur tatami — si elle remet en cause un parcours, un libellé ou un comportement, **le produit s'adapte au terrain**, jamais l'inverse.
- **Portée** : structurante (contenu + méthode de fin de Phase 4).

## D-012 — Synthèse, pas arbitrage : les qualités V2 se conservent ou se sacrifient explicitement

- **Date** : 2026-07-11 · **Statut : Validée humain** (retour de Yahya, session 9)
- **Contexte** : constat humain sur l'incrément 1 — la V3 échangeait des qualités (capture fluide) contre d'autres (découverte/exploration de la V2), sans que ce sacrifice soit décidé. L'attente est une **synthèse**, pas un arbitrage.
- **Décision** :
  1. **Règle permanente** (intégrée à [conventions.md](conventions.md) §8) : toute qualité existante du produit (V2 ou V3 antérieure) qui serait supprimée ou dégradée par un choix doit faire l'objet d'un **sacrifice explicite et justifié**, tracé dans la matrice de conservation ([archives/increment-1.md](archives/increment-1.md) §6bis) — jamais d'une perte subie.
  2. **Exploration restaurée dans l'incrément 1** : explorateur de discipline en grille visuelle à vignettes, filtres ceinture/famille/nom **cumulables**, couleurs de ceintures. Pertes silencieuses de conversion réparées : couleurs de niveaux (11) et variantes (4) réintégrées au modèle, au convertisseur et aux données.
  3. Les sacrifices restants sont recensés et justifiés dans la matrice (§6bis d'archives/increment-1.md) — dont : vignettes dépendantes du réseau pour les contenus référencés (inhérent aux vidéos non téléchargées), favoris différés (couche perso de l'incrément 3).
- **Portée** : structurante (règle de méthode permanente).

## D-013 — Rencontre des voix : constat, conséquences, recommandation

- **Date** : 2026-07-11 · **Statut : Proposée** (arbitrage humain demandé — touche le contrat §2 en pratique, pas en schéma)
- **Constat [FAIT — mesuré sur les données]** : l'implémentation fait **cohabiter des copies**, elle ne réalise pas la rencontre des voix. La conversion a créé une identité de technique **par pack** : 24 des 49 techniques du club portent le même nom (normalisé) qu'une technique Kodokan (Harai-goshi, Ippon-seoi-nage…) et existent pourtant en **double**, avec des ids distincts. S'y ajoutent des quasi-doublons que le nom seul ne détecte pas (« De Ashi Barai » ↔ « De-ashi-harai »). 6 des 12 familles du club coïncident aussi avec celles du Kodokan.
- **Conséquences** :
  - **M3 affaibli** : la fiche à deux voix ne réunit que référentiel + *personnel* ; l'enseignement du club sur Harai-goshi n'apparaît jamais sur la fiche Kodokan de Harai-goshi.
  - **Recherche** : doublons dans les résultats (deux « Harai goshi »).
  - **Relations fragmentées** : les 26 relations du club n'éclairent que les copies club.
  - **Dérive conceptuelle** : la provenance glisse de « nature du savoir » vers « étiquette de pack » — contraire à vision §7.2 validée.
  - **Import/export** : figer `.movpack` v3 sur cette base figerait la fragmentation.
- **Cause racine [DÉDUCTION]** : le **modèle est conforme au contrat** (une identité, des contributions par provenance — aucun changement de schéma requis) ; c'est l'**unité d'instanciation** qui est fausse : un pack importé crée sa propre discipline et ses propres identités au lieu de **rejoindre** la discipline et les identités existantes. C'est le problème d'identité inter-packs que la V2 avait explicitement différé.
- **Recommandation [RECO]** :
  1. **Une discipline = l'art martial** (« Judo »), jamais la source. Kodokan et club deviennent des voix (provenance + attribution) autour des mêmes identités.
  2. **Rapprochement à l'import** (fonction pure du domaine) : nom normalisé identique dans la discipline → la technique importée **rejoint** l'identité existante (24 cas immédiats) ; sinon elle en crée une. Quasi-correspondances → file **« à rapprocher »** avec suggestion, même geste que « à rattacher » (déjà validé). Familles fusionnées par le même mécanisme.
  3. **Relations réécrites** vers les identités rejointes → les relations du club éclairent la fiche unique.
  4. **Niveaux du club** = programme (matière de l'incrément 2) ; portés par la discipline fusionnée en attendant.
  5. L'export par provenance reste intact (chaque contribution garde provenance + attribution) : le pack club se ré-exporte tel quel.
- **Alternatives écartées** : *statu quo* (cohabitation) — simple mais pérennise doublons et provenance-étiquette ; *identifiant canonique global* (slug inter-packs) — surdimensionné, le rapprochement par nom + confirmation humaine suffit à l'échelle.
- **Séquence proposée** : implémenter le rapprochement **avant** de figer `.movpack` v3 ; rejouer la conversion des deux packs à travers lui ; l'accueil montre alors une seule discipline Judo, la fiche réunit réellement les voix.
- **Portée** : structurante (réalisation du cœur du modèle).

## D-014 — Garde-fou déterministe contre la dérive documentaire

- **Date** : 2026-07-11 · **Statut : Autonome** (réversible)
- **Contexte [FAIT]** : dérive constatée par l'humain entre l'état réel et la mémoire du dépôt — `README.md` affirmait encore « le code V3 n'existe pas », `etat.md` gardait ouvertes des hypothèses levées par D-011 et « aucune dette » malgré le code. Cause racine : des **assertions de présent dupliquées hors d'`etat.md`** (violation de conventions §2) et une mise à jour d'`etat.md` incrémentale au lieu d'une relecture.
- **Décision** :
  1. **Garde-fou mécanique (CI)** : toute poussée qui modifie `src/`, `donnees/`, `tools/` ou `tests*/` sans modifier `docs/etat.md` **échoue**. (Ne garantit pas la justesse du contenu, mais rend l'oubli impossible.)
  2. **Règle renforcée** (conventions §6) : la mise à jour de fin de session d'`etat.md` est une **réécriture des sections périssables** (état, risques, dettes, hypothèses), pas un ajout — chaque hypothèse/risque est soit reconduit, soit fermé avec référence.
  3. **Interdiction confirmée** : aucune assertion d'état courant hors d'`etat.md` ; les autres documents pointent vers lui.
- **Portée** : réversible (mécanisme ajustable).

## D-015 — D-013 et D-014 validées ; propriétés exigées du rapprochement

- **Date** : 2026-07-11 · **Statut : Validée humain** (Yahya, session 11)
- **Décision** : D-013 validée — une discipline représente **l'art martial** ; les packs et leurs auteurs sont des **sources de contributions**. Implémentation du rapprochement **avant** de figer `.movpack` v3. D-014 également validée (garde-fou CI : observer son coût/bruit ; il garantit la *modification* d'etat.md, pas sa *véracité* — le faire évoluer s'il pousse à des modifications artificielles, jamais le garder par inertie).
- **Propriétés exigées du rapprochement** :
  1. automatique **uniquement** au sein d'une même discipline et si non ambigu ;
  2. **aucune fusion silencieuse irréversible** ;
  3. **traçabilité** vers le pack et l'élément source ;
  4. **réimport idempotent**, sans duplication ;
  5. quasi-correspondances et variantes traitées **explicitement** ;
  6. **toutes les relations réécrites et validées** vers les identités réunies.
- **Arbitrage par lots** : les rapprochements incertains sont présentés en lot compact ; une fois arbitrés ils deviennent **déterministes et réutilisables** (table de rapprochement versionnée comme donnée).
- **Mandats associés** : (a) surveiller la transition documentaire « mission → système construit » (architecture réelle, flux, contrats de données, format d'échange, procédures, capacités) — documents consolidés, schémas et contrats exécutables, pas de coquilles ; (b) examiner **de façon critique** deux intuitions humaines (bibliothèque comme matériau de composition ; carnet comme indices de récupération) avant le gel du format V3 — analyse, pas validation automatique.
- **Portée** : structurante.

## D-016 — Examen des deux intuitions : composition et indices de récupération

- **Date** : 2026-07-11 · **Statut : Proposée** (analyse rendue, arbitrage attendu ; détail dans la conversation de session 11)
- **Intuition 1 — la bibliothèque comme matériau de composition** :
  - **[DÉDUCTION]** Révèle une **destination** plus qu'une extension : la trajectoire du produit est *capturer → relier → composer*. La **préparation de grade est un cas particulier** d'un concept général : une composition (séquence ordonnée de références à des identités, avec transitions commentées et médias propres) dont la provenance varie — programme de grade (`enseignement`/`referentiel`), prestation ou système (`personnel`), cours, séance. Les données le confirment déjà : les « Nage no Kata — 1er/2e groupe » du club **sont** des compositions.
  - **Compatibilité** : totale avec le modèle — une composition est une entité **additive** qui référence des identités (y compris inter-disciplines), sans toucher Technique/Contribution/Relation. Ajoutable par migration ; **rien à figer dans `.movpack` v3 aujourd'hui**, car les deux fondations nécessaires sont posées par D-013/D-015 : identités stables (l'id survit au rapprochement, l'origine trace) et références inter-disciplines libres.
  - **Principe acté en amont** (seul engagement pris maintenant) : les **transitions de composition ne sont pas des relations** — la relation reste le savoir objectif du graphe ; la transition est contextuelle à une composition. Ne jamais surcharger l'un avec l'autre.
  - **Critique** : risque « produit-dans-le-produit » (déjà le rejet FB1 de la V2), besoin calibré n=1, valeur conditionnée à la densité du contenu, et danger de détourner l'incrément avant sa recette. → **Différer l'implémentation** ; concevoir l'incrément 2 comme « compositions » (programme de grade en premier cas), avec prototype conceptuel D-008 à ce moment-là.
- **Intuition 2 — le carnet fournit des indices de récupération, pas de la documentation** :
  - **[DÉDUCTION]** Fondée : le complément personnel utile est un **déclencheur** (« la banane », « coup de volant ») qui réactive une mémoire incarnée ; la vidéo est le souvenir, le mot est la clé.
  - **« Note », « repère », « mot personnel » et média ne sont pas des objets métier distincts** — les séparer serait de la sur-modélisation ; la contribution actuelle (texte libre + médias) les porte tous. Ce qui manque est une **capacité**, pas un objet : (a) la **recherche doit indexer les mots personnels** (chercher « banane » doit retrouver la technique — aujourd'hui seule l'identité est indexée) ; (b) la capture doit **inviter le mot bref et la vidéo d'abord**, pas la rédaction (libellés/placeholder).
  - **Critique** : idiolecte n=1 — sans risque, la provenance `personnel` l'isole ; collision de mots — la recherche renvoie plusieurs fiches, comportement voulu.
  - → **Deux retouches réversibles proposées pour l'incrément courant** (sans changement de modèle ni de format) : extension de la recherche au texte des contributions personnelles ; reformulation de la feuille de capture. Le reste attend la recette.
- **Ce que les deux révèlent ensemble [HYPOTHÈSE, à laisser mûrir]** : Movenso serait la **mémoire externe du savoir incarné** — des identités stables où les voix se rencontrent, sur lesquelles on capture (indices), relie (graphe), compose (réutilise). Noté sans le figer (question des dix ans, D-009).
- **Portée** : structurante si validée (oriente l'incrément 2) ; les retouches proposées sont réversibles.

## D-017 — Movenso est un moteur générique ; aucun contenu disciplinaire embarqué

- **Date** : 2026-07-11 · **Statut : Validée humain** (principe posé par Yahya, session 12) — implémentée le jour même
- **Principe** : Movenso n'est pas une application de judo rendue extensible : c'est un **système où l'utilisateur crée, structure, qualifie, relie, enrichit, retrouve, compose, importe, exporte et partage son propre savoir martial**. Le judo, le Kodokan et le pack club sont des **jeux de données d'épreuve** — précieux comme fixtures et démonstrations, jamais comme définition ni dépendance du produit.
- **Décisions d'implémentation** :
  1. **Aucun pack embarqué** dans l'application de production : distribution séparée (artefact `packs-demo`, future page publique), installation volontaire en un geste.
  2. **Vide mais jamais bloqué** : au premier lancement, trois actions — capturer immédiatement (y compris technique + discipline créées à la volée), importer un pack, créer sa discipline de zéro.
  3. **Taxonomies = données** : discipline, familles, niveaux, couleurs, appellations vivent dans les données ; le moteur ne fige que les catégories épistémiques (provenances) et le vocabulaire sémantique des relations (nécessaire à la dérivation d'inverse) — assumés et documentés, extensibles par migration.
  4. **Règles de rapprochement = données de corpus** (`donnees/rapprochements-judo.json`), consommées par l'outillage et les fixtures, jamais par le cœur.
  5. **Plateforme vidéo explicite** : `Media.service` (« youtube » aujourd'hui) — le service n'est plus une hypothèse implicite du moteur.
  6. Kodokan + club restent les **tests exigeants** du moteur générique (fixtures de la suite de tests et du e2e, qui éprouve désormais le vrai parcours : démarrage vide → import volontaire → fusion des voix).
- **Contaminations corrigées** : seeding embarqué (racine.ts), packs dans le bundle (vite publicDir), table judo chargée par le cœur, `disciplines[0]` supposée à la création de technique, kanji 柔道 codé en dur, YouTube implicite, libellés judo (kuzushi/manche, tatami) génériqués.
- **Portée** : structurante — conditionne le gel de `.movpack` v3.

## D-018 — Distillation du corpus de conception ; apports de la contre-analyse externe

- **Date** : 2026-07-11 · **Statut : Autonome** (intégrations réversibles ; les points de portée produit restent des hypothèses/exigences pressenties, pas des décisions)
- **Contexte** : l'humain a transmis l'export de la conversation parallèle de contre-analyse (ChatGPT) ayant accompagné le chantier. Passe d'ingestion **unique** : le transcript n'entre pas dans le dépôt ni dans le chemin de reprise ; seule la connaissance durable est intégrée aux sources existantes.
- **Constat** : l'essentiel du transcript recopie les livrables déjà capitalisés (D-001→D-017). Les apports réellement nouveaux sont les **quatre réserves de la contre-analyse** sur D-017, intégrées comme suit :
  1. **Exigences du contrat `.movpack` v3** (intégrées à l'action « figer v3 » d'etat.md et à systeme.md §5) : identité du pack, auteur, provenance, **version**, intégrité, conditions d'utilisation, **mise à jour et réimport**, signalement fiable officiel/club/personnel — la confiance dans la source est au cœur de Movenso — plus une expérience de distribution simple (site, partage de fichier, QR, messagerie → import explicite).
  2. **La propriété des données exige un filet démontré** : OPFS est un stockage privé d'application — désinstallation ou perte du téléphone = perte totale tant que l'export intégral + la **restauration testée** n'existent pas. L'export/import v3 est une **fondation produit**, pas une fonctionnalité périphérique ; à démontrer avant de considérer la fondation stable (risque R8, priorité relevée). La composition (D-016) reste en conception derrière.
  3. **« Pas d'admin lourd » ne doit pas devenir un dogme** : la curation contextuelle suffit pour ajouter, pas pour construire ou réorganiser cinquante techniques. Piste différée tracée (matrice §6bis) : **atelier de curation grand écran**, distinct du quotidien — ni backend, ni supprimé par principe.
  4. **Le vocabulaire des relations est une hypothèse bornée (H5)** : `prépare/enchaîne/contre/similaire` n'est pas démontré suffisant pour karaté, JJB, boxe ou exercices pédagogiques. Ne pas rendre déclaratif maintenant ; l'éprouver sur d'autres disciplines **avant gel définitif** du format.
  - Complément de recette : faire tester le **premier lancement vide par un œil neuf** (quelqu'un qui n'a jamais vu Movenso).
- **Écarté volontairement** : le dialogue lui-même, les répétitions, le méta-protocole de distillation (exécuté), l'archivage du transcript dans le dépôt.
- **Portée** : réversible (exigences et hypothèses, pas d'implémentation).

## D-019 — Distillation de la connaissance produit : intégrations minimales validées, corrections de statut

- **Date** : 2026-07-12 · **Statut : Validée humain** (Yahya, session 15)
- **Contexte** : distillation de ce que les échanges ont changé dans la
  compréhension du produit (principes validés, tensions, connaissances
  négatives, hypothèses en maturation). Quatre manques réels identifiés dans le
  dépôt ; l'humain valide les intégrations minimales, en demandant trois
  corrections de formulation et de statut avant application.
- **Intégrations validées** :
  1. L'hypothèse « **mémoire externe du savoir martial incarné** » (D-016)
     devient visible dans les fils conducteurs d'`etat.md` — comme hypothèse en
     maturation, candidate à la question des dix ans (D-009), **sans** promotion
     dans la vision (une telle réponse se découvre, ne se fabrique pas).
  2. **Pièges de conception** ajoutés à [conventions.md](conventions.md) §8,
     symétriques des pièges de code — critère d'entrée strict : une erreur
     *observée* ou un rejet *arbitré*, jamais une opinion.
  3. La **curation lourde** est requalifiée de « différée » en **tension
     permanente** (matrice archives/increment-1.md §6bis) : à porter comme tension
     d'entrée de la conception de l'incrément 2, sans résolution hâtive ni dans
     le sens « admin-panel reconstruit sur mobile », ni dans le sens « refus de
     la curation d'échelle par dogme ».
  4. La **consolidation de la vision** (aujourd'hui distribuée entre
     vision-v3.md et D-013/D-016/D-017) est **différée à la frontière
     Validation 4 → Validation 5**, après la recette.
- **Corrections de formulation et de statut** (précisent D-016 et D-009 sans
  les réécrire — journal append-only) :
  1. **Composition — finalité ≠ provenance** : une prestation, un cours, un
     programme ou un système sont des **finalités ou formes d'usage**, jamais
     des provenances — chacune peut porter une provenance `personnel`,
     `enseignement`, `referentiel` ou autre. Cette séparation est stricte. De
     même, la « séquence ordonnée de références » est une **forme possible** de
     composition, pas encore sa définition universelle.
  2. **Requalification épistémique** : les groupes de Nage-no-Kata
     **[DÉDUCTION] suggèrent** un besoin de regroupement structuré ou de
     composition — ils ne démontrent pas à eux seuls être des compositions. Les
     références inter-disciplines sont une **compatibilité probable** des
     fondations actuelles, non démontrée tant que le modèle de composition
     n'existe pas.
  3. **Indices personnels** : le statut juste est « **aucune modélisation
     supplémentaire n'est justifiée aujourd'hui** » — une sobriété actuelle,
     pas une identité conceptuelle définitive. Note, repère, mot et média
     restent portés par la même contribution, mais pourront demain exiger des
     comportements UX, de recherche ou d'affichage différenciés.
  4. **Désirabilité (précise D-007/D-009)** : remplacer « jamais par davantage
     de fonctionnalités » par une formulation non absolue — l'ajout de
     fonctionnalités **n'est pas une réponse automatique** au manque de
     valeur ; chaque nouvelle capacité doit démontrer qu'elle renforce les
     usages centraux sans dégrader les qualités existantes.
- **Non couvert** : le fond de D-016 (la composition comme colonne vertébrale
  de l'incrément 2 ; les deux retouches réversibles) reste **Proposée**,
  arbitrage attendu.
- **Portée** : réversible (formulations et visibilité — aucun changement de
  modèle ni de code).

## D-020 — Mission d'exécution : la synthèse Movenso V2/V3, en autonomie

- **Date** : 2026-07-12 · **Statut : Validée humain** (mission écrite de Yahya, session 16)
- **Contexte** : la phase d'analyse est close. L'humain confie la conception et
  l'implémentation **en autonomie** d'une synthèse cohérente conservant les
  meilleures qualités V2 et V3 — sans arbitrage écran par écran. L'arbitrage
  humain n'est sollicité que pour une décision irréversible, destructive,
  juridique ou en conflit avec une décision validée.
- **Décisions de cadrage contenues dans la mission** (elles tranchent des
  points jusqu'ici ouverts) :
  1. **La composition devient une capacité explicite du produit** — le fond de
     D-016 (intuition 1) est arbitré : workflow vertical minimal réel
     (« Ma spéciale » : créer → ajouter → réordonner → consulter → modifier →
     exporter → restaurer). Blocs ordonnés de natures différentes ; les
     exemples (prestation, programme de grade, cours…) ne sont **pas** une
     taxonomie universelle ; finalité ≠ provenance (D-019) ; les transitions
     de composition ne sont pas les relations du graphe ; une composition
     **référence** les identités, ne les duplique jamais.
  2. **Le vocabulaire des relations devient un mécanisme générique de
     données** — tranche H5 (D-018.4) par généralisation maîtrisée : un type
     de relation porte libellé, libellé inverse éventuel, direction ou
     symétrie, origine, règles de validation. Les relations existantes restent
     migrables. La liberté de configuration reste compatible avec validation,
     portabilité et compréhension de l'interface.
  3. **L'espace de curation est décidé** (tranche la tension D-018.3/D-019) :
     distinct de l'usage quotidien, adapté au grand écran, même code — nommé
     autrement qu'« Admin » (retenu : **Atelier**). Gouvernance du corpus par
     sensei/curateur ; indicateurs uniquement actionnables (conflit, média
     absent, relation invalide, sans source, rapprochement en attente,
     sauvegarde nécessaire). À exclure : tableau de bord dense, compteurs sans
     décision, formulaires monolithiques sur téléphone, rôles/permissions sans
     usage démontré.
  4. **Réglage du comportement de démarrage** (accueil contextuel / dernière
     bibliothèque consultée / bibliothèque ou discipline choisie), accessible
     dans les paramètres ou l'Atelier, sans compliquer le premier lancement.
  5. **La fiche technique est repensée** : média principal en tête (hiérarchie
     V2 conservée pour sa valeur), origine/auteur/provenance identifiables,
     voix distinctes, relations et compositions en accès compact — lecture
     immédiate sur téléphone, pas de longue succession verticale.
  6. **L'identité visuelle est à refondre** : la charte V3 actuelle est jugée
     générique (grands rectangles arrondis, bleu-violet uniforme). Direction
     demandée : identité propre, énergie martiale sans folklore, priorité aux
     médias et aux gestes, densité maîtrisée, aucune couleur disciplinaire
     codée en dur dans le moteur.
  7. **Documentation visuelle vivante des workflows** : un support consolidé
     unique (Mermaid + prototype HTML navigable quand plus efficace),
     distinguant implémenté / prototypé / différé / hypothèse.
  8. **Raison d'être élargie et réaffirmée** : Movenso est un **système
     souverain** pour structurer, gouverner, diffuser, consulter, enrichir et
     réutiliser un savoir martial — le carnet personnel et la capture sont des
     usages importants mais ne réduisent pas Movenso à une app de notes.
     Tablette de club, téléphone du pratiquant et grand écran du curateur =
     trois contextes du **même système**.
  9. **Critères de sortie** : démonstration complète sur installation vide
     (import/création, exploration, fiche média-en-tête, voix distinctes,
     capture guidée, rattachement différé, modification contextuelle,
     composition « Ma spéciale », export complet, restauration sur
     installation vierge sans perte, choix du démarrage, documentation
     visuelle fidèle). La V2 reste en lecture seule.
- **Méthode maintenue** : incréments verticaux complets ; aucune qualité
  sacrifiée silencieusement (matrice à jour, D-012) ; modèle/migrations/tests/
  export/documentation maintenus en parallèle ; commit et poussée à chaque
  jalon cohérent.
- **Portée** : structurante (elle définit la phase 5 du projet).

## D-021 — Choix d'exécution autonomes de la synthèse (session 16)

- **Date** : 2026-07-12 · **Statut : Autonome** (cadre D-020 ; tous réversibles)
- **Contexte** : la mission D-020 délègue la conception ; ce billet trace les
  choix non triviaux pour qu'ils restent discutables sans archéologie de code.
- **Choix** :
  1. **Identité visuelle** : encre et papier washi, **un seul accent
     vermillon laqué** pour l'action et la marque (fab, boutons principaux,
     tiret des étiquettes de section) ; l'indigo et l'ocre redeviennent des
     **couleurs de provenance** (sourcé / personnel), portées par des filets
     latéraux plutôt que des blocs pleins ; coins francs (6-10 px) ; le
     jugement de désirabilité reste humain (D-009), la recette tranche.
  2. **Restauration complète réservée aux installations vierges** : un export
     `portee: "complet"` ne s'importe pas dans une bibliothèque habitée
     (message actionnable renvoyant au pack de discipline) — évite toute
     fusion hasardeuse d'exports complets, sans bloquer le cas réel (nouveau
     téléphone, PC). À rouvrir si la recette montre un besoin de fusion.
  3. **La publication d'un pack exclut toujours le carnet personnel** — le
     partage du savoir personnel passera par un geste explicite distinct,
     jamais par défaut.
  4. **Retour contextuel** : la fiche revient à l'explorateur de sa
     discipline, une composition à la liste des compositions — le bouton
     Android suit la même logique.
  5. **Types de bloc de composition fixés côté moteur** (8 natures, dont
     `etape` libre qui couvre le non-nommé) — même statut épistémique que les
     provenances : vocabulaire assumé, extensible par migration.
  6. **Préférences d'appareil hors bibliothèque** (fichier OPFS séparé) :
     le réglage de démarrage ne voyage jamais dans un export — l'appareil
     choisit, pas le savoir.
- **Portée** : réversible.

## D-022 — Release candidate de la synthèse ; gel du périmètre jusqu'au retour de recette

- **Date** : 2026-07-12 · **Statut : Validée humain** (Yahya, session 17)
- **Décision** : la livraison des jalons 0→7 (D-020) est reconnue comme
  **release candidate techniquement démontrée** — PAS comme une Validation 4
  terminée. Le périmètre fonctionnel est **gelé** : aucun ajout ni refonte
  avant le retour de recette. Les workflows sont documentés « **implémentés
  techniquement, validation terrain en attente** », jamais « validés ».
- **Référence de la RC** : commit `d3a0579` (code gelé), run `apk`
  29181115999 (artefacts `movenso-apk` + `packs-demo`, expiration
  2026-08-11). Les commits suivants ne touchent que la documentation.
- **Points que la recette observera** (listés dans
  [recette.md](recette.md) §Recette 2) : média principal multi-voix,
  rattachement différé réservé au personnel, publication vs sauvegarde
  intégrale, fluidité des compositions sur téléphone, direction graphique,
  tablette collective vs téléphone personnel. **Aucune décision corrective
  sur ces points avant le retour humain** — seule exception : une anomalie
  empêchant l'installation ou la recette elle-même.
- **Portée** : structurante (borne la phase 5 jusqu'à la Validation 4).

## D-023 — Phase de fermeture fonctionnelle ; premiers retours terrain

- **Date** : 2026-07-12 · **Statut : Validée humain** (Yahya, session 18 —
  remplace le gel D-022 par une phase exclusive de **fermeture fonctionnelle**)
- **Cadre** : aucune nouvelle fonctionnalité hors du strict nécessaire aux
  quatre fermetures ci-dessous. La **V2 sert de référence de complétude**
  (capacités utiles, pas ses écrans). Arbitrage humain uniquement si la
  notion de collection ou les règles de publication imposent un choix de
  modèle irréversible. Un workflow n'est « complet » que si l'utilisateur ne
  rencontre **aucune impasse visible** — un test automatisé ne suffit pas.
- **Les quatre fermetures** :
  1. **Corpus de bout en bout** : discipline → première technique →
     structure → média/contribution → apparition en bibliothèque. Depuis une
     capture : rattacher à l'existant, créer une technique, ou structurer
     plus tard — sans impasse (constat : « Créer ma discipline » menait à
     une bibliothèque vide sans création de technique visible).
  2. **Collections / publication maîtrisée** : la fusion des identités ne
     doit pas supprimer le parcours et la publication de **corpus
     distincts**. Examiner une couche de collection/vue (référentiel,
     programme club, préparation de grade, sélection personnelle) **sans
     recréer les techniques**. Une publication n'emporte **jamais par
     défaut** les contributions d'une source que l'auteur ne maîtrise pas.
  3. **Atelier en parcours** : réorganiser autour de workflows compréhensibles
     — construire le corpus · vérifier et résoudre · publier une sélection
     maîtrisée · protéger et restaurer — sans recréer le tableau de bord V2.
  4. **Compositions terminées** : créer → ajouter → modifier → réordonner →
     **consulter dans un mode adapté à l'entraînement** → naviguer vers une
     fiche **puis revenir** → exporter → restaurer ; clarifier « Capturer »
     depuis une composition.
- **[FAIT — humain] Premiers retours terrain** (avant recette formelle) :
  - Préférence globale actuelle pour la **V2** : workflows plus complets et
    aboutis, même si discutables.
  - **Aimés en V3** : arriver sur un accueil de conception (pas la
    bibliothèque) ; bouton Capturer contextuel ; navigation Android en bas ;
    l'option de démarrage (« top ») ; les couleurs jour/nuit ; la
    bibliothèque « split en deux ».
  - **Manques constatés** : créer discipline → impasse ; types de relation
    incompréhensibles (« nouveau type / inverse ») et **non supprimables** ;
    sauvegardes locales sans trace de la modification (rollback aveugle) ;
    les packs de démo sont des JSON, pas des `.movpack` ; la fusion à
    l'import devrait être une **proposition** (fusion complète / par
    technique / conserver / écraser — « une idée ») pas un automatisme
    subi ; la bascule accueil/bibliothèques à revoir ; **Reprendre**
    contient tout sans notion de « fini » (à réétudier — peut-être le point
    de départ des workflows) ; le menu Atelier mérite des sections comme la V2.
- **Portée** : structurante (définit la phase 6).

## D-024 — Passe contrariante sur l'UX (critique humaine, session 19)

- **Date** : 2026-07-12 · **Statut : Autonome** (cadre D-023 ; tous réversibles)
- **Contexte** : critique écran par écran de Yahya ; mandat « analyse d'un
  contrariant, fais les choix et mets-les en place ».
- **Choix appliqués** :
  1. **Accueil maigre** : Reprendre + Compositions + Chercher + Importer.
     La création de discipline n'apparaît qu'à la toute première installation
     (D-017) ; ensuite elle vit à l'Atelier — construire n'est pas une action
     quotidienne. La clé à molette disparaît (redondante avec la barre basse).
  2. **Les cartes de packs vivent dans l'onglet Bibliothèque** : direct si une
     seule discipline, liste sinon — l'accueil ne duplique plus la navigation.
  3. **Reprendre reste en tête d'accueil** : c'est l'hypothèse H2, la recette
     la juge — pas ce billet.
  4. **Fiche** : « ＋ note / 🎞 vidéo / 🔗 lien » DIRECTEMENT dans Mon carnet
     (la feuille de capture reste le geste du bord du tatami, plus un péage) ;
     les voix sourcées deviennent **amendables** en édition (description,
     attribution) — c'est TA bibliothèque ; provenance et origine restent
     tracées. Boutons clarifiés : « Terminer les modifications », « Supprimer
     cette note », « Retirer cette technique de la bibliothèque » (en zone
     basse, explicite, réversible par snapshot).
  5. **Composition : deux gestes** — ＋ technique, ＋ commentaire (bloc
     `repere`). Les huit natures restent dans le MODÈLE (les packs peuvent en
     porter, l'affichage les distingue) ; l'UI n'impose plus le choix —
     verrouiller l'utilisateur dans une taxonomie de blocs était une
     complexité sans valeur démontrée (D-019). Export : libellé + explication.
  6. **Atelier en accordéon** (details natif, un volet ouvert à la fois) :
     Construire (+ création de discipline) · Vérifier (badge de compteur) ·
     Publier · Protéger · Réglages — fin du mur de texte.
  7. Libellés de sources humanisés (« club-judo » → « Club judo »).
- **Non traité, tracé** : « des options V2 toujours absentes » (sans précision —
  la matrice §6bis reste la référence, à pointer en recette) ; la place de
  Reprendre (recette) ; l'avertissement sécurité (différé, matrice).
- **Portée** : réversible.

## D-025 — Reprise de l'Atelier sur retours terrain (session 20)

- **Date** : 2026-07-12 · **Statut : Autonome** (retours écrits de Yahya ; réversible)
- **Appliqué** :
  1. **Volets tous fermés** par défaut (accordéon conservé).
  2. **Réglages** : thème Auto / Jour / Nuit (forçable, priorité sur le
     système) + **6 tonalités** d'accent (vermillon, indigo, forêt, ocre,
     prune, acier) — préférences d'appareil, jamais exportées.
  3. **Protéger et échanger** : export **.movpack uniquement**, en deux
     variantes — *avec vidéos* (restauration à l'identique) ou *sans vidéos*
     (léger) ; le sélecteur d'import n'accepte plus que `.movpack` (la
     lecture JSON reste tolérée par détection de contenu — fixtures, D-005) ;
     `packs-demo` livré en `.movpack` seuls. La **publication par discipline**
     (périmètre de sources) est FUSIONNÉE ici : publier = exporter une
     sélection, il n'y avait pas deux concepts (constat humain juste).
     L'import multi-pack passe déjà par la proposition confirmée.
  4. **Vérifier et résoudre = tableau de voyants** (l'esprit des KPI V2,
     sans tableau de bord mort) : cinq contrôles verts/rouges — à rattacher,
     relations cassées, vidéos manquantes, techniques sans contenu,
     techniques sans niveau — chacun actionnable quand il est rouge.
  5. **Construire complété** : familles et niveaux **renommables**,
     **supprimables** (refus actionnable si utilisés), niveaux avec
     **double couleur de ceinture** (qualité V2 restaurée à l'édition —
     elle n'existait qu'en données) ; ajout par bouton ＋ (plus d'Entrée
     obligatoire).
  6. **Liens entre techniques** : tout type est supprimable, y compris
     utilisé — avec **avertissement de rupture chiffré** (« rompra N
     relations ») et snapshot motivé avant cascade.
- **Portée** : réversible.

## D-026 — Constat de finition (48 h de terrain) : la vérification devient visuelle

- **Date** : 2026-07-12 · **Statut : Autonome** (constat humain sévère et fondé)
- **Constat [FAIT — terrain]** : après 48 h d'usage réel, les finitions V3
  sont en-dessous de la V2 sur les écrans de gouvernance — champ de création
  non vidé (risque de doublon), titre de discipline déguisé en champ de
  saisie, FAB « Capturer » recouvrant le contenu de l'Atelier, mode d'emploi
  incrusté dans les libellés, action destructive habillée en action de
  création, placeholders tronqués. Cause racine : la vérification reposait
  sur le e2e (qui clique mais ne voit pas) et des captures en thème clair
  sur des états déjà peuplés — jamais l'état réel post-action en sombre.
- **Décision** :
  1. **Règle permanente (conventions §10)** : tout écran modifié se vérifie
     par capture d'écran dans l'état réel du parcours, thème sombre compris,
     et se REGARDE avant livraison. Un run vert ne vaut pas finition.
  2. Correctifs immédiats : champs vidés après création (Atelier,
     compositions, explorateur) + refus des doublons de discipline ; titre
     de discipline réel avec crayon explicite ; FAB retiré de l'Atelier et
     de l'édition de composition ; sous-volets sobres (« Familles (16) ») ;
     explication des liens repliée (« Comment ça marche ? ») ; « Retirer »
     en style destructif distinct ; méta sur une ligne ; placeholders courts.
  3. Vérifié sur capture sombre dans l'état exact du constat terrain
     (création de discipline) avant cette livraison.
- **Portée** : réversible (correctifs) ; la règle 1 est une méthode permanente.

## D-027 — Contributions importées : original intact, adaptation locale (remplace D-024)

- **Date** : 2026-07-12 (session 22, pendant le lot 3) · **Statut : Validée (décision humaine)**
- **Décision** : ni la D-024 telle quelle (amendement libre des voix
  sourcées), ni une règle générale « toute contribution portant une origine
  de pack est non modifiable ». Une contribution tierce importée reste
  **intacte et non modifiable directement** ; l'utilisateur peut ajouter son
  repère personnel ou **créer une adaptation locale** — nouvelle
  contribution locale, préremplissable depuis la voix source, attribuée
  lisiblement (« Adaptation locale d'après Kodokan »), affichée séparément
  de l'original, jamais écrasée par une réimportation. Une contribution
  créée localement reste directement modifiable. La maîtrise éditoriale ne
  se déduit pas de la seule origine de pack ; tant qu'elle n'est pas
  représentable fiablement, protéger l'original et proposer l'adaptation,
  sans nouveau système de propriété. Adaptations et carnet exclus par
  défaut de la publication (précisé au lot 6). Aucun champ grisé sans
  explication. Détail opérationnel : `docs/execution/DECISIONS.md` §57-64.

