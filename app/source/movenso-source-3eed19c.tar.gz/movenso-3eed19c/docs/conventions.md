# Conventions du dépôt Movenso V3

> **Type : vivant** · **Statut : NON VALIDÉ (proposition initiale, 2026-07-10)**
> Ce document définit les règles de fonctionnement du dépôt. Il est la seule
> source de vérité pour ces règles : ne pas les redéfinir ailleurs.

## 1. Pourquoi ces conventions existent

La mission ([MISSION-movenso-v3.md](../MISSION-movenso-v3.md)) exige que le dépôt
devienne la mémoire du projet : reprise à faible coût en tokens, séparation
présent / historique / hypothèses / décisions, et distinction stricte entre ce
qui est validé humainement et ce qui ne l'est pas. Ces conventions transforment
ces exigences en règles mécaniques, pour qu'aucun agent n'ait à refaire ce
raisonnement.

## 2. Carte documentaire (une source de vérité par sujet)

Chaque information durable vit dans **un seul** document faisant autorité sur
son sujet. Avant de créer un document, vérifier qu'aucun existant ne peut
l'accueillir. Le tableau ci-dessous est **la carte à jour** (unifiée le
2026-07-24, D-128) : elle réconcilie le socle de conception (`docs/*.md`) et la
mémoire opérationnelle introduite en finition (`docs/execution/*`).

**Autorité par sujet** (« qui dit vrai sur… ») :

| Sujet | Source de vérité UNIQUE | Ne PAS chercher ailleurs |
|---|---|---|
| Le **présent** (phase, prochaines actions, réserves, dettes) | `docs/execution/STATE.md` | (l'ancien `docs/etat.md` est un **pointeur historique** — voir plus bas) |
| Les **décisions** (arbitrages numérotés `D-NNN`) | le **journal en deux segments** : `docs/decisions.md` (D-001→D-027, conception) **puis** `docs/execution/DECISIONS.md` (D-028→D-127+, finition) — voir §5 | nulle part on ne reformule une décision : on la cite par son numéro |
| L'**architecture réelle** (structure du code, modèle, flux, plateformes) | `docs/systeme.md` | — |
| Les **parcours utilisateur** (workflows + leur statut de démonstration) | `docs/workflows.md` | — |
| Le **protocole agent** (boucle autonome, conditions d'arrêt) | `docs/execution/MASTER.md` | — |
| La **recette, non-régression et matrice des capacités** | `docs/execution/QUALITY.md` (+ check-lists testeurs `docs/recette-beta*.md`, protocole appareil `docs/recette.md`) | — |
| Les **règles du dépôt** (ce document) | `docs/conventions.md` | — |

**Documents figés / de référence** (ne pilotent plus rien, cités mais pas mis à jour) :

| Document | Rôle | Type |
|---|---|---|
| `MISSION-movenso-v3.md` | Mission d'origine — autorité supérieure du projet | figé |
| `docs/vision-v3.md` | Utilisateurs, vision A validée + analyse §7 (Validation 2) | figé (validé — D-007) |
| `docs/contrat-construction.md` | Choix structurants de construction (Validation 3) | figé (validé) |
| `docs/execution/note-modele-donnees.md` | Note de conception du modèle en couches + **backlog de durcissement** (§7bis) | proposition (à valider) |
| `docs/execution/plan-beta.md` | Plan de livraison de la bêta | vivant (court) |
| `README.md` | Porte d'entrée humaine : quoi, où, comment reprendre | vivant |
| `CLAUDE.md` | Protocole de session condensé pour agents | vivant |

**Historique / analyse figée** (mémoire, jamais de l'état courant) :
`docs/archives/` (roadmap des lots 1-10 **exécutée**, conception d'incrément 1,
rapport de recette `rc.1`, protocole de conception) · `docs/v2/`
(compréhension produit + analyse technique de la V2) · `docs/prototypes/`
(artefacts de communication, D-008). **Transitoire / jetable** :
`docs/execution/analyse-captures-chatgpt.md`,
`docs/execution/notes-doc-utilisateur.md` (amorce de la future doc utilisateur).

Règles :

- **Présent** = `docs/execution/STATE.md` uniquement. Tout le reste décrit du
  stable, du figé ou de l'historique. `docs/etat.md` a rempli ce rôle pendant la
  conception (lots 1-10) ; il est désormais **réduit à un pointeur** vers
  `STATE.md` (conservé pour l'historique et le garde-fou CI D-014).
- **Décisions** = le journal (§5). Un autre document cite une décision par son
  numéro (`D-067`), jamais ne la reformule.
- **Une seule mémoire opérationnelle** : la phase de finition écrit dans
  `docs/execution/*`. On n'ouvre pas un second `docs/*.md` concurrent pour le
  même sujet — on met à jour l'existant (voir la règle §12).
- Un document supprimé, fusionné ou archivé laisse une ligne de trace dans le
  journal des décisions.

## 3. Statuts documentaires

Chaque document commence par un en-tête :

```
> **Type : vivant | figé | append-only** · **Statut : VALIDÉ (date, par qui) | NON VALIDÉ**
```

- **NON VALIDÉ** : proposition ou analyse d'agent. Ne doit jamais être lu comme
  une décision. C'est le statut par défaut de tout contenu produit par un agent.
- **VALIDÉ** : approuvé explicitement par l'humain (Yahya). Seul l'humain fait
  passer un contenu à VALIDÉ ; l'agent ne fait qu'enregistrer la validation
  (date + périmètre) après l'avoir reçue.
- **figé** : ne sera plus modifié (historique). **vivant** : tenu à jour, la
  version courante fait foi. **append-only** : on ajoute, on ne réécrit pas.

## 4. Marqueurs épistémiques

Toute affirmation importante dans un document d'analyse ou de décision porte sa
nature. Vocabulaire fermé :

- **[FAIT]** — observé directement (code, doc, comportement reproduit). Citer la source.
- **[DÉCISION V2]** — décision historique tracée dans les docs V2. Elle explique la V2, elle n'engage pas la V3.
- **[DÉCISION]** — décision V3, enregistrée dans `docs/decisions.md`.
- **[DÉDUCTION]** — conclusion raisonnée à partir de faits ; réfutable.
- **[HYPOTHÈSE]** — supposition non vérifiée ; doit apparaître dans les questions ouvertes de `docs/etat.md` si elle conditionne la suite.
- **[RECO]** — recommandation de l'agent, en attente d'arbitrage humain.

Règle absolue (mission) : une hypothèse ne devient jamais un fait par simple
répétition. Elle devient un fait par vérification, ou une décision par
validation humaine.

## 5. Journal des décisions (un journal, deux segments physiques)

Le journal des décisions est **une seule séquence continue `D-001 → D-127+`**,
répartie sur deux fichiers pour des raisons historiques (aucune renumérotation
possible : les `D-NNN` sont cités dans une vingtaine de fichiers, code compris) :

- **`docs/decisions.md`** — segment **conception** : `D-001 → D-027`. Format
  narratif (contexte · décision · justification · portée · statut).
- **`docs/execution/DECISIONS.md`** — segment **finition** : `D-028 → D-127+`.
  Regroupe une **synthèse d'invariants** par thème (Navigation, Bibliothèque,
  Fiche…) **et** les arbitrages datés numérotés qui la révisent. Un item daté
  postérieur **prime** sur un invariant antérieur qu'il révise (ex. l'arbitrage
  « nav à quatre onglets » prime sur l'invariant « trois onglets »).

Règles communes :

- **Append-only, jamais renumérotées.** On ajoute, on ne réécrit pas.
- Une décision se **résout sans ambiguïté par sa plage** : `D-013` → `decisions.md` ;
  `D-067` → `execution/DECISIONS.md`.
- Statut : **Validée humain** / **Autonome** (réversible, prise par l'agent dans
  une phase validée) / **Proposée** (en attente d'arbitrage).
- Annuler = nouvelle entrée qui référence l'ancienne (« annule / révise D-0XX »),
  pas une réécriture.
- Pour la **vérité courante** du produit (et non l'historique des arbitrages),
  lire `docs/systeme.md` (architecture) et `docs/execution/STATE.md` (présent),
  pas la synthèse d'invariants.

## 6. Protocole de session

**Début de session :** suivre l'ordre de lecture de [CLAUDE.md](../CLAUDE.md)
(`docs/execution/MASTER.md` → `STATE.md` → `DECISIONS.md`, puis la carte du
système `docs/systeme.md` au besoin). Ne pas relire la mission ni les analyses
V2 en entier sauf si `STATE.md` le demande. Si l'analyse V2 l'exige : recloner
le dépôt V2 `https://github.com/prettozm/movenso` (lecture seule) dans le
scratchpad.

**Fin de session / de boucle (ou avant toute pause / demande de validation) :**
1. **Réécrire** les sections périssables de `docs/execution/STATE.md` (état réel,
   réserves, dettes, prochaines actions) — les réécrire, pas les compléter
   (D-014). Aucune assertion d'état courant ne vit ailleurs que dans `STATE.md`.
2. **Amender la doc au fil de l'eau** (règle §12) : toute évolution du produit
   met à jour, dans le même commit, `docs/systeme.md` (si l'architecture ou un
   comportement change), `docs/workflows.md` (si un parcours change) et
   `docs/execution/QUALITY.md` (recette/capacités).
3. Enregistrer les décisions nouvelles dans le journal (§5).
4. Committer et pousser sur la branche de travail. **Tout travail non poussé est perdu** (conteneur éphémère).

Garde-fou mécanique (D-014) : la CI échoue si une poussée modifie `src/`,
`donnees/`, `tools/` ou `tests*/` sans toucher le **présent**
(`docs/execution/STATE.md` — ou, par compatibilité, `docs/etat.md`).

## 7. Git

- Branche de travail imposée par la mission : `claude/movenso-v2-mission-ynb4ig`.
- `main` reçoit des **fusions de la branche de travail sur autorisation
  explicite de l'humain** (première autorisation : session 13) — jamais de
  commit direct.
- Dépôt V2 (`prettozm/movenso`) : **strictement lecture seule**.
- Messages de commit en français, impératif, préfixés par le domaine :
  `docs:`, `decision:`, `code:`, `test:`, `build:`, `etat:`.
- Commits fréquents et thématiques (un sujet = un commit). Pousser au minimum en fin de session.

## 8. Qualité (checklist permanente)

Avant de clore un lot de travail, se demander (mission §Qualité) :
supprimer ? simplifier ? automatiser ? désambiguïser ? réduire le coût de
reprise ? éviter qu'un futur agent refasse ce raisonnement ?

**Valeur d'abord (D-007, précisée D-019)** : tout choix important répond
explicitement à « quelle valeur nouvelle cette décision apporte-t-elle au
premier utilisateur ? ». Autant d'énergie à démontrer la valeur créée qu'à
supprimer la complexité. L'ajout de fonctionnalités **n'est pas une réponse
automatique** au manque de valeur : chaque nouvelle capacité doit démontrer
qu'elle renforce les usages centraux sans dégrader les qualités existantes.

**Conservation des qualités (D-012)** : la V3 vise une **synthèse**, pas un
arbitrage. Toute qualité existante (héritée de la V2 ou acquise en V3) qui
serait supprimée ou dégradée par un choix doit être un **sacrifice explicite,
justifié et tracé** — jamais une perte subie. Avant de clore un lot :
« quelle qualité existante ce lot dégrade-t-il, et l'ai-je décidé ? ». La
matrice de conservation d'origine est archivée
([archives/increment-1.md](archives/increment-1.md) §6bis, figée) ; depuis la
finition, tout sacrifice se trace dans le **journal des décisions** (§5).

Quand une connaissance devient stable, la sortir du probabiliste : convention
(ici), règle, script, test ou validation automatique. Une friction rencontrée
deux fois doit devenir un mécanisme.

**Pièges de conception (D-019)** — symétriques des pièges de code (§10).
Critère d'entrée strict : une erreur **observée** ou un rejet **arbitré**
(avec sa D-référence), jamais une opinion. Avant de concevoir, vérifier qu'on
ne retombe pas dans :

- l'**unité d'instanciation fausse sous un schéma conforme** — le modèle était
  juste et les copies cohabitaient quand même (D-013) ;
- la **perte silencieuse d'une qualité** lors d'une conversion ou d'une
  simplification (D-012) ;
- l'**usage anticipé au lieu d'observé** — la gouvernance V2, construite pour
  un contexte jamais constaté (D-006) ;
- le **produit-dans-le-produit** — rejet FB1 de la V2 ; critique de la
  composition (D-016) ;
- « **ne pas gêner** » pris pour de la valeur — condition nécessaire, jamais
  une preuve de désirabilité (D-010) ;
- l'**assertion de présent dupliquée** hors d'`etat.md` (D-014).

**Format des demandes de validation (mission)** : toute demande de validation
humaine présente synthèse courte, recommandation, alternatives, conséquences,
points à arbitrer, **et l'auto-critique (trois faiblesses + pourquoi
recommander malgré tout)** — constat de la session 14 : l'auto-critique
s'était érodée après la Validation 3 ; elle est obligatoire, pas décorative.

## 9. Communication visuelle (D-008)

Quand une décision se comprend mieux visuellement qu'en texte, produire
spontanément la représentation qui minimise le coût de compréhension et de
validation humaine :

- workflow, modèle métier, architecture, navigation → **Mermaid** dans le
  document concerné (rendu nativement par GitHub) ;
- interface / parcours utilisateur → **prototype HTML interactif** quand il
  réduit le coût des itérations humaines avant développement.

Aucun format privilégié par principe. Les prototypes vivent dans
`docs/prototypes/`, autonomes (un fichier, aucune ressource externe), et sont
des **artefacts de communication** : jamais du code de production, jamais une
référence d'implémentation.

## 10. Conventions de code (à partir de la Phase 4)

- **TypeScript strict**, ESM, Node LTS ; tests avec `node:test` (zéro
  dépendance de test). `npx tsc --noEmit` à 0 erreur + `npm test` vert avant
  tout commit de code.
- **Vocabulaire du domaine en français** (`Technique`, `Contribution`,
  `Provenance`…), fidèle aux documents — le code et la doc partagent les mêmes
  mots. Fichiers sources en français (`modele.ts`, `validation.ts`).
- `src/domaine/` reste **pur** : aucune dépendance plateforme, aucun accès
  E/S — c'est la garantie du principe « une seule implémentation » (contrat §3).
- Budget indicatif **~400 lignes par fichier** source ; au-delà, découper ou
  justifier dans le message de commit (contrat §9.4).
- Commentaires : uniquement le *pourquoi* non évident, avec renvoi au document
  de décision quand il existe (`cf. contrat §2.2`).
- **Finitions (D-026, constat terrain)** : tout écran modifié se vérifie
  **visuellement** avant livraison — capture d'écran dans l'ÉTAT RÉEL du
  parcours (y compris juste après une action : champ vidé ? doublon
  possible ?), **thème sombre compris**, et regardée. Le e2e clique, il ne
  voit pas ; un run vert ne vaut pas finition.
- **Pièges rencontrés (ne pas les repayer)** : (a) Lit sans décorateurs — un
  champ de classe ES2022 masque les accesseurs réactifs de `static properties`;
  initialiser les propriétés réactives dans le constructeur (`declare` +
  affectation) ; (b) Playwright — `hasText` matche en sous-chaîne
  (« Ko-soto-gari » contient « o-soto-gari ») : cibler en regex exacte ou par
  filtre sur l'élément de nom ; (c) les vignettes réseau échouent en sandbox :
  le e2e tolère uniquement les erreurs de ressources `img.youtube.com`.

## 11. Ce qui reste humain / ce qui s'automatise (mission §Mission)

**Reste humain, toujours** : les validations de mission et le passage d'un
statut à VALIDÉ ; les arbitrages de rapprochement incertains (lots) ; la
recette sur appareil réel et le jugement de désirabilité ; les releases et
toute diffusion ; les décisions de portée produit (vision, modèle, périmètre).

**S'automatise, systématiquement** : la vérification (typecheck, tests,
cohérence des données, e2e) ; les garde-fous de process (D-014) ; la
conversion et l'assemblage des packs ; les rapprochements **non ambigus** et
l'application des règles déjà arbitrées ; les builds (APK, web).

## 12. Doc à jour au fil de l'eau (anti-retard — D-128)

Constat (audit du 2026-07-24) : pendant la finition, le produit a avancé plus
vite que sa doc « propre » — `docs/systeme.md` décrivait encore « trois onglets »
alors que la nav en avait quatre. La règle qui suit empêche cette dérive de se
reformer.

**Une boucle n'est jamais « verte » si sa doc n'est pas à jour.** La mise à
jour documentaire fait partie de la *Definition of Done* d'une boucle (cf.
[CLAUDE.md](../CLAUDE.md) « Fin d'une boucle »), **dans le même commit** que le
code. Concrètement, avant de committer une évolution du produit, se demander et
agir :

| Ce qui change dans le code | Document à amender dans le même commit |
|---|---|
| Structure du code, modèle de données, flux, plateformes, version de schéma/movpack | `docs/systeme.md` |
| Un parcours utilisateur (entrée → étapes → sortie) ou son statut de démonstration | `docs/workflows.md` |
| Une capacité, une non-régression, un critère de recette | `docs/execution/QUALITY.md` |
| Un arbitrage (nouveau comportement décidé) | le journal des décisions (§5) |
| L'état d'avancement, une réserve, une dette | `docs/execution/STATE.md` |

**Épargne de vérité, pas de duplication** : on met à jour **le** document qui
fait autorité sur le sujet (§2), on n'en ouvre pas un second. Une affirmation
périmée est un bug de doc : on la corrige, on ne l'empile pas.

**Marqueur de fraîcheur** : les documents vivants descriptifs (`systeme.md`,
`workflows.md`) portent en en-tête la date de leur dernière remise en
cohérence avec le code. Un écart visible entre cette date et l'avancement de
`STATE.md` est un signal de dette documentaire à résorber à la boucle suivante.

## 13. Vues nouvelles : données ciblées, jamais `app` entier (S3.A2, D-204)

Règle d'architecture pour le code NEUF (l'existant ne se convertit pas en
bloc — décision D-204) : **toute nouvelle fonction de vue reçoit les données
et callbacks dont elle a besoin, pas l'instance `MovensoApp` entière.**
Une vue qui reçoit `app` couple son test et sa lecture à tout l'état racine ;
une vue qui reçoit `{ techniques, onOuvrir }` se comprend et s'essaie seule.
Conversion **opportuniste** : quand une boucle touche une vue existante,
resserrer sa signature si le coût est marginal — jamais de refonte dédiée.
