# Vision produit — Movenso V3

> **Type : figé** · **Statut : VALIDÉ (2026-07-10, Yahya — décisions D-006 et
> D-007, §7 inclus)**
> Réserve permanente (D-007) : la vision validée n'est pas figée — toute
> hypothèse importante infirmée par un prototype ou une recette est remise en
> cause immédiatement, jamais préservée par inertie.
> Note factuelle post-validation : les mentions « référentiel pré-chargé »
> (§5, §6/H2) sont **amendées par D-017** — aucun contenu embarqué ; H2 se lit
> désormais « l'app vide est actionnable et l'import en un geste suffit à la
> rendre riche ».
> Méthode imposée par D-005 : raisonner à partir des **utilisateurs potentiels
> et de leurs besoins**, pas des fonctionnalités V2. Base factuelle :
> [v2/comprehension-produit.md](v2/comprehension-produit.md) (VALIDÉ, dont
> l'addendum §8 : aucun utilisateur actif, V2 = prototype d'apprentissage).
> Marqueurs épistémiques : [conventions.md](conventions.md) §4.

---

## 1. Le problème de fond (avant tout utilisateur)

**[FAIT — nature du domaine]** Le savoir des disciplines du mouvement est un savoir
**incarné, montré, et périssable** : une technique est démontrée quelques
minutes en cours, puis la mémoire s'érode jusqu'à la séance suivante. Il est
aussi **relationnel** (entrées, enchaînements, contres, systèmes) et **nommé**
(terminologie, souvent japonaise, exigée aux passages de grade).

**[DÉDUCTION]** Ce savoir vit aujourd'hui à trois endroits qui ne se parlent
pas : (a) le cours (la variante du coach, jamais notée nulle part), (b) les
référentiels officiels (Kodokan, programmes fédéraux — dispersés, pas
structurés pour l'apprentissage individuel), (c) l'océan de vidéo en ligne
(YouTube, instructionals — volumineux, non organisé, non possédé). **Le
problème générique de Movenso : capturer, structurer et se réapproprier un
savoir technique incarné, sans dépendre d'un tiers.**

## 2. Utilisateurs potentiels, objectifs, contraintes, besoins

**[HYPOTHÈSE — l'ensemble de ce chapitre]** Ces profils sont construits par
raisonnement sur le domaine (et l'expérience V2 documentée), pas par enquête
terrain. Le seul utilisateur observable aujourd'hui est le mainteneur
(pratiquant + curateur).

### U1 — Le pratiquant en club (profil pivot)

Pratique 1 à 3 fois/semaine ; prépare des passages de grade ; à partir d'un
certain niveau, construit « son » système (tokui-waza, enchaînements favoris).

- **Objectifs** : retenir ce qui a été montré au cours ; réussir ses passages
  de grade (gestes + vocabulaire) ; construire un jeu personnel cohérent.
- **Contraintes** : fenêtres de temps courtes (vestiaire, trajet, veille de
  cours) ; le seul appareil au bord du tatami est le **téléphone** ; connectivité
  médiocre dans les gymnases ; aucune tolérance pour de la saisie longue ; la
  variante enseignée par *son* coach n'existe dans aucun référentiel.
- **Besoins (hypothèses de besoin)** :
  - B1. Retrouver une technique en secondes, par nom approximatif ou par situation.
  - B2. **Capturer en moins d'une minute** ce qui vient d'être montré (filmer,
    dicter/taper deux lignes, rattacher à une technique de référence).
  - B3. Voir son **programme de grade** : ce qui est exigé, ce qui est acquis,
    ce qui reste à travailler.
  - B4. Réviser le vocabulaire et les liens (préparations, contres) —
    idéalement auto-généré, sans saisie dédiée.
  - B5. Organiser ses techniques en **systèmes personnels** qui reflètent sa
    façon de combattre, pas la taxonomie officielle.

### U2 — L'autodidacte / cross-trainer

Consomme beaucoup de contenu en ligne (instructionals BJJ, chaînes YouTube),
souvent en plus du club. Même personne que U1 à un autre moment.

- **Objectifs** : ne pas perdre ce qu'il glane ; transformer des heures de
  vidéo en système exploitable au sparring.
- **Contraintes** : le contenu ne lui appartient pas (liens, plateformes
  tierces) ; volume énorme ; attention fragmentée.
- **Besoins** : B6. Capturer une référence en ligne (lien + horodatage + note)
  aussi vite qu'un favori de navigateur, mais rangée dans *sa* structure.
  B7. Organiser par situation/position autant que par discipline. B5, B4.

### U3 — Le coach / enseignant

- **Objectifs** : transmettre son programme ; garder la mémoire pédagogique de
  son club ; préparer ses cours.
- **Contraintes** : quasi aucun temps de saisie ; zéro appétence pour gérer de
  l'infrastructure ; élèves hétérogènes.
- **Besoins** : B8. Produire un référentiel de club à coût marginal (filmer en
  cours → fiche). B9. Le distribuer sans serveur ni comptes (un fichier).
  B10. Structurer par programme/grade.

### U4 — Le curateur de référentiel

Constitue un référentiel propre et sourcé d'une discipline (cas réel : le pack
Kodokan de la V2, 111 entrées). Aujourd'hui : le mainteneur lui-même.

- **Objectifs** : exactitude, sourçage, complétude raisonnée.
- **Contraintes** : coût de saisie énorme (make-or-break identifié par la V2) ;
  droits (référencer les vidéos officielles, jamais les copier).
- **Besoins** : B11. Outillage de production et de validation de packs
  (génération, tests de cohérence). B12. Publication simple (fichier + page).

### Écartés à ce stade

- **Le club/la fédération comme institution** (déploiement organisé,
  gouvernance multi-rôles) : aucun signal réel ; c'est l'hypothèse qui a le
  plus coûté à la V2 (cf. §3).
- **Le grand public sportif** (fitness, gamification) : contredit l'identité
  du produit et le rejet V2 explicite de la gamification.

**[DÉDUCTION centrale]** U1/U2 sont la même personne (le pratiquant qui
apprend), U3/U4 sont des producteurs. Sans base d'utilisateurs, un produit ne
peut compter sur aucun effet de réseau : **il doit créer de la valeur pour un
utilisateur seul, dès le premier jour**. Le seul profil qui satisfait cette
condition ET correspond à un utilisateur réel observable est **U1/U2**. U3/U4
restent atteignables plus tard par le même canal (les packs-fichiers), sans
qu'il faille les servir d'abord.

## 3. Hypothèses V2 réexaminées

**[DÉDUCTION]** À la lumière des faits D-004 :

1. **« Movenso est un outil de club » (V1/V2)** — hypothèse **jamais vérifiée** :
   aucun club, aucun élève. Elle a pourtant dimensionné le produit : PIN admin,
   rôles, journal d'activité, « édition autorisée pour tous », app vide au
   premier lancement (l'élève attend son pack). Cette gouvernance est la
   première **complexité spéculative** de la V2.
2. **« Le glissement d'audience vers le pratiquant » (vision V2 du 2026-06-02)**
   — directionnellement **juste** (c'est le seul usage réel), mais traité comme
   une **couche** au-dessus du produit-club, donc éternellement différé. La V2
   a construit le socle de distribution d'un contenu que personne ne recevait,
   et différé l'usage que quelqu'un avait.
3. **« Une seule UI sur trois runtimes »** — coût structurel n°1 mesuré
   (duplication renderer/Electron/Java, dette non testable) pour servir des
   plateformes sans utilisateurs. Hypothèse de valeur **non démontrée** ;
   le besoin réel est l'appareil du tatami (téléphone) + un écran confortable
   pour la curation.
4. **« Le graphe ne vaut que par ses données »** — hypothèse **confirmée** par
   l'expérience (le pack Kodokan a exigé un gros travail de curation ; la
   fonctionnalité sans données est une UI vide). Toute vision V3 doit intégrer
   le coût d'alimentation dès la conception.
5. **« Offline-first, sans compte, local »** — non testé en diffusion, mais
   c'est l'**identité** du produit et sa différenciation durable (pérennité,
   possession des données). Reconduit comme invariant ; le « portable sur
   3 runtimes » redevient un choix ouvert.

## 4. Visions candidates

### Vision A — Le compagnon d'entraînement du pratiquant *(recommandée)*

**Formule** : *« Ce que le tatami t'enseigne, garde-le. »* Movenso V3 est le
carnet d'entraînement structuré d'un pratiquant : il capture ce que le cours
lui montre, l'accroche à un référentiel propre, et le transforme en système
personnel et en préparation de grade.

- **Problème résolu** : l'érosion du savoir entre deux cours et la dispersion
  (cours / référentiel / vidéos en ligne) — le problème §1 vu du seul
  utilisateur réel.
- **Valeur pour** : U1/U2 dès le premier jour, seul, sans réseau. U4 (curateur)
  servi par l'outillage de packs ; U3 (coach) atteignable plus tard : un coach
  est un pratiquant qui partage (export de packs), pas un rôle à gouverner.
- **Ce qu'elle conserve de la V2 (valeur démontrée, D-005)** :
  - Les invariants offline / sans compte / local / simple / robuste / pérenne —
    l'identité (§3.5), renforcée : au bord du tatami, le réseau est un luxe.
  - Le **pack-fichier** (concept `.movpack` v2 : conteneur à portée +
    manifeste d'aperçu + détection par contenu) — seul mécanisme de
    distribution compatible « sans compte », pont vers U3/U4, format éprouvé.
  - Le **graphe de relations à inverse dérivé** — substrat des systèmes
    personnels (B5) et de la révision (B4) ; design validé par l'usage V2.
  - Le **contenu de référence comme donnée** (pack Kodokan et son pipeline de
    génération/validation) — l'actif le plus coûteux de la V2, directement
    réutilisable comme socle sur lequel le pratiquant accroche son savoir.
  - Les leçons d'architecture (domaine pur, une seule implémentation par
    règle, identités stables ULID + dédup sha256).
- **Ce qu'elle supprime** :
  - **Toute la gouvernance multi-utilisateurs** : PIN admin, rôles, « édition
    autorisée pour tous », journal d'activité, auto-logout. Un appareil = un
    propriétaire ; l'app appartient à son utilisateur. (Un verrou d'app simple
    pourrait revenir plus tard comme confort, pas comme modèle de rôles.)
  - **L'app vide au premier lancement** (posture « l'élève attend son pack ») :
    la V3 démarre utile — référentiel proposé à l'installation, capture
    immédiate.
  - **La séparation figée contenu-partagé/couche-perso comme architecture de
    gouvernance** : tout appartient à l'utilisateur ; la **provenance** (pack
    importé vs création perso) reste tracée pour permettre mise à jour de
    packs et exports propres — c'est une métadonnée, plus une frontière.
  - **Le double modèle vidéo** (VideoRef ⇄ MediaIndex) et l'encodage
    `youtube:<id>` — une seule représentation, types de source explicites
    (locale / lien direct / plateforme).
  - **La parité 3 runtimes comme dogme** : cible primaire = le téléphone ;
    le reste se justifie au contrat de construction (Validation 3).
- **Ce qu'elle apporte de nouveau** (besoin → réponse) :
  - B2 → **Capture éclair** : filmer/lier + deux lignes de note, rattachées à
    une technique (de référence ou créée à la volée), en moins d'une minute,
    hors ligne. C'est le geste fondateur du produit.
  - B5/B7 → **Systèmes personnels** : collections curées s'appuyant sur le
    graphe (attaques / préparations / enchaînements / contres *choisis*),
    définies par l'utilisateur, presets par discipline jamais codés en dur.
  - B3 → **Préparation de grade** : le programme (donnée du pack, par niveau)
    croisé avec l'état personnel (« travaillé / à revoir / acquis »).
  - B4 → **Révision auto-générée** (nom ↔ technique, reconnaissance vidéo,
    relations) — incrément ultérieur, aucune saisie dédiée, pas de gamification.
  - B1/B6 → recherche par nom approximatif et par situation ; capture de liens
    horodatés aussi rapide qu'un favori.
- **Compromis assumés** :
  - Mono-utilisateur par conception : si un vrai contexte club émerge, une
    partie de la gouvernance devra être reconstruite (pari YAGNI explicite).
  - La valeur dépend de la **discipline de capture** de l'utilisateur — le
    cimetière des apps de notes est réel. Mitigations par conception : coût de
    capture quasi nul, référentiel pré-chargé (l'app est utile avant la
    première capture), la préparation de grade crée un motif de retour.
  - Produit calibré sur n=1 utilisateur observable ; la recette réelle
    (Validation 4) est le seul juge.

### Vision B — L'atelier du transmetteur

**Formule** : Movenso V3 est l'outil de **production** de référentiels
techniques : un studio pour coachs et curateurs (filmer en cours, structurer,
relier, valider, publier des packs), accompagné d'un lecteur minimal pour les
élèves.

- **Problème résolu** : le coût de production d'un référentiel de qualité —
  le vrai goulot identifié par la V2 (make-or-break de l'alimentation).
- **Valeur pour** : U3/U4. Les consommateurs (U1/U2) reçoivent un lecteur
  simple, sans épaisseur produit.
- **Conserve de la V2** : format de pack, pipeline de génération/validation
  (élevé au rang de produit), taxonomies par discipline, relations.
- **Supprime** : tout le versant consommation riche (favoris, couche perso) ;
  la gouvernance in-app (l'auteur est propriétaire de son atelier).
- **Apporte** : authoring mobile en situation de cours, sourçage/attribution,
  contrôle qualité (cohérence, liens morts), publication (fichier + page).
- **Compromis** : produit pour des producteurs **sans consommateurs** — la
  valeur d'un pack se réalise chez un élève qui n'existe pas encore ; le seul
  curateur réel (le mainteneur) est déjà outillé par des scripts ; le besoin
  coach est totalement hypothétique (aucun coach n'a rien demandé).
- **Non recommandée parce que** : elle sert le maillon de la chaîne dont la
  demande est la moins vérifiée, et reporte (encore) la valeur d'usage au
  moment où quelqu'un d'autre adopterait le produit. C'est la reconduction du
  biais V2 (§3.2) sous une autre forme.

### Vision C — La bibliothèque de club, refaite proprement

**Formule** : reconstruire le produit V2 (bibliothèque partagée + gouvernance
club) sur une architecture assainie (une implémentation par règle, dette
résorbée).

- **Problème résolu** : principalement des problèmes **internes** (duplication,
  dette, testabilité) — pas un problème utilisateur nouveau.
- **Valeur pour** : un club hypothétique ; en pratique, le mainteneur-développeur.
- **Conserve** : presque tous les concepts V2. **Supprime** : la dette.
  **Apporte** : de la qualité technique.
- **Compromis** : c'est la « V2 plus propre » que la mission **exclut
  explicitement** (« Ne cherche jamais à produire une V2 plus propre »), au
  service d'une audience (§3.1) jamais vérifiée.
- **Non recommandée parce que** : elle échoue au critère central de la
  Validation 2 (valeur supplémentaire réelle) et réinvestit dans l'hypothèse
  la plus coûteuse et la moins validée de la V2.

### Vision D (écartée d'emblée) — Le format ouvert / référentiel commun

Movenso comme **standard de données** (format + ids canoniques + graphe
inter-disciplines), les apps n'étant que des vues. Écartée sans traitement
complet : un standard sans communauté n'est qu'un schéma privé ; c'est un
**moyen** (le pack l'implémente déjà à petite échelle), pas une vision produit.

## 5. Recommandation

**[RECO] Vision A — le compagnon d'entraînement du pratiquant**, en intégrant
de B ce qui sert un pratiquant-auteur (la capture éclair EST de l'authoring ;
l'outillage de curation de packs reste un outillage de dépôt, pas un produit).

Pourquoi A plutôt que B ou C :

1. **C'est la seule vision falsifiable immédiatement** : un utilisateur réel
   existe (le mainteneur-pratiquant) ; la Validation 4 (recette sur appareil
   réel) peut la confirmer ou l'infirmer sans dépendre de l'adoption par des
   tiers. B et C ne sont testables que par des utilisateurs hypothétiques.
2. **Elle crée de la valeur au premier utilisateur, seul** — condition
   nécessaire établie en §2 pour un produit sans base installée.
3. **Elle résout le problème §1 du point de vue de celui qui le subit** ; B et
   C le résolvent du point de vue de celui qui le ferait subir à d'autres.
4. **Elle supprime la complexité la plus spéculative de la V2** (gouvernance
   multi-rôles) au lieu de la reconduire, et attaque frontalement la dette
   architecturale n°1 (multi-runtime) en re-questionnant les plateformes.
5. **Elle ne ferme aucune porte** : les packs-fichiers restent le pont vers
   coachs et curateurs. Si un club apparaît, A + export est déjà utilisable ;
   l'inverse (C → usage perso riche) a précisément échoué en V2.

## 6. Hypothèses critiques que cette vision devra prouver

- **[HYPOTHÈSE H1]** Le geste de capture < 1 min, hors ligne, est réellement
  tenable en situation (vestiaire, fin de cours) et sera réellement fait. —
  *Test : Validation 4, usage réel sur plusieurs semaines d'entraînement.*
- **[HYPOTHÈSE H2]** Le référentiel pré-chargé + la préparation de grade
  suffisent à rendre l'app utile avant toute capture personnelle. — *Test :
  premier incrément.*
- **[HYPOTHÈSE H3]** Les « systèmes personnels » adossés au graphe sont
  utilisés par un pratiquant réel (et pas seulement élégants sur le papier). —
  *Test : différable après le cœur capture/référentiel/grade.*
- **[HYPOTHÈSE H4]** Le téléphone comme cible primaire ne sacrifie pas la
  curation confortable (grand écran) — à trancher au contrat de construction.

## 7. Analyse complémentaire (mandat de la Validation 2, D-006)

> Ajouté après la validation de la Vision A. Statut : NON VALIDÉ — conclusions
> reprises dans le contrat de construction (Validation 3).

### 7.1 Le cœur du modèle : rôles ou situations d'usage ?

**Question posée** : les profils U1-U4 sont-ils une séparation fondamentale ou
un outil d'analyse ? Le modèle métier doit-il se construire autour de rôles ou
de situations d'usage ?

**Examen.** Trois observations convergent :

1. **[FAIT — domaine]** Les frontières entre profils sont poreuses dans le
   temps et dans la semaine : un pratiquant devient enseignant (et continue de
   pratiquer), un curateur pratique, un gradé assiste le prof le jeudi et
   prépare son propre grade le samedi. Aucune de ces bascules ne change la
   *nature* de ce que la personne fait avec Movenso : consulter, capturer,
   organiser, réviser, échanger.
2. **[DÉDUCTION]** Aucune frontière de **données** ne suit les profils : le
   coach capture exactement comme le pratiquant ; le curateur consulte comme
   l'autodidacte. Ce qui distingue leurs productions n'est pas *qui ils sont*
   mais *le statut du savoir produit* (référentiel sourcé, enseignement de
   club, note personnelle) — cf. §7.2.
3. **[FAIT — leçon V2]** Encoder les rôles dans le produit a été la principale
   complexité spéculative de la V2 (PIN, rôles, type à 3 états résiduel),
   construite pour des frontières de personnes qui ne se sont jamais
   matérialisées.

**Conclusion [DÉDUCTION].** Les profils U1-U4 étaient un **outil d'analyse**
(utile pour énumérer les besoins), pas une structure du modèle. Le cœur du
modèle métier V3 se construit autour de **situations d'usage** — *consulter,
capturer, organiser (systèmes, grades), réviser, échanger (importer/exporter)*
— toutes exercées par **la même personne** sur la même bibliothèque. Le modèle
de données ne contient **aucune notion d'utilisateur ni de rôle** ; la
distinction pratiquant/enseignant/curateur ne survit que comme **provenance du
savoir** (§7.2). L'UI s'organise par situations, pas par rôles. Cette
conclusion renforce la Vision A : « le coach est un pratiquant qui partage »
devient une propriété du modèle, plus seulement un argument.

### 7.2 Les niveaux de connaissance : au cœur du modèle

**Question posée** : le modèle doit-il représenter explicitement plusieurs
niveaux de connaissance ou de confiance autour d'une même technique
(référentiel officiel, enseignement d'un club, ressource sélectionnée,
connaissance personnelle) — ou cette notion est-elle hors périmètre V3 ?

**Examen par les situations d'usage.** Autour d'une même technique
(o-soto-gari), un pratiquant réel accumule des savoirs de natures différentes :
la fiche du référentiel Kodokan (sourcée, stable), la variante montrée par son
prof (contextuelle, datée), un lien d'instructional choisi (externe, non
possédé), ses propres notes et vidéos (privées, faillibles). Si le modèle ne
distingue pas ces natures :

- **La mise à jour d'un référentiel détruit ou duplique** : impossible de
  remplacer le pack Kodokan v(n+1) sans écraser les notes perso accrochées, ou
  sans créer un deuxième « o-soto-gari » qui fragmente le graphe de relations.
- **L'échange devient impropre** : exporter « ma bibliothèque » réexporterait
  le contenu Kodokan comme s'il était mien (problème de droits et d'exactitude
  identifié dès la V2) ; inversement, partager sa variante de club sans ses
  notes intimes devient impossible.
- **La révision (B4) se corrompt** : un quiz auto-généré doit interroger sur le
  savoir de référence, pas sur mes hypothèses personnelles.
- **La confiance est invérifiable** : « qui dit ça ? » est une question
  centrale dans un domaine où mal exécuter une technique blesse.

**Conclusion [DÉDUCTION + RECO].** Cette notion appartient **au cœur du modèle
V3**, sous une forme précise : la **provenance des contributions**. Une
technique est une **identité** (un nœud du graphe) à laquelle s'attachent des
**contributions** portant chacune une provenance d'un vocabulaire fermé —
*référentiel* (corpus sourcé importé), *enseignement* (transmis par un
club/prof), *ressource* (lien externe sélectionné), *personnel* (produit par
l'utilisateur). La « confiance » est une lecture de la provenance, pas un
mécanisme séparé.

**Garde-fous anti-sur-modélisation [RECO]** : vocabulaire de provenances fermé
et petit (4 valeurs) ; **aucun score de confiance calculé** ; aucun moteur de
résolution de conflits (les contributions coexistent, l'utilisateur lit) ;
une contribution a exactement une provenance. C'est la généralisation du vrai
insight V2 (les deux couches contenu/perso) débarrassée de ce qui l'encombrait :
la provenance est une **métadonnée du savoir**, plus une **frontière de
gouvernance**.
