# Contrat de construction — Movenso V3

> **Type : figé** · **Statut : VALIDÉ (2026-07-10, Yahya — décision D-007)**
> Notes factuelles post-validation (le corps figé n'est pas réécrit) :
> l'hypothèse de stockage (§4, OPFS/WebView) a été **levée** par le spike
> S1/S2 sur appareil réel (D-011), fallback abandonné. Le point §10.2
> (« référentiel pré-chargé ») est **amendé par D-017** : aucun contenu n'est
> embarqué — les packs se distribuent séparément et s'installent
> volontairement ; l'app vide reste pleinement actionnable.
> Exigences permanentes attachées à la validation (détail : D-007) : chaque
> choix important répond à « quelle valeur nouvelle pour le premier
> utilisateur ? » ; remise en question active jusqu'à la Validation 4 ;
> Android primaire re-justifié par la valeur produit en continu ; périmètre de
> l'incrément 1 réévaluable si le grade devient indispensable à la
> démonstration de valeur.
> Fondations engagées par ce contrat : [vision-v3.md](vision-v3.md) (VALIDÉ,
> D-006), dont l'analyse §7 (situations d'usage, provenance) que ce document
> incarne. Couvre les points exigés par la mission : architecture, modèle
> métier, stockage/portabilité, médias, migration V2, sécurité, plateformes,
> tests/packaging, premier incrément. Les détails réversibles à l'intérieur de
> ce cadre relèvent de l'autonomie de l'agent (§11).

---

## 1. Invariants reconduits (proposés comme charte V3)

**[RECO]** Six invariants, hérités de l'identité du produit (valeur démontrée
comme différenciation durable, D-005), reformulés pour la V3 :

1. **Hors ligne d'abord** — aucune situation d'usage cœur n'exige le réseau ;
   le réseau n'apparaît que pour lire une ressource en ligne explicitement choisie.
2. **Sans compte, sans cloud** — aucune donnée ne quitte l'appareil sans un
   geste d'export de l'utilisateur.
3. **Local et possédé** — source de vérité : fichiers JSON + vidéos sur
   l'appareil, lisibles et réparables sans l'application.
4. **Simple** — un mainteneur seul comprend tout le flux en une session ;
   chaque dépendance se justifie.
5. **Robuste** — validation avant écriture, sauvegarde avant opération
   destructrice, jamais d'écrasement silencieux.
6. **Pérenne** — formats diffables, stack minimale et standard, utilisable dans dix ans.

L'invariant V2 « portable (même code sur 3 runtimes) » n'est **pas reconduit**
comme fin en soi : la portabilité redevient une conséquence des choix (§7),
pas un dogme (cf. vision §3.3).

## 2. Modèle métier cible

Incarne vision §7 : pas de rôles, pas d'utilisateur dans les données ; la
provenance du savoir est la métadonnée centrale.

### 2.1 Entités

- **Discipline** : espace de nommage et de taxonomie (familles, niveaux,
  types de relation par défaut). Livrée par un pack référentiel ou créée localement.
- **Technique (identité)** : nœud du graphe. `id` **ULID (string, unique)**,
  discipline, nom, nom traditionnel (optionnel), famille, niveaux (tags),
  relations. C'est l'ancre stable à laquelle tout s'attache.
- **Contribution** : unité de savoir attachée à une technique. Champs :
  provenance (§2.2), contenu (description, points clés), médias (§5), source /
  attribution (pour référentiel et ressource), dates. Une technique a une
  **contribution d'origine** (celle qui l'a créée — fixe sa fiche de base) et
  des contributions additionnelles. **La capture éclair crée une contribution
  personnelle** (sur une technique existante, ou sur une identité créée à la volée).
- **Relation** : `technique → technique`, type ∈ {prépare, enchaîne, contre,
  similaire}, stockée dans un seul sens, **inverse dérivé à l'affichage**
  (emprunt V2, valeur démontrée : pas de graphe asymétrique), cibles absentes
  tolérées (affichées, jamais bloquantes).
- **Programme de grade** *(modélisé, implémenté à l'incrément 2)* : donnée par
  discipline — niveau → exigences (techniques, vocabulaire). L'état personnel
  (« à travailler / travaillé / acquis ») est une donnée personnelle distincte
  du programme.
- **Système personnel** *(concept réservé, incrément 3)* : collection nommée de
  références au graphe. Aucune implémentation avant l'incrément 3.

### 2.2 Provenance (vocabulaire fermé — vision §7.2)

`referentiel` (corpus sourcé importé) · `enseignement` (transmis par un
club/prof) · `ressource` (lien externe sélectionné) · `personnel` (produit par
l'utilisateur). Une contribution a exactement une provenance. Pas de score de
confiance, pas de résolution de conflits : les contributions coexistent et se
lisent. Toute mise à jour d'un pack référentiel remplace **ses** contributions
(même origine de pack), jamais celles des autres provenances.

### 2.3 Schéma et migrations

- Schéma **versionné dès le premier jour**, avec un mécanisme de migration
  n→n+1 exécuté à l'ouverture (leçon V2 : `schemaVersion ≠ 1` rejeté sans
  chemin de migration).
- Identifiants : **ULID string partout** (leçon V2 : `id: number|string` a
  contaminé ~20 fichiers).
- Invariants validés avant toute écriture (unicité des ids, références
  taxonomie existantes, une vidéo primaire par technique, chemins relatifs sûrs).

## 3. Architecture générale

### 3.1 Principe directeur

**Une seule implémentation de chaque règle, exécutée partout** — réponse
directe à la dette n°1 de la V2 (triple implémentation renderer/Electron/Java).

### 3.2 Structure

```
domaine (TS pur)      modèle, validation, provenance, relations, packs, migrations
                      — zéro dépendance plateforme, testé unitairement
stockage (TS, unique) une seule implémentation sur APIs web standard (§4)
UI (web)              situations d'usage : consulter / capturer / organiser / échanger
coquille Android      Capacitor : WebView + plugins officiels minimaux (partage/export)
```

Il n'y a **pas de couche d'adaptation par plateforme** pour la logique : web et
Android exécutent le même code de stockage (APIs web standard disponibles dans
le WebView). La frontière native est réduite à ce que le web ne sait pas faire
dans une WebView : partager/enregistrer un fichier exporté (plugins Capacitor
**officiels** uniquement — aucun plugin Java maison, leçon V2).

### 3.3 Stack

**[RECO]** TypeScript strict + **Lit** (composants standard, ~5 Ko, pas de
lock-in) + **Vite** (build) + **fflate** (ZIP des packs) + **Capacitor**
(coquille Android). Justification par la valeur (pas par l'héritage V2) :
dépendances minimales et standards = invariants 4 et 6 ; et surface maximale
testable par le mainteneur et les agents (§9). Node LTS pour l'outillage.
Découpage UI par situation d'usage, gestion d'état simple et centralisée —
pas d'objet-Dieu (leçon V2 : budget de taille par fichier, cf. §9).

## 4. Stockage et portabilité

- **Une seule implémentation** : OPFS (Origin Private File System) pour les
  fichiers (JSON de la bibliothèque + vidéos), disponible dans Chrome et le
  WebView Android moderne. Données lisibles : la bibliothèque est un ensemble
  de fichiers JSON diffables, pas un blob opaque.
- **[HYPOTHÈSE à lever par le spike S1, §9.3]** OPFS + lecture vidéo + écriture
  en flux fonctionnent dans le WebView Android cible. **Fallback documenté** :
  plugin officiel `@capacitor/filesystem` pour les vidéos uniquement (le reste
  inchangé). Aucun développement au-dessus du stockage avant la levée de S1.
- **Web** : `navigator.storage.persist()` demandé (risque d'éviction, leçon V2).
- **Sauvegardes** : snapshot automatique **par session de modification** (à la
  première mutation) + avant toute opération destructrice (import écrasant,
  suppression de discipline, remise à zéro), rotation 10. Fini le clone complet
  par micro-mutation (dette V2 §6.10). La vraie sauvegarde de long terme est
  l'**export**.
- **Portabilité** : l'export `.movpack` (§6) fait circuler la bibliothèque
  entre téléphone et PC (web/PWA). **Pas de sync** : transfert par fichier, assumé.

## 5. Gestion des médias

- **Une seule représentation** (suppression du double modèle V2
  VideoRef ⇄ MediaIndex) : un média appartient à une contribution ; type de
  source **explicite** : `local` (fichier ULID + sha256, dédup à l'import) |
  `lien` (URL de fichier direct) | `plateforme` (YouTube : id + URL, embed
  nocookie). Fini l'encodage `youtube:<id>` dans un champ fichier (dette V2).
- Fichiers vidéo nommés par ULID, aucun sens métier dans le nom ; sha256 pour
  la déduplication (emprunt V2, valeur démontrée).
- Les médias en ligne ne sont **jamais téléchargés** (référence seule), jamais
  comptés « manquants » hors ligne, affichage dégradé propre si lien mort.
- Capture vidéo via les APIs web (caméra) — spike S2 (§9.3).
- Réconciliation JSON ↔ fichiers (orphelins/manquants) : conservée comme
  diagnostic simple — un scan en échec ne signale jamais de manquants (emprunt V2).

## 6. Format d'échange et compatibilité V2

- **Un seul format lu et écrit par l'application** : `.movpack` **v3** — ZIP
  (fflate) contenant `manifest.json` (format, version, **portée** :
  technique / discipline / bibliothèque, aperçu : disciplines, compteurs,
  présence de vidéos), les JSON de contenu **avec provenances**, et les vidéos
  locales optionnelles. Détection par contenu, jamais par extension (emprunt
  V2, valeur démontrée). L'export peut **filtrer par provenance** (partager
  l'enseignement du club sans les notes personnelles ; ne jamais réexporter un
  référentiel tiers comme sien).
- **Migration V2 = outillage, pas code d'app** : un script du dépôt
  (`tools/convertir-movpack-v2.ts`) convertit les `.movpack` v2 en packs v3
  (provenance `referentiel` ou `enseignement` selon le pack). Le **pack
  Kodokan** (actif le plus coûteux de la V2) est converti une fois et versionné
  comme donnée V3. Les bibliothèques personnelles V2 (appareils du mainteneur)
  passent par : export V2 → script → import V3. **Aucun lecteur de format
  legacy dans l'application** (la V2 en portait trois pour toujours).

## 7. Plateformes

| Plateforme | Statut | Justification |
|---|---|---|
| **Android (APK, Capacitor)** | **Primaire** | L'appareil du tatami (D-006). Recette réelle à chaque incrément. |
| **Web / PWA** | Secondaire | Curation grand écran (H4), développement, tests automatisés. Même code, zéro coût marginal. |
| Windows portable (Electron) | **Supprimé** | Usage jamais démontré ; source de la dette n°1 de la V2 (process CJS dupliqué, `webSecurity`). L'usage PC passe par le web/PWA. |
| iOS | Non (porte ouverte) | Aucun utilisateur ; Capacitor garde le chemin praticable si un besoin réel apparaît. |

## 8. Sécurité

- **Aucune authentification** (D-006 : gouvernance supprimée ; un appareil = un
  propriétaire ; le verrou de l'OS protège l'appareil). Pas de PIN, pas de
  rôles, pas de journal d'activité. Réintroduction possible uniquement sur
  usage observé.
- **Aucune télémétrie, aucun réseau implicite.** Seul accès réseau : lecture
  d'un média en ligne explicitement choisi (embed nocookie / lien direct).
- CSP stricte (`script-src 'self'`, frame YouTube-nocookie uniquement),
  pas d'injection HTML (templates échappés), chemins relatifs validés.
- Modèle de menace **documenté honnêtement** : les données sont en clair sur
  l'appareil ; la confidentialité = celle de l'appareil (leçon V2 : ne pas
  vendre du théâtre de sécurité).
- L'avertissement de sécurité de la pratique (contenu, pas code) est conservé —
  valeur réelle dans un domaine où l'on peut se blesser.

## 9. Stratégie de tests et de packaging

### 9.1 Principe (réponse au risque R3)

**Maximiser la surface testable sans appareil ; nommer explicitement le reste.**
La dette V2 venait de code invérifiable en environnement de dev (Electron
packagé, WebView réel). En V3 : le domaine et le stockage s'exécutent dans un
navigateur — testables en CI.

### 9.2 Pyramide

1. **Domaine** : tests unitaires (node:test, zéro dépendance) — modèle,
   validation, provenance, relations, packs (round-trips), migrations.
2. **Cohérence des données** : tests sur les packs distribués (ids uniques,
   références existantes, liens plausibles) — leçon V2 (C-5).
3. **Parcours UI + stockage réel** : Playwright sur Chromium (OPFS réel) — les
   situations d'usage de bout en bout : consulter, capturer, exporter/importer.
4. **Appareil réel** : **checklist de recette versionnée**
   (`docs/recette-appareil.md`, créée avec l'incrément 1) — lecture vidéo,
   capture caméra, partage de fichier, bouton retour, hors-ligne réel.
   Exécutée par l'humain à chaque incrément ; chaque défaut reproductible
   devient test, script ou règle (mission, Validation 4).

### 9.3 Spikes de dé-risquage (avant tout développement au-dessus)

- **S1 — OPFS dans le WebView Android** : APK minimal écrivant/lisant/jouant
  une vidéo depuis OPFS. Lève l'hypothèse §4 ou déclenche le fallback.
- **S2 — Capture caméra dans le WebView** : filmer et enregistrer en flux.
Ces deux spikes constituent la **première recette humaine** (petit APK jetable).

### 9.4 Budgets de qualité (garde-fous mécaniques)

`tsc --noEmit` 0 erreur + tests verts avant tout commit de code ; budget
indicatif de ~400 lignes par fichier source (au-delà : découper ou justifier
dans le commit) — réponse mécanique aux objets-Dieu V2.

### 9.5 CI / packaging

- **PR** : typecheck + tests domaine/cohérence + build web + Playwright.
- **À la demande** : APK debug en artefact (workflow séparé, tolérant réseau).
- **Pas de signing ni secret en CI** (leçon V2 validée) ; release = geste humain.

## 10. Premier incrément utilisable (périmètre proposé pour la Validation 4)

**Flux vertical « consulter + capturer »**, installable sur ton téléphone :

1. APK Android + PWA web (même build).
2. **Référentiel Kodokan V3 pré-chargé** (converti par le script §6) — l'app
   est utile avant la première capture (H2).
3. **Consulter** : recherche par nom approximatif, fiche (description, points
   clés, vidéo Kodokan référencée, relations cliquables avec inverse dérivé).
4. **Capturer** (< 1 min, hors ligne) : filmer ou noter, rattaché à une
   technique existante ou créée à la volée — contribution `personnel` (H1).
5. **Retrouver** : mes captures sur la fiche de la technique + liste « récentes ».
6. **Exporter / importer** la bibliothèque en `.movpack` v3 (portabilité,
   sauvegarde, chemin téléphone ⇄ PC).

**La préparation de grade n'est pas dans l'incrément 1** *(détermination
demandée par D-006)* : le flux vertical minimal qui teste la vision (H1, H2),
les fondations (modèle + provenance + médias + stockage), la cohérence des
données et la portabilité est « consulter + capturer + échanger ». Le programme
de grade n'ajoute aucune fondation nouvelle — mais exige une curation de
données (programmes par ceinture) qui retarderait la première recette. C'est
l'**incrément 2** (fort motif de retour dans l'app), suivi des systèmes
personnels (3) puis de la révision (4).

## 11. Autonomie / validation humaine

- **Autonome (réversible)** : découpage des modules, schémas JSON exacts,
  détails d'UI, choix d'outillage interne, contenu des tests, ordre des
  chantiers à l'intérieur d'un incrément validé.
- **Validation humaine obligatoire** : tout changement aux invariants (§1), au
  modèle de provenance (§2.2), aux plateformes (§7), au périmètre d'un
  incrément ; l'issue des spikes S1/S2 si le fallback change l'architecture ;
  chaque recette d'incrément (Validation 4 puis 5).

## 12. Risques et dettes acceptés à la signature

- **R-S1** : l'hypothèse OPFS/WebView peut échouer → fallback §4 (coût borné,
  décision tracée).
- **Liens YouTube périssables** (pack Kodokan) : assumé, affichage dégradé
  propre ; c'est une propriété des références externes, pas un bug.
- **n=1** : le premier incrément est calibré sur un utilisateur réel unique ;
  c'est le dispositif de falsification choisi (vision §5), pas un oubli.
- **Pas de sync multi-appareils** : transfert par fichier uniquement — dette
  d'usage assumée, cohérente avec « sans compte, sans cloud ».
