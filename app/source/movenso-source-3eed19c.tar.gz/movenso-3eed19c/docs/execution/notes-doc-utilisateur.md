# Notes pour la future doc utilisateur (à rédiger)

> **Il n'existe pas encore de documentation utilisateur** — tout `docs/` est
> interne (vision, système, exécution, recette). Ce fichier **collecte les
> comportements à expliquer** au pratiquant le jour où on écrit un guide / une
> aide in-app / des notes de version beta. Ce n'est pas le guide lui-même :
> juste la liste des points à couvrir, alimentée au fil du balayage.

## Améliorations différées (backlog beta)

- **Mode pas-à-pas (« Passer en revue ») — enrichissements (relevé 2026-07-18,
  vue 12).** Le déroulé plein écran est réactivé (D-093, bouton ▶). À ajouter
  plus tard, hors périmètre beta : **minuterie** facultative par étape, **écran
  maintenu éveillé** (wake lock), **mode paysage**, **sortie verrouillée par
  PIN** (tablette partagée d'un club).

## Points à expliquer

- **Travail progressif des fiches (relevé 2026-07-18, vue 9 analyse).** Movenso
  **accepte volontairement** qu'une fiche reste minimale (juste un nom) : on
  n'est **jamais forcé** de tout documenter d'un coup (média, description,
  classement viennent quand on veut). Ce n'est pas un bug ni un oubli — c'est un
  parti pris (une fiche « juste un nom » est légitime). Pour ceux qui veulent
  **retrouver ce qui reste à compléter**, il y a le filtre **« À compléter »**
  dans **Plus › Techniques** (mode avancé). → À dire clairement dans la doc pour
  que l'utilisateur ne prenne pas une fiche courte pour une fiche « cassée ».
