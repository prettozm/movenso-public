# Étude — modèles commerciaux applicables à Movenso

> **Type : aide à la décision** (demande porteur, 2026-08-03). RIEN n'est acté
> ici : le journal ([DECISIONS.md](DECISIONS.md)) reste la seule autorité.
> Contexte : D-211 (« pas de stratégie commerciale, dev pour la communauté,
> ouvert à discussion »), D-218/D-220 (code GPLv3, packs CC BY-NC-SA 4.0).
> Méthode : chaque modèle passe au CONTRARIANT (le meilleur argument contre).

## 1. Le cadre qui contraint tout

- **Code GPLv3** : recompilable et redistribuable gratuitement par quiconque —
  aucun modèle fondé sur le verrouillage du logiciel ne tient.
- **Packs CC BY-NC-SA 4.0** : le NC interdit l'usage commercial AUX AUTRES,
  pas au titulaire des droits — Movenso peut vendre ou double-licencier SES
  packs. C'est le seul verrou commercial réel du projet.
- **Local-first, sans compte, sans cloud, sans télémétrie** : promesse publiée
  (site, privacy policy, À propos) — tout modèle exigeant serveur ou compte
  casse le contrat du produit.
- **Niche** : arts martiaux francophones, développeur solo, v1 non lancée.

## 2. Les modèles au contrariant

### M1 — Gratuit + dons (Liberapay / GitHub Sponsors / Ko-fi)
- **Pourquoi** : aligné D-211, zéro friction, zéro infra, compatible licences.
- **Contrariant** : un don est un pourboire, pas un modèle — 0,1 à 1 % des
  actifs donnent ; sur une niche, négligeable. La pérennité reste suspendue à
  la seule motivation du porteur.
- **Implique** : lien sur le SITE et dans À propos ; ⚠️ dans l'APK Play, un
  bouton de paiement externe est en zone grise (politique Google Play
  Billing) — le lien de don vit sur le site. Dons = revenus déclarables.

### M2 — App payante (achat unique Play)
- **Contrariant (décisif)** : la même app est déjà distribuée GRATUITE sur le
  site (web + APK), et la GPLv3 garantit que d'autres peuvent la republier.
  Payer sur Play = don déguisé ; la barrière freine la croissance de la niche.
- **Implique** : compte marchand, 15 % Google, incohérence de canaux, attentes
  de support. → écarté.

### M3 — Freemium / fonctions premium (IAP)
- **Contrariant (décisif)** : (a) GPLv3 — le verrou est public, un fork le
  retire ; (b) produit — tout ce qui a de la valeur est déjà livré gratuit et
  promis tel quel : retirer après coup est une trahison ; (c) sans compte, pas
  de restitution d'achat en web. → écarté.

### M4 — Packs premium (double licence du NC) — 🕐 option 12-18 mois
- **Pourquoi** : LE modèle que la structure de licences permet — packs de base
  gratuits, packs approfondis vendus (préparation de grades, katas,
  programmes). Valeur éditoriale = inforkable, contrairement au code.
- **Contrariant** : (a) un pack vendable = des dizaines d'heures d'expertise
  éditoriale par pack — métier d'éditeur ; (b) aucun circuit de vente (site
  statique en clair, .movpack repartageable, pas de DRM — non souhaité) ;
  (c) **droits amont non réglés** (question D-211 ouverte : contenu
  Kodokan/fédéral) — vendre du contenu aux droits flous est le seul vrai
  risque juridique de cette étude ; (d) la niche paie rarement ce qu'un prof
  donne au tatami.
- **Implique** : boutique web (Stripe/Gumroad, hors Play = 0 % commission),
  TVA numérique UE, clarification ÉCRITE des droits avant le premier euro,
  **CLA obligatoire** si des contributions communautaires entrent un jour
  dans les packs officiels (sinon la double licence devient impossible).

### M5 — Abonnement
- **Contrariant (décisif en v1)** : rien à abonner — aucun coût récurrent
  côté Movenso, donc rente injustifiée. Le seul abonnement honnête (sync
  chiffrée) contredit « sans compte ni cloud », promesse publiée.
- **Implique (si un jour)** : serveur, comptes, RGPD, astreinte — un second
  métier. Uniquement en option strictement additive, jamais en v1.

### M6 — B2B : clubs, enseignants, fédérations — ✅ seul axe de revenu réel
- **Pourquoi** : le seul segment avec un BUDGET et un besoin structurel. Le
  mécanisme existe (pack publié au nom du club, D-211§4). Prestations :
  création du pack de club, formation, pack fédéral. Au projet (300-1 500 €)
  ou maintenance annuelle.
- **Contrariant** : c'est du consulting — le temps ne scale pas ; marché
  associatif pauvre et lent ; dépendance au réseau personnel ; un gros client
  peut déformer le produit contre la communauté.
- **Implique** : micro-entreprise, devis/factures — zéro changement du
  produit ni des licences (le contenu du club appartient au club). Le modèle
  le moins invasif de la liste.

### M7 — Sponsoring / partenariats — 🕐 après audience
- **Contrariant** : un sponsor achète une audience inexistante à ce stade ; le
  premier logo dans une app « souveraine, sans pub » entame le capital
  confiance. Si un jour : côté site uniquement.

### M8 — Publicité — ❌ définitif
- **Contrariant éliminatoire** : contradiction frontale et TECHNIQUE — la CSP
  stricte bloque les régies par construction, pas de télémétrie = pas de
  ciblage, la privacy policy le promet, un fork sans pub sortirait le
  lendemain (GPLv3).

### M9 — Open core / double licence du code — ❌ (garder l'option : CLA)
- **Contrariant** : « le code est public et le restera » est déjà écrit dans
  l'À propos ; deux éditions en solo = double charge ; l'option EXPIRE au
  premier contributeur externe sans CLA.
- **Implique** : pour seulement garder l'option, poser un CLA au premier
  contributeur externe. Sinon rien.

### M10 — Crowdfunding / subventions (ANS, sport-numérique) — 🕐 après traction
- **Contrariant** : un crowdfunding exige une communauté déjà chaude (v1 non
  lancée) ; subventions = dossiers et délais pris sur le produit.
- **Implique** : rien sur le produit ; par jalon précis (iOS, campagne packs).

## 3. Récapitulatif

| Modèle | Verdict | Raison en une ligne |
|---|---|---|
| M1 dons | ✅ tout de suite | coût nul, cohérent — mais pas un revenu |
| M2 app payante | ❌ | GPLv3 + canaux gratuits déjà publiés |
| M3 freemium | ❌ | forkable + trahit la promesse |
| M4 packs premium | 🕐 12-18 mois | actif inforkable, droits amont à régler d'abord |
| M5 abonnement | ❌ v1 | rien à abonner ; casse « sans compte » |
| M6 B2B clubs | ✅ | budget réel, produit intact |
| M7 sponsoring | 🕐 | après audience, site seulement |
| M8 publicité | ❌ définitif | l'app la refuse par construction |
| M9 open core | ❌ (CLA = option) | promesse publiée + double charge |
| M10 crowdfunding | 🕐 | après traction, par jalon |

## 4. Recommandation (agent)

**M1 maintenant + M6 comme seul axe de revenu à construire + M4 en option à
12-18 mois** (conditionnée à : droits Kodokan/fédéraux clarifiés PAR ÉCRIT et
demande prouvée). La valeur défendable de Movenso n'est ni le code (GPLv3,
forkable) ni l'hébergement (inexistant) : c'est le CONTENU éditorial (protégé
par le NC) et la RELATION avec les clubs (servie par le pack de club). Tout
est déjà en place, sans toucher au produit.

**Contrariant sur cette recommandation** : « gratuit + B2B plus tard »
ressemble à « pas de modèle du tout ». Si l'objectif réel devient de VIVRE de
Movenso, il faudrait lancer payant dès le début — passer de gratuit à payant
est bien plus dur que l'inverse, et chaque mois de gratuité installe
l'attente du gratuit. Tant que l'objectif déclaré (D-211) reste
communautaire, M1+M6 est cohérent ; si l'objectif change, le dire AVANT la
v1, pas après.

## 5. Décisions que cette étude appelle (si le porteur arbitre)

1. Acter le cap (communautaire vs revenu) — détermine tout le reste.
2. M1 : ajouter (ou non) un lien de soutien sur le site.
3. M6 : formaliser (ou non) une offre « pack de club » sur la page Contribuer.
4. M4 : instruire la question des droits Kodokan/fédéraux avant toute vente.
5. CLA : décider si l'option open core doit rester ouverte.
