# MASTER — Boucle autonome contrôlée

## 1. Mission

Exécuter séquentiellement les lots de `docs/execution/lots/`.

Le but n’est pas de produire beaucoup de code, mais de fermer des comportements complets, démontrés, documentés et non régressifs.

Chaque lot est un contrat. Aucun lot n’autorise une refonte générale.

## 2. Sources de vérité

Ordre de lecture :

1. `CLAUDE.md`
2. `MASTER.md`
3. `STATE.md`
4. `DECISIONS.md`
5. lot courant
6. `QUALITY.md`
7. code et documentation existants

En cas de contradiction nécessitant un nouvel arbitrage produit, arrêter et demander une décision humaine.

## 3. Définition d’une boucle courte

Une boucle traite un seul comportement formulable en une phrase.

Exemples valides :

- Une ancienne route Accueil redirige vers Bibliothèque.
- Le retour depuis une fiche restaure les filtres.
- Une technique peut être ajoutée aux Favoris.
- Un média encore référencé ne peut pas être supprimé.
- Un `.movpack` corrompu est refusé sans mutation.

Exemples trop larges :

- Refaire la Bibliothèque.
- Terminer les médias.
- Moderniser l’Atelier.

Scinder toute boucle qui mélange plusieurs workflows indépendants.

## 4. Cycle obligatoire d’une boucle

### A — Relecture

Relire le lot, l’état courant, les décisions et les invariants voisins.

### B — Observation

Avant d’écrire :

- suivre le workflow réel ;
- identifier composants, services, routes, stockage et tests ;
- identifier les données persistantes touchées ;
- relever les capacités à préserver ;
- vérifier les régressions plausibles.

### C — Plan minimal

Écrire dans `STATE.md` :

- objectif unique ;
- fichiers probablement concernés ;
- preuve attendue ;
- risque principal ;
- éléments explicitement non touchés.

### D — Recette

Créer ou compléter une fiche `REC-*` dans `QUALITY.md`.

### E — Implémentation

Appliquer le plus petit changement cohérent.

Règles :

- conserver les données ;
- réutiliser les services existants ;
- ne pas modifier un format persistant sans migration ;
- ne pas masquer une erreur ;
- ne pas détendre un test pour accepter un mauvais comportement ;
- ne pas refactorer une zone voisine par opportunisme ;
- ne pas anticiper une boucle future.

### F — Vérification ciblée

Exécuter les tests unitaires, d’intégration, E2E et le typecheck pertinents.

### G — Non-régression voisine

Vérifier les invariants susceptibles d’être affectés : navigation, médias, sécurité, compositions, import/export ou restauration selon le cas.

### H — Qualité

Mettre à jour recette, invariant et matrice. Ne jamais confondre navigateur, émulateur et Android réel.

### I — Auto-revue

Vérifier le périmètre, les données, les migrations, les erreurs, la preuve, la documentation et l’absence de secret ou identifiant interne exposé.

### J — Commit et mémoire

Créer un commit local vert, puis mettre à jour `STATE.md` avec le résultat et la prochaine boucle exacte.

## 5. Cadence de tests

À chaque boucle : test ciblé et invariants voisins.

Toutes les 3 à 5 boucles : vérification élargie du lot.

À la fin d’un lot :

- `npm run verifier` ;
- build web ;
- build Android lorsque le lot touche Android, médias, stockage, navigation embarquée ou sécurité ;
- scénarios d’acceptation ;
- checkpoint de lot.

Créer `verify:fast` si cela élimine une friction répétitive sans affaiblir les contrôles.

## 6. Recette et non-régression

Toute capacité importante possède :

- une recette humaine ;
- un test automatique lorsque pertinent ;
- un invariant durable lorsque sa casse future serait coûteuse.

Priorités : conservation des données, retour, doublons, médias partagés, import sans mutation, sauvegarde/restauration, contenus personnels, protections, formats et références de compositions.

## 7. Réduction des frictions

Créer de l’outillage local déterministe lorsqu’il supprime une manipulation répétitive, évite une erreur, rend une preuve reproductible ou accélère plusieurs boucles.

Exemples : fixtures, reset contrôlé, inspecteur `.movpack`, hashes, corpus de test, nettoyage des temporaires, build APK, helpers E2E.

Tout outil doit être local, documenté, sans secret, non destructif par défaut et idempotent lorsque possible.

Ne pas changer de framework ni de dépendance centrale pour le confort de l’agent.

## 8. Tests instables

Ne jamais relancer jusqu’à obtenir du vert, supprimer ou ignorer silencieusement un test instable.

Reproduire, identifier la cause, corriger, documenter et vérifier plusieurs exécutions.

## 9. Autonomie autorisée

Claude peut décider seul de petites structures internes, tests, fixtures, outils locaux, ordre des critères et correction minimale d’une régression directement causée par la boucle.

Claude ne peut pas décider seul d’une nouvelle fonction, entité métier, migration destructive, fusion ambiguë, plateforme, service distant, stratégie de sécurité, rupture de format public ou remplacement technologique central.

## 10. Conditions d’arrêt humain

Arrêter en cas de :

- risque de perte ou corruption ;
- migration irréversible ;
- contradiction produit ;
- suppression de capacité nécessaire ;
- fusion ambiguë ;
- format public à casser ;
- changement de plateforme ;
- secret détecté ;
- état Git inattendu ;
- P0/P1 sans correction locale évidente ;
- restauration impossible à prouver ;
- correction couvrant plusieurs lots ;
- ressource externe indispensable mais indisponible.

Avant l’arrêt, préserver le dernier état vert, mettre à jour `STATE.md`, décrire les options et recommander une décision.

## 11. Git

Jamais sur `main`, aucune fusion, aucun force-push, aucune réécriture, aucune suppression de branche, aucune modification de V2, aucun secret.

Un commit vert par boucle et un checkpoint par lot.

## 12. Fin d’un lot

Un lot est `ACCEPTABLE` si ses critères sont traités, aucun P0/P1 lié n’est ouvert, ses workflows sont complets, les migrations sont prouvées, `npm run verifier` est vert, les builds requis existent et Git est propre.

Un lot avec réserve ne peut être poursuivi automatiquement si la réserve touche les données, la sécurité, la restauration, un workflow essentiel ou une compatibilité annoncée.

## 13. Sous-lots imposés

Lot 8 :

- 8A — Registre et cycle de vie des médias
- 8B — `.movpack`, manifeste et intégrité
- 8C — Transactions, sauvegarde et restauration
- 8D — Android et matrice des plateformes

Lot 10 :

- 10A — Audit sans correction fonctionnelle
- 10B — Corrections P0/P1
- 10C — Recette finale depuis un environnement propre

Pendant 10A, ne corriger aucune fonctionnalité.

## 14. Reprise

Après interruption ou compactage : relire les fichiers, vérifier Git, exécuter la vérification rapide et reprendre uniquement la boucle indiquée dans `STATE.md`.
