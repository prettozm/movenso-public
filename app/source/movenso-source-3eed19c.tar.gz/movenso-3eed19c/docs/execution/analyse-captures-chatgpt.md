# Analyse ChatGPT des 52 captures — note de travail (temporaire)

> **Statut : document de travail transitoire.** Sert de fil pour la passe de
> **finition beta**, balayée **point par point** (challenger → décider →
> traiter ou clore). À supprimer une fois la passe close et les décisions
> retenues consignées dans `DECISIONS.md`.
>
> **Avancement du balayage :**
> - **Vue 1 — Bibliothèque, densité et filtres → TRAITÉ (D-090).** Densité en
>   curseur dans Apparence (« Auto » par défaut, 1..6, cap 6) ; cœur-filtre
>   retiré de la barre de recherche ; fondu de bord sur les rangées de filtres
>   qui débordent ; FAB « + » inchangé (décision humaine).
> - **Vue 2 — Favoris → CLOS (arbitrage humain, 2026-07-18).** « On ne fait
>   rien » : le cœur-filtre de la barre est déjà retiré (D-090) et les favoris
>   ont leur onglet ; pas d'autre changement.
> - **Vue 3 — Fiche en consultation (rectangle média) → CLOS (arbitrage humain,
>   2026-07-18).** « On laisse tel quel, c'est léger et contrôlé par le nom
>   renseigné. » Le fond sombre du lecteur n'est PAS une contrainte YouTube
>   (seule la lecture via l'embed officiel l'est) : c'est notre façade opt-in
>   (contrat §8, aucune requête réseau avant le tap ▶). On garde ainsi ; l'idée
>   « poster = couverture D-083, fallback miniature YT » est notée mais non
>   retenue pour la beta.
> - **Vue 4 — Modification d'une technique → TRAITÉ (D-091, maquette SVG
>   validée).** Refonte de la zone médias en édition : un **bloc par média**
>   (titre → vidéo → « vidéo principale » badge/bouton + 🗑 Retirer),
>   « Ajouter un média » remonté en tête, Vignette déplacée après les médias.
>   Fin des deux rangées de puces jumelles et du bouton « aperçu principal »
>   redondant. Retrait d'un média = nouvelle méthode `retirerMedia` (snapshot +
>   fichier laissé orphelin, jamais détruit). Consultation inchangée. Écartés
>   comme non pertinents : « alerte modifs non enregistrées » (auto-save) et
>   « sections repliables » (formulaire volontairement plat, D-069).
> - **Vue 5 — Partage d'une technique → TRAITÉ (D-092).** Une **feuille de
>   pré-partage** s'intercale **seulement s'il y a un choix** (vidéo locale
>   présente) : reçu (« 1 technique · N liens · M vidéos locales (~taille) ·
>   sans notes privées ») + interrupteur « Inclure les vidéos locales ». Sans
>   vidéo locale → partage direct, un tap (inchangé). Rappel : le carnet/les
>   favoris sont exclus par construction (D-067). **⚠ Suite à traiter :**
>   partager sa PROPRE vidéo filmée (capture perso → sensei) est aujourd'hui
>   impossible (exclusion `personnel`) — tension notée dans
>   `note-modele-donnees.md` §7bis (piste : opt-in explicite décoché par défaut).
> - **Vue 6 — Point d'entrée « Ajouter » → CLOS (arbitrage humain, 2026-07-18).**
>   « On ne touche à rien. » Le libellé « Capture rapide » est jugé assez clair
>   (sous-texte « filmer / choisir une vidéo / lier » + emoji 🎥 vidéo).
> - **Vue 7 — Création rapide → CLOS (2026-07-18).** L'amélioration de fond
>   (doublons détectés avant validation : « Utiliser « X » » + « Créer quand
>   même ») est **déjà en place** ; « créer une variante » = concept variantes
>   reporté ; exemple d'appellation écarté (rejudoïserait un champ neutre).
> - **Vue 8 — Vignette/vidéo locale/lien → CLOS (2026-07-18).** Les conséquences
>   sont **déjà affichées** sous chaque option (« caméra, hors ligne » /
>   « stockée hors ligne » / « lecture en ligne »).
> - **Vue 9 — Fiche quasi vide → CLOS (2026-07-18).** Le travail progressif est
>   un parti pris assumé (D-009/D-019) ; l'incomplet se traque déjà via « À
>   compléter » (Plus › Techniques). Pas de badge « nag » sur la fiche. → À
>   **expliquer dans la doc utilisateur** : voir `notes-doc-utilisateur.md`.
> - **Vue 10 — Compositions liste/création → CLOS (2026-07-18).** Les exemples
>   sont **déjà donnés** (placeholder « Ma spéciale, Kata libre, Séance… », état
>   vide, devise). Idée des **modèles cliquables** (pré-remplir des blocs) notée
>   au backlog `note-modele-donnees.md` §7bis — hors périmètre beta.
> - **Vue 11 — Éditeur de composition → CLOS (2026-07-18).** Suppression globale
>   déjà en bas + PIN + confirmation ; frictions restantes (petit ✕ par bloc,
>   haptique au glisser) mineures ou contre la simplicité.
> - **Vue 12 — Lecture de composition → TRAITÉ (D-093).** Le **mode pas-à-pas
>   existait mais était débranché** (`demarrerEntrainement` jamais appelé) →
>   bouton **▶ « Passer en revue »** réactivé dans la barre (lecture, si blocs).
>   Enrichissements (minuterie, wake lock, paysage, PIN) notés au backlog
>   `notes-doc-utilisateur.md`.
> - **Vue 13 — Écran Plus (libellés) → TRAITÉ (D-094).** « Discipline » → « Disciplines et classement », « Techniques » → « Gestion des techniques », « Médias » → « Médias et intégrité ».
> - **Vue 14 — Disciplines/catégories/niveaux → CLOS (2026-07-18).** L'arbitrage
>   avant suppression d'une taxonomie utilisée (impact + Remplacer/Retirer/Annuler)
>   est déjà en place (`panneauSuppressionTaxonomie`).
> - **Vue 15 — Gestion des techniques/corbeille → CLOS (2026-07-18).** La raison
>   de chaque problème est déjà affichée (étiquettes par ligne) ; la corbeille
>   passe par un confirm ; « actions groupées » → backlog.
> - **Vue 16 — Export d'un pack → TRAITÉ (D-095).** Choix vidéos explicité
>   (« vidéos locales » + les liens toujours inclus) et estimation de taille
>   avant Valider. **Ne résout pas** le partage vidéo perso (même exclusion
>   `personnel` que le partage de fiche).
> - **Vues 17→20 → traitées/closes (D-099).** 17 (vocabulaire : contributions→contenus, snapshot→point de restauration) et 20 (bouton « Créer un lien » dans le graphe vide) traités ; 18 (Sécurité) et 19 (barre Relations) clos sans changement.
> - **Vues 21→24 → CLOSES (2026-07-19).** Déjà couvertes : 21 (exemple concret
>   dans « Comment ça marche ? »), 22 (critères dans l'état vide + fusion
>   sélective), 23 (KPI cliquables/filtrants + puces navigables + origine des
>   fichiers inutilisés expliquée), 24 (diagnostic « sans aucun secret » +
>   réinitialisation avec suggestion de sauvegarde et confirmation forte).
>
> **BALAYAGE TERMINÉ (vues 1 → 24).** 10 corrections codées (D-090→099) ; le
> reste clos (déjà couvert ou parti pris assumé). Backlog consigné dans
> `note-modele-donnees.md` §7bis et `notes-doc-utilisateur.md`. Ce fichier peut
> être supprimé (les décisions vivent dans `DECISIONS.md`) — conservé pour
> l'instant en archive de la passe.
>
> Le texte ci-dessous est l'analyse brute (non éditée), conservée pour référence.

---

## Verdict général

Movenso ne ressemble plus à un simple prototype de bibliothèque. Il constitue
déjà un produit offline structuré, avec plusieurs niveaux d'usage :

- consultation rapide ;
- création et enrichissement personnel ;
- construction de séquences ;
- transport et sauvegarde des données ;
- administration et maintenance avancées.

La base est très saine. Le principal défi n'est plus d'ajouter des fonctions,
mais de rendre visibles les bonnes fonctions au bon moment, sans transformer
l'application en outil d'administration.

## Évaluation globale

| Axe | Appréciation |
|---|---|
| Compréhension immédiate | 8/10 |
| Cohérence globale | 8/10 |
| Friction utilisateur | 7/10 |
| Valeur produit | 9/10 |
| Robustesse visible | 7,5/10 |
| Potentiel de différenciation | 9/10 |

---

## Analyse des vues

### 1. Bibliothèque, densité et filtres — captures 01 à 07

1 — Compréhension immédiate. La fonction principale est évidente : chercher,
filtrer, consulter et ajouter une technique. L'identité de Movenso est
immédiatement perceptible.

2 — Cohérence globale. Recherche, discipline, catégories, cartes et navigation
inférieure forment une hiérarchie logique. Le changement de densité en une,
deux ou trois colonnes est pertinent pour des usages différents.

3 — Friction. Les boutons − et + ne disent pas clairement qu'ils modifient la
densité d'affichage. Les catégories sont horizontalement tronquées sans
indicateur évident de défilement. En mode une colonne, le bouton flottant
masque une partie de la seconde carte.

4 — Valeur produit. Très bonne : cette vue donne immédiatement l'impression
d'une vraie bibliothèque visuelle, rapide à parcourir sur un tatami.

5 — Recette complémentaire. Tester recherche, filtres et densité avec 500
techniques, des noms très longs et plusieurs disciplines.

6 — Workflow observé et amélioration. Ouvrir l'application → rechercher ou
filtrer → adapter la densité → ouvrir une fiche. Nommer ou illustrer
temporairement les commandes de densité, mémoriser le choix de l'utilisateur et
afficher un léger fondu sur le bord droit des filtres pour suggérer le
défilement.

Point particulier. La densité à deux colonnes semble être le meilleur
compromis par défaut. Une colonne convient à la découverte visuelle, trois
colonnes à la recherche rapide, mais réduit fortement la lisibilité des
sous-titres.

### 2. Ajout aux favoris et vue Favoris — captures 04, 05 et 08

1 — Compréhension immédiate. Le cœur est standard et son changement d'état est
clair. Le message de confirmation rassure.

2 — Cohérence globale. Le favori existe à trois endroits : sur les cartes, dans
la recherche de bibliothèque et dans un onglet dédié. Cela reste cohérent, mais
crée une légère redondance.

3 — Friction. Le bouton cœur placé à côté de la recherche ressemble autant à un
filtre qu'à un accès aux favoris, alors qu'un onglet Favoris existe déjà.
L'utilisateur peut se demander quelle différence existe entre les deux.

4 — Valeur produit. Forte pour l'usage quotidien : les favoris deviennent
naturellement la sélection personnelle de travail.

5 — Recette complémentaire. Vérifier la synchronisation instantanée d'un favori
entre carte, fiche, filtre, onglet et composition.

6 — Workflow observé et amélioration. Marquer une technique → retrouver la
sélection dans Favoris → réutiliser ces techniques dans une composition. Soit
supprimer le cœur-filtre de la bibliothèque, soit le représenter comme un
véritable filtre activable avec un état clairement visible.

### 3. Fiche technique en consultation — capture 09

1 — Compréhension immédiate. Excellente. Catégorie, titre, nom traditionnel,
média, description, points clés et note personnelle sont présentés dans le bon
ordre.

2 — Cohérence globale. La fiche prolonge parfaitement le langage visuel de la
bibliothèque. Les actions modifier, favorite, partager et fermer sont
correctement regroupées.

3 — Friction. Le grand rectangle noir du média paraît vide avant lecture et ne
montre ni vignette, ni durée, ni origine claire. Le champ commentaire semble
directement éditable dans une vue de consultation, sans indication
d'enregistrement automatique.

4 — Valeur produit. C'est l'un des écrans les plus convaincants. Il répond
précisément au besoin « retrouver rapidement le geste, les repères et ma propre
note ».

5 — Recette complémentaire. Tester une fiche sans média, avec plusieurs médias,
une longue description et une note personnelle très longue.

6 — Workflow observé et amélioration. Ouvrir une technique → regarder la
démonstration → lire les repères → ajouter une note privée. Ajouter une
miniature au lecteur, un badge En ligne ou Local, et une indication discrète
Note privée — enregistrée automatiquement.

### 4. Modification d'une technique — captures 10 et 11

1 — Compréhension immédiate. Les champs sont explicites et la validation par
coche se comprend. La séparation titre, classement, vignette, médias et contenu
est logique.

2 — Cohérence globale. Les valeurs éditées correspondent exactement à ce qui
sera présenté sur la fiche, ce qui évite un modèle mental différent entre
consultation et édition.

3 — Friction. La page devient longue et dense. Les blocs vidéo noirs occupent
beaucoup d'espace. La miniature associée à un média possède un libellé tronqué.
La distinction entre « vignette de la fiche » et « miniature de la vidéo »
mérite d'être renforcée.

4 — Valeur produit. Élevée : Movenso permet réellement de curer une
bibliothèque, pas seulement de stocker un nom et une vidéo.

5 — Recette complémentaire. Modifier tous les champs, fermer sans valider,
revenir en arrière puis redémarrer l'application pour vérifier la persistance.

6 — Workflow observé et amélioration. Fiche → modifier → classer → définir une
vignette → gérer les médias → enrichir le contenu → enregistrer. Ajouter des
sections repliables, conserver une validation fixe en haut et signaler les
modifications non enregistrées avant la fermeture.

### 5. Partage d'une technique — capture 12

1 — Compréhension immédiate. Le bouton de partage produit bien la feuille de
partage Android attendue.

2 — Cohérence globale. Le partage est accessible depuis la fiche, ce qui est
l'endroit naturel.

3 — Friction. La capture ne montre pas ce qui est réellement partagé : fiche
structurée, fichier .movpack, texte, lien ou média. L'utilisateur doit le
découvrir après déclenchement.

4 — Valeur produit. Très forte si le destinataire peut ouvrir directement la
technique dans Movenso tout en conservant ses médias et métadonnées.

5 — Recette complémentaire. Partager vers Gmail, Drive, WhatsApp et un second
téléphone puis importer réellement le résultat.

6 — Workflow observé et amélioration. Ouvrir une fiche → partager → choisir une
application Android → transmettre. Afficher avant la feuille Android une courte
confirmation du contenu partagé : 1 technique, 1 lien vidéo, sans notes privées.

### 6. Point d'entrée « Ajouter » — capture 13

1 — Compréhension immédiate. Le choix entre créer une technique et effectuer
une capture rapide est très pertinent.

2 — Cohérence globale. Il sépare correctement le travail structuré du besoin
immédiat sur le tatami.

3 — Friction. « Capture rapide » peut encore être compris comme une simple
photo, alors que le texte parle de filmer ou choisir une vidéo.

4 — Valeur produit. Excellente : cette séparation matérialise deux usages
réels, « je prépare ma bibliothèque » et « je capture maintenant, je classerai
plus tard ».

5 — Recette complémentaire. Tester une capture rapide interrompue, sans
autorisation caméra et avec une vidéo déjà existante.

6 — Workflow observé et amélioration. Ajouter → créer proprement maintenant ou
capturer rapidement et classer plus tard. Renommer éventuellement la seconde
action Capturer une vidéo rapidement et montrer qu'elle alimentera une file « à
classer ».

### 7. Création rapide d'une technique — captures 14 à 16

1 — Compréhension immédiate. La création minimale par nom est très bonne. Le
classement immédiat reste facultatif, ce qui évite de bloquer l'utilisateur.

2 — Cohérence globale. Le formulaire reprend discipline et catégorie déjà
utilisées ailleurs. Le message après création conduit naturellement vers
l'enrichissement.

3 — Friction. Le rôle du sous-titre ou de « l'appellation traditionnelle »
pourrait bénéficier d'un exemple. Le bouton Créer la technique est proche du
clavier, mais le parcours demeure fluide.

4 — Valeur produit. Très forte : une technique peut exister en quelques
secondes puis être enrichie progressivement.

5 — Recette complémentaire. Créer deux techniques portant le même nom, avec
accents, tirets, japonais et différentes disciplines.

6 — Workflow observé et amélioration. Ajouter → saisir le nom → classer
maintenant ou plus tard → créer → compléter la fiche. Détecter les doublons
avant validation et proposer Ouvrir l'existante, Créer une variante ou
Continuer malgré tout.

### 8. Vignette, vidéo locale et lien — captures 17 à 19

1 — Compréhension immédiate. La distinction est bonne : la vignette utilise le
sélecteur photo, tandis qu'un média peut être filmé, choisi sur l'appareil ou
ajouté par lien.

2 — Cohérence globale. L'intégration aux interfaces Android est naturelle et
respecte les permissions limitées aux fichiers choisis.

3 — Friction. Le panneau média mélange capture immédiate, fichier local et
média distant sans présenter leurs conséquences : taille, fonctionnement hors
ligne, exportabilité ou disponibilité future.

4 — Valeur produit. Centrale. C'est ce qui fait de Movenso une mémoire
personnelle réellement exploitable hors ligne.

5 — Recette complémentaire. Tester vidéo très lourde, rotation portrait, lien
invalide, lien supprimé, permission refusée et fichier déplacé.

6 — Workflow observé et amélioration. Éditer une technique → choisir la source
du média → importer ou coller un lien → vérifier la lecture. Ajouter sous
chaque option une conséquence courte : Disponible hors ligne, Copié dans
Movenso, Nécessite Internet.

### 9. Recherche de la nouvelle technique — captures 20 et 21

1 — Compréhension immédiate. La technique créée est immédiatement retrouvable
et sa fiche reste utilisable même avec très peu de contenu.

2 — Cohérence globale. Le cycle création → bibliothèque → fiche est
correctement fermé.

3 — Friction. Une fiche quasi vide ressemble visuellement à une fiche terminée.
Le manque d'informations ou de média n'est pas particulièrement signalé.

4 — Valeur produit. Bonne : Movenso accepte le travail progressif sans obliger
l'utilisateur à tout documenter immédiatement.

5 — Recette complémentaire. Redémarrer l'application après la création puis
rechercher la technique par titre, sous-titre et catégorie.

6 — Workflow observé et amélioration. Créer → retrouver → ouvrir → enrichir
plus tard. Ajouter un badge discret À compléter et un accès direct Continuer la
fiche sur les techniques incomplètes.

### 10. Liste et création de compositions — captures 22 et 23

1 — Compréhension immédiate. Le texte explique bien que les compositions
servent à créer des enchaînements, programmes ou séances.

2 — Cohérence globale. La composition est clairement séparée de la
bibliothèque : les techniques restent la source, les compositions les
assemblent.

3 — Friction. Le premier écran est très vide. La création commence par un
simple champ et un bouton, sans exemples de formats possibles.

4 — Valeur produit. Très élevée. C'est probablement la fonction qui différencie
le plus Movenso d'une simple encyclopédie vidéo.

5 — Recette complémentaire. Créer dix compositions, rechercher un nom existant,
dupliquer une composition et vérifier l'ordre de la liste.

6 — Workflow observé et amélioration. Ouvrir Compositions → nommer le projet →
définir son objectif → assembler des techniques et consignes. Proposer au
premier usage trois exemples non contraignants : Enchaînement, Passage de
grade, Séance.

### 11. Éditeur de composition — captures 23 et 24

1 — Compréhension immédiate. Les trois composants sont bien identifiés :
technique, texte libre et média de présentation.

2 — Cohérence globale. Les favoris servent intelligemment de raccourcis. Les
étapes peuvent contenir des transitions, pauses et consignes.

3 — Friction. La suppression complète de la composition est très visible dans
l'écran d'édition. Les suggestions de techniques et le clavier occupent
rapidement tout l'écran. Les petits boutons de suppression de chaque étape
peuvent être touchés involontairement.

4 — Valeur produit. Excellente : le modèle est suffisamment générique pour un
kata, une démonstration, un programme pédagogique ou une séance.

5 — Recette complémentaire. Créer une composition de 30 étapes, réordonner
chaque type de bloc et vérifier le comportement après rotation ou fermeture
brutale.

6 — Workflow observé et amélioration. Ajouter une technique ou un texte →
réordonner → compléter par une présentation → enregistrer ou partager. Déplacer
la suppression globale dans un menu secondaire, proposer une recherche plein
écran et permettre le glisser-déposer avec retour haptique.

### 12. Lecture d'une composition — capture 25

1 — Compréhension immédiate. La séquence numérotée est immédiatement lisible.
Les techniques sont visuelles et les blocs texte se différencient correctement.

2 — Cohérence globale. La composition restitue fidèlement la structure
construite dans l'éditeur.

3 — Friction. Il manque un véritable usage « en situation ». La vue est encore
une fiche verticale classique alors qu'une séance ou une démonstration appelle
souvent un mode plein écran.

4 — Valeur produit. Potentiellement majeure, mais la valeur maximale dépendra
du mode d'exécution de la séquence.

5 — Recette complémentaire. Ouvrir chaque technique depuis la composition puis
revenir en conservant exactement la position et l'étape courante.

6 — Workflow observé et amélioration. Ouvrir la composition → suivre les étapes
→ consulter une technique → reprendre la séquence. Ajouter un Mode séance avec
étapes plein écran, navigation précédent/suivant, minuterie facultative et
verrouillage de l'écran.

### 13. Écran Plus — captures 26, 46, 48 et 49

1 — Compréhension immédiate. Les groupes « Ma bibliothèque », « Importer,
exporter et sauvegarder » et « Préférences » sont bien structurés.

2 — Cohérence globale. Les outils avancés apparaissent lorsque le mode avancé
est activé, ce qui évite de surcharger l'utilisateur standard.

3 — Friction. Plus devient progressivement un centre d'administration très
riche. Certains intitulés sont trop génériques : Discipline, Techniques,
Médias. Les utilisateurs doivent parfois entrer dans l'écran pour comprendre sa
finalité exacte.

4 — Valeur produit. Très forte pour l'autonomie et la pérennité des données.

5 — Recette complémentaire. Tester l'écran avec une bibliothèque vide, cinq
disciplines et tous les modules avancés activés.

6 — Workflow observé et amélioration. Plus → administrer la bibliothèque,
transporter les données, régler l'application ou diagnostiquer. Renommer
certains éléments en Disciplines et classement, Gestion des techniques,
Intégrité des médias et conserver les outils rares derrière le mode avancé.

### 14. Disciplines, catégories et niveaux — captures 27 à 30

1 — Compréhension immédiate. L'organisation discipline → catégories → niveaux
est intelligible. Les poignées de réorganisation et boutons d'ajout sont
cohérents.

2 — Cohérence globale. Le classement configuré ici nourrit directement les
filtres et les formulaires de création.

3 — Friction. Les croix de suppression sont petites et proches de chaque ligne.
L'ajout de niveau montre plusieurs carrés colorés dont la fonction n'est pas
explicitée. Aucun niveau — touche + est discret.

4 — Valeur produit. Très élevée pour rendre Movenso multi-disciplines sans
imposer une taxonomie universelle.

5 — Recette complémentaire. Supprimer, renommer et réordonner une catégorie
déjà utilisée par plusieurs techniques et compositions.

6 — Workflow observé et amélioration. Choisir une discipline → personnaliser
catégories et niveaux → utiliser ce classement dans la bibliothèque. Avant
suppression, présenter l'impact exact et proposer Réaffecter les techniques,
Conserver sans catégorie ou Annuler.

### 15. Gestion des techniques et corbeille — captures 31 à 33

1 — Compréhension immédiate. La liste compacte est adaptée à l'administration.
Les filtres Toutes, À compléter et Problèmes sont pertinents.

2 — Cohérence globale. La suppression vers une corbeille restaurable limite les
risques et respecte une logique familière.

3 — Friction. Les icônes de corbeille sur chaque ligne facilitent aussi la
suppression accidentelle. La définition exacte de Problèmes n'est pas visible.
Il manque des actions groupées.

4 — Valeur produit. Forte, en particulier lorsqu'une bibliothèque contient
plusieurs centaines de fiches.

5 — Recette complémentaire. Restaurer une technique et vérifier ses notes,
favoris, médias, relations et références dans les compositions.

6 — Workflow observé et amélioration. Filtrer les fiches → identifier celles à
compléter ou problématiques → supprimer → restaurer ou vider. Ouvrir une fiche
par pression simple, réserver la suppression au glissement ou à une sélection
multiple, et afficher la raison de chaque problème.

### 16. Export d'un pack — captures 34 à 36

1 — Compréhension immédiate. La phrase « produire un fichier à partager — pas
une sauvegarde » est excellente. L'exclusion du carnet, des favoris et des
captures personnelles est clairement annoncée.

2 — Cohérence globale. Discipline, contenu, vidéos, auteur et note de diffusion
correspondent bien au concept de pack transmissible.

3 — Friction. Avec vidéos reste ambigu : vidéos locales seulement, liens en
ligne, miniatures ou ensemble des médias ? Aucune estimation de taille n'est
affichée. La sélection manuelle de 111 techniques manque de recherche et de
sélection par catégorie.

4 — Valeur produit. Très forte : c'est la base du partage de packs officiels,
clubs ou enseignants.

5 — Recette complémentaire. Exporter le pack, inspecter son contenu, l'importer
sur un appareil vierge et comparer chaque fiche et média.

6 — Workflow observé et amélioration. Choisir une discipline → choisir tout ou
certaines techniques → inclure ou non les médias → renseigner l'auteur →
exporter. Remplacer Avec vidéos par Inclure les vidéos locales, préciser que
les liens restent inclus, afficher la taille estimée et proposer Ouvrir le
dossier après export.

### 17. Sauvegardes et snapshots — captures 37 à 40

1 — Compréhension immédiate. La différence entre sauvegarde complète,
sauvegarde légère et état automatique est bien expliquée.

2 — Cohérence globale. L'écran distingue correctement le partage de contenu du
rétablissement fidèle d'une installation.

3 — Friction. Le vocabulaire devient technique : sauvegarde complète, sauvegarde
partielle, sauvegarde légère, snapshot, installation et contribution. Un
utilisateur non technique peut hésiter malgré les explications.

4 — Valeur produit. Exceptionnelle pour une application sans compte ni serveur.
Cette autonomie est un vrai argument produit.

5 — Recette complémentaire. Restaurer une sauvegarde complète sur un appareil
vierge et contrôler données, médias, favoris, compositions et protections.

6 — Workflow observé et amélioration. Créer une sauvegarde → conserver le
fichier ailleurs → restaurer au besoin ou revenir à un état automatique récent.
Normaliser les termes autour de Sauvegarde complète, Sauvegarde sans vidéos et
Point de restauration automatique, puis ajouter un contrôle d'intégrité avant
restauration.

Anomalie de vocabulaire. 111 contributions est difficile à interpréter. Une
formulation telle que 111 fiches de référence ou 111 contenus techniques serait
plus parlante.

### 18. Sécurité locale — capture 41

1 — Compréhension immédiate. L'absence de compte et de serveur est clairement
rappelée. La protection distincte des modifications et des actions sensibles est
pertinente.

2 — Cohérence globale. Le préréglage « tablette partagée » correspond à un cas
d'usage réel pour un club ou un dojo.

3 — Friction. Les boutons Protéger… ne révèlent pas immédiatement ce qui sera
demandé ni la durée du déverrouillage. L'état global de sécurité pourrait être
plus synthétique.

4 — Valeur produit. Forte pour les enseignants, clubs et appareils partagés,
secondaire pour un usage strictement personnel.

5 — Recette complémentaire. Tester PIN erroné, redémarrage, retour arrière,
expiration de session, suppression sensible et oubli du code.

6 — Workflow observé et amélioration. Choisir les actions protégées → définir un
PIN local → utiliser normalement → déverrouiller à la demande. Afficher un
résumé Appareil personnel — aucune protection ou Tablette partagée —
modifications et suppressions protégées, avec durée de session configurable.

### 19. Apparence et comportement au démarrage — captures 42, 43 et 47

1 — Compréhension immédiate. Thème, tonalité, pseudonyme, fonctions avancées et
écran de démarrage sont clairement séparés.

2 — Cohérence globale. La personnalisation reste fonctionnelle, sans basculer
dans une surenchère décorative.

3 — Friction. L'activation de Relations fait apparaître un nouvel onglet et
déplace les autres onglets. La mémoire musculaire de navigation change selon le
réglage. Mode avancé et Vue relation se recouvrent partiellement dans leurs
descriptions.

4 — Valeur produit. Bonne : l'utilisateur peut adapter l'outil à son usage
personnel, enseignant ou curateur.

5 — Recette complémentaire. Basculer tous les thèmes et tonalités en mode clair
et sombre, puis vérifier contrastes, icônes et états désactivés.

6 — Workflow observé et amélioration. Personnaliser l'apparence → signer ses
modifications → activer les outils experts → choisir l'écran de départ. Garder
une navigation inférieure stable : intégrer Relations dans Plus tant que la
fonction est bêta, ou réserver dès le départ un cinquième emplacement fixe.

### 20. Vue Relations — capture 44

1 — Compréhension immédiate. La technique centrale est bien identifiée et la
recherche permet d'en choisir une autre.

2 — Cohérence globale. La vue graphique complète logiquement les compositions :
l'une ordonne une séquence, l'autre décrit les liens possibles entre techniques.

3 — Friction. L'état vide demande d'aller dans Plus > Relations entre techniques
pour ajouter un lien. La consultation et l'édition sont séparées de façon
excessive.

4 — Valeur produit. Potentiellement très forte pour les enchaînements, contres,
préparations et variantes, mais elle dépend d'une saisie réellement simple.

5 — Recette complémentaire. Créer vingt relations autour d'une technique et
vérifier lisibilité, navigation circulaire et absence de doublons.

6 — Workflow observé et amélioration. Choisir une technique centrale → explorer
ses liens → ouvrir une technique liée. Ajouter directement un bouton Créer un
lien dans l'état vide et une action Relier cette technique depuis chaque fiche.

### 21. Types de relations — capture 45

1 — Compréhension immédiate. Les couples directs et inverses sont
conceptuellement justes : prépare/préparé par, enchaîne depuis/vers,
contre/contré par.

2 — Cohérence globale. La modélisation bidirectionnelle évite d'enregistrer
manuellement les deux sens d'une relation.

3 — Friction. L'écran est abstrait sans exemple concret. Les crayons et croix
sont petits. Les notions de lecture directe et inverse peuvent être difficiles
pour un utilisateur non technique.

4 — Valeur produit. Très élevée pour créer une ontologie personnalisable,
notamment entre disciplines différentes.

5 — Recette complémentaire. Renommer une relation déjà utilisée et vérifier
toutes ses lectures directes, inverses et exportations.

6 — Workflow observé et amélioration. Définir un type et son inverse →
l'utiliser pour relier des techniques → explorer les liens dans les deux sens.
Montrer un exemple en temps réel : O-uchi-gari prépare Uchi-mata / Uchi-mata est
préparé par O-uchi-gari.

### 22. Doublons potentiels — capture 50

1 — Compréhension immédiate. L'état vide explique clairement le rôle de l'outil.

2 — Cohérence globale. Le module appartient correctement au mode avancé et à la
maintenance de bibliothèque.

3 — Friction. La capture ne montre pas les critères utilisés ni les options
lorsqu'un doublon est détecté.

4 — Valeur produit. Forte pour les imports répétés de packs et les bibliothèques
multi-sources.

5 — Recette complémentaire. Importer deux variantes d'un même pack et vérifier
les cas même identifiant, même nom et contenus divergents.

6 — Workflow observé et amélioration. Scanner la bibliothèque → examiner les
rapprochements → conserver, fusionner ou ignorer. Pour chaque candidat,
expliquer la raison du rapprochement et permettre de choisir précisément les
champs à fusionner.

### 23. Médiathèque et intégrité des médias — capture 51

1 — Compréhension immédiate. La distinction vidéos locales, médias en ligne,
techniques sans vidéo et problèmes à traiter est excellente.

2 — Cohérence globale. Cet écran donne une vue transversale complémentaire aux
fiches individuelles.

3 — Friction. Les chiffres sont cliquables en apparence, mais l'action
disponible n'est pas démontrée. Fichiers inutilisés peut inquiéter sans
explication de leur provenance.

4 — Valeur produit. Très forte : c'est essentiel dans une application vidéo
offline où les fichiers peuvent devenir lourds ou orphelins.

5 — Recette complémentaire. Supprimer ou déplacer physiquement une vidéo, créer
un fichier orphelin puis lancer la détection et la réparation.

6 — Workflow observé et amélioration. Contrôler l'état des médias → ouvrir une
anomalie → rattacher, remplacer ou supprimer. Rendre chaque compteur navigable
et proposer une correction guidée plutôt qu'un simple constat.

### 24. Diagnostic, export technique et réinitialisation — capture 52

1 — Compréhension immédiate. Les deux usages sont bien séparés : diagnostiquer
ou remettre l'application à zéro.

2 — Cohérence globale. Le diagnostic appartient logiquement au mode avancé. La
réinitialisation est isolée dans une zone dangereuse.

3 — Friction. Exporter le diagnostic ne précise pas les données contenues. La
réinitialisation complète est accessible sur un écran relativement simple, sans
mise en avant d'une sauvegarde préalable.

4 — Valeur produit. Importante pour le support et la résilience, même si elle
concerne rarement l'utilisateur ordinaire.

5 — Recette complémentaire. Exporter un diagnostic, vérifier qu'il ne contient
aucune note personnelle ni média, puis tester une réinitialisation après
sauvegarde.

6 — Workflow observé et amélioration. Constater un problème → exporter un
diagnostic pour analyse ou sauvegarder puis réinitialiser. Expliquer exactement
ce que contient le diagnostic et imposer une confirmation forte avec proposition
de sauvegarde avant toute remise à zéro.

---

## Workflows produit identifiés

- **Workflow 1 — Consultation quotidienne.** Lancer → chercher/filtrer → ouvrir
  une fiche → média → points clés → note. Déjà très solide ; rendre médias et
  notes plus explicites.
- **Workflow 2 — Capture sur le tatami.** Ajouter → filmer/choisir → fiche
  minimale → classer plus tard. Pertinent mais pas entièrement visible ; devrait
  devenir l'un des parcours les plus courts.
- **Workflow 3 — Création structurée.** Ajouter → nommer → classer → vignette +
  médias → repères → enregistrer. Bon modèle progressif ; détecter les doublons
  dès la saisie du nom.
- **Workflow 4 — Préparation personnelle.** Favoris → retrouver sa sélection →
  notes privées → composition. Rendre explicite via « Ajouter à une composition »
  depuis fiche/favoris.
- **Workflow 5 — Construction d'une séquence.** Créer une composition →
  techniques + consignes → réordonner → présentation → consulter/partager. Plus
  fort potentiel différenciant.
- **Workflow 6 — Administration de bibliothèque.** Disciplines/catégories →
  repérer les fiches incomplètes → corriger/supprimer → restaurer. Doit rester
  discret pour l'utilisateur standard.
- **Workflow 7 — Transmission d'un corpus.** Discipline/techniques → pack →
  partager → importer ailleurs. Sécuriser la compréhension du contenu de chaque
  fichier.
- **Workflow 8 — Sauvegarde et restauration.** Sauvegarde complète → stocker
  ailleurs → restaurer / snapshot automatique. Un des points forts.
- **Workflow 9 — Appareil partagé.** Préréglage tablette partagée → protéger les
  modifications → consultation libre. Ouvre une déclinaison club/enseignant.
- **Workflow 10 — Curation avancée.** Mode avancé → doublons/médias/relations →
  diagnostic. Bonne séparation quotidien/maintenance.

---

## Idées d'amélioration prioritaires

### Priorité 1 — Stabiliser et clarifier l'existant

1. **Rendre la navigation inférieure immuable.** L'apparition dynamique de
   l'onglet Relations déplace les autres entrées. Pendant la bêta, Relations peut
   rester dans Plus ou remplacer une entrée fixe choisie par l'utilisateur.
2. **Clarifier la différence entre les types de fichiers.** Vocabulaire uniforme :
   Pack (à partager) ; Sauvegarde complète (restaurable avec médias) ; Sauvegarde
   sans vidéos (données seules) ; Point de restauration (auto local). Éviter
   snapshot, installation, contribution, partielle.
3. **Donner un reçu après chaque opération importante.** Après export, import,
   sauvegarde, restauration ou partage : « 111 techniques · 116 liens · 0 vidéo
   locale · 1 composition — Fichier enregistré dans Téléchargements/Movenso —
   Ouvrir le dossier · Partager · Fermer ».
4. **Sécuriser toutes les suppressions.** Les suppressions de structure doivent
   afficher leur impact : techniques, compositions, relations, médias.
5. **Distinguer clairement les médias.** Mêmes catégories partout : vidéo locale
   (hors ligne) ; lien vidéo (connexion requise) ; vignette ; capture non classée ;
   fichier orphelin.

### Priorité 2 — Renforcer les workflows principaux

6. **Créer un vrai mode séance pour les compositions.** Une étape par écran ;
   précédent/suivant ; minuterie facultative ; média ; ouverture rapide de la
   fiche ; écran éveillé ; paysage ; sortie verrouillable par PIN.
7. **Ajouter « Utiliser cette technique ».** Depuis une fiche : favoris ;
   composition ; relation ; dupliquer comme variante ; partager.
8. **Créer une file « À classer ».** Toute capture rapide y arrive : vignette
   auto, date, durée, nom provisoire, rattachement rapide ou création.
9. **Introduire un état de complétude.** Minimale / à compléter / complète /
   problème détecté, en expliquant ce qui manque.
10. **Améliorer la sélection dans les grands corpus.** Recherche ; sélection par
    catégorie ; tout (dé)sélectionner ; favoris seuls ; complètes seules ;
    compteur permanent.

### Priorité 3 — Construire la différenciation Movenso

11. **Transformer Relations en outil pédagogique.** Vues : préparations,
    enchaînements, contres, similaires, progression ; création depuis la fiche.
12. **Autoriser les variantes personnelles sans dupliquer aveuglément.**
    (Référence / variantes / repère personnel sous une même technique.)
13. **Définir des packs avec provenance.** Auteur, version, date, discipline,
    nombre de fiches, empreinte, conditions, mises à jour.
14. **Créer un tableau de santé de la bibliothèque.** Synthèse : à compléter,
    sans média, médias manquants, doublons, dernière sauvegarde.
15. **Prévoir des actions groupées.** Classer, changer de catégorie, ajouter un
    niveau, ajouter à un pack/composition, supprimer/restaurer, rattacher un
    auteur.

---

## Conclusion

Le plus important est déjà acquis : Movenso possède une logique produit crédible.
Le risque serait de continuer à ajouter des fonctions avant de fermer les
boucles existantes. Les trois chantiers les plus rentables :

1. clarifier médias, packs et sauvegardes ;
2. transformer les compositions en véritable mode séance ;
3. connecter directement fiches, compositions et relations.

Movenso n'a pas besoin d'être réinventé : resserré, fiabilisé, rendu plus
évident dans ses transitions.
