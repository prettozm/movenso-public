# LOT 8 — FORMATS, MÉDIAS, STOCKAGE ET PLATEFORMES : RENDRE LA PORTABILITÉ RÉELLE ET LE BUILD REPRODUCTIBLE

## Contexte

Les lots précédents ont fermé les principaux workflows métier :

- navigation ;
- Bibliothèque ;
- fiche technique ;
- création et capture ;
- Favoris et Compositions ;
- Atelier ;
- protections facultatives.

La V3 possède déjà :

- un stockage local fondé sur OPFS ;
- des données métier sérialisées ;
- des médias locaux ;
- des exports `.movpack` sous forme de conteneur ZIP ;
- un manifeste ;
- une empreinte SHA-256 partielle ;
- un export et une restauration testés ;
- un build web Vite ;
- une cible Android Capacitor ;
- une génération d'APK en CI.

Cependant, plusieurs risques techniques restent ouverts :

- métadonnées média insuffisantes ;
- noms physiques opaques ou sans extension ;
- fichiers potentiellement supprimés alors qu'ils sont encore
  référencés ;
- snapshots ne restaurant pas nécessairement les octets des médias ;
- export ZIP construit entièrement en mémoire ;
- intégrité ne couvrant pas tous les fichiers ;
- import ou restauration non totalement transactionnels ;
- fichiers temporaires ou orphelins possibles après échec ;
- différence insuffisamment claire entre pack publié, sauvegarde et
  snapshot ;
- compatibilité JSON historique contournant le manifeste ;
- projet Android et procédure de release à clarifier ;
- PWA ou Windows parfois évoqués sans cible réellement livrée ;
- absence d'une cartographie simple des emplacements et noms de
  fichiers.

Ce lot est un **lot de durcissement**.

Il ne doit pas ajouter de nouvelle fonction produit.

## Objectif unique

Rendre Movenso techniquement prévisible et portable en garantissant :

1. un registre média sûr ;
2. un stockage physique documenté ;
3. des références multiples sans suppression accidentelle ;
4. un format `.movpack` versionné et vérifiable ;
5. des exports à mémoire bornée ;
6. des imports et restaurations préparés avant mutation ;
7. une sauvegarde complète incluant réellement les médias ;
8. une cible Android reproductible ;
9. un statut honnête des cibles web, PWA, Windows et Electron.

## 1. Source de vérité des données

Établir et conserver une seule source de vérité pour chaque catégorie.

**Données métier :**

- disciplines ;
- identités techniques ;
- contributions ;
- sources et origines ;
- taxonomies ;
- relations ;
- captures à reprendre ;
- favoris ;
- compositions ;
- réglages non secrets.

**Registre média :**

- métadonnées de tous les médias connus ;
- emplacement logique ;
- empreinte ;
- type ;
- état ;
- références.

**Fichiers binaires :**

- vidéos ;
- images ;
- aperçus ou miniatures ;
- éventuels fichiers associés.

Ne pas laisser plusieurs copies indépendantes d'un index média dans
différentes couches.

Le registre média doit être cohérent avec le stockage physique, mais le
fichier physique ne doit pas devenir la seule source de métadonnées.

## 2. Modèle logique d'un média

Chaque média local doit porter au minimum :

- identifiant stable ;
- type fonctionnel : vidéo ; image ; autre fichier supporté ;
- MIME réel ;
- extension canonique ;
- nom original lorsqu'il existe ;
- taille en octets ;
- empreinte SHA-256 ;
- date d'ajout ;
- origine : caméra ; fichier local ; import ; génération interne ;
- service externe lorsque pertinent ;
- référence externe originale lorsqu'il s'agit d'un lien ;
- libellé facultatif ;
- état : disponible ; manquant ; temporaire ; à vérifier ;
- éventuelles dimensions ou durée si elles sont déjà accessibles sans
  coût excessif.

Ne pas rendre obligatoires des métadonnées impossibles à obtenir de
manière fiable.

Ne pas stocker une vidéo distante comme fichier local si elle n'a pas été
réellement téléchargée.

Un média externe conserve : URL originale ; service détecté ; identifiant
distant éventuel ; aucune fausse taille locale.

## 3. Registre central des médias

Introduire ou consolider un registre central des médias.

Une contribution, une identité, une composition ou une capture référence
un média par identifiant.

Elles ne possèdent pas directement le fichier.

Le registre permet de déterminer :

- combien de références utilisent le média ;
- où il est utilisé ;
- si le fichier existe ;
- s'il peut être supprimé ;
- s'il est inclus dans un export ;
- s'il est orphelin.

Ne pas maintenir manuellement un compteur susceptible de dériver s'il
peut être calculé de manière fiable.

Si un compteur mis en cache est utilisé :

- le recalculer ou le valider régulièrement ;
- ne jamais l'utiliser seul pour une suppression destructive.

## 4. Références multiples

Un même média peut être utilisé par : plusieurs contributions ;
plusieurs techniques ; une composition ; une capture à reprendre ; un
média principal ; une miniature.

Retirer une référence ne supprime jamais immédiatement le fichier
physique si une autre référence existe.

Comportement attendu :

- suppression d'une contribution → retrait de ses références ;
- recalcul des usages ;
- fichier conservé tant qu'il reste utilisé ;
- fichier sans référence → marqué orphelin ;
- suppression physique uniquement après confirmation ou politique
  explicite.

Ne pas déduire la propriété du fichier de la première contribution qui
l'a créé.

## 5. Ingestion d'un média

Tout média local entrant suit un pipeline unique :

1. réception dans une zone temporaire ;
2. lecture des métadonnées ;
3. calcul de l'empreinte ;
4. validation du type et de la taille ;
5. recherche d'un média identique ;
6. déduplication ou création ;
7. déplacement vers le stockage définitif ;
8. écriture du registre ;
9. création de la référence métier ;
10. nettoyage du temporaire.

En cas de doublon exact :

- réutiliser l'identifiant existant lorsque cela est sûr ;
- créer une nouvelle référence ;
- ne pas dupliquer le fichier physique.

Ne pas dédupliquer uniquement sur le nom d'origine.

Utiliser au minimum : taille ; SHA-256.

En cas d'échec avant rattachement :

- conserver la capture récupérable lorsque l'utilisateur a choisi
  `Garder pour plus tard` ;
- sinon nettoyer le temporaire ;
- ne pas créer une référence vers un fichier inexistant.

## 6. Nommage physique

Définir une convention stable et documentée.

Exemple acceptable : `<mediaId>.<extension-canonique>`

Le nom physique ne dépend pas : du nom de la technique ; du titre de la
composition ; du nom du pack ; du nom original fourni par l'utilisateur.

Ces valeurs peuvent changer.

Conserver le nom original dans les métadonnées.

Ne pas stocker les nouveaux médias sans extension lorsque l'extension
est connue.

Le nom physique doit être :

- sûr pour Android, navigateur et futur desktop ;
- sans caractères spéciaux dépendants de la plateforme ;
- indépendant de la langue ;
- stable après renommage d'une technique.

Les médias existants sans extension doivent rester lisibles.

Prévoir une migration réversible ou une résolution de chemin compatible :
ancien emplacement ; nouvel emplacement.

Ne pas renommer tous les fichiers sans stratégie de reprise en cas
d'interruption.

## 7. Arborescence logique

Documenter une arborescence logique claire.

Exemple :

```
state/          — bibliothèque courante, version du modèle
media/          — originaux
thumbnails/     — aperçus régénérables
staging/        — imports et écritures temporaires
snapshots/      — états locaux
exports/        — uniquement si conservation interne réellement nécessaire
```

L'arborescence exacte peut différer selon les contraintes OPFS et
Capacitor.

Elle doit toutefois respecter les responsabilités suivantes : état
courant ; médias définitifs ; temporaires ; miniatures ; snapshots.

Ne pas mélanger fichiers temporaires et définitifs dans le même espace
sans marqueur fiable.

## 8. Emplacement réel et cycle de vie

Documenter pour chaque cible :

**Android :**

- stockage privé de l'application ;
- visibilité ou non par l'utilisateur ;
- conservation lors d'une mise à jour ;
- suppression lors d'une désinstallation ;
- méthode utilisée pour partager ou exporter un fichier hors de l'espace
  privé.

**Navigateur :**

- OPFS propre à l'origine ;
- conséquences d'un effacement des données du site ;
- quota ;
- comportement en navigation privée ;
- persistance demandée ou non.

**PWA si réellement livrée :**

- origine utilisée ;
- même stockage que la version navigateur ;
- comportement après désinstallation de la PWA ;
- différence entre désinstallation de l'icône et effacement des données
  du site.

Ne pas présenter OPFS comme un dossier visible dans l'explorateur
Android.

La propriété des données repose sur l'export et la sauvegarde, pas sur
l'accès manuel au stockage privé.

## 9. Miniatures et aperçus

Les aperçus sont dérivables.

Ils ne constituent pas la copie de référence du média.

Chaque aperçu doit pouvoir être : régénéré ; supprimé sans perdre
l'original ; associé clairement au média source.

La sauvegarde complète peut choisir : d'inclure les miniatures ; ou de
les régénérer après restauration.

Ce choix doit être explicite.

Recommandation :

- ne pas inclure les miniatures régénérables dans la sauvegarde ;
- les reconstruire progressivement ;
- ne pas bloquer l'application pendant leur régénération.

Un aperçu absent n'est pas une perte de donnée.

## 10. Quota et espace disponible

Avant une opération volumineuse (import ; restauration ; capture
longue ; duplication physique éventuelle), estimer lorsque possible :
taille à écrire ; espace disponible ; marge de sécurité.

Si l'estimation n'est pas fiable, l'indiquer sans promettre une garantie
absolue.

En cas d'espace insuffisant :

- refuser avant mutation lorsque possible ;
- conserver l'état existant ;
- nettoyer les temporaires ;
- afficher la taille requise et l'espace estimé disponible.

Ne pas laisser une erreur de quota produire une bibliothèque
partiellement restaurée.

## 11. Nature du `.movpack`

Un `.movpack` est un conteneur ZIP versionné portant une extension
dédiée.

Il ne s'agit pas : d'un JSON simplement renommé ; d'un dossier ; d'un
format implicite dépendant du code courant.

Définir un type logique et un MIME documenté.

Exemple :

- extension : `.movpack`
- conteneur : ZIP
- MIME applicatif recommandé : `application/vnd.movenso.movpack+zip`
- fallback de partage : `application/zip` ou `application/octet-stream`
  selon les limites Android.

Ne pas se fier uniquement à l'extension lors de l'import.

Vérifier : signature ZIP ; présence du manifeste ; version ; structure
attendue.

## 12. Structure canonique du conteneur

Définir et documenter une structure canonique.

Elle peut conserver les noms actuels s'ils sont cohérents.

Exemple conceptuel :

```
manifeste.json
bibliotheque.json
medias/
  <mediaId>.<extension>
apercus/        — optionnel
```

Le manifeste ne doit pas dupliquer intégralement les données métier.

Il décrit le conteneur.

Les anciens conteneurs utilisant par exemple `videos/` doivent rester
importables au moyen d'un lecteur compatible.

Ne pas casser les `.movpack` déjà produits par la V3 sans migration ou
lecture rétrocompatible.

## 13. Manifeste

Le manifeste doit contenir au minimum :

- identifiant stable du pack ou de la sauvegarde ;
- version du format ;
- version du modèle de données ;
- type d'objet : pack publié ; sauvegarde complète ; export de
  composition ; autre portée explicitement supportée ;
- nom éditorial ;
- auteur ou organisation ;
- date de création ;
- version éditoriale ;
- portée ;
- conditions ou note de diffusion lorsque pertinent ;
- inventaire des fichiers ;
- tailles ;
- empreintes ;
- algorithme utilisé ;
- options d'inclusion : médias ; contenu personnel ; réglages ;
- éventuelles dépendances ou références externes.

L'identifiant stable ne doit pas être recalculé uniquement à partir du
nom de discipline.

Renommer un pack ne doit pas créer une nouvelle identité technique du
pack par accident.

## 14. Intégrité

L'intégrité doit couvrir : le fichier de données métier ; chaque média
inclus ; éventuellement les autres fichiers non régénérables.

Pour chaque fichier, conserver : chemin canonique ; taille ; SHA-256.

À l'import :

1. lire le manifeste ;
2. vérifier la liste ;
3. vérifier les tailles ;
4. vérifier les empreintes ;
5. refuser avant mutation en cas d'écart.

Ne pas vérifier uniquement `bibliotheque.json`.

Une miniature régénérable peut être exclue de la validation principale
si elle est explicitement optionnelle.

Un fichier supplémentaire inattendu doit être ignoré avec avertissement,
ou refusé selon la politique documentée.

Ne jamais l'exécuter ni le rendre accessible arbitrairement.

## 15. Export à mémoire bornée

L'export ne doit plus :

- charger toutes les vidéos en mémoire simultanément ;
- construire l'intégralité du ZIP sous forme d'un unique tableau avant
  écriture ;
- encoder les vidéos en base64 dans le JSON.

Utiliser une stratégie de streaming ou d'écriture incrémentale
compatible avec les cibles.

Comportement attendu :

- traiter les médias un par un ;
- libérer les buffers intermédiaires ;
- afficher une progression ;
- permettre l'annulation tant que l'état reste cohérent ;
- supprimer le fichier temporaire en cas d'abandon.

Si la bibliothèque ZIP actuelle ne permet pas ce comportement :

- utiliser son API streaming ;
- ou remplacer uniquement la couche d'archive par une solution légère et
  maintenue.

Ne pas remplacer toute la pile technique.

## 16. Tailles de référence

Le système doit être éprouvé avec au minimum :

- plusieurs centaines de techniques ;
- vingt médias ;
- au moins 500 Mo de fichiers cumulés ;
- un média individuel d'au moins 150 Mo.

La valeur exacte peut être adaptée à la capacité du terminal de recette.

L'objectif n'est pas une promesse de taille illimitée.

L'objectif est de démontrer : absence de chargement simultané de tous
les médias ; progression ; absence de crash mémoire ; résultat
restaurable.

Documenter les limites réelles observées.

## 17. Import en zone de préparation

Un import suit un workflow transactionnel autant que la plateforme le
permet.

Étapes :

1. copier ou lire le conteneur en zone de préparation ;
2. vérifier structure et intégrité ;
3. analyser les données ;
4. appliquer les migrations en mémoire ou dans une zone temporaire ;
5. produire le plan de rapprochement ;
6. estimer les médias à écrire ;
7. créer un snapshot préalable ;
8. écrire les nouveaux médias dans une zone temporaire ;
9. préparer le nouvel état métier ;
10. basculer vers le nouvel état ;
11. finaliser les médias ;
12. nettoyer.

Aucune modification durable ne doit intervenir avant : validation ;
confirmation utilisateur.

Si une atomicité parfaite n'est pas réalisable dans OPFS :

- utiliser un journal de transaction ou marqueur d'opération ;
- rendre l'opération reprenable ou annulable au prochain lancement ;
- ne pas prétendre qu'elle est atomique.

## 18. Bascule de l'état métier

Éviter l'écriture directe non protégée sur le fichier d'état courant.

Stratégie recommandée :

- écrire le nouvel état dans un fichier temporaire ;
- le relire et le valider ;
- conserver l'ancien état ;
- basculer l'indicateur ou remplacer de manière contrôlée ;
- supprimer l'ancien uniquement après succès.

Si le remplacement de fichier n'est pas atomique sur la plateforme :

- utiliser deux emplacements et un pointeur de version ;
- ou un journal de commit minimal.

Au démarrage :

- détecter une transaction inachevée ;
- choisir le dernier état validé ;
- proposer ou effectuer le nettoyage sûr.

## 19. Échec d'import

En cas d'échec :

- l'état précédent reste utilisable ;
- les médias temporaires sont supprimés ou identifiés ;
- le snapshot préalable est conservé ;
- aucun élément partiel n'apparaît dans la Bibliothèque ;
- un rapport indique l'étape et la cause ;
- l'utilisateur peut réessayer.

Ne pas laisser : discipline vide fantôme ; contribution sans média ;
fichier sans registre ; registre sans fichier ; moitié d'un pack
importée.

## 20. Sauvegarde complète

Une sauvegarde complète est un conteneur `.movpack` de type `sauvegarde`.

Elle inclut réellement :

- état métier complet ;
- registre média ;
- médias locaux non régénérables ;
- disciplines ;
- techniques ;
- contributions ;
- sources ;
- taxonomies ;
- relations ;
- captures à reprendre ;
- favoris ;
- compositions ;
- paramètres fonctionnels retenus ;
- informations nécessaires aux migrations.

Elle exclut :

- session curateur ;
- PIN en clair ;
- secret dérivé transportable si la décision du lot 7 prévoit une
  reconfiguration ;
- temporaires ;
- cache ;
- miniatures régénérables, sauf décision documentée ;
- logs non nécessaires.

Si certains médias ne peuvent pas être inclus :

- l'opération ne doit pas être appelée `sauvegarde complète` ;
- afficher une sauvegarde partielle avec liste précise des exclusions.

## 21. Restauration complète

La restauration complète doit fonctionner sur une installation vierge.

Étapes :

1. sélectionner le fichier ;
2. vérifier manifeste et intégrité ;
3. vérifier la version ;
4. migrer vers le modèle courant ;
5. afficher le contenu ;
6. estimer l'espace ;
7. confirmer ;
8. écrire en zone temporaire ;
9. valider ;
10. basculer ;
11. régénérer les éléments dérivables ;
12. afficher un rapport.

Après restauration, vérifier : nombres d'identités et contributions ;
médias disponibles ; sources ; taxonomies ; relations ; favoris ;
compositions ; captures à reprendre ; préférences retenues.

La restauration sur installation non vide ne doit pas effectuer une
fusion implicite.

Options acceptables : réservée à une installation vierge ; remplacement
complet après sauvegarde préalable ; opération de fusion distincte
clairement nommée.

Ne pas mélanger ces comportements.

## 22. Snapshots locaux

Un snapshot local est un mécanisme de retour arrière rapide.

Il n'est pas nécessairement une sauvegarde exportable complète.

Deux stratégies sont acceptables.

**A. Snapshot avec médias** — plus lourd, mais rollback complet.

**B. Snapshot état métier uniquement** — plus léger, mais ne restaure pas
un fichier supprimé physiquement.

Si la stratégie B est conservée :

- le nommer clairement ;
- indiquer ses limites ;
- ne pas promettre un rollback média complet ;
- éviter la suppression physique immédiate des médias après une action
  métier ;
- conserver éventuellement une corbeille temporaire.

Ne pas appeler `sauvegarde complète` un snapshot sans médias.

## 23. Corbeille média temporaire

Pour les opérations destructrices, envisager une corbeille locale
temporaire :

- média retiré du registre actif ;
- fichier conservé pendant une durée ou jusqu'à validation du snapshot ;
- restauration possible ;
- nettoyage ultérieur.

Ne pas implémenter une corbeille complexe si elle dépasse le lot.

Mais si les snapshots restent sans médias, une stratégie de rétention
physique est nécessaire pour que le rollback ait un sens.

Toute suppression définitive doit être clairement distinguée.

## 24. Pack publié

Un pack publié contient uniquement le corpus sélectionné et maîtrisé.

Il ne s'agit pas d'une sauvegarde.

Il inclut :

- manifeste éditorial ;
- identités nécessaires ;
- contributions sélectionnées ;
- taxonomies requises ;
- relations valides dans la portée ;
- médias sélectionnés ;
- éventuelles compositions explicitement incluses.

Il exclut par défaut :

- carnet personnel ;
- favoris ;
- captures à reprendre ;
- réglages ;
- PIN ;
- snapshots ;
- autres packs tiers ;
- contributions non sélectionnées.

Les références vers des identités non incluses doivent être : soit
ajoutées explicitement ; soit conservées comme dépendances signalées ;
soit exclues avec avertissement.

Ne pas produire silencieusement des relations cassées.

## 25. Export de composition

Un export de composition doit utiliser le même conteneur et le même
mécanisme d'intégrité.

Il peut proposer :

- composition seule avec références ;
- composition avec les techniques nécessaires ;
- médias inclus ou non.

Ne pas créer un second format parallèle.

Le manifeste précise la portée.

Une composition exportée ne duplique pas silencieusement les identités
lorsqu'elle est réimportée.

## 26. JSON historiques et démonstration

Conserver la lecture des JSON historiques uniquement comme compatibilité
contrôlée.

Lorsqu'un JSON sans manifeste est importé :

- le détecter comme format historique ;
- afficher qu'il ne possède ni manifeste ni intégrité de conteneur ;
- analyser et valider son schéma ;
- convertir vers le modèle courant ;
- produire un rapport.

Ne pas présenter un JSON historique comme un `.movpack`.

Les artefacts `packs-demo` doivent contenir en priorité de vrais
`.movpack`.

Les JSON peuvent rester comme fixtures de tests ou outils de
développement.

Ils ne doivent pas être le chemin normal présenté à l'utilisateur.

## 27. Compatibilité V2

Établir précisément les formats V2 réellement supportés :

- JSON de bibliothèque ;
- ZIP `.movpack` V2 ;
- export technique ;
- export discipline ;
- export bibliothèque ;
- médias.

Ne pas annoncer une migration complète si certains éléments sont perdus.

Pour chaque format, documenter : détecté ; importable ; migré ; ignoré ;
perdu ; nécessitant un outil externe.

Le code de migration V2 reste dans l'outillage ou une couche dédiée.

Il ne contamine pas le domaine V3.

Ajouter des fixtures représentatives réelles.

## 28. Versionnement et migrations

Distinguer : version du format conteneur ; version du modèle métier ;
version éditoriale du pack ; version de l'application.

Une migration doit être : déterministe ; testée ; idempotente lorsque
applicable ; non destructive ; explicite sur les valeurs perdues ou
transformées.

Ne pas utiliser un même champ `version` pour les quatre notions.

En cas de format futur non supporté :

- refuser proprement ;
- ne pas tenter une lecture partielle hasardeuse ;
- afficher la version minimale requise.

## 29. Projet Android

La cible Android doit être reproductible depuis le dépôt.

Décider et appliquer l'une des stratégies suivantes.

**A. Projet Android versionné**

Recommandée si des réglages natifs, permissions ou plugins sont
nécessaires.

Le dépôt contient : dossier Android ; Gradle ; manifeste ; ressources ;
configuration Capacitor ; éventuels plugins locaux.

**B. Projet généré de manière déterministe**

Acceptable uniquement si :

- toutes les modifications sont appliquées par scripts versionnés ;
- la CI et une machine neuve produisent exactement le même projet ;
- aucune modification manuelle n'est nécessaire.

Ne pas dépendre d'un projet généré puis modifié manuellement hors Git.

Documenter la stratégie retenue.

## 30. Identité et configuration Android

Confirmer et versionner :

- application ID ;
- nom affiché ;
- versionCode ;
- versionName ;
- icônes ;
- permissions ;
- orientations supportées ;
- politiques de stockage ;
- FileProvider ou mécanisme équivalent si utilisé ;
- partage ;
- sélection de fichiers ;
- caméra ;
- règles de sauvegarde Android.

Ne pas ajouter de permission de stockage globale si le sélecteur système
suffit.

Respecter le stockage cloisonné moderne.

## 31. Export et partage Android

Après création d'un `.movpack` ou d'une sauvegarde :

- proposer le partage Android ;
- ou enregistrer via le sélecteur système ;
- afficher un résultat compréhensible.

Ne pas afficher seulement un chemin interne inaccessible.

Le fichier partagé doit posséder : nom lisible ; extension `.movpack` ;
MIME approprié ; taille ; accès valide pendant le partage.

Tester avec : Google Drive ; Files ; partage local ; messagerie
autorisant le type de fichier.

Si une application refuse le MIME personnalisé :

- utiliser un fallback sûr ;
- conserver l'extension.

## 32. Installation, mise à jour et désinstallation

Démontrer :

**Mise à jour APK :**

- conserve l'état OPFS ;
- conserve les médias ;
- applique les migrations ;
- ne demande pas un nouvel import.

**Désinstallation :**

- supprime le stockage privé conformément au comportement Android ;
- n'est jamais présentée comme une sauvegarde ;
- nécessite une restauration depuis un fichier exporté.

**Réinstallation :**

- démarre vide ;
- permet de restaurer ;
- retrouve les données et médias.

Documenter ce comportement dans la recette.

## 33. Signature et release Android

Le workflow actuel peut continuer à produire un APK debug pour la
recette.

Préparer néanmoins une chaîne release documentée : build release ;
signature ; keystore externe au dépôt ; secrets CI ; versionnement ;
artefact APK ou AAB ; vérifications.

Ne jamais committer : keystore ; mot de passe ; secret.

Si les secrets ne sont pas encore disponibles :

- le workflow peut rester désactivé ou documenté ;
- mais la procédure doit être reproductible.

## 34. Web et PWA

Distinguer clairement :

**Web :**

- application ouverte dans un navigateur ;
- OPFS ;
- fonctionnement local après chargement selon le cache réel.

**PWA :**

- manifeste installable ;
- service worker ;
- cache de l'application ;
- démarrage hors ligne ;
- stratégie de mise à jour ;
- icônes ;
- comportement installable.

Ne pas appeler la cible `PWA` si ces éléments n'existent pas.

Décider pour ce lot : soit livrer une PWA minimale réelle ; soit
documenter `Web uniquement, PWA différée`.

Ne pas créer un service worker fragile uniquement pour cocher une case.

Si la PWA est livrée, tester : installation ; lancement hors ligne ;
mise à jour ; conservation OPFS ; erreur contrôlée pour les médias
distants.

## 35. Windows et Electron

Établir un statut explicite.

Electron est soit : présent et maintenu ; absent et différé ; abandonné
au profit d'une PWA ; à réintroduire dans un lot futur.

Ne pas introduire Electron automatiquement dans ce lot sans décision
justifiée.

Si Electron reste absent :

- le documenter clairement ;
- identifier la perte par rapport à la V2 : exécutable Windows portable ;
  accès fichier plus direct ; stockage à côté de l'application ;
- expliquer ce que le web ou la PWA remplace réellement et ce qu'elle ne
  remplace pas.

Ne pas déclarer la PWA équivalente à un ZIP portable Windows sans
démonstration.

Si une cible Windows portable reste un besoin dur, produire un arbitrage
humain compact avant d'ajouter Electron.

## 36. Matrice des plateformes

Maintenir une matrice factuelle.

Pour chaque cible (Android ; navigateur desktop ; PWA ; Windows
portable ; Electron), indiquer : statut ; commande de build ; stockage ;
import ; export ; caméra ; fichiers ; hors ligne ; partage ; signature ;
limites.

Utiliser des statuts tels que : livré ; démontré ; partiel ; différé ;
absent.

Ne pas utiliser `supporté` sans préciser ce qui l'est.

## 37. Build reproductible

Depuis une machine neuve, un développeur doit pouvoir :

1. cloner ;
2. installer les dépendances ;
3. lancer les tests ;
4. produire le build web ;
5. produire l'APK debug ;
6. inspecter un `.movpack` ;
7. lancer les migrations ;
8. créer les packs de démonstration.

Documenter les versions requises : Node ; npm ; Java ; Android SDK ;
Gradle ; Capacitor ; navigateurs de test.

Éviter les dépendances globales non documentées.

Ajouter si utile : `.nvmrc` ; version dans `package.json` ; vérification
de l'environnement.

## 38. Observabilité et diagnostic

Les erreurs techniques doivent être compréhensibles sans exposer les
secrets.

Pour une opération d'import, export ou stockage, produire : identifiant
d'opération ; étape ; message utilisateur ; détail technique
exportable ; fichiers temporaires concernés ; action de reprise.

Ne pas journaliser : PIN ; contenu personnel complet ; URL signée
sensible ; octets média.

Prévoir une action dans l'Atelier : `Exporter le diagnostic` — contenant
uniquement les informations techniques nécessaires.

Ne pas reconstruire un historique CSV exhaustif.

## 39. Limites strictes du lot

Ne pas modifier :

- navigation ;
- Bibliothèque ;
- présentation de la fiche ;
- workflows de capture ;
- Favoris ;
- UX des Compositions ;
- architecture de l'Atelier ;
- règles fonctionnelles de sécurité ;
- modèle de provenance ;
- rapprochement métier ;
- relations ;
- identité graphique générale.

Les évolutions de modèle autorisées concernent uniquement : registre
média ; métadonnées média ; versionnement ; manifeste ; intégrité ;
transactions ; migrations nécessaires.

Ne pas ajouter de nouvelle fonctionnalité utilisateur hors : progression ;
messages d'erreur ; actions nécessaires au partage, export et
restauration.

## 40. Critères d'acceptation

**Scénario A — média partagé**

1. ajouter la même vidéo à deux contributions ;
2. vérifier un seul fichier physique ;
3. retirer une contribution ;
4. vérifier que la vidéo reste lisible dans l'autre ;
5. retirer la dernière référence ;
6. vérifier que le fichier devient orphelin ;
7. supprimer physiquement uniquement après confirmation.

**Scénario B — déduplication**

1. importer deux fois le même fichier ;
2. vérifier la même empreinte ;
3. ne pas créer deux fichiers physiques ;
4. conserver deux références si les usages sont distincts.

**Scénario C — export volumineux**

1. préparer au moins 500 Mo de médias ;
2. exporter une sauvegarde complète ;
3. observer la progression ;
4. ne pas charger tous les médias simultanément ;
5. annuler une première fois ;
6. vérifier le nettoyage ;
7. recommencer ;
8. obtenir un fichier valide.

**Scénario D — intégrité**

1. produire un `.movpack` ;
2. modifier un octet d'un média ;
3. tenter l'import ;
4. voir l'erreur d'intégrité ;
5. vérifier qu'aucune donnée n'a changé.

**Scénario E — interruption**

1. lancer une restauration ;
2. interrompre l'application pendant la préparation ou l'écriture ;
3. relancer ;
4. retrouver l'état précédent valide ;
5. voir la transaction inachevée ;
6. nettoyer ou reprendre sans corruption.

**Scénario F — installation vierge**

1. créer une sauvegarde complète ;
2. désinstaller ;
3. réinstaller ;
4. restaurer ;
5. vérifier toutes les données ;
6. lire les médias ;
7. utiliser Favoris et Compositions.

**Scénario G — snapshot**

1. créer un snapshot ;
2. supprimer une contribution et un média ;
3. restaurer ;
4. vérifier exactement ce qui revient ;
5. si le média ne revient pas, voir la limite explicitement annoncée
   avant action.

**Scénario H — pack publié**

1. publier les contributions du club ;
2. vérifier le manifeste ;
3. vérifier tous les fichiers ;
4. confirmer l'absence du carnet, du PIN, des favoris et des
   contributions Kodokan non sélectionnées.

**Scénario I — JSON historique**

1. importer un JSON de démonstration ;
2. voir l'avertissement format historique ;
3. convertir ;
4. produire ensuite un vrai `.movpack` ;
5. réimporter ce conteneur avec contrôle d'intégrité.

**Scénario J — V2**

1. importer au moins une fixture V2 représentative ;
2. afficher le rapport de migration ;
3. vérifier les techniques ;
4. vérifier les médias ;
5. afficher les données non migrées ou perdues.

**Scénario K — Android**

1. construire l'APK depuis une machine neuve ou la CI ;
2. installer ;
3. filmer ;
4. exporter ;
5. partager vers Files ou Drive ;
6. réimporter ;
7. mettre à jour l'APK ;
8. vérifier les données.

**Scénario L — réseau coupé**

1. couper le réseau ;
2. lancer l'application ;
3. consulter les données ;
4. créer une sauvegarde ;
5. restaurer ;
6. utiliser les médias locaux ;
7. ne pas dépendre d'un service distant.

**Scénario M — plateforme**

1. lire la matrice ;
2. vérifier que chaque cible annoncée dispose d'une commande ou est
   marquée absente ;
3. ne trouver aucune mention Electron ou PWA ambiguë.

## 41. Tests

Ajouter ou adapter les tests pour couvrir :

- validation des métadonnées média ;
- calcul SHA-256 ;
- déduplication ;
- références multiples ;
- suppression de la dernière référence ;
- détection d'orphelins ;
- chemins et extensions ;
- migration des anciens médias ;
- manifeste ;
- inventaire ;
- intégrité de chaque fichier ;
- conteneur corrompu ;
- version future refusée ;
- export à traitement incrémental ;
- annulation ;
- import en staging ;
- bascule ;
- reprise après interruption ;
- nettoyage des temporaires ;
- sauvegarde complète ;
- publication filtrée ;
- export de composition ;
- JSON historique ;
- fixtures V2 ;
- mise à jour du modèle ;
- build Android reproductible.

Ajouter un E2E vertical :

```
installation vide
→ importer un vrai `.movpack`
→ ajouter deux références vers un même média
→ sauvegarde complète
→ restauration dans un contexte vierge
→ vérifier les médias
→ exporter un pack filtré
→ vérifier son manifeste
→ corrompre un média
→ vérifier le refus sans mutation.
```

`npm run verifier` doit être vert.

Ajouter des tests d'intégration spécifiques au stockage lorsque
Playwright seul ne suffit pas.

Une vérification Android réelle est obligatoire pour :

- caméra ;
- fichier volumineux ;
- partage ;
- import depuis Files ;
- quota ;
- mise à jour ;
- désinstallation/réinstallation ;
- interruption pendant export ou restauration.

## 42. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- ingestion média ;
- média partagé ;
- export ;
- import ;
- sauvegarde complète ;
- restauration ;
- interruption ;
- publication ;
- partage Android.

`docs/systeme.md` :

- diagramme réel des couches ;
- registre média ;
- arborescence logique ;
- nommage ;
- transactions ;
- format `.movpack` ;
- manifeste ;
- intégrité ;
- migrations ;
- plateformes ;
- build.

Ajouter un Mermaid compact :

```
Entrée média
→ Staging
→ Validation + SHA
→ Déduplication
→ Registre
→ Stockage définitif
→ Référence métier
```

et :

```
.movpack
→ Vérification
→ Migration
→ Plan
→ Staging
→ Validation
→ Bascule
→ Nettoyage
```

Matrice de conservation :

- maturité média V2 réintroduite ;
- identités et contributions V3 conservées ;
- JSON brut rétrocompatible mais non format principal ;
- ZIP en mémoire remplacé ;
- sauvegarde complète distinguée du snapshot ;
- Electron explicitement présent, différé ou absent ;
- Windows portable déclaré honnêtement ;
- PWA uniquement si réellement livrée.

`docs/etat.md` :

- lot terminé ;
- format courant ;
- version du modèle ;
- limites de taille observées ;
- stratégie Android ;
- statut des plateformes ;
- risques restant ouverts ;
- prochain lot : identité graphique et consolidation UX.

README :

- procédure de reprise en trente minutes ;
- builds ;
- artefacts ;
- inspection d'un `.movpack` ;
- emplacements logiques des données.

## 43. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- vrais `.movpack` de démonstration ;
- un pack volumineux de test non distribué publiquement ;
- rapport d'inspection d'un conteneur ;
- matrice des plateformes ;
- captures ou vidéo montrant :
  - export avec progression ;
  - rapport d'intégrité ;
  - refus d'un conteneur corrompu ;
  - restauration ;
  - partage Android ;
  - diagnostics média.

Rapport compact :

- fichiers modifiés ;
- modèle média final ;
- arborescence ;
- convention de nommage ;
- format exact ;
- stratégie d'intégrité ;
- stratégie transactionnelle ;
- tailles testées ;
- comportement Android ;
- statut Electron, Windows, Web et PWA ;
- limites encore ouvertes.

N'anticipe pas le lot 9 Identité graphique.

Ne modifie pas les workflows produit déjà validés.

**La réussite de ce lot se mesure à une chose : un utilisateur peut
confier ses vidéos et son corpus à Movenso, les exporter, perdre son
installation, les restaurer et vérifier leur intégrité sans dépendre
d'une promesse implicite, d'un chemin mystérieux ou d'un format que seul
le code courant sait relire.**
