# LOT 2 — BIBLIOTHÈQUE : EXPLORER, CHERCHER ET PEUPLER UN CORPUS

## Contexte

Le lot 1 a supprimé l'Accueil et installé trois destinations principales :

- Bibliothèque ;
- Pratique ;
- Atelier.

La Bibliothèque est désormais la destination de démarrage et le centre de
consultation de Movenso.

La V3 possède déjà plusieurs qualités à conserver :

- une grille visuelle efficace ;
- des identités techniques réunissant plusieurs contributions ;
- une recherche multi-source ;
- des filtres de familles et de niveaux ;
- des miniatures vidéo ;
- une navigation discipline → techniques → fiche ;
- des disciplines pouvant exister sans contenu embarqué.

Cependant, plusieurs ambiguïtés subsistent :

- discipline, pack, source et provenance ne sont pas toujours clairement
  distingués dans l'interface ;
- une discipline vide peut mener à une impasse ;
- les identifiants techniques de packs peuvent apparaître comme des
  libellés utilisateur ;
- l'import et la création de discipline occupent parfois inutilement le
  premier plan ;
- les filtres et états de navigation doivent être conservés de manière
  fiable ;
- une identité réunissant plusieurs voix ne doit jamais réapparaître
  plusieurs fois dans les résultats.

Ce lot porte **exclusivement** sur la Bibliothèque :

- racine des disciplines ;
- recherche globale ;
- exploration d'une discipline ;
- filtres ;
- cartes techniques ;
- états vides ;
- accès à la création d'une première technique.

Il ne refond pas encore :

- la fiche technique ;
- le workflow détaillé de création ou de capture ;
- les favoris ;
- les compositions ;
- l'Atelier ;
- le modèle des médias ;
- la sécurité ;
- la direction graphique générale.

## Objectif unique

Faire de la Bibliothèque un espace immédiatement compréhensible et complet
pour :

1. choisir une discipline ;
2. rechercher dans l'ensemble du savoir installé ;
3. explorer visuellement les techniques ;
4. filtrer sans perdre les identités réunies ;
5. comprendre la différence entre discipline et source ;
6. commencer à peupler une discipline vide sans impasse.

## 1. Hiérarchie conceptuelle à respecter

L'interface doit respecter strictement les distinctions suivantes.

**Discipline :**

- représente la discipline ou le champ de pratique ;
- exemples : Judo, Boxe, Karaté, JJB ;
- apparaît à la racine de la Bibliothèque.

**Identité technique :**

- représente une technique unique ;
- exemples : Ashi-guruma, Crochet gauche ;
- apparaît une seule fois dans la grille, même si plusieurs sources la
  décrivent.

**Source :**

- indique l'auteur ou le corpus d'origine d'une contribution ;
- exemples : Kodokan, Club X, Sensei Y, Moi ;
- sert de filtre ou d'information secondaire ;
- ne crée jamais une discipline parallèle.

**Pack :**

- est une unité d'import, d'export, de versionnement et de distribution ;
- son nom technique ou son identifiant interne ne doit pas devenir
  automatiquement un libellé d'interface ;
- un pack peut contribuer à une discipline existante.

**Provenance :**

- qualifie la nature d'une contribution :
  - référentiel ;
  - enseignement ;
  - ressource ;
  - personnel ;
- ne remplace ni la discipline, ni le nom du pack, ni son auteur.

Ne pas introduire dans ce lot une nouvelle entité métier `Collection`.

Si le besoin d'une collection distincte apparaît, le tracer comme question
ouverte sans modifier le modèle.

## 2. Racine de la Bibliothèque

La racine affiche la liste des disciplines présentes.

Chaque discipline apparaît une seule fois.

Une carte de discipline contient au minimum :

- son nom utilisateur ;
- le nombre d'identités techniques uniques ;
- éventuellement le nombre de sources présentes ;
- éventuellement le nombre de techniques possédant plusieurs voix.

Exemple acceptable :

```
Judo
136 techniques · 2 sources · 24 à plusieurs voix
```

Ne pas afficher comme sous-titre générique :

- « référentiel » ;
- « pack club » ;
- un identifiant tel que `club-judo` ;
- une addition brute du nombre d'éléments de chaque pack.

Les compteurs doivent porter sur les identités réellement visibles dans la
discipline, pas sur le total des contributions.

Une discipline vide doit apparaître clairement :

```
Boxe
0 technique · prête à être complétée
```

La carte reste ouvrable.

## 3. Actions à la racine

**Bibliothèque contenant au moins une discipline :**

- ne pas afficher en permanence de grandes actions `Importer un pack` ou
  `Créer une discipline` ;
- ces fonctions restent disponibles dans l'Atelier ;
- ne pas ajouter de bouton flottant global.

**Bibliothèque totalement vide :**

afficher un état vide contenant :

- une phrase courte ;
- `Importer un pack` ;
- `Créer une discipline`.

Exemple :

```
Ta bibliothèque est vide.
Importe un corpus existant ou commence ta propre discipline.
```

Une fois la première discipline créée ou le premier pack importé, cet écran
disparaît au profit de la liste normale.

Ne pas créer d'onboarding supplémentaire.

## 4. Recherche globale

La Bibliothèque doit proposer une recherche globale clairement accessible
depuis sa racine.

Elle interroge l'ensemble des disciplines et sources installées.

La recherche doit couvrir au minimum :

- nom principal de la technique ;
- nom traditionnel ;
- appellations ou alias disponibles ;
- texte personnel indexable ;
- libellés utiles déjà pris en charge par le moteur de recherche actuel.

Elle doit être :

- insensible à la casse ;
- tolérante aux accents ;
- tolérante aux espaces et traits d'union ;
- compatible avec les variantes simples de romanisation déjà gérées.

Exemples :

- `de ashi` retrouve `De-ashi-harai` ;
- `banane` retrouve une technique contenant ce repère personnel ;
- une appellation traditionnelle retrouve la technique concernée.

Une identité apparaît une seule fois dans les résultats, même si plusieurs
contributions correspondent à la recherche.

Chaque résultat affiche suffisamment de contexte :

- nom ;
- nom traditionnel si disponible ;
- discipline ;
- miniature ou fallback ;
- sources ou nombre de voix lorsque cela est pertinent.

Ouvrir un résultat puis revenir doit restaurer :

- la requête ;
- les résultats ;
- la position de défilement.

Ne pas afficher l'intégralité des descriptions dans les résultats.

## 5. Explorateur d'une discipline

Conserver la grille visuelle actuelle de la V3 comme base.

Sur téléphone :

- deux colonnes lorsque la largeur le permet ;
- cartes lisibles sans textes tronqués de façon incohérente.

Sur tablette ou grand écran :

- augmenter naturellement le nombre de colonnes ;
- ne pas étirer les cartes sur toute la largeur.

En tête de l'explorateur :

- retour vers la liste des disciplines ;
- nom de la discipline ;
- nombre d'identités techniques uniques ;
- recherche locale ;
- filtres de sources ;
- filtres de niveaux ;
- filtres de familles ou catégories.

Ne pas afficher les packs comme s'ils étaient des disciplines.

## 6. Filtre par source

Ajouter ou conserver un filtre de source au sein de la discipline.

Exemples de libellés :

- Toutes les sources ;
- Kodokan ;
- Club de Castres ;
- Moi.

Ne jamais afficher directement un identifiant technique tel que :

- `club-judo` ;
- `pack-kodokan-v1` ;
- un UUID ;
- un slug interne.

Le libellé provient en priorité :

1. du nom éditorial du manifeste ;
2. du nom de l'auteur ou de l'organisation ;
3. d'un fallback lisible explicitement construit.

Si deux sources portent le même nom, les différencier avec une information
compréhensible :

- auteur ;
- organisation ;
- version ;
- origine.

Ne pas utiliser leurs identifiants bruts comme solution d'interface.

Sémantique du filtre :

- `Toutes les sources` affiche chaque identité une seule fois ;
- sélectionner une source affiche les identités possédant au moins une
  contribution issue de cette source ;
- une identité ayant plusieurs contributions issues de la même source reste
  affichée une seule fois ;
- `Moi` sélectionne les identités possédant une contribution personnelle.

Le filtre de source ne supprime ni ne duplique les identités.

## 7. Représentation d'une technique selon le filtre de source

En vue `Toutes les sources` :

- utiliser le média principal de l'identité lorsque disponible ;
- sinon utiliser le meilleur média disponible selon les règles existantes ;
- indiquer discrètement lorsqu'une technique contient plusieurs voix.

En vue filtrée par une source :

- privilégier pour l'aperçu un média provenant de la source sélectionnée
  lorsqu'il existe ;
- sinon conserver le média principal avec une indication claire que
  l'aperçu vient d'une autre source ;
- ne pas modifier le média principal global simplement parce qu'un filtre
  est actif.

Ne pas exposer toute la provenance sur la carte.

Une indication compacte suffit, par exemple :

- `2 voix` ;
- un petit badge de source ;
- un filet visuel ;
- une icône accompagnée d'un libellé accessible.

L'utilisateur doit comprendre le résultat sans transformer chaque carte en
fiche détaillée.

## 8. Cartes techniques

Chaque carte contient au minimum :

- miniature ou fallback ;
- nom principal ;
- nom traditionnel lorsqu'il existe ;
- niveaux pertinents sous forme compacte ;
- indication de pluralité des voix lorsque nécessaire.

La famille peut être affichée uniquement si elle ne surcharge pas la carte.

Fallback sans média :

- initiale du nom principal ;
- appellation traditionnelle ;
- symbole générique non disciplinaire.

Ne pas coder en dur :

- kanji de judo ;
- icône propre à une discipline ;
- couleur de ceinture universelle.

Ne pas ajouter sur chaque vignette :

- crayon d'édition ;
- suppression ;
- menu administratif permanent ;
- bouton de capture.

Toucher la carte ouvre la fiche.

Les modifications et actions détaillées appartiennent à la fiche ou aux
workflows contextuels des lots suivants.

Les éventuels favoris ne sont pas implémentés dans ce lot.

Si des données de favoris existent déjà :

- les préserver ;
- ne pas les supprimer ;
- ne pas refondre leur UX avant le lot Pratique.

## 9. Filtres cumulables

Les filtres doivent fonctionner ensemble.

Dimensions minimales :

- recherche ;
- source ;
- famille ou catégorie ;
- niveau.

Sémantique :

- entre dimensions : ET ;
- plusieurs choix au sein d'une même dimension, si le moteur le permet : OU.

Exemple :

```
Source = Club
ET
Niveau = Jaune ou Orange
ET
Famille = Ashi-waza
ET
Recherche = gari
```

Les résultats et leur compteur se mettent à jour immédiatement.

Les filtres actifs doivent être visibles.

Prévoir une action compacte :

- `Réinitialiser les filtres`

uniquement lorsqu'au moins un filtre est actif.

Lorsque aucun résultat ne correspond :

afficher :

- la phrase `Aucune technique ne correspond à ces filtres` ;
- les filtres actifs ;
- l'action de réinitialisation.

Ne pas afficher une bibliothèque vide ambiguë lorsqu'il s'agit uniquement
d'un filtre trop restrictif.

## 10. Niveaux et taxonomies

Les niveaux, familles et catégories sont issus des données de la
discipline.

Le moteur ne suppose pas :

- des ceintures ;
- un ordre de grades universel ;
- une nomenclature japonaise ;
- une seule famille par technique.

Afficher les couleurs lorsqu'elles existent dans les données.

Un niveau sans couleur reste utilisable et visible.

Le libellé du filtre doit provenir de la donnée et non d'un vocabulaire
codé dans l'interface.

Ne pas modifier dans ce lot :

- la création ;
- le renommage ;
- la suppression ;
- l'ordre des taxonomies.

Ces opérations restent dans l'Atelier et seront traitées dans son lot.

## 11. Discipline vide

Ouvrir une discipline vide ne doit plus produire seulement :

- une grille vide ;
- `Rien avec ces filtres` ;
- un bouton Capturer demandant ensuite une technique inexistante.

Afficher un état vide spécifique :

```
Boxe ne contient encore aucune technique.
```

Action principale :

- `Créer la première technique`

Action secondaire possible :

- `Importer un pack`

L'action principale doit ouvrir le workflow de création de technique
existant.

Dans ce lot, ne pas refondre entièrement ce workflow.

Cependant, vérifier qu'il permet au minimum :

- de préselectionner la discipline ouverte ;
- de créer la technique ;
- de revenir dans cette discipline ;
- de voir immédiatement la nouvelle technique.

Si le workflow actuel ne permet pas ce parcours minimal, effectuer
uniquement les adaptations nécessaires pour supprimer l'impasse.

Le workflow complet de création, capture et édition sera traité au lot
correspondant.

## 12. Action contextuelle dans une discipline

Lorsqu'une discipline contient déjà des techniques et que les
modifications sont autorisées, proposer une action contextuelle claire :

- `+ Technique`
ou
- `Nouvelle technique`

Ne pas utiliser le libellé générique `Capturer` pour cette action.

Cette action ouvre le workflow existant de création ou de capture avec la
discipline préselectionnée.

Lorsqu'une protection interdit les modifications, l'action doit être :

- masquée ;
ou
- présentée comme protégée avec un comportement cohérent.

Ne pas implémenter ou refondre le PIN dans ce lot.

Respecter simplement l'état d'autorisation existant.

## 13. Conservation de l'état

Pour chaque discipline, conserver pendant la session :

- recherche ;
- source sélectionnée ;
- familles sélectionnées ;
- niveaux sélectionnés ;
- position de défilement.

Changer d'onglet puis revenir ne doit pas effacer ces éléments.

Ouvrir une fiche puis revenir doit restaurer exactement l'explorateur.

Revenir à la racine Bibliothèque puis rouvrir une discipline peut restaurer
son dernier état pendant la session.

Après fermeture complète de l'application, conserver uniquement ce qui est
déjà prévu par les préférences existantes.

Ne pas ajouter de persistance permanente de tous les filtres sans besoin
démontré.

## 14. Performance

La Bibliothèque doit rester fluide avec :

- plusieurs disciplines ;
- plusieurs centaines de techniques ;
- plusieurs sources par identité ;
- miniatures locales ou distantes.

Éviter :

- recalcul complet non nécessaire à chaque frappe ;
- reconstruction de toutes les miniatures à chaque filtre ;
- duplication des identités dans des tableaux intermédiaires persistants ;
- chargement complet des médias vidéo pour afficher une vignette.

Utiliser les index et métadonnées existants.

Ne pas refondre le modèle de stockage dans ce lot.

## 15. Limites strictes du lot

Ne pas modifier :

- le modèle identité/contribution ;
- le rapprochement inter-packs ;
- le format `.movpack` ;
- le stockage OPFS ;
- le modèle des médias ;
- la fiche technique ;
- les compositions ;
- les favoris ;
- l'organisation interne de l'Atelier ;
- la sécurité et le PIN ;
- la direction graphique globale ;
- la publication des packs ;
- les relations.

Les changements métier autorisés sont limités à ce qui est nécessaire pour :

- rechercher ;
- filtrer ;
- présenter sans duplication ;
- ouvrir une discipline vide ;
- créer sa première technique avec le workflow existant.

Toute autre amélioration détectée doit être **tracée, pas implémentée**.

## 16. Critères d'acceptation

**Scénario A — racine :**

1. ouvrir Bibliothèque ;
2. voir une seule carte Judo ;
3. vérifier que Kodokan et Club ne sont pas affichés comme disciplines
   séparées ;
4. vérifier que le nombre affiché correspond aux identités uniques ;
5. ouvrir Judo.

**Scénario B — exploration :**

1. voir la grille visuelle ;
2. filtrer par famille ;
3. ajouter un niveau ;
4. ajouter une source ;
5. saisir une recherche ;
6. vérifier que tous les filtres se cumulent ;
7. réinitialiser ;
8. retrouver la grille complète.

**Scénario C — multi-source :**

1. afficher Toutes les sources ;
2. vérifier qu'Ashi-guruma n'apparaît qu'une fois ;
3. filtrer Kodokan ;
4. vérifier qu'Ashi-guruma reste visible avec l'aperçu approprié ;
5. filtrer Club ;
6. vérifier qu'elle reste unique ;
7. ne voir aucun identifiant technique de pack dans l'interface.

**Scénario D — recherche globale :**

1. revenir à la racine ;
2. chercher une technique présente dans plusieurs sources ;
3. obtenir un seul résultat ;
4. ouvrir la fiche ;
5. revenir ;
6. retrouver la requête et la position.

**Scénario E — recherche personnelle :**

1. créer ou utiliser un repère personnel existant ;
2. le rechercher depuis la Bibliothèque ;
3. retrouver la technique concernée ;
4. vérifier qu'aucune autre contribution n'est dupliquée.

**Scénario F — discipline vide :**

1. ouvrir Boxe vide ;
2. voir l'état vide spécifique ;
3. choisir Créer la première technique ;
4. créer Crochet gauche avec le workflow existant ;
5. revenir automatiquement dans Boxe ;
6. voir Crochet gauche dans la grille.

**Scénario G — retour et état :**

1. Judo ;
2. activer plusieurs filtres ;
3. faire défiler ;
4. ouvrir une fiche ;
5. revenir ;
6. retrouver filtres et position ;
7. aller dans Pratique ;
8. revenir dans Bibliothèque ;
9. retrouver le même état.

**Scénario H — bibliothèque totalement vide :**

1. démarrer sans discipline ;
2. voir Importer un pack et Créer une discipline ;
3. créer une discipline ;
4. arriver sur son état vide ;
5. ne jamais passer par un Accueil ou un onboarding.

## 17. Tests

Ajouter ou adapter les tests pour couvrir :

- disciplines uniques ;
- compte des identités et non des contributions ;
- recherche globale sans doublons ;
- recherche dans les contributions personnelles ;
- filtre par source ;
- labels de source éditoriaux ;
- absence d'identifiants internes dans l'interface ;
- cumul des filtres ;
- discipline vide ;
- création d'une première technique ;
- conservation des filtres et du scroll ;
- retour fiche → explorateur ;
- absence de régression sur l'import des deux packs Judo.

Ajouter un scénario E2E minimal :

```
installation vide
→ création Boxe
→ création Crochet gauche
→ apparition dans la grille
→ recherche
→ ouverture de la fiche
→ retour avec état conservé.
```

`npm run verifier` doit être vert.

Une vérification Android réelle reste obligatoire pour :

- défilement ;
- clavier ;
- retour ;
- position restaurée ;
- fluidité de la grille.

## 18. Documentation

Mettre à jour les documents existants uniquement.

`docs/workflows.md` :

- Bibliothèque vide ;
- Bibliothèque contenant plusieurs disciplines ;
- recherche globale ;
- exploration d'une discipline ;
- filtres cumulables ;
- filtre par source ;
- création de la première technique ;
- niveaux de démonstration réels.

`docs/systeme.md` :

- construction de la vue Bibliothèque ;
- source des compteurs ;
- règles de déduplication ;
- règles de libellé des sources ;
- état conservé par discipline.

Matrice de conservation :

- grille visuelle V2/V3 conservée ;
- filtres cumulables conservés ;
- packs retirés de la racine et transformés en filtres de source ;
- import/création retirés de la façade normale mais conservés dans les
  états vides et l'Atelier ;
- édition par vignette non reprise ;
- favoris préservés mais différés au lot Pratique.

`docs/etat.md` :

- lot terminé ;
- tests ;
- limites restantes ;
- prochain lot : fiche technique.

Ne pas documenter comme implémenté ce qui appartient encore aux lots
suivants.

## 19. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures de :
  - racine Bibliothèque ;
  - discipline avec grille et filtres ;
  - source sélectionnée ;
  - discipline vide ;
  - résultat de recherche globale.

Rapport compact :

- fichiers modifiés ;
- règles de discipline/source appliquées ;
- champs indexés par la recherche ;
- comportement des filtres ;
- état conservé ;
- adaptations minimales faites pour créer la première technique ;
- anomalies hors périmètre.

N'anticipe pas le lot Fiche technique.

Ne refonds pas les médias, la capture, les compositions, l'Atelier ou le
modèle métier dans ce lot.

**La réussite de ce lot se mesure à une chose : un utilisateur peut entrer
dans sa bibliothèque, comprendre ce qu'il possède, retrouver une technique
sans doublons et commencer une discipline vide sans rencontrer d'impasse.**
