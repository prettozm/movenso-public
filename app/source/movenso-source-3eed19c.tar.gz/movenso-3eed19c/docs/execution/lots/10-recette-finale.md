# LOT 10 — RECETTE FINALE, STABILISATION ET CLÔTURE DE MOVENSO V3

## Contexte

Les lots 1 à 9 ont défini et implémenté la cible Movenso V3 :

**Lot 1 :** suppression de l'Accueil ; navigation Bibliothèque, Pratique,
Atelier ; démarrage sur la Bibliothèque ; actions contextuelles.

**Lot 2 :** disciplines uniques ; recherche globale ; recherche
multisource ; filtres ; grille visuelle ; discipline vide.

**Lot 3 :** fiche technique média-first ; plusieurs voix ; carnet
personnel ; galerie ; relations et compositions compactes.

**Lot 4 :** création minimale ; capture rapide ; rattachement immédiat ou
différé ; contenus à reprendre ; contribution contextualisée.

**Lot 5 :** Favoris ; À reprendre ; Compositions ; blocs Technique et
Texte ; mode entraînement.

**Lot 6 :** Atelier organisé en quatre intentions ; disciplines et
taxonomies ; diagnostics ; import ; publication ; sauvegarde ;
restauration.

**Lot 7 :** appareil personnel modifiable par défaut ; protections
facultatives ; PIN local ; session curateur ; tablette partagée.

**Lot 8 :** registre média ; format `.movpack` ; intégrité ; transactions ;
sauvegarde complète ; Android et plateformes.

**Lot 9 :** identité graphique ; coque sombre et contenu clair ;
responsive ; accessibilité ; consolidation UX.

Le périmètre produit est maintenant **gelé**.

Ce lot ne sert pas à améliorer la vision, ajouter des fonctions ou
poursuivre une refonte.

Il sert à répondre objectivement à trois questions :

1. les workflows promis fonctionnent-ils réellement ?
2. les données survivent-elles aux opérations et aux incidents prévus ?
3. l'application peut-elle être reprise, construite et recettée par
   quelqu'un d'autre ?

## Objectif unique

Produire une version candidate de Movenso V3 :

- fonctionnellement cohérente ;
- techniquement reproductible ;
- testée de bout en bout ;
- installable sur Android ;
- utilisable hors ligne ;
- restaurable ;
- documentée ;
- sans défaut bloquant connu ;
- accompagnée d'un rapport honnête de ses limites.

Le lot se termine obligatoirement par une décision explicite : **GO** ;
**GO AVEC RÉSERVES** ; **NO-GO**.

## 1. Règles de sécurité du travail

Travailler uniquement sur la branche explicitement approuvée pour
Movenso V3.

Interdictions :

- ne pas modifier `main` directement ;
- ne pas fusionner dans `main` ;
- ne pas effectuer de force-push ;
- ne pas réécrire l'historique ;
- ne pas supprimer une branche distante ;
- ne pas modifier V2 ;
- ne pas publier de release publique ;
- ne pas modifier des secrets CI ;
- ne pas utiliser les données personnelles réelles comme fixtures ;
- ne pas effectuer de test destructif sur l'unique installation de
  l'utilisateur.

Avant toute opération :

- relever la branche courante ;
- relever le dernier commit ;
- vérifier l'état Git ;
- signaler les fichiers non suivis ou modifications préexistantes ;
- créer un point de retour identifié.

Les tests destructifs utilisent : un profil isolé ; une installation de
recette ; des fixtures dédiées ; ou une sauvegarde vérifiée.

## 2. Gel du périmètre

Aucune nouvelle fonctionnalité n'est autorisée.

Sont notamment interdits : nouvel onglet ; nouvel écran métier ; nouvelle
provenance ; nouveau type de composition visible ; nouvelle entité
Collection ; compte utilisateur ; synchronisation ; cloud ;
statistiques ; gamification ; biométrie ; nouvelle cible desktop ;
nouveau modèle d'autorité ; nouvelle taxonomie ; nouveau workflow
d'import.

Une correction est autorisée uniquement si elle :

- répare un comportement déjà promis ;
- empêche une perte de données ;
- corrige une incohérence d'interface ;
- restaure une compatibilité explicitement annoncée ;
- corrige un défaut de sécurité ;
- permet le build, le test ou la reprise.

Toute autre idée rejoint la liste post-V3.

## 3. Exécution en trois sous-étapes

**10A — Audit**

- ne pas effectuer de correction fonctionnelle ;
- exécuter les tests ;
- inspecter les workflows ;
- établir la matrice ;
- classer les anomalies ;
- proposer un plan de correction fermé.

**10B — Stabilisation**

- corriger uniquement les P0 et P1 validés ;
- corriger éventuellement un P2 trivial s'il ne modifie pas le
  périmètre ;
- ajouter un test de non-régression pour chaque défaut corrigé ;
- ne pas refondre les zones voisines.

**10C — Recette finale**

- repartir d'un build propre ;
- exécuter la matrice complète ;
- produire les artefacts ;
- documenter les preuves ;
- rendre la décision Go/No-Go.

Un commit distinct est attendu après chacune des trois sous-étapes.

## 4. Classification des anomalies

**P0 — Bloquant absolu**

Exemples : perte ou corruption de données ; application impossible à
lancer ; build impossible ; sauvegarde prétendument réussie mais
inutilisable ; restauration détruisant l'état existant ; média supprimé
alors qu'il reste utilisé ; secret stocké en clair ; action destructive
sans confirmation ; APK inutilisable.

Décision : correction obligatoire ; No-Go tant que présent.

**P1 — Majeur**

Exemples : workflow principal incomplet ; impasse utilisateur ; retour
Android cassé ; import ou export courant impossible ; capture perdue
après interruption prévue ; fiche ou composition inutilisable ;
protection contournable depuis un point d'entrée normal ; régression
importante par rapport à une capacité validée.

Décision : correction obligatoire avant Go.

**P2 — Modéré**

Exemples : information secondaire incorrecte ; mise en page dégradée
dans un cas non bloquant ; texte ambigu ; diagnostic incomplet ;
performance médiocre sur un corpus extrême ; compatibilité partielle
clairement annoncée.

Décision : correction uniquement si courte et sans risque ; sinon
réserve documentée.

**P3 — Mineur**

Exemples : détail graphique ; animation ; alignement ; optimisation
facultative ; amélioration de confort.

Décision : ne pas corriger dans ce lot ; enregistrer dans le backlog.

## 5. Lot 10A — état initial

Avant toute correction, produire un état initial comprenant :

- branche ;
- commit ;
- version applicative ;
- version du modèle ;
- version du format `.movpack` ;
- version Node ;
- version npm ;
- version Java ;
- version Android SDK ;
- version Capacitor ;
- système d'exploitation de build ;
- état de Git ;
- liste des commandes disponibles.

Exécuter au minimum : installation propre des dépendances ; typecheck ;
lint si présent ; tests unitaires ; tests d'intégration ; E2E ; tests
visuels ciblés ; build web ; build Android ; génération des packs de
démonstration ; inspection d'un `.movpack`.

Ne pas modifier le code pour faire disparaître un échec pendant cette
étape.

Consigner chaque résultat.

## 6. Matrice des capacités

Créer ou mettre à jour une matrice unique avec les statuts suivants :
Démontré automatiquement ; Démontré manuellement ; Partiellement
démontré ; Non démontré ; Échec ; Non applicable.

Chaque ligne doit inclure : capacité ; lot d'origine ; test ou scénario ;
plateforme ; preuve ; anomalie éventuelle ; décision.

Capacités minimales :

**Navigation :** démarrage Bibliothèque ; trois onglets ; retour
Android ; conservation des états.

**Bibliothèque :** discipline vide ; recherche globale ; multisource ;
filtres cumulables ; absence de doublons.

**Fiche :** média principal ; plusieurs voix ; carnet ; plusieurs
médias ; relations ; compositions utilisatrices.

**Création :** technique minimale ; capture ; rattachement ; capture à
reprendre ; création depuis capture ; annulation.

**Pratique :** Favoris ; À reprendre ; composition ; réordonnancement ;
mode entraînement.

**Atelier :** discipline ; taxonomie ; diagnostics ; import ; publication ;
sauvegarde ; restauration.

**Sécurité :** appareil personnel ; protections séparées ; PIN ;
expiration ; tablette partagée ; action destructive.

**Technique :** média partagé ; déduplication ; `.movpack` ; intégrité ;
transaction ; restauration vierge ; mise à jour Android.

**UX :** téléphone ; tablette ; paysage ; thème clair ; thème sombre ;
accessibilité essentielle.

## 7. Corpus de recette

Préparer des jeux de données non personnels.

**A. Installation vide** — aucune discipline ; aucun réglage ; aucun
PIN.

**B. Corpus personnel minimal** — une discipline ; trois techniques ; un
média ; un repère ; un favori ; une composition.

**C. Corpus multisource** — une même identité avec au moins deux voix ;
référentiel ; enseignement ; personnel ; médias distincts ; relations.

**D. Corpus volumineux** — plusieurs centaines de techniques ; plusieurs
sources ; au moins vingt médias ; volume média défini au lot 8 ;
compositions longues.

**E. Corpus dégradé contrôlé** — média manquant ; miniature absente ;
référence de composition indisponible ; taxonomie utilisée ; capture non
rattachée.

**F. Formats historiques** — fixture V2 réellement représentative ; JSON
historique V3 ; ancien `.movpack` ; format courant.

**G. Conteneurs invalides** — manifeste absent ; version future ; JSON
invalide ; média corrompu ; hash incorrect ; ZIP tronqué ; fichier
supplémentaire non attendu.

Ne jamais construire les preuves uniquement autour du pack heureux.

## 8. Recette du démarrage

**Scénario installation vide**

1. installer ;
2. lancer ;
3. arriver sur Bibliothèque ;
4. voir les deux actions prévues ;
5. créer une discipline ;
6. créer la première technique ;
7. fermer complètement ;
8. relancer ;
9. retrouver la discipline.

**Scénario avec données**

1. lancer ;
2. arriver sur la destination configurée ;
3. naviguer dans les trois onglets ;
4. fermer depuis Bibliothèque ;
5. relancer ;
6. vérifier l'état attendu.

**Scénario migration**

1. installer une version précédente compatible ;
2. créer des données ;
3. mettre à jour l'APK ;
4. lancer ;
5. appliquer la migration ;
6. vérifier les données et médias.

## 9. Recette Bibliothèque

Vérifier : une discipline par pratique ; packs non affichés comme
disciplines ; compte des identités uniques ; recherche nom ; recherche
alias ; recherche dans Mon carnet ; recherche multisource sans doublon ;
filtre source ; filtre niveau ; filtre famille ; filtres cumulés ; état
aucun résultat ; réinitialisation ; retour fiche vers position
précédente ; changement d'onglet et restauration.

Tester : nom long ; technique sans média ; technique à plusieurs voix ;
source sans nom parfait ; plusieurs centaines de cartes ; hors ligne.

## 10. Recette fiche technique

Vérifier : média principal immédiatement visible ; fallback propre ;
lecture vidéo locale ; lien distant hors connexion ; galerie ;
changement de média principal ; sources lisibles ; plusieurs voix non
fusionnées ; contribution importée protégée ; Mon carnet éditable ;
recherche actualisée après édition ; ajout de plusieurs médias ; média
manquant ; relations ; navigation vers une technique liée ; compositions
utilisatrices ; favori ; retrait sécurisé.

Aucun identifiant interne ne doit apparaître dans l'interface normale.

## 11. Recette création et capture

Vérifier : création avec nom seul ; classification facultative ;
suggestion de doublon ; absence de fusion automatique ; caméra ; fichier ;
lien ; texte ; rattachement à une technique ; création depuis capture ;
provenance personnelle par défaut ; enseignement attribué ; garder pour
plus tard ; fermeture et relance ; reprise ; abandon ; nettoyage ; refus
de permission Android ; interruption en arrière-plan ; mode hors ligne.

Aucun contenu validé ne doit disparaître après un retour Android normal.

## 12. Recette Pratique

**Favoris :** ajouter ; ouvrir ; revenir ; retirer ; restaurer.

**À reprendre :** afficher uniquement une action réelle ; rattacher ;
créer ; supprimer ; disparaître après résolution.

**Compositions :** créer avec titre seul ; ajouter technique ; ajouter
texte ; réordonner ; modifier ; dupliquer ; supprimer ; relancer ; mode
entraînement ; ouvrir une fiche ; revenir au bon bloc ; technique
indisponible ; export ; import ; restauration.

Tester une composition d'au moins cinquante blocs.

## 13. Recette Atelier

**Construire :** créer discipline ; renommer ; retirer une discipline
vide ; bloquer une suppression incohérente ; créer et réordonner les
taxonomies ; contrôler leurs usages ; gérer les types de relation.

**Médias et qualité :** média manquant ; média orphelin ; média partagé ;
miniature ; contribution sans auteur ; rapprochement ambigu ; référence
de composition invalide.

**Échanger et protéger :** import valide ; annulation avant mutation ;
import corrompu ; rapport ; publication filtrée ; exclusion du
personnel ; sauvegarde complète ; restauration ; rollback.

**Réglages :** démarrage ; thème ; protection ; fallback d'une
destination supprimée.

## 14. Recette sécurité

**Appareil personnel :** aucune demande de PIN ; modification directe ;
confirmation destructive conservée.

**Protection des modifications :** activation ; création du PIN ; action
protégée ; annulation ; déverrouillage ; session ; expiration.

**Protection des suppressions :** modification libre si configurée
ainsi ; PIN avant destruction ; confirmation après PIN ; sauvegarde
préalable.

**Tablette partagée :** consultation libre ; médias lisibles ; mode
entraînement utilisable ; modifications protégées ; arrière-plan
verrouillant ; verrouillage manuel.

Vérifier : aucun PIN en clair ; aucune valeur secrète dans les logs ;
aucun secret dans un pack publié ; restauration ne transportant pas
automatiquement le secret ; temporisation après erreurs ; changement du
PIN ; désactivation ; réinitialisation.

## 15. Recette médias

Cas obligatoires : même fichier utilisé deux fois ; retrait de la
première référence ; fichier encore disponible ; retrait de la dernière
référence ; statut orphelin ; suppression après confirmation ;
restauration selon la stratégie documentée.

**Déduplication :** deux imports du même fichier ; même empreinte ; une
seule copie physique ; plusieurs références logiques.

**Échec :** quota ; interruption ; fichier non lisible ; type incorrect ;
média absent ; registre incohérent.

Après chaque échec : état métier valide ; aucun média fantôme ; aucun
fichier temporaire non diagnostiqué ; possibilité de reprendre ou
nettoyer.

## 16. Recette `.movpack`

Pour chaque conteneur courant : vérifier signature ZIP ; lire le
manifeste ; valider version ; valider inventaire ; valider tailles ;
valider empreintes ; vérifier les médias ; importer ; comparer les
données.

Tester : pack publié ; sauvegarde complète ; export de composition ;
format historique ; version future ; corruption ; fichier manquant ;
fichier supplémentaire ; média modifié ; JSON brut.

Un import refusé ne doit produire aucune mutation visible.

## 17. Recette sauvegarde et restauration

**Scénario de référence**

1. créer plusieurs disciplines ;
2. ajouter plusieurs sources ;
3. ajouter vidéos et notes ;
4. ajouter Favoris ;
5. créer Compositions ;
6. créer une capture à reprendre ;
7. créer une sauvegarde complète ;
8. inspecter son manifeste ;
9. désinstaller l'application de recette ;
10. réinstaller ;
11. restaurer ;
12. comparer l'état.

Comparer au minimum : disciplines ; identités ; contributions ; sources ;
taxonomies ; relations ; médias ; Favoris ; Compositions ; blocs et
ordre ; captures à reprendre ; paramètres fonctionnels annoncés.

Lire réellement plusieurs vidéos après restauration.

Une simple égalité des compteurs ne suffit pas.

## 18. Recette publication

Créer un pack de club contenant uniquement les données maîtrisées.

Vérifier : auteur ; organisation ; version ; discipline ; contributions
sélectionnées ; médias sélectionnés ; relations valides ; aucune note
personnelle ; aucun favori ; aucune capture à reprendre ; aucun PIN ;
aucune sauvegarde ; aucune contribution tierce non sélectionnée.

Importer le pack sur une installation vierge.

Vérifier que le corpus reste utilisable sans les données privées de
l'émetteur.

## 19. Recette Android

Construire depuis un environnement propre.

Tester sur appareil réel : installation ; premier lancement ;
permissions ; caméra ; sélection de fichiers ; partage ; import depuis
Files ; retour Android ; clavier ; arrière-plan ; orientation ; mise à
jour APK ; désinstallation ; restauration ; hors ligne ; tablette si
disponible.

Relever : modèle de terminal ; version Android ; taille écran ;
orientation ; résultat.

Ne pas déclarer Android validé uniquement sur émulateur.

## 20. Recette web et plateformes

**Navigateur desktop :** lancement ; stockage ; import ; export ; lecture
média ; clavier ; hors ligne selon capacité réelle.

**PWA :** tester uniquement si elle est déclarée livrée ; installation ;
lancement hors ligne ; mise à jour ; stockage.

**Windows/Electron :** tester uniquement si réellement livré ; sinon
maintenir le statut `absent` ou `différé`.

La matrice de plateformes doit correspondre aux preuves.

## 21. Recette visuelle

Résolutions minimales : petit téléphone ; téléphone standard ; tablette
portrait ; tablette paysage ; desktop.

États : clair ; sombre ; système ; texte agrandi ; réduction des
animations ; nom long ; contenu vide ; contenu riche ; erreur ; média
manquant.

Vérifier : aucun chevauchement ; aucune action sous la barre système ;
aucune carte coupée ; aucun bouton inaccessible ; navigation basse
stable ; une seule action principale ; pas de Capturer global ; Atelier
sans mur de texte ; grille média-first ; mode entraînement lisible à
distance.

## 22. Accessibilité

Vérifier au minimum : focus visible ; navigation clavier ; libellé des
actions ; boutons iconiques accessibles ; contraste ; taille tactile ;
erreur annoncée ; état ouvert des accordéons ; alternatives au
glisser-déposer ; contenu compréhensible sans couleur ; réduction des
animations.

Documenter les limites restantes.

Ne pas déclarer une conformité complète à un référentiel sans audit
dédié.

## 23. Performance

Établir une ligne de base avant correction : lancement ; ouverture
Bibliothèque ; recherche ; filtrage ; ouverture fiche ; galerie ;
ouverture Pratique ; réordonnancement ; ouverture Atelier ; export ;
restauration.

Mesurer sur : petit corpus ; corpus volumineux ; appareil Android réel
lorsque possible.

Règles : aucune opération interactive longue sans feedback ; aucune
vidéo complète chargée pour une simple miniature ; un seul lecteur
actif ; export à mémoire bornée ; pas de régression manifeste après les
corrections.

Ne pas effectuer une optimisation générale sans anomalie démontrée.

## 24. Nettoyage avant release

Retirer du build de production : logs de débogage excessifs ; secrets ou
valeurs de test ; routes mortes visibles ; boutons factices ; données
personnelles ; fichiers de test lourds ; JSON de développement présentés
comme contenu produit ; dépendances inutilisées manifestes ; feature
flags abandonnés ; textes `TODO` visibles ; identifiants internes
affichés.

Ne pas supprimer : fixtures nécessaires aux tests ; migrations
historiques ; lecteurs rétrocompatibles ; diagnostics utiles.

Faire la distinction entre : code mort prouvé ; code de compatibilité.

## 25. Lot 10A — rapport d'audit

À la fin de 10A, produire : résultats de toutes les commandes ; matrice
des capacités ; liste des anomalies ; sévérité ; reproduction ; lot
concerné ; données touchées ; proposition de correction ; risque de
correction ; estimation relative ; décision recommandée.

Ne corriger aucun P2 ou P3 pendant l'audit.

S'arrêter après le rapport 10A.

**La suite ne commence qu'après validation humaine du plan fermé de
P0/P1.**

## 26. Lot 10B — règle de correction

Pour chaque P0 ou P1 validé :

1. ajouter ou isoler un scénario reproductible ;
2. identifier la cause racine ;
3. proposer la correction minimale ;
4. vérifier les données existantes ;
5. implémenter ;
6. ajouter le test de non-régression ;
7. exécuter les tests voisins ;
8. documenter ;
9. committer.

Ne pas profiter d'un bug pour : renommer toute une architecture ;
déplacer plusieurs modules ; remplacer une bibliothèque ; réécrire un
workflow ; modifier le modèle hors nécessité.

Une modification de modèle exige : migration ; test d'ancienne donnée ;
justification ; preuve de non-perte.

## 27. Critères de sortie de 10B

10B peut se terminer lorsque : aucun P0 ouvert ; aucun P1 ouvert ; tests
de non-régression ajoutés ; build propre ; données de fixtures migrées ;
APK produit ; matrice mise à jour.

Les P2 et P3 restent dans un backlog séparé.

Ne pas les corriger pour obtenir artificiellement une liste vide.

## 28. Lot 10C — recette à blanc

Repartir de zéro : nouveau clone ou espace propre ; installation
propre ; aucune donnée de développement ; génération des artefacts ;
installation APK ; jeu de recette versionné.

Exécuter la totalité des scénarios critiques sans intervenir dans le
code.

Toute correction pendant cette phase :

- invalide la recette ;
- nécessite un nouveau commit ;
- impose de relancer les scénarios affectés ;
- produit une nouvelle version candidate.

## 29. Scénarios critiques de bout en bout

**Scénario 1 — installation vide**

```
installation
→ Bibliothèque
→ créer discipline
→ créer technique
→ ajouter média
→ relancer.
```

**Scénario 2 — import multisource**

```
importer référentiel
→ importer club
→ identité réunie
→ deux voix
→ recherche
→ filtre source.
```

**Scénario 3 — pratique personnelle**

```
ouvrir fiche
→ ajouter repère
→ favori
→ composition
→ mode entraînement
→ retour fiche.
```

**Scénario 4 — capture terrain**

```
filmer
→ garder pour plus tard
→ fermer
→ relancer
→ rattacher
→ lire sur la fiche.
```

**Scénario 5 — tablette partagée**

```
activer protections
→ consulter
→ tenter modification
→ déverrouiller
→ modifier
→ expiration.
```

**Scénario 6 — publication**

```
sélectionner source maîtrisée
→ prévisualiser
→ publier
→ importer sur installation vierge
→ vérifier les exclusions.
```

**Scénario 7 — perte de l'installation**

```
sauvegarder
→ désinstaller
→ réinstaller
→ restaurer
→ lire médias
→ utiliser composition.
```

**Scénario 8 — corruption**

```
modifier un fichier du conteneur
→ importer
→ refus
→ état existant inchangé.
```

**Scénario 9 — mise à jour**

```
installer version précédente
→ créer données
→ installer candidate
→ migrer
→ vérifier.
```

**Scénario 10 — média partagé**

```
deux références
→ retirer une
→ média conservé
→ retirer la dernière
→ diagnostic orphelin
→ suppression confirmée.
```

## 30. Critères GO

La décision `GO` exige :

- aucun P0 ;
- aucun P1 ;
- tous les scénarios critiques réussis ;
- build reproductible ;
- APK installable ;
- navigation Android correcte ;
- sauvegarde complète démontrée ;
- restauration complète démontrée ;
- intégrité `.movpack` démontrée ;
- import corrompu sans mutation ;
- absence de secret en clair ;
- publication filtrée ;
- données conservées après mise à jour ;
- documentation alignée sur le réel ;
- plateforme annoncée réellement démontrée.

## 31. Critères GO AVEC RÉSERVES

`GO AVEC RÉSERVES` est possible uniquement si :

- aucun P0 ;
- aucun P1 ;
- uniquement des P2 connus ;
- aucune réserve ne concerne la perte de données ;
- aucune réserve ne concerne la sécurité du PIN ;
- aucune réserve ne concerne la restauration annoncée ;
- les limites sont visibles et documentées ;
- une solution de contournement existe.

Exemples possibles : PWA différée ; Windows portable absent ; aperçu
d'un service distant indisponible hors ligne ; import d'un format
historique partiel et clairement annoncé.

## 32. Critères NO-GO

Décision `NO-GO` si au moins un élément persiste : P0 ; P1 ; corruption ;
perte média ; sauvegarde inutilisable ; restauration non démontrée ;
import partiel invisible ; action destructive non maîtrisée ; protection
facilement contournable ; APK non reproductible ; migration cassée ;
workflow essentiel en impasse ; documentation affirmant une capacité non
démontrée.

Ne pas maquiller un No-Go en réserve.

## 33. Version et identification de la candidate

Produire une version candidate identifiable.

Utiliser le schéma déjà adopté par le projet.

À défaut : version applicative cohérente ; versionCode Android
incrémenté ; suffixe de candidate explicite ; commit associé ; date ;
version du modèle ; version du format.

Ne pas créer arbitrairement une version publique majeure.

Le rapport doit permettre d'associer sans ambiguïté : code ; APK ; packs
de démonstration ; documentation ; résultats de recette.

## 34. Artefacts finaux

Produire : build web ; APK debug de recette ; APK ou AAB release
uniquement si la chaîne de signature est disponible ; `.movpack` de
démonstration ; sauvegarde de démonstration ; export de composition ;
fixtures historiques ; rapport de tests ; matrice des capacités ;
matrice des plateformes ; rapport Go/No-Go ; checksums des artefacts
livrés.

Ne jamais inclure : keystore ; mot de passe ; secret CI ; données
personnelles ; PIN réel.

## 35. Documentation de reprise

Une personne ne connaissant pas le projet doit pouvoir en moins de trente
minutes :

1. comprendre le but de Movenso ;
2. cloner ;
3. installer ;
4. lancer ;
5. tester ;
6. construire le web ;
7. construire Android ;
8. importer un pack ;
9. créer une sauvegarde ;
10. comprendre les limites des plateformes.

Mettre à jour :

**README :** présentation ; prérequis ; commandes ; builds ; données ;
artefacts ; limitations.

**`docs/systeme.md` :** architecture réelle ; modèle ; stockage ;
médias ; transactions ; sécurité ; plateformes.

**`docs/workflows.md` :** workflows réellement démontrés ; captures à
jour ; niveaux de preuve.

**`docs/etat.md` :** version candidate ; résultat final ; anomalies
ouvertes ; décision ; prochaine étape éventuelle.

Matrice de conservation : capacités V2 conservées ; capacités V3
ajoutées ; capacités différées ; capacités abandonnées ; justification.

## 36. Documentation des limites

Créer une liste compacte et honnête.

Exemples : Windows portable non livré ; PWA non livrée ; snapshot ne
contenant pas les médias ; import V2 partiel ; taille maximale non
garantie ; lien externe non disponible hors ligne ; absence de
chiffrement complet.

Chaque limite contient : impact ; contournement ; risque ; priorité
future.

Ne pas dissimuler une limite dans un journal technique.

## 37. Backlog post-V3

Déplacer toutes les idées non nécessaires dans un backlog séparé.

Classer : dette critique future ; amélioration produit ; plateforme ;
confort ; recherche.

Ne pas inclure automatiquement toutes les suggestions accumulées.

Chaque entrée doit répondre à : quel problème réel ? qui est concerné ?
preuve ou observation ? pourquoi après V3 ? dépendances ?

Le backlog ne doit pas devenir une nouvelle roadmap exécutée pendant ce
lot.

## 38. Rapport final

Le rapport final commence par : version ; commit ; branche ; date ;
décision ; résumé en dix lignes maximum.

Puis :

**A. Capacités démontrées**

**B. Tests automatiques** — nombre ; résultats ; durées ; échecs
éventuels.

**C. Recette manuelle** — appareils ; plateformes ; scénarios ; preuves.

**D. Données** — import ; export ; sauvegarde ; restauration ;
intégrité ; migrations.

**E. Sécurité** — protections ; secret ; exports ; limites.

**F. Performances** — corpus ; observations ; limites.

**G. Anomalies restantes** — P2 ; P3 ; contournements.

**H. Comparaison avec V2** — objectivement supérieure ; équivalente ;
encore inférieure ; non comparable.

**I. Recommandation** — continuer V3 ; exploiter V3 avec réserves ;
revenir sur V2 ; différer une plateforme.

Ne pas conclure automatiquement que V3 est supérieure parce que les lots
sont terminés.

## 39. Comparaison finale V2 / V3

Comparer sur des preuves, pas sur l'architecture théorique.

Dimensions minimales : exploration ; médias ; capture ; création ;
personnalisation ; multisource ; provenance ; compositions ; curation ;
import/export ; sauvegarde/restauration ; Android ; Windows ; hors
ligne ; sécurité ; maintenance ; reprise du projet.

Pour chaque dimension : V2 ; V3 ; preuve ; gagnant actuel ; réserve.

La conclusion peut être : V3 supérieure globalement ; V3 supérieure sur
le modèle mais pas encore sur l'exploitation ; V2 encore supérieure
comme produit opérationnel ; choix dépendant de la plateforme.

Ne pas forcer un résultat favorable à V3.

## 40. Limites strictes du lot

Ne pas :

- ajouter de fonctionnalité ;
- changer la vision ;
- refondre le modèle ;
- refaire l'UX ;
- introduire une plateforme ;
- réorganiser les dossiers pour esthétique ;
- remplacer une dépendance sans nécessité ;
- modifier V2 ;
- fusionner dans main ;
- publier une release publique.

Les seules modifications autorisées sont : corrections P0/P1 validées ;
tests de non-régression ; documentation ; nettoyage strictement
nécessaire ; préparation d'artefacts.

## 41. Critères d'acceptation du lot

Le lot 10 est terminé uniquement lorsque :

- 10A est documenté ;
- le plan de corrections a été validé ;
- 10B ne contient aucun P0/P1 ouvert ;
- 10C a été exécuté depuis un environnement propre ;
- les dix scénarios critiques réussissent ;
- l'APK est disponible ;
- les sauvegardes et restaurations sont démontrées ;
- les artefacts sont identifiés ;
- les matrices sont à jour ;
- les limites sont explicites ;
- le rapport Go/No-Go est rendu ;
- aucune modification non committée ne subsiste.

## 42. Livrable

Produire trois commits dédiés :

- `lot-10a-audit`
- `lot-10b-stabilisation`
- `lot-10c-recette`

Adapter les messages aux conventions existantes du dépôt.

Ne pas fusionner.

Livrables finaux :

- APK de recette ;
- build web ;
- packs de démonstration ;
- sauvegarde démonstrative ;
- checksums ;
- matrice des capacités ;
- matrice des plateformes ;
- rapport de recette ;
- rapport V2/V3 ;
- décision Go/No-Go ;
- backlog hors périmètre.

**La réussite de ce lot se mesure à une chose : une personne extérieure
au développement peut installer Movenso, l'utiliser, lui confier des
données, sauvegarder ces données, perdre l'installation, les restaurer
et comprendre précisément ce qui est fiable, ce qui reste limité et
pourquoi la version peut — ou non — être retenue comme nouvelle base du
produit.**
