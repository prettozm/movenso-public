# Dossier S1.10 — Stockage : environnements non compatibles et emplacement des données

> **Phase : STABILISATION V1** · Instruction pure (AUCUN code) — rédigé le 2026-08-02
> pour arbitrage porteur (D-163 : « on traite après, tout seul, car besoin de
> préciser l'implémentation et les cas possibles »). Pistes porteur consignées
> en D-162 : sauvegarde portable, emplacement manuel Plus › Stockage,
> `.movmedia` sous `Documents/movenso/` selon l'appareil.

## 1. Constat du comportement actuel

- **Garde de démarrage D-110** (`racine.ts #demarrer`) : si `navigator.storage.getDirectory`
  manque, un message clair s'affiche au lieu d'un écran blanc. **Deux faiblesses** :
  1. le message est rédigé POUR Android (« Mets à jour Android System WebView (Play
     Store) ») — trompeur sur un Firefox ancien ou un Safari de bureau ;
  2. la garde ne teste que `getDirectory`, pas `createWritable` (utilisé par toutes
     nos écritures) — **Safari expose le premier mais pas le second sur le fil
     principal** : il passerait la garde puis échouerait plus loin, en erreur brute.
- **Persistance** : demandée ET affichée depuis S1.9 (carte Espace, bouton redemander).
- **Échappatoire portable** : la sauvegarde complète `.movpack` existe (web : téléchargement ;
  APK : `Documents/Movenso/` via l'API native — le code d'écriture native par blocs
  existe déjà, `#ecrireFichierNatifParBlocs`).

## 2. Faits par plateforme (vérifiés)

| Capacité | Chrome/Edge desktop | Chrome Android | Firefox | Safari | APK (Capacitor) |
|---|---|---|---|---|---|
| OPFS (`getDirectory`) | ✅ | ✅ | ✅ (≥111) | ⚠️ partiel | ✅ (WebView) |
| `createWritable` (nos écritures) | ✅ | ✅ | ✅ | ❌ fil principal | ✅ |
| « Choisir un dossier » (File System Access) | ✅ | ❌ | ❌ | ❌ | n/a (API native) |
| Écriture `Documents/movenso/` | ❌ (hors FSA) | ❌ | ❌ | ❌ | ✅ (déjà utilisée pour les exports) |
| Visibilité galeries/Fichiers | n/a (OPFS invisible) | n/a | n/a | n/a | visible si Documents/ |

Points structurants :
- **OPFS est invisible des galeries par nature** — la « pollution » n'existe que si on
  écrit des fichiers *visibles* (Documents/). Sur Android, la convention **`.nomedia`**
  (fichier vide dans le dossier) exclut tout le dossier des galeries — plus simple que
  renommer chaque média. Le renommage **`.movmedia`** ajoute un choix produit distinct :
  médias illisibles par les autres apps (confidentialité ↑, interopérabilité ↓).
- **« Choisir un emplacement » n'est PAS universalisable** : l'API n'existe que sur
  Chrome/Edge **de bureau**. Toute option « emplacement choisi » est donc par canal,
  jamais uniforme.
- Le modèle actuel est documenté (systeme.md §5bis) : *la propriété des données passe
  par l'export/sauvegarde, jamais par l'accès manuel au stockage privé*.

## 3. Options

### Option 1 — Statu quo durci (recommandée pour la v1) — ~2 boucles
1. **Garde D-110 généralisée** : tester `getDirectory` ET `createWritable` ; message par
   plateforme (Android → WebView ; desktop → « navigateurs supportés : Chrome, Edge,
   Firefox récent » ; Safari → dit explicitement non supporté) ; **écran propre** avec la
   liste des navigateurs et l'échappatoire (« tes données restent transportables par
   sauvegarde ») — critères exacts de l'audit P0.10.
2. Rien d'autre ne change : OPFS partout, persist() + gardes d'espace (S1.9), sauvegarde
   portable comme propriété des données.
   *Risque résiduel accepté* : éviction navigateur théorique (mitigée par persist(),
   dite honnêtement dans la carte Espace) ; pas d'accès direct aux fichiers (choix
   documenté). **Zéro migration, zéro nouveau backend.**

### Option 2 — Hybride par canal (chantier post-v1 si le besoin émerge) — ~8-15 boucles + décisions
- Web : comme option 1. — **APK** : médias sous `Documents/movenso/medias/` (+ `.nomedia`,
  et/ou noms `.movmedia` si confidentialité voulue), métadonnées restant internes ;
  index par id + empreinte, détection des fichiers déplacés/supprimés hors app.
  — **Desktop Chrome/Edge** : « Choisir un emplacement » optionnel (File System Access,
  permission persistante, reprise au démarrage, dossier déplacé/lecture seule à gérer).
- Exige : migration des vidéos existantes, contrat de backend (l'interface à ~15
  méthodes esquissée par la roadmap écartée), recette par plateforme, scénarios
  « permission retirée / dossier renommé / quota ». C'est le vrai « Lot stockage ».

### Option 3 — Emplacement choisi partout — ÉCARTÉE (fait de plateforme)
Impossible sur Chrome Android et Firefox/Safari : l'expérience ne serait jamais uniforme,
et le canal principal (mobile) resterait en OPFS de toute façon.

## 4. Recommandation

**Option 1 pour la v1** (elle ferme le point P0.10 de l'audit avec les critères exacts),
en notant l'option 2 comme chantier post-v1 déclenchable sur besoin réel (gros volumes,
interopérabilité). La piste `.movmedia`/`Documents/movenso` reste pertinente **dans le
cadre de l'option 2 uniquement** ; `.nomedia` suffirait contre les galeries.

**Arbitrage attendu du porteur** : option 1 / option 2 maintenant / option 1 + option 2
planifiée post-v1 (recommandé) — et, si option 2 un jour : `.movmedia` ou `.nomedia` seul.
