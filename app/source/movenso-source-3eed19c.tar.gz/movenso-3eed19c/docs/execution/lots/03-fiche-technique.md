# LOT 3 — FICHE TECHNIQUE : CONSULTER, COMPRENDRE ET ENRICHIR UNE TECHNIQUE

## Contexte

Le lot 1 a mis en place une navigation à trois onglets :

- Bibliothèque ;
- Pratique ;
- Atelier.

Le lot 2 a fait de la Bibliothèque le centre d'exploration :

- disciplines uniques ;
- recherche globale ;
- grille visuelle ;
- filtres cumulables ;
- filtres par source ;
- création d'une première technique dans une discipline vide.

La fiche technique actuelle possède de bonnes fondations :

- identité technique commune ;
- contributions séparées par provenance ;
- média principal ;
- carnet personnel ;
- relations ;
- compositions utilisant la technique ;
- édition contextuelle partielle.

Cependant, l'expérience actuelle reste insatisfaisante :

- le média n'est pas toujours suffisamment dominant ;
- la succession verticale des voix, relations et actions produit un écran
  long ;
- des libellés techniques ou génériques comme « Club » ne donnent pas
  clairement l'autorité réelle ;
- l'utilisateur doit parfois passer par `Capturer` pour modifier un simple
  commentaire personnel ;
- l'édition ne rend pas toujours explicite ce qui est modifiable et
  pourquoi ;
- le workflow d'ajout de plusieurs vidéos n'est pas visible ;
- `Retirer` et `Terminer` sont exposés comme des actions normales alors
  qu'ils ne le sont pas ;
- les relations prennent trop de place ou reposent sur un vocabulaire
  difficile à comprendre ;
- les compositions utilisant la technique ne disposent pas encore d'un
  accès compact et naturel.

Ce lot porte **exclusivement** sur la fiche technique et ses actions
directement liées :

- consultation ;
- hiérarchie visuelle ;
- médias ;
- voix et sources ;
- contribution personnelle ;
- édition contextuelle ;
- relations compactes ;
- compositions utilisant la technique ;
- actions secondaires et destructrices.

Il ne refond pas :

- le workflow global de capture non rattachée ;
- le modèle physique des médias ;
- le modèle des relations ;
- le modèle des compositions ;
- l'Atelier ;
- la sécurité et le PIN ;
- la publication des packs ;
- la direction graphique globale de toute l'application.

## Objectif unique

Produire une fiche technique immédiatement utile pendant la pratique,
permettant de :

1. voir et lire le média principal sans défiler ;
2. identifier la technique et ses classifications essentielles ;
3. comprendre qui affirme quoi ;
4. consulter les différentes voix sans les mélanger ;
5. modifier directement ses propres contenus ;
6. ajouter plusieurs médias à la technique ;
7. accéder aux relations et compositions sans créer un mur vertical ;
8. protéger les contenus sourcés et les actions destructrices.

## 1. Structure générale de la fiche

La fiche doit suivre cette hiérarchie :

1. en-tête compact ;
2. média principal ;
3. informations essentielles ;
4. voix et contenus ;
5. accès compact aux relations et compositions ;
6. actions secondaires.

L'utilisateur ne doit pas traverser de longs blocs textuels avant
d'atteindre la vidéo.

Éviter une structure constituée uniquement d'une succession de grandes
cartes arrondies.

La fiche doit rester lisible :

- sur téléphone en portrait ;
- sur tablette ;
- avec ou sans média ;
- avec une seule voix ;
- avec plusieurs voix ;
- avec ou sans contribution personnelle ;
- avec ou sans relations ;
- avec ou sans composition associée.

## 2. En-tête

L'en-tête contient :

- bouton retour ;
- nom principal de la technique ;
- nom traditionnel ou appellation secondaire lorsqu'il existe ;
- action secondaire compacte de type menu `⋮`.

Ne pas afficher dans l'en-tête :

- un bouton `Retirer` ;
- un bouton `Terminer` ;
- un bouton global `Capturer` ;
- plusieurs icônes d'administration alignées sans libellé.

Le retour doit restaurer exactement l'état de l'explorateur :

- filtres ;
- recherche ;
- source sélectionnée ;
- position de défilement.

Le menu secondaire peut contenir selon les droits :

- Modifier les informations générales ;
- Partager ou exporter ;
- Gérer les médias ;
- Retirer de la bibliothèque.

Les actions non disponibles ne doivent pas apparaître comme actives.

## 3. Média principal en tête

Afficher le média principal immédiatement sous l'en-tête.

Il doit être visible sans défilement significatif sur un téléphone
standard.

Le composant média doit gérer :

- vidéo locale ;
- vidéo de plateforme ;
- image ou miniature ;
- absence de média ;
- erreur de lecture ;
- média local manquant.

Afficher sous le média une légende compacte indiquant :

- source ou auteur ;
- provenance ;
- éventuellement le libellé du média.

Exemples :

```
Vidéo Kodokan · Référentiel officiel
Démonstration de Sensei Martin · Enseignement
Ma vidéo · Personnel
```

Ne pas afficher uniquement :

- `Club` ;
- `Référentiel` ;
- `Source externe` ;

lorsqu'un nom éditorial plus précis existe.

En cas d'absence de média principal :

- afficher un fallback discret ;
- proposer une action `Ajouter un média` si l'utilisateur possède les
  droits nécessaires ;
- ne pas afficher un grand rectangle vide sans explication.

## 4. Choix du média principal

La fiche doit permettre de consulter les autres médias associés.

Sous le média principal, afficher un accès compact :

- miniatures horizontales ;
- compteur `3 médias` ;
- ou bouton `Voir les médias`.

Ne pas afficher toutes les vidéos en pleine taille les unes sous les
autres.

L'utilisateur doit pouvoir :

- ouvrir un autre média ;
- voir sa source et sa provenance ;
- le lire ;
- revenir au média principal ;
- définir comme média principal un média qu'il maîtrise, selon les règles
  existantes ;
- ajouter un nouveau média.

Ne pas modifier dans ce lot les règles internes de stockage ou de
propriété.

Si le choix du média principal est global à l'identité, rendre
explicitement visible l'effet de l'action :

`Utiliser comme aperçu principal de cette technique`

Ne pas laisser croire que cela modifie le média officiel d'un pack source.

Si le comportement actuel permet à un pack importé de remplacer
silencieusement le média principal, tracer le risque et empêcher l'action
silencieuse dans l'interface.

## 5. Ajouter un média depuis la fiche

Ajouter une action clairement visible :

`Ajouter un média`

Elle doit être accessible :

- sous le média principal ;
- ou dans la galerie des médias ;
- ou dans le menu secondaire.

Elle ne doit pas nécessiter de quitter la fiche pour lancer un flux
générique `Capturer`.

Le workflow doit proposer selon les capacités existantes :

- Filmer maintenant ;
- Choisir une vidéo ou un fichier de l'appareil ;
- Coller un lien ;
- éventuellement choisir un média déjà présent dans la bibliothèque si
  cette capacité existe réellement.

Après ajout :

- le média apparaît immédiatement dans la galerie ;
- l'utilisateur voit la provenance et l'auteur appliqués ;
- le média peut être choisi comme principal ;
- le retour reste sur la fiche.

Si une information est nécessaire, poser uniquement les questions
utiles :

- qui a produit ce média ?
- quelle nature de contribution ?
- quel libellé facultatif ?

Ne pas demander à nouveau la technique : la fiche ouverte la détermine
déjà.

## 6. Informations essentielles

Sous le média, afficher de manière compacte :

- discipline ;
- familles ou catégories ;
- niveaux ;
- alias ou appellations utiles ;
- éventuelle pluralité des voix.

Ne pas afficher des identifiants techniques.

Ne pas afficher toutes les métadonnées du modèle dans la vue principale.

Les niveaux et taxonomies utilisent les données réelles :

- libellés ;
- ordre ;
- couleurs lorsqu'elles existent.

L'utilisateur doit pouvoir ouvrir une édition contextuelle des
informations générales lorsqu'il possède les droits nécessaires.

Cette édition porte uniquement sur les propriétés réellement modifiables
au niveau de l'identité ou de son propre corpus.

Ne pas permettre de réécrire silencieusement les informations
appartenant à un référentiel importé.

## 7. Voix et contributions

La fiche doit rendre perceptible le principe :

**Une technique, plusieurs voix.**

Cependant, elle ne doit pas afficher toutes les contributions sous forme
de grandes cartes intégralement ouvertes.

Présenter les voix dans une zone compacte, par exemple :

- liste repliable ;
- onglets ;
- accordéon ;
- sélecteur de source ;
- aperçu suivi de `Lire la suite`.

Une seule voix peut être ouverte à la fois par défaut.

Ordre recommandé :

1. voix correspondant au média principal ou à la source sélectionnée
   depuis la Bibliothèque ;
2. référentiel ;
3. enseignement ;
4. ressource ;
5. personnel.

Cet ordre peut être adapté si les données ou le contexte indiquent une
meilleure hiérarchie.

Chaque voix affiche au minimum :

- auteur ou organisation ;
- nom éditorial de la source ;
- provenance ;
- texte ou points clés ;
- médias propres à cette contribution ;
- possibilité de modification uniquement lorsque l'utilisateur la
  maîtrise.

Ne pas utiliser le seul mot `Club` comme titre lorsque le nom du club ou
du pack est disponible.

Exemples :

```
Enseignement · Judo Club de Castres
Référentiel · Kodokan
Ressource · Jean Dupont
Personnel · Moi
```

## 8. Modification des voix

Une contribution sourcée importée reste protégée.

L'utilisateur ne modifie pas directement :

- une contribution Kodokan importée ;
- une contribution fédérale ;
- une contribution issue d'un pack tiers non maîtrisé.

Il peut :

- ajouter sa propre contribution ;
- ajouter une contribution de club ou de sensei s'il en est le curateur ;
- créer une adaptation distincte ;
- masquer localement un contenu si cette capacité existe déjà ;
- corriger les métadonnées qu'il maîtrise.

L'interface doit expliquer la règle sans jargon.

Exemple :

```
Ce contenu vient du pack Kodokan et n'est pas modifiable ici.
Tu peux ajouter une note ou une contribution distincte.
```

Ne pas désactiver silencieusement un champ sans explication.

## 9. Mon carnet

`Mon carnet` est une zone personnelle directement éditable depuis la
fiche.

L'utilisateur ne doit pas être obligé de lancer `Capturer` pour :

- ajouter un mot ;
- saisir une phrase ;
- corriger son commentaire ;
- effacer une note personnelle.

Comportement attendu :

- état vide : `Ajouter un repère personnel` ;
- état rempli : texte visible avec action d'édition discrète ;
- appui : édition directe ou panneau léger ;
- sauvegarde : automatique ou action `Enregistrer` clairement localisée ;
- annulation : comportement explicite.

Le texte peut être :

- un mot ;
- un moyen mnémotechnique ;
- une phrase ;
- une explication développée.

Ne pas imposer :

- deux lignes ;
- une taxonomie ;
- un type `note`, `repère` ou `commentaire`.

Le stockage reste une contribution personnelle selon le modèle actuel.

Le texte personnel doit rester indexé par la recherche de la
Bibliothèque.

La suppression du texte personnel ne supprime jamais la technique.

## 10. Édition contextuelle

Distinguer clairement trois types d'édition.

**A. Informations générales de l'identité**

Exemples :

- nom local ;
- nom traditionnel ;
- familles ;
- niveaux ;
- média principal.

Accessible uniquement selon les droits et les règles du modèle.

**B. Contribution maîtrisée**

Exemples :

- texte du club ;
- points clés du sensei ;
- média d'une contribution locale ;
- attribution.

**C. Contenu personnel**

Exemples :

- note ;
- repère ;
- média personnel.

L'interface ne doit pas présenter un unique grand formulaire mélangeant
ces trois responsabilités.

Privilégier :

- édition au point d'usage ;
- panneaux ciblés ;
- formulaires courts ;
- sauvegarde explicite uniquement lorsque nécessaire.

Ne pas placer un crayon sur chaque carte de la Bibliothèque.

La fiche est le point d'entrée principal de l'édition contextuelle.

## 11. Relations

Les relations restent visibles, mais dans une zone compacte.

Afficher par exemple :

```
Relations · 6
```

avec un aperçu limité :

- 2 ou 3 relations ;
- nom de la relation ;
- technique cible ;
- flèche ou direction compréhensible.

Une action `Voir toutes les relations` ouvre :

- un panneau ;
- une sous-vue ;
- ou une section développée.

Ne pas afficher toutes les relations en pleine longueur en bas de fiche.

Chaque relation doit montrer :

- libellé utilisateur ;
- direction ;
- technique cible ;
- éventuelle source ou auteur lorsque disponible.

Ne pas afficher les identifiants internes des types de relation.

Toucher une technique liée ouvre sa fiche.

Le bouton retour revient à la fiche précédente sans perdre le contexte.

Ne pas modifier le modèle des types de relation dans ce lot.

Ne pas créer de nouvelles relations automatiques.

## 12. Compositions utilisant la technique

Afficher un accès compact :

```
Utilisée dans · 3 compositions
```

L'aperçu peut montrer :

- nom des compositions ;
- position ou contexte lorsque disponible ;
- type éditorial facultatif si le modèle le porte déjà.

Toucher une composition ouvre sa consultation dans l'onglet Pratique.

Le retour revient à la fiche technique.

Ne pas afficher toutes les étapes des compositions sur la fiche.

Ne pas confondre :

- relations du graphe ;
- transitions dans une composition ;
- présence de la technique dans une composition.

Si aucune composition n'utilise la technique, la section peut être
absente.

Ne pas ajouter depuis cette zone un workflow complexe de création de
composition dans ce lot.

## 13. Favoris

Si le modèle de favoris existe déjà, permettre depuis la fiche :

- ajouter aux favoris ;
- retirer des favoris.

L'action doit être simple et immédiatement compréhensible.

Elle ne doit pas modifier la technique elle-même.

Les favoris seront organisés dans l'onglet Pratique lors du lot
correspondant.

Si le modèle de favoris n'existe pas encore :

- ne pas le créer dans ce lot ;
- ne pas afficher un bouton factice ;
- tracer le besoin pour le lot Pratique.

## 14. Partage et export de la technique

Si le workflow actuel permet réellement l'export d'une technique :

- rendre l'action accessible dans le menu secondaire ;
- utiliser un libellé explicite : `Exporter cette technique` ou `Partager
  cette technique`.

Avant export, indiquer ce qui sera inclus :

- identité ;
- contributions sélectionnées ;
- médias ;
- carnet personnel ou non.

Le carnet personnel ne doit jamais être partagé par défaut.

Si le workflow V3 ne permet pas encore une exportation sûre à cette
granularité :

- ne pas créer un bouton qui promet plus que ce qui existe ;
- tracer la capacité comme différée ;
- ne pas modifier le format `.movpack` dans ce lot.

## 15. Action de retrait

`Retirer` ne doit jamais apparaître comme action principale à côté de
l'édition.

La placer dans :

- menu secondaire ;
- section danger ;
- ou écran de gestion approprié.

Le libellé doit expliquer précisément l'effet.

Exemples selon le comportement réel :

```
Retirer cette technique de ma bibliothèque
Supprimer uniquement mon contenu personnel
Retirer les contenus issus de cette source
```

Ne pas employer un terme ambigu si l'action peut :

- détacher des notes ;
- supprimer une identité ;
- supprimer des médias ;
- affecter des compositions ;
- retirer une contribution importée.

Avant confirmation, afficher :

- les données concernées ;
- les compositions ou relations impactées ;
- l'existence d'une sauvegarde automatique ;
- le comportement de restauration.

Toute action destructive doit respecter les protections existantes :

- confirmation ;
- snapshot ou sauvegarde préalable ;
- absence de suppression silencieuse ;
- refus si l'opération est incohérente.

Ne pas refondre le PIN dans ce lot.

## 16. Suppression du bouton `Terminer`

Supprimer `Terminer` de la fiche stable.

Ce libellé n'a de sens que dans un workflow temporaire.

Utiliser selon le contexte :

- Enregistrer ;
- Annuler ;
- Fermer ;
- retour automatique après sauvegarde.

Si l'édition est inline avec sauvegarde automatique, afficher une
confirmation discrète :

```
Enregistré
```

Ne pas ajouter un bouton de validation permanent en bas de la fiche de
consultation.

## 17. États particuliers

**A. Technique avec une seule voix et aucun média**

- nom ;
- informations essentielles ;
- fallback média ;
- voix unique ;
- action d'ajout selon les droits.

**B. Technique à plusieurs voix**

- une seule identité ;
- média principal ;
- sélecteur de voix ;
- sources claires ;
- aucune duplication du nom ou de la fiche.

**C. Technique personnelle uniquement**

- ne pas la présenter comme un référentiel ;
- permettre modification complète des contenus maîtrisés.

**D. Média local manquant**

- expliquer le problème ;
- ne pas afficher un lecteur cassé sans message ;
- proposer selon les capacités : remplacer ; retirer la référence ;
  ouvrir le diagnostic dans l'Atelier.

**E. Technique utilisée dans une composition**

- empêcher une suppression silencieuse ;
- informer des dépendances.

**F. Contribution sans auteur explicite**

- utiliser un fallback lisible ;
- ne jamais afficher `undefined`, UUID ou slug brut.

## 18. Accessibilité et ergonomie

Les actions principales doivent avoir :

- libellé accessible ;
- zone tactile suffisante ;
- retour visuel ;
- contraste correct.

Ne pas reposer uniquement sur :

- une couleur de provenance ;
- une icône sans texte ;
- un filet coloré ;
- une position visuelle.

Les sections repliables doivent indiquer :

- état ouvert ou fermé ;
- titre ;
- nombre d'éléments lorsque pertinent.

Le lecteur vidéo doit être accessible au clavier sur web et utilisable au
toucher sur Android.

Les textes longs doivent rester lisibles sans largeur excessive sur
tablette.

## 19. Conservation de l'état

La fiche conserve pendant la session :

- voix ouverte ;
- média sélectionné ;
- position de défilement si l'utilisateur ouvre temporairement une
  relation ou composition ;
- état d'édition non enregistré lorsque le système le permet.

Retour vers la Bibliothèque :

- restaure l'explorateur ;
- ne réinitialise pas les filtres ;
- ne recharge pas inutilement les médias.

Navigation vers une technique liée puis retour :

- revient à la fiche précédente ;
- conserve le média et la voix précédemment consultés.

## 20. Performance

Ne pas charger toutes les vidéos en mémoire à l'ouverture de la fiche.

Charger :

- métadonnées ;
- miniatures ;
- média sélectionné lorsque nécessaire.

Ne pas instancier plusieurs lecteurs vidéo actifs simultanément.

Les voix repliées ne doivent pas déclencher inutilement le chargement de
tous leurs médias.

Ne pas modifier le stockage OPFS dans ce lot.

## 21. Limites strictes du lot

Ne pas modifier :

- le modèle métier identité/contribution ;
- le rapprochement inter-packs ;
- le modèle physique des médias ;
- le format `.movpack` ;
- les compositions ;
- les types de relation ;
- la sécurité et le PIN ;
- la publication ;
- la Bibliothèque ;
- l'architecture détaillée de l'Atelier ;
- la direction graphique globale de l'application.

Les adaptations autorisées concernent uniquement :

- présentation de la fiche ;
- actions contextuelles ;
- galerie des médias ;
- édition des contenus déjà supportés ;
- ajout de médias via les services existants ;
- navigation vers relations et compositions ;
- clarification des actions destructrices.

Toute faiblesse du modèle identifiée doit être documentée, pas corrigée
silencieusement dans ce lot.

## 22. Critères d'acceptation

**Scénario A — consultation immédiate**

1. ouvrir une technique depuis la Bibliothèque ;
2. voir le média principal sans défiler ;
3. lire son origine ;
4. voir le nom, l'appellation et les niveaux ;
5. revenir ;
6. retrouver l'explorateur inchangé.

**Scénario B — plusieurs voix**

1. ouvrir Harai-goshi ;
2. voir une seule fiche ;
3. identifier clairement Kodokan et le club ;
4. ouvrir chaque voix ;
5. vérifier que les contenus ne sont pas fusionnés ;
6. ne voir aucun identifiant technique de pack.

**Scénario C — carnet personnel**

1. ouvrir une technique sans note personnelle ;
2. choisir Ajouter un repère personnel ;
3. saisir `coup de volant` ;
4. enregistrer sans passer par Capturer ;
5. revenir dans la Bibliothèque ;
6. rechercher `coup de volant` ;
7. retrouver la technique ;
8. réouvrir et modifier directement le texte.

**Scénario D — plusieurs médias**

1. ouvrir une fiche ;
2. voir le média principal ;
3. choisir Ajouter un média ;
4. ajouter un lien ;
5. ajouter une vidéo locale ou filmer ;
6. voir les deux médias dans la galerie ;
7. lire chacun ;
8. choisir l'un comme média principal ;
9. revenir après relance et retrouver le choix.

**Scénario E — contribution protégée**

1. ouvrir une voix Kodokan ;
2. constater qu'elle n'est pas directement modifiable ;
3. comprendre pourquoi ;
4. ajouter une contribution personnelle distincte ;
5. vérifier que la source originale reste intacte.

**Scénario F — relations**

1. ouvrir une technique possédant plusieurs relations ;
2. voir un aperçu compact ;
3. ouvrir toutes les relations ;
4. naviguer vers une technique liée ;
5. revenir à la fiche d'origine.

**Scénario G — compositions**

1. ouvrir une technique utilisée dans `Ma spéciale` ;
2. voir `Utilisée dans · 1` ;
3. ouvrir la composition ;
4. revenir ;
5. retrouver la fiche dans son état précédent.

**Scénario H — retrait**

1. ouvrir le menu secondaire ;
2. choisir l'action destructive ;
3. lire précisément ce qui sera retiré ;
4. annuler sans modification ;
5. recommencer et confirmer ;
6. vérifier la sauvegarde préalable ;
7. vérifier l'absence de suppression incohérente.

**Scénario I — média manquant**

1. simuler ou utiliser une référence locale absente ;
2. ouvrir la fiche ;
3. voir un état explicite ;
4. accéder à une action de résolution ;
5. ne pas avoir de lecteur cassé silencieux.

## 23. Tests

Ajouter ou adapter les tests pour couvrir :

- média principal en tête ;
- fallback sans média ;
- libellé de source éditorial ;
- plusieurs voix sur une seule identité ;
- protection d'une contribution importée ;
- édition directe du carnet personnel ;
- recherche après modification du carnet ;
- ajout de plusieurs médias ;
- choix du média principal ;
- galerie sans duplication ;
- relations compactes ;
- navigation vers une technique liée ;
- compositions utilisant la technique ;
- menu destructif ;
- suppression du bouton `Terminer` ;
- absence de bouton global `Capturer` sur la fiche ;
- retour vers l'explorateur avec état conservé.

Ajouter un scénario E2E vertical :

```
import Kodokan + club
→ ouvrir une technique réunie
→ consulter les deux voix
→ ajouter un repère personnel
→ ajouter un média
→ choisir le média principal
→ naviguer vers une relation
→ revenir
→ ouvrir une composition utilisatrice
→ revenir
→ vérifier que tout est conservé.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- lecteur vidéo ;
- capture caméra ;
- sélection d'un fichier ;
- clavier et édition du carnet ;
- galerie horizontale ;
- retour Android ;
- absence de chevauchement avec la barre basse.

## 24. Documentation

Mettre à jour les documents existants uniquement.

`docs/workflows.md` :

- consultation d'une technique ;
- changement de voix ;
- ajout d'un repère personnel ;
- ajout de plusieurs médias ;
- choix du média principal ;
- navigation par relations ;
- navigation vers une composition ;
- retrait sécurisé ;
- niveaux de démonstration réels.

Ajouter un schéma Mermaid compact :

```
Bibliothèque
→ Fiche
→ Média principal
→ Voix
→ Carnet personnel
→ Relations / Compositions
→ Retour Bibliothèque
```

`docs/systeme.md` :

- construction de la fiche ;
- responsabilité des composants ;
- sélection du média principal ;
- règles d'édition selon la maîtrise de la contribution ;
- chargement différé des médias ;
- navigation contextuelle.

Matrice de conservation :

- vidéo en tête V2 conservée ;
- plusieurs médias V2 conservés ;
- voix V3 conservées ;
- édition directe du carnet ajoutée ;
- formulaire monolithique V2 non repris ;
- longue liste de relations V2 transformée en accès compact ;
- actions destructrices déplacées ;
- `Terminer` supprimé avec justification.

`docs/etat.md` :

- lot terminé ;
- tests ;
- limites restantes ;
- éventuelles faiblesses du modèle révélées mais non corrigées ;
- prochain lot : création, capture et édition.

## 25. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures montrant :
  - fiche avec média principal ;
  - fiche à plusieurs voix ;
  - édition directe de Mon carnet ;
  - galerie avec plusieurs médias ;
  - relations compactes ;
  - compositions utilisant la technique ;
  - menu secondaire avec action destructive.

Rapport compact :

- fichiers modifiés ;
- hiérarchie finale de la fiche ;
- règles de choix et d'affichage du média principal ;
- règles de modification selon la source ;
- workflow d'ajout de médias ;
- comportement de Mon carnet ;
- comportement du retour ;
- anomalies découvertes hors périmètre.

N'anticipe pas le lot Création, capture et édition globale.

Ne refonds pas le stockage des médias, le modèle des compositions, les
relations, la sécurité ou l'Atelier.

**La réussite de ce lot se mesure à une chose : un pratiquant ouvre une
technique, voit immédiatement le geste, comprend qui lui parle, enrichit
directement ce qu'il maîtrise et accède au reste sans traverser un mur de
texte.**
