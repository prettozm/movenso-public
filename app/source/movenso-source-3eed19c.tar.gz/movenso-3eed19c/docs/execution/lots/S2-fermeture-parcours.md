# Lot S2 — Fermeture des parcours fonctionnels (P1 de l'audit)

> ## ✅ LOT S2 CLOS — CHECKPOINT du 2026-08-02
> **16/16 chantiers traités** : 13 livrés (S2.1→S2.4, S2.6→S2.12, S2.14→S2.16), S2.5 clos (purge), S2.13 rayé (couvert par S1.9). Recettes appareil : S2.3 contre-recette 4/4 OK, S2.10 TalkBack = remontées utilisateur (D-172), fluidité au doigt confirmée. `npm run verifier` COMPLET VERT (typecheck + garde sources + 203 unit + build + garde dist + e2e zéro erreur JS). Remontées de recette Relations consignées au lot S3 volet D (D-173). App publique déployée jusqu'à `6964f48`.

> **Phase : STABILISATION V1** (D-161). Source : [`docs/execution/audit-stabilisation-v1.md`](../audit-stabilisation-v1.md), chantiers P1.1 → P1.16.
> **S1 CLOS (12/12, checkpoint vert, D-167).** **ARBITRÉ le 2026-08-02 (D-168)** :
> S2.4/S2.6/S2.7/S2.8/S2.9/S2.10/S2.11/S2.12/S2.15/S2.16 ✅ · S2.3 ✅ (recette avec porteur + sa décision arrière-plan) · S2.14 ✅ (starter pack à étudier ensemble) · **S2.13 RAYÉ** (couvert par S1.9) · **S2.5 CLOS** (UX déjà retirée ; code mort purgé) · **S2.1 : instruction pour/contre demandée** · **S2.2 : détail « qui fait quoi » demandé avant go**.
> Ordre : S2.8 → S2.11 → S2.14 → [S2.2 après détail validé] → S2.7 → [S2.1 après verdict] → S2.4 → S2.6 → S2.12 → S2.9 → S2.10 → S2.15 → S2.16 → S2.3 (campagne avec porteur).
> Le gel fonctionnel de la phase s'applique (voir S1).

États : `À FAIRE` · `PARTIEL` · `LARGEMENT FAIT` · `À INSTRUIRE` · `PROBABLEMENT CLOS` (à vérifier puis rayer).

---

## S2.1 — Unifier la création de techniques (P1.1) — À INSTRUIRE

Vérifier si création rapide et création complète partagent le même service (doublons exacts/proches, validation des noms, slug vide, noms emojis/symboles). Compléter + tests sur tous les points d'entrée.

## S2.2 — Terminer proprement les séances (P1.2) — À FAIRE (constat confirmé)

**Vérifié** : le lecteur désactive simplement « Suivant → » au dernier bloc (`compositions.ts:526`) — pas de « Terminer », pas de résumé.
- [ ] « Terminer » sur la dernière étape ; arrêt chrono + voix + bips ; résumé minimal (durée réalisée) ; fermeture sans ambiguïté ;
- [ ] tests : dernière étape sans durée, dernière étape en avancement automatique.

## S2.3 — Fiabiliser chronomètre et audio (P1.3) — ✅ LIVRÉ (REC-S2-003, D-170)

Recette appareil faite (Samsung A36/Chrome) : phase A 6/6 verte ; phases B/C → **dérive confirmée « selon les cas »** en arrière-plan/verrouillé. **Décision porteur (D-170)** : arrière-plan = séance **SUSPENDUE** (pause auto, voix coupée, bandeau au retour, reprise d'un geste) + **verrou d'écran** pendant l'entraînement (l'écran ne s'éteint pas tout seul — D-93 levé). Livré + e2e. **Contre-recette appareil 4/4 OK (porteur, 2026-08-02) — S2.3 définitivement CLOS.**

## S2.4 — Annulation des opérations longues (P1.4) — PARTIEL

Le voile « … en cours » (D-131) existe sans bouton d'annulation. À couvrir : analyse vidéo, copie, empreinte, export, import, sauvegarde — avec suppression des temporaires, état précédent conservé, message de confirmation.

## S2.5 — « Tablette partagée » (P1.5) — CLOS (purge faite, D-168)

**Décision passée confirmée par le porteur** : les deux protections PIN restent, la notion « tablette partagée » avait été retirée de l'UX. Re-vérification : l'UX était bien retirée ; restait du CODE MORT (`activerPrereglagePartage`, branche « partage » du formulaire PIN, explication orpheline) — **purgé** (aucun comportement changé, tests verts).

## S2.6 — Clarifier fusion et défusion (P1.6) — PARTIEL

La fusion/défusion existe (doublons D-068, défusion par source). À compléter : annonce claire que la défusion n'est pas bit à bit, aperçu (relations/médias/compositions concernées), point de restauration avant fusion, tests sur les relations entrantes.

## S2.7 — Vocabulaire suppression / corbeille / restauration (P1.7) — À FAIRE

Harmoniser : « supprimer » = corbeille ; « retirer définitivement » = plus restaurable depuis la corbeille ; mention du point de restauration global + durée. Tests : suppression d'une technique utilisée dans une composition, reliée, d'une discipline entière (certains existent — inventorier d'abord).

## S2.8 — Corriger les promesses de sauvegarde (P1.8) — À FAIRE (occurrences localisées)

**Re-vérifié** : « restaurable à l'identique » subsiste à `atelier.ts:117` (feuille Sauvegardes) et `:334` (aide À propos) + `docs/recette-beta.md` ; le toast de restauration dit DÉJÀ « réglages d'appareil à reconfigurer » et le site est correct. La formulation exacte est documentée (REC-S1-006). ~1 boucle courte.

## S2.9 — Alternatives au glisser-déposer (P1.9) — ✅ LIVRÉ (REC-S2-009)

**Vérifié (constat corrigé)** : plus aucune flèche nulle part — le glisser (poignée ⠿, Pointer Events) était le SEUL chemin sur les quatre sites (disciplines, catégories, niveaux, blocs de composition). **Livré** : poignée = bouton focalisable (flèches = déplacer d'un cran), boutons ▲/▼ explicites nommés (désactivés en butée), annonce `aria-live` de chaque déplacement, persistance immédiate sous la même garde PIN ; bug « descendre = no-op » de la primitive `reordonner` contourné (on fait monter le voisin). e2e sur les trois familles de sites. TalkBack réel : à confirmer en recette appareil (S2.3/S2.10).

## S2.10 — Accessibilité des parcours essentiels (P1.10) — ✅ CLOS (REC-S2-010, D-172)

**Inventaire (2026-08-02, revue du code)** — déjà correct : `lang="fr"`, nav basse avec `aria-current`, onglets Relations `role=tab`/`aria-selected`, favoris `aria-pressed`, toast `role="status"` (erreurs annoncées), `:focus-visible` global, tous les boutons-icônes ont un `aria-label`, titres `h1/h2` par écran, réordonner au clavier (S2.9). **Écarts** : (1) champs nommés par le seul placeholder (16 inputs + 2 textareas) ; (2) **modales** (`feuille`/`voile`, ~32 occurrences) : pas d'`aria-modal`, pas d'Escape, pas de focus initial ni de retour du focus à la fermeture ; (3) cibles/contraste/zoom 200 % à vérifier visuellement ; (4) TalkBack + clavier Windows = recette appareil (porteur).

**Tranches** : ✅ **1. noms accessibles** (tous les champs portent `aria-label` ou `<label>` ; garde e2e `champsTousNommes` balayée aux points denses — plus jamais de champ anonyme) · ✅ **2. modales** (Échap ferme la modale du dessus via son voile, `aria-modal`+`tabindex=-1` sur les 15 feuilles, focus central : entre dans la feuille à l'ouverture, rendu à l'ouvreur à la fermeture ; e2e) · ✅ **3. cibles/contraste/zoom** (contraste AA vérifié par calcul sur 2 thèmes × 5 tonalités, zéro correctif ; 2 cibles sous 24 px remontées ; e2e zoom 200 % via viewport 320 px sans défilement horizontal) · ✅ **4. TalkBack (D-172)** : traversée exhaustive abandonnée par le porteur (coût) — socle e2e en place, remontées utilisateur font foi ; fluidité au doigt confirmée. **S2.10 CLOS.**

## S2.11 — Ouverture des ressources externes (P1.11) — À FAIRE (avec S1.3)

Indicateur « lien externe », domaine affiché, avertissement HTTP, contexte séparé, aucun lien silencieux depuis une carte entière. À traiter dans la foulée du validateur d'URL (S1.3) pour ne pas repasser deux fois.

## S2.12 — Médias orphelins (P1.12) — ✅ LIVRÉ (REC-S2-012, D-171)

**Vérifié** : distinction orphelin ≠ référence cassée et suppression individuelle avec prévisualisation existaient (D-107) ; signalement au démarrage depuis S1.5-C. **Livré** : total de la section affiché, rattachement d'un média retrouvé (contribution personnelle, empreinte recalculée, rollback), et **suppression groupée des fichiers VÉRIFIÉS** (D-171 — précision de D-107 : bouton « Supprimer les N fichiers vérifiés — X Mo » dès 2 vérifiés, chaque fichier revérifié à l'instant T). e2e complets.

## S2.13 — Limite vidéo avant écriture (P1.13) — LARGEMENT FAIT (par S1.9)

**Re-vérifié** : `#espaceInsuffisantPour(fichier)` refuse AVANT toute écriture (taille connue + marge 10 %/16 Mo, limite volontaire D-097 comprise) ; un fichier dédupliqué ne s'écrit pas (donc jamais compté deux fois). Reste marginal : rien d'identifié — à rayer sauf retour de recette.

## S2.14 — Première ouverture claire (P1.14) — LARGEMENT FAIT

**Vérifié** : l'état vide propose Importer / Créer, sans PIN imposé ni tutoriel. Reste : une phrase « ce qu'est Movenso », mention données locales + comment sauvegarder, starter pack éventuel (décision porteur).

## S2.15 — Tous les workflows sur bibliothèque vide (P1.15) — ✅ LIVRÉ (REC-S2-015)

Campagne e2e systématique sur installation vierge (mode avancé + bêta révélés) : les 5 onglets et les 13 sous-écrans de Plus se rendent utilement, zéro erreur JS. Les workflows sur vide étaient déjà démontrés un à un (création depuis rien, recherche sans résultat, restauration sur vierge, états vides Favoris/Relations) — inventaire consigné dans REC-S2-015.

## S2.16 — Tous les workflows sur grosse bibliothèque (P1.16) — ✅ LIVRÉ (REC-S2-016)

`npm run campagne:charge` : 10 disciplines / 2 000 techniques / 10 000 relations / 500 contributions / 100 compositions générées, persistées, rechargées à froid, zéro erreur JS. Mesures (conteneur) : démarrage ~1 s, recherche ~120 ms, fiche ~25 ms, explorateur ~80 ms, Mindmap ~25 ms, bascules Carte/Explorer ~3 ms, persistance ~230 ms, mémoire ~34 Mo — aucun goulot. Restes consignés : médias multi-Go (allocation disque conteneur), temps d'import isolé (rapprochement ×2 000 à surveiller), fluidité au doigt → recette appareil.

---

## Fin du lot S2

Points arbitrés démontrés (tests + recettes), `verifier` vert, docs à jour, checkpoint `STATE.md`. Le cycle complet « ouvrir → importer/créer → capturer → classer → retrouver → composer → dérouler → sauvegarder → restaurer » fonctionne sans impasse ni perte silencieuse.
