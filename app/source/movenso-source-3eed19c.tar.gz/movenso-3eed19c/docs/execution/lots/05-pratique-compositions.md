# LOT 5 — PRATIQUE, FAVORIS ET COMPOSITIONS : RETROUVER ET RÉUTILISER SON SAVOIR

## Contexte

Le lot 1 a installé trois destinations principales :

- Bibliothèque ;
- Pratique ;
- Atelier.

Le lot 2 a rendu la Bibliothèque exploitable :

- disciplines uniques ;
- exploration visuelle ;
- recherche globale ;
- filtres cumulables ;
- filtres par source ;
- création d'une première technique.

Le lot 3 a refondu la fiche technique :

- média principal en tête ;
- voix distinctes ;
- carnet personnel directement éditable ;
- plusieurs médias ;
- relations compactes ;
- accès aux compositions utilisant la technique.

Le lot 4 a distingué :

- création d'une technique ;
- capture rapide ;
- rattachement immédiat ou différé ;
- modification contextuelle.

L'onglet Pratique doit maintenant devenir un espace personnel réellement
utile.

Il ne doit pas reproduire la Bibliothèque ni devenir un nouvel écran
d'accueil générique.

Il doit réunir trois usages :

1. reprendre les quelques contenus réellement inachevés ;
2. retrouver rapidement ses techniques favorites ;
3. construire, modifier et utiliser ses propres compositions.

La V3 possède déjà un modèle de composition riche avec plusieurs natures
de blocs. Cette richesse ne doit pas être exposée telle quelle à
l'utilisateur lors de chaque ajout.

Ce lot porte **exclusivement** sur :

- la racine de Pratique ;
- les Favoris ;
- la file `À reprendre` ;
- les Compositions ;
- la création et l'édition d'une composition ;
- le mode de consultation pendant l'entraînement ;
- l'export, la sauvegarde et la restauration des compositions.

Il ne refond pas :

- la Bibliothèque ;
- la fiche technique ;
- le workflow général de capture ;
- l'Atelier ;
- le format physique des médias ;
- la sécurité ;
- la publication d'un pack disciplinaire ;
- l'identité graphique globale.

## Objectif unique

Faire de Pratique un espace personnel simple permettant de :

- reprendre un contenu réellement inachevé ;
- retrouver ses favoris ;
- créer `Ma spéciale`, `Mon enchaînement`, `Mon kata libre` ou tout autre
  support personnel ;
- ajouter des techniques et du texte libre ;
- réordonner les éléments ;
- consulter la composition pendant la pratique ;
- modifier sans perdre le contexte ;
- exporter, sauvegarder et restaurer sans dupliquer les techniques.

## 1. Raison d'être de l'onglet Pratique

Pratique contient ce que l'utilisateur sélectionne ou construit pour son
propre usage.

Il ne contient pas :

- toutes les techniques ;
- toutes les disciplines ;
- tous les packs ;
- les fonctions d'administration ;
- les diagnostics ;
- la publication d'un corpus ;
- un historique exhaustif des consultations.

Pratique répond à trois questions :

- Qu'est-ce que je dois encore ranger ?
- Qu'est-ce que je veux retrouver rapidement ?
- Qu'est-ce que je suis en train de construire ou travailler ?

## 2. Racine de Pratique

La racine de Pratique comporte au maximum trois sections :

- À reprendre ;
- Favoris ;
- Compositions.

Ordre recommandé :

1. À reprendre, uniquement si la section n'est pas vide ;
2. Favoris ;
3. Compositions.

Ne pas afficher de section vide sous forme d'un grand bloc inutile.

Si aucune capture n'est à reprendre : la section `À reprendre` n'apparaît
pas.

Si aucun favori n'existe, afficher dans la zone Favoris un état vide
compact :

`Ajoute une technique à tes favoris depuis sa fiche.`

Si aucune composition n'existe, afficher :

`Crée ton premier enchaînement, cours ou parcours personnel.`

avec l'action `Nouvelle composition`.

La racine ne doit pas devenir une longue succession de grandes cartes
explicatives.

Privilégier :

- titres courts ;
- aperçus compacts ;
- accès `Voir tout` lorsqu'il existe plusieurs éléments.

## 3. À reprendre

La section `À reprendre` contient uniquement des actions inachevées ou
des brouillons nécessitant une décision.

Exemples valides :

- capture non rattachée ;
- contenu dont le rattachement a échoué ;
- brouillon de composition explicitement enregistré comme incomplet ;
- média capturé mais non encore classé.

Ne pas y mettre automatiquement :

- dernière technique consultée ;
- dernière note créée ;
- historique de navigation ;
- toutes les contributions personnelles ;
- compositions simplement existantes.

Chaque élément affiche au minimum :

- aperçu du média ou du texte ;
- date ;
- provenance ou auteur si nécessaire ;
- discipline présélectionnée éventuelle ;
- état compréhensible.

Actions disponibles :

- Reprendre ;
- Rattacher à une technique ;
- Créer une technique ;
- Modifier le libellé ou le texte ;
- Supprimer avec confirmation.

Après rattachement réussi :

- l'élément disparaît immédiatement de `À reprendre` ;
- le contenu apparaît dans la fiche cible ;
- aucun doublon ne subsiste.

Si la capture est supprimée :

- expliquer si un fichier local sera également supprimé ;
- respecter sauvegarde et confirmation existantes.

Ne pas ajouter de nouvelle logique de publication dans cette section.

## 4. Favoris — modèle et sémantique

Un favori est un marque-page personnel vers une identité technique.

Il ne crée :

- ni nouvelle technique ;
- ni nouvelle contribution ;
- ni copie du contenu ;
- ni modification d'un pack.

Un favori référence l'identifiant stable de la technique.

Le statut favori est :

- personnel ;
- local à l'installation ;
- inclus dans la sauvegarde intégrale ;
- restauré avec la bibliothèque ;
- exclu par défaut des packs publiés.

Si le modèle ne possède pas encore de favoris, ajouter uniquement le
mécanisme minimal nécessaire :

- collection d'identifiants de techniques favorites ;
- validation des références ;
- migration du modèle ;
- sauvegarde et restauration.

Ne pas créer pour ce lot :

- dossiers de favoris ;
- tags de favoris ;
- ordre manuel complexe ;
- partage public des favoris ;
- favoris collaboratifs.

## 5. Ajout et retrait d'un favori

Depuis la fiche technique, permettre :

- Ajouter aux favoris ;
- Retirer des favoris.

L'action doit être immédiate et réversible.

Utiliser :

- une étoile ou un marque-page ;
- un libellé accessible ;
- un état visuel qui ne repose pas uniquement sur la couleur.

Après ajout, confirmation discrète : `Ajouté aux favoris` — la technique
apparaît dans Pratique.

Après retrait :

- elle disparaît de Favoris ;
- elle reste intacte dans la Bibliothèque ;
- aucune contribution ou donnée n'est supprimée.

Ne pas demander de confirmation pour ajouter ou retirer un favori.

## 6. Liste des favoris

Afficher les favoris sous une forme visuelle cohérente avec la
Bibliothèque, mais plus compacte.

Chaque favori contient :

- miniature ou fallback ;
- nom ;
- appellation traditionnelle facultative ;
- discipline ;
- éventuellement niveau ou famille.

Toucher ouvre la fiche technique.

Le retour revient dans Pratique avec :

- position ;
- recherche éventuelle ;
- état de la section.

Prévoir une recherche uniquement si le nombre d'éléments le justifie.

Ne pas dupliquer tous les filtres avancés de la Bibliothèque.

Une action secondaire peut permettre : Retirer des favoris.

Ne pas afficher :

- suppression de la technique ;
- édition administrative ;
- source technique brute ;
- identifiant du pack.

Si une technique favorite n'existe plus :

- ne pas casser l'écran ;
- afficher un élément indisponible ou nettoyer la référence selon les
  règles validées ;
- tracer le comportement ;
- ne pas recréer une technique fantôme.

## 7. Composition — définition utilisateur

Une composition est un support personnel ordonné permettant d'assembler :

- des techniques existantes ;
- du texte libre.

Exemples possibles :

- Ma spéciale ;
- Mes enchaînements ;
- Mon kata libre ;
- Mon cours ;
- Ma séance ;
- Préparation 2e dan ;
- Travail de la semaine.

Ces exemples ne sont pas une taxonomie obligatoire.

L'utilisateur choisit librement le titre.

Le système ne lui demande pas de classer immédiatement la composition
comme : kata ; cours ; grade ; enchaînement ; système ; prestation.

Une telle classification pourra être ajoutée ultérieurement si un besoin
réel est observé.

## 8. Simplification des blocs visibles

Dans l'interface d'ajout, exposer exactement deux choix :

- Ajouter une technique ;
- Ajouter du texte.

Ne pas exposer comme choix séparés : étape ; transition ; consigne ;
objectif ; durée ; repère ; média.

Le texte libre peut servir à écrire : une transition ; une consigne ; une
durée ; un objectif ; un titre de partie ; un repère ; une attaque ; un
contexte.

Exemples :

```
Tirer la manche puis avancer
3 répétitions de chaque côté
Attaque : Hadaka-jime
Transition au sol
Partie 1 — projections
Faire lentement
```

Le modèle interne peut conserver ses types existants pour compatibilité.

Règles :

- les anciens blocs doivent rester lisibles ;
- aucun contenu existant ne doit être perdu ;
- l'interface peut les présenter comme texte libre ;
- ne pas effectuer de migration destructrice vers un type unique ;
- ne pas supprimer les informations de type existantes à l'export.

Lorsque l'utilisateur crée un nouveau bloc texte, utiliser le type
interne le plus générique prévu par le modèle.

## 9. Création d'une composition

Point d'entrée :

```
Pratique
→ Compositions
→ Nouvelle composition.
```

Étape minimale : titre obligatoire.

Champ facultatif : description courte ou objectif général.

Ne pas demander au départ : provenance ; type de composition ; discipline ;
durée totale ; niveau ; pack ; auteur si l'utilisateur courant est déjà
connu.

Par défaut :

- auteur : Moi ;
- usage : personnel ;
- non publiée.

Après création :

- ouvrir immédiatement l'éditeur ;
- afficher une composition vide ;
- proposer : Ajouter une technique ; Ajouter du texte.

Une composition vide peut être conservée comme brouillon.

Ne pas imposer un écran de confirmation supplémentaire.

## 10. Ajouter une technique

L'action `Ajouter une technique` ouvre un sélecteur utilisant la
Bibliothèque.

Le sélecteur doit permettre :

- recherche globale ;
- choix d'une discipline ;
- filtres simples si nécessaires ;
- accès aux favoris ;
- sélection d'une technique.

Chaque technique sélectionnée est ajoutée comme référence à son identité
stable.

Ne pas copier dans la composition : nom complet comme donnée autonome
faisant foi ; description ; vidéo ; contribution ; taxonomies.

La composition peut conserver un libellé de secours pour la résilience de
l'affichage, mais l'identité technique reste la référence principale.

Après sélection :

- revenir immédiatement à la composition ;
- afficher le nouvel élément ;
- permettre d'ajouter un texte juste après ;
- permettre d'ajouter une autre technique.

Ne pas fermer l'éditeur ni revenir à la racine Pratique à chaque ajout.

## 11. Ajouter du texte

L'action `Ajouter du texte` ouvre un champ simple.

Accepter : un mot ; une phrase ; plusieurs lignes courtes.

Ne pas demander quel type de texte il s'agit.

Prévoir facultativement un style d'affichage léger, seulement si cela
reste simple : texte normal ; titre ou séparateur.

Ne pas exposer les huit types métier comme un choix.

Après validation :

- le bloc est ajouté à la position choisie ;
- il est directement modifiable ;
- l'utilisateur reste dans l'éditeur.

## 12. Ordre et réorganisation

Chaque élément de composition doit être réordonnable.

Sur téléphone :

- poignée de déplacement ;
- boutons Monter / Descendre accessibles ;
- ou glisser-déposer avec alternative accessible.

Sur tablette et web :

- glisser-déposer possible ;
- conserver une alternative clavier ou boutons.

Le réordonnancement doit être :

- immédiatement visible ;
- sauvegardé ;
- stable après fermeture et relance.

Ne pas déclencher une sauvegarde lourde ou un rechargement de tous les
médias à chaque déplacement.

Ne pas dupliquer une étape après plusieurs déplacements rapides.

## 13. Modifier une composition

L'utilisateur peut modifier : titre ; description ; ordre des éléments ;
texte libre ; références techniques ; ajout ou suppression d'éléments.

Toucher un bloc texte : édition directe ou panneau léger.

Toucher un bloc technique en mode édition, ouvrir un menu contextuel :

- Voir la fiche ;
- Remplacer la technique ;
- Ajouter du texte après ;
- Retirer de la composition.

Retirer un bloc technique de la composition ne supprime jamais la
technique de la Bibliothèque.

Supprimer une composition :

- demander confirmation ;
- effectuer une sauvegarde préalable selon les règles existantes ;
- ne supprimer aucune technique ou média source.

## 14. Mode édition et mode entraînement

Distinguer deux usages.

**A. Mode Édition**

Permet : ajouter ; modifier ; réordonner ; supprimer des blocs ; modifier
le titre.

Il affiche les poignées et actions contextuelles.

**B. Mode Entraînement**

Permet de suivre la composition sans éléments d'administration.

Il affiche :

- titre ;
- progression ;
- bloc courant ;
- bloc précédent ou suivant selon le contexte ;
- accès à la technique référencée ;
- texte associé ;
- navigation simple.

Le mode entraînement doit pouvoir être utilisé : téléphone tenu en main ;
téléphone posé ; tablette au bord du tatami.

Prévoir de grandes actions : Précédent ; Suivant ; Quitter.

La barre basse peut être masquée dans ce mode.

Ne pas imposer un chronomètre ou une lecture automatique.

## 15. Présentation du mode entraînement

Le mode entraînement doit privilégier la lisibilité.

Pour un bloc technique :

- nom ;
- appellation traditionnelle facultative ;
- miniature ou média principal si disponible ;
- texte adjacent ou suivant ;
- action `Voir la fiche`.

Pour un bloc texte :

- texte lisible en grand ;
- aucune métadonnée technique inutile.

Navigation :

- balayage horizontal facultatif ;
- boutons toujours présents ;
- indication : `3 / 8`.

Depuis une fiche ouverte dans ce contexte :

- retour vers la même position de la composition ;
- ne pas revenir à la Bibliothèque.

La mise en veille peut continuer à suivre les règles système dans ce lot.

Ne pas ajouter de maintien d'écran actif sans décision explicite sur la
batterie.

## 16. Relation entre texte et technique

Le texte libre reste un bloc indépendant.

L'utilisateur peut naturellement composer :

```
Technique A
→ Texte de transition
→ Technique B
→ Texte de consigne.
```

Ne pas rendre obligatoire l'attachement d'un texte à une technique
précise.

Pour faciliter la lecture, permettre dans l'éditeur : ajouter un texte
avant ; ajouter un texte après.

Mais le stockage reste une séquence ordonnée de blocs.

Ne pas transformer le texte en relation objective du graphe.

## 17. Compositions utilisant une technique

La fiche technique doit continuer à afficher :

`Utilisée dans · N`

Le calcul porte sur les références réelles présentes dans les
compositions.

Ouvrir une composition depuis une fiche :

- ouvre sa consultation dans Pratique ;
- positionne si possible sur l'étape utilisant la technique ;
- retour vers la fiche.

Si une technique est retirée de la Bibliothèque :

- détecter les compositions concernées ;
- empêcher la disparition silencieuse de leur référence ;
- afficher un état `Technique indisponible` avec le libellé de secours ;
- permettre de remplacer ou retirer la référence.

Ne pas supprimer automatiquement le bloc de toutes les compositions.

## 18. Liste des compositions

Dans Pratique, la liste affiche pour chaque composition :

- titre ;
- nombre d'éléments ;
- date de dernière modification ;
- éventuellement miniature de la première technique ;
- état brouillon si vide ou incomplet.

Actions principales : ouvrir ; démarrer le mode entraînement.

Actions secondaires : modifier ; dupliquer ; exporter ; supprimer.

La duplication crée :

- une nouvelle composition ;
- de nouvelles références vers les mêmes techniques ;
- aucune copie des techniques ni médias.

Ne pas afficher un grand bouton d'administration sur chaque carte.

## 19. Recherche et tri des compositions

Prévoir une recherche par titre si plusieurs compositions existent.

Tri minimal : récemment modifiées ; ordre alphabétique.

Ne pas ajouter : catégories complexes ; tags ; dossiers ; statistiques
d'usage ; notation.

Les compositions favorites ou épinglées peuvent être différées.

## 20. Export d'une composition

Rendre l'action accessible depuis le menu de la composition :

`Exporter la composition`

Avant export, expliquer ce qui sera produit.

Deux usages possibles :

**A. Composition seule**

Inclut : composition ; références techniques ; libellés de secours ;
métadonnées minimales.

Ne duplique pas nécessairement les techniques si le destinataire possède
déjà la bibliothèque compatible.

**B. Composition avec les techniques nécessaires**

Inclut : composition ; identités référencées ; contributions
sélectionnées ; médias selon le choix et les capacités du format.

Si le format `.movpack` actuel ne supporte pas proprement ces deux
granularités :

- implémenter la granularité minimale sûre ;
- ne pas afficher une option non fonctionnelle ;
- documenter précisément ce qui est inclus.

Le carnet personnel n'est jamais exporté par défaut.

Avant tout export, afficher : composition incluse ; nombre de techniques
référencées ; médias inclus ou non ; contenu personnel inclus ou non.

Ne pas modifier profondément le format `.movpack` sans nécessité.

Toute évolution nécessaire doit :

- être versionnée ;
- être migrable ;
- conserver les anciens exports ;
- avoir des tests d'import/restauration.

## 21. Import d'une composition

Lorsqu'un `.movpack` contient une composition :

- importer la composition ;
- relier ses références aux identités existantes lorsque possible ;
- utiliser les règles de rapprochement existantes ;
- signaler les références non résolues ;
- ne pas créer silencieusement plusieurs copies d'une même technique.

Si une technique référencée manque :

- conserver le bloc ;
- afficher `Technique à retrouver` ;
- proposer : rattacher à une technique existante ; importer le corpus
  nécessaire ; retirer ce bloc.

Ne pas perdre la structure de la composition parce qu'une technique
manque.

## 22. Sauvegarde et restauration

La sauvegarde intégrale doit inclure :

- favoris ;
- compositions ;
- ordre des blocs ;
- textes libres ;
- références techniques ;
- états à reprendre.

Après restauration sur une installation vierge :

- les favoris pointent vers les bonnes techniques ;
- les compositions gardent leur ordre ;
- les textes sont intacts ;
- les techniques référencées s'ouvrent ;
- le mode entraînement fonctionne ;
- les captures à reprendre restent accessibles.

Les packs publiés par discipline n'incluent pas automatiquement : favoris ;
compositions personnelles ; captures à reprendre.

La sauvegarde personnelle et la publication d'un corpus restent deux
opérations différentes.

## 23. Hors ligne

Toutes les fonctions de Pratique doivent fonctionner hors ligne : Favoris ;
création de composition ; ajout de technique locale ; texte ;
réorganisation ; mode entraînement ; sauvegarde locale.

Un média distant peut être indisponible hors connexion.

Dans ce cas :

- afficher la miniature mise en cache si disponible ;
- sinon un fallback ;
- ne pas bloquer la progression dans la composition.

## 24. Performance

Ne pas charger à l'ouverture de Pratique : tous les médias des favoris ;
toutes les vidéos de toutes les compositions ; toutes les fiches
techniques complètes.

Charger : métadonnées ; miniatures ; contenu nécessaire à l'écran courant.

En mode entraînement :

- préparer éventuellement le bloc suivant ;
- ne pas instancier tous les lecteurs vidéo simultanément.

Les opérations de réordonnancement doivent rester fluides avec au moins
cinquante blocs.

## 25. Limites strictes du lot

Ne pas modifier :

- la navigation à trois onglets ;
- la structure de la Bibliothèque ;
- la fiche technique hors intégration Favoris et navigation Composition ;
- le workflow global de capture ;
- le modèle identité/contribution ;
- le rapprochement inter-packs ;
- le stockage physique des médias ;
- les types de relation ;
- l'Atelier ;
- la sécurité et le PIN ;
- la publication disciplinaire ;
- l'identité graphique globale.

Les modifications de modèle autorisées sont limitées à :

- favoris personnels ;
- adaptations indispensables aux compositions ;
- compatibilité/migration des anciens blocs ;
- sauvegarde et restauration des données de Pratique.

Toute idée supplémentaire doit être **tracée, pas implémentée**.

## 26. Critères d'acceptation

**Scénario A — Favoris**

1. ouvrir une fiche ;
2. ajouter la technique aux favoris ;
3. ouvrir Pratique ;
4. retrouver la technique ;
5. ouvrir sa fiche ;
6. revenir ;
7. retirer des favoris ;
8. vérifier que la technique reste dans la Bibliothèque.

**Scénario B — À reprendre**

1. créer une capture non rattachée ;
2. ouvrir Pratique ;
3. voir la section À reprendre ;
4. rattacher la capture ;
5. vérifier qu'elle disparaît ;
6. vérifier le contenu dans la fiche.

**Scénario C — création simple**

1. ouvrir Compositions ;
2. créer `Ma spéciale` ;
3. ne saisir que le titre ;
4. ajouter O-goshi ;
5. ajouter le texte `tirer la main` ;
6. ajouter Juji-gatame ;
7. voir trois blocs dans l'ordre.

**Scénario D — réorganisation**

1. créer cinq blocs ;
2. déplacer le dernier en deuxième position ;
3. fermer ;
4. relancer ;
5. vérifier l'ordre ;
6. modifier un texte ;
7. vérifier la sauvegarde.

**Scénario E — mode entraînement**

1. ouvrir Ma spéciale ;
2. démarrer ;
3. naviguer bloc par bloc ;
4. ouvrir la fiche O-goshi ;
5. revenir au même bloc ;
6. poursuivre jusqu'à la fin ;
7. quitter vers la composition.

**Scénario F — blocs existants V3**

1. ouvrir une ancienne composition contenant transition, consigne et
   durée ;
2. vérifier que tous les textes restent visibles ;
3. les modifier sans perte ;
4. exporter ;
5. restaurer ;
6. vérifier que les types internes ne sont pas détruits.

**Scénario G — technique indisponible**

1. utiliser une technique dans une composition ;
2. retirer la technique de la Bibliothèque ;
3. ouvrir la composition ;
4. voir la référence indisponible ;
5. remplacer la technique ;
6. vérifier que la composition reste cohérente.

**Scénario H — duplication**

1. dupliquer Ma spéciale ;
2. modifier la copie ;
3. vérifier que l'original reste inchangé ;
4. vérifier qu'aucune technique n'est dupliquée.

**Scénario I — export et import**

1. exporter une composition ;
2. importer sur installation vierge ;
3. vérifier son titre, son ordre et ses textes ;
4. vérifier les références résolues ;
5. afficher clairement les références absentes.

**Scénario J — sauvegarde intégrale**

1. créer favoris, composition et capture à reprendre ;
2. effectuer une sauvegarde complète ;
3. vider ou réinstaller ;
4. restaurer ;
5. vérifier les trois catégories ;
6. démarrer le mode entraînement.

**Scénario K — hors ligne**

1. couper le réseau ;
2. ouvrir les favoris ;
3. modifier une composition ;
4. utiliser le mode entraînement ;
5. fermer ;
6. relancer ;
7. retrouver les modifications.

## 27. Tests

Ajouter ou adapter les tests pour couvrir :

- ajout/retrait de favori ;
- absence de duplication ;
- technique favorite supprimée ;
- inclusion dans sauvegarde ;
- exclusion des packs publiés ;
- création d'une composition avec titre seul ;
- ajout de référence technique ;
- ajout de texte libre ;
- réordonnancement ;
- modification ;
- duplication ;
- suppression ;
- ancienne composition avec types riches ;
- navigation mode entraînement ;
- retour fiche → composition ;
- calcul `Utilisée dans` ;
- référence technique manquante ;
- export/import ;
- restauration intégrale ;
- fonctionnement hors ligne.

Ajouter un E2E vertical :

```
importer Judo
→ mettre O-goshi en favori
→ créer Ma spéciale
→ ajouter O-goshi
→ ajouter un texte
→ ajouter Juji-gatame
→ réordonner
→ mode entraînement
→ ouvrir une fiche
→ revenir
→ exporter
→ restaurer dans un contexte vierge
→ vérifier favoris et composition.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- réordonnancement tactile ;
- mode entraînement ;
- retour Android ;
- ouverture/retour d'une fiche ;
- lisibilité sur téléphone ;
- utilisation sur tablette ;
- absence de chevauchement avec la barre système.

## 28. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- racine Pratique ;
- Favoris ;
- À reprendre ;
- création d'une composition ;
- ajout d'une technique ;
- ajout d'un texte ;
- réordonnancement ;
- mode entraînement ;
- export/import ;
- sauvegarde/restauration.

Chaque workflow doit indiquer : entrée ; étapes ; sortie ; données créées ;
niveau réel de démonstration.

Ajouter un Mermaid compact :

```
Pratique
├── À reprendre
│   └── Rattacher / Créer / Supprimer
├── Favoris
│   └── Fiche technique
└── Compositions
    ├── Édition
    │   ├── Technique
    │   └── Texte
    └── Mode entraînement
```

`docs/systeme.md` :

- modèle des favoris ;
- références de techniques ;
- compatibilité des anciens blocs ;
- mode entraînement ;
- gestion des références absentes ;
- sauvegarde et export.

Matrice de conservation :

- favoris V2 conservés ;
- compositions V3 conservées et simplifiées ;
- huit types de blocs masqués dans l'interface mais préservés dans les
  données ;
- deux ajouts visibles retenus ;
- `À reprendre` conservé uniquement pour les actions inachevées ;
- historique de consultation non transformé en pseudo-reprise ;
- duplication des techniques explicitement interdite.

`docs/etat.md` :

- lot terminé ;
- scénarios démontrés ;
- limites connues ;
- choix d'export réellement implémenté ;
- prochain lot : Atelier.

## 29. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures ou courte vidéo montrant :
  - racine Pratique ;
  - Favoris ;
  - À reprendre ;
  - création de Ma spéciale ;
  - éditeur avec technique et texte ;
  - réordonnancement ;
  - mode entraînement ;
  - retour fiche → composition.

Rapport compact :

- fichiers modifiés ;
- modèle minimal des favoris ;
- compatibilité des anciens blocs ;
- comportement des références techniques ;
- export réellement implémenté ;
- comportement de sauvegarde et restauration ;
- limites hors périmètre.

N'anticipe pas le lot Atelier.

Ne refonds pas la Bibliothèque, la fiche, la capture, les médias, la
sécurité ou la publication disciplinaire.

**La réussite de ce lot se mesure à une chose : l'utilisateur peut
retrouver ce qu'il a choisi, reprendre ce qu'il n'a pas encore rangé et
construire un parcours utilisable pendant l'entraînement, sans transformer
Movenso en outil de gestion de projet.**
