# LOT 7 — SÉCURITÉ ET MODES D'USAGE : APPAREIL PERSONNEL, TABLETTE PARTAGÉE ET SESSION CURATEUR

## Contexte

Le lot 1 a installé trois destinations :

- Bibliothèque ;
- Pratique ;
- Atelier.

Les lots suivants ont fermé les principaux workflows :

- exploration et création d'un corpus ;
- fiche technique et médias ;
- capture et rattachement ;
- favoris et compositions ;
- construction, diagnostic, import, publication, sauvegarde et
  restauration dans l'Atelier.

La V2 imposait une logique de connexion Admin par PIN avant certaines
opérations. Cette protection répondait à un vrai besoin de tablette
collective, mais elle créait une friction inutile sur un appareil
personnel et exposait une gouvernance plus complexe que les usages
réellement observés.

La cible est désormais :

- appareil personnel : modification autorisée par défaut, sans PIN ;
- tablette partagée : consultation libre, actions choisies protégées ;
- curateur ou sensei : déverrouillage temporaire permettant d'effectuer
  les opérations protégées.

Le système ne doit pas introduire :

- de comptes ;
- de profils utilisateurs ;
- de serveur ;
- de rôles collaboratifs complexes ;
- d'authentification obligatoire au démarrage.

Ce lot porte sur :

- les modes d'usage ;
- l'activation facultative des protections ;
- la création et la vérification du PIN ;
- la session temporaire de curateur ;
- le verrouillage automatique ;
- la matrice des opérations protégées ;
- le comportement sur tablette partagée ;
- la migration des anciens réglages de sécurité.

Il ne porte pas sur :

- le chiffrement intégral des données ;
- la sécurité physique du terminal ;
- les comptes multiples ;
- la synchronisation distante ;
- les permissions éditoriales fines entre plusieurs personnes ;
- le modèle de propriété des packs.

## Objectif unique

Permettre à Movenso de fonctionner naturellement dans deux contextes :

1. appareil personnel entièrement modifiable sans PIN ;
2. appareil partagé librement consultable, dont les modifications et
   opérations sensibles sont protégées par un PIN local.

La consultation, la lecture des médias et l'utilisation des compositions
ne doivent jamais être bloquées par défaut.

## 1. Modes d'usage

L'interface peut présenter deux configurations compréhensibles.

**A. Appareil personnel**

Valeur par défaut après installation.

Comportement :

- consultation libre ;
- création et modification libres ;
- suppressions confirmées mais sans PIN ;
- Atelier accessible ;
- aucun écran de connexion ;
- aucun badge Admin ;
- aucun PIN exigé.

**B. Appareil partagé**

Préréglage proposé dans :

```
Atelier
→ Réglages et sécurité
→ Protections.
```

Comportement recommandé :

- consultation libre ;
- Bibliothèque utilisable ;
- médias lisibles ;
- recherche et filtres libres ;
- Favoris et compositions consultables ;
- modifications protégées ;
- suppressions et opérations sensibles protégées ;
- déverrouillage temporaire par PIN.

Le préréglage `Appareil partagé` active les protections recommandées,
mais les deux protections restent configurables séparément.

Ne pas créer deux applications ni deux interfaces différentes.

Le mode d'usage ne modifie pas les données métier.

## 2. Deux protections seulement

Proposer deux réglages indépendants.

**A. Protéger les modifications**

Lorsque cette protection est active, un PIN est nécessaire pour :

- créer ou renommer une discipline ;
- créer, modifier ou retirer une technique ;
- modifier les taxonomies ;
- ajouter, modifier ou retirer une relation ;
- ajouter ou modifier une contribution ;
- modifier un contenu de club ou de sensei ;
- ajouter ou retirer un média ;
- changer le média principal ;
- importer un pack ;
- traiter un rapprochement ;
- créer, modifier ou supprimer une composition ;
- modifier les réglages structurants du corpus.

Les actions purement personnelles peuvent suivre la même protection en
mode partagé afin d'éviter qu'un visiteur modifie l'appareil collectif :

- carnet personnel local ;
- favoris ;
- captures à reprendre.

Ne pas introduire un troisième niveau de permissions dans ce lot.

**B. Protéger les suppressions et opérations sensibles**

Lorsque cette protection est active, un PIN est nécessaire pour :

- supprimer une discipline ;
- retirer une technique ;
- supprimer une contribution ;
- supprimer un média ou un fichier orphelin ;
- supprimer une composition ;
- supprimer une sauvegarde ;
- restaurer une sauvegarde ;
- effectuer un rollback ;
- réinitialiser la bibliothèque ;
- modifier ou désactiver les protections ;
- changer le PIN ;
- publier ou partager un pack ;
- exporter une sauvegarde complète contenant des données personnelles.

Les confirmations et sauvegardes préalables restent obligatoires même
après saisie du PIN.

Le PIN ne remplace jamais la confirmation destructive.

## 3. Activation des protections

Aucun PIN ne doit être demandé tant qu'aucune protection n'est activée.

Lors de la première activation de l'une des deux protections :

1. expliquer brièvement ce qui sera protégé ;
2. demander la création d'un PIN ;
3. demander sa confirmation ;
4. enregistrer le secret de manière sécurisée ;
5. activer la protection ;
6. proposer facultativement le préréglage `Appareil partagé`.

Si la confirmation diffère :

- ne rien activer ;
- conserver l'écran ;
- afficher une erreur claire.

Ne jamais enregistrer temporairement un PIN incomplet ou non confirmé.

Si un PIN existe déjà, activer la seconde protection ne doit pas demander
d'en créer un nouveau.

## 4. Format du PIN

Utiliser un PIN numérique local.

Règles recommandées :

- minimum 6 chiffres ;
- maximum raisonnable, par exemple 12 chiffres ;
- refus des valeurs trop évidentes si cela peut être fait sans complexité
  excessive : 000000 ; 123456 ; répétition d'un même chiffre.

Ne pas imposer : majuscule ; caractère spécial ; mot de passe
alphanumérique ; compte distant.

Le clavier numérique doit être demandé sur mobile.

L'interface doit permettre de masquer ou révéler temporairement les
chiffres saisis si cela reste cohérent avec le composant utilisé.

## 5. Stockage du PIN

Le PIN ne doit jamais être stocké en clair : ni dans LocalStorage ; ni
dans IndexedDB ; ni dans le JSON principal ; ni dans un fichier de
configuration ; ni dans les logs ; ni dans les sauvegardes exportées sous
forme lisible.

Utiliser l'API Web Crypto disponible dans les cibles actuelles.

Mécanisme minimal attendu :

- sel aléatoire propre à l'installation ;
- dérivation PBKDF2 avec SHA-256 ;
- nombre d'itérations documenté et suffisamment élevé pour l'appareil
  cible ;
- stockage uniquement du sel, des paramètres et du résultat dérivé ;
- comparaison sans journalisation du PIN.

Ne pas introduire une bibliothèque cryptographique lourde si Web Crypto
répond au besoin.

Les tests ne doivent jamais contenir le PIN de production ni imprimer les
secrets.

## 6. Migration de la sécurité existante

Analyser les paramètres de sécurité déjà présents dans la V3 et, le cas
échéant, dans les données migrées de V2.

Cas à gérer :

- aucun PIN existant ;
- ancien PIN stocké selon un autre format ;
- protection activée sans données de vérification valides ;
- ancien réglage `Admin requis` ;
- session Admin précédemment persistée.

Stratégie :

- ne pas conserver une session Admin permanente après migration ;
- migrer un ancien hash uniquement si sa vérification reste sûre ;
- sinon désactiver les protections et demander une nouvelle activation
  explicite ;
- ne jamais convertir un ancien PIN en clair ;
- documenter le comportement réel.

Une migration invalide ne doit pas bloquer l'accès en consultation.

## 7. Déverrouillage au point d'action

Ne pas demander le PIN au démarrage de l'application.

Lorsqu'un utilisateur déclenche une action protégée :

1. conserver le contexte de l'action ;
2. afficher un panneau ou écran de déverrouillage ;
3. indiquer pourquoi le PIN est demandé ;
4. vérifier le PIN ;
5. reprendre automatiquement l'action initiale si le déverrouillage
   réussit.

Exemples :

```
Modification protégée
Saisis le PIN pour modifier cette technique.

Opération sensible
Saisis le PIN pour restaurer cette sauvegarde.
```

Ne pas renvoyer l'utilisateur vers une page générale de connexion.

Après annulation :

- revenir exactement au contexte précédent ;
- ne modifier aucune donnée ;
- ne perdre aucun formulaire non enregistré.

## 8. Session temporaire de curateur

Une saisie correcte ouvre une session temporaire de curateur.

Pendant cette session :

- les actions couvertes par le niveau déverrouillé ne redemandent pas
  immédiatement le PIN ;
- un indicateur discret permet de comprendre que les modifications sont
  temporairement déverrouillées ;
- l'utilisateur peut verrouiller manuellement.

Ne pas afficher un gros mode Admin permanent.

Durée par défaut recommandée : 5 minutes d'inactivité.

Prévoir dans les réglages, uniquement si simple : 5 minutes ; 15 minutes ;
jusqu'à la mise en arrière-plan.

Ne pas permettre une session permanente par défaut sur un appareil
partagé.

La session doit se verrouiller lorsque :

- le délai d'inactivité est dépassé ;
- l'utilisateur appuie sur `Verrouiller maintenant` ;
- l'application reste en arrière-plan au-delà du seuil prévu ;
- l'appareil est redémarré ;
- l'application est complètement fermée ;
- le PIN est modifié ou les protections sont reconfigurées.

La session ne doit pas être incluse dans une sauvegarde.

## 9. Niveau de déverrouillage

Si seule la protection des modifications est activée :

- une saisie correcte autorise les modifications ;
- les suppressions suivent leur réglage propre.

Si les deux protections sont activées :

- une saisie correcte peut déverrouiller les deux niveaux pour la
  session ;
- ne pas demander deux PIN distincts.

Ne pas créer : PIN de modification ; PIN de suppression ; PIN de
publication ; plusieurs comptes.

Un seul PIN local suffit.

## 10. Échecs et temporisation

Après un PIN incorrect :

- afficher une erreur claire ;
- ne pas révéler la longueur ou la proximité du PIN correct ;
- conserver le contexte de l'action.

Introduire une temporisation progressive après plusieurs échecs
consécutifs.

Exemple :

- 1 à 4 erreurs : nouvelle tentative immédiate ;
- à partir de la 5e : attente courte croissante.

Ne pas verrouiller définitivement les données après quelques erreurs.

Réinitialiser le compteur après une vérification réussie.

Ne pas écrire les PIN tentés dans les logs.

Un journal technique peut conserver : date d'un déverrouillage réussi ;
nombre d'échecs agrégé ; verrouillage manuel — sans valeur secrète ni
contenu personnel.

## 11. Changement du PIN

Accessible dans :

```
Atelier
→ Réglages et sécurité
→ Changer le PIN.
```

Workflow :

1. vérifier le PIN actuel ;
2. saisir le nouveau PIN ;
3. confirmer ;
4. réécrire les données de vérification avec un nouveau sel ;
5. fermer toutes les sessions actives ;
6. confirmer le changement.

En cas d'échec après vérification de l'ancien PIN :

- conserver l'ancien PIN ;
- ne jamais laisser l'installation sans vérification valide.

## 12. Désactivation des protections

Désactiver une protection exige le PIN actuel.

Si les deux protections sont désactivées :

- proposer de supprimer les données de vérification du PIN ;
- expliquer qu'aucune action ne sera plus protégée ;
- fermer la session active.

Comportement recommandé :

- supprimer les données de PIN lorsque plus aucune protection n'est
  active ;
- ne pas conserver un secret inutile par inertie.

Ne pas demander le PIN au prochain lancement.

## 13. PIN oublié

Movenso est hors ligne et ne possède ni compte ni serveur de
récupération.

L'interface doit l'expliquer honnêtement.

Ne pas créer : de question secrète ; de PIN maître caché ; de porte
dérobée ; de récupération par e-mail fictive.

Prévoir une voie de récupération réaliste selon les capacités
existantes :

- réinstaller l'application puis restaurer une sauvegarde connue ;
- ou réinitialiser entièrement les données locales après avertissement
  explicite.

Si un ancien code de récupération V2 existe et est conservé :

- le traiter comme un secret distinct ;
- ne jamais le stocker en clair ;
- l'afficher une seule fois lors de sa création ;
- documenter précisément son rôle.

Ne pas réintroduire ce code uniquement pour reproduire la V2 si aucun
besoin n'est démontré.

La sécurité applicative ne peut pas empêcher le propriétaire physique du
terminal de désinstaller l'application.

## 14. Mode tablette partagée

Le préréglage `Tablette partagée` doit être accessible dans les
protections.

Activation recommandée :

- protéger les modifications ;
- protéger les suppressions et opérations sensibles ;
- délai de session court ;
- verrouillage à la mise en arrière-plan ;
- Bibliothèque comme écran de démarrage.

Dans ce mode, sans déverrouillage :

autorisé :

- parcourir les disciplines ;
- rechercher ;
- filtrer ;
- ouvrir les fiches ;
- lire les médias ;
- consulter les relations ;
- consulter les compositions ;
- utiliser le mode entraînement.

protégé :

- créer ;
- éditer ;
- capturer ;
- mettre en favori si les favoris appartiennent à l'appareil collectif ;
- modifier une composition ;
- importer ;
- publier ;
- sauvegarder ou restaurer ;
- accéder aux réglages sensibles.

L'Atelier peut rester visible, mais ses actions protégées déclenchent le
PIN.

Ne pas masquer complètement l'Atelier si cela empêche de comprendre
l'état ou les diagnostics.

## 15. Appareil personnel

Sur un appareil personnel sans protection :

- aucun cadenas permanent ;
- aucun bandeau `Mode Admin` ;
- aucune demande de PIN ;
- tous les workflows restent accessibles ;
- les suppressions conservent confirmation et sauvegarde préalable.

L'utilisateur peut activer les protections ultérieurement sans migrer ses
données.

Le fonctionnement personnel est le défaut produit, pas un mode avancé.

## 16. Indications visuelles

Les actions protégées doivent rester compréhensibles.

Avant déverrouillage, utiliser selon le contexte : petit cadenas ;
libellé `Protégé` ; explication au déclenchement.

Ne pas griser toutes les actions sans expliquer pourquoi.

Préférer : action visible ; demande de PIN lorsqu'elle est utilisée.

Cela permet à un utilisateur de tablette partagée de comprendre les
possibilités sans pouvoir les exécuter.

Lorsque la session curateur est ouverte :

- afficher une indication discrète dans l'Atelier ou la barre
  supérieure ;
- proposer `Verrouiller maintenant`.

Ne pas utiliser uniquement la couleur pour signaler l'état.

## 17. Matrice des actions

Créer dans le code une matrice ou politique centralisée des actions
protégées.

Ne pas disperser des conditions telles que `if (pinActif)` dans chaque
composant.

La politique doit pouvoir répondre à :

- action demandée ;
- protection activée ;
- session déverrouillée ou non ;
- autorisation résultante.

Catégories minimales :

- CONSULTATION ;
- MODIFICATION ;
- DESTRUCTION_OU_SENSIBLE.

Exemples :

- lire une fiche → CONSULTATION ;
- ajouter une note → MODIFICATION ;
- supprimer une technique → DESTRUCTION_OU_SENSIBLE ;
- restaurer → DESTRUCTION_OU_SENSIBLE ;
- changer le thème → CONSULTATION ou préférence non protégée ;
- changer les protections → DESTRUCTION_OU_SENSIBLE.

Les composants demandent une autorisation au service central et ne
réimplémentent pas les règles.

## 18. Opérations asynchrones

Une opération protégée déjà lancée après autorisation ne doit pas être
interrompue au milieu par l'expiration de session.

Exemples : import ; export ; restauration ; génération d'un pack ;
écriture d'une vidéo.

La permission est vérifiée avant le début.

L'expiration pendant l'opération :

- laisse l'opération se terminer ;
- verrouille les actions suivantes ;
- ne corrompt pas les données.

Ne jamais demander à nouveau le PIN au milieu d'une restauration.

## 19. Modifications non enregistrées

Si la session expire pendant un formulaire ouvert :

- ne pas effacer les données saisies ;
- empêcher uniquement l'enregistrement final si une nouvelle
  autorisation est nécessaire ;
- demander le PIN au moment d'enregistrer ;
- reprendre ensuite la sauvegarde.

Si l'utilisateur annule le déverrouillage :

- conserver le brouillon lorsque le workflow le permet ;
- ou proposer de quitter sans enregistrer.

Ne pas perdre silencieusement un commentaire ou une taxonomie en cours
d'édition.

## 20. Retour Android et arrière-plan

Lorsqu'un panneau PIN est ouvert :

- le bouton retour ferme le panneau ;
- revient au contexte précédent ;
- n'exécute pas l'action protégée.

Lors du passage en arrière-plan :

- mémoriser l'heure ;
- appliquer les règles de verrouillage au retour ;
- ne pas afficher brièvement un écran d'édition déverrouillé avant de se
  verrouiller.

Si l'application est capturée dans les applications récentes, éviter
d'exposer une vue sensible uniquement si les capacités Android actuelles
le permettent sans refactor lourd.

Tracer cette possibilité pour le lot plateforme si elle nécessite du
natif.

## 21. Sécurité des exports

Distinguer : pack publiable ; sauvegarde intégrale ; partage d'une
technique ; export d'une composition.

Lorsque la protection des opérations sensibles est active :

- publication et export complet exigent le PIN ;
- sauvegarde intégrale exige le PIN ;
- export d'un contenu personnel exige le PIN ;
- export public clairement limité à un corpus maîtrisé suit les règles de
  publication.

Ne pas inclure par défaut dans un pack publié : PIN ; hash ; sel ;
préférences de sécurité ; session ; historique d'échecs ; carnet
personnel.

Une sauvegarde intégrale ne doit pas permettre de lire le PIN en clair.

Décider et documenter si elle inclut :

- les réglages de protection sans secret ;
- ou aucun réglage de sécurité.

Recommandation :

- restaurer les données ;
- demander une nouvelle configuration des protections sur le nouvel
  appareil ;
- ne pas transporter automatiquement un PIN entre appareils.

## 22. Réinitialisation

La remise à zéro complète est une opération sensible.

Workflow :

1. expliquer ce qui sera supprimé ;
2. recommander ou proposer une sauvegarde ;
3. demander le PIN si la protection est active ;
4. demander une confirmation renforcée ;
5. supprimer les données ;
6. supprimer les réglages de sécurité ;
7. revenir à la Bibliothèque vide.

Ne pas laisser un ancien hash ou une session après réinitialisation.

Ne pas appeler cette opération simplement `Déconnexion`.

## 23. Journal et traçabilité

Conserver une trace minimale des événements de sécurité utiles au
diagnostic :

- protections activées ou désactivées ;
- PIN modifié ;
- déverrouillage réussi ;
- nombre agrégé d'échecs ;
- verrouillage manuel ;
- réinitialisation.

Ne jamais enregistrer : PIN ; hash complet dans un export de logs ;
contenu des formulaires ; texte personnel ; nom des vidéos comme
information de sécurité.

L'historique détaillé de type CSV de la V2 ne doit pas être recréé comme
fonction centrale.

## 24. Accessibilité

Le panneau PIN doit être utilisable : au clavier ; au tactile ; avec
lecteur d'écran.

Prévoir :

- titre décrivant l'action ;
- champ correctement étiqueté ;
- bouton Valider ;
- bouton Annuler ;
- message d'erreur annoncé ;
- zone tactile suffisante.

Ne pas déclencher automatiquement la validation avant que l'utilisateur
ait terminé si cela crée des erreurs de saisie.

## 25. Limites de la protection

Afficher dans la documentation et éventuellement dans l'aide courte :

- le PIN protège les actions dans Movenso ;
- il ne chiffre pas nécessairement toutes les données au repos ;
- il ne protège pas contre un utilisateur ayant accès au système de
  fichiers, au compte Android ou à la désinstallation ;
- la sécurité du terminal reste nécessaire.

Ne pas présenter Movenso comme un coffre-fort certifié.

Ne pas utiliser de formulation anxiogène dans l'interface courante.

## 26. Limites strictes du lot

Ne pas modifier :

- la navigation principale ;
- la Bibliothèque ;
- la fiche ;
- la capture ;
- les Favoris ;
- les Compositions ;
- l'architecture de l'Atelier hors section sécurité ;
- le modèle identité/contribution ;
- le rapprochement ;
- le format `.movpack` en profondeur ;
- le stockage des médias ;
- les plateformes ;
- la direction graphique générale.

Les changements de modèle autorisés sont limités à :

- réglages des protections ;
- paramètres de dérivation du PIN ;
- état de session non persistant ;
- éventuelle migration des anciens réglages.

Ne pas créer : comptes ; rôles multiples ; profils ; biométrie ;
synchronisation ; récupération distante ; chiffrement complet de la
bibliothèque.

Toute demande hors périmètre doit être **tracée pour un lot ultérieur**.

## 27. Critères d'acceptation

**Scénario A — appareil personnel**

1. installation vierge ;
2. ouvrir Movenso ;
3. créer une discipline ;
4. créer une technique ;
5. modifier une fiche ;
6. supprimer après confirmation ;
7. ne jamais rencontrer de PIN.

**Scénario B — première activation**

1. Atelier > Réglages et sécurité ;
2. activer Protéger les modifications ;
3. créer et confirmer un PIN ;
4. quitter l'Atelier ;
5. tenter de modifier une technique ;
6. voir la demande de PIN ;
7. annuler ;
8. vérifier qu'aucune donnée n'a changé.

**Scénario C — session curateur**

1. déclencher une modification ;
2. saisir le bon PIN ;
3. modifier la technique ;
4. modifier une seconde technique sans nouvelle demande immédiate ;
5. attendre l'expiration ;
6. tenter une troisième modification ;
7. voir la demande de PIN.

**Scénario D — protections distinctes**

1. protéger uniquement les suppressions ;
2. modifier une note sans PIN ;
3. tenter de supprimer la technique ;
4. saisir le PIN ;
5. voir ensuite la confirmation destructive ;
6. annuler ;
7. vérifier que la technique existe toujours.

**Scénario E — tablette partagée**

1. activer le préréglage Tablette partagée ;
2. relancer ;
3. explorer la Bibliothèque ;
4. lire une vidéo ;
5. consulter une composition ;
6. tenter d'ajouter une note ;
7. voir la demande de PIN ;
8. annuler et continuer la consultation.

**Scénario F — mauvais PIN**

1. saisir plusieurs PIN incorrects ;
2. voir une erreur sans fuite d'information ;
3. constater une temporisation progressive ;
4. saisir le bon PIN ;
5. retrouver l'action initiale.

**Scénario G — changement**

1. déverrouiller ;
2. changer le PIN ;
3. vérifier l'ancien PIN refusé ;
4. vérifier le nouveau accepté ;
5. vérifier la session précédente fermée.

**Scénario H — désactivation**

1. désactiver la protection des modifications ;
2. conserver celle des suppressions ;
3. modifier librement ;
4. supprimer avec PIN ;
5. désactiver la dernière protection ;
6. vérifier que le PIN n'est plus demandé.

**Scénario I — arrière-plan**

1. déverrouiller ;
2. mettre l'application en arrière-plan ;
3. attendre au-delà du seuil ;
4. revenir ;
5. tenter une modification ;
6. voir la demande de PIN ;
7. ne jamais voir brièvement une opération protégée exécutée.

**Scénario J — formulaire en cours**

1. ouvrir l'édition ;
2. saisir un texte ;
3. laisser la session expirer ;
4. enregistrer ;
5. saisir le PIN ;
6. vérifier que le texte est conservé et enregistré une seule fois.

**Scénario K — sauvegarde et restauration**

1. activer les protections ;
2. créer une sauvegarde intégrale ;
3. vérifier l'absence de PIN en clair ;
4. restaurer sur une installation vierge ;
5. vérifier que les données sont présentes ;
6. vérifier qu'une nouvelle configuration de sécurité est demandée ou que
   les protections sont désactivées selon la décision documentée.

**Scénario L — réinitialisation**

1. activer les deux protections ;
2. lancer la remise à zéro ;
3. lire les conséquences ;
4. saisir le PIN ;
5. annuler ;
6. recommencer et confirmer ;
7. vérifier bibliothèque vide et absence d'ancien PIN.

## 28. Tests

Ajouter ou adapter les tests pour couvrir :

- installation sans PIN ;
- activation au premier réglage ;
- confirmation du PIN ;
- absence de stockage en clair ;
- vérification correcte ;
- mauvais PIN ;
- temporisation ;
- protections indépendantes ;
- politique centralisée ;
- session temporaire ;
- expiration ;
- verrouillage manuel ;
- arrière-plan ;
- changement de PIN ;
- désactivation partielle et totale ;
- reprise d'une action après déverrouillage ;
- formulaire non perdu ;
- opération asynchrone non interrompue ;
- exclusion des secrets des exports ;
- restauration sans transport du secret ;
- migration des anciens réglages ;
- réinitialisation.

Ajouter un E2E vertical :

```
installation personnelle
→ modifier sans PIN
→ activer Tablette partagée
→ consulter librement
→ tenter une modification
→ déverrouiller
→ effectuer plusieurs modifications
→ expiration
→ tentative de suppression
→ PIN
→ confirmation
→ sauvegarde
→ inspection de l'absence de secret.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- clavier numérique ;
- arrière-plan ;
- expiration ;
- bouton retour ;
- changement d'orientation ;
- tablette partagée ;
- absence d'apparition furtive d'un contenu protégé ;
- session après fermeture forcée.

## 29. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- appareil personnel ;
- activation des protections ;
- tablette partagée ;
- action protégée ;
- session curateur ;
- expiration ;
- changement du PIN ;
- désactivation ;
- réinitialisation.

Ajouter un Mermaid compact :

```
Appareil personnel
→ aucune protection
→ modification directe

Appareil partagé
→ consultation libre
→ action protégée
→ PIN
→ session curateur temporaire
→ expiration ou verrouillage
```

`docs/systeme.md` :

- politique centralisée d'autorisation ;
- stockage du PIN ;
- dérivation ;
- session temporaire ;
- événements de verrouillage ;
- matrice des opérations ;
- exclusions des exports ;
- limites réelles de la sécurité.

Matrice de conservation :

- PIN V2 conservé comme protection facultative ;
- connexion Admin obligatoire supprimée ;
- modification autorisée par défaut ;
- tablette partagée conservée ;
- rôles Admin/Contributeur non repris ;
- confirmation et sauvegarde avant destruction conservées ;
- secret non exporté ;
- code de récupération non repris sauf justification explicite.

`docs/etat.md` :

- lot terminé ;
- protections réellement démontrées ;
- paramètres cryptographiques ;
- migrations ;
- limites ;
- prochain lot : formats, médias et plateformes.

## 30. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures ou vidéo montrant :
  - Réglages et sécurité sans protection ;
  - activation du mode partagé ;
  - création du PIN ;
  - demande de déverrouillage contextuelle ;
  - session curateur ouverte ;
  - action de verrouillage manuel ;
  - suppression avec PIN puis confirmation.

Rapport compact :

- fichiers modifiés ;
- matrice réelle des actions ;
- algorithme de dérivation utilisé ;
- comportement de la session ;
- migration des anciens réglages ;
- contenu de sécurité inclus ou exclu des sauvegardes ;
- limites explicites ;
- anomalies réservées au lot technique.

N'anticipe pas le lot 8 Formats, médias et plateformes.

Ne refonds pas les workflows métier ni l'identité graphique.

**La réussite de ce lot se mesure à une chose : Movenso reste
immédiatement consultable et modifiable sur un appareil personnel, tout
en devenant une tablette collective sûre et prévisible dès que son
propriétaire active volontairement les protections.**
