# LOT 4 — CRÉATION, CAPTURE ET ÉDITION : AJOUTER DU SAVOIR SANS FORMULAIRE MONOLITHIQUE

## Contexte

Le lot 1 a installé trois destinations principales :

- Bibliothèque ;
- Pratique ;
- Atelier.

Le lot 2 a rendu la Bibliothèque exploitable :

- disciplines uniques ;
- recherche globale ;
- grille visuelle ;
- filtres cumulables ;
- sources ;
- discipline vide ;
- création d'une première technique.

Le lot 3 a refondu la fiche technique :

- média principal en tête ;
- voix distinctes ;
- contribution personnelle directement éditable ;
- plusieurs médias ;
- édition contextuelle ;
- relations et compositions compactes ;
- actions destructrices déplacées.

La V3 possède actuellement plusieurs flux qui se chevauchent :

- créer une technique ;
- filmer ;
- choisir une vidéo ;
- coller un lien ;
- écrire un mot ;
- rattacher à une technique ;
- créer une contribution ;
- modifier une fiche.

Ces flux exposent encore parfois le modèle métier à l'utilisateur :

- demande de rattachement alors qu'aucune technique n'existe ;
- sélection de provenance ou d'auteur trop tôt ;
- formulaire trop long pour conserver une simple vidéo ;
- passage obligatoire par `Capturer` pour modifier une fiche connue ;
- création d'une technique, d'une contribution et d'un média confondues ;
- bouton global dont le sens varie selon l'écran.

Ce lot doit produire des workflows complets, distincts et cohérents pour :

1. créer une technique connue ;
2. capturer rapidement quelque chose pendant l'entraînement ;
3. rattacher immédiatement ou plus tard ;
4. créer une technique à partir d'une capture ;
5. modifier un contenu existant sans relancer le flux de capture.

## Objectif unique

Permettre à un utilisateur de créer, capturer, rattacher et modifier du
contenu sans impasse, sans formulaire monolithique et sans devoir
comprendre les objets internes de Movenso.

Le parcours doit notamment permettre :

- création minimale d'une technique ;
- capture d'une vidéo, d'un fichier, d'un lien ou d'un texte ;
- classement immédiat facultatif ;
- conservation comme brouillon à structurer ;
- création d'une technique depuis une capture ;
- contribution personnelle par défaut ;
- contribution d'enseignement ou de ressource sur choix explicite ;
- reprise et finalisation ultérieures ;
- absence de fichiers ou données orphelins après annulation ou échec.

## 1. Distinction des trois intentions

L'interface doit distinguer trois intentions.

**A. Créer une technique**

L'utilisateur sait ce qu'il veut ajouter au corpus.

Exemple : Créer `Crochet gauche` dans Boxe.

Résultat :

- une identité technique existe ;
- elle apparaît dans la Bibliothèque ;
- elle peut être enrichie immédiatement ou plus tard.

**B. Capturer quelque chose**

L'utilisateur veut conserver rapidement :

- une vidéo ;
- un fichier ;
- un lien ;
- un mot ou un commentaire.

Il ne sait pas nécessairement :

- le nom exact de la technique ;
- si la technique existe déjà ;
- comment la classifier ;
- si ce contenu deviendra personnel, club ou ressource.

Résultat possible :

- rattachement à une technique existante ;
- création d'une nouvelle technique ;
- conservation dans `À reprendre`.

**C. Modifier une technique ou contribution existante**

L'utilisateur connaît déjà la destination.

Exemples :

- corriger son commentaire personnel ;
- ajouter une seconde vidéo ;
- modifier un enseignement local ;
- corriger le nom ou les niveaux d'une technique qu'il maîtrise.

Ce parcours reste contextuel à la fiche et ne doit pas relancer le flux
générique de capture.

Ne pas présenter ces trois intentions comme une seule opération
`Capturer`.

## 2. Points d'entrée

Aucun bouton global permanent `Capturer` ne doit réapparaître dans le
shell.

**Bibliothèque — racine**

Prévoir une action contextuelle `Ajouter`.

Elle peut ouvrir un panneau compact contenant :

- Créer une technique ;
- Filmer ou garder quelque chose.

Si aucune discipline n'existe :

- `Créer une technique` commence par le choix ou la création d'une
  discipline ;
- `Filmer ou garder quelque chose` permet une capture sans discipline, à
  structurer plus tard.

**Bibliothèque — discipline ouverte**

Action contextuelle `Ajouter` ou `+`.

Options :

- Nouvelle technique ;
- Filmer maintenant ;
- Choisir un média ;
- Coller un lien ;
- Ajouter un repère.

La discipline ouverte est préselectionnée.

**Fiche technique**

Les actions sont locales :

- Ajouter un média ;
- Ajouter ou modifier mon repère ;
- Ajouter une contribution ;
- Modifier ce que je maîtrise.

Ne pas redemander la discipline ou la technique.

**Pratique**

Les captures personnelles non rattachées peuvent apparaître dans
`À reprendre`.

Ne pas ajouter dans ce lot un nouveau bouton global de capture dans
Pratique.

**Atelier**

Aucune action de capture générique.

L'Atelier pourra ultérieurement traiter les contenus à vérifier ou à
publier.

## 3. Panneau contextuel `Ajouter`

Le panneau `Ajouter` doit être court et orienté vers les gestes.

Exemple dans une discipline :

```
Que veux-tu ajouter ?

- Une technique
- Filmer maintenant
- Une vidéo ou un fichier
- Un lien
- Un mot ou commentaire
```

Ne pas afficher dans ce premier panneau :

- identité ;
- contribution ;
- provenance ;
- origine ;
- pack ;
- manifeste ;
- média plateforme.

Les choix techniques sont déduits plus tard par l'application.

La fermeture du panneau ne modifie aucune donnée.

## 4. Création minimale d'une technique

Le workflow de création doit permettre de créer une technique avec le
minimum suivant :

- discipline ;
- nom.

Si le workflow est lancé depuis une discipline :

- discipline préselectionnée ;
- ne pas la redemander.

Si aucune discipline n'existe :

- permettre de créer la discipline dans le même parcours ;
- revenir ensuite à la création de la technique ;
- ne pas perdre les informations déjà saisies.

Champs immédiatement visibles :

- Nom de la technique — obligatoire ;
- Appellation traditionnelle ou secondaire — facultative.

Classification facultative :

- famille ou catégorie ;
- niveau ;
- autres taxonomies existantes.

Ces informations doivent être dans une section facultative
`Classer maintenant` avec possibilité explicite `Je le ferai plus tard`.

Ne pas empêcher la création si aucune famille ou aucun niveau n'existe.

Après création, proposer sans imposer :

- Ajouter un média ;
- Ajouter une explication ;
- Ouvrir la fiche.

Le résultat par défaut est :

- création ;
- ouverture de la fiche ;
- technique immédiatement visible dans la discipline.

## 5. Prévention des doublons

Pendant la saisie du nom, rechercher les identités existantes dans la
même discipline.

Afficher des suggestions compactes :

```
Technique similaire déjà présente :
- Seoi-nage
- Morote-seoi-nage
```

Actions possibles :

- Utiliser cette technique ;
- Créer quand même une technique distincte.

Ne jamais fusionner automatiquement sur une simple ressemblance.

Si le nom normalisé correspond exactement à une identité unique :

- recommander de l'ouvrir ou de lui ajouter une contribution ;
- permettre la création séparée uniquement après confirmation explicite.

Si plusieurs correspondances sont ambiguës :

- ne prendre aucune décision silencieuse ;
- présenter les candidats ;
- laisser l'utilisateur choisir.

Ne pas modifier le moteur de rapprochement dans ce lot.

## 6. Capture rapide

Le workflow de capture rapide doit commencer par le contenu, pas par les
métadonnées.

**A. Filmer maintenant**

1. demander l'autorisation caméra si nécessaire ;
2. filmer ;
3. afficher un aperçu ;
4. proposer : Utiliser ; Refilmer ; Abandonner.

**B. Choisir un média**

1. ouvrir le sélecteur système ;
2. choisir le fichier ;
3. afficher un aperçu ou ses métadonnées ;
4. proposer : Utiliser ; Choisir un autre fichier ; Abandonner.

**C. Coller un lien**

1. saisir ou coller l'URL ;
2. détecter le service lorsque possible ;
3. afficher un aperçu ou le domaine ;
4. conserver l'URL originale ;
5. proposer : Utiliser ; Modifier ; Abandonner.

**D. Ajouter un mot ou commentaire**

1. afficher un champ libre ;
2. accepter un seul mot comme un texte long ;
3. ne pas imposer de nombre de lignes ;
4. ne pas imposer de taxonomie.

Exemples de libellés :

- Un mot à toi peut suffire
- Ce que tu veux retrouver plus tard

Ne pas demander la technique avant que le contenu soit capturé.

## 7. Décision de rattachement

Après capture du contenu, poser une question simple :

`Sais-tu où le ranger ?`

Trois possibilités : Rattacher à une technique existante ; Créer une
nouvelle technique ; Garder pour plus tard.

**A. Technique existante**

- rechercher dans la discipline présélectionnée ;
- permettre d'élargir à toutes les disciplines ;
- montrer nom, discipline et miniature ;
- rattacher le contenu ;
- ouvrir la fiche ou revenir au contexte initial.

**B. Nouvelle technique**

- reprendre le workflow minimal de création ;
- conserver la capture en mémoire pendant le parcours ;
- préselectionner la discipline connue ;
- créer l'identité ;
- rattacher le contenu ;
- ouvrir la fiche.

**C. Garder pour plus tard**

- créer une capture non rattachée ;
- conserver le média ou le texte ;
- indiquer où elle sera retrouvée : `Pratique > À reprendre` ;
- ne pas obliger à choisir une discipline ;
- permettre facultativement d'ajouter un libellé court.

Ne jamais perdre une capture parce que l'utilisateur ne connaît pas
encore le nom de la technique.

## 8. Contenu personnel par défaut

Le comportement par défaut d'une capture rapide est :

- auteur : Moi ;
- provenance : Personnel.

Ne pas demander systématiquement : auteur ; organisation ; provenance ;
source.

Prévoir une action secondaire :

`Ce contenu vient de quelqu'un d'autre`

Elle ouvre des choix simples :

- Enseignement d'un professeur ou d'un club ;
- Ressource externe ;
- Référentiel ou source officielle, uniquement si l'utilisateur possède
  réellement ce rôle de curation.

En cas d'enseignement, demander uniquement ce qui est nécessaire : nom du
professeur, du club ou de l'auteur ; commentaire facultatif.

En cas de ressource : auteur ou organisation ; lien ou attribution si
nécessaire.

Ne pas utiliser le nom du pack comme auteur par défaut.

Ne pas qualifier automatiquement une vidéo filmée sur le tatami comme
personnelle si l'utilisateur indique qu'elle montre l'enseignement du
professeur.

## 9. Capture non rattachée

Une capture non rattachée doit conserver :

- son identifiant ;
- type de contenu ;
- média ou texte ;
- date ;
- auteur ;
- provenance ;
- éventuelle discipline présélectionnée ;
- éventuel libellé ;
- état : à reprendre.

Elle ne doit pas créer une fausse technique vide.

Dans `Pratique > À reprendre`, l'utilisateur doit pouvoir :

- ouvrir la capture ;
- la lire ou la consulter ;
- la rattacher à une technique existante ;
- créer une technique ;
- modifier son libellé ou son texte personnel ;
- supprimer la capture avec confirmation.

Si le contenu n'est pas personnel mais relève d'un enseignement ou d'une
ressource :

- conserver la provenance choisie ;
- ne pas publier automatiquement ;
- permettre sa reprise ultérieure.

La réorganisation définitive de `À reprendre` appartient au lot Pratique,
mais le workflow doit déjà fonctionner.

## 10. Créer une technique à partir d'une capture

Ce parcours doit être atomique du point de vue utilisateur :

```
capture
→ nouvelle technique
→ rattachement
→ fiche.
```

Si la création échoue :

- la capture reste disponible ;
- aucun fichier média ne disparaît ;
- aucune identité partielle ne reste visible.

Si le rattachement échoue après création :

- proposer de réessayer ;
- conserver la technique et la capture dans un état cohérent ;
- ne pas dupliquer le fichier au prochain essai.

Si l'utilisateur annule la création :

- revenir au choix : rattacher ; garder pour plus tard ; abandonner.

## 11. Ajout de contribution à une technique existante

Depuis une fiche, permettre `Ajouter une contribution`.

Ce parcours est distinct de `Mon carnet`.

Exemples :

- enseignement du club ;
- explication du sensei ;
- ressource externe ;
- contribution personnelle plus développée.

Questions minimales :

1. De qui vient ce contenu ?
2. Que veux-tu ajouter ? (texte ; média ; texte et média)
3. Attribution facultative ou obligatoire selon le cas.

La technique ouverte est déjà connue.

Ne pas demander : discipline ; technique ; pack cible ; identifiant de
source.

Une contribution ajoutée par l'utilisateur ne modifie jamais une
contribution importée.

## 12. Édition d'une technique existante

Les opérations d'édition doivent réutiliser les composants ciblés du
lot 3.

**A. Modifier les informations générales**

- nom ; appellation ; familles ; niveaux ; média principal.

**B. Modifier une contribution maîtrisée**

- texte ; auteur ; attribution ; médias de cette contribution.

**C. Modifier son carnet**

- édition directe ; aucun assistant complet.

**D. Gérer les médias**

- ajouter ; retirer une référence maîtrisée ; changer le média principal ;
  modifier un libellé.

Ne pas réintroduire un formulaire unique comportant tous les champs du
modèle.

Ne pas obliger l'utilisateur à parcourir toutes les étapes lorsqu'il
corrige un seul champ.

## 13. Classification progressive

Une technique peut être créée sans : famille ; niveau ; description ;
média ; contribution longue.

L'application doit accepter cette incomplétude.

Elle peut signaler dans l'Atelier : technique sans famille ; technique
sans niveau ; technique sans média ; technique sans source claire.

Mais elle ne bloque pas la création.

Depuis la fiche ou l'Atelier, l'utilisateur peut enrichir progressivement.

Ne pas afficher des alertes anxiogènes pendant le geste de capture.

## 14. Gestion des médias pendant le flux

Utiliser les services de stockage existants.

Le workflow doit éviter :

- duplication d'un même fichier après double clic ;
- fichier orphelin après annulation ;
- référence enregistrée sans fichier ;
- perte après fermeture intempestive ;
- média ajouté deux fois après réessai.

Pendant une capture :

- utiliser un état temporaire jusqu'à confirmation ;
- ne rattacher définitivement qu'après validation ;
- nettoyer l'état temporaire après abandon lorsque cela est possible ;
- conserver une capture récupérable si l'écriture physique a réussi mais
  que le rattachement échoue.

Ne pas refondre dans ce lot tout le modèle physique des médias.

Toute faiblesse structurelle empêchant un comportement sûr doit être
documentée et isolée, pas masquée.

## 15. Permissions Android

Gérer clairement : autorisation caméra ; accès aux fichiers ; refus
temporaire ; refus permanent ; interruption par Android ; application
mise en arrière-plan.

En cas de refus :

- expliquer l'action nécessaire ;
- proposer une alternative : choisir un fichier ; coller un lien ; écrire
  un mot.

Ne pas bloquer tout le workflow parce qu'une permission est refusée.

Après retour depuis les réglages Android, reprendre le parcours lorsque
possible.

## 16. Annulation et retour

Le bouton retour Android suit cette priorité :

1. fermer le clavier ;
2. fermer le sélecteur ou panneau courant ;
3. revenir à l'étape précédente ;
4. proposer de conserver ou abandonner une capture déjà réalisée ;
5. quitter le workflow.

Si aucun contenu n'a été produit : quitter sans confirmation inutile.

Si une vidéo, un fichier ou un texte existe, afficher :

`Que faire de cette capture ?`

- Garder pour plus tard ;
- Continuer ;
- Abandonner.

Ne pas perdre silencieusement le contenu.

Ne pas enregistrer automatiquement comme contribution finale un contenu
abandonné.

## 17. Libellés

Utiliser un vocabulaire concret.

Préférer :

- Nouvelle technique ;
- Filmer maintenant ;
- Choisir une vidéo ;
- Coller un lien ;
- Ajouter un repère ;
- Rattacher ;
- Créer la technique ;
- Garder pour plus tard ;
- Ajouter une contribution.

Éviter dans l'interface courante :

- Instancier une identité ;
- Créer une contribution ;
- Sélectionner la provenance ;
- Élément source ;
- Média plateforme ;
- Flux de rattachement.

Le mot `Contribution` peut être utilisé dans la fiche ou l'Atelier
lorsque le contexte l'explique, mais pas comme première question au bord
du tatami.

## 18. Accessibilité et ergonomie

Les choix principaux doivent être utilisables : d'une main ; avec des
gants fins ou doigts humides ; sur téléphone ; sur tablette posée au bord
du tatami.

Prévoir :

- zones tactiles suffisantes ;
- libellés visibles ;
- pas uniquement des icônes ;
- pas de boutons principaux collés à la barre système ;
- progression compréhensible ;
- indication claire de l'étape lorsqu'il y en a plusieurs.

Limiter le nombre de choix simultanés.

Ne pas afficher toutes les options avancées par défaut.

## 19. Mode hors ligne

Tous les parcours locaux doivent fonctionner sans réseau : création ;
vidéo locale ; fichier local ; texte ; rattachement ; technique ;
contribution ; reprise.

Un lien externe peut être enregistré hors ligne même si son aperçu n'est
pas disponible.

L'absence de réseau ne doit pas empêcher la sauvegarde du lien.

Indiquer simplement : `Aperçu indisponible hors connexion`

Ne pas transformer une absence de réseau en erreur de données.

## 20. Conservation du contexte

Depuis une discipline :

- la discipline reste présélectionnée ;
- après création, revenir dans cette discipline ou ouvrir la fiche ;
- les filtres précédents restent conservés.

Depuis une fiche :

- la technique reste connue ;
- après ajout, rester sur la fiche ;
- le média ou la contribution nouvellement créé apparaît immédiatement.

Depuis une recherche globale :

- après création ou rattachement, le retour restaure la recherche.

Depuis `À reprendre` :

- après rattachement, retirer l'élément de la liste ;
- ouvrir la fiche ou revenir à la liste selon le choix utilisateur.

## 21. Actions de fin de parcours

Après création d'une technique :

- `Ouvrir la fiche`
- éventuellement `Ajouter autre chose`

Après rattachement d'une capture :

- `Voir la technique`
- `Retourner à la bibliothèque`

Après conservation pour plus tard, message court :

`Conservé dans Pratique > À reprendre`

Ne pas utiliser un bouton générique `Terminer`.

Ne pas créer un écran de succès inutile lorsque le retour direct suffit.

## 22. Limites strictes du lot

Ne pas modifier :

- la navigation principale ;
- la structure générale de la Bibliothèque ;
- la hiérarchie complète de la fiche ;
- le modèle identité/contribution ;
- le rapprochement inter-packs ;
- le format `.movpack` ;
- le stockage OPFS en profondeur ;
- le modèle des compositions ;
- les types de relation ;
- la structure interne de l'Atelier ;
- la sécurité et le PIN ;
- la publication ;
- la direction graphique globale.

Les adaptations métier autorisées sont limitées à :

- finaliser les workflows de création ;
- finaliser les captures non rattachées ;
- rattacher à une technique ;
- créer une technique depuis une capture ;
- ajouter une contribution ;
- réutiliser les éditions contextuelles ;
- garantir la cohérence des annulations et reprises.

Toute nouvelle idée hors périmètre doit être **tracée, pas implémentée**.

## 23. Critères d'acceptation

**Scénario A — création minimale**

1. ouvrir Judo ;
2. choisir Nouvelle technique ;
3. saisir uniquement `Nouvelle projection` ;
4. ignorer famille et niveau ;
5. créer ;
6. voir la fiche ;
7. revenir ;
8. retrouver la technique dans la grille.

**Scénario B — discipline créée de zéro**

1. installation vide ;
2. créer Boxe ;
3. choisir Créer la première technique ;
4. créer `Crochet gauche` ;
5. ajouter un repère facultatif ;
6. voir la technique dans Boxe ;
7. ne rencontrer aucune demande de rattachement incohérente.

**Scénario C — vidéo rattachée immédiatement**

1. ouvrir Judo ;
2. Filmer maintenant ;
3. filmer ;
4. choisir Rattacher à une technique existante ;
5. chercher O-goshi ;
6. rattacher ;
7. ouvrir la fiche ;
8. lire la vidéo dans la galerie.

**Scénario D — création depuis une capture**

1. ouvrir Boxe ;
2. filmer une technique inconnue ;
3. choisir Créer une nouvelle technique ;
4. nommer `Uppercut` ;
5. créer ;
6. voir la vidéo attachée ;
7. revenir ;
8. retrouver Uppercut dans la grille.

**Scénario E — garder pour plus tard**

1. filmer depuis la Bibliothèque ;
2. choisir Garder pour plus tard ;
3. fermer l'application ;
4. relancer ;
5. ouvrir Pratique ;
6. retrouver la capture dans À reprendre ;
7. la rattacher ;
8. vérifier qu'elle disparaît de la file et apparaît sur la fiche.

**Scénario F — mot personnel**

1. choisir Ajouter un repère ;
2. saisir `la banane` ;
3. rattacher à une technique ;
4. ouvrir la fiche ;
5. voir le texte dans Mon carnet ;
6. rechercher `la banane` depuis la Bibliothèque ;
7. retrouver la technique.

**Scénario G — enseignement**

1. filmer une démonstration ;
2. indiquer qu'elle vient d'un professeur ;
3. saisir son nom ;
4. rattacher à une technique ;
5. ouvrir la fiche ;
6. voir une voix Enseignement correctement attribuée ;
7. vérifier que le contenu n'apparaît pas comme personnel.

**Scénario H — annulation**

1. filmer ;
2. commencer le rattachement ;
3. appuyer sur retour ;
4. choisir Garder pour plus tard ;
5. vérifier que la vidéo n'est pas perdue ;
6. recommencer avec Abandonner ;
7. vérifier l'absence de capture et de technique fantôme.

**Scénario I — doublon potentiel**

1. créer `De Ashi Barai` dans Judo ;
2. voir la suggestion `De-ashi-harai` ;
3. choisir l'identité existante ;
4. ajouter le contenu ;
5. vérifier qu'aucune nouvelle identité n'est créée ;
6. recommencer et choisir explicitement Créer séparément ;
7. vérifier qu'une confirmation est nécessaire.

**Scénario J — ajout depuis une fiche**

1. ouvrir une technique ;
2. ajouter un média ;
3. ne jamais sélectionner à nouveau la discipline ou la technique ;
4. ajouter une contribution d'enseignement ;
5. revenir à la fiche ;
6. voir immédiatement les nouveaux contenus.

**Scénario K — hors ligne**

1. couper le réseau ;
2. créer une technique ;
3. filmer ;
4. saisir un repère ;
5. coller un lien externe ;
6. sauvegarder ;
7. relancer ;
8. retrouver tous les éléments locaux.

## 24. Tests

Ajouter ou adapter les tests pour couvrir :

- création avec nom uniquement ;
- discipline préselectionnée ;
- discipline créée dans le même parcours ;
- classification facultative ;
- suggestions de doublons ;
- absence de fusion automatique ;
- capture vidéo ;
- sélection fichier ;
- lien hors ligne ;
- texte personnel ;
- rattachement existant ;
- création depuis capture ;
- conservation pour plus tard ;
- reprise après relance ;
- provenance personnelle par défaut ;
- enseignement explicitement attribué ;
- annulation avec conservation ;
- abandon et nettoyage ;
- absence de fichiers orphelins dans les cas couverts ;
- absence de duplication après réessai ;
- retour vers le contexte d'origine.

Ajouter un scénario E2E vertical :

```
installation vide
→ créer Boxe
→ filmer
→ créer Crochet gauche depuis la capture
→ ajouter un mot personnel
→ fermer
→ relancer
→ retrouver la fiche
→ effectuer une seconde capture non rattachée
→ la reprendre
→ la rattacher
→ vérifier l'absence de doublon.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- caméra ;
- permissions ;
- sélecteur de fichiers ;
- mise en arrière-plan ;
- clavier ;
- bouton retour ;
- conservation d'une vidéo après interruption ;
- absence de chevauchement avec la barre basse.

## 25. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- création minimale ;
- capture vidéo ;
- sélection de fichier ;
- ajout de lien ;
- ajout d'un repère ;
- rattachement immédiat ;
- création depuis une capture ;
- conservation pour plus tard ;
- reprise ;
- contribution d'enseignement ;
- annulation.

Chaque workflow doit indiquer :

- entrée ;
- étapes ;
- sortie ;
- données créées ;
- niveau réel de démonstration : test unitaire ; e2e ; Android manuel ;
  validation terrain en attente.

Ajouter un Mermaid compact :

```
Ajouter
→ Technique
ou
→ Capture
   → Technique existante
   → Nouvelle technique
   → À reprendre
```

`docs/systeme.md` :

- composants partagés de création ;
- cycle de vie temporaire d'une capture ;
- rattachement ;
- reprise ;
- règles de provenance par défaut ;
- comportement en cas d'échec.

Matrice de conservation :

- création complète V2 conservée sous forme progressive ;
- formulaire monolithique V2 supprimé ;
- capture rapide V3 conservée ;
- rattachement différé conservé ;
- bouton Capturer global supprimé ;
- ajout direct depuis la fiche conservé ;
- classification obligatoire supprimée ;
- attribution explicite conservée lorsque nécessaire.

`docs/etat.md` :

- lot terminé ;
- scénarios démontrés ;
- limites connues ;
- éventuels risques médias non corrigés dans ce lot ;
- prochain lot : Pratique et Compositions.

## 26. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures ou courte vidéo montrant :
  - panneau Ajouter ;
  - création minimale ;
  - capture vidéo ;
  - choix de rattachement ;
  - création depuis une capture ;
  - capture À reprendre ;
  - contribution d'enseignement.

Rapport compact :

- fichiers modifiés ;
- points d'entrée ;
- étapes des différents workflows ;
- règles par défaut de provenance ;
- comportement des annulations ;
- gestion des captures temporaires ;
- tests réalisés ;
- anomalies hors périmètre.

N'anticipe pas le lot Pratique et Compositions.

Ne refonds pas le stockage média, l'Atelier, le format d'échange, les
relations ou la sécurité.

**La réussite de ce lot se mesure à une chose : au bord du tatami, un
utilisateur peut garder immédiatement une vidéo ou un mot, décider
maintenant ou plus tard où le ranger, et ne jamais perdre son contenu ni
remplir un formulaire inutile.**
