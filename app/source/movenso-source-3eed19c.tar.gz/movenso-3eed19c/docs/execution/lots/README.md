# Lots d’exécution

Créer un fichier par lot et y coller sans les résumer les prompts détaillés validés.

Noms attendus :

1. `01-navigation.md`
2. `02-bibliotheque.md`
3. `03-fiche-technique.md`
4. `04-creation-capture.md`
5. `05-pratique-compositions.md`
6. `06-atelier.md`
7. `07-securite.md`
8. `08-formats-medias-plateformes.md`
9. `09-identite-graphique.md`
10. `10-recette-finale.md`

`MASTER.md` décrit comment travailler. Chaque fichier de lot décrit quoi produire.

## Phase STABILISATION V1 (D-161, 2026-08-01)

Les lots 01-10 (roadmap V3) sont clos. La phase courante suit
[`docs/execution/audit-stabilisation-v1.md`](../audit-stabilisation-v1.md),
loti en trois lots séquentiels — chaque point est arbitré par le porteur
avant implémentation :

1. `S1-securite-integrite-plateforme.md` — les P0 (bloquants de publication)
2. `S2-fermeture-parcours.md` — les P1 (parcours complets, sans impasse)
3. `S3-maintenabilite-publication.md` — les P2 + P3 + P4 (dette, publication, finitions)

**Gel fonctionnel** pendant toute la phase : aucune nouvelle vue, aucun
nouveau type de relation, aucun enrichissement de pack, aucune fonction
secondaire tant que S1 et S2 ne sont pas clos.
