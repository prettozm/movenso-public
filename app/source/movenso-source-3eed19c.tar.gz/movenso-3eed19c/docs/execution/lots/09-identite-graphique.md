# LOT 9 — IDENTITÉ GRAPHIQUE ET CONSOLIDATION UX : DONNER À MOVENSO UNE EXPRESSION VISUELLE COHÉRENTE, SOBRE ET PROFESSIONNELLE

## Contexte

Les lots précédents ont défini et stabilisé :

- une navigation à trois onglets ;
- une Bibliothèque centrée sur les disciplines et les médias ;
- une fiche technique organisée autour du geste et des différentes
  voix ;
- des workflows contextuels de création et de capture ;
- un espace Pratique avec Favoris et Compositions ;
- un Atelier organisé autour de quatre intentions ;
- des protections facultatives ;
- des formats, médias, imports, sauvegardes et plateformes durcis.

L'application ne doit plus évoluer fonctionnellement dans ce lot.

La V3 actuelle présente plusieurs qualités :

- cohérence générale ;
- navigation basse ;
- composants modernes ;
- interface sombre ;
- langage visuel homogène.

Mais elle présente également des limites :

- surfaces sombres uniformes réduisant la respiration et la priorité
  donnée aux médias ;
- accumulation de cartes arrondies ;
- hiérarchie parfois portée presque uniquement par les conteneurs ;
- densité insuffisamment différenciée entre téléphone et tablette ;
- textes d'aide trop présents ;
- boutons ou badges trop nombreux dans certains écrans ;
- faible contraste entre consultation quotidienne et gestion du corpus ;
- identité Movenso encore générique ;
- rupture avec la richesse visuelle et l'efficacité de la Bibliothèque
  V2.

La direction cible reprend les qualités reconnues de la V2 sans recopier
son code ni ses lourdeurs :

- coque et navigation sombres ;
- contenu principalement clair ;
- grille visuelle dense ;
- médias fortement valorisés ;
- informations lisibles rapidement ;
- administration reléguée derrière l'Atelier ;
- sensation d'application martiale professionnelle, non folklorique.

## Objectif unique

Appliquer une identité graphique cohérente et consolider l'ergonomie de
tous les workflows validés, sans modifier leurs règles fonctionnelles.

Le résultat doit donner l'impression d'un produit :

- abouti ;
- stable ;
- immédiatement compréhensible ;
- adapté au bord du tatami ;
- lisible sur téléphone ;
- particulièrement efficace sur tablette ;
- générique pour toutes les disciplines ;
- sobre, distinctif et durable.

## 1. Interdiction de reconcevoir le produit

Ce lot ne doit modifier aucune décision métier validée.

Ne pas :

- recréer un Accueil ;
- ajouter un nouvel onglet ;
- déplacer les Favoris hors de Pratique ;
- exposer davantage les types internes de composition ;
- réintroduire un bouton global Capturer ;
- modifier le modèle identité/contribution ;
- changer les workflows de sécurité ;
- modifier les formats ;
- réorganiser fonctionnellement l'Atelier ;
- créer de nouvelles fonctionnalités.

Les adaptations autorisées concernent :

- mise en page ;
- typographie ;
- couleurs ;
- icônes ;
- densité ;
- responsive ;
- hiérarchie visuelle ;
- libellés courts ;
- placement des actions déjà validées ;
- feedback ;
- accessibilité ;
- cohérence entre écrans.

Si une faiblesse fonctionnelle est découverte :

- la documenter ;
- ne pas la corriger dans ce lot sauf blocage visuel strict.

## 2. Direction générale

Adopter une direction dite `coque sombre, contenu vivant`.

La coque comprend : barre supérieure ; barre basse ; navigation interne
structurante ; éventuellement panneau latéral sur grand écran.

Elle utilise une surface sombre et stable.

Le contenu principal utilise par défaut :

- fonds clairs ou très légèrement teintés ;
- surfaces médias franches ;
- typographie sombre ;
- séparateurs discrets ;
- couleur d'accent limitée.

L'application ne doit pas ressembler : à un tableau de bord SaaS ; à un
thème gaming ; à un dojo japonais décoratif ; à une application de
fitness générique ; à un panneau d'administration sombre uniforme.

Éviter : motifs de tatami ; calligraphie décorative ; drapeaux ; kanji
codés en dur ; silhouettes de combat omniprésentes ; flammes, néons ou
effets métalliques ; couleurs de ceinture utilisées comme langage global.

L'identité martiale vient : du contenu ; des gestes ; des médias ; de la
précision ; de la structure ; du rythme visuel.

## 3. Thèmes

Conserver trois réglages lorsque déjà supportés : Système ; Clair ;
Sombre.

Thème clair recommandé comme référence principale de conception : coque
sombre ; contenu clair ; médias contrastés.

Thème sombre :

- conserver la même hiérarchie ;
- ne pas simplement inverser chaque couleur ;
- éviter l'enchaînement de cartes légèrement différentes sur un fond
  noir ;
- utiliser des séparateurs, de l'espace et des changements de surface
  mesurés.

Le thème système suit le terminal.

Tous les composants doivent être lisibles dans les deux thèmes.

Aucun texte ou badge ne doit devenir invisible selon le thème.

## 4. Système de tokens

Centraliser les valeurs visuelles dans un système de tokens.

Catégories minimales : surfaces ; textes ; accent ; états ; provenance ;
bordures ; ombres ; rayons ; espacements ; dimensions tactiles ;
typographie ; navigation ; médias.

Ne pas disperser des valeurs hexadécimales et dimensions arbitraires dans
chaque composant.

Limiter le nombre de niveaux de surfaces.

Exemple conceptuel :

```
surface-shell
surface-page
surface-elevated
surface-muted
surface-media
text-primary
text-secondary
text-on-shell
border-subtle
accent-primary
state-danger
state-warning
state-success
```

Ne pas créer un token pour chaque écran.

## 5. Couleur d'accent

Choisir une couleur principale sobre et suffisamment distinctive.

Elle sert à : destination active ; action principale ; focus ;
sélection ; progression ; liens utiles.

Elle ne doit pas colorer : tous les titres ; toutes les icônes ; toutes
les cartes ; toutes les bordures.

Conserver éventuellement une nuance chaude ou naturelle cohérente avec
Movenso, sans imiter une couleur de ceinture.

La décision exacte doit être appliquée de manière centralisée et
documentée.

Ne pas proposer un sélecteur complet de couleurs dans ce lot.

## 6. Typographie

Utiliser une typographie système ou embarquée déjà compatible avec les
plateformes.

Ne pas ajouter une police exotique ni un poids lourd inutile.

Définir une échelle limitée : titre de page ; titre de section ; titre de
technique ; texte courant ; métadonnée ; libellé d'action ; légende.

Les noms de techniques doivent être particulièrement lisibles.

Les appellations traditionnelles doivent être : secondaires ;
immédiatement associées au nom principal ; suffisamment grandes pour
rester utiles ; sans style pseudo-calligraphique.

Éviter : textes tout en capitales ; corps trop petits ; titres coupés sur
une ligne alors que l'espace permet deux lignes ; contrastes faibles pour
les métadonnées.

Les textes longs de contributions doivent avoir une largeur de lecture
maîtrisée sur tablette.

## 7. Espacement et densité

Créer une échelle d'espacements cohérente.

**Téléphone :**

- actions tactiles confortables ;
- marges suffisantes ;
- contenu non collé aux bords ;
- deux colonnes visuelles lorsque pertinent.

**Tablette :**

- réduire les grandes zones vides ;
- augmenter le nombre de colonnes ;
- utiliser des panneaux côte à côte ;
- éviter d'étirer une carte téléphone sur toute la largeur.

**Grand écran :**

- largeur maximale du contenu ;
- densité accrue ;
- navigation interne latérale lorsque déjà prévue ;
- fiche ou détail affichable à côté d'une liste lorsque cela ne modifie
  pas la navigation fonctionnelle.

Ne pas appliquer une largeur fixe unique à tous les écrans.

## 8. Rayons et cartes

Réduire l'usage systématique des cartes arrondies.

Utiliser une carte lorsque l'élément est réellement : autonome ;
ouvrable ; déplaçable ; sélectionnable ; comparable à ses voisins.

Utiliser plutôt : espace ; titre ; séparateur ; changement léger de
fond ; alignement — pour structurer : métadonnées ; sections d'une
fiche ; réglages ; explications ; listes simples.

Limiter les rayons à deux ou trois valeurs.

Les grandes cartes imbriquées dans d'autres cartes sont interdites sauf
nécessité démontrée.

Ne pas entourer chaque ligne de réglage d'un rectangle.

## 9. Icônes

Utiliser une seule famille d'icônes cohérente.

Les icônes doivent être : simples ; reconnaissables ; non décoratives ;
accompagnées d'un libellé lorsque le sens n'est pas évident.

Éviter plusieurs symboles différents pour la même action.

Standardiser notamment : Bibliothèque ; Pratique ; Atelier ; Favori ;
Ajouter ; Filmer ; Média ; Modifier ; Supprimer ; Importer ; Publier ;
Sauvegarder ; Restaurer ; Protéger ; Verrouiller.

Ne pas utiliser des emojis comme icônes de production.

## 10. Barre supérieure

La barre supérieure appartient à la coque sombre.

Elle affiche selon le contexte : retour ; titre court ; action
contextuelle secondaire ; menu supplémentaire.

Ne pas afficher simultanément : titre très long ; plusieurs badges ;
trois boutons ; menu ; explication.

Sur une racine d'onglet :

- titre Movenso ou nom de la destination ;
- action réellement utile seulement.

Sur une fiche :

- retour ;
- nom de la technique ;
- menu secondaire.

Sur tablette, le titre peut être plus riche si l'espace le permet.

La barre ne doit pas changer brutalement de hauteur entre les écrans.

## 11. Navigation basse

Conserver exactement : Bibliothèque ; Pratique ; Atelier.

La navigation basse reste sombre.

L'onglet actif est identifiable par plusieurs signaux : icône ;
libellé ; contraste ou fond ; éventuellement indicateur.

Ne pas utiliser uniquement une légère variation de couleur.

Respecter : zones sûres Android ; hauteur tactile ; textes non tronqués ;
orientation paysage ; clavier.

Ne pas ajouter : Accueil ; Capturer ; Réglages ; Compositions comme
quatrième destination.

## 12. Action contextuelle principale

Une seule action principale visible au maximum par écran.

Exemples :

- discipline → Ajouter ;
- liste Compositions → Nouvelle composition ;
- discipline vide → Créer la première technique ;
- fiche sans média → Ajouter un média ;
- Atelier → aucune action globale générique.

Sur mobile, elle peut prendre la forme : bouton flottant ; bouton dans la
barre ; bouton plein dans un état vide.

Le choix doit dépendre du contexte, mais rester cohérent.

Le bouton flottant ne doit pas masquer : la navigation basse ; une
vidéo ; une action destructive ; le dernier élément d'une liste.

Ne pas afficher plusieurs boutons flottants.

## 13. Bibliothèque — racine

La racine Bibliothèque doit exprimer immédiatement la richesse du
contenu.

Conserver : recherche globale visible ; disciplines ; compteurs utiles ;
aperçu visuel.

Les cartes de disciplines peuvent utiliser : mosaïque légère de
miniatures ; média représentatif ; initiale sobre en fallback ; nom ;
compte d'identités ; sources ou voix lorsque pertinent.

Ne pas utiliser une grande icône disciplinaire générique occupant
l'essentiel de la carte si des médias existent.

La racine ne doit pas ressembler à un panneau de configuration.

État vide : illustration facultative très simple ; une phrase ; deux
actions ; aucun long paragraphe.

## 14. Bibliothèque — discipline

La grille technique est le cœur visuel du produit.

Priorités :

1. média ;
2. nom ;
3. appellation ;
4. niveaux ou informations utiles ;
5. pluralité des voix.

Les cartes doivent rester suffisamment grandes pour lire le geste.

Éviter : métadonnées trop nombreuses ; multiples badges empilés ;
boutons d'administration ; texte descriptif.

Sur téléphone : deux colonnes lorsque réaliste ; une colonne uniquement
lorsque l'accessibilité ou le contenu l'exige.

Sur tablette : trois à six colonnes selon la largeur ; carte de largeur
stable ; alignement propre.

Les miniatures doivent avoir : ratio commun ; recadrage cohérent ;
fallback visuel homogène ; état média manquant distinct d'une technique
sans média.

## 15. Recherche et filtres

La recherche reste immédiatement visible.

Les filtres actifs doivent être compréhensibles sans occuper la moitié de
l'écran.

Utiliser : rangée horizontale scrollable ; panneau inférieur ; bouton
Filtres avec compteur ; chips uniquement pour les sélections actives.

Ne pas afficher en permanence toutes les familles, sources et niveaux
sous forme de dizaines de boutons.

Les chips ne doivent pas devenir le seul langage de l'application.

État aucun résultat :

- distinguer bibliothèque vide et filtres trop restrictifs ;
- montrer la possibilité de réinitialiser ;
- conserver la requête visible.

## 16. Fiche technique

La fiche doit suivre la hiérarchie validée : média principal ; identité ;
classifications ; voix ; carnet ; relations ; compositions ; actions
secondaires.

Le média principal doit être le premier élément visuel majeur.

Ne pas enfermer le lecteur dans plusieurs couches de cartes.

La galerie secondaire doit être compacte et tactile.

Les informations générales utilisent : lignes ; groupes ; badges
limités ; séparateurs.

Les voix sont présentées dans une section claire avec une seule voix
développée.

La source ouverte doit être immédiatement identifiable.

Les autres voix restent visibles comme choix, pas comme grands blocs
empilés.

## 17. Provenance et sources

Définir un langage visuel cohérent pour : Référentiel ; Enseignement ;
Ressource ; Personnel.

La provenance peut utiliser : libellé ; icône ; accent discret.

Ne jamais reposer uniquement sur une couleur.

Ne pas attribuer une couleur forte différente à chaque source ou pack.

Le nom de la source ou de l'auteur reste prioritaire : Kodokan ; Judo
Club de Castres ; Sensei Martin ; Moi.

La provenance est secondaire : `Kodokan · Référentiel`

## 18. Mon carnet

Mon carnet doit être identifiable comme espace personnel sans sembler
détaché de la fiche.

État vide : invitation discrète ; action locale.

État rempli : texte lisible ; modification simple ; signal personnel
compact.

Ne pas utiliser une grande carte colorée pour un seul mot.

Le texte doit pouvoir être très court sans donner l'impression d'un
composant vide.

## 19. Pratique

La racine de Pratique doit être compacte et personnelle.

**À reprendre :**

- mise en avant uniquement lorsqu'une action existe ;
- accent modéré de type attention ;
- pas de rouge si aucune erreur.

**Favoris :**

- grille ou carrousel visuel ;
- accès rapide ;
- cohérence avec la Bibliothèque.

**Compositions :**

- cartes plus éditoriales ;
- titre ;
- aperçu d'étapes ;
- dernière modification ;
- action Démarrer facilement identifiable.

Ne pas présenter Favoris, À reprendre et Compositions comme trois énormes
panneaux de même poids.

## 20. Éditeur de composition

L'éditeur doit rester simple.

Actions visibles : Ajouter une technique ; Ajouter du texte.

Les blocs utilisent deux traitements distincts mais sobres.

**Technique :** miniature ; nom ; poignée ; menu.

**Texte :** texte ; poignée ; édition.

Ne pas afficher le type interne du bloc.

Le réordonnancement doit être lisible sans transformer chaque bloc en
grande carte.

Les actions de suppression restent secondaires.

## 21. Mode entraînement

Le mode entraînement est une rupture visuelle volontaire.

Il privilégie : contenu ; lisibilité ; grandes actions ; distraction
minimale.

Masquer : navigation basse ; commandes d'administration ; informations
techniques.

Afficher : progression ; technique ou texte courant ; média lorsque
pertinent ; Précédent ; Suivant ; Quitter.

Le mode doit fonctionner à plusieurs mètres sur tablette.

Prévoir une taille de texte et des actions adaptées.

Ne pas utiliser un carrousel décoratif complexe.

## 22. Atelier

L'Atelier doit être visuellement plus dense que la Bibliothèque, sans
redevenir un panneau Admin.

**Racine :**

- quatre intentions clairement distinctes ;
- pictogramme sobre ;
- description d'une ligne maximum ;
- problème éventuel.

**Dans une intention :**

- titre ;
- sous-navigation ;
- listes d'actions ;
- indicateurs actionnables.

Éviter : paragraphes introductifs permanents ; cartes imbriquées ;
boutons de même poids pour toutes les opérations.

**Actions sensibles :**

- poids visuel distinct ;
- jamais en action principale par défaut ;
- zone danger lorsque nécessaire.

## 23. Formulaires

Les formulaires doivent être ciblés.

Règles :

- labels persistants ;
- aide courte ;
- erreurs près du champ ;
- champs facultatifs indiqués ;
- clavier adapté ;
- bouton principal clair ;
- annulation disponible.

Ne pas utiliser uniquement des placeholders comme labels.

Les sections avancées restent repliées.

Les formulaires longs doivent être découpés seulement lorsque cela
correspond à de vraies étapes, pas artificiellement.

Éviter les boutons Terminer ; Continuer — lorsque l'action réelle peut
être nommée : Créer ; Ajouter ; Importer ; Restaurer ; Publier ;
Enregistrer.

## 24. Dialogues et panneaux

Utiliser : panneau inférieur pour choix courts sur mobile ; dialogue pour
confirmation ; écran complet pour workflow complexe ; panneau latéral
sur tablette si utile.

Ne pas utiliser un dialogue étroit pour : importer un pack ; éditer une
longue contribution ; inspecter une sauvegarde.

Une confirmation destructive contient : objet ; conséquences ;
possibilité de restauration ; action clairement nommée.

Le bouton dangereux ne doit pas être placé là où l'utilisateur attend le
bouton principal habituel sans distinction.

## 25. États vides

Standardiser les états vides.

Ils contiennent au maximum : titre ; une phrase ; action principale ;
action secondaire éventuelle.

Exemples distincts : bibliothèque vide ; discipline vide ; aucun favori ;
aucune composition ; aucun résultat de filtre ; aucun problème Atelier ;
aucune capture à reprendre.

Ne pas répéter le même texte générique partout.

Ne pas afficher une illustration différente lourde pour chaque cas.

## 26. Chargements

Éviter les écrans blancs ou les spinners globaux lorsque le contenu peut
être affiché progressivement.

Utiliser : skeletons simples ; progression ; état média en cours de
chargement ; indicateur local.

**Import, export, sauvegarde et restauration :**

- progression déterminée lorsque possible ;
- étape courante ;
- volume traité ;
- possibilité d'annuler si sûre.

Ne pas afficher un spinner indéfini pour une opération pouvant durer
plusieurs minutes.

## 27. Feedback et messages

Les confirmations légères utilisent : toast ; message inline ;
changement visuel immédiat.

Exemples : Ajouté aux favoris ; Repère enregistré ; Média ajouté ;
Capture conservée.

Les opérations structurantes utilisent un rapport : import ;
restauration ; publication ; sauvegarde.

Éviter les messages techniques : `Entity updated` ; `OPFS write
successful` ; `Contribution created`.

Les erreurs doivent indiquer : ce qui n'a pas fonctionné ; si les données
sont préservées ; l'action possible.

## 28. Erreurs et alertes

Définir trois niveaux visuels : information ; attention ; erreur ou
danger.

Ne pas utiliser le rouge pour : contenu incomplet facultatif ; absence de
média ; capture à reprendre ; technique sans niveau.

Le rouge est réservé à : intégrité rompue ; suppression ; échec
bloquant ; risque de perte.

Les avertissements doivent être accompagnés d'un texte ou d'une icône
accessible.

## 29. Accessibilité

Respecter au minimum : contraste des textes ; contraste des actions ;
focus clavier visible ; zones tactiles ; libellés lecteurs d'écran ;
ordre de navigation ; alternatives aux gestes ; états non représentés
uniquement par la couleur ; réduction des animations si le système le
demande.

Les vidéos doivent permettre : lecture ; pause ; contrôle du volume
lorsque pertinent ; navigation clavier sur web.

Les glisser-déposer disposent d'une alternative.

Les textes peuvent être agrandis sans rendre l'écran inutilisable.

## 30. Animations

Utiliser des animations courtes pour : ouverture de panneau ; changement
d'onglet ; insertion ou déplacement ; expansion de section ; feedback.

Ne pas utiliser : transitions longues ; parallaxe ; zooms spectaculaires ;
animations permanentes ; effets de rebond excessifs.

Respecter `prefers-reduced-motion`.

Le produit doit rester fluide sur un terminal Android moyen.

## 31. Tablette

La tablette est une cible prioritaire de Movenso.

**Bibliothèque :**

- grille plus dense ;
- filtres accessibles ;
- aperçu ou fiche éventuellement côte à côte si la navigation reste
  compréhensible.

**Fiche :**

- média à gauche ou en largeur maîtrisée ;
- voix et carnet à droite lorsque l'espace le permet ;
- pas d'immense vidéo étirée inutilement.

**Pratique :**

- favoris et compositions dans une grille ;
- mode entraînement lisible à distance.

**Atelier :**

- menu interne à gauche ;
- détail à droite ;
- listes plus denses.

Ne pas simplement agrandir les composants téléphone.

## 32. Paysage

Tester téléphone et tablette en paysage.

La barre basse, les panneaux et les médias ne doivent pas : chevaucher
les zones système ; masquer les actions ; occuper toute la hauteur.

Le mode entraînement doit particulièrement bénéficier du paysage.

Ne pas imposer une seule orientation sauf nécessité technique déjà
validée.

## 33. Identité Movenso

Le nom Movenso doit être visible avec sobriété.

Ne pas répéter le logo sur chaque écran.

L'identité peut reposer sur : contraste coque/contenu ; accent ; forme
simple ; rythme typographique ; traitement des médias.

Ne pas créer dans ce lot un nouveau logo complexe ou une mascotte.

Utiliser le logo existant s'il est suffisamment propre.

Sinon :

- conserver une marque typographique temporaire ;
- documenter le besoin de branding séparé ;
- ne pas ralentir le produit.

## 34. Cohérence des libellés

Faire une passe complète sur les libellés visibles.

Uniformiser : Ajouter une technique ; Ajouter un média ; Nouvelle
composition ; Importer un pack ; Publier un pack ; Créer une
sauvegarde ; Restaurer ; Protéger les modifications ; Protéger les
suppressions.

Éliminer les termes incohérents : pack utilisé comme synonyme de
discipline ; collection non définie ; Capturer pour toute action ;
Retirer sans objet ; Terminer hors workflow ; Club lorsqu'un nom précis
existe ; Admin lorsque Atelier ou Curateur suffit.

Ne pas réécrire les textes métier des contributions.

## 35. CSS et architecture des composants

Éviter un nouveau monolithe CSS.

Organiser : tokens globaux ; styles de coque ; composants primitifs ;
dispositions ; styles propres aux fonctionnalités.

Créer ou consolider des composants réutilisables uniquement lorsqu'ils
portent une vraie cohérence : bouton ; icône ; champ ; badge ; chip ;
carte média ; état vide ; dialogue ; panneau ; barre d'actions ; lecteur ;
grille.

Ne pas transformer chaque élément en composant abstrait générique.

Ne pas déplacer la logique métier dans les composants de design.

## 36. Performance visuelle

Conserver : rendu progressif ; miniatures ; lazy loading ; un seul
lecteur actif ; listes fluides.

Éviter : ombres lourdes ; filtres CSS coûteux ; arrière-plans floutés sur
toute la page ; animations sur de grandes listes ; recalculs de layout à
chaque défilement.

Tester une Bibliothèque avec plusieurs centaines de techniques.

Les changements visuels ne doivent pas dégrader les temps d'ouverture
validés.

## 37. Captures de référence

Créer un corpus de captures de référence pour les écrans clés :
Bibliothèque vide ; racine Bibliothèque ; discipline ; filtres actifs ;
fiche avec média ; fiche multi-voix ; Pratique ; Favoris ; Composition en
édition ; mode entraînement ; Atelier ; diagnostic ; import ; sécurité ;
thème sombre ; téléphone ; tablette.

Ne pas utiliser les captures comme tests uniques.

Elles servent : à détecter les incohérences ; à documenter le produit ;
à comparer les régressions futures.

## 38. Tests de régression visuelle

Ajouter des tests visuels ciblés si l'infrastructure actuelle le permet.

Résolutions minimales : téléphone étroit ; téléphone standard ; tablette
portrait ; tablette paysage ; desktop.

Tester : thème clair ; thème sombre sur quelques écrans principaux ;
texte long ; nom long ; absence de média ; plusieurs sources ; données
vides ; erreur.

Ne pas créer une suite fragile couvrant chaque pixel de chaque écran.

Cibler les structures majeures.

## 39. Limites strictes du lot

Ne pas modifier :

- modèle métier ;
- stockage ;
- format `.movpack` ;
- recherche ;
- règles de rapprochement ;
- sécurité ;
- workflow de capture ;
- logique des compositions ;
- publication ;
- import ;
- restauration ;
- cible Android ;
- PWA ou Electron.

Ne pas ajouter : nouvel écran fonctionnel ; nouvel onglet ; nouvelle
taxonomie ; nouvelle provenance ; nouvelles statistiques ; nouveau rôle.

Toute modification fonctionnelle nécessaire doit être **remontée avant
implémentation**.

## 40. Critères d'acceptation

**Scénario A — identité globale**

1. lancer l'application ;
2. voir une coque sombre cohérente ;
3. voir un contenu clair et visuel ;
4. naviguer dans les trois onglets ;
5. conserver une identité constante ;
6. ne rencontrer aucun écran sombre uniforme sans hiérarchie.

**Scénario B — Bibliothèque**

1. ouvrir une discipline avec plus de cent techniques ;
2. voir une grille média-first ;
3. lire les noms ;
4. utiliser recherche et filtres ;
5. ne pas voir de badges ou actions superflus ;
6. défiler sans perte de fluidité.

**Scénario C — fiche**

1. ouvrir une fiche avec plusieurs voix et médias ;
2. voir le média immédiatement ;
3. identifier la source ;
4. changer de voix ;
5. modifier Mon carnet ;
6. consulter relations et compositions ;
7. ne pas traverser une succession de cartes imbriquées.

**Scénario D — Pratique**

1. ouvrir Pratique avec À reprendre, Favoris et Compositions ;
2. distinguer les trois usages immédiatement ;
3. ouvrir une composition ;
4. l'éditer ;
5. lancer le mode entraînement ;
6. lire l'écran à distance sur tablette.

**Scénario E — Atelier**

1. ouvrir Atelier ;
2. identifier les quatre intentions ;
3. entrer dans Médias et qualité ;
4. traiter un problème ;
5. ouvrir Échanger et protéger ;
6. ne jamais rencontrer de mur de texte ou de tableau de bord décoratif.

**Scénario F — action contextuelle**

1. Bibliothèque → action Ajouter ;
2. Pratique → Nouvelle composition ;
3. Atelier → aucune action générique ;
4. fiche → Ajouter un média ;
5. ne jamais voir Capturer comme bouton universel.

**Scénario G — téléphone**

1. tester portrait et paysage ;
2. utiliser tous les workflows principaux ;
3. ne rencontrer aucun chevauchement ;
4. conserver des zones tactiles suffisantes ;
5. ne pas devoir zoomer.

**Scénario H — tablette**

1. ouvrir Bibliothèque ;
2. voir une densité supérieure au téléphone ;
3. ouvrir une fiche ;
4. exploiter la largeur ;
5. utiliser le mode entraînement ;
6. administrer dans l'Atelier sans écrans inutilement étirés.

**Scénario I — thème sombre**

1. activer le thème sombre ;
2. parcourir les écrans principaux ;
3. vérifier les contrastes ;
4. distinguer les niveaux de surface ;
5. ne pas voir une accumulation de rectangles gris.

**Scénario J — accessibilité**

1. navigation clavier web ;
2. lecteur d'écran sur actions critiques ;
3. réduction des animations ;
4. agrandissement du texte ;
5. alternative au glisser-déposer ;
6. états compréhensibles sans couleur.

## 41. Tests

Ajouter ou adapter les tests pour couvrir :

- trois destinations ;
- action principale unique ;
- absence de Capturer global ;
- thèmes ;
- responsive ;
- zones sûres ;
- affichage de noms longs ;
- états vides ;
- erreurs ;
- sources ;
- provenance ;
- composants principaux ;
- navigation clavier ;
- `prefers-reduced-motion`.

Ajouter une série de tests visuels ciblés.

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire sur :

- petit téléphone ;
- téléphone standard ;
- tablette portrait ;
- tablette paysage ;
- thème système clair ;
- thème système sombre ;
- taille de texte agrandie ;
- gestes et retour Android.

## 42. Documentation

Mettre à jour uniquement les documents existants.

`docs/systeme.md` :

- tokens ;
- thèmes ;
- composants ;
- responsive ;
- architecture CSS ;
- règles d'accessibilité.

`docs/workflows.md` :

- mettre à jour les captures ;
- ne pas modifier les flux ;
- vérifier que les schémas correspondent toujours aux écrans.

Créer ou mettre à jour la section de guide visuel existante avec :
principes ; coque ; surfaces ; typographie ; accent ; états ; provenance ;
cartes ; grilles ; actions ; responsive.

Matrice de conservation :

- force visuelle et médias de la V2 conservés ;
- navigation basse V3 conservée ;
- mur sombre uniforme supprimé ;
- accumulation de cartes réduite ;
- panneau Admin V2 non repris ;
- densité tablette renforcée ;
- logique métier inchangée.

`docs/etat.md` :

- lot terminé ;
- écrans couverts ;
- écrans restant à polir ;
- résultats des tests visuels ;
- prochain lot : recette et clôture.

## 43. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- corpus complet de captures téléphone et tablette ;
- comparaison avant/après sur les principaux écrans ;
- inventaire des tokens ;
- rapport d'accessibilité ;
- résultats des tests visuels.

Rapport compact :

- fichiers modifiés ;
- composants créés ou consolidés ;
- règles visuelles retenues ;
- éléments V2 réinterprétés ;
- éléments V3 conservés ;
- nombre de valeurs CSS remplacées par des tokens ;
- éventuelles incohérences fonctionnelles découvertes mais non
  modifiées ;
- performances avant et après.

N'anticipe pas le lot 10 Recette finale.

Ne modifie aucun workflow déjà validé.

**La réussite de ce lot se mesure à une chose : Movenso doit sembler
évident à utiliser, professionnel à présenter et suffisamment sobre pour
laisser les gestes, les sources et le savoir martial occuper la première
place.**
