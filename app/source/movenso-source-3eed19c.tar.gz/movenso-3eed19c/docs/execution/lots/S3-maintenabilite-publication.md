# Lot S3 — Maintenabilité, publication et finitions (P2 + P3 + P4 de l'audit)

> **Phase : STABILISATION V1** (D-161). Source : [`docs/execution/audit-stabilisation-v1.md`](../audit-stabilisation-v1.md), chantiers P2.1 → P2.14, P3.1 → P3.13, P4.1 → P4.6, matrice de recette et critères v1.
> **ARBITRÉ le 2026-08-02 (D-174)** : analyse et ordre validés sur le principe, questions d'arbitrage posées **étape par étape** au moment d'attaquer chaque point.
> **Ordre acté : D1 → D2 → A6 → A12 → A13 → A1/A3 (par tranches) → A4 → A5 → A7+A8 → A10 → C2 → C3 → C4 → C5 → volet B en bloc (B2/B11 d'abord) → B4 (RC) en clôture.**
> Conséquences validées (confirmables au fil de l'eau) : C1 rayé (S2.15), C6 rayé (S1.8-B), A11 fusionné dans A10.

---

## Volet A — Stabilisation technique (P2)

### S3.A1 — Réduire `racine.ts` (P2.1) — ✅ CLOS (T1→T7, D-181→D-187)
racine.ts : **4 018 → 1 920 lignes** en 7 tranches réversibles (verifier complet vert à chacune). Dix modules nés : `services/` espace · import-pack · export-pack · fichiers · compositions-actions · medias-fiche · capture · favoris-doublons · taxonomies · atelier-etat, + `feuilles.ts` (gabarits du shell). Internes documentés : `persister`, `garde` (≠ exécuteur `autoriser` — piège D-181), `occuperPendant`, `consignerEchec`, `lireMediaComplet`, `pousserNouvelleTechnique`. Restent sur la racine, à dessein : état Lit, démarrage/garde plateforme, navigation, sécurité PIN, dispatch de rendu, FAB, nav basse. La cible ~1 200 reste approchable mais on n'ira plus loin que sur besoin réel (D-189).

### S3.A2 — Vues sans dépendance à `MovensoApp` (P2.2) — ✅ CLOS en RÈGLE (D-204)
Pas de conversion en bloc (coût énorme, gain théorique — l'e2e couvre déjà les vues). Devient une **règle d'architecture** (conventions §13) : toute NOUVELLE vue reçoit données + callbacks ciblés, jamais `app` entier ; conversion opportuniste quand une boucle touche une vue existante.

### S3.A3 — Découper `atelier.ts` (P2.3) — ✅ CLOS (3 tranches, D-188/D-189)
atelier.ts : **1 969 → 140 lignes** (entrée + aides partagées + ré-exports — les consommateurs n'ont pas bougé). Trois modules : `atelier-medias.ts` (658 l. — médiathèque, À traiter, corbeille, doublons/fusion, conflits de liaisons), `atelier-taxonomies.ts` (550 l. — disciplines, catégories/niveaux, types de relation, techniques, sources), `atelier-reglages.ts` (682 l. — publier, sauvegardes, sécurité PIN, apparence, à propos, diagnostic). État mort `nomsEnEdition` purgé.

### S3.A4 — Découper `relations-visuelle.ts` (P2.4) — ✅ CLOS (2 tranches, D-190/D-191)
relations-visuelle.ts : **1 644 → 932 lignes** (entrée `gabaritRelationsVisuelle`, bienvenue, en-tête uniforme loupe/🎲/⌖, historique, Liste, Explorer, feuille « Lien », section fiche). Deux modules nés, code déménagé tel quel : `relations-carte.ts` (472 l. — layout par ancres de rôle, séparation D-159/D-160, fit/zoom, gestes, dépliage D-158, rendu des cartes) et `relations-mindmap.ts` (281 l. — gabarit spatial fixe D-148, slots déterministes, chips, connecteurs SVG D-153). Aides partagées exportées de relations-visuelle (`etat`, `pousser`, `grouper`, `trier`, `ORDRE_ROLE`, couleurs/icônes de rôle). **Explorer (~120 l.) reste en place tant que D3 n'est pas arbitré** — le découper avant de savoir s'il se réécrit serait du travail jeté.

### S3.A5 — Découper `app.css` (P2.5) — ✅ CLOS (D-192)
1 270 lignes → `src/styles/app.css` = index de neuf `@import` (ordre = ordre des sections d'origine, cascade inchangée ; Vite regroupe au build) : `base` (tokens/thèmes/tonalités/reset), `shell`, `fiche`, `bibliotheque` (+favoris), `compositions` (+entraînement/chrono/entonnoir), `atelier`, `navigation`, `relations`, `capture`. Sûreté démontrée par script : 725 règles = 725, ordre relatif des sélecteurs dupliqués préservé, bundle dist recompté à 725.

### S3.A6 — Inversion de dépendance domaine → échange (P2.6) — ✅ LIVRÉ (D-176)
`sourceDe` (dérivation pure du modèle) remonté dans `domaine/modele.ts`, les 5 consommateurs rebranchés. **Ordre des couches formalisé et gardé statiquement** (`verifier-sources`, verifier + CI) : `app → (echange | stockage | securite) → domaine` — démontré par test négatif (un import interdit fait échouer le garde).

### S3.A7 — Découper les tests E2E (P2.7) — ✅ CLOS (3 tranches, D-193→D-195)
Le monolithe était un scénario LINÉAIRE à état cumulatif : l'indépendance totale par domaine (lettre de l'audit) repayerait navigateur + imports + reconstruction d'état à chaque fichier — écartée (calibrage utile, pas cérémonial). Livré : `harnais.mjs` (206 l. — serveur dist/, Chromium, surveillance erreurs JS, calibration D-103, 11 aides paramétrées par la page) + **18 chapitres** à contexte propre dans `tests-navigateur/parcours/` (T2 : demarrage-vide, certification-sauvegarde, import-transactionnel, environnement-non-supporte, bibliotheque-vide, zoom-200 ; T3 : espace-insuffisant, integrite-pack, reimport-meme-pack, identite-pack-renommage, bascule-etat-atomique, atomicite-media-metier, sauvegarde-honnete, snapshot-retention, export-diagnostic, pin-capture, publication-cible-externe, defusion-doublons), appelés par le runner aux mêmes positions (couverture et ordre inchangés). parcours.mjs : 4 061 → **2 017 l.** (flux principal B→F→I, 8A.2/8A.3, S2.4/S2.1 — état cumulatif réel). Méthode : bornes par lignes vérifiées par asserts, dépendances analysées par script (seul 8A.4 consommait un fichier du flux → paramètre), e2e complet vert à chaque tranche.

### S3.A8 — Réduire les temporisations fixes (P2.8) — ✅ CLOS (D-196)
Deux attentes d'état au harnais : `rendu(p)` (updateComplete Lit + deux frames) et `finit(fn)` (re-essai de lecture+assertion toutes les 40 ms, borné `lent(2000)`). 174 sommeils ≤ 250 ms convertis en `rendu`, ~80 assertions post-action passées en `finit` (web-first assertions) — mises au point sous conteneur chargé (calibration ×3.26), chaque échec révélant un sommeil qui couvrait une persistance asynchrone. **21 délais fixes assumés** : 400 ms « tailles OPFS » (mesure système sans signal DOM) et durées réelles testées (1 600/2 000/3 600 ms) — un délai qui teste une durée n'est pas une dette. Deux runs complets verts consécutifs.

### S3.A9 — Tests applicatifs intermédiaires (P2.9) — ARBITRÉ (D-204), à livrer
Ciblé, pas une couche : ~10 tests node sur les services extraits en A1 qui portent de la logique sans DOM (gardes d'espace, export en flux, transactions d'import côté calcul). Harnais OPFS simulé écarté (l'e2e teste l'OPFS réel).

### S3.A10 — Chaîne de qualité (P2.10) — ✅ CLOS (« go reco » D-198, livré D-199)
Trois gardes neufs dans `verifier` ET la CI : **`knip`** (`verifier:mort` — code mort, exports/dépendances inutilisés ; 21 `export` superflus + 1 constante morte purgés au premier passage, test négatif démontré) ; **cycles d'import runtime interdits** (`verifier-sources` : DFS, `import type` ignoré, `export … from` compté — les 6 cycles hérités d'A3/A4 cassés par `relations-commun.ts`, `atelier-commun.ts`, `vignette.ts`) ; **budgets** (2 000 lignes max par fichier de src/, 900 Ko max pour dist/ — franchissement légitime = recalibrage par décision). Écartés conformément à l'arbitrage : Prettier, couverture chiffrée, ESLint (réouvrable). S1.11 (injection) et S1.2 (dist) étaient déjà en place.

### S3.A11 — Budgets de complexité (P2.11) — À FAIRE
Empêcher l'aggravation (pas de blocage v1 sur un seuil arbitraire).

### S3.A12 — Anomalies connues du code (P2.12) — ✅ LIVRÉ (D-177)
Chaque anomalie instruite avant correction : « double suppression `supprimerArchiveTemp` » **non confirmée** (rien à corriger) ; « toast dupliqué » = texte copié dans deux gardes → **factorisé** (`#toastEspaceInsuffisant`) ; reliquat « Reprendre » **purgé** (3 fonctions + préférence + 10 règles CSS mortes, docs réalignées, migration d'anciennes préférences testée) ; imports inutilisés : rien trouvé.

### S3.A13 — Simplifier la documentation (P2.13) — ✅ LIVRÉ (D-178)
STATE.md réécrit en UNE page (phase, lots clos, état par chantier du lot courant, questions ouvertes, réserves vivantes, prochaine étape, procédure de reprise) ; l'historique-fleuve de 1 337 lignes archivé INTÉGRALEMENT (`docs/archives/STATE-historique-2026-08.md`). Garde-fou CI D-014 inchangé.

### S3.A14 — Diagnostic structuré (P2.14) — ✅ LIVRÉ (D-217)
**Re-vérifié** : diagnostic 8D.1 (builder pur testé, sans secret) **+ « Dernier échec » livré par S1.12** (consigné aux catch critiques + erreurs non gérées). **Complété « simple » (D-211/D-217)** : codes d'erreur STABLES (`CODES_ECHEC`, `MOV-Enn` — jamais recyclés), opération longue au diagnostic (voile + export en flux : en cours / terminée datée), version applicative complète (`x.y.z+sha`). La check-list P2.14 est couverte.

## Volet B — Publication communautaire (P3)

### S3.B1 — Définition publique de la v1 (P3.1) — À FAIRE
Page inclus / non inclus (reprendre la liste de l'audit).

### S3.B2 — Canaux officiels (P3.2) — ARBITRÉ D-211, LARGEMENT FAIT
Canaux actés : **Play Store** (compte porteur, bêta interne soumise par lui) + **site public** (app web + APK téléchargeable) + **packs officiels découvrables dans l'app** (Plus › Packs officiels, D-213) — joignables aussi depuis l'APK (URL absolue + CSP, D-219). Version câblée au commit (D-212). Reste côté porteur : secret keystore (D-110), fiche Play.

### S3.B3 — Versionnement (P3.3) — LARGEMENT FAIT
**Vérifié** : SemVer + version visible au build + registre `docs/versions.md` (D-132). Reste : tags Git, notes de version liées au build, version dans les sauvegardes (à vérifier).

### S3.B4 — Release candidates (P3.4) — À FAIRE
`1.0.0-rc.1` interne → `1.0.0-rc.2` groupe fermé (5-15 testeurs) → dernière RC corrections seules → `1.0.0` identique.

### S3.B5 — Packs de référence (P3.5) — PARTIEL
**Vérifié** : 7 packs de recette existent déjà (`docs/recette/packs-test/` + kodokan/club-judo). Manquent : pack invalide, pack hostile, ancienne version, volumineux ; et les métadonnées (auteur, licence, sources, statut, mainteneur).

### S3.B6 — Gouvernance des packs (P3.6) — À FAIRE
Champs et licence obligatoires, officiel/communautaire, signalement, retrait, forks, conflits d'identifiants, « vérifié techniquement ≠ validé pédagogiquement ».

### S3.B7 — Documenter le format `.movpack` (P3.7) — À FAIRE
Structure ZIP, manifeste, schéma, limites, migrations, exemples, erreurs fréquentes ; validateur CLI souhaitable.

### S3.B8 — Documentation utilisateur (P3.8) — À FAIRE
Courte, orientée actions (notes préparatoires : `docs/execution/notes-doc-utilisateur.md`).

### S3.B9 — Support communautaire (P3.9) — À FAIRE
Tickets, modèles de bugs, périmètre de support, navigateurs supportés, problèmes connus.

### S3.B10 — Politique de sécurité (P3.10) — À FAIRE
Signalement privé, versions supportées, délais, politique de correction.

### S3.B11 — Licences (P3.11) — ✅ LIVRÉ (D-218)
Arbitré D-211, **corrigé D-220 (porteur)** : **code GPLv3, packs CC BY-NC-SA 4.0** (pas d'usage commercial), vidéos = propriété de leurs auteurs (liens seulement). Livré : `LICENSE` (GPL-3.0-only), `THIRD_PARTY_NOTICES.md`, `package.json`, À propos (carte Licences), README, site public (LICENSE CC BY-NC-SA + mentions.html + packs.js). Assumé : licence des packs au catalogue, pas dans les manifestes (réouvrable).

### S3.B12 — Politique de confidentialité (P3.12) — À FAIRE
Local-first, connexions du site, ressources externes, diagnostic, sauvegardes non chiffrées, PIN, absence de télémétrie.

### S3.B13 — Page publique (P3.13) — PARTIEL
**Vérifié** : movenso-public existe (app + packs) ; l'aligner sur les réponses attendues (qu'est-ce, pour qui, où sont les données, comment sauvegarder, statut de version) et sur les promesses corrigées (S2.8, S1.8).

## Volet C — Finitions (P4)

### S3.C1 — États vides (P4.1) — PROBABLEMENT CLOS (par S2.15)
**Re-vérifié** : campagne S2.15 passée — 5 onglets + 13 sous-écrans se rendent utilement sur installation vierge, workflows sur vide démontrés un à un (REC-S2-015). À rayer sauf complément ciblé.

### S3.C2 — Retours utilisateur uniformes (P4.2) — ✅ CLOS (D-204→D-209)
Toasts, couleurs de statut, verbes, confirmations, information/avertissement/erreur.
**Inventaire** : 111 appels `afficherToast` (texte libre, pas de niveau info/avertissement/erreur — une seule apparence) ; **18 `confirm()` natifs** répartis dans 9 fichiers (compositions, taxonomies ×6, médias ×4, réglages ×2, capture, vues, ajouter, relations) alors que les suppressions sensibles ont déjà leurs feuilles nommées (arbitrage de taxonomie, fusion, suppression groupée D-171). **Arbitrage (D-204)** : deux niveaux de toast minimaux ; confirms destructifs → feuille maison par tranches. **Livré** : (a) `afficherToast(message, niveau?)` — 25 refus/échecs en « alerte » (fond `--state-danger`, `role=alert` assertif), confirmations neutres inchangées ; (b) `demanderConfirmation({titre, corps, bouton, action})` + `feuilleConfirmation` — **17 sites convertis** en 4 tranches (composition, lien, corbeille, taxonomies ×6, capture, médias ×3, doublon exact ×2, instantané, réinitialisation) ; ordre PIN → confirmation re-prouvé ; voile/Échap = annuler sans effet, démontré. **1 confirm() natif assumé** : le rapport pré-vol d'export de composition (informatif, non destructif — D-209). Plus aucun `page.once("dialog")` dans la suite e2e.

### S3.C3 — Thèmes et densités (P4.3) — CAMPAGNE
Jour/nuit/auto, tonalités, densités, écrans, orientations.

### S3.C4 — Performances graphiques (P4.4) — PARTIEL (base posée par S2.16)
**Re-vérifié** : la campagne de charge S2.16 mesure déjà Mindmap/Carte/Explorer à 10 000 arêtes (tout < 30 ms, mémoire 34 Mo) et la fluidité au doigt est confirmée sur appareil (D-172). Restent : Mindmap DENSE (centre à fort degré), sessions longues (fuites), recentrages répétés.

### S3.C5 — Rapports après opérations (P4.5) — PARTIEL
**Vérifié** : rapport d'import complet (D-071, conflits D-157). À étendre : sauvegarde, restauration, nettoyage ; copie/export du rapport.

### S3.C6 — Mise à jour PWA (P4.6) — CONDITIONNEL
Seulement si S1.8 = option A.

## Volet D — Remontées de recette S2 (porteur, 2026-08-02 — D-173, à arbitrer avec le lot)

### S3.D1 — Mindmap : recentrer sur une autre technique — ✅ CLOS (D-175 instruction, D-179 verdict)
**Instruction** : le recentrage existait (toucher une carte + loupe). **Verdict porteur** : le manque était l'UNIFORMITÉ entre les quatre vues — « la loupe en haut est mieux que la barre ». **Livré** : loupe dans l'en-tête des 4 vues, panneau « Centrer sur… » partagé (`panneauCentrer`), ancienne barre inline (`selecteurCentre`) et doublon Mindmap supprimés. e2e (loupe opérante depuis la Liste).

### S3.D2 — « Choisis un point de départ » — ✅ CLOS (v3, D-179 + D-180)
**Verdicts porteur** : le dé centre aléatoirement SUR PLACE (« exit la page principale ») ; l'écran d'entrée, réservé à la première visite, devient une **bienvenue explicative** réinvocable depuis l'aide. **Livré** : 🎲 dans l'en-tête des 4 vues (D-179) ; « Bienvenue dans Relations » + règles du jeu en 6 lignes (centre, les 4 vues et leurs rôles, outils d'en-tête) + choix du départ ; « 🔗 Découvrir Relations » dans Plus › À propos (bêta active) ; « ← Reprendre sur <centre> » referme tel quel (D-180). e2e complets.

### S3.D3 — Explorer — ✅ CLOS (D-198→D-210 : O1+O5+O2 livrés, O4 appliqué)

**Ce qui existe précisément** : (1) entrée « Que veux-tu faire avec X ? » — QUATRE intentions fixes mappées sur les rôles du graphe (Construire un enchaînement→after, Trouver une préparation→before, Comparer→peer, Voir les contres→opposition), chacune n'apparaissant que si ≥1 candidat ; (2) parcours pas-à-pas : à chaque étape ≤6 candidats triés par priorité éditoriale, chacun montrant SA raison ; choisir avance ET recentre (fil d'Ariane synchronisé) ; (3) ← Revenir, Changer d'objectif (garde le chemin), fin de piste honnête ; (4) « Enregistrer comme composition » dès 2 étapes — les raisons deviennent les consignes des blocs, composition jouable immédiatement.

**Ce qui est complet** : le mécanisme fonctionne de bout en bout (démontré e2e + fluide à 10 000 arêtes S2.16). C'est un moteur correct.

**Critique d'usage réel (honnête)** : (a) **le facteur limitant est le MAILLAGE, pas l'UI** — ~2,5 liens/technique sur le dataset Judo → fins de piste dès le 2e-3e pas ; aucune UI ne comblera des arêtes absentes ; (b) une **intention verrouillée par parcours** ne colle pas au réel (on enchaîne PUIS on veut le contre du dernier) — le mélange est possible via « Changer d'objectif » mais invisible/non dit ; (c) **« Comparer » ne compare pas** : il liste les similaires sans face-à-face ni les notes « à ne pas confondre » (pourtant en données D-136) ; (d) **pas de destination** : on avance sans but — l'usage « comment aller de A à B ? » n'existe pas ; (e) le **niveau de l'élève est ignoré** (un débutant reçoit des suites avancées sans signal, alors que les niveaux sont en données) ; (f) le parcours **meurt à la sortie** (pas de reprise, seule la composition survit).

**Arbitrage (D-198)** : O4 (maillage) + O1 (transparence) + O5 (niveau) + O2 (Comparer face-à-face) retenus ; O3 (« aller vers ») écarté à ce stade.

**Livré** : Explorer extrait (`relations-explorer.ts`) ; O1 (badges de rôle, mélange d'objectifs affiché, D-200) ; O5 (niveaux sur les candidats, D-201) ; O2 (Comparer = face-à-face avec note de distinction, D-202) ; **O4 appliqué** (D-210 : 64 arêtes ajoutées aux packs — 8 contres, 12 renraku, 10 à-ne-pas-confondre, 8 liaisons DEBOUT-SOL, 26 arêtes club — maillage 2,5 → ~3,1/technique, zéro technique club isolée, priorités D-134 posées, invariants de test recalés à 315).

---

## Clôture de la phase (critères v1 de l'audit)

S1 et S2 fermés · aucun bug connu de perte ou divulgation · import/sauvegarde/restauration testés sur appareils réels · matrice de recette v1 validée (plateformes + scénarios de l'audit) · dernière RC utilisée plusieurs jours · promesses publiques exactes · build reproductible · v1 identique à la dernière RC.
