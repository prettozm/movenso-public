# Lot S1 — Sécurité, intégrité et plateforme (P0 de l'audit)

> **Phase : STABILISATION V1** (D-161). Source : [`docs/execution/audit-stabilisation-v1.md`](../audit-stabilisation-v1.md), chantiers P0.1 → P0.12.
> **Statut du lot : ARBITRÉ le 2026-08-01 (D-162)** — verdicts du porteur :
> S1.1 ✅ · S1.2 ✅ · S1.3 ✅ · S1.4 ✅ · **S1.5 À INSTRUIRE** (constat soumis avant correction) · S1.6 ✅ · S1.7 ✅ · **S1.8 ✅ OPTION B** (promesse réduite — D-163 ; PWA notée post-v1) · S1.9 ✅ (plan validé D-163) · **S1.10 REPORTÉ EN FIN DE LOT, dossier séparé** (D-163 — implémentation et cas à préciser avant tout code) · S1.11 ✅ (recalibré) · S1.12 ✅.
> Ordre d'exécution (D-163) : S1.2 ✔ → S1.1 → S1.9 → S1.3 → S1.4 → S1.5 (instruction) → S1.6 → S1.7 → S1.8 (boucle de reformulation, option B) → S1.11 → S1.12 → **puis S1.10 traité seul** (dossier stockage dédié).
> **Gel fonctionnel** (règle de la phase) : aucune nouvelle vue, aucun nouveau type de relation, aucun enrichissement de pack, aucune fonction secondaire tant que S1 et S2 ne sont pas clos.

Chaque chantier porte un **état vérifié contre le dépôt** (2026-08-01) :
`À FAIRE` = rien n'existe · `PARTIEL` = socle présent, compléments listés · `LARGEMENT FAIT` = reste marginal · `À INSTRUIRE` = constat de l'audit à vérifier avant de trancher · `DÉCISION PORTEUR` = choix produit préalable.

---

## S1.1 — Build reproductible (P0.1) — PARTIEL

**Constat vérifié** : la CI (`.github/workflows/ci.yml`) part déjà d'un clone propre et enchaîne `npm ci` → typecheck → tests → build → e2e ; `package-lock.json` versionné ; `apk.yml` construit l'artefact Android.
**Reste à faire** :
- [ ] figer la version de Node.js (champ `engines` + doc) et encadrer npm ;
- [ ] `npm ci` + build vérifiés depuis une machine vierge hors CI (procédure documentée) ;
- [ ] publier le build web comme artefact CI avec **SHA-256** ;
- [ ] vérifier qu'aucun fichier non versionné n'est requis par le build ;
- [ ] règle écrite : seul un artefact CI est publiable (jamais un build local).

**Critère de sortie** : un tiers clone, exécute une procédure documentée et obtient exactement le build publiable.

## S1.2 — CI intégralement verte (P0.2) — LARGEMENT FAIT

**Constat vérifié** : typecheck, 167 tests unitaires (migrations, import/export inclus), build de production et e2e Chromium tournent déjà à chaque push ; le harnais e2e échoue sur toute erreur JS.
**Reste à faire** :
- [ ] vérification du contenu du build (fichiers attendus, rien de plus) ;
- [ ] contrôle qu'aucun fichier source ou secret inutile n'entre dans `dist/`.

**Critère de sortie** : aucun test ignoré sans justification, aucune publication CI rouge.

## S1.3 — Centraliser et sécuriser les URL externes (P0.3) — À FAIRE

**Constat vérifié** : aucun validateur central (`src/securite/` = `pin.ts` + `politique.ts`, sans `new URL()` de validation) ; les liens externes stockés (ressources, YouTube) ne passent par aucun contrôle de protocole.
**À faire** (liste de l'audit intégralement) :
- [ ] fonction unique de validation (`new URL()`, `https:` seul par défaut, refus `javascript:`/`data:`/`file:`/inconnus, normalisation avant stockage) ;
- [ ] parseur YouTube strict (domaines prévus, extraction d'identifiant) ;
- [ ] jamais de chaîne brute vers `href`/`src`/embed ; `rel="noopener noreferrer"` ;
- [ ] signal visuel de sortie de Movenso ;
- [ ] tests de sécurité sur chaque protocole refusé.

**Critère de sortie** : aucune chaîne utilisateur n'atteint un `href`, `src` ou embed sans validation.

## S1.4 — Durcir les imports `.movpack` (P0.4) — PARTIEL

**Constat vérifié** : le manifeste v4 inventorie chaque fichier avec taille + SHA-256 (testé), l'import est en flux avec staging OPFS vérifié (D-114) ; mais **aucune limite de volume, de nombre, de profondeur ni contrôle de ratio**, et pas de corpus hostile.
**Reste à faire** :
- [ ] limites explicites : tailles (archive, total décompressé, fichier, manifeste, `bibliotheque.json`), nombres (entrées ZIP, techniques, disciplines, contributions, relations, compositions, médias), profondeur JSON, longueurs de textes/identifiants ;
- [ ] refus chemins absolus / `../` / chemins Windows dangereux / doublons de chemins ;
- [ ] contrôle du ratio compression/décompression ;
- [ ] contrôle du type réel des médias (contenu, pas extension) ; refus des exécutables ;
- [ ] arrêt propre + nettoyage du staging au dépassement ;
- [ ] corpus de tests hostiles : ZIP bomb simulée, manifeste mensonger, JSON tronqué/profond, chemins malveillants.

**Critère de sortie** : une archive hostile ne sort pas de la zone prévue et ne sature ni mémoire ni stockage en silence.

## S1.5 — Import réellement transactionnel (P0.5) — ✅ ARBITRÉ B+C (D-166) et LIVRÉ le 2026-08-02

**Constat DÉMONTRÉ** (`confirmerImport` racine.ts, idem `confirmerRestauration`) — l'ordre réel est :
garde d'espace → snapshot JSON → **(a) `promouvoirImportMedias`** (staging → `videos/`, idempotent) → **(b) `#persister`** (écrire-valider-basculer 8C.2). Un échec de (b) après (a) réussie laisse des **fichiers promus dans `videos/` qu'aucune bibliothèque persistée ne référence**.

**Qualification du risque** : jamais de perte ni de corruption (la bibliothèque live reste l'ancienne, 8C.2) ; la proposition RESTE → un **réessai** re-promeut (skip idempotent) puis re-persiste — l'orphelin se résorbe seul. Le risque réel : l'utilisateur **annule** après l'échec, ou **crash brutal** entre (a) et (b) → orphelins silencieux dans `videos/` (espace occupé), détectables aujourd'hui seulement via Plus › Médias/diagnostic.

**Options soumises au porteur** :
- **A — Inverser l'ordre (persister puis promouvoir)** : pire sans journal de transaction — un crash entre les deux crée des **références cassées** (plus visible qu'un orphelin) ET `nettoyerStaging` jette les fichiers au redémarrage → cassure définitive. Déconseillé tel quel.
- **B — Rollback des médias promus** *(recommandé)* : `promouvoirImportMedias` retourne la liste des fichiers RÉELLEMENT déplacés ; si la persistance échoue, ils sont re-déplacés vers le staging (état d'avant, proposition intacte, retry possible). ~1 boucle + test de coupure (échec de `sauvegarder` simulé).
- **C — Signalement de réconciliation au démarrage** *(complément recommandé)* : détecter les orphelins au démarrage et le DIRE discrètement (toast → Plus › Médias) — jamais de suppression automatique (« proposé, jamais subi »). Couvre le crash brutal que B ne voit pas. ~1 petite boucle.

**Critère de sortie** : après toute interruption, ancien état complet OU nouvel état complet — jamais un mélange silencieux.

## S1.6 — Certifier sauvegardes et restaurations (P0.6) — PARTIEL

**Constat vérifié** : sauvegarde/restauration en flux testées en e2e (restauration de base, idempotence D-114), avertissement « non chiffrée » (D-131). Manque la **campagne de certification** sur corpus de référence.
**Reste à faire** :
- [ ] bibliothèque de référence complète (disciplines, techniques, relations, favoris, contributions, compositions, médias) ;
- [ ] sauvegarde légère + complète → restauration sur installation vierge → **comparaison objet par objet** + empreintes des médias ;
- [ ] cas : Unicode/accents, médias manquants, sauvegarde corrompue, tronquée, ancienne version, interruption pendant restauration ;
- [ ] rien d'écrasé avant confirmation ;
- [ ] documentation exacte de ce qui est restauré / pas restauré.

**Critère de sortie** : une sauvegarde complète restaure exactement ce qui est promis, et uniquement cela.

## S1.7 — Confidentialité de tous les exports (P0.7) — PARTIEL

**Constat vérifié** : l'épreuve 8B couvre déjà l'exclusion des notes personnelles du pack partagé ; pas d'inspection systématique **par format**.
**Reste à faire** : pour chaque export (pack complet, partiel, technique seule, composition, sauvegarde légère, complète, diagnostic) :
- [ ] ouvrir réellement l'archive et vérifier l'absence de : notes privées non sélectionnées, favoris, pseudo, PIN et dérivé, réglages de sécurité, historique, captures non rattachées, médias non sélectionnés, chemins locaux, identifiants internes inutiles ;
- [ ] test automatique de non-divulgation **par format**.

**Critère de sortie** : chaque format exporté a son test de non-divulgation.

## S1.8 — Trancher la promesse « hors ligne » (P0.8) — DÉCISION PORTEUR

**Constat vérifié** : ni `manifest.webmanifest` ni service worker dans le dépôt — l'app web nécessite le réseau au chargement ; seules les données sont locales.
**Options** (exclusives) :
- **A** — PWA réelle : manifeste + service worker + cache versionné + démarrage en mode avion + gestion des mises à jour (chantier significatif) ;
- **B** — Promesse réduite, affichée telle quelle : « Les données et vidéos restent sur l'appareil. Une connexion peut être nécessaire pour charger ou mettre à jour l'application web. » (une boucle de reformulation site + aide).

**Critère de sortie** : aucune différence entre la communication publique et le comportement réel.

## S1.9 — Persistance OPFS (P0.9) — À FAIRE

**Constat vérifié** : `navigator.storage.persist()` n'est **jamais appelé** ; l'espace est estimé (diagnostic 8D.1) mais la persistance n'est ni demandée ni affichée — le navigateur peut théoriquement purger OPFS.
**À faire** :
- [ ] demander `persist()` et lire son résultat ; afficher persistance accordée / purge possible ;
- [ ] afficher espace utilisé + quota estimé (déjà calculés au diagnostic → exposer dans Plus) ;
- [ ] vérifier l'espace avant une grosse écriture ; arrêt propre + message si insuffisant ;
- [ ] tests : quota presque plein, dépassement en cours d'écriture, persistance refusée.

**Critère de sortie** : Movenso ne commence pas une opération qu'il sait ne pas pouvoir terminer.

## S1.10 — Navigateurs non compatibles (P0.10) — À INSTRUIRE (arbitrage D-162)

**Constat à vérifier en début de boucle** : comportement réel actuel sans OPFS (Firefox privé, navigateurs anciens) — écran blanc ? erreur brute ?
**À faire (selon constat)** :
- [ ] détection des capacités ; écran explicatif nommant les navigateurs supportés ;
- [ ] jamais d'interface partiellement fonctionnelle ;
- [ ] tests : navigateur sans OPFS, mode privé, quota très faible.

**Pistes du porteur (2026-08-01, à instruire comme dossier « stockage » avant décision)** :
- la **sauvegarde portable (zip)** comme échappatoire de principe : si l'environnement est limité, les données restent transportables ;
- **Plus › Stockage** : possibilité de choisir manuellement un emplacement (si avertissement OPFS ou par choix utilisateur) ;
- pour ne pas polluer les galeries tierces : médias renommés **`.movmedia`** et arborescence dédiée type `Documents/movenso/` (médias, json, …) **selon l'appareil**.

L'instruction devra poser les faits par plateforme (File System Access API absent sur Chrome Android ; Capacitor/Android : dossier applicatif ou Documents via l'API native, convention `.nomedia` ; OPFS invisible des galeries par nature) puis proposer 2-3 options chiffrées. **Décision porteur avant tout code structurant.**

**Critère de sortie** : aucun écran blanc ni erreur technique brute sur environnement non supporté.

## S1.11 — `innerHTML` (P0.11) — LARGEMENT FAIT (recalibré)

**Constat vérifié** : **une seule** occurrence dans tout `src/` (`relations-visuelle.ts:1120`, construction SVG des connecteurs à partir de données géométriques calculées — aucune donnée utilisateur). Risque réel faible : l'audit le classait P0, on le traite comme durcissement.
**Reste à faire** :
- [ ] remplacer par des éléments SVG typés (ou justifier + tester l'innocuité) ;
- [ ] garde-fou automatisé interdisant tout nouvel `innerHTML` non justifié.

**Critère de sortie** : aucun contenu métier injecté par concaténation HTML, et le garde-fou l'empêche durablement.

## S1.12 — Erreurs sans perdre l'utilisateur (P0.12) — PARTIEL

**Constat vérifié** : toasts d'erreur actionnables, voile « … en cours » (D-131), rapport d'import, diagnostic exportable — mais pas d'inventaire systématique par opération critique.
**Reste à faire** : pour chaque opération longue/critique (import, export, sauvegarde, restauration, capture vidéo, suppression, réinitialisation) :
- [ ] message compréhensible + cause dans le diagnostic ; aucune stack trace brute ;
- [ ] action de reprise ou retour ; état précédent conservé ; temporaires nettoyés ;
- [ ] un test par chemin d'erreur P0.

**Critère de sortie** : toute erreur critique a un test et un chemin de récupération.

---

## Fin du lot S1

Le lot est clos quand : tous les points arbitrés « à faire » sont démontrés (test + recette QUALITY), `npm run verifier` est vert, les docs décrivent le réel, checkpoint dans `STATE.md`.
