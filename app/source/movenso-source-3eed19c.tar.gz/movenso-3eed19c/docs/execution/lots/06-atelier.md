# LOT 6 — ATELIER : CONSTRUIRE, VÉRIFIER, ÉCHANGER ET PROTÉGER LE CORPUS

## Contexte

Le lot 1 a installé trois destinations principales :

- Bibliothèque ;
- Pratique ;
- Atelier.

Le lot 2 a rendu la Bibliothèque exploitable :

- disciplines uniques ;
- recherche globale ;
- filtres ;
- sources ;
- états vides ;
- création d'une première technique.

Le lot 3 a refondu la fiche technique :

- média principal ;
- plusieurs voix ;
- édition contextuelle ;
- carnet personnel ;
- médias ;
- relations et compositions compactes.

Le lot 4 a distingué :

- création d'une technique ;
- capture rapide ;
- rattachement ;
- modification contextuelle.

Le lot 5 a rendu Pratique fonctionnel :

- À reprendre ;
- Favoris ;
- Compositions ;
- mode entraînement ;
- sauvegarde et restauration des données personnelles.

L'Atelier actuel contient déjà plusieurs fonctions utiles, mais son
organisation expose encore trop directement le modèle interne :

- disciplines ;
- taxonomies ;
- types de relation ;
- diagnostics ;
- import ;
- publication ;
- sauvegardes ;
- réglages.

Présentées dans une longue page, ces fonctions produisent un mur de texte
et obligent l'utilisateur à savoir à l'avance quel objet technique il
recherche.

La V2 possédait de nombreuses capacités de gouvernance réelles :

- construction des disciplines, catégories et niveaux ;
- gestion des médias ;
- diagnostics ;
- import et export ;
- sauvegardes ;
- restauration ;
- historique ;
- rollback ;
- protections par PIN.

L'objectif n'est pas de reproduire son ancien panneau Admin, mais de
conserver ses capacités derrière une architecture d'usage plus claire.

## Objectif unique

Transformer l'Atelier en espace de curation compréhensible, organisé
autour de quatre intentions :

1. Construire ;
2. Médias et qualité ;
3. Échanger et protéger ;
4. Réglages et sécurité.

Chaque intention doit mener à des workflows complets, sans exposer
inutilement le modèle interne et sans dupliquer les usages quotidiens de
la Bibliothèque.

## 1. Positionnement de l'Atelier

L'Atelier sert à agir sur le corpus dans son ensemble.

Il permet notamment de :

- structurer une discipline ;
- administrer ses taxonomies ;
- rechercher les éléments incomplets ou incohérents ;
- réparer les problèmes de médias ;
- importer un corpus ;
- publier ce que l'utilisateur maîtrise ;
- sauvegarder l'installation ;
- restaurer ou revenir en arrière ;
- configurer l'application ;
- activer ultérieurement les protections.

Il ne doit pas devenir le passage obligatoire pour :

- consulter une technique ;
- ajouter un repère personnel ;
- ajouter un média à une fiche connue ;
- mettre une technique en favori ;
- créer une composition ;
- utiliser Movenso pendant l'entraînement.

Ces actions restent dans Bibliothèque, Fiche ou Pratique.

## 2. Entrée unique

L'onglet inférieur `Atelier` est l'unique entrée globale vers cet espace.

Supprimer toute clé à molette globale qui ouvre exactement la même
destination.

Une clé ou icône d'outil peut rester uniquement lorsqu'elle représente
une action locale, par exemple :

- gérer les médias d'une fiche ;
- modifier la structure d'une discipline précise.

Elle ne doit pas constituer une seconde navigation vers l'Atelier
général.

Les anciennes routes Admin ou Réglages doivent rediriger vers la section
appropriée de l'Atelier.

## 3. Architecture de la racine

La racine contient exactement quatre intentions principales :

- Construire ;
- Médias et qualité ;
- Échanger et protéger ;
- Réglages et sécurité.

Sur téléphone :

- utiliser des sections repliables ;
- une seule section principale ouverte à la fois ;
- l'ouverture d'une section referme la précédente ;
- conserver l'état de la section active pendant la session.

Sur tablette et grand écran, utiliser au choix :

- menu latéral et panneau de contenu ;
- onglets internes ;
- ou accordéon large.

La structure et les libellés restent identiques à ceux du téléphone.

Ne pas afficher les quatre sections entièrement développées les unes sous
les autres.

## 4. Synthèse actionnable

En haut de l'Atelier, afficher une synthèse uniquement lorsqu'une action
est réellement nécessaire.

Exemples :

- 3 captures à rattacher ;
- 2 vidéos introuvables ;
- 1 rapprochement à arbitrer ;
- 4 techniques sans classification ;
- sauvegarde jamais effectuée.

Chaque élément est cliquable et ouvre directement le workflow
correspondant.

Ne pas afficher :

- nombre total de techniques sans décision associée ;
- nombre total de disciplines comme KPI ;
- nombre de visites ;
- statistiques décoratives ;
- graphiques sans action possible.

Si aucun problème n'est détecté, afficher au maximum une mention
compacte : `Aucun problème détecté`.

Ne pas occuper un écran complet avec un tableau de bord vide.

## 5. Section Construire

La section `Construire` regroupe la structure du corpus.

Sous-sections recommandées :

- Disciplines ;
- Taxonomies ;
- Techniques ;
- Relations ;
- Sources et auteurs, uniquement si le modèle existant permet une gestion
  utile.

Ne pas afficher toutes les sous-sections en même temps sur téléphone.

Une navigation interne ou un second niveau d'accordéon est autorisé.

## 6. Gestion des disciplines

Afficher la liste des disciplines avec :

- nom ;
- nombre d'identités techniques ;
- nombre de taxonomies ;
- nombre de sources présentes ;
- éventuels problèmes actionnables.

Actions disponibles :

- créer ;
- renommer ;
- réordonner ;
- ouvrir dans la Bibliothèque ;
- gérer la structure ;
- retirer si elle est vide ;
- préparer une suppression sécurisée si elle contient des données.

Créer une discipline demande au minimum : nom.

Informations facultatives : description ; icône ou initiale ; métadonnées
déjà supportées par le modèle.

Ne pas demander : pack ; provenance ; familles obligatoires ; système de
niveaux obligatoire.

Une discipline nouvellement créée peut rester vide.

Action proposée après création :

- Créer la première technique ;
- Structurer la discipline ;
- Ouvrir dans la Bibliothèque.

Renommer une discipline ne doit pas :

- recréer les techniques ;
- casser les références des compositions ;
- changer silencieusement l'identité d'un pack existant ;
- perdre ses médias.

Si le modèle actuel calcule une identité de pack à partir du nom de
discipline, signaler clairement ce risque et le tracer pour le lot
technique au lieu de le masquer.

## 7. Suppression d'une discipline

Une discipline vide peut être retirée avec confirmation simple.

Une discipline contenant des techniques ne doit jamais être supprimée en
un clic.

Présenter :

- nombre de techniques ;
- contributions ;
- médias ;
- compositions concernées ;
- relations ;
- sources ou packs concernés.

Options possibles selon les capacités réelles :

- annuler ;
- exporter ou sauvegarder avant ;
- retirer uniquement une source ;
- déplacer ou détacher certains contenus ;
- supprimer la discipline et son contenu après confirmation renforcée.

Une sauvegarde préalable est obligatoire avant suppression en masse.

Ne pas implémenter dans ce lot une suppression complexe non supportée par
le modèle.

Dans ce cas :

- refuser l'opération ;
- expliquer ce qui doit être traité ;
- proposer les actions disponibles.

## 8. Taxonomies

Les taxonomies appartiennent aux données de la discipline.

La section doit permettre de gérer : familles ; catégories ; niveaux ;
autres taxonomies déjà supportées.

Pour chaque taxonomie :

- créer ;
- renommer ;
- ordonner ;
- modifier une couleur facultative ;
- supprimer ou fusionner avec contrôle des usages.

Ne pas présupposer : ceintures ; grades ; catégories judo ; nomenclature
japonaise ; hiérarchie universelle.

Lorsqu'un élément est utilisé par des techniques, afficher avant
suppression :

- nombre d'utilisations ;
- techniques concernées ;
- actions possibles.

Options possibles : remplacer par une autre valeur ; retirer la
classification ; annuler.

Ne pas laisser une suppression créer des références invalides.

## 9. Gestion des techniques dans l'Atelier

Ne pas créer une seconde Bibliothèque complète dans l'Atelier.

La sous-section Techniques sert à :

- rechercher une technique à administrer ;
- repérer les techniques incomplètes ;
- traiter plusieurs problèmes similaires ;
- ouvrir une fiche en mode édition ;
- détecter les doublons ou rapprochements en attente.

Afficher une liste orientée gestion avec :

- nom ;
- discipline ;
- sources ;
- état de classification ;
- état des médias ;
- éventuel problème.

Actions :

- ouvrir la fiche ;
- modifier ce que l'utilisateur maîtrise ;
- traiter un problème ;
- sélectionner plusieurs éléments uniquement si une vraie action de masse
  est supportée.

Ne pas implémenter de modifications de masse factices.

Si les opérations de masse restent différées, afficher des actions
unitaires et tracer ce manque.

## 10. Types de relation

Les types de relation sont des données administrables, mais ils ne
doivent pas être exposés comme un schéma technique brut.

Afficher pour chaque type :

- libellé principal ;
- libellé inverse éventuel ;
- caractère dirigé ou symétrique ;
- nombre de relations utilisant ce type ;
- origine ou source lorsqu'elle existe.

Permettre selon les capacités actuelles :

- créer ;
- renommer ;
- modifier l'inverse ;
- modifier la symétrie ;
- désactiver pour de nouvelles relations ;
- supprimer uniquement lorsqu'il n'est pas utilisé.

Ne pas permettre une modification qui rend les relations existantes
incohérentes sans avertissement et migration explicite.

Les quatre types historiques restent disponibles après migration.

Ne pas afficher leur identifiant interne.

## 11. Sources et auteurs

La distinction suivante doit rester claire : source ou corpus ; auteur ou
organisation ; provenance ; pack ; discipline.

Si le modèle possède déjà des informations éditoriales utilisables,
permettre de :

- corriger un nom d'affichage local ;
- consulter l'auteur ;
- consulter la version ;
- consulter les conditions ;
- retrouver les contributions associées.

Ne pas permettre de modifier le manifeste original d'un pack tiers comme
s'il appartenait à l'utilisateur.

Une adaptation locale doit rester distincte de la source importée.

Ne pas créer un registre d'auteurs complexe dans ce lot s'il n'existe pas
encore.

## 12. Section Médias et qualité

Cette section regroupe les contrôles et réparations.

Sous-sections possibles :

- Problèmes à traiter ;
- Médiathèque ;
- Aperçus et miniatures ;
- Qualité du corpus.

Ne pas exposer une liste technique de fichiers sans contexte.

Chaque anomalie doit répondre à trois questions : quel est le problème ?
quels contenus sont concernés ? que peut faire l'utilisateur ?

## 13. Diagnostics médias

Détecter ou conserver les diagnostics existants :

- fichier local introuvable ;
- référence média sans fichier ;
- fichier sans référence ;
- miniature absente ou invalide ;
- média dupliqué ;
- média non lisible ;
- technique sans média principal ;
- contribution pointant vers un média manquant.

Ne pas présenter `technique sans vidéo` comme une erreur bloquante.

La distinguer des vrais problèmes d'intégrité.

Pour chaque problème, proposer uniquement les actions réellement
disponibles :

- retrouver ou remplacer le fichier ;
- retirer la référence cassée ;
- ouvrir la fiche ;
- régénérer l'aperçu ;
- supprimer un fichier orphelin ;
- ignorer ou marquer comme traité.

Ne jamais supprimer automatiquement tous les fichiers détectés comme
orphelins.

Une prévisualisation et une confirmation sont obligatoires.

## 14. Médiathèque

La médiathèque offre une vue de gestion des médias existants.

Afficher :

- miniature ;
- type ;
- taille si connue ;
- source ;
- nombre de références ;
- état du fichier ;
- techniques ou contributions associées.

Actions possibles selon les capacités réelles :

- ouvrir ;
- voir les utilisations ;
- remplacer ;
- modifier le libellé ;
- choisir comme média principal depuis la fiche concernée ;
- retirer une référence ;
- supprimer le fichier uniquement s'il n'est plus utilisé.

Ne pas supposer qu'un média n'est utilisé qu'une seule fois.

Si le modèle média actuel ne protège pas correctement les références
multiples :

- empêcher la suppression globale depuis l'interface ;
- documenter le risque ;
- réserver le refactor au lot technique.

## 15. Qualité du corpus

Afficher les informations incomplètes de manière actionnable :

- capture à rattacher ;
- technique sans famille ;
- technique sans niveau ;
- contribution sans auteur lisible ;
- relation invalide ;
- rapprochement ambigu ;
- média manquant ;
- référence de composition indisponible.

Ces éléments ne sont pas tous des erreurs.

Distinguer : erreur d'intégrité ; contenu à compléter ; arbitrage humain ;
information facultative.

Permettre :

- ouvrir l'élément ;
- corriger ;
- ignorer lorsqu'il est réellement facultatif ;
- regrouper les arbitrages compatibles dans un lot compact.

Ne pas transformer Movenso en outil de notation de qualité avec un score
global arbitraire.

## 16. Section Échanger et protéger

Cette section regroupe quatre gestes distincts :

- Importer ;
- Publier ;
- Sauvegarder ;
- Restaurer ou revenir en arrière.

Ces gestes ne doivent jamais être présentés comme des synonymes.

## 17. Importer un pack

Workflow attendu :

1. choisir un fichier ;
2. identifier son format ;
3. valider le manifeste ou le contenu ;
4. afficher un aperçu ;
5. signaler les conflits ou rapprochements ;
6. confirmer ;
7. importer ;
8. afficher un rapport.

L'aperçu doit montrer au minimum :

- nom du pack ;
- auteur ou organisation ;
- version ;
- discipline ou portée ;
- conditions éventuelles ;
- nombre de techniques ;
- nombre de contributions ;
- nombre de médias ;
- volume total lorsque connu ;
- nouveaux éléments ;
- éléments réunis ;
- suggestions à arbitrer ;
- erreurs bloquantes.

Ne pas afficher les identifiants internes comme information principale.

Un import invalide doit être refusé avant mutation autant que le
permettent les services actuels.

Si l'import n'est pas complètement atomique :

- ne pas prétendre qu'il l'est ;
- créer une sauvegarde préalable ;
- tracer le besoin pour le lot technique ;
- présenter clairement le comportement réel.

Les JSON de démonstration peuvent rester compatibles techniquement, mais
l'interface de production doit privilégier les vrais conteneurs
`.movpack`.

## 18. Rapport d'import

Après import, afficher un rapport compact :

- nouvelles techniques ;
- identités réunies ;
- contributions ajoutées ;
- médias ajoutés ;
- relations ajoutées ;
- éléments à rapprocher ;
- erreurs ou avertissements.

Actions : Ouvrir la discipline ; Traiter les rapprochements ; Fermer.

Ne pas renvoyer automatiquement vers l'Accueil.

Ne pas afficher un simple message `Import réussi` sans expliquer ce qui a
changé.

## 19. Publier un pack

Publier signifie créer un corpus destiné à être distribué.

Ce n'est pas une sauvegarde complète de l'installation.

Le workflow doit empêcher la republication silencieuse de contenus
tiers.

L'utilisateur choisit au minimum :

- discipline ;
- source ou contributions qu'il maîtrise ;
- nom éditorial du pack ;
- auteur ou organisation ;
- version ;
- conditions ou note de diffusion ;
- inclusion des médias.

Par défaut, exclure :

- carnet personnel ;
- favoris ;
- captures à reprendre ;
- compositions personnelles ;
- contributions provenant de packs tiers ;
- réglages ;
- sauvegardes.

Les contributions d'un référentiel importé ne doivent pas être incluses
simplement parce qu'elles appartiennent à la même discipline.

Avant génération, afficher une prévisualisation exacte :

- nombre d'identités ;
- contributions incluses ;
- sources incluses ;
- médias ;
- taille estimée ;
- éléments exclus ;
- avertissements.

Si le modèle actuel ne sait pas représenter de manière sûre la propriété
éditoriale d'une contribution :

- ne pas publier toute la discipline ;
- limiter la publication aux origines explicitement sélectionnées et
  maîtrisées ;
- documenter la limite.

Ne pas introduire une nouvelle entité Collection sans nécessité démontrée
dans ce lot.

## 20. Sortie du pack publié

Après génération :

- afficher le nom réel du fichier ;
- son type ;
- sa taille ;
- sa version ;
- un résumé du contenu ;
- proposer Partager ou Enregistrer.

Sur Android, utiliser le mécanisme existant réellement fonctionnel.

Ne pas afficher un chemin de fichier inaccessible à l'utilisateur comme
unique résultat.

Si le partage Android n'est pas fiable, le documenter et le réserver au
lot technique au lieu d'afficher un faux succès.

## 21. Sauvegarde intégrale

La sauvegarde personnelle protège l'installation de l'utilisateur.

Elle inclut selon les capacités validées :

- disciplines ;
- techniques ;
- contributions ;
- sources ;
- taxonomies ;
- relations ;
- médias ;
- captures à reprendre ;
- favoris ;
- compositions ;
- paramètres utiles ;
- protections ;
- historique ou snapshots nécessaires.

Elle ne doit pas être confondue avec un pack publiable.

Afficher clairement : `Sauvegarde complète de cette installation`

Le workflow montre :

- date ;
- taille estimée ;
- présence des médias ;
- emplacement ou mode de partage ;
- éventuelles limites.

Après sauvegarde, proposer : Enregistrer ; Partager ; Vérifier.

Si les médias ne sont pas réellement inclus, ne pas employer le terme
sauvegarde complète.

## 22. Sauvegardes locales et historique

Conserver ou introduire une vue compacte des snapshots existants.

Pour chaque snapshot :

- date ;
- motif ;
- version du modèle ;
- taille si connue ;
- action à l'origine.

Exemples de motifs :

- Avant suppression d'une discipline ;
- Avant import du pack Kodokan ;
- Avant restauration ;
- Sauvegarde manuelle.

Actions : Voir le contenu ; Restaurer ; Supprimer l'ancien snapshot si
autorisé.

Ne pas reconstruire l'export CSV détaillé de la V2 comme fonction
centrale.

Un historique technique peut rester accessible dans une vue secondaire de
diagnostic.

## 23. Restauration

Distinguer deux opérations.

**A. Restaurer une sauvegarde complète**

Utilisée notamment sur une installation vierge.

Avant restauration, afficher : contenu ; version ; disciplines ; médias ;
favoris ; compositions ; paramètres concernés.

**B. Revenir à un snapshot local**

Utilisé après une erreur ou une action destructive.

Avant toute restauration :

- créer un snapshot de l'état courant lorsque possible ;
- prévenir des éléments remplacés ;
- permettre l'annulation avant exécution ;
- afficher le résultat.

Si la restauration complète n'est supportée que sur une installation
vierge :

- l'indiquer clairement ;
- ne pas laisser choisir un fichier pour échouer en fin de parcours ;
- proposer de vider de manière sécurisée ou d'utiliser une autre
  opération, uniquement si supporté.

Ne pas implémenter silencieusement une fusion de sauvegardes sans modèle
clair.

## 24. Rollback

Le rollback doit être compréhensible.

Ne pas afficher uniquement : `Restaurer snapshot 01HZX...`

Afficher : `Revenir à l'état avant l'import du 12 juillet à 18:42`

Avant confirmation :

- expliquer ce qui sera remplacé ;
- indiquer si les médias sont réellement restaurés ;
- signaler les données créées depuis ce point ;
- créer une sauvegarde de sécurité de l'état courant.

Si les snapshots ne contiennent pas les octets des médias :

- l'indiquer explicitement ;
- ne pas promettre une restauration complète ;
- tracer le refactor pour le lot technique.

## 25. Section Réglages et sécurité

Cette section accueille les préférences générales et l'entrée vers les
protections.

Dans ce lot, traiter :

- écran de démarrage ;
- thème ;
- préférences d'affichage existantes utiles ;
- état actuel des protections ;
- accès au futur réglage de sécurité.

Ne pas implémenter encore la refonte complète du PIN.

Le lot 7 définira :

- édition autorisée par défaut ;
- protection facultative des modifications ;
- protection facultative des suppressions ;
- création du PIN lors de l'activation ;
- comportement tablette partagée.

Ne pas créer de contrôles factices avant le lot 7.

Si les anciens réglages de sécurité existent :

- les conserver ;
- les regrouper visuellement ;
- indiquer leur état réel ;
- ne pas changer leur sémantique dans ce lot.

## 26. Écran de démarrage

La valeur par défaut reste : Bibliothèque.

Permettre facultativement de choisir parmi les destinations réellement
supportées :

- Bibliothèque ;
- dernière discipline consultée ;
- discipline choisie ;
- Pratique.

Ne jamais proposer : Accueil ; ancien écran Admin ; route supprimée ;
fiche ou workflow temporaire.

Si la discipline choisie n'existe plus :

- revenir automatiquement à Bibliothèque ;
- informer discrètement l'utilisateur ;
- ne pas bloquer le lancement.

## 27. Thème et apparence

Conserver uniquement les réglages apportant une vraie valeur : thème
système ; clair ; sombre.

Les couleurs d'accent personnalisées sont différées sauf si elles
existent déjà sans coût de maintenance.

Ne pas entamer dans ce lot la refonte graphique générale.

L'Atelier doit cependant être lisible dans les thèmes réellement
supportés.

## 28. Responsive et grand écran

Sur téléphone :

- une seule intention principale ouverte ;
- listes compactes ;
- actions en panneau ou écran secondaire ;
- éviter les tableaux larges.

Sur tablette :

- liste à gauche ;
- détail à droite lorsque pertinent ;
- conservation de la navigation basse principale.

Sur web/grand écran :

- navigation latérale interne possible ;
- tableaux uniquement pour les workflows qui bénéficient réellement d'une
  vue dense ;
- gestion des taxonomies et médias facilitée ;
- ne pas créer une application différente.

Le même modèle et les mêmes règles métier s'appliquent sur toutes les
plateformes.

## 29. Conservation de l'état

L'Atelier conserve pendant la session :

- intention principale ouverte ;
- sous-section active ;
- recherche ;
- filtres ;
- élément sélectionné ;
- position de défilement.

Changer d'onglet puis revenir ne doit pas ramener systématiquement en
haut de la racine.

Après une action :

- revenir au contexte pertinent ;
- mettre à jour les compteurs ;
- retirer les problèmes résolus ;
- ne pas réinitialiser toute la navigation.

## 30. Actions destructrices

Toute action destructive depuis l'Atelier doit appliquer :

- libellé précis ;
- conséquences visibles ;
- confirmation ;
- sauvegarde préalable lorsque nécessaire ;
- résultat explicite ;
- possibilité de restauration lorsque réellement supportée.

Ne pas utiliser un bouton générique `Supprimer` lorsque plusieurs niveaux
sont possibles.

Préférer :

- Retirer cette taxonomie ;
- Supprimer ce fichier inutilisé ;
- Retirer cette discipline vide ;
- Restaurer cette sauvegarde ;
- Retirer les contenus issus de cette source.

Le détail des protections par PIN appartient au lot 7.

## 31. Limites strictes du lot

Ne pas modifier :

- la navigation principale ;
- la Bibliothèque ;
- la fiche technique ;
- le workflow de capture ;
- Pratique et Compositions ;
- le modèle identité/contribution ;
- le rapprochement inter-packs ;
- le modèle physique des médias ;
- le format `.movpack` en profondeur ;
- les types de blocs des compositions ;
- la logique de sécurité et de PIN ;
- la direction graphique globale ;
- les plateformes ou le build Android.

Les adaptations autorisées concernent :

- architecture de l'Atelier ;
- workflows de structure ;
- diagnostics existants ;
- présentation et orchestration de l'import ;
- sélection sûre pour la publication ;
- sauvegarde et restauration avec les services existants ;
- réglages généraux existants ;
- redirections des anciennes routes Admin.

Toute faiblesse structurelle de format, stockage ou transaction doit être
**tracée pour le lot technique** et ne pas être masquée par l'interface.

## 32. Critères d'acceptation

**Scénario A — navigation Atelier**

1. ouvrir Atelier ;
2. voir quatre intentions seulement ;
3. ouvrir Construire ;
4. ouvrir Médias et qualité ;
5. vérifier que Construire se referme ;
6. passer à Échanger et protéger ;
7. quitter vers Bibliothèque ;
8. revenir et retrouver la section active.

**Scénario B — discipline**

1. ouvrir Construire > Disciplines ;
2. créer Karaté ;
3. renommer en Karaté Shotokan ;
4. ouvrir dans la Bibliothèque ;
5. revenir ;
6. retirer une discipline vide ;
7. tenter de retirer une discipline non vide ;
8. obtenir une explication actionnable sans perte.

**Scénario C — taxonomies**

1. créer une famille ;
2. créer un niveau ;
3. modifier leur ordre ;
4. utiliser les deux dans une technique ;
5. tenter de les supprimer ;
6. voir les utilisations ;
7. remplacer ou annuler ;
8. vérifier l'intégrité de la fiche.

**Scénario D — relation**

1. ouvrir les types de relation ;
2. voir les quatre types migrés ;
3. créer un type symétrique ;
4. l'utiliser ;
5. vérifier l'affichage de son libellé ;
6. empêcher sa suppression tant qu'il est utilisé.

**Scénario E — média manquant**

1. ouvrir Médias et qualité ;
2. voir une référence locale manquante ;
3. ouvrir la fiche concernée ;
4. remplacer ou retirer la référence ;
5. revenir ;
6. constater la disparition du problème.

**Scénario F — média orphelin**

1. lancer l'analyse ;
2. voir un fichier non référencé ;
3. ouvrir son détail ;
4. annuler la suppression ;
5. confirmer ensuite ;
6. vérifier qu'aucun média utilisé n'est supprimé.

**Scénario G — import**

1. choisir un `.movpack` ;
2. voir manifeste, auteur, version et contenu ;
3. voir les rapprochements ;
4. annuler sans mutation ;
5. recommencer ;
6. importer ;
7. lire le rapport ;
8. ouvrir la discipline.

**Scénario H — publication**

1. choisir Judo ;
2. sélectionner uniquement les contributions du club ;
3. vérifier que Kodokan et Mon carnet sont exclus ;
4. renseigner nom, auteur et version ;
5. voir la prévisualisation ;
6. générer ;
7. inspecter le rapport du pack ;
8. ne trouver aucun contenu tiers non sélectionné.

**Scénario I — sauvegarde**

1. créer une sauvegarde complète ;
2. voir les éléments et médias inclus ;
3. obtenir un fichier partageable ;
4. vérifier le nom, la taille et la date ;
5. ne pas confondre cette action avec Publier.

**Scénario J — restauration**

1. ouvrir une sauvegarde ;
2. voir son contenu avant action ;
3. annuler sans changement ;
4. restaurer sur installation compatible ;
5. vérifier Bibliothèque, Favoris, Compositions et médias ;
6. voir un rapport final.

**Scénario K — rollback**

1. modifier une discipline ;
2. utiliser un snapshot préalable ;
3. lire les conséquences ;
4. restaurer ;
5. vérifier l'état ;
6. conserver un snapshot de l'état abandonné si supporté.

**Scénario L — écran de démarrage**

1. choisir dernière discipline ;
2. fermer complètement ;
3. relancer ;
4. arriver sur cette discipline ;
5. supprimer la discipline ;
6. relancer ;
7. revenir automatiquement à Bibliothèque.

**Scénario M — téléphone**

1. parcourir toutes les sections ;
2. ne jamais avoir quatre blocs ouverts simultanément ;
3. ne pas rencontrer de mur de texte ;
4. toujours comprendre comment revenir.

## 33. Tests

Ajouter ou adapter les tests pour couvrir :

- quatre intentions exactement ;
- accordéon à une section ouverte ;
- redirection ancienne route Admin ;
- création, renommage et retrait de discipline vide ;
- refus de suppression non vide ;
- création et ordre de taxonomies ;
- dépendances avant suppression ;
- types de relation ;
- diagnostics médias ;
- absence de suppression d'un média référencé ;
- prévisualisation d'import ;
- annulation sans mutation ;
- rapport d'import ;
- sélection des contributions publiables ;
- exclusion du carnet et des sources tierces ;
- sauvegarde distincte de publication ;
- restauration ;
- snapshots ;
- préférence de démarrage ;
- fallback si la discipline choisie disparaît.

Ajouter un E2E vertical :

```
installation vide
→ Atelier
→ créer Judo
→ créer familles et niveaux
→ importer un pack
→ consulter le rapport
→ détecter un problème média
→ le traiter
→ publier uniquement une source maîtrisée
→ créer une sauvegarde
→ restaurer dans un contexte vierge
→ vérifier les données.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- sélection de fichier ;
- partage du pack ;
- partage de sauvegarde ;
- restauration ;
- accordéons ;
- retour Android ;
- clavier ;
- comportement sur tablette.

## 34. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- architecture de l'Atelier ;
- création et gestion d'une discipline ;
- taxonomies ;
- diagnostics médias ;
- import ;
- publication ;
- sauvegarde ;
- restauration ;
- rollback ;
- réglages de démarrage.

Ajouter un Mermaid compact :

```
Atelier
├── Construire
│   ├── Disciplines
│   ├── Taxonomies
│   ├── Techniques
│   └── Relations
├── Médias et qualité
│   ├── Problèmes
│   ├── Médiathèque
│   └── Qualité du corpus
├── Échanger et protéger
│   ├── Importer
│   ├── Publier
│   ├── Sauvegarder
│   └── Restaurer
└── Réglages et sécurité
    ├── Démarrage
    ├── Apparence
    └── Protections — lot 7
```

Pour chaque workflow, indiquer :

- entrée ;
- étapes ;
- sortie ;
- données affectées ;
- niveau réel de démonstration ;
- limites techniques connues.

`docs/systeme.md` :

- responsabilités de l'Atelier ;
- orchestration des services ;
- distinction publication/sauvegarde ;
- diagnostics ;
- règles de suppression ;
- gestion des états.

Matrice de conservation :

- capacités Admin V2 conservées ;
- tableau de bord dense supprimé ;
- KPI décoratifs supprimés ;
- disciplines et taxonomies conservées ;
- gestion média conservée ;
- historique CSV sacrifié comme fonction centrale ;
- rollback conservé ;
- publication séparée de la sauvegarde ;
- sécurité déplacée dans Atelier et différée au lot 7.

`docs/etat.md` :

- lot terminé ;
- workflows réellement démontrés ;
- limites ;
- risques techniques réservés au lot 8 ;
- prochain lot : Sécurité et modes d'usage.

## 35. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures ou vidéo montrant :
  - racine Atelier ;
  - les quatre intentions ;
  - Construire ;
  - diagnostic média ;
  - aperçu avant import ;
  - aperçu avant publication ;
  - sauvegardes et restauration ;
  - réglage de démarrage.

Rapport compact :

- fichiers modifiés ;
- anciennes routes redirigées ;
- architecture finale de l'Atelier ;
- fonctions V2 conservées ;
- fonctions transformées ;
- fonctions volontairement différées ;
- contenu exact d'un pack publié ;
- contenu exact d'une sauvegarde ;
- limites transactionnelles ou médias restant au lot technique.

N'anticipe pas le lot 7 Sécurité.

Ne refonds pas la Bibliothèque, la fiche, la capture, Pratique, le
stockage média ou les plateformes.

**La réussite de ce lot se mesure à une chose : un utilisateur qui
souhaite construire, vérifier, échanger ou protéger son corpus trouve
immédiatement le bon parcours, sans connaître l'architecture interne de
Movenso et sans traverser un panneau d'administration monolithique.**
