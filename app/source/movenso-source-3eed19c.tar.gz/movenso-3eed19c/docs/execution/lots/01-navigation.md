# LOT 1 — NAVIGATION GLOBALE ET DÉMARRAGE

## Contexte

Movenso V3 possède actuellement quatre destinations principales :

- Accueil ;
- Bibliothèque ;
- Compositions ;
- Atelier.

L'Accueil mélange recherche, reprise personnelle, compositions, import et
accès aux disciplines. Il crée un passage supplémentaire sans porter une
fonction suffisamment distincte.

La cible validée est désormais une application organisée autour de trois
intentions seulement :

1. consulter et enrichir son savoir ;
2. utiliser et réutiliser son savoir ;
3. construire, gouverner et protéger le corpus.

Ce lot porte **exclusivement** sur le shell de navigation, les routes, le
démarrage, la conservation de l'état et la redistribution des fonctions
actuellement placées sur l'Accueil.

Il ne doit **pas** anticiper la refonte détaillée de la Bibliothèque, des
fiches, des compositions ou de l'Atelier, qui feront l'objet de lots séparés.

## Objectif unique

Supprimer l'Accueil comme destination et comme passage obligatoire, puis
mettre en place une navigation stable à trois onglets :

- Bibliothèque ;
- Pratique ;
- Atelier.

L'application doit ouvrir directement sur la Bibliothèque et chaque fonction
actuellement accessible depuis l'Accueil doit conserver une destination
claire, **sans duplication ni perte silencieuse**.

## 1. Navigation principale

Mettre en place une barre de navigation basse contenant exactement trois
entrées :

- Bibliothèque ;
- Pratique ;
- Atelier.

La barre doit respecter les zones sûres Android et rester utilisable sur
téléphone comme sur tablette.

Ordre obligatoire :

1. Bibliothèque ;
2. Pratique ;
3. Atelier.

Utiliser des icônes simples et distinctes :

- Bibliothèque : livre, collection ou bibliothèque ;
- Pratique : assemblage, parcours ou entraînement ;
- Atelier : outil ou clé.

Ne pas conserver d'icône Accueil.

La destination active doit être immédiatement identifiable, **sans reposer
uniquement sur la couleur** : icône, libellé ou contraste doivent également
traduire l'état actif.

## 2. Suppression de l'Accueil

Supprimer l'Accueil :

- de la barre basse ;
- des routes de navigation normales ;
- du comportement de démarrage ;
- des liens de retour ;
- des préférences de démarrage ;
- de la documentation des workflows actifs.

Ne pas seulement masquer l'écran : **redistribuer ses capacités avant de
supprimer sa route**.

Les anciennes routes ou préférences pointant vers l'Accueil doivent être
migrées ou redirigées vers la Bibliothèque.

**Aucune donnée créée depuis l'ancien Accueil ne doit être supprimée.**

## 3. Démarrage

Au premier lancement, après une mise à jour et après une fermeture complète
de l'application, la destination par défaut est la **Bibliothèque**.

Deux états doivent être possibles.

**Bibliothèque contenant des disciplines :**

- afficher immédiatement la liste des disciplines ;
- ne pas imposer une recherche, une reprise ou une étape intermédiaire.

**Bibliothèque vide :**

- expliquer en une phrase que la bibliothèque est prête à recevoir du contenu ;
- proposer directement :
  - Importer un pack ;
  - Créer une discipline.

Ces actions peuvent encore utiliser leurs workflows actuels dans ce lot.
Leur refonte détaillée appartient au lot Bibliothèque.

Ne pas recréer un écran d'onboarding distinct.

Si une ancienne préférence de démarrage désigne l'Accueil, la **migrer
automatiquement** vers la Bibliothèque.

## 4. Onglet Bibliothèque

La Bibliothèque devient le **centre de consultation** du produit.

Dans ce lot, conserver ses capacités actuelles et y rendre accessibles les
fonctions de l'ancien Accueil qui relèvent réellement de la consultation :

- liste des disciplines ;
- recherche multi-discipline ou multi-pack déjà existante ;
- import d'un pack lorsque la bibliothèque est vide ;
- création d'une discipline lorsque la bibliothèque est vide.

Ne pas redessiner encore :

- les cartes ;
- les filtres ;
- les fiches ;
- les sources ;
- les médias ;
- les workflows de création.

Ces sujets appartiennent aux lots suivants.

La navigation doit cependant permettre :

```
Bibliothèque
→ discipline
→ liste des techniques
→ fiche technique
→ retour à la même liste, avec filtres et position conservés.
```

## 5. Onglet Pratique

Créer une destination principale **Pratique**.

Elle réunit les usages personnels et de réutilisation du savoir sans les
mélanger avec la gestion du corpus.

La racine de Pratique doit donner accès à :

- **Favoris** ;
- **Compositions**.

Les compositions actuellement accessibles comme onglet principal deviennent
une sous-destination de Pratique :

```
Pratique
→ Compositions
→ composition
→ consultation ou édition.
```

Les anciennes routes directes vers Compositions doivent être conservées par
redirection ou migration vers la nouvelle route.

**Favoris** doit disposer d'une entrée réelle dans Pratique.

Si le modèle V3 ne possède pas encore de favoris, **ne pas inventer un faux
comportement et ne pas modifier le modèle dans ce lot**. Créer seulement la
destination et son état vide explicite, puis tracer l'implémentation
fonctionnelle pour le lot Pratique.

Une section **À reprendre** peut être affichée uniquement lorsqu'il existe
une action réellement inachevée, par exemple :

- une capture non rattachée ;
- un brouillon de composition ;
- une action interrompue explicitement sauvegardée comme brouillon.

Ne pas utiliser « À reprendre » comme simple historique de consultation ou
comme liste de notes récentes.

Si aucun élément actionnable n'existe, la section n'apparaît pas.

Ne pas conserver le texte actuel centré sur « ton carnet est vide ».

## 6. Onglet Atelier

Conserver l'Atelier comme troisième destination principale.

Dans ce lot :

- ne pas refondre encore ses sections internes ;
- ne pas modifier ses capacités métier ;
- ne pas modifier le stockage, les packs ou les diagnostics ;
- conserver l'accès aux fonctions déjà présentes.

La refonte en quatre intentions sera faite dans le **lot Atelier** :

- Construire ;
- Médias et qualité ;
- Échanger et protéger ;
- Réglages et sécurité.

La clé à molette et l'onglet Atelier ne doivent pas constituer deux entrées
concurrentes.

Après la mise en place de la barre basse :

- supprimer toute clé à molette globale qui ne ferait qu'ouvrir l'Atelier ;
- garder une clé uniquement lorsqu'elle représente une action réellement
  locale à un écran.

## 7. Actions contextuelles

Supprimer le bouton flottant global `Capturer` du shell de l'application.

Il ne doit plus apparaître automatiquement :

- sur l'Atelier ;
- sur les compositions ;
- sur tous les écrans sans distinction.

Prévoir dans le shell un emplacement pour une **action contextuelle**,
définie par l'écran courant.

Pour ce lot, réutiliser les actions existantes sans refondre leurs workflows :

**Bibliothèque ou discipline :**

- action `Ajouter` ou `Nouvelle technique` lorsqu'une discipline est connue ;
- possibilité d'accéder au flux existant de capture ou de création.

**Fiche technique :**

- les actions restent locales à la fiche ;
- ne pas afficher un bouton global qui masque le contenu.

**Pratique, racine :**

- aucune action globale obligatoire.

**Liste des compositions :**

- action `Nouvelle composition`.

**Composition ouverte :**

- les actions d'ajout et d'édition appartiennent à la composition, pas au
  shell global.

**Atelier :**

- aucun bouton flottant générique.

Les libellés doivent décrire l'action réelle. Ne pas utiliser `Capturer`
lorsqu'il s'agit en réalité de créer une composition, modifier une taxonomie
ou publier un pack.

## 8. Conservation de l'état

Chaque onglet doit conserver son état pendant la session.

Exemples :

**Bibliothèque :**

- discipline ouverte ;
- recherche ;
- filtres ;
- position de défilement ;
- fiche précédemment ouverte lorsque le retour est demandé.

**Pratique :**

- sous-section Favoris ou Compositions ;
- composition ouverte ;
- position de liste.

**Atelier :**

- section ouverte ;
- position de défilement.

Changer d'onglet ne doit pas réinitialiser inutilement les écrans ni recréer
leurs données.

Un second appui sur l'onglet déjà actif peut revenir à sa racine ou remonter
en haut de la liste, à condition que ce comportement soit constant et
documenté.

## 9. Comportement du bouton retour Android

Le comportement doit être déterministe.

Ordre de priorité :

1. fermer le clavier ;
2. fermer une modale, un panneau ou un menu temporaire ;
3. quitter un workflow d'édition avec gestion explicite des modifications
   non enregistrées ;
4. remonter d'une fiche vers sa liste ;
5. remonter d'une sous-section vers la racine de son onglet ;
6. depuis la racine de Pratique ou Atelier, revenir à la Bibliothèque ;
7. depuis la racine de la Bibliothèque, laisser Android fermer ou mettre
   l'application en arrière-plan.

Le changement d'onglet ne doit pas empiler une infinité d'entrées dans
l'historique.

Un retour depuis une fiche doit restaurer les filtres et la position de la
bibliothèque.

## 10. Affichage de la barre basse

Afficher la barre basse sur :

- la racine Bibliothèque ;
- la liste d'une discipline ;
- la racine Pratique ;
- la liste des compositions ;
- la racine Atelier.

Elle peut être masquée pendant :

- capture guidée ;
- édition plein écran ;
- import ou restauration en cours ;
- confirmation destructive ;
- lecture immersive d'un média ;
- mode d'utilisation d'une composition pendant l'entraînement.

Ne pas la masquer arbitrairement sur les écrans de consultation courante.

## 11. Capacités de l'ancien Accueil à redistribuer

Avant suppression définitive de l'Accueil, vérifier la destination de
chaque capacité :

- recherche globale → Bibliothèque ;
- liste des disciplines → Bibliothèque ;
- import d'un pack → Bibliothèque vide et Atelier ;
- création d'une discipline → Bibliothèque vide et Atelier ;
- compositions → Pratique ;
- favoris → Pratique ;
- captures non rattachées → Pratique « À reprendre » ou futur espace de
  vérification de l'Atelier ;
- réglages → Atelier ;
- capture rapide → action contextuelle adaptée, jamais bouton global
  permanent.

Ne conserver aucune fonction uniquement parce qu'elle existait sur
l'Accueil.

Ne supprimer aucune fonction simplement parce que l'Accueil disparaît.

## 12. Limites strictes du lot

Ne pas modifier dans ce lot :

- le modèle de données métier ;
- le rapprochement des identités ;
- le modèle de provenance ;
- le format `.movpack` ;
- le stockage OPFS ;
- la gestion des médias ;
- la structure des compositions ;
- les types de relations ;
- le contenu interne détaillé de l'Atelier ;
- la fiche technique ;
- la direction graphique générale ;
- les règles de sécurité ou de PIN.

Les changements techniques autorisés sont limités à :

- routes ;
- shell ;
- navigation ;
- redirections ;
- état de navigation ;
- migration des préférences de démarrage ;
- déplacement des points d'entrée existants ;
- adaptations minimales nécessaires à la barre basse.

Toute amélioration identifiée hors périmètre doit être **tracée, pas
implémentée**.

## 13. Critères d'acceptation

Le lot est accepté uniquement si les scénarios suivants fonctionnent
réellement.

**Scénario A — démarrage avec contenu :**

1. lancer l'application ;
2. arriver directement sur Bibliothèque ;
3. voir les disciplines ;
4. ouvrir Judo ;
5. appliquer un filtre ;
6. ouvrir une technique ;
7. revenir ;
8. retrouver le filtre et la position.

**Scénario B — navigation :**

1. ouvrir Bibliothèque ;
2. passer à Pratique ;
3. ouvrir Compositions ;
4. revenir à Pratique ;
5. passer à Atelier ;
6. revenir à Bibliothèque ;
7. vérifier que les états précédents sont conservés.

**Scénario C — installation vide :**

1. lancer sans contenu ;
2. arriver sur la Bibliothèque vide ;
3. voir Importer un pack et Créer une discipline ;
4. utiliser chacun des deux points d'entrée sans repasser par un Accueil.

**Scénario D — bouton retour :**

1. Bibliothèque → discipline → fiche ;
2. retour vers la discipline avec état conservé ;
3. passage vers Atelier ;
4. retour Android vers Bibliothèque ;
5. retour Android depuis Bibliothèque vers le système.

**Scénario E — actions contextuelles :**

- aucun bouton Capturer dans l'Atelier ;
- aucune action Nouvelle composition dans la Bibliothèque ;
- création de composition accessible depuis Pratique ;
- ajout de technique accessible depuis une discipline ;
- aucune action globale ambiguë.

**Scénario F — compatibilité :**

- une ancienne route Accueil redirige vers Bibliothèque ;
- une ancienne route Compositions ouvre Pratique > Compositions ;
- une ancienne préférence de démarrage Accueil est migrée ;
- aucune donnée existante n'est perdue.

## 14. Tests

Ajouter ou adapter les tests automatisés pour couvrir :

- route initiale ;
- redirections ;
- trois onglets seulement ;
- restauration de l'état ;
- navigation Android simulée lorsque possible ;
- ancien lien Compositions ;
- ancienne préférence Accueil ;
- disparition du bouton global dans l'Atelier.

Compléter par une vérification manuelle Android lorsque le comportement du
bouton retour ou du clavier ne peut pas être prouvé par le navigateur.

`npm run verifier` doit être vert.

## 15. Documentation

Mettre à jour les sources existantes, sans créer un nouveau document :

- **`docs/workflows.md`** :
  - carte Mermaid de la navigation à trois onglets ;
  - destinations de l'ancien Accueil ;
  - comportement du bouton retour ;
  - statut réellement démontré de chaque parcours ;
- **`docs/systeme.md`** :
  - shell et routes réels ;
- **matrice de conservation** :
  - Accueil supprimé avec justification ;
  - fonctions redistribuées ;
  - aucune capacité perdue silencieusement ;
- **`docs/etat.md`** :
  - lot terminé ;
  - tests ;
  - limites connues ;
  - prochain lot.

La documentation doit refléter l'implémentation réelle et non la cible
future.

## 16. Livrable

À la fin du lot :

- commit et push dédiés au lot 1 ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- trois captures montrant les racines :
  - Bibliothèque ;
  - Pratique ;
  - Atelier ;
- rapport compact contenant :
  - fichiers modifiés ;
  - routes supprimées ou redirigées ;
  - comportement du bouton retour ;
  - capacités de l'Accueil redistribuées ;
  - anomalies restantes strictement hors périmètre.

**N'interprète pas ce lot comme une autorisation à modifier les autres
onglets ou à anticiper les étapes suivantes.**

**Aucune fonctionnalité métier nouvelle, aucune refonte de fiche, aucune
modification du modèle et aucune réorganisation détaillée de l'Atelier ne
doivent être réalisées dans ce lot.**
