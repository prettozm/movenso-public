# Backlog exhaustif de stabilisation vers Movenso v1

Cette liste est exhaustive **au regard du dépôt source et de l’audit fonctionnel réalisés**. La recette sur appareils pourra naturellement révéler quelques anomalies supplémentaires.

## Règle de départ

À partir de maintenant :

> **Gel fonctionnel complet jusqu’à la v1.**

Aucune nouvelle vue, aucun nouveau type de relation, aucun enrichissement des packs et aucune fonction secondaire tant que les priorités P0 à P2 ne sont pas closes.

Les priorités signifient :

- **P0 — Bloquant** : impossible de publier publiquement sans traitement.
- **P1 — Critique** : nécessaire pour une v1 fiable et compréhensible.
- **P2 — Stabilisation technique** : nécessaire pour éviter que la v1 soit difficile à maintenir.
- **P3 — Publication communautaire** : nécessaire pour distribuer et supporter proprement la v1.
- **P4 — Finition optimale** : fortement souhaitable, mais reportable après la v1 si nécessaire.

---

# P0 — Bloquants avant toute mise à disposition publique

## P0.1 — Garantir un build reproductible

- [ ] Tester un `npm ci` depuis une machine vierge.
- [ ] Vérifier qu’aucune dépendance ne dépend implicitement d’un registre npm privé.
- [ ] Fixer officiellement la version de Node.js.
- [ ] Fixer ou encadrer la version de npm.
- [ ] Conserver un `package-lock.json` propre et reproductible.
- [ ] Vérifier que le build ne dépend d’aucun fichier non versionné.
- [ ] Documenter les commandes exactes de construction.
- [ ] Construire l’application dans la CI à partir d’un clone propre.
- [ ] Publier comme artefact CI le build réellement testé.
- [ ] Interdire qu’un build local différent soit publié manuellement.

**Critère de sortie :** un tiers clone le dépôt, exécute une seule procédure documentée et obtient exactement le build publiable.

---

## P0.2 — Obtenir une CI intégralement verte

La chaîne minimale doit exécuter :

- [ ] vérification TypeScript ;
- [ ] tests unitaires ;
- [ ] tests de migration ;
- [ ] tests d’import/export ;
- [ ] build de production ;
- [ ] tests E2E Chromium ;
- [ ] vérification des fichiers produits ;
- [ ] vérification qu’aucun fichier source ou secret inutile n’est inclus dans le build.

**Critère de sortie :** aucun test ignoré sans justification et aucune publication possible lorsque la CI est rouge.

---

## P0.3 — Centraliser et sécuriser toutes les URL externes

Créer une seule fonction de validation utilisée partout.

- [ ] Parser chaque URL avec `new URL()`.
- [ ] Autoriser uniquement `https:`.
- [ ] N’autoriser `http:` que si c’est une décision explicite.
- [ ] Refuser `javascript:`.
- [ ] Refuser `data:`.
- [ ] Refuser `file:`.
- [ ] Refuser les protocoles inconnus.
- [ ] Refuser les chaînes non valides.
- [ ] Normaliser l’URL avant stockage.
- [ ] Traiter YouTube via un parseur strict.
- [ ] Accepter seulement les domaines YouTube prévus.
- [ ] Extraire proprement l’identifiant de la vidéo.
- [ ] Ne jamais construire directement un `href` ou un `src` depuis une chaîne brute.
- [ ] Ajouter `rel="noopener noreferrer"` sur les liens externes.
- [ ] Signaler clairement que l’utilisateur quitte Movenso.
- [ ] Ajouter des tests de sécurité sur chaque protocole refusé.

**Critère de sortie :** aucune chaîne utilisateur ne peut atteindre directement un `href`, un `src` ou un embed sans validation préalable.

---

## P0.4 — Durcir les imports `.movpack`

Ajouter des limites explicites avant et pendant la décompression.

- [ ] Taille maximale de l’archive compressée.
- [ ] Taille maximale totale décompressée.
- [ ] Taille maximale d’un fichier.
- [ ] Taille maximale du manifeste.
- [ ] Taille maximale de `bibliotheque.json`.
- [ ] Nombre maximal d’entrées dans le ZIP.
- [ ] Nombre maximal de techniques.
- [ ] Nombre maximal de disciplines.
- [ ] Nombre maximal de contributions.
- [ ] Nombre maximal de relations.
- [ ] Nombre maximal de compositions.
- [ ] Nombre maximal de médias.
- [ ] Profondeur maximale des structures JSON.
- [ ] Longueur maximale des textes et identifiants.
- [ ] Refus des chemins absolus.
- [ ] Refus de `../`.
- [ ] Refus des chemins Windows dangereux.
- [ ] Refus des doublons de chemins dans l’archive.
- [ ] Contrôle du ratio compression/décompression.
- [ ] Contrôle du type réel des médias.
- [ ] Contrôle de l’extension par rapport au contenu.
- [ ] Refus des fichiers exécutables ou inattendus.
- [ ] Arrêt propre lorsque la limite est dépassée.
- [ ] Nettoyage du staging après rejet.
- [ ] Tests avec ZIP bomb simulée.
- [ ] Tests avec manifeste volontairement mensonger.
- [ ] Tests avec JSON tronqué ou extrêmement profond.
- [ ] Tests avec chemins malveillants.

**Critère de sortie :** une archive hostile ne peut ni sortir de la zone prévue, ni saturer silencieusement la mémoire ou le stockage.

---

## P0.5 — Rendre l’import réellement transactionnel

Aujourd’hui, certains médias peuvent être promus avant la persistance finale de la bibliothèque.

Il faut garantir :

- [ ] staging complet de l’import ;
- [ ] validation complète avant toute promotion ;
- [ ] liste exacte des fichiers nouvellement créés ;
- [ ] promotion des médias ;
- [ ] persistance de la bibliothèque ;
- [ ] rollback des médias si la persistance échoue ;
- [ ] rollback si l’utilisateur annule après une erreur ;
- [ ] nettoyage après fermeture ou interruption ;
- [ ] reprise explicite ou abandon propre après crash ;
- [ ] absence de média orphelin après échec ;
- [ ] idempotence en cas de nouvel essai ;
- [ ] test de coupure à chaque étape de la transaction.

**Critère de sortie :** après n’importe quelle interruption, Movenso revient soit à l’état précédent, soit au nouvel état complet, jamais à un état intermédiaire.

---

## P0.6 — Certifier les sauvegardes et restaurations

Construire une campagne réelle avec des bibliothèques de référence.

- [ ] Créer une bibliothèque comprenant disciplines, techniques, relations, favoris, contributions, compositions et médias.
- [ ] Produire une sauvegarde légère.
- [ ] Produire une sauvegarde complète.
- [ ] Restaurer sur une installation vierge.
- [ ] Comparer chaque objet métier avant/après.
- [ ] Comparer les empreintes des médias.
- [ ] Vérifier les favoris.
- [ ] Vérifier les relations orientées et symétriques.
- [ ] Vérifier les compositions.
- [ ] Vérifier les contributions personnelles.
- [ ] Vérifier les éléments « À traiter ».
- [ ] Vérifier les médias manquants.
- [ ] Vérifier les caractères Unicode et noms accentués.
- [ ] Tester une sauvegarde corrompue.
- [ ] Tester une sauvegarde tronquée.
- [ ] Tester une sauvegarde provenant d’une ancienne version.
- [ ] Tester l’interruption pendant la restauration.
- [ ] Vérifier qu’aucune donnée existante n’est écrasée avant confirmation.
- [ ] Documenter précisément ce qui est restauré.
- [ ] Documenter précisément ce qui ne l’est pas.

**Critère de sortie :** une sauvegarde complète restaure exactement ce qui est promis, et uniquement ce qui est promis.

---

## P0.7 — Inspecter la confidentialité de tous les exports

Pour chaque type d’export :

- [ ] pack complet ;
- [ ] pack partiel ;
- [ ] technique seule ;
- [ ] composition ;
- [ ] sauvegarde légère ;
- [ ] sauvegarde complète ;
- [ ] diagnostic ;

ouvrir réellement l’archive et vérifier l’absence de :

- [ ] notes privées non sélectionnées ;
- [ ] favoris ;
- [ ] pseudo ;
- [ ] PIN ;
- [ ] dérivé du PIN ;
- [ ] réglages de sécurité ;
- [ ] historique de navigation ;
- [ ] captures non rattachées ;
- [ ] médias personnels non sélectionnés ;
- [ ] chemins locaux ;
- [ ] identifiants internes inutiles ;
- [ ] données de diagnostic non annoncées.

**Critère de sortie :** tests automatiques de non-divulgation ajoutés pour chaque format exporté.

---

## P0.8 — Trancher définitivement la promesse « hors ligne »

Deux options seulement.

### Option A — Tenir la promesse complète

- [ ] créer `manifest.webmanifest` ;
- [ ] ajouter un service worker ;
- [ ] mettre en cache l’app-shell ;
- [ ] versionner les caches ;
- [ ] nettoyer les anciennes versions ;
- [ ] prévoir une page de secours ;
- [ ] rendre l’application installable ;
- [ ] indiquer lorsque l’application est prête hors ligne ;
- [ ] gérer proprement les mises à jour du service worker ;
- [ ] tester un démarrage à froid en mode avion ;
- [ ] tester un rechargement en mode avion ;
- [ ] tester une mise à jour après retour du réseau.

### Option B — Réduire la promesse

Dire explicitement :

> Les données et vidéos restent sur l’appareil. Une connexion peut être nécessaire pour charger ou mettre à jour l’application web et consulter les ressources externes.

**Critère de sortie :** aucune différence entre la communication publique et le comportement réel.

---

## P0.9 — Gérer correctement la persistance OPFS

- [ ] lire le résultat de `navigator.storage.persist()`;
- [ ] afficher si la persistance a été accordée ;
- [ ] afficher si le stockage peut être nettoyé par le navigateur ;
- [ ] afficher l’espace utilisé ;
- [ ] afficher le quota estimé ;
- [ ] vérifier l’espace disponible avant une grosse écriture ;
- [ ] vérifier la limite Movenso avant de démarrer ;
- [ ] arrêter proprement si le quota devient insuffisant ;
- [ ] informer clairement l’utilisateur ;
- [ ] tester un quota presque plein ;
- [ ] tester un dépassement en cours d’écriture ;
- [ ] tester un navigateur refusant la persistance.

**Critère de sortie :** Movenso ne commence pas une opération qu’il sait ne pas pouvoir terminer.

---

## P0.10 — Gérer les navigateurs non compatibles

L’application ne doit pas simplement échouer lorsque OPFS manque.

- [ ] détecter précisément les capacités disponibles ;
- [ ] afficher un écran explicatif ;
- [ ] nommer les navigateurs supportés ;
- [ ] proposer une action de sortie ou de sauvegarde ;
- [ ] ne pas afficher une interface partiellement fonctionnelle ;
- [ ] tester un navigateur sans OPFS ;
- [ ] tester le mode privé ;
- [ ] tester un environnement où le quota est très faible.

**Critère de sortie :** aucun écran blanc ou erreur technique brute sur un environnement non supporté.

---

## P0.11 — Supprimer les injections par `innerHTML`

- [ ] remplacer la construction SVG par des éléments DOM/SVG typés ;
- [ ] ou démontrer et tester l’échappement strict de chaque valeur ;
- [ ] interdire l’arrivée future de valeurs utilisateur dans ces chaînes ;
- [ ] ajouter un contrôle automatisé empêchant les nouveaux usages non justifiés de `innerHTML`.

**Critère de sortie :** aucun contenu métier ou utilisateur injecté par concaténation HTML.

---

## P0.12 — Traiter les erreurs sans perdre l’utilisateur

Pour chaque opération longue ou critique :

- [ ] message d’erreur compréhensible ;
- [ ] cause conservée dans le diagnostic ;
- [ ] aucune stack trace brute dans l’interface ;
- [ ] action de reprise ou de retour ;
- [ ] possibilité d’exporter un diagnostic ;
- [ ] conservation de l’état précédent ;
- [ ] nettoyage des fichiers temporaires ;
- [ ] absence de boucle de redémarrage.

**Critère de sortie :** toute erreur P0 possède un test et un chemin de récupération.

---

# P1 — Fonctions critiques à fermer pour une v1 cohérente

## P1.1 — Unifier la création de techniques

- [ ] faire utiliser le même service métier à la création rapide et à la création complète ;
- [ ] appliquer partout la détection des doublons exacts ;
- [ ] appliquer partout les suggestions de doublons proches ;
- [ ] appliquer partout la validation des noms ;
- [ ] gérer les noms constitués uniquement d’emojis ou de symboles ;
- [ ] générer un identifiant stable lorsque le slug est vide ;
- [ ] ajouter des tests couvrant tous les points d’entrée.

---

## P1.2 — Terminer proprement les séances

- [ ] remplacer « Suivant » par « Terminer » sur la dernière étape ;
- [ ] arrêter proprement le chronomètre ;
- [ ] arrêter la voix et les bips ;
- [ ] afficher un résumé minimal ;
- [ ] indiquer la durée réalisée ;
- [ ] permettre de fermer sans ambiguïté ;
- [ ] tester la dernière étape sans durée ;
- [ ] tester la dernière étape avec avancement automatique.

---

## P1.3 — Fiabiliser le chronomètre et l’audio

Tester au minimum :

- [ ] écran verrouillé ;
- [ ] changement d’onglet ;
- [ ] application en arrière-plan ;
- [ ] écran éteint puis rallumé ;
- [ ] appel téléphonique ;
- [ ] interruption audio ;
- [ ] casque Bluetooth ;
- [ ] sortie Bluetooth ;
- [ ] mode silencieux ;
- [ ] navigateur bloquant l’autoplay ;
- [ ] changement de voix système ;
- [ ] dérive après 5, 15 et 30 minutes ;
- [ ] pause puis reprise ;
- [ ] passage manuel à l’étape suivante ;
- [ ] retour à l’étape précédente.

Décider explicitement ce qui est garanti ou non en arrière-plan.

---

## P1.4 — Ajouter l’annulation des opérations longues

- [ ] annulation pendant l’analyse d’une vidéo ;
- [ ] annulation pendant la copie ;
- [ ] annulation pendant le calcul d’empreinte ;
- [ ] annulation pendant un export ;
- [ ] annulation pendant un import ;
- [ ] annulation pendant une sauvegarde ;
- [ ] suppression des fichiers temporaires ;
- [ ] conservation de l’état précédent ;
- [ ] message confirmant l’annulation.

---

## P1.5 — Fermer la fonction « Tablette partagée »

Choisir une seule option :

- [ ] exposer un bouton « Configurer comme tablette partagée » ;
- [ ] expliquer les protections activées ;
- [ ] permettre de revenir aux réglages précédents ;

ou :

- [ ] supprimer le code mort et la documentation associée.

---

## P1.6 — Clarifier fusion et défusion

- [ ] expliquer que la défusion n’est pas forcément une restauration bit à bit ;
- [ ] afficher les relations qui resteront rattachées ;
- [ ] indiquer les médias concernés ;
- [ ] indiquer les compositions concernées ;
- [ ] créer un point de restauration avant fusion ;
- [ ] permettre une prévisualisation ;
- [ ] harmoniser tous les textes de l’interface ;
- [ ] ajouter des tests sur les relations entrantes.

---

## P1.7 — Harmoniser suppression, corbeille et restauration

Remplacer les termes ambigus.

- [ ] « supprimer » : déplacement dans la corbeille ;
- [ ] « retirer définitivement de la corbeille » : plus restaurable depuis la corbeille ;
- [ ] préciser qu’un point de restauration global peut encore exister ;
- [ ] afficher sa durée de conservation ;
- [ ] tester la suppression d’une technique utilisée dans une composition ;
- [ ] tester la suppression d’une technique reliée ;
- [ ] tester la suppression d’une discipline entière.

---

## P1.8 — Corriger toutes les promesses de sauvegarde

Remplacer « restaurable à l’identique » par une formulation exacte :

> Sauvegarde complète de la bibliothèque, du carnet et des médias présents. Les réglages propres à l’appareil et le PIN devront être reconfigurés.

- [ ] corriger l’aide ;
- [ ] corriger le chemin « Plus › Sauvegardes » ;
- [ ] corriger les modales ;
- [ ] corriger le site public ;
- [ ] corriger les notes de version ;
- [ ] ajouter la limite « restauration sur installation vierge ».

---

## P1.9 — Ajouter des alternatives au glisser-déposer

Pour chaque élément réordonnable :

- [ ] bouton Monter ;
- [ ] bouton Descendre ;
- [ ] ordre clavier ;
- [ ] annonce accessible du nouvel emplacement ;
- [ ] support TalkBack ;
- [ ] support petit écran ;
- [ ] conservation du drag-and-drop comme raccourci.

Cela concerne notamment :

- [ ] compositions ;
- [ ] disciplines ;
- [ ] catégories ;
- [ ] niveaux ;
- [ ] éléments de relations lorsque pertinent.

---

## P1.10 — Rendre les parcours essentiels accessibles

- [ ] labels accessibles pour tous les boutons ;
- [ ] nom accessible des icônes ;
- [ ] ordre de tabulation logique ;
- [ ] focus visible ;
- [ ] retour du focus après fermeture d’une modale ;
- [ ] modales réellement modales pour le lecteur d’écran ;
- [ ] messages d’erreur annoncés ;
- [ ] boutons suffisamment grands ;
- [ ] contraste jour et nuit ;
- [ ] zoom texte à 200 % ;
- [ ] utilisation sans souris ;
- [ ] test TalkBack Android ;
- [ ] test clavier Windows.

---

## P1.11 — Clarifier l’ouverture des ressources externes

- [ ] indicateur visuel « lien externe » ;
- [ ] confirmation facultative selon préférence ;
- [ ] affichage du domaine ;
- [ ] avertissement en cas de HTTP ;
- [ ] ouverture dans un contexte séparé ;
- [ ] aucun lien silencieux depuis une carte entière.

---

## P1.12 — Nettoyer et réparer les médias orphelins

- [ ] identifier les fichiers orphelins ;
- [ ] afficher leur taille ;
- [ ] permettre une suppression individuelle ;
- [ ] permettre une suppression groupée ;
- [ ] créer un point de restauration lorsque possible ;
- [ ] distinguer fichier orphelin et référence cassée ;
- [ ] permettre de rattacher un média retrouvé ;
- [ ] tester les erreurs de suppression.

---

## P1.13 — Vérifier la limite vidéo avant écriture

- [ ] contrôler la taille connue du fichier ;
- [ ] estimer le besoin temporaire du staging ;
- [ ] intégrer la marge pour les sauvegardes et métadonnées ;
- [ ] prévenir avant le démarrage ;
- [ ] refuser proprement si la limite sera dépassée ;
- [ ] ne pas compter deux fois un média dédupliqué.

---

## P1.14 — Garantir une première ouverture claire

- [ ] expliquer en une phrase ce qu’est Movenso ;
- [ ] proposer « Importer un pack » ;
- [ ] proposer « Créer une discipline » ;
- [ ] proposer éventuellement un starter pack ;
- [ ] ne pas forcer un tutoriel long ;
- [ ] indiquer que les données restent locales ;
- [ ] indiquer comment sauvegarder ;
- [ ] ne pas demander de PIN dès le démarrage.

---

## P1.15 — Vérifier tous les workflows sur une bibliothèque vide

Aucun écran ne doit supposer qu’il existe déjà :

- [ ] une discipline ;
- [ ] une technique ;
- [ ] une composition ;
- [ ] une relation ;
- [ ] un favori ;
- [ ] un média ;
- [ ] une capture ;
- [ ] un pack installé.

---

## P1.16 — Vérifier tous les workflows sur une grosse bibliothèque

Créer un jeu de test d’au moins :

- [ ] 10 disciplines ;
- [ ] 2 000 techniques ;
- [ ] 10 000 relations ;
- [ ] 500 contributions ;
- [ ] 100 compositions ;
- [ ] plusieurs gigaoctets de médias simulés ou réels.

Mesurer :

- [ ] temps de démarrage ;
- [ ] temps de recherche ;
- [ ] temps d’affichage ;
- [ ] temps d’import ;
- [ ] temps de sauvegarde ;
- [ ] consommation mémoire ;
- [ ] fluidité de la Mindmap ;
- [ ] fluidité d’Explorer.

---

# P2 — Stabilisation de l’architecture et de la maintenabilité

## P2.1 — Réduire `racine.ts`

Objectif recommandé : passer de près de 3 700 lignes à moins de 1 200, puis continuer progressivement.

Extraire au minimum :

- [ ] service de navigation ;
- [ ] service d’import ;
- [ ] service d’export ;
- [ ] service de sauvegarde/restauration ;
- [ ] service de médias ;
- [ ] service de sécurité ;
- [ ] service de compositions ;
- [ ] service de relations ;
- [ ] service de disciplines et taxonomies ;
- [ ] service de doublons ;
- [ ] service de notifications ;
- [ ] état de session d’entraînement ;
- [ ] état de capture ;
- [ ] état des modales.

La racine doit principalement :

- initialiser ;
- composer les services ;
- porter la navigation générale ;
- rendre l’application.

---

## P2.2 — Éviter que les vues dépendent de `MovensoApp`

Dix modules semblent connaître directement l’objet applicatif complet.

- [ ] définir des interfaces minimales par vue ;
- [ ] passer uniquement les données nécessaires ;
- [ ] passer des callbacks ciblés ;
- [ ] interdire la mutation libre de la racine ;
- [ ] utiliser des événements typés ;
- [ ] tester les vues isolément.

---

## P2.3 — Découper `atelier.ts`

Extraire :

- [ ] édition d’une technique ;
- [ ] gestion des contributions ;
- [ ] gestion des médias ;
- [ ] classement ;
- [ ] provenance ;
- [ ] aperçu ;
- [ ] validations ;
- [ ] actions destructrices.

---

## P2.4 — Découper `relations-visuelle.ts`

Séparer :

- [ ] modèle de disposition ;
- [ ] calcul des positions ;
- [ ] rendu SVG ;
- [ ] interaction tactile ;
- [ ] navigation clavier ;
- [ ] gestion du centre ;
- [ ] sélection ;
- [ ] zoom et déplacement ;
- [ ] règles de visibilité.

Le calcul graphique devrait pouvoir être testé sans DOM.

---

## P2.5 — Découper `app.css`

- [ ] variables et thèmes ;
- [ ] shell ;
- [ ] bibliothèque ;
- [ ] fiches ;
- [ ] capture ;
- [ ] compositions ;
- [ ] relations ;
- [ ] administration ;
- [ ] modales ;
- [ ] accessibilité ;
- [ ] responsive.

Éviter les sélecteurs globaux fragiles.

---

## P2.6 — Corriger l’inversion de dépendance du domaine

Le domaine ne devrait pas importer depuis `echange`.

- [ ] déplacer `sourceDe` dans le domaine ou dans un module neutre ;
- [ ] vérifier toutes les dépendances entre couches ;
- [ ] empêcher par lint les imports interdits ;
- [ ] formaliser l’ordre :

```text
domaine
↑
application
↑
infrastructure / stockage / échange
↑
interface
```

---

## P2.7 — Découper les tests E2E

Créer des fichiers indépendants :

- [ ] démarrage ;
- [ ] bibliothèque ;
- [ ] capture ;
- [ ] médias ;
- [ ] compositions ;
- [ ] relations ;
- [ ] doublons ;
- [ ] import ;
- [ ] export ;
- [ ] sauvegarde ;
- [ ] restauration ;
- [ ] sécurité ;
- [ ] maintenance ;
- [ ] réinitialisation.

Chaque test doit pouvoir être lancé séparément.

---

## P2.8 — Réduire les temporisations fixes

- [ ] remplacer `waitForTimeout` par des attentes d’état ;
- [ ] attendre un élément visible ;
- [ ] attendre la disparition d’un chargement ;
- [ ] attendre une écriture OPFS terminée ;
- [ ] attendre un événement applicatif ;
- [ ] ne conserver les délais fixes que pour tester une durée réelle.

---

## P2.9 — Ajouter des tests applicatifs intermédiaires

Entre le domaine unitaire et l’E2E complet :

- [ ] tests de services applicatifs ;
- [ ] tests des contrôleurs ;
- [ ] tests des vues avec dépendances simulées ;
- [ ] tests des transactions d’import ;
- [ ] tests des scénarios de médias ;
- [ ] tests de navigation ;
- [ ] tests de permissions PIN.

Cela réduira la dépendance au gros E2E.

---

## P2.10 — Ajouter une vraie chaîne de qualité

- [ ] ESLint ;
- [ ] Prettier ;
- [ ] vérification automatique du format ;
- [ ] détection du code mort ;
- [ ] détection des exports inutilisés ;
- [ ] contrôle des dépendances circulaires ;
- [ ] contrôle des frontières architecturales ;
- [ ] couverture de tests ;
- [ ] seuil minimum de couverture ;
- [ ] rapport de taille du bundle ;
- [ ] budget de bundle ;
- [ ] contrôle de la taille des fichiers ;
- [ ] interdiction de nouveaux `innerHTML` ;
- [ ] interdiction de `any` ;
- [ ] audit des dépendances.

---

## P2.11 — Définir des budgets de complexité

Par exemple :

- [ ] maximum 800 lignes par composant UI ;
- [ ] maximum 400 lignes recommandé ;
- [ ] maximum de complexité cyclomatique ;
- [ ] maximum de paramètres par fonction ;
- [ ] maximum de responsabilités par service ;
- [ ] justification obligatoire pour les exceptions.

Ne pas bloquer la v1 sur un nombre arbitraire, mais empêcher l’aggravation.

---

## P2.12 — Nettoyer les anomalies connues du code

- [ ] suppression appelée deux fois dans `supprimerArchiveTemp` ;
- [ ] toast ou message dupliqué dans le contrôle d’espace ;
- [ ] fonctions non raccordées ;
- [ ] imports inutilisés ;
- [ ] branches mortes ;
- [ ] commentaires devenus faux ;
- [ ] anciens noms de vues ;
- [ ] anciennes promesses ;
- [ ] anciennes décisions contredites par le produit courant.

---

## P2.13 — Simplifier la documentation

Conserver quatre niveaux distincts :

### État courant

- [ ] document court ;
- [ ] uniquement ce qui est vrai aujourd’hui ;
- [ ] problèmes ouverts ;
- [ ] prochaine étape.

### Architecture

- [ ] architecture réellement en vigueur ;
- [ ] dépendances ;
- [ ] formats ;
- [ ] invariants.

### Décisions

- [ ] ADR courtes et immuables ;
- [ ] statut accepté, remplacé ou abandonné ;
- [ ] lien vers la décision suivante.

### Historique

- [ ] archives par version ou jalon ;
- [ ] sorties de `STATE.md` ;
- [ ] anciennes roadmaps.

Objectif : qu’un nouveau contributeur puisse comprendre le projet sans lire 30 000 lignes.

---

## P2.14 — Établir un diagnostic structuré

- [ ] codes d’erreur stables ;
- [ ] contexte technique non sensible ;
- [ ] version de l’application ;
- [ ] version du schéma ;
- [ ] plateforme ;
- [ ] état du stockage ;
- [ ] opération en cours ;
- [ ] dernier échec ;
- [ ] export manuel du diagnostic ;
- [ ] aucune donnée personnelle par défaut.

---

# P3 — Préparation de la mise à disposition communautaire

## P3.1 — Définir précisément ce qu’est la v1

Écrire une page contenant :

### Inclus

- bibliothèque locale ;
- import/export `.movpack` ;
- capture ;
- contributions ;
- relations bêta ou stable ;
- compositions ;
- séances guidées ;
- sauvegarde ;
- diagnostic ;
- protection PIN.

### Non inclus

- compte ;
- cloud ;
- synchronisation multiappareil ;
- récupération distante du PIN ;
- marketplace ;
- validation officielle des contenus ;
- sauvegarde hébergée ;
- collaboration temps réel.

---

## P3.2 — Choisir les canaux officiels

- [ ] application web ;
- [ ] PWA éventuelle ;
- [ ] application Android Play Store ;
- [ ] APK miroir signé ;
- [ ] packs séparés.

Pour chaque canal :

- [ ] version ;
- [ ] date ;
- [ ] empreinte ;
- [ ] provenance ;
- [ ] procédure de mise à jour ;
- [ ] support prévu.

---

## P3.3 — Mettre en place un versionnement clair

- [ ] Semantic Versioning ;
- [ ] version visible dans l’application ;
- [ ] version dans les diagnostics ;
- [ ] version dans les sauvegardes ;
- [ ] version dans les packs ;
- [ ] version dans les artefacts ;
- [ ] tag Git correspondant ;
- [ ] notes de version correspondant exactement au build.

---

## P3.4 — Préparer une vraie release candidate

Créer successivement :

- [ ] `1.0.0-rc.1` pour tests internes ;
- [ ] `1.0.0-rc.2` pour groupe fermé ;
- [ ] dernière RC sans nouvelle fonction ;
- [ ] `1.0.0` identique à la dernière RC, hors numéro de version.

Aucune correction non testée directement dans la v1.

---

## P3.5 — Préparer un jeu de packs de référence

- [ ] petit starter pack ;
- [ ] pack avec relations ;
- [ ] pack avec compositions ;
- [ ] pack avec liens ;
- [ ] pack avec vidéos ;
- [ ] ancienne version pour tester les mises à jour ;
- [ ] pack volontairement invalide pour la recette ;
- [ ] pack volumineux.

Chaque pack doit avoir :

- [ ] auteur ;
- [ ] version ;
- [ ] licence ;
- [ ] sources ;
- [ ] date ;
- [ ] statut officiel ou communautaire ;
- [ ] contact ou identifiant du mainteneur.

---

## P3.6 — Définir la gouvernance des packs communautaires

- [ ] format obligatoire ;
- [ ] champs obligatoires ;
- [ ] licence obligatoire ;
- [ ] déclaration des sources ;
- [ ] responsabilité de l’auteur ;
- [ ] distinction officiel/non officiel ;
- [ ] procédure de signalement ;
- [ ] procédure de retrait ;
- [ ] politique de mise à jour ;
- [ ] gestion des forks ;
- [ ] gestion des conflits d’identifiants ;
- [ ] absence de garantie pédagogique ou médicale.

---

## P3.7 — Documenter le format `.movpack`

La documentation publique doit couvrir :

- [ ] structure du ZIP ;
- [ ] manifeste ;
- [ ] schéma JSON ;
- [ ] identifiants ;
- [ ] disciplines ;
- [ ] techniques ;
- [ ] relations ;
- [ ] contributions ;
- [ ] médias ;
- [ ] compositions ;
- [ ] empreintes ;
- [ ] limites ;
- [ ] compatibilité ;
- [ ] migrations ;
- [ ] exemples minimaux ;
- [ ] erreurs fréquentes.

Idéalement fournir un validateur CLI ou une commande de validation.

---

## P3.8 — Préparer la documentation utilisateur

Documentation courte et orientée actions :

- [ ] démarrer ;
- [ ] importer un pack ;
- [ ] capturer ;
- [ ] classer plus tard ;
- [ ] ajouter un média ;
- [ ] créer une composition ;
- [ ] lancer une séance ;
- [ ] sauvegarder ;
- [ ] restaurer ;
- [ ] partager ;
- [ ] comprendre le PIN ;
- [ ] comprendre le stockage local ;
- [ ] récupérer après un problème ;
- [ ] exporter un diagnostic.

---

## P3.9 — Préparer le support communautaire

- [ ] dépôt public ou espace de tickets ;
- [ ] modèle de bug ;
- [ ] modèle de demande d’évolution ;
- [ ] modèle de problème de pack ;
- [ ] informations minimales demandées ;
- [ ] export du diagnostic ;
- [ ] politique de réponse ;
- [ ] périmètre de support ;
- [ ] navigateurs supportés ;
- [ ] appareils testés ;
- [ ] problèmes connus.

---

## P3.10 — Publier une politique de sécurité

- [ ] méthode privée de signalement ;
- [ ] adresse ou canal de contact ;
- [ ] versions supportées ;
- [ ] délai indicatif de traitement ;
- [ ] consigne de ne pas publier une vulnérabilité immédiatement ;
- [ ] politique de correction ;
- [ ] historique des correctifs de sécurité.

---

## P3.11 — Vérifier les licences

- [ ] licence du code ;
- [ ] licence de la documentation ;
- [ ] licence des packs ;
- [ ] licence des images ;
- [ ] licence des vidéos ;
- [ ] droit d’utiliser les liens externes ;
- [ ] mentions des dépendances ;
- [ ] fichier `LICENSE` ;
- [ ] fichier `THIRD_PARTY_NOTICES` si nécessaire.

---

## P3.12 — Préparer une politique de confidentialité exacte

Même sans compte ni cloud :

- [ ] expliquer ce qui reste local ;
- [ ] expliquer les connexions réseau du site ;
- [ ] expliquer les ressources externes ;
- [ ] expliquer le diagnostic ;
- [ ] expliquer les sauvegardes non chiffrées ;
- [ ] expliquer le PIN ;
- [ ] préciser l’absence de télémétrie si c’est le cas ;
- [ ] préciser l’absence de vente ou transfert de données ;
- [ ] expliquer les responsabilités de l’utilisateur.

---

## P3.13 — Préparer la page publique

Elle doit répondre rapidement à :

- qu’est-ce que Movenso ;
- pour qui ;
- ce que l’application permet ;
- ce qu’elle ne fait pas ;
- où restent les données ;
- comment sauvegarder ;
- comment installer ;
- comment obtenir des packs ;
- comment contribuer ;
- comment signaler un problème ;
- quel est le statut de la version.

Éviter le mur technique et les promesses absolues.

---

# P4 — Finitions pour une v1 optimale

## P4.1 — Améliorer les états vides

Prévoir un état utile pour :

- favoris vides ;
- compositions vides ;
- relations vides ;
- corbeille vide ;
- « À traiter » vide ;
- aucune vidéo ;
- aucun résultat de recherche ;
- aucune discipline récente.

---

## P4.2 — Uniformiser les retours utilisateur

- [ ] mêmes conventions de toast ;
- [ ] mêmes couleurs de statut ;
- [ ] mêmes verbes ;
- [ ] mêmes confirmations ;
- [ ] mêmes actions Annuler/Confirmer ;
- [ ] distinction information/avertissement/erreur ;
- [ ] aucun message technique non traduit.

---

## P4.3 — Tester tous les thèmes et densités

- [ ] thème jour ;
- [ ] thème nuit ;
- [ ] thème automatique ;
- [ ] six tonalités ;
- [ ] toutes les densités ;
- [ ] petit écran ;
- [ ] tablette ;
- [ ] bureau ;
- [ ] orientation portrait ;
- [ ] orientation paysage.

---

## P4.4 — Vérifier les performances graphiques

- [ ] Mindmap avec peu de relations ;
- [ ] Mindmap dense ;
- [ ] Explorer avec long parcours ;
- [ ] recentrage rapide ;
- [ ] zoom ;
- [ ] déplacement tactile ;
- [ ] absence de fuite mémoire après plusieurs ouvertures.

---

## P4.5 — Ajouter un rapport après les opérations importantes

Après import, sauvegarde, restauration ou nettoyage :

- nombre d’éléments traités ;
- nombre d’éléments ignorés ;
- conflits ;
- doublons ;
- fichiers ajoutés ;
- fichiers manquants ;
- espace utilisé ;
- avertissements ;
- possibilité de copier ou exporter le rapport.

---

## P4.6 — Améliorer la stratégie de mise à jour PWA

- [ ] prévenir qu’une nouvelle version est disponible ;
- [ ] ne pas remplacer l’application pendant une écriture ;
- [ ] attendre la fin d’une séance ;
- [ ] permettre « Mettre à jour maintenant » ;
- [ ] permettre « Plus tard » ;
- [ ] sauvegarder avant une migration importante.

---

# Matrice minimale de recette v1

La v1 ne doit pas sortir avant validation de cette matrice.

## Plateformes

- [ ] Chrome Android récent ;
- [ ] Chrome Windows ;
- [ ] Edge Windows ;
- [ ] second navigateur Android ;
- [ ] téléphone bas ou milieu de gamme ;
- [ ] téléphone récent ;
- [ ] tablette ;
- [ ] écran bureau ;
- [ ] clavier seul ;
- [ ] TalkBack.

## Scénarios

- [ ] première ouverture ;
- [ ] redémarrage ;
- [ ] mode avion ;
- [ ] import de chaque pack ;
- [ ] mise à jour de chaque pack ;
- [ ] import corrompu ;
- [ ] import hostile ;
- [ ] capture vidéo ;
- [ ] vidéo longue ;
- [ ] quota dépassé ;
- [ ] fermeture pendant écriture ;
- [ ] ajout de note ;
- [ ] création de technique ;
- [ ] doublon exact ;
- [ ] doublon proche ;
- [ ] composition ;
- [ ] séance complète ;
- [ ] audio en arrière-plan ;
- [ ] relations ;
- [ ] fusion ;
- [ ] défusion ;
- [ ] suppression ;
- [ ] corbeille ;
- [ ] restauration ;
- [ ] export de technique ;
- [ ] export de pack ;
- [ ] inspection de confidentialité ;
- [ ] sauvegarde légère ;
- [ ] sauvegarde complète ;
- [ ] restauration complète ;
- [ ] PIN ;
- [ ] oubli du PIN ;
- [ ] diagnostic ;
- [ ] réinitialisation ;
- [ ] mise à jour de l’application.

---

# Critères de passage en v1.0

Movenso peut être déclaré v1 lorsque :

- [ ] tous les P0 sont fermés ;
- [ ] tous les P1 sont fermés ;
- [ ] aucun bug connu ne provoque de perte de données ;
- [ ] aucun bug connu ne divulgue des données privées ;
- [ ] import, sauvegarde et restauration ont été testés sur appareils réels ;
- [ ] la dernière RC a été utilisée plusieurs jours sans anomalie bloquante ;
- [ ] les promesses publiques correspondent exactement au produit ;
- [ ] les navigateurs supportés sont documentés ;
- [ ] le processus de support est prêt ;
- [ ] les licences sont vérifiées ;
- [ ] le build est reproductible ;
- [ ] la version publiée est exactement celle testée ;
- [ ] aucune nouvelle fonctionnalité n’a été ajoutée entre la dernière RC validée et la v1.

---

# Ordre d’exécution recommandé

## Lot 1 — Sécurité et intégrité

P0.1 à P0.7.

Objectif : démontrer qu’on peut importer, sauvegarder, restaurer et partager sans perte ni fuite.

## Lot 2 — Plateforme et promesses

P0.8 à P0.12.

Objectif : rendre le comportement web réellement prévisible et aligné avec le discours.

## Lot 3 — Fermeture des parcours

Tous les P1.

Objectif : supprimer les fonctions incomplètes, ambiguïtés et impasses UX.

## Lot 4 — Réduction de dette

P2.1 à P2.14.

Objectif : empêcher la couche applicative de devenir le point de rupture après la v1.

## Lot 5 — Recette communautaire fermée

- 5 à 15 testeurs ;
- profils techniques et non techniques ;
- plusieurs disciplines ;
- appareils variés ;
- utilisation réelle sur plusieurs jours.

## Lot 6 — Publication

P3, dernière RC, gel, puis v1 identique à la RC validée.

---

# Ce qu’il ne faut surtout pas ajouter avant la v1

- synchronisation cloud ;
- comptes utilisateurs ;
- marketplace intégrée ;
- nouvelles visualisations de relations ;
- nouveaux formats d’export ;
- éditeur de packs avancé ;
- collaboration ;
- statistiques de pratique ;
- recommandations automatiques ;
- IA embarquée ;
- nouvelles disciplines uniquement pour enrichir le catalogue ;
- restauration sélective complexe ;
- chiffrement complet des sauvegardes, sauf exigence impérative découverte pendant la recette.

La v1 ne sera pas optimale parce qu’elle contient tout.

> **Elle sera optimale si elle fait parfaitement ce qu’elle promet, ne perd aucune donnée, ne divulgue rien, se sauvegarde réellement et reste compréhensible par quelqu’un qui n’a pas participé à sa conception.**
