# Note de conception — modèle de données en couches (packs / perso / réglages)

> **Type : proposition (à valider)** · Rédigée le 2026-07-17 · Ne code rien tant
> qu'elle n'est pas validée. Cadre : passage à des **packs activables** (dont
> officiels), **illustrations avec licence/attribution** et **liens embed** —
> ce qui met sous tension le modèle actuel « un seul document ».

## 1. Où on en est (existant)

- **Un seul document racine** `Bibliotheque` persisté en OPFS
  (`src/domaine/modele.ts`), contenant toutes les collections :
  `disciplines`, `techniques`, `contributions`, `typesRelation`,
  `compositions`, `favoris`, `doublonsIgnores`, `corbeille`.
- **Déjà normalisé par identifiants** : `technique.disciplineId`,
  `contribution.techniqueId`, `relation.cibleId`, `media.id`… Les cibles
  absentes sont **tolérées** (jamais bloquantes) — propriété clé qu'on réutilisera.
- **Médias** : fichiers binaires en OPFS (dossier `videos/`), référencés par id ;
  registre dérivé (`src/domaine/medias.ts`).
- **Préférences** : document séparé (thème, mode avancé, densité, pseudo, PIN…),
  **jamais exporté**.
- **`.movpack`** : archive ZIP (manifeste + JSON + médias), unité d'échange.
- **Provenance** portée par `contribution.provenance` / `origine` : c'est
  aujourd'hui le SEUL séparateur entre « savoir de pack » et « savoir perso »,
  au sein du même document.

**Limite** : source (pack) et perso sont **mélangés** dans un même blob. Or les
besoins qui arrivent (activer/désactiver un pack, le mettre à jour, porter des
licences, ne jamais exporter le perso) demandent une **frontière nette**.

## 2. Principe directeur

Découper **par propriété et cycle de vie**, PAS « un JSON par table ». Trois
couches, fusionnées à l'exécution en la vue unifiée actuelle (l'utilisateur ne
voit pas la séparation) :

| Couche | Contenu | Cycle de vie | Exporté ? |
|---|---|---|---|
| **Source (pack)** | par pack installé : disciplines, techniques (identités), contributions de référence, **illustrations + licence/auteur/source**, **liens embed**, types de relation apportés | read-mostly ; **activable/désactivable** ; **remplaçable** par une MAJ de pack | oui (c'est l'unité de partage) |
| **Perso** | créations et éditions de l'utilisateur : techniques perso, notes/commentaires, favoris, **couvertures perso**, compositions, corbeille, amendements de fiches sourcées | mutable ; **jamais exporté** ; **survit** aux MAJ/désactivations de pack | non |
| **Réglages** | préférences d'appareil | mutable | non (déjà le cas) |

Un **registre médias/illustrations** transverse porte, par média : type
(local/lien/plateforme/**image**), `ref`/URL, et **licence + auteur + source**
(nouveau, requis pour CC BY-SA & co).

## 2bis. Deux rôles d'écriture : pratiquant (perso) vs éditeur (pack en édition)

Clarification (arbitrage humain, 2026-07-17) : « ce que crée l'utilisateur »
recouvre **deux rôles opposés**, à ne pas confondre — ils ont des sémantiques
d'export **contraires**.

- **Pratiquant → couche perso PRIVÉE.** Notes, favoris, captures, couvertures,
  **amendements privés** d'une fiche venue d'un pack. Posée *par-dessus* les
  packs. **Jamais publiée** (« le carnet ne part jamais »).
- **Éditeur / club → PACK EN ÉDITION.** Il crée la **source** d'un pack
  (techniques, illustrations licenciées, embed, descriptions) **destinée à être
  publiée/exportée**. Porte **auteur, version, licences**.

Le discriminant est **propriété + destination**, pas « qui tape » :

| | Perso (pratiquant) | Pack en édition (club) | Pack installé (autrui) |
|---|---|---|---|
| Éditable | oui (privé) | oui (le mien) | non (read-only) |
| Publié / exporté | **jamais** | **oui, c'est le but** | tel quel |
| Auteur / licence | non | **oui** | oui |

Un **« pack en édition »** = un pack dont l'auteur est **cet appareil/ce club**,
en état **modifiable et publiable**. L'éditer = éditer sa **source** directement.
Amender une fiche d'un pack installé (pratiquant) = **overlay privé**, jamais
publié — sauf **fork explicite** vers un pack en édition.

⚠️ Correctif de fond vs l'existant : aujourd'hui « créer une technique » tombe en
provenance `personnel`, que l'export **exclut** → un club verrait son travail
exclu de son propre pack. Le modèle cible doit router la création **selon le
rôle/la destination choisie**, pas selon un seul drapeau `provenance`.

## 3. Modèle cible (esquisse, à affiner)

```
état runtime (fusion)
├── reglages            (1 doc — préférences, comme aujourd'hui)
├── perso               (1 doc — couche utilisateur)
│    ├── techniques[]           (créées par l'utilisateur)
│    ├── contributions[]        (notes perso + amendements de fiches de pack)
│    ├── couvertures{}          (techniqueId → couverture perso)
│    ├── favoris[]
│    ├── compositions[]
│    ├── corbeille[]
│    └── doublonsIgnores[]
└── packs[]             (1 doc PAR pack installé + son état activé/désactivé)
     └── pack:
          ├── meta        (id, nom, version, auteur, note de diffusion)
          ├── disciplines[] / taxonomies
          ├── techniques[]              (identités de référence)
          ├── contributions[]           (savoir de référence)
          ├── illustrations[]           (image + LICENCE + auteur + source + embed)
          └── typesRelation[]
```

- **Références perso → pack** par id (ex. un favori pointe une technique de pack).
  Règle, cohérente avec l'existant : **une cible absente est tolérée** (pack
  désactivé → le favori devient inactif mais n'est pas perdu ; réactivation → il
  revit). Le nettoyage éventuel se fait comme la corbeille (au vidage explicite).
- La **vue unifiée** = packs actifs ⊕ perso, résolue par id (même logique que
  `relationsPourFiche` aujourd'hui).

## 4. Ce que ça débloque

1. **Packs activables à la carte** (judo Kodokan, yoga, boxe…) fournis dans
   l'app, allumés au choix — sans tout charger.
2. **Mise à jour d'un pack** sans écraser le perso (remplacer la couche source,
   garder la couche perso par-dessus).
3. **Licences/crédits propres** : chaque illustration porte licence/auteur/
   source ; un écran **Crédits** les agrège ; elles **voyagent avec le pack**.
4. **Export sûr par construction** : le perso est un fichier à part → jamais
   partagé par accident (garantit D-069/054 « le carnet ne part jamais »).
5. **Modèle « liste + illustration + embed »** (légalement sain, cf. discussion
   réglementation) devient la forme native d'un pack.

## 5. Coûts et risques (pourquoi c'est une décision, pas un patch)

- **Atomicité d'écriture** : plusieurs documents → écritures coordonnées. Le
  staging OPFS existant (écriture en `staging/` puis bascule) sert de base ;
  à généraliser aux docs JSON.
- **Intégrité référentielle inter-couches** : définir le comportement quand un
  pack est désactivé/mis à jour (favoris, compositions, relations, couvertures
  qui pointent dedans). Principe proposé : **tolérance + réconciliation**, jamais
  de perte silencieuse.
- **Migration** depuis le mono-document : lire l'ancien schéma, répartir en
  couches (le sourcé → un pack « importé historique » ; le `provenance:personnel`
  → couche perso), versionner (`versionSchema`).
- **`.movpack`** : devient « 1 pack = 1 couche source » (+ médias) ; l'export du
  perso reste interdit. À aligner sans casser l'ouverture des packs existants.
- **Pas de big-bang** : migrer **couche par couche**, en gardant la vue unifiée
  et `npm run verifier` vert à chaque étape.

## 6. Plan de migration incrémental (proposé)

1. **Extraire les réglages** — déjà fait (préférences séparées). ✅
2. **Introduire la couche perso** en lecture/écriture, le mono-doc restant la
   source ; router les mutations perso vers elle ; vue unifiée inchangée.
3. **Formaliser le format « pack »** (meta + illustrations licenciées + embed) ;
   convertir Kodokan/club en packs de ce format.
4. **Chargeur multi-pack** + activation/désactivation ; résolution unifiée par id.
5. **Adapter `.movpack`** (export = 1 pack source ; jamais le perso).
6. **Registre médias enrichi** (licence/auteur/source) + écran **Crédits**.
7. **Migration one-shot** de l'état existant + garde-fou de schéma (tests).

Chaque étape = une ou plusieurs boucles vertes, réversibles.

## 7. Décisions (arbitrage humain, 2026-07-17)

- **D-a — TRANCHÉE : (c) les deux de front.** Le modèle sert d'emblée les packs
  activables/MAJ **et** les licences/crédits.
- **D-b — TRANCHÉE : multidisciplinaire dès le début.** Le modèle vise le
  **catalogue multi-discipline** (judo, yoga, boxe…) activable à la carte, pas
  un judo mono-discipline qu'on généraliserait ensuite.
- **D-c — proposée (défaut retenu sauf objection) :** une référence perso vers un
  pack **désactivé** est **masquée mais conservée** (réactivation du pack → elle
  revit) ; nettoyage seulement explicite (comme la corbeille). Jamais de perte
  silencieuse.
- **D-d — proposée (défaut retenu sauf objection) :** l'**unité d'activation est
  le pack** ; un pack **peut porter plusieurs disciplines**, mais le **catalogue
  intégré démarre à un pack par discipline** (judo-kodokan, yoga, boxe…).

## 7bis. Idées / backlog de conception (à reprendre plus tard)

- **Rôle d'écriture — REPORTÉ.** Comment l'utilisateur exprime s'il écrit en
  « perso privé » ou en « pack en édition » : (1) rôle d'appareil, (2) choix de
  destination à chaque création, (3) espace « pack en édition » dédié. Instinct :
  (3) + overlay perso par-dessus, et un même appareil peut être les deux. **Non
  tranché — on y revient plus tard.**

- **Partager sa PROPRE vidéo (capture perso) — À TRAITER (relevé 2026-07-18).**
  Aujourd'hui le partage d'une fiche exclut **par construction** les
  contributions `personnel` (carnet + captures perso, D-067) : une vidéo qu'on a
  **filmée soi-même n'est jamais embarquée** dans le `.movpack`. Tension réelle :
  un **élève qui se filme veut l'envoyer à son sensei** (cas légitime) ; mais
  **protéger l'utilisateur lambda** d'une diffusion involontaire de son contenu
  privé est **aussi légitime** (c'est le sens de l'exclusion actuelle). Ni l'un
  ni l'autre ne doit être sacrifié → il faut un **choix explicite**, pas un
  défaut qui tranche à la place de l'utilisateur.
  - **Piste candidate (à valider) :** la **feuille de pré-partage (D-092)** est
    l'endroit naturel : y ajouter un **opt-in explicite « Inclure aussi ma vidéo
    perso (filmée) »**, **décoché par défaut** (protège le lambda), mais
    disponible (débloque élève → sensei). Ça garde le défaut sûr tout en rendant
    le cas légitime faisable, sans changer le modèle. À creuser : la feuille doit
    alors s'ouvrir aussi quand il n'y a QUE des vidéos perso (aujourd'hui elle ne
    s'ouvre que pour les vidéos partageables) ; et l'exclusion des **notes/carnet**
    reste, elle, non négociable.
  - **Non tranché — à décider avant ou après la beta selon priorité.**

- **Fusion « multi-sources » réversible (proposition U — relevé 2026-07-19).**
  Au lieu de fusionner deux quasi-doublons en un seul enregistrement (voie H
  retenue pour la beta : combine + défusion), **garder les deux fiches** et les
  **présenter côte à côte** sur une vue fusionnée : « description (Kodokan) » ET
  « description (Club) », idem points clés, médias… avec une **icône dé-fusion**.
  Esprit « 2 voix » de la V2. **C'est une fonctionnalité de modèle** : réintroduit
  la fiche composite multi-sources (retirée en D-069) et la réunion d'identités
  (retirée en D-067) → il faut un **lien de fusion persistant** + dédup partout
  (bibliothèque = une carte, recherche, filtres, favoris, compositions, relations,
  export/pack) + gestion des **groupes N>2**. → **À faire avec le modèle en
  couches** (c'est un de ses cas d'usage phares), pas avant.

- **Actions groupées (curation) — À EXPLORER (relevé 2026-07-18, vues 15/16).**
  Pour les gros corpus : sélectionner plusieurs techniques et **classer en lot**
  (catégorie, niveau), **ajouter à un pack / une composition**, supprimer/restaurer,
  rattacher un auteur ; et côté export, **recherche + sélection par catégorie**
  dans le choix des techniques (aujourd'hui : cases une à une). Vraie feature de
  curation avancée → **hors périmètre beta.**

- **Modèles de compositions — À EXPLORER (relevé 2026-07-18, vue 10 analyse).**
  Au-delà des exemples textuels déjà présents (placeholder « Ma spéciale, Kata
  libre, Séance du mardi… », état vide, devise), proposer au premier usage des
  **modèles cliquables qui pré-remplissent des blocs** : p. ex. « Enchaînement »,
  « Passage de grade », « Séance » → créent une composition avec quelques blocs
  types (technique, consigne, durée…) à compléter. Vraie petite feature (pas un
  simple libellé) → **hors périmètre beta, à reprendre plus tard.**

- **Média/fiche porté par une RELATION (à explorer).** Cas : une vidéo qui montre
  l'*interaction* entre deux techniques (ex. « O-goshi contré par O-goshi », ou
  une combinaison A→B). Elle ne « appartient » pas vraiment à une seule fiche.
  Aujourd'hui une relation est une **arête pure** (`{type, cibleId}`, sens unique,
  inverse dérivé, sans charge utile). Options :
  1. **Statu quo** — on attache la vidéo à la technique principale ; simple, mais
     l'objet réel (la *paire* A×B) n'est pas de première classe, et la vidéo ne
     remonte pas naturellement côté B.
  2. **Charge utile sur la relation** — la relation gagne un id + média/texte
     optionnels ; la vidéo « A contre B » vit sur l'arête, visible des deux côtés
     (inverse dérivé). Coût : les relations deviennent des objets (fin du modèle
     valeur-seule dédupliqué) — vrai changement de modèle.
  3. **Relation promue en fiche** — certaines relations (combinaison, contre,
     enchaînement) méritent leur **propre fiche** (illustration, description,
     média, liens vers les deux techniques). La plus riche.
  - **Piste à creuser en priorité** : Movenso a **déjà** les **compositions**
    (séquences de blocs technique + blocs média propres). Une combinaison/contre
    illustré ressemble beaucoup à une **composition à 2 blocs avec son média** —
    donc l'option (3) pourrait se faire **sans nouvel objet**, en réutilisant les
    compositions (ou une « liaison illustrée » légère). À arbitrer plus tard.

  - **Direction retenue (arbitrage humain, 2026-07-17 — à implémenter plus tard) :
    option 3 + option 2 combinées.** Un **« enchaînement »** est une **fiche
    dédiée** (comme une technique) portant **sa propre vidéo/illustration** et
    reliée à ses techniques constituantes. Concrètement :
    - **Bibliothèque** : une **section « Enchaînements »** (filtre/catégorie) où
      ces fiches apparaissent.
    - **Module relations** : l'enchaînement est visible via la relation ; depuis
      la fiche **O-goshi**, on **navigue vers la fiche « O-goshi contré par
      O-goshi »** (et retour).
    - **En plus (option 2)** : la même vidéo est **rattachée à O-goshi en vidéo
      secondaire** → on la voit aussi directement depuis O-goshi, sans l'enterrer.
    - **À trancher à l'implémentation** : l'« enchaînement » = une **Technique
      marquée `type: enchainement`** (référencée par relations, filtrable en
      section) **ou** une **Composition** promue en fiche de bibliothèque. La
      vidéo partagée = **un même média référencé** par l'enchaînement ET par
      O-goshi (le modèle tolère déjà le multi-référencement d'un média).

- **Outillage de test — passer les asserts e2e en attente-de-condition (relevé
  2026-07-19, suite D-103).** L'échelle des temporisations (D-103) neutralise le
  flake *pratique* mais l'*élargit* au lieu de le *supprimer*. Fix durable :
  remplacer le motif « `waitForTimeout(N)` puis `assert` mono-coup » par une
  assertion qui **attend que la condition tienne** (poll, budget ~4 s). Gains :
  supprime la course (robustesse absolue, pas statistique), **suite plus rapide**
  sur machine saine (rend la main dès que vrai, au lieu de dormir la durée
  pleine), immunise contre la faille théorique de D-103 (la calibration mesure le
  démarrage, pas un pic de charge en milieu de parcours).
  - **⚠️ Piège identifié (pourquoi PAS de big-bang) :** sur les 89 sites, **40
    sont positifs** (« devient actif », « apparaît ») → poll propre ; **49 sont
    négatifs** (« count === 0 », « se ferme », « ne crée rien »). Un poll
    « rejoue jusqu'à vrai » sur une **négative passe à t=0**, avant que l'effet de
    bord (buggé) ait eu le temps de se produire → l'assertion devient un
    **quasi-no-op qui passe toujours**, et **un run vert ne le détecte pas**
    (perte de couverture silencieuse). Les négatives doivent **garder un settle**
    (ou asserter la *stabilité sur une fenêtre*), jamais un poll first-pass-wins.
  - **Stratégie retenue :** **incrémental + opportuniste** — convertir les asserts
    d'un scénario quand on le retouche déjà, la dette fond sans boucle dédiée.
    **Amorce sans risque possible :** solder d'un coup **les 40 positives**
    (conversion propre, zéro piège) et **laisser les 49 négatives sous l'échelle
    D-103** (déjà protégées) → capte ~45 % de la dette à risque nul. Pas d'urgence
    tant que l'échelle tient.

- **Authenticité des packs (≠ intégrité) — À PRÉVOIR si téléchargement de packs
  TIERS (relevé porteur 2026-07-24).** Le `.movpack` porte un **SHA-256** par
  fichier + un manifeste : cela garantit la **cohérence technique** (le contenu
  n'a pas été altéré/corrompu en transit, cf. lot 8B) — **PAS l'authenticité**.
  Quiconque modifie un pack peut **recalculer les empreintes et reconstruire le
  manifeste** : rien ne prouve *qui* l'a produit. Il manque, dans l'ordre : (1)
  une **signature numérique** du pack (clé privée de l'auteur), (2) un
  **certificat/identité d'auteur** vérifiable, (3) une **chaîne de confiance**
  (autorité ou réseau de confiance). **Sans incidence tant que l'utilisateur
  n'importe que SES propres packs ou ceux reçus en main propre** (le cas bêta
  actuel). **Devient un vrai sujet le jour où Movenso propose de TÉLÉCHARGER des
  packs de tiers** (place de marché, dépôt communautaire) : à traiter AVANT
  d'ouvrir ce canal, jamais après. Piste : signature détachée type minisign/PGP
  dans le manifeste + affichage « auteur vérifié / non vérifié » à l'import.
  **Hors bêta ; pré-requis de toute distribution ouverte.**

- **Ouverture directe d'un `.movpack` par Android (intent) — MANQUE IMPORTANT
  (relevé porteur 2026-07-24).** Aucune **association Android** n'est déclarée :
  ni `ACTION_VIEW`, ni l'extension `.movpack`, ni un **type MIME** Movenso, ni la
  **réception d'un fichier partagé** (`ACTION_SEND` / intent-filter). Conséquence :
  recevoir un pack dans WhatsApp, Drive, Gmail ou le gestionnaire de fichiers **ne
  permet pas** de toucher le fichier et de choisir « Ouvrir avec Movenso ».
  Parcours actuel, lourd : **enregistrer le fichier → ouvrir Movenso → Importer →
  sélectionner le fichier**. Pour une app **fondée sur le partage de packs**,
  c'est un frein réel à l'adoption. À faire : déclarer un `intent-filter` dans le
  `AndroidManifest` (extension + MIME `application/movpack` ou `application/zip`
  + `BROWSABLE`), gérer l'intent entrant (Capacitor `App.getLaunchUrl` / plugin
  `SendIntent`) → router vers le flux d'import existant (D-114, déjà en flux).
  **Web/PWA : équivalent `launch_queue` / File Handling API à évaluer.** Chantier
  natif ciblé, à planifier tôt dans la diffusion.

- **Sauvegarde COMPLÈTE non chiffrée — À TRANCHER (relevé porteur 2026-07-24).**
  Une sauvegarde `.movpack` **complète** (portée `complet`, D-114) contient
  **notes personnelles + favoris + bibliothèque + vidéos**. Elle est protégée
  **contre la corruption** (SHA-256, lot 8B) mais **pas contre la lecture** :
  c'est un ZIP + JSON lisibles tels quels. Une sauvegarde envoyée au mauvais
  destinataire est **exploitable directement** (le carnet perso, exclu du
  partage/pack de discipline, se retrouve ici en clair car une sauvegarde EST
  tout l'appareil). Deux réponses possibles, non exclusives : (1) **sauvegarde
  chiffrée par mot de passe** (dérivation type PBKDF2/scrypt + AES-GCM sur le
  contenu du conteneur ; le mot de passe n'est jamais stocké — perte = sauvegarde
  illisible, à dire clairement) ; (2) à défaut/immédiatement, un **avertissement
  très explicite avant l'export complet** (« cette sauvegarde contient ton carnet
  et tes vidéos EN CLAIR — ne la partage qu'avec toi-même / un appareil de
  confiance »). **Option (2) = quasi gratuite, envisageable dès la bêta ; option
  (1) = chantier crypto, hors bêta.** À décider.

> **Note transverse (relevé porteur 2026-07-24) : le projet `android/` n'est PAS
> dans le dépôt — il est gitignoré et RÉGÉNÉRÉ à chaque build** (`npx cap add
> android` + `cap sync`, cf. `.github/workflows/apk.yml`). Donc `allowBackup`,
> le `FileProvider` et l'`AndroidManifest` viennent des **défauts Capacitor**.
> Pour les durcir de façon PÉRENNE, deux voies : (a) une **étape de patch** dans
> `apk.yml` après `cap add` (déposer un `AndroidManifest`/`file_paths.xml`
> personnalisé, comme on copie déjà `branding/android-res/*`), ou (b) **committer
> un `android/` persistant** (plus lourd à maintenir). (a) est cohérent avec
> l'existant.

- **`allowBackup="true"` (défaut Android) — À TRANCHER VOLONTAIREMENT (relevé
  porteur 2026-07-24).** Le manifeste hérite de `android:allowBackup="true"` :
  Android peut alors sauvegarder les données de l'app (dont l'OPFS) via ses
  mécanismes système (Auto Backup / adb backup) vers le cloud de l'utilisateur.
  Pour un produit présenté comme **local et privé**, ce comportement **ne doit
  pas dépendre du défaut du framework** — il doit être un **choix explicite**
  (activé = confort de restauration multi-appareils ; désactivé = les données ne
  quittent l'appareil que par les sauvegardes `.movpack` maîtrisées). À décider,
  puis fixer via le patch manifeste (voir note transverse). Interaction : si
  activé, cohérence à penser avec le PIN et la non-exportation des réglages de
  sécurité (§21 / lot 7).

- **`FileProvider` trop large — À RÉDUIRE (relevé porteur 2026-07-24).** Le
  partage natif passe par un `FileProvider` **non exporté** (bien), mais sa
  config (défaut Capacitor) déclare des racines très larges : `external-path
  path="."` et `cache-path path="."` (toute la racine du stockage externe / du
  cache). Les URI ne sont accordées que **temporairement** (par intent, pas une
  exposition permanente) — donc **pas de faille directe** — mais le principe de
  moindre privilège commande de **restreindre** au strict nécessaire : le
  **répertoire d'export Movenso** et le **cache des fichiers partagés** seulement.
  À corriger via un `file_paths.xml` personnalisé (patch, voir note transverse).

- **Limites défensives sur les archives importées — À AJOUTER pour packs TIERS
  (relevé porteur 2026-07-24).** L'import contrôle l'**espace disque** et traite
  en **flux** (D-114, `lireMovpackFlux`) — bon socle. Mais **pas de plafonds
  stricts et centralisés** sur : (1) le **nombre d'entrées** du ZIP, (2) la
  **taille du manifeste**, (3) la **taille du `bibliotheque.json`**, (4) la
  **taille décompressée totale**, (5) le **ratio de compression** (garde
  anti-« zip bomb »), (6) la **durée max de traitement**. Faible risque pour SES
  propres packs ; mais un pack **tiers volontairement pathologique** (zip bomb,
  JSON géant) pourrait **monopoliser stockage ou CPU** avant même les gardes
  actuelles. À faire **en même temps que l'ouverture aux packs tiers** (cf. note
  authenticité) : des bornes dures et nommées dans `lireMovpackFlux` (rejet franc
  au dépassement, message clair), testées par des fixtures pathologiques.
  **Hors bêta ; pré-requis de toute distribution ouverte.**

- **Vidéos stockées TELLES QUELLES — stratégie de compatibilité à définir
  (relevé porteur 2026-07-24).** L'ingestion (D-111, `ingestion.ts`) lit les
  métadonnées, calcule l'empreinte et déduplique, mais **ne transcode ni ne
  normalise jamais** : une vidéo de téléphone est gardée avec son **codec**, sa
  **résolution**, son **débit** et sa **taille** d'origine. Conséquences : (1)
  **plusieurs centaines de Mo pour quelques minutes** ; (2) **comportement
  dépendant des codecs supportés par la WebView** — une vidéo lisible sur un
  téléphone peut être **illisible sur un autre** (ex. HEVC/H.265, HDR, conteneurs
  exotiques) ; (3) **remplissage rapide du stockage**. Le **plafond configurable**
  (garde d'espace) est utile mais **ne remplace pas** une stratégie de
  compatibilité. Pistes (hors bêta, chantier lourd) : transcodage à l'ingestion
  (H.264/AAC en MP4, cap résolution/débit) — coûteux en natif WebView, à évaluer
  (MediaCodec natif via plugin plutôt que WASM) ; a minima, **détecter à la
  lecture** un média non décodable et l'afficher clairement (au lieu d'un lecteur
  muet), et **avertir à l'ajout** d'une vidéo très lourde / d'un codec à risque.
  **À décider : normalisation vs. simple garde + message.** Impacte export/partage
  (poids des `.movpack`) autant que le stockage local.

- **« Reprendre » codé mais NON BRANCHÉ à l'UI livrée — écart produit (relevé
  porteur 2026-07-24).** Le fil « Reprendre » (savoir personnel récent, le plus
  récent d'abord) existe en code — `filPersonnel()`, `masquerReprise()`,
  `repriseMasquees`, `pratiqueDeplie.reprendre`, `carteCapture()` — mais **aucun
  de ces points n'a de caller dans un gabarit monté** (vérifié : `filPersonnel()`
  et `carteCapture()` ne sont appelés nulle part ; `pratiqueDeplie.reprendre`
  n'est jamais lu). La promesse **« j'ouvre Movenso et je retrouve immédiatement
  ce que je dois reprendre »** n'est donc **pas matérialisée**. Aujourd'hui le
  besoin est éparpillé : notes perso dans les fiches, captures non rattachées
  dans « À traiter », favoris, compositions — pas incohérent, mais pas *la* vue
  de reprise. **Décision à prendre** : (a) **brancher** un écran/section
  « Reprendre » orienté pratique (voir ci-dessous), ou (b) **retirer le
  scaffolding mort** si l'idée est abandonnée. Ne pas laisser en l'état (code
  vivant non atteignable).

- **« À traiter » est une vue de MAINTENANCE, pas un « Reprendre » de PRATIQUE
  (relevé porteur 2026-07-24).** « À traiter » regroupe bien captures non
  rattachées / techniques sans vidéo / sans classification / médias manquants /
  fichiers orphelins — utile, mais **administratif**. Un « Reprendre » orienté
  pratique répondrait plutôt à : *ce que j'ai capturé récemment*, *ce que je dois
  retravailler*, *ce que j'ai commencé*, *mes dernières techniques*, *ma prochaine
  séance*. Les deux sont complémentaires, pas substituables. À cadrer avec la
  décision « Reprendre » ci-dessus (le socle `filPersonnel()` est déjà là).

- **Compositions : le MODÈLE est plus riche que l'INTERFACE (relevé porteur
  2026-07-24).** Le moteur sait représenter **objectifs, transitions, consignes,
  repères** (types de bloc + `consigne`), mais l'utilisateur construit surtout
  **une technique / une étape libre / une pause / une durée**. Module fonctionnel,
  mais **potentiel pédagogique pas encore exposé**. Backlog UX : rendre saisissables
  les intentions riches (ex. « objectif de séance », « repère » qualifié) sans
  ré-alourdir l'entonnoir simplifié (D-126) — équilibre à trouver.

> **Résiduel V2/V3 nettoyé (2026-07-24) :** le toast d'import d'un export complet
> sur base non vierge disait « … (Atelier → Publier) » — parcours disparu.
> Corrigé en « … (Plus › Créer ou exporter un pack) ». Le mot « Atelier » ne
> subsiste plus que dans des **commentaires** et des **noms de méthodes internes**
> (`#rafraichirAtelier`), jamais dans l'UI. Rappel confirmé : l'ancien mode de
> démarrage `accueil` migre vers `bibliotheque` (V3 = **library-first**, pas de
> page d'accueil — cohérent D-017 « jamais d'onboarding »).

- **Finition « sentiment d'app terminée » — lot de clôture bêta (relevé porteur
  2026-07-24).** Manquent les éléments de finition qui signalent un produit
  abouti. Classés par coût :
  - **Quasi gratuits (à faire dans la boucle de clôture)** :
    - **Écran « À propos »** + **version visible** (dérivée de `package.json`,
      aujourd'hui `3.0.0-dev` ; y afficher aussi la nature debug/éphémère de
      l'APK, cf. D-113) — une entrée dans Plus.
    - **Emplacement des exports plus visible** : après un export/enregistrement
      local, dire *où* le fichier a été écrit (dossier), pas seulement « exporté ✓ ».
    - **Distinction PARTAGE PUBLIC vs SAUVEGARDE PRIVÉE** rendue explicite dans
      l'UI (rejoint « sauvegarde non chiffrée » : un pack de partage exclut le
      perso, une sauvegarde complète contient TOUT en clair — le dire).
    - **Retour utilisateur après opérations longues** : import / restauration /
      export de gros médias — indicateur de progression ou état « en cours… »
      (aujourd'hui surtout un toast final ; un long import peut sembler figé).
  - **Aide / prise en main (plus délicat)** :
    - **Aide rapide** + **explication sauvegarde/restauration** : accessibles à la
      demande (dans Plus / « À propos »), pas imposées.
    - **Première prise en main** : ⚠️ **tension avec D-017 « jamais d'onboarding »**
      (déjà relevée ci-dessus, item « premier lancement »). À trancher : tunnel de
      bienvenue (revirement assumé) vs. aides découvrables in-context. **Maquette
      avant de coder.**

## 8. Suite

Décisions gâchettes acquises (D-a, D-b). Mise en œuvre par boucles vertes, sans
big-bang, en gardant la vue unifiée :

- **Étape 2 (prochaine) — couche perso.** Introduire la couche perso en
  lecture/écriture ; router les mutations perso (notes, favoris, couvertures,
  compositions, corbeille, techniques créées) vers elle ; le mono-document reste
  la source pour l'instant ; la vue unifiée et tous les tests restent identiques
  et verts. Aucune rupture d'usage.

Feu vert attendu pour ouvrir l'étape 2.

- **Onboarding + packs préchargés / communautaires — À REPRENDRE (relevé 2026-07-18).**
  Piste de distribution : livrer l'app avec des **packs préchargés activables ou
  non** par l'utilisateur (dispo dans Plus). L'**onboarding** (à terme) pourrait
  proposer d'**activer les packs par défaut** (x, y, z) et/ou d'**importer un pack
  communautaire fourni**, plus le **choix du pseudo**, la **limite d'espace** (D-097,
  avec précision), et **demain l'activation des fonctions bêta**. ⚠️ Tension à
  trancher : Movenso a un principe « **jamais d'onboarding** » (D-017) — un tunnel
  de bienvenue est un revirement à assumer (option B) vs réglages découvrables
  dans Plus (option A). **On en reparle** (maquette avant de coder).
