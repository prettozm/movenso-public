# Proposition O4 — enrichissement du maillage (S3.D3, D-198)

> **Type : APPLIQUÉ le 2026-08-03 (D-210)** — validé tel quel par le porteur ;
> conservé comme trace de la campagne. Était : Chaque ligne est une
> arête candidate `source → cible [type] « raison »`. Tu barres/corriges ce que
> tu veux ; j'applique ensuite dans `donnees/kodokan.json` / `club-judo.json`
> (retrait des lignes barrées, tes formulations reprises telles quelles), puis
> réimport vérifié par l'e2e. Les raisons sont OBLIGATOIRES sur
> `enchaine`/`contre`/`a_ne_pas_confondre` (c'est elles que le parcours et le
> face-à-face affichent) ; facultatives sur `similaire`.
>
> État mesuré : kodokan 2,5 arêtes/technique (57/111 avec `enchaine`,
> 5 « à ne pas confondre », 10 `contre`) ; club 0,9/technique, 24/49 sans lien.

## A. Kodokan — contres classiques (kaeshi-waza) `[contre]`

Les *gaeshi* à degré 1 portent déjà leur lien vers la technique contrée —
celles-ci MANQUENT :

1. Tsubame-gaeshi → De-ashi-harai « Le contre du balayage : esquive du pied attaqué puis contre-balayage immédiat dans le même tempo. »
2. Uchi-mata-sukashi → Uchi-mata « Esquive pure : le pivot d'uke passe dans le vide, aucune force opposée — timing seul. »
3. Ushiro-goshi → Hane-goshi « Contre des attaques de hanche : absorber la rotation en soulevant uke par l'arrière. »
4. Utsuri-goshi → Harai-goshi « Contre de hanche : reprise du contrôle par changement de hanche avant la projection. »
5. Ura-nage → Seoi-nage « Contre des entrées en rotation : ceinturer et projeter en arrière par-dessus l'épaule. »
6. Tani-otoshi → Ippon-seoi-nage « Contre d'une entrée manquée : bloquer la hanche et chuter en barrage derrière les jambes. »
7. Yoko-guruma → Harai-goshi « Contre en sacrifice latéral quand la hanche d'uke est déjà engagée. »
8. Sumi-otoshi → Kuchiki-taoshi « Contre en déséquilibre pur sur une saisie de jambe trop franche. »

## B. Kodokan — enchaînements classiques (renraku-waza) `[enchaine]`

9. Kata-guruma → Kuchiki-taoshi « Si uke se redresse pour bloquer le chargement, repli immédiat sur la saisie de jambe. »
10. Sukui-nage → Ura-nage « Même famille de ceinturage : si la cuillère échoue de face, bascule arrière en sacrifice. »
11. Uki-otoshi → Sumi-otoshi « Deux déséquilibres purs : si uke résiste vers l'avant, renversement dans l'angle arrière. »
12. Morote-gari → Kuchiki-taoshi « Si uke dégage une jambe de la saisie double, terminer sur la jambe restante. »
13. Kibisu-gaeshi → Kuchiki-taoshi « Le talon accroché appelle la poussée sur le torse ; même chaîne de saisies de jambe. »
14. O-guruma → Ashi-guruma « Si le point de rotation glisse trop bas, transfert direct sur la jambe tendue. »
15. Harai-goshi → Harai-makikomi « Si uke bloque le fauchage en résistant au corps à corps, enrouler en makikomi. »
16. Uchi-mata → Uchi-mata-makikomi « Blocage de la saisie classique → enroulement en abandonnant la manche. »
17. Hane-goshi → Hane-makikomi « Même mécanique : le blocage du sursaut appelle l'enroulement sacrifié. »
18. Soto-makikomi → O-soto-makikomi « Chaîne des enroulements extérieurs selon la jambe disponible. »
19. Ko-uchi-gari → Ko-uchi-makikomi « Si le petit fauchage intérieur cale, l'enroulement force la chute. »
20. Tomoe-nage → Sumi-gaeshi « Si uke plie les genoux sur l'entrée sacrifiée, transfert sur le crochet intérieur. »
21. Sumi-gaeshi → Hikikomi-gaeshi « Même famille de sacrifices avant : selon la saisie (ceinture → hikikomi). »
22. Yoko-otoshi → Tani-otoshi « Sacrifices latéraux : si uke recule du côté attaqué, barrage arrière. »
23. Uki-waza → Yoko-wakare « Sacrifices avant-latéraux : le corps s'ouvre plus franchement si uke charge. »
24. Ushiro-goshi → Ura-nage « Après le soulevé de contre, terminer en projection arrière si uke se cambre. »

## C. Kodokan — à ne pas confondre `[a_ne_pas_confondre]` (5 → 15)

25. Uki-goshi ↔ O-goshi « Uki-goshi projette par la demi-hanche SANS charger ; O-goshi engage la hanche entière sous le centre d'uke. »
26. Harai-goshi ↔ Uchi-mata « Le fauchage passe à l'EXTÉRIEUR de la cuisse pour Harai-goshi, à l'INTÉRIEUR pour Uchi-mata. »
27. Hane-goshi ↔ Uchi-mata « La jambe fléchie de Hane-goshi SOULÈVE les deux jambes ; Uchi-mata fauche une seule cuisse intérieure. »
28. O-guruma ↔ Ashi-guruma « Même roue autour d'une jambe tendue : au niveau de l'abdomen pour O-guruma, du genou pour Ashi-guruma. »
29. De-ashi-harai ↔ Okuri-ashi-harai « Un seul pied balayé au posé (De-ashi) contre les DEUX pieds réunis en déplacement latéral (Okuri). »
30. Tai-otoshi ↔ Seoi-otoshi « Corps ouvert et jambe en barrage pour Tai-otoshi ; dos chargé genou(x) au sol pour Seoi-otoshi. »
31. Seoi-nage ↔ Ippon-seoi-nage « Deux mains à la manche/revers contre UN bras passé sous l'aisselle. »
32. Tomoe-nage ↔ Sumi-gaeshi « Pied au ventre et rotation complète contre crochet du mollet et renversement dans l'angle. »
33. Uki-waza ↔ Yoko-otoshi « Le corps de tori s'étend DEVANT uke (Uki-waza) ou reste À CÔTÉ en barrage (Yoko-otoshi). »
34. Kata-guruma ↔ Sukui-nage « Chargement sur les épaules contre cuillère par ceinturage des cuisses — aucune épaule engagée. »

## D. Kodokan — liaison debout-sol `[enchaine]` (nouvelle capacité de parcours)

Aujourd'hui AUCUNE arête ne relie projection et contrôle au sol — Explorer ne
peut jamais y descendre. Huit liaisons pédagogiques classiques :

35. O-soto-gari → Kesa-gatame « La chute arrière laisse le bras dans la saisie : contrôle en écharpe immédiat. »
36. Harai-goshi → Yoko-shiho-gatame « La rotation amène tori perpendiculaire à uke : contrôle latéral naturel. »
37. Tai-otoshi → Kesa-gatame « La manche reste en main : suivre au sol en écharpe. »
38. Tomoe-nage → Tate-shiho-gatame « La rotation complète amène naturellement tori à cheval. »
39. Uchi-mata → Kuzure-kesa-gatame « La tête engagée à la retombée appelle l'écharpe modifiée. »
40. Sumi-gaeshi → Kami-shiho-gatame « Le roulé au-dessus de la tête place tori côté nord. »
41. Seoi-nage → Kata-gatame « Le bras chargé se contrôle contre la tête à l'arrivée au sol. »
42. Tani-otoshi → Yoko-shiho-gatame « La chute en barrage laisse tori déjà collé au flanc d'uke. »

## E. Club judo — raccrocher les 24 sans lien (types du pack : similaire/enchaine/prepare)

43. Chute Arrière → prepare → De Ashi Barai « Savoir tomber en arrière AVANT de subir le balayage. »
44. Chute Arrière → prepare → O Soto Gari « La grande faucheuse arrière exige l'ukemi arrière maîtrisé. »
45. Chute Avant Gauche → similaire → Chute Avant Droite « Même ukemi, côté opposé — travailler les deux. »
46. Morote Seoi Nage → similaire → Ippon Seoi Nage « Deux saisies au revers contre un bras passé dessous — même projection d'épaule. »
47. Tsuri Komi Goshi → similaire → O Goshi « Hanche engagée identique ; la saisie pêche-soulève remplace le ceinturage. »
48. Uki Goshi → prepare → O Goshi « La demi-hanche enseigne le placement avant la hanche complète. »
49. Sasae Tsuri Komi Ashi → similaire → Hiza Guruma « Blocage de cheville contre blocage de genou — le kuzushi est le même. »
50. Yoko Tomoe Nage → similaire → Tomoe Nage « Même sacrifice, la rotation part sur le côté au lieu de l'axe. »
51. Uki Waza → similaire → Yoko Tomoe Nage « Sacrifices latéraux voisins du programme marron. »
52. Kuzure Gesa Gatame → similaire → Hon Gesa Gatame « L'écharpe modifiée : le bras passe sous l'aisselle au lieu du cou. »
53. Ushiro Gesa Gatame → similaire → Hon Gesa Gatame « L'écharpe inversée : contrôle dos à la tête d'uke. »
54. Gyaku Juji Jime → similaire → Nami Juji Jime « Croisé de mains inversé : paumes vers soi contre paumes vers uke. »
55. Kata Juji Jime → similaire → Nami Juji Jime « Croisé mixte : une paume dessus, une dessous. »
56. Okuri Eri Jime → similaire → Hadaka Jime « Étranglements arrière : avec le revers contre à mains nues. »
57. Kata Ha Jime → similaire → Okuri Eri Jime « Même base arrière, l'épaule bloquée en plus. »
58. Sode Guruma Jime → similaire → Kata Juji Jime « Étranglement en croix avec l'avant-bras/manche en travers. »
59. Juji Gatame → similaire → Ude Gatame « Clés sur le coude tendu : en croix au sol contre debout-appuyé. »
60. Hiza Gatame → similaire → Juji Gatame « La clé au genou reproduit l'hyperextension du coude, jambe en levier. »
61. Hara Gatame → similaire → Waki Gatame « Levier du coude sur le ventre contre sous l'aisselle. »
62. Waki Gatame → similaire → Ude Gatame « Contrôles du bras tendu : l'aisselle enferme ce que la main appuie. »
63. Ashi Gatame Jime → similaire → Juji Gatame « Le contrôle en croix se conclut jambe sur le cou — frontière clé/étranglement. »
64. Clef de catcheur → similaire → Ude Garami « C'est le même garami (bras enroulé), nom d'atelier. »
65. Retournement Uke à plat ventre → enchaine → Juji Gatame « Le retournement classique se termine en croix sur le bras exposé. »
66. Retournement coude + genou → similaire → Retournement coude à 2 mains « Même famille : provoquer la bascule par le coude. »
67. Nage no Kata — 2e groupe → similaire → Nage no Kata — 1er groupe « La suite du même kata (koshi/ashi-waza après te-waza). »
68. Kata Juji Jime → enchaine → Tate Shiho Gatame « L'étranglement en croix se pose naturellement depuis le contrôle à cheval — et inversement. »

## Questions ouvertes (à trancher à la relecture)

- **Q1 — katas kodokan isolés** (Ju-no-Kata, Itsutsu, Koshiki, Kodomo) : les
  relier entre eux et à Nage-no-kata par `similaire` « famille des formes », ou
  ASSUMER leur isolement (le dé et la recherche y mènent déjà) ?
- **Q2 — interdites** (Kani-basami, Kawazu-gake) : une arête `a_ne_pas_confondre`
  vers leur voisine légale (Kani-basami ↔ Yoko-otoshi ; Kawazu-gake ↔
  Ko-soto-gake) avec la raison « interdite en compétition (blessure) — à
  connaître pour ne pas la subir » ? Ou isolement assumé ?
- **Q3 — liaison debout-sol (section D)** : ce type de parcours te va-t-il ?
  C'est la nouveauté la plus structurante (Explorer descendra au sol).
- **Q4 — pack club** : il n'a NI `contre` NI `a_ne_pas_confondre` dans ses types.
  En rester aux 3 types existants (proposé ici), ou enrichir ses types ?
