# Plan — livraison d'une beta grand public

> **Objectif présent (arbitrage humain, 2026-07-17) :** figer la branche
> `feat/v3-ajustements` et **sortir une vraie application pour un beta test
> général**. La refonte du modèle de données (couches packs/perso, catalogue
> multidiscipline, enchaînements) est **reportée après la beta** — elle vit dans
> `note-modele-donnees.md`.

## Périmètre de la beta (ce qui entre)

1. **Relations** — désactivées par défaut, en **bêta** (option « Vue relation
   (bêta) »). Fait (D-084 / D-086). ✅
2. **Nettoyage cosmétique** — dernière passe de finition. *Liste précise à
   arrêter avec Yahya* (cf. questions ouvertes).
3. **Packs** — **fusion Kodokan + Judo** en un pack cohérent. → **Yahya**
   (contenu).
4. **Miniatures / illustrations** — par défaut on affiche une **illustration
   (image)**, pas la miniature de la vidéo. Illustrations **à créer** (Yahya :
   ~2 membres du club produisent des essais, puis passage dans un modèle pour
   homogénéiser). Côté app : la **couverture image** existe déjà (D-083) et prime
   sur la vidéo ; *reste à confirmer si un flux d'assignation en lot est utile*.
5. **Gel + qualité + build** — `npm run verifier` vert, APK de beta, canal de
   distribution choisi (cf. questions ouvertes).

## Hors périmètre (reporté après la beta)

- Modèle de données en **couches** (packs / perso / réglages).
- **Catalogue multidiscipline** activable, format de pack licencié.
- **Enchaînements** (fiches dédiées + vidéo secondaire).
- Rôle d'écriture pratiquant vs éditeur/club.
→ Tout est consigné dans `note-modele-donnees.md`.

## Répartition

| Qui | Quoi |
|---|---|
| **Yahya** (contenu) | fusion des packs Kodokan + Judo ; production des illustrations (club + modèle) |
| **Claude** (app) | nettoyage cosmétique ; « illustration par défaut » opérationnelle ; gel + `verifier` + APK ; aide au canal de distribution |

## Questions (réponses Yahya 2026-07-17)

- **Q1 — Nettoyage cosmétique : liste à venir (demain).** J'attends la liste
  précise des écrans/éléments à reprendre avant d'ouvrir la passe finition.
- **Q2 — Illustrations : Yahya s'en occupe.** Production + assignation côté
  Yahya ; il demandera **au besoin quelques micro-ajustements du workflow**
  (ex. import/assignation). Côté app : « illustration par défaut » repose sur la
  couverture image (D-083), déjà en place.
- **Q3 — Distribution : build en local.** Yahya a un **WSL déjà configuré** pour
  Movenso → les builds (dont *release* signé si besoin) se font **chez lui**. La
  CI reste sur l'APK *debug* en artefact (dépannage), **aucun keystore n'entre
  dans le dépôt**. Pas de chaîne de signature à monter côté CI pour l'instant.
- **Q4 — iOS : hors beta.** Pas de licence Apple (90 $) → cible **Android + PWA**
  pour ce test. Confirmé.

## Suite

En attente de la **liste cosmétique (Q1)** pour ouvrir la passe « finition
beta » par boucles vertes. Ensuite : gel d'un commit de référence, et Yahya
produit le build de beta depuis son WSL.
