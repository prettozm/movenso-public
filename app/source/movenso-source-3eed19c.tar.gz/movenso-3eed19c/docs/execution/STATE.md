# STATE — le présent, en une page

> **Type : vivant** · Réécrit court le **2026-08-02** (S3.A13/D-178) — l'ancien
> STATE-fleuve est préservé intégralement dans
> [`docs/archives/STATE-historique-2026-08.md`](../archives/STATE-historique-2026-08.md).
> Règle inchangée : le présent ne vit QU'ICI ; le pourquoi vit dans
> [DECISIONS.md](DECISIONS.md) ; la recette dans [QUALITY.md](QUALITY.md) ;
> l'architecture dans [../systeme.md](../systeme.md) ; les parcours dans
> [../workflows.md](../workflows.md).

## Phase courante

**STABILISATION V1** (D-161, 2026-08-01). Référence : l'audit externe
[`audit-stabilisation-v1.md`](audit-stabilisation-v1.md), loti en 3 lots
(fichiers dans [`lots/`](lots/)), arbitrage porteur **point par point avant
implémentation**. App `0.9.0-rc.1`, **schéma 5** (D-266), movpack v4.

- **Lot S1 (P0 — sécurité/intégrité/plateforme) : CLOS 12/12** (checkpoint
  2026-08-02, D-162→D-167). Détail : [`lots/S1-…`](lots/S1-securite-integrite-plateforme.md).
- **Lot S2 (P1 — parcours) : CLOS 16/16** (checkpoint 2026-08-02, D-168→D-173,
  recettes appareil comprises). Détail : [`lots/S2-…`](lots/S2-fermeture-parcours.md).
- **Lot S3 (P2-P4 — dette/publication/finitions) : EN COURS** — arbitré D-174
  (ordre validé, questions posées étape par étape).

## Lot courant : S3 — état par chantier

Ordre acté : D1 → D2 → A6 → A12 → A13 → A1/A3 → A4 → A5 → A7+A8 → A10 → C2 →
C3 → C4 → C5 → volet B (B2/B11 d'abord) → B4 (RC).

| Chantier | État |
|---|---|
| D1 recentrage Mindmap | ✅ CLOS — uniformisation : loupe + panneau « Centrer sur… » sur les 4 vues, barre inline supprimée (D-179) |
| D2 retour au « point de départ » | ✅ CLOS v3 — 🎲 hasard SUR PLACE (D-179) ; écran d'entrée = BIENVENUE explicative (règles du jeu, rôle des vues), réinvocable via Plus › À propos (D-180) |
| D3 Explorer (O4+O1+O5+O2, D-198) | ⚠️ O4 DÉFAIT PAR D-241 (voir volet B) — le reste CLOS — Explorer extrait (`relations-explorer.ts`) ; **O1 livré** (badges de rôle, mélange d'objectifs visible et dit, D-200) ; **O5 livré** (niveaux, D-201) ; **O2 livré** (Comparer = face-à-face, note de distinction en vedette, « Continuer sur » explicite, D-202). **O4 était APPLIQUÉ** (D-210 : 64 arêtes ajoutées, maillage 2,5 → ~3,1/technique, zéro technique isolée) puis **DÉFAIT par l'épuration porteur D-241** — le pack Judo publié est à 1,21 arête/technique et 40 techniques sur 111 n'ont plus aucun lien. C'est un choix de CONTENU assumé par le porteur, pas une régression de code : O1/O2/O5 et le moteur d'Explorer sont intacts. Conséquence à connaître : dans le pack Judo, un parcours Explorer s'arrête après un pas (les 5 arêtes « enchaîne » restantes mènent toutes à un cul-de-sac) |
| A6 ordre des couches | ✅ CLOS — `sourceDe` au domaine + garde statique (D-176) |
| A12 anomalies du code | ✅ CLOS — instruites une à une, reliquat Reprendre purgé (D-177) |
| A13 STATE court | ✅ CLOS — ce fichier (D-178) |
| A1/A3 réduire racine.ts / atelier.ts | ✅ **CLOS** (D-181→D-189) — racine 4 018 → **1 920 l.** à la clôture, **1 995 l. aujourd'hui : cinq lignes sous le budget de 2 000** (le garde A10 refusera le prochain ajout — sortir au service, comme en D-243) ; atelier 1 969 → **106 l.**, 14 modules nés (9 services + feuilles + 3 atelier-*), zéro changement de comportement, e2e complet vert à chaque tranche |
| A4 découper relations-visuelle.ts | ✅ CLOS — 2 tranches (D-190/D-191) : Carte → `relations-carte.ts`, Mindmap → `relations-mindmap.ts`, relations-visuelle 1 644 → **637 l.** (entrée + Liste + Explorer + feuille Lien). Explorer reste en place tant que D3 n'est pas arbitré |
| A5 découper app.css | ✅ CLOS — 9 feuilles thématiques + index `@import` (ordre = cascade inchangée, 725 règles = 725, contrôlé par script, D-192) |
| A7 découper l'e2e | ✅ CLOS — harnais + **21 chapitres** à contexte propre dans `tests-navigateur/parcours/` (18 à la clôture D-193→D-195, puis molette, composition-à-plusieurs, retraits-liens) ; parcours.mjs 4 061 → **2 151 l.** (flux principal B→F→I à état cumulatif + ordonnancement) |
| A8 temporisations fixes | ✅ CLOS — `rendu()` (updateComplete Lit) + `finit()` (re-essai borné) au harnais ; 174 sommeils ≤250 ms convertis, ~80 assertions auto-réessayées ; **21 délais restants assumés** (tailles OPFS 400 ms, durées réelles testées) (D-196) |
| A10 chaîne qualité | ✅ CLOS (« go reco » D-198, livré D-199) — `knip` (code mort, dans verifier+CI, 22 reliquats purgés au 1er passage), cycles d'import runtime INTERDITS (6 cycles hérités cassés : `relations-commun`, `atelier-commun`, `vignette`), budgets (2 000 l./fichier src, 900 Ko dist). Écartés : Prettier, couverture chiffrée, ESLint |
| A2 vues sans MovensoApp | ✅ CLOS (D-204) — règle d'architecture pour le code neuf (conventions §13), conversion opportuniste, pas de refonte |
| A9 tests intermédiaires | RAYÉ (D-211 — l'e2e couvre sur OPFS réel) |
| A11 budgets | fusionné dans A10 (D-174) |
| A14 diagnostic | ✅ CLOS (« go simple » D-211, livré D-217) — codes d'erreur STABLES `MOV-Enn`, opération longue (en cours/terminée) et version d'app complète au diagnostic |
| C1 états vides · C6 PWA | rayés (D-174 : S2.15 / S1.8-option B) |
| C2 retours uniformes | ✅ CLOS (D-204→D-209) — 2 niveaux de toast (25 alertes assertives) ; **17 confirmations nommées** (feuille thémable, voile-annule prouvé) ; 1 confirm natif assumé (rapport pré-vol d'export) ; plus aucun dialog dans l'e2e |
| C3 thèmes | réduit à une **passe visuelle** à la recette RC (D-211) |
| C4 perfs · C5 rapports · A9 tests | **RAYÉS** (contrariant confirmé, D-211) |
| Volet B (publication) | ARBITRÉ D-211 — EN COURS : garde pack club + version+commit (D-212) ; **« Packs officiels » dans l'app livré** (catalogue du site, import via circuit normal, D-213 + garde vocabulaire Kodokan) ; retours du contrôle web appliqués (D-214 : Jujitsu, niveaux ventilés, ←/→) ; pack Judo **0.6.0** publié (315 liens, niveaux) ; compositions retrouvables (D-215) ; limites connues consignées (D-216) ; **licences écrites** (D-218, corrigé D-220 : GPLv3 code, CC BY-NC-SA 4.0 packs — pas d'usage commercial, LICENSE + notices + À propos + site) ; **préparation store, tranche technique faite** (D-219 : Packs officiels joignables depuis l'APK — URL absolue natif + CSP vers le seul site public ; keystore stable D-110 réactivé dans apk.yml ; artefact club-judo purgé). Pack Yoga **0.2.0** publié (72 vignettes illustrées, sous-titres nettoyés, D-221) ; **correctif D-222** : la mise à jour d'un pack applique le sous-titre et la couverture fournis (bug porteur : maj 0.1.0→0.2.0 sans images). **Compositions passées en bêta opt-in** comme Relations (D-223 — ajustements à venir). **Fiche sans vidéo : l'illustration en tête** (O1 arbitré sur maquettes, D-224) + vignettes yoga refaites (inpainting, plus de troncature) — pack Yoga 0.3.0. Écran Packs officiels remis au propre (cartes, résumés complets, D-225). **Pack Karaté 0.2.0 : 109 techniques illustrées** (D-226) — le judo reste sans illustrations (deux corps = génération non fiable, assumé). **Compositions à plusieurs** (D-227 : acteurs + simultanéité ; D-229 : `Bloc.lien` découpant la séquence en **temps**). **Refonte D-231 après recette porteur sur appareil** (six captures : la vue à deux colonnes ne s'affichait jamais chez lui, quatre rôles) — rôles déclarés **dans l'entonnoir** (« Qui pratique ? », Seul par défaut), **aucun nom proposé** (ni paire, ni « Rôle N »), trame par temps dès **2 rôles OU un lien**, **voies pilotées par la LARGEUR** en requêtes de conteneur (2 dès 360 px, 3 dès 530, 4 dès 700… colonne unique par défaut), six teintes de rôle distinctes, lien porté par la carte, nom du rôle toujours dans le DOM. Correctif PC : la molette défile les rangées de filtres (D-228). Artefact miniatures ramené à 1 jour de rétention (D-230). **Correctif D-232** : `.carte-technique` réemployé par la trame écrasait la grille de la bibliothèque (vignettes minuscules) — classe renommée `.trame-technique`, et `verifier-sources` refuse désormais toute NOUVELLE classe CSS partagée entre deux feuilles thématiques ; « Qui pratique ? » simplifié à *Seul / À plusieurs*. **D-233** : le glisser-déposer est retiré de TOUTE l'app (flèches ▲/▼ seules, WCAG 2.5.7) et le **✎ de la barre haute** bascule la composition en **mode édition** (rôle, lien, ordre et retrait sur chaque pas, en une colonne) — en lecture, les cartes n'ont plus aucun outil. **D-234** : « Réglages avancés » devient une section propre de « Plus » (sortie d'Apparence — périmètre ≠ présentation) ; diagnostic **encodé avec BOM UTF-8** (il arrivait en « â€” » chez le porteur) et enrichi (sources du contenu, sauvegardes, maillage, capacités réelles de la plateforme, réglages non sensibles). **D-235 — grammaire FERMÉE pour la v1** : `Bloc.lien` devient un **booléen** (« rejoint le temps précédent »), la simultanéité est le sens de partager un temps et la mise en page la porte (rangée = temps, colonne = rôle, cartes empilées = simultanées, **aucun glyphe**) ; la cause va en consigne. Garde-fou porteur tenu : normalisation systématique au seul chemin d'écriture, transmission du rôle d'ouvreur à la suppression, liens attachés à la position au déplacement — 5 tests unitaires sur les quatre gestes. **D-238** : packs **Judo 0.6.1** (Nage-no-kata, 15 projections référencées) et **Jujitsu 0.1.1** (Goshin-jutsu, 21 attaques) — versions MACRO seulement, les versions détaillées attendent la dictée du porteur (contenu de kata non vérifiable de mémoire) ; source `donnees/jujitsu.json` créée (le pack n'était pas reproductible) ; correctif : un pas neutre traverse les voies. **D-236** : l'espace de stockage quitte Apparence pour « Stockage et sauvegardes » (sa ligne de persistance S1.9 est une question de sécurité des données), l'entrée du menu disant l'espace utilisé et la date de la dernière sauvegarde. **D-241 — pack Judo 0.7.0, épuré par le porteur** : 315 → **67 liens** (kata et « à ne pas confondre » intacts, l'essentiel des « enchaîne » et « similaire » retirés, type `fondamentaux` supprimé), 111 techniques inchangées, Nage-no-kata en **6 compositions** (synthèse + 5 séries). Contrôle : conteneur intègre, bibliothèque valide, mise à jour 0.6.1 → 0.7.0 simulée. Deux constats du contrôle : **D-210 est défait** (maillage 5,68 → 1,21 ; 40 techniques sur 111 sans aucun lien) et **une mise à jour de pack n'enlève jamais un lien** (limite consignée — l'épuration ne vaut que pour les installations neuves). **D-242 — pack Jujitsu 0.2.0** : le porteur a **dicté le Goshin-jutsu détaillé** (levée du refus D-238) — 4 compositions (synthèse 36 pas, Saisies 60, Attaques à distance 43, Armes 15), au geste près, avec le lien booléen D-235 employé sur du contenu réel ; et **0 → 54 relations** notées (le pack n'avait aucun maillage). 162 techniques inchangées, bibliothèque valide, trame vérifiée dans l'app (deux voies déployées, en-têtes nommés une fois). Réserves dites : les 3 dernières références de technique deviennent du texte libre, et la synthèse déclare Tori sans l'employer. **D-243 — un pack peut enfin RETIRER un lien**, en le proposant : `ConflitLiaison.sens` (`contenu` | `retrait`), différence calculée à l'import (donc **rétroactive**, contrairement à une origine posée sur les arêtes), arbitrage « garder / retirer » dans Plus › Relations + action groupée à confirmation nommée et point de restauration. Mesuré : Judo 0.6.1 → 0.7.0 = 255 retraits proposés, 0 retiré ; après « Tout retirer », 67 liens = l'installation neuve. Limite D-241 **LEVÉE**. **D-244 — pack Jujitsu 0.3.0 : les 16 familles illustrées** (planches porteur, découpe calée sur le titre car les quatre planches diffèrent). Arbitrage porteur : l'image de famille est recopiée sur chaque technique (**modèle inchangé, pas de seconde exception au gel**) et **garde son titre générique**, ce qui lève l'objection de véracité — la fiche montre une carte de famille assumée, pas une photo qui prétend être la technique. Vignettes en fichiers dans `donnees/images/jujitsu/` (364 Ko), recopiées à l'emballage. Poids : **1,0 Mo** — une couverture répétée doit tenir **sous 32 Kio de base64** (fenêtre deflate), sinon 6,1 Mo pour la même image. **D-245 — pack Karaté 0.3.0** : enrichi par le porteur (0 → 39 liens notés, 0 → **14 compositions** : Kihon par famille, Kumite, séries Heian/Tekki, programmes 1er→5e Dan), **109 illustrations spécifiques SAUVÉES** — le pack fourni n'en portait aucune, arbitrage porteur après question posée ; les 8 cartes de famille servent de repli. **Piège écarté** : l'identité publiée du karaté vient de sa DISCIPLINE, pas de son nom de fichier — l'emballer comme les autres aurait dupliqué 109 techniques chez qui l'a déjà (drapeau `idDepuisDiscipline`, mise à jour simulée). Source versionnée créée (`donnees/karate-shotokan.json`). Correction de la découpe D-244 : la rustine de pastille ramenait un titre inversé sur les titres longs. **D-246 — pack JJB 0.2.0** : enrichi (0 → **97 liens** notés, 0 → **14 compositions** : garde fermée, chaîne Armbar-Triangle-Omoplata, passages, prise de dos, système de jambes No-Gi…) et **150 techniques illustrées** par leurs 12 familles — le pack publié n'avait aucune image, c'est un gain net. Identité dérivée de la discipline traitée d'emblée (leçon D-245), mise à jour simulée : 150 techniques, pas 300. Quatrième source versionnée (`donnees/jjb.json`). **D-247 — identité des packs unifiée et DEUX packs réparés** : les six packs étaient nés avec un id dérivé de leur discipline ; l'outil d'emballage en avait cassé deux (`pack-kodokan`, `pack-jujitsu`) — défaut ACTIF et publié, que j'avais déclaré vérifié à tort. Règle unique `idPackStable(discipline)` sans exception, identités d'origine restaurées, et **garde `tests/packs-identite.test.ts`** qui épingle chaque identité (échoue si un ULID de source change, si un pack est emballé sans épinglage, ou si l'outil repasse au nom de fichier). Coût assumé : qui a installé judo ou jujitsu depuis la cassure doit retirer la discipline et réinstaller. **D-248 — pack Taïso 0.2.0** : 0 → **48 liens** notés, **12 → 16 séances** intégralement MINUTÉES (20 à 46 min) — le seul pack qui exerce le chrono de bout en bout, donc le meilleur support pour REC-S2-003. Deux renommages de libellé, deux types de relation nouveaux (données, D-020.2). Identité épinglée dès l'intégration (réflexe D-247). Cinquième source versionnée ; seul le Yoga reste hors dépôt. **114 techniques sur 114 illustrées** — 34 planches par TECHNIQUE (comme le karaté), tous les titres appariés exactement sur les noms du pack, aucune fiche nue. Reste : soumission Play (porteur) |

## Questions ouvertes (porteur)

1. **Versions DÉTAILLÉES des deux katas** (Goshin-jutsu, Nage-no-kata) : le
   porteur les prépare et les dictera (D-238/D-239). Rien à faire d'ici là.
2. Contrôle web en cours côté porteur — l'APK debug se lance À SA DEMANDE
   (Actions → apk → Run workflow, D-197).

Sorties de cette liste le 2026-08-08 (D-239) : le secret
`ANDROID_DEBUG_KEYSTORE_B64` est **repoussé de deux semaines** (la RC se
recette donc sur un APK à signature éphémère, D-113) et l'artefact
`miniatures-kodokan` est **conservé jusqu'à nouvel ordre** (6,2 Mo, rétention
ramenée à 1 jour en D-230).

## Réserves et dettes vivantes

- La **version éditoriale d'un pack installé n'est pas mémorisée** (seul
  `origine.pack` existe) — consigné dans KNOWN_LIMITATIONS ; registre des packs
  envisagé post-v1. C'est ce qui rendait D-222 indiagnosticable.
- **Embranchement** dans une composition (variante, « si… alors ») : absent du
  modèle, noté post-v1 (D-234).
- **Réaction ciblée** (à quelle action précise un pas répond) : une arête entre
  deux pas, structure nouvelle — post-v1 (D-235).
- On ne peut plus dire « X enchaîne DANS le même temps » (D-235) : c'est deux
  temps. Assumé, dit au porteur avant son go.
- Composition à rôles : les voies suivent la **largeur** (D-231) ; au-delà de
  **six rôles**, colonne unique quelle que soit la taille d'écran — assumé.
- Leçon D-231 : une preuve fabriquée sur le chemin que l'on a dessiné ne prouve
  rien du chemin de l'utilisateur. Toute capacité de saisie se démontre
  désormais **par l'entonnoir réel**, et à une taille de plus que le cas nominal.
- e2e découpé (harnais + 18 chapitres, A7 clos) et sur attentes d'état (A8
  clos) — 21 délais fixes assumés (durées réelles testées, tailles OPFS).
- TalkBack : socle vérifié par e2e, remontées utilisateur font foi (D-172).
- Limites connues CONSIGNÉES : [docs/KNOWN_LIMITATIONS.md](../KNOWN_LIMITATIONS.md)
  (D-216) — dont ZIP64/~4 Go (D-166) ; les parlantes reprises dans À propos.
- Médias multi-Go non mesurés en conteneur (allocation disque) — REC-S2-016.
- Stockage : options 2/3 (hybride `Documents/movenso`, emplacement choisi)
  notées post-v1 (D-167). Signature APK éphémère assumée (D-113).
- Comportements natifs Android non atteignables en e2e web (garde D-110,
  `Filesystem` D-106/D-111) — couverts par recette appareil.

## Dernière boucle (2026-08-09)

**D-249 — la croix ✕ défaisait l'édition dans le modèle, pas à l'écran.**
Trouvé en exécutant la vérification d'ouverture de session : l'e2e a rougi sur
l'assertion D-105, puis est repassé au vert. Reproduit plutôt que relancé
(MASTER §8) — c'était un vrai défaut, pas un test fragile : la liaison Lit du
commentaire survit à la sortie d'édition et compare au dernier COMMIT, jamais
au DOM, donc la valeur restaurée par ✕ était égale au mémo et Lit sautait
l'écriture. L'écran gardait le texte abandonné pendant que l'app annonçait
« Modifications annulées » — et la perte de focus suivante l'aurait
ré-enregistré. Le modèle ET la persistance étaient corrects (écritures OPFS
en file, vérifié).

**D-251 — et mon premier correctif était pire que le défaut.** Question du
porteur : ce champ n'est pas un champ de fiche, c'est une **note personnelle
libre, auto-enregistrée à la perte de focus, non exportée**. Contrôlé, les
trois points sont vrais (`provenance: "personnel"`, enregistrement au
`change`, `contenuPersonnel` réservé à `portee === "complet"` avec
`tests/non-divulgation.test.ts` en garde). Or `live()` réécrit le champ dès
que le DOM diffère du modèle : entre la frappe et le blur, il **effaçait la
note en cours de frappe**. Correctif retenu : `.value=` simple (la frappe est
intouchable) + `keyed` sur `generationCarnet`, incrémenté par la seule
`annulerEditionFiche` — le champ n'est repris QUE sur ce geste. Garde :
chapitre e2e `annulation-edition.mjs` (**22 chapitres**), qui couvre les deux
moitiés et rougit dans les deux sens. `npm run verifier` vert.

**D-250 — le site annonçait faux ce qu'il distribuait juste.** Les six
`.movpack` publiés sont les bons (identités d'origine vérifiées, garde D-247
tient), mais les **deux catalogues du site avaient divergé** : `packs/index.json`
(app) à jour, **`packs.js` (page web) resté à Judo 0.6.0, Karaté 0.2.0 et
Jujitsu/JJB/Taïso en 0.1.0 « 25 juillet »** — un visiteur lisait 0.1.0 et
téléchargeait le pack enrichi. `docs/versions.md` §2, pourtant « source de
vérité des versions » (D-132), était périmé lui aussi : trois emplacements,
trois états. Remis au réel tous les trois ; garde exécutable
`verifier-catalogues.mjs` côté site (vérifiée dans les deux sens), appelée par
`DEPLOY.md` **et lancée à chaque poussée** par le workflow `catalogues` —
une garde que rien n'exécute est une consigne de plus, c'est-à-dire ce qui
venait d'échouer.

**D-252 — les deux catalogues n'en font plus qu'un** (demandé par le porteur,
« mettre ça au propre dès maintenant »). Réparer `packs.js` traitait le
symptôme : deux listes tenues à la main finissent toujours par diverger, et
une garde qui les compare ne fait que constater la dérive une fois écrite.
`packs/index.json` devient le catalogue **unique** — il reçoit les champs
d'affichage, `site.js` le charge par `fetch`, `packs.js` est supprimé.
Vérifié des deux côtés sur le fichier réel : l'app liste six packs avec leurs
versions, la page web affiche six cartes, recherche et filtre par discipline
intacts. La garde devient celle du catalogue unique et couvre en plus **le
fichier publié que personne n'annonce** et **le retour d'une seconde liste**.
Reste une troisième copie, assumée et dite : le tableau `versions.md` §2 vit
dans l'autre dépôt, donc aucune garde exécutable ne peut l'y rattacher — le
registre déclare désormais que le catalogue fait foi.

**D-253 — une information, un lieu (demandé par le porteur).** `versions.md`
ne porte plus aucun numéro : il dit OÙ chaque version vit ; `npm run versions`
les lit à leurs sources. Garde `verifier:references` dans le vérificateur et
en CI (aucune version dans `versions.md`, version d'app nulle part ailleurs
que dans `package.json`) — elle a mordu sur quatre recopies au premier
passage, toutes traitées, **aucune exception ajoutée pour la faire taire**.
La méthode qui avait laissé passer D-251 est écrite dans `CLAUDE.md`
(qualifier l'objet avant de le corriger, démontrer dans les deux sens, ne pas
fabriquer d'événement que le produit n'émet pas, demander en cas de doute).
Piège de test consigné : `stockage.charger()` **reprend une transaction
inachevée**, donc il supprime le `.tmp` de bascule — le sonder en boucle
pendant une écriture casse cette écriture. On attend désormais par la file.

**D-254 — dépôts renommés** (`movenso-v3` → `movenso`, prototype V2 `movenso`
→ `old.movenso`). **Aucun impact produit** : l'app affiche le SHA de build et
non une URL (choix D-212, motivé par le renommage à venir), la CI n'écrit pas
le dépôt en dur, le CSP et « Packs officiels » visent `movenso-public`
inchangé. **L'`appId` Android reste `fr.prettozm.movenso.v3`** — le changer
ferait une autre application (mise à jour impossible, fin de la cohabitation
avec la V2 installée). Le risque était documentaire : la mission déclarait
`prettozm/movenso` comme « la V2, à ne jamais modifier », alors que c'est
désormais le dépôt de travail — corrigé, avec note datée (seules les adresses,
le contenu reste figé). `verifier:references` refuse maintenant toute URL
`movenso-v3` : GitHub redirige, donc un lien périmé marche et rien ne le dit.

## Lot S4 — audit externe du 2026-08-09

Ouvert et **arbitré point par point** (D-256). Détail exécutable :
[`lots/S4-audit-externe.md`](lots/S4-audit-externe.md). L'audit a été
**qualifié dans le code avant tout arbitrage** — 15 points sur 17 vérifiés,
2 déjà fermés le jour même, et deux de ses formulations corrigées.

- **S4.1 validation exhaustive des champs optionnels : ✅ CLOS** (D-255) —
  `alertes`, `couverture`, `origine` et les champs parcourus sont désormais
  refusés proprement ; **229 tests** ; les six packs publiés restent
  installables (contrepartie mesurée, pas supposée).
- **S4.4 restauration transactionnelle : ✅ CLOS** (D-258) — la restauration
  passe par `sauvegarder` ; l'invariant « un seul écrivain de la
  bibliothèque » est tenu par une **garde de sources**, pas par un test de
  course (leçon D-249).
- **S4.11 spécifié et arbitré** (D-257, D-259) : bandeau rouge/jaune/
  jamais-APK, actionnable, refermable, poussant vers **deux** actions
  (persistance ET sauvegarde — « inconnue » ne veut pas dire « ça marche »).
  Journal d'actions au diagnostic : **identifiants oui, libellés non** ; le
  type reste structurellement incapable de fuiter. Emplacement anonymisé.
  Dossier local en dur = **option** (l'API manque à Firefox et au mobile),
  jamais le défaut. Avertissement de visibilité + `.nomedia` sur Android.
- **En attente du porteur** : mentions éditeur/contact (le recadrage du
  risque est écrit en D-259 — l'exposition réelle est la blessure physique,
  pas l'appareil), et le go pour rédiger les textes d'un bloc.
- **S4.3 vignettes distantes : ✅ CLOS** (D-260) — éteintes par défaut, réglage
  dans Réglages avancés ; preuve par le RÉSEAU (23ᵉ chapitre e2e), pas par le
  DOM. **S4.10 textes publics : ✅ CLOS** — éditeur, contact, garantie et
  responsabilité en français, confidentialité disant les trois connexions
  sortantes réelles, sécurité recentrée sur la pratique physique. Le ® a été
  refusé (pas de marque déposée).
- **S4.12 CSP du site : ✅ CLOS** (D-261) — huit pages, politique stricte sans
  `unsafe-inline`, zéro violation mesurée. `frame-ancestors` retiré : inerte
  en `<meta>`, donc protection dite absente plutôt que feinte. **La police
  Manrope était chargée chez Google** : le site d'un projet « sans cloud »
  envoyait l'IP de chaque visiteur à un tiers, page Confidentialité comprise.
  Hébergée localement (40 Ko, OFL 1.1) → **aucune requête sortante**.
  **Compatibilité (reliquat S4.11) : ✅** — le site ne nomme plus de
  navigateurs, il renvoie au verdict de l'app.
- **S4.5 partage natif en flux : ✅ CLOS** (D-262) — les vidéos ne sont plus
  lues en mémoire sur le geste le plus banal ; le cas coûteux (partager EN
  gardant la vidéo) est joué pour la première fois en e2e.
- **S4.2 manifeste strict : ✅ CLOS** (D-263) — v4 exige son inventaire, le
  repli est réservé à v3, les deux lecteurs sont couverts. **236 tests.**
  La condition posée pour ouvrir le **movpack v5** est levée.
- **S4.6 + S4.8 + S4.9 : ✅ CLOS** (D-264) — `tools/publier.ts` remplace
  `emballer-packs.ts` : source unique `publication/packs.json`, conteneurs
  relus par le lecteur réel, **compteurs calculés depuis le conteneur**,
  catalogue généré. Licence dans les six manifestes. **Yoga reconstruit** →
  les six packs sont reproductibles depuis `donnees/`. Mise à jour simulée
  sur les six : aucune duplication. Son identité, jamais épinglée jusqu'ici,
  l'est désormais.
- **S4.7 + S4.13 : ✅ CLOS** (D-265) — la source correspondante voyage avec le
  binaire (`movenso-source-<sha>.tar.gz`, nommée par le commit affiché dans À
  propos) ; la garde du site refuse un `app/` publié sans elle, et **elle a
  rougi sur l'état réel** : le build en ligne était distribué sans source,
  c'est réparé. 11 Actions épinglées par SHA + garde.
- **S4.2bis boucle A : ✅ CLOS** (D-266) — **schéma 5** : la famille porte son
  image, la technique la dérive (grille ET fiche). Migration 4→5 conservatrice,
  6 tests + rejouée sur les six bibliothèques publiées + mise à jour croisée
  schéma 4 → pack schéma 5 : aucune duplication, aucune illustration perdue.
  Bibliothèque installée : jujitsu 4,43 → **0,60 Mo**, jjb 4,68 → **0,54 Mo**.
  **Reste la boucle B** (images en fichiers du ZIP, movpack v5) : elle ne migre
  plus de données, le modèle l'ayant déjà été.
- **Deux dépôts, deux régimes : ✅ ACTÉ** (D-267) — `movenso` reste toujours en
  branche ; `movenso-public` accepte la publication directe sur `main` sous
  quatre conditions, **sauf** le rédigé/engageant et la posture de sécurité,
  qui passent par une PR. La règle vit dans `CLAUDE.md` ; `DEPLOY.md` ne dit
  plus que les gestes. **La quatrième condition est devenue une garde** :
  `app/build.json` remplace `app/source/COMMIT` (version, commit,
  `versionSchema`, `versionMovpack`, source), le catalogue porte le
  `versionSchema` **relu** de chaque conteneur, et `verifier-catalogues.mjs`
  refuse un pack en schéma N+1 devant une app restée en schéma N — l'écart que
  le passage au schéma 5 rendait possible.
- **Reste en go** : **movpack v5 boucle B** — images en fichiers du ZIP,
  intégrité par fichier, plus d'inflation base64 (S4.2bis).
- **Acté hors v1** : registre des packs installés câblé au diagnostic,
  `racine.ts` découpé par famille d'actions, **PWA abandonnée**, version
  portable rouverte seulement si demandée.
- **Acté sur la signature** : aucun secret dans GitHub, APK de publication
  signé en local. Le risque se déplace sur la **conservation du keystore** —
  le perdre, c'est perdre la mise à jour Play définitivement.

## Prochaine étape

**B4 (RC) — EN COURS.** **Fonctions GELÉES le 2026-08-08** (D-240) : ne
restent recevables que les correctifs de recette et le contenu. **Une exception
nommée au gel** a été accordée par le porteur (D-243 : un pack peut proposer le
retrait des liens qu'il ne déclare plus, sans quoi l'épuration D-241 n'aurait
atteint que les installations neuves). La doc a été remise au réel
AVANT le gel — trois écarts nés des boucles D-232→D-235 (recette REC-229-001,
`systeme.md`, `workflows.md` décrivaient encore les quatre liens, le
glisser-déposer et « À deux »). **Recette appareil écrite : `REC-B4-001`**
(QUALITY, sept points, dont la passe visuelle C3 et les Packs officiels depuis
l'APK, D-219) ; elle prévient que réinstaller l'APK exige de désinstaller
(signature éphémère, D-113/D-239) donc **de sauvegarder avant**. Ensuite :
`0.9.0-rc.1` → v1. Côté porteur : dérouler la recette, bêta interne Play.

## Procédure de reprise (session neuve)

1. Vérifier branche/commit/état Git. **Dans `movenso` : toujours une branche,
   jamais `main`, jamais de fusion.** Dans `movenso-public`, la publication
   directe sur `main` est permise sous conditions — voir « Deux dépôts, deux
   régimes » dans `CLAUDE.md` (D-267). Si une consigne de démarrage nomme la
   même branche pour les deux dépôts, le **signaler**.
2. Lire ce fichier, puis [MASTER.md](MASTER.md), [DECISIONS.md](DECISIONS.md) (queue),
   le lot courant dans [`lots/`](lots/), les sections QUALITY concernées.
3. `npm run verifier` = typecheck + garde sources (injection + couches +
   collisions de classes CSS) + **identité des packs** (D-247) +
   224 unit + build + garde dist + e2e 21 chapitres (zéro erreur JS). Campagne de charge à
   la demande : `npm run campagne:charge`. **Compter ~2 min** (mesuré :
   1 min 55, dont 1 min 48 d'e2e) — il tient dans un appel au premier plan, ne
   PAS le lancer en tâche de fond puis l'attendre en boucle (D-237). Pour
   itérer sur un seul chapitre e2e : `npm run e2e:chapitre <nom>` (~4 s).
4. Publication : quatre conditions cumulatives (D-267) — commit `movenso`
   **poussé**, `npm run verifier` **vert** sur ce commit, `verifier-catalogues.mjs`
   vert **après** dépôt, et **app + packs + source dans le même commit** (la
   garde le refuse via `app/build.json`). Un `git push` n'est PAS une
   publication : vérifier que le run Pages conclut `success`.
   **En ligne : build `9cb0bdb`** (site `cbeb188`, Pages vert le
   2026-08-08) — packs Judo **0.7.1**, Jujitsu **0.3.1**, Karaté **0.3.0**,
   JJB **0.2.0** et Taïso **0.2.0**, tous à leur identité d'ORIGINE (D-247).
   **Cinq des six packs sont reproductibles depuis `donnees/`** ; seul le Yoga
   reste hors dépôt (dette connue).
5. **Publier les packs** : `node --experimental-strip-types tools/publier.ts`
   → `dist-packs/`. Contrôler un conteneur reçu : `tools/inspecter-movpack.ts`.
   Avant d'intégrer un pack fourni par le porteur, TOUJOURS le comparer au
   publié (techniques, images, compositions, identité) — c'est ce qui a permis
   de voir que le karaté v3 avait perdu ses 109 images (D-245) et que l'identité
   du jujitsu avait dérivé (D-247). Les illustrations vivent en fichiers dans
   `donnees/images/` (voir systeme.md), jamais en base64 dans la source.
