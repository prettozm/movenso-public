# Movenso — Recette bêta (version courte)

Merci de tester 🥋 Coche si le **résultat attendu** se produit. Sinon, note
l'étape + ce qui s'est passé + ton modèle de téléphone (Android) + la taille des
vidéos en jeu (+ capture si message d'erreur).

> Appareil : ……… · Version APK : ……… · Testeur : ………

---

**0. Avant toute mise à jour ⚠️** — une nouvelle version **efface les données**
(il faut désinstaller/réinstaller). Donc **fais d'abord une sauvegarde** (point 2)
et garde le fichier.

**1. Grosse vidéo ⭐** — ajoute/filme une vidéo **lourde (200 Mo – 1 Go)** sur une
fiche.
- [ ] L'ajout va au bout **sans plantage** (une progression s'affiche).
- [ ] Après fermeture/réouverture, la vidéo est **toujours là et se lit**.

**2. Sauvegarde ⭐** — **Plus › Sauvegardes › fichier avec les vidéos**.
- [ ] Un message confirme et **dit où** le fichier est enregistré.
- [ ] Le fichier `.movpack` est **bien présent** à cet endroit (appli *Fichiers*).

**3. Restauration ⭐** — réimporte ce fichier (idéalement après réinstallation).
- [ ] Un écran décrit le contenu **avant** d'écrire ; on **confirme**.
- [ ] Même **grosse**, la restauration va au bout **sans plantage**.
- [ ] Tout revient à l'identique — techniques, favoris, **vidéos lisibles**.

---

Souci ? Note : **le point (1/2/3)**, ce que tu as fait / vu / attendais,
**modèle + Android**, **taille** des vidéos, capture d'écran. Merci ! 🙏
