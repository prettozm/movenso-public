# Limites connues — assumées et dites (volet B, D-216)

> **Type : vivant.** La liste HONNÊTE de ce que Movenso ne garantit pas
> aujourd'hui. Chaque entrée cite sa décision d'origine. Une limite levée se
> RAYE ici dans le même commit que son correctif (conventions §12) ; les
> limites parlantes pour l'utilisateur sont reprises dans l'app
> (Plus › À propos › « Limites connues »).

| Limite | Détail | Origine |
|---|---|---|
| **Export ~4 Go non garanti** | La bibliothèque d'écriture ZIP (fflate) ne produit pas de ZIP64 : un export (sauvegarde ou pack) dont le conteneur dépasse ~4 Go peut échouer. L'export en flux borne la mémoire, pas la taille du fichier final. | D-166 |
| **Médias multi-Go non mesurés** | L'ingestion et la restauration de vidéos de plusieurs Go n'ont pas été mesurées en environnement contraint (allocation disque réelle d'un appareil plein). Les gardes d'espace (D-096/097) refusent AVANT d'écrire quand l'estimation est fiable. | REC-S2-016 |
| **TalkBack : socle vérifié, traversée non certifiée** | Noms accessibles, modales, annonces et contrastes sont tenus par l'e2e ; la traversée TalkBack exhaustive n'est pas faite — les remontées utilisateur font foi. | D-172 |
| **Navigateurs sans OPFS : refus propre, pas de repli** | Un environnement sans OPFS (ou sans `createWritable`, cas Safari ancien) reçoit un message clair — l'app ne fonctionne pas en mode dégradé. | D-167/S1.10 |
| **Bêta : signature APK éphémère tant que le secret n'est pas posé** | Le workflow `apk` réutilise un keystore debug stable dès que le secret `ANDROID_DEBUG_KEYSTORE_B64` existe (D-110, réactivé D-219 — création : commande dans D-110). Sans lui : keystore jetable, une mise à jour ne s'installe pas par-dessus l'ancienne (désinstaller = OPFS effacé) — **exporter une sauvegarde avant chaque mise à jour.** | D-113/D-219 |
| **Hors ligne : app web** | Les données restent sur l'appareil, mais l'app WEB peut demander une connexion pour se charger ou se mettre à jour (pas de PWA/service worker en v1). L'APK n'a pas cette limite. | S1.8/D-163 |
| ~~**Un lien retiré d'un pack ne disparaît pas des bibliothèques déjà servies**~~ | **LEVÉE le 2026-08-08 (D-243).** Une mise à jour PROPOSE désormais le retrait des liens que le pack ne déclare plus (écran Plus › Relations, « garder / retirer », action groupée avec point de restauration). Elle ne les retire toujours pas d'office, et c'est délibéré : une arête ne porte pas d'origine, donc un lien tracé à la main entre deux techniques du pack figure dans la liste — l'humain tranche. | D-241 → D-243 |
| **Judo et Jujitsu : réinstallation nécessaire pour les bêta-testeurs** | L'identité de ces deux conteneurs avait dérivé (`pack-kodokan`, `pack-jujitsu`) puis a été **remise à l'identité d'origine** (D-247). Qui a installé le judo ou le jujitsu pendant la période de dérive doit **retirer la discipline puis réinstaller** le pack : sans cela, la prochaine mise à jour s'installera comme un pack neuf et dupliquera son contenu. Les quatre autres packs ne sont pas concernés. | D-247 |
| **Vignettes en ligne** | Les vignettes YouTube se chargent en direct : hors connexion, l'initiale de la technique s'affiche à la place (dégradation prévue). | D-091 |

## La version d'un pack installé n'est pas mémorisée

La bibliothèque retient, sur chaque élément, l'**identifiant** du pack dont il
vient (`origine.pack`) — mais pas sa **version éditoriale**. On sait donc
toujours *d'où* vient une technique, jamais *quelle version* du pack est
installée.

Conséquence concrète : « j'ai mis à jour le pack yoga et rien n'a changé » ne
se diagnostique pas depuis l'app (c'était le bug D-222). Le diagnostic technique
rapporte les sources et leur volume, pas leur version — il ne l'invente pas.

Contournement : la page **Packs officiels** affiche la version publiée ; la
comparer à ce qu'on croit avoir installé. Correctif envisagé post-v1 : un
registre des packs installés sur la bibliothèque (champ optionnel, sans
migration).
