# Compréhension du produit Movenso (analyse de la V2)

> **Type : figé** · **Statut : VALIDÉ (2026-07-10, Yahya — décision D-004)**
> Le corps du document est figé tel que validé ; l'**addendum §8** enregistre
> les faits fournis par l'humain lors de la validation.
> Support de la **Validation 1** de la mission. Sources : dépôt V2
> (`movenso-main.zip`, état du 2026-07-10) — code, `docs/vision.md`,
> `docs/roadmap.md`, `docs/ideas.md`, `docs/history/v2/*` (audit, contre-revue,
> revue UX, vision produit du 2026-06-02, rapport final), notice utilisateur,
> changelog. Chaque affirmation porte son marqueur épistémique
> ([conventions.md](../conventions.md) §4).

---

## 1. Pourquoi Movenso existe

**[FAIT — docs V2]** Movenso est une bibliothèque **offline-first de techniques
d'arts martiaux** : des fiches (nom, nom traditionnel, famille, niveau,
description, points clés) reliées à des vidéos, organisées en
`Discipline → Famille → Technique → Vidéo`. Le nom fusionne *Mouvement* et
*Ensō* (le cercle Zen tracé en un seul geste) : capturer une technique en un
mouvement complet, ressaisissable et transmissible.

**[FAIT — docs V2]** Le problème d'origine est celui du **club** : un coach
constitue et transmet un référentiel de techniques (fiches + vidéos) à ses
élèves, sans dépendre d'un service en ligne, d'un compte ou d'un abonnement.
Les données vivent sur l'appareil, s'échangent par fichiers (`.movpack`), et
doivent rester lisibles dans dix ans.

**[DÉCISION V2 — vision-produit 2026-06-02]** Un **glissement d'audience** a été
acté en cours de V2 : au-delà du club, l'utilisateur réel est aussi le
**pratiquant individuel** qui curate sa propre vue (vidéos en ligne, favoris,
à terme « systèmes de combat » personnels). Un pratiquant avancé ne raisonne
pas en `Discipline → Famille → Technique` mais en
`Mon système → Mes attaques → Mes préparations → Mes enchaînements → Mes contres`.

**[DÉDUCTION]** Movenso existe donc pour répondre à deux usages d'un même
domaine : **transmettre** (le coach vers ses élèves — contenu partagé) et
**s'approprier** (le pratiquant pour lui-même — couche personnelle). La V2 a
livré le premier presque complètement, et seulement l'embryon du second
(favoris locaux, vidéos en ligne).

## 2. Les invariants (l'ADN)

**[DÉCISION V2 — charte `docs/vision.md`, non négociable en V2]** Sept
invariants, qui priment sur toute considération de modernité :

1. **Offline-first** — aucune opération cœur n'exige le réseau.
2. **Sans compte, sans cloud obligatoire** — pas d'auth serveur, pas de sync.
3. **Local d'abord** — source de vérité = JSON + fichiers vidéo sur l'appareil.
4. **Simple** — un mainteneur seul doit tout comprendre en une session.
5. **Robuste** — backup avant mutation, validation de schéma, jamais d'écrasement silencieux.
6. **Portable** — même code sur web, Windows portable, Android.
7. **Pérenne** — formats lisibles/diffables, stack minimale, utilisable dans dix ans.

**[DÉDUCTION]** Ces invariants sont la véritable identité du produit — davantage
que toute fonctionnalité. Ils ont survécu à la V1 et à la V2, et la V2 a rejeté
explicitement tout ce qui les érodait (sync cloud, comptes, changement de
framework, gamification).

**[HYPOTHÈSE — à confirmer en Validation 1]** Ces sept invariants restent tous
valables pour la V3, au même niveau d'exigence. En particulier : le trio de
plateformes (web + Windows portable + Android) est-il toujours le bon périmètre ?

## 3. Ce que la V2 est aujourd'hui

**[FAIT — code + changelog]** État livré (V2, 2026-07-10) :

- Bibliothèque complète : disciplines, familles, techniques, vidéos locales
  (import/capture) et **vidéos en ligne opt-in** (URL directe ou embed YouTube),
  recherche, filtres, favoris locaux, thème dual.
- **Graphe de relations** entre techniques (prépare / enchaîne / contre /
  similaire), inverse dérivé automatiquement, puces cliquables dans la fiche.
- **Format d'échange unifié `.movpack`** (ZIP : manifeste + packs JSON + vidéos),
  trois portées (technique / discipline / bibliothèque), lecture rétro-compatible
  des formats V1 par détection de contenu.
- Modèle d'accès simplifié : **un seul PIN admin** (PBKDF2-SHA256 600k itérations,
  verrou anti-brute-force), édition = booléen « autorisée pour tous / admin seul »,
  backups automatiques avant mutation (15 conservés), journal d'activité.
- **Pack de référence « Judo Kodokan »** : 111 entrées (100 techniques + kata +
  bases), toutes avec vidéo officielle Kodokan référencée, relations réelles.
- **Page publique** (`prettozm.github.io/movenso-public/`) : téléchargement de
  l'app et du pack Kodokan, avertissements légaux/sécurité.
- CI GitHub Actions (typecheck + tests + build web en PR ; APK / Electron /
  web en artefacts à la demande). ~94 tests unitaires sur le domaine.

**[FAIT — audit V2]** La stack : Lit + TypeScript + Vite, fflate (ZIP),
Electron (Windows portable), Capacitor (Android). Domaine pur sans dépendance
plateforme ; tout ce qui varie par plateforme est isolé derrière `PlatformAdapter`.

**[FAIT — roadmap V2]** Reste ouvert en V2 : publication des binaires en
Release `latest` (404 actuel sur la page publique), flux « PIN oublié sans tout
effacer », retrait de `webSecurity: false` à valider sur build réel,
`navigator.storage.persist()` côté web, écriture vidéo Android sans base64,
volet juridique (responsabilité, marque Kodokan) si diffusion large.

## 4. Ce que la V2 a jugé mais pas construit (la valeur différée)

**[DÉCISION V2 — roadmap/ideas, reporté sciemment]**

- **Couche perso avancée** : collections / « systèmes de combat » (sous-graphe
  personnel du graphe partagé), notes perso, ordre custom. Reportée car
  « produit dans le produit » à l'époque — mais identifiée comme la suite
  naturelle : favoris → collections → notes.
- **Quiz / auto-évaluation** : consommateur du graphe (passage de grade,
  rétention du vocabulaire, reconnaissance vidéo). Utile seulement si
  auto-généré depuis la donnée structurée ; rejet explicite de la gamification
  (badges/streaks).
- **IA locale** : traversée du graphe + formulation par LLM on-device
  (« 3 préparations + 2 enchaînements pour o-soto-gari »). Sans valeur tant que
  le graphe n'est pas dense.
- **Relations inter-packs** (id canonique/slug) : besoin marginal, non bloquant.
- **Présentation des « techniques liées »** à repenser (retour utilisateur :
  « trop figé »).

**[DÉDUCTION]** La V2 s'est volontairement arrêtée à la **couche contenu
partagé**. La valeur différée est presque entièrement du côté du **pratiquant
individuel** (couche perso et ses consommateurs : quiz, IA). C'est le principal
espace de valeur nouvelle disponible pour une V3 — sous réserve de l'arbitrage
humain (Validation 2).

## 5. Leçons de la V2 (ce qui a coûté, ce qui a protégé)

### Ce qui a bien fonctionné — **[DÉDUCTION** à partir des faits audités**]**

- **Le domaine pur, testé, sans dépendance plateforme** : là où vivent les
  règles, les régressions ont été rares.
- **La frontière `PlatformAdapter`** : une seule UI sur trois runtimes, réelle.
- **Les invariants écrits + le processus contradictoire** (Architecte /
  Contrariant / Gardien) : ont empêché l'usine à gaz — sync cloud, éditeur de
  graphe visuel, SQLite, i18n spéculative ont tous été rejetés à temps.
- **La rétro-compatibilité par contenu** (jamais par extension) et le
  « backup avant mutation » : zéro perte de données signalée.
- **Traiter le contenu comme de la donnée** (packs importables) et non du code.

### Ce qui a coûté — **[FAIT — audité en V2, assumé comme dette]**

- **Duplication renderer/Electron** : la persistance existe deux fois (TS
  renderer + CJS process main Electron) ; chaque règle média doit être écrite
  deux fois. Premier poste de coût de maintenance identifié.
- **Objets-Dieu UI** : `admin-panel.ts` ~1 800 lignes (7 onglets),
  `main.ts` ~1 000 lignes. Non refactorés par gestion du risque.
- **`webSecurity: false`** (Electron) posé tôt, jamais retirable faute
  d'environnement de test runtime.
- **Android** : transfert vidéo par chunks base64 (lent sur gros fichiers) ;
  import `.movpack` cassé par le mapping MIME du WebView (bug P0 découvert
  seulement au test réel sur appareil).
- **PIN = théâtre de sécurité si survendu** : verrou anti-curieux (hash+sel
  lisibles localement), pas un coffre-fort. L'honnêteté sur ce point est
  elle-même une leçon.

**[DÉDUCTION]** Les leçons transversales : (a) ce qui n'est pas testable dans
l'environnement de dev (Electron packagé, appareil Android réel) devient une
dette permanente — la V3 doit prévoir sa boucle de recette réelle dès le
départ ; (b) la duplication multi-runtime est le coût structurel n°1 — le choix
d'architecture V3 doit la traiter à la racine ; (c) la valeur d'un graphe ou
d'une structure vient de ses **données**, pas de son moteur — livrer une
fonctionnalité sans ses données revient à livrer une UI vide.

## 6. Modèle mental à retenir (synthèse)

**[DÉDUCTION]** Movenso se comprend en deux couches :

| Couche | Contenu | Auteur | Distribution |
|---|---|---|---|
| **Contenu partagé** | packs : taxonomie, techniques, relations, vidéos | coach / source (Kodokan) | fichiers `.movpack`, read-only côté consommateur |
| **Couche perso** | favoris, collections/« systèmes », notes, vidéos ajoutées | pratiquant | locale à l'appareil, jamais exportée dans le pack |

La V2 a construit la première couche et posé l'embryon de la seconde. Le tout
sous sept invariants (offline, no-account, local, simple, robuste, portable,
pérenne) qui définissent l'identité du produit plus que ses fonctionnalités.

## 7. Inconnues et hypothèses à lever (avec l'humain)

Ces points ne sont **pas déductibles** du dépôt V2 et conditionnent la vision V3 :

- **[HYPOTHÈSE]** Usage réel : qui utilise Movenso aujourd'hui (un club ? le
  mainteneur seul ? des tiers via la page publique ?), sur quels appareils, à
  quelle fréquence ? Le dépôt montre l'app « côté producteur », pas la réalité terrain.
- **[HYPOTHÈSE]** Motivation V3 : la mission exige une valeur nouvelle réelle —
  est-elle attendue plutôt côté pratiquant (couche perso), côté contenu
  (nouvelles disciplines, qualité des packs), côté plateforme (iOS ?), ou côté
  simplification/pérennité ?
- **[HYPOTHÈSE]** Périmètre plateformes : le Windows portable (Electron) est-il
  réellement utilisé, ou Android est-il devenu la cible principale ? iOS est-il
  souhaité un jour ?
- **[HYPOTHÈSE]** Migration : quelles données V2 réelles doivent survivre en V3
  (bibliothèques d'appareils existants ? uniquement les packs publiés ?).
- **[HYPOTHÈSE]** Diffusion : Movenso reste-t-il un outil personnel/club, ou la
  page publique et le Play Store annoncent-ils une diffusion plus large
  (avec le volet juridique que la V2 a signalé) ?

## 8. Addendum post-validation (faits fournis par l'humain, 2026-07-10)

Enregistrés lors de la Validation 1 (décision D-004) ; ils lèvent en partie les
hypothèses du §7 :

- **[FAIT — humain]** Movenso n'a **jamais été diffusé publiquement** et n'a
  **aucune base d'utilisateurs actifs**.
- **[FAIT — humain]** La V2 est un **prototype très avancé**, qui a
  essentiellement servi à explorer le domaine, valider des choix techniques et
  apprendre.
- **[DÉCISION — D-005]** La compatibilité fonctionnelle avec la V2 n'est pas un
  objectif : la valeur de la V3 prime ; tout élément V2 conservé doit l'être
  pour sa valeur démontrée.

**[DÉDUCTION]** Conséquence directe : les « demandes récurrentes des
utilisateurs » mentionnées dans les docs V2 (§1) reflétaient l'expérience du
mainteneur et de son entourage, pas une base d'utilisateurs. Toute vision V3
doit créer de la valeur **dès le premier utilisateur, seul** — aucun effet de
réseau ou contexte de déploiement (club équipé, élèves abonnés aux packs) ne
peut être présupposé.
