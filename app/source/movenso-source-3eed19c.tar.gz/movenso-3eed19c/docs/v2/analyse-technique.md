# Analyse technique de Movenso V2

> **Type : figé** · **Statut : VALIDÉ (2026-07-10, Yahya — décision D-004)**
> Analyse factuelle du code V2 (`movenso-main.zip`, état du 2026-07-10), annexe
> technique de [comprehension-produit.md](comprehension-produit.md). Les §1-7
> sont des **[FAIT]** observés dans le code (chemins relatifs à la racine du
> dépôt V2) ; le §8 est explicitement composé de **[DÉDUCTION]/[RECO]**.

---

## 1. Modèle de données réel (`src/domain/model.ts`)

**Versionnement** : `CURRENT_SCHEMA_VERSION = 1` et `MEDIA_SCHEMA_VERSION = 1` (model.ts:1-2). Aucune migration de version de schéma n'existe : `schema.ts:12` **rejette** tout `schemaVersion !== 1`. `migrations.ts` ne fait pas de migration versionnée — il convertit la base **legacy V1** (un seul `db.json` plat, champs `japonais`, `videoFile`, `kuzures`) en packs par discipline (`splitLegacyDbByDiscipline`).

**Entités (champs exacts)** :
- `Discipline { id, label, ordre? }` ; `Famille { id, label, disc, ordre? }` ; `Niveau { id, label, disc, couleur?, couleur2?, ordre? }` ; `Source { id, label, ordre? }` ; `TypeVideo { id, label, ordre? }`.
- `Technique { id: number|string, disc, titre, nom_traditionnel?, famille, niveaux[], source?, videos: VideoRef[], desc?, points[], variantes?, relations? }` — **l'id est `number | string`** (héritage V1 numérique), d'où des `String(t.id)` défensifs partout.
- `VideoRef { file, type, label?, chapitres[], isPrimary, created_at?, captured_on_device?, online?, url?, youtubeId? }` — `file` est soit un chemin relatif, soit une identité synthétique `youtube:<id>` / `online:<url>` si `online: true`.
- `MartialArtPack { schemaVersion, discipline, familles, niveaux, sources, typesVideo, techniques }` — **un pack = une discipline**, taxonomie embarquée dans le pack.
- `ContentManifest { schemaVersion, activePacks[], packs[]{id,label,file,enabled} }`.
- Relations : vocabulaire contrôlé `RELATION_TYPES = ["prepare_par","continue_vers","contre_par","similaire_a"]` (model.ts:63) ; stockées **dans un seul sens**, inverses dérivés à l'affichage (relations.ts:53-75), `similaire_a` symétrique, cibles absentes tolérées (schema.ts:158-183).

**Modèle média (parallèle)** : `VideoMeta { id: ULID, title, original_filename, filename, sha256?, size, mime, duration?, created_at, updated_at, storage_id, storage_key, club?, captured_on_device? }` + `VideoLink { id, video_id, target_type: technique|famille|discipline, target_id, target_disc?, role, label?, isPrimary?, chapitres? }` dans un `MediaIndex { schemaVersion, videos{}, video_links[], storage_locations{} }`.

**Identifiants** : ULID custom sans dépendance (ulid.ts, 26 chars Crockford, monotone) pour `VideoMeta` et les copies importées ; ids de taxonomie = slugs ; noms de fichiers vidéo `[XXXXXXXX] label.ext` (id court 8 chars, platform/utils.ts:15-18).

**Invariants validés** (schema.ts) : exactement une vidéo primaire par technique, pas de chemins absolus ni `..` dans les `storage_key`, unicité des ids, cohérence des références famille/niveau/type, `target_disc` obligatoire pour les liens technique.

**Point structurel important** : les vidéos vivent **en double** — `Technique.videos[]` (dans le pack) **et** `MediaIndex`, synchronisés par `media-sync.ts:syncTechniqueMediaIndex` à chaque sauvegarde (avec des `VideoMeta` factices `"PENDING"` créés à la volée, media-sync.ts:20-30). Le pack est la source de vérité pour l'affichage ; le MediaIndex sert à la dédup sha256, aux diagnostics et à l'export.

## 2. Format `.movpack`

Trois générations coexistent en lecture :
- **v1 technique** (movpack.ts) : ZIP fflate — `manifest.json` (format `"movpack"`), `pack.json` (mini-pack 1 technique + taxonomie réduite), `media.json`, `videos/<ULID>.<ext>` optionnels.
- **v1 discipline** : `.zip` d'export (media-io.ts:exportZip) — `export.json`/`manifest.json`, `database.json`, `metadata.json`, `packs/*.json`, `media.json`, `videos/`.
- **v2 unifié** (movenso-pack.ts, seul format d'écriture) : `manifest.json` (format `"movenso-pack"`, version 2) avec **`scope: "technique" | "discipline" | "library"`**, `packs/<discId>.json` (1..N), `media.json`, `videos/`. Le manifeste porte des champs d'aperçu (title, disciplines[], techniqueCount, containsVideos, videoCount) pour prévisualiser un import sans tout déballer.

**Rétrocompatibilité** : `readMovensoPack` (movenso-pack.ts:140-164) détecte **par contenu, jamais par extension**. L'application scope=technique repasse par la logique v1 via une vue adaptateur (movenso-pack.ts:249).

**Hashing/dédup** : sha256 par vidéo ; à l'import, `MediaStore.mergeFrom` (media-store.ts:225-298) — même ULID + sha256 différent = conflit critique (le local gagne), sha256 identique = remap d'id. Compression : niveau 0 avec vidéos, 6 sinon. Conflit d'import technique : `replace | copy | skip` (« copy » génère `<disc>-<ULID>`).

**Astuce d'implémentation** : l'import d'un movpack technique est converti en « remplacement de discipline entière fusionnée » (movpack.ts:321) pour réutiliser l'unique chemin plateforme `applyLibraryImport`.

## 3. Gestion des médias

- **MediaStore** (media-store.ts) : classe pure immuable (`structuredClone` systématique) — CRUD vidéos/liens/stockages, invariant « une primaire par cible », diagnostics (orphelines, liens cassés), merge d'import avec rapport.
- **Stockage physique par plateforme** :
  - *Web* : IndexedDB — **deux bases distinctes** selon le chemin de code : `bibliotheque-technique-videos` (local.ts:29-30) et `jcl-video-storage` (storage-provider.ts:41) ; le `StorageProvider` abstrait est en pratique contourné par `LocalAdapter`.
  - *Electron* : dossier `videos/` à côté de l'exécutable, servi via protocole custom `jcl-video://` (main.cjs:910-914), miniatures ffmpeg dans `thumbnails/`.
  - *Android* : plugin Capacitor Java `LocalMediaPlugin` (369 lignes) ; écriture par **chunks base64 de 512 Ko** (local.ts:77-88), lecture via `content://` + `Capacitor.convertFileSrc`.
- **Réconciliation** (media-reconcile.ts) : croisement pur références JSON ↔ scan disque (`findMissingMedia`, `removeMissingVideos` avec réassignation de primaire). Vidéos `online` exclues.
- **Vidéos en ligne** (online-video.ts) : URL de fichier direct (lue dans `<video>`) ou YouTube (embed `youtube-nocookie.com`, miniature `img.youtube.com`). Jamais téléchargées, aucune entrée MediaIndex.
- **Backups** : snapshot complet avant **chaque** mutation (technique, taxonomie, vidéo, import, restore), rotation 15 ; clone JSON complet en web, copie récursive de `data/` en Electron.

## 4. Couche plateforme

**Contrat `PlatformAdapter`** (adapter.ts, 59 lignes) : `caps {fileSystem, nativeMedia}` + ~30 méthodes (données, vidéos, media index, miniatures — Electron seulement, import/export, backups, logs). Sélection : `window.jclDesktop ? ElectronAdapter : LocalAdapter` — **`LocalAdapter` couvre web ET Android**, différenciés à l'exécution par `Capacitor.isNativePlatform()`.

- **LocalAdapter** (local.ts, 791 l.) : implémentation complète TS sur IndexedDB (`jcl-app-v1`), branches natives Android partout.
- **ElectronAdapter** (electron.ts, 190 l.) : pur proxy IPC — la logique métier tourne dans le process main (`main.cjs`).
- **Généralité anticipée non utilisée** : `StorageLocationType` prévoit `desktop-folder` et `android-external`, jamais implémentés ; seule `internal` existe.

## 5. Sécurité

- **PIN admin unique** (security.ts) : PBKDF2-SHA256, sel 32 octets, 600 000 itérations (upgrade depuis 100k au changement de PIN), hash+sel en localStorage. Le commentaire du code est honnête : verrou anti-curieux, pas un secret cryptographique.
- **Anti-brute-force** : 5 échecs → verrou 30 s, doublé par salve, plafond 30 min, persisté.
- **Permissions réelles** : 3 rôles nominaux dans le type (`invite|contributeur|admin`) mais **2 états en pratique** (invité, admin) + booléen « édition autorisée pour tous » ; suppression = admin seul. Le rôle contributeur a été supprimé du produit mais survit dans le type.
- **Auto-logout** admin après 5 min d'inactivité. **Journal d'activité** applicatif (rotation 30 jours, export CSV) — best-effort, pas un audit trail.
- **`webSecurity: false`** (main.cjs:870), assumé comme dette ; compensé partiellement par contextIsolation, preload minimal, blocage `window.open`/`will-navigate`, CSP au build.

## 6. Complexité / dette observées dans le code

1. **Duplication Electron ↔ domaine** (la plus grosse) : `electron/main.cjs` (1 152 l. CJS) **réimplémente** au lieu d'importer — validation MediaIndex, validation technique, normalizeTechnique, ULID, nommage vidéo, import/reset/rename/delete (main.cjs:560-1145 vs domaine). Toute règle existe en 2 (parfois 3) exemplaires. Cause racine : process main CJS qui ne consomme pas le domaine TS.
2. **Double représentation vidéo** `VideoRef` ⇄ `MediaIndex`, synchronisée par convention (`storage_key = "videos/" + file`) avec métadonnées factices « PENDING ».
3. **Trois formats d'échange à lire pour toujours** + fichiers redondants dans le zip v1 (`database.json`/`export.json`/`metadata.json`).
4. **Chunks base64 512 Ko sur Android** : +33 % de volume, N allers-retours JS↔Java par vidéo.
5. **`webSecurity: false`** (cf. §5) — retrait jamais validé faute d'environnement de test Electron packagé.
6. **StorageProvider mort-né** : interface complète, une seule implémentation réelle, contournée sur 2 plateformes sur 3.
7. **`id: number | string`** sur Technique → conversions défensives dans ~20 endroits.
8. **Deux bases IndexedDB vidéo** en web selon le chemin de code.
9. Bricolages : détection d'annulation du file picker par focus + timeouts (3 s/120 s), timeout arbitraire 2,5 s au chargement Electron.
10. **Backup complet avant chaque micro-mutation** (y compris un ajout de famille) — coûteux, sature les 15 slots de rotation.

## 7. Qualité

- **Tests** (17 fichiers, node:test) : couvrent **exclusivement le domaine pur** (schema, migrations legacy, stores, media-io, movpack v1/v2, online-video, relations, sha256, accès/PIN, cohérence des packs distribués). **Non testé** : toute l'UI (~3 700 l.), `local.ts` (791 l.), `electron.ts`, `main.cjs` (1 152 l. — la copie CJS n'est couverte par rien), le plugin Java. Aucun test E2E/runtime.
- **Gros fichiers UI** : admin-panel.ts 1 798 l., main.ts 1 002 l. Lit en light DOM, CSS global à tokens, pas de state manager (état dans `JclApp`, callbacks en props).
- **Patterns positifs** : domaine 100 % pur (3 dépendances runtime : lit, fflate, capacitor) ; validation avant toute écriture ; `structuredClone` défensif ; commentaires expliquant le *pourquoi* avec renvois aux docs ; scripts de contenu qui « dogfoodent » le domaine ; **doc fidèle au code, dettes incluses**.

## 8. Verdicts par composant — [DÉDUCTION]/[RECO], pas des faits

| Composant V2 | Verdict | Justification |
|---|---|---|
| Domaine pur testé (`src/domain/`) | **Bonne idée à conserver** | Zéro dépendance, invariants centralisés, bien testé. Le principe, pas forcément le découpage. |
| `.movpack` v2 (scope + détection par contenu + manifeste d'aperçu) | **À conserver conceptuellement** | Design mûr, a déjà absorbé 2 formats v1. En V3 : ne garder que v2 en lecture/écriture, trancher le sort des formats v1. |
| Dédup sha256 + ULID + noms `[id] label.ext` | **À conserver** | Résout réellement doublons et renommages ; simple, testé. |
| Relations unidirectionnelles à inverse dérivé | **À conserver** | Élégant, évite le graphe incohérent, tolère les références absentes. |
| Vidéos en ligne encodées dans `VideoRef.file` (`youtube:<id>`) | **Discutable** | Bon besoin, mauvais encodage : hack qui pollue toute la logique fichier. En V3 : type de source explicite. |
| Double modèle VideoRef ⇄ MediaIndex | **Complexité accidentelle** | Deux vérités synchronisées par convention. En V3 : une seule représentation. |
| `electron/main.cjs` dupliqué | **Complexité accidentelle** | ~600 l. de logique métier recopiée, non testée. En V3 : une seule implémentation de chaque règle, exécutée partout. |
| StorageProvider multi-emplacements | **Complexité accidentelle (YAGNI)** | Abstraction sans deuxième implémentation. |
| PlatformAdapter (l'idée de frontière) | **À conserver** ; périmètre discutable | La bonne frontière, mais interface fourre-tout (~30 méthodes) à re-découper. |
| PIN PBKDF2 + verrou + auto-logout | **À conserver** | Proportionné au modèle de menace assumé, petit, honnête. |
| Type à 3 rôles | **Complexité résiduelle** | Le produit a convergé vers admin + booléen ; modéliser ce qui existe. |
| Backup avant chaque mutation | **Discutable** | Filet précieux ; granularité coûteuse. Alternatives V3 : journal d'opérations ou backup par session. |
| Chunks base64 Android | **Discutable** | Imposé par le bridge de l'époque ; vérifier les API modernes avant de reproduire. |
| UI monolithique (admin-panel, JclApp) | **Complexité accidentelle/discutable** | Là où la dette UI s'accumule ; découpage et gestion d'état à concevoir en V3. |
| Doc synchronisée avec le code, dettes admises | **Pratique à conserver** | Valeur réelle démontrée pour la reprise. |

**[DÉDUCTION] Enseignement transversal** : la V2 a un noyau domaine excellent entouré de trois couches d'exécution qui n'arrivent pas toutes à le consommer (main.cjs dupliqué, plugin Java, branches natives dans LocalAdapter). Le chantier n°1 d'une V3 n'est pas le modèle de données (sain) mais **l'architecture d'exécution** : qu'il n'existe qu'une seule implémentation de chaque règle, exécutée sur toutes les plateformes, et que ce qui n'est testable que sur appareil réel soit réduit au minimum et couvert par une procédure de recette.
