# Incrément 1 — conception

> **📦 ARCHIVÉ — figé (2026-07-24).** Document de conception de l'incrément 1,
> conservé comme **mémoire historique**. La **matrice de conservation §6bis**
> qu'il contient est un instantané de cette période : les sacrifices et qualités
> depuis la finition sont tracés dans [`../execution/DECISIONS.md`](../execution/DECISIONS.md).
> État courant : [`../execution/STATE.md`](../execution/STATE.md) · architecture :
> [`../systeme.md`](../systeme.md). Les liens internes ci-dessous datent de la
> rédaction et peuvent être périmés.

> **Type : figé (historique)** · **Statut : NON VALIDÉ (conception d'incrément)**
> Cadre engagé : [../contrat-construction.md](../contrat-construction.md) §10 (périmètre
> validé D-007). Ce document conçoit l'expérience et les critères de recette de
> l'incrément, sous l'exigence « valeur d'abord » (D-007). Prototype interactif
> du parcours : [prototypes/increment-1.html](prototypes/increment-1.html)
> (artefact de communication, pas une référence d'implémentation — D-008).
> **Révisé (session 5)** après challenge humain : M1 reformulé (le Kodokan est
> une démonstration, pas la valeur) ; point de départ du parcours déplacé de
> « chercher » vers « retrouver ce que je viens d'apprendre » ; rattachement
> de capture rendu optionnel.

---

## 1. La proposition de valeur (« pourquoi V3 plutôt que V2 »)

**[DÉDUCTION]** La V2 est une **bibliothèque que l'on consulte** : elle répond à
« montre-moi o-soto-gari ». Elle ne répond pas à la question que le pratiquant
se pose en sortant du cours : **« qu'est-ce que j'ai appris ce soir, et où le
retrouver ? »** — l'édition V2 modifiait le contenu partagé, il n'existait
aucun endroit pour *son* savoir. La V3 est un **carnet qui apprend avec toi**,
adossé à un référentiel quand il en existe un. Trois moments observables dès
l'incrément 1, chacun impossible en V2 :

| # | Moment | Vécu | Impossible en V2 parce que |
|---|---|---|---|
| M1 | **« J'ouvre, je peux agir — quelle que soit ma discipline »** (précisé par D-017) | Premier lancement **sans aucun contenu imposé**, mais jamais bloqué : capturer tout de suite, importer un pack en un geste (officiel, club, perso), ou créer sa discipline de zéro | App vide + création de PIN + connexion admin obligatoires avant tout ; sans pack, la V2 (pure visionneuse) n'avait **aucune** valeur ni action possible |
| M2 | **« Le cours de ce soir est capturé — même sans son nom »** | Sortie de cours : bouton unique → filmer ou noter → rattacher **si je sais à quoi**, sinon « plus tard » ; hors ligne, < 1 min | Aucun lieu pour le savoir personnel ; et rien n'existait pour un savoir pas encore nommé |
| M3 | **« La fiche à deux voix »** | Sur o-soto-gari : ce que dit le **référentiel** (sourcé, stable) et ce que dit **mon carnet** (ma vidéo de mardi, la variante du prof) — distincts, au même endroit | Une seule fiche indifférenciée ; toute annotation contaminait le référentiel |

M3 est la **provenance rendue visible** (vision §7.2) : ce n'est pas une
fonctionnalité de plus, c'est le modèle métier qui devient une expérience.

### 1.1 Ce que M1 est vraiment (challenge session 5)

**[DÉDUCTION]** La valeur de M1 n'est **pas** le pack Kodokan : c'est la
propriété « **l'app n'est jamais vide de sens à l'ouverture** ». Le Kodokan en
est la première démonstration (et le seul référentiel de qualité existant
aujourd'hui — un actif, pas un principe). Le mécanisme réel de M1 :

1. **Aucun contenu embarqué** (D-017) : les packs (Kodokan, club…) se
   distribuent séparément et s'installent **volontairement**, en un geste,
   depuis l'accueil. L'app vide n'est jamais bloquée : capturer, importer,
   ou créer sa discipline.
2. **Le carnet est utile sans référentiel** — conséquence structurante : pour
   un **karatéka** (aucun référentiel public aujourd'hui), la V3 vaut dès la
   première capture ; sa bibliothèque naît de son entraînement, fiches créées à
   la volée, provenance `personnel`. Le référentiel est un **accélérateur,
   jamais un prérequis** — l'inverse exact de la V2. La fiche doit donc être
   conçue *aussi* pour le cas « carnet seul » (une voix, pas deux).
3. **Le référentiel d'un club est un import de premier rang** : un coach qui
   diffuse son programme = un `.movpack` (provenance `enseignement`) importé en
   un geste depuis l'accueil — même mécanique que le Kodokan, pas un parcours
   d'administration.
4. **Tablette de dojo** (consultation partagée) : scénario *couvert* par la
   distribution de packs (une bibliothèque sans captures personnelles), mais
   **hors périmètre de conception** tant qu'il n'est pas un usage observé
   (D-006 : pas de gouvernance anticipée).

**Conséquence sur le périmètre incrément 1** : l'onboarding discipline (1) et
le cas « carnet seul » (2) entrent dans l'incrément ; l'import club (3) est
déjà couvert par « importer un .movpack » ; (4) n'ajoute rien à construire.

## 2. Le parcours cœur (révisé)

**[DÉDUCTION — challenge session 5]** Le premier réflexe en sortant du tatami
n'est pas « chercher une technique » : c'est **« retenir / retrouver ce que je
viens d'apprendre »** — souvent sans en connaître encore le nom canonique
(l'index mental du pratiquant est temporel et situationnel : « ce que le prof a
montré mardi », pas « Sasae-tsuri-komi-ashi »). La recherche par nom est le
réflexe du moment **froid** (préparer, vérifier, explorer le référentiel), pas
du moment **chaud**. Le parcours s'organise donc sur deux moments :

- **Chaud (sortie de cours)** : capturer, sans friction, **sans obligation de
  nommer** — le rattachement est optionnel, une capture non rattachée va dans
  « à rattacher » et se raccroche plus tard, quand le référentiel ou le prof
  donne le nom.
- **Froid (dans la semaine)** : **reprendre** — le fil des captures récentes
  (groupées par séance) est la porte d'entrée de l'accueil ; la recherche et le
  référentiel viennent ensuite.

```mermaid
flowchart TD
    subgraph chaud [Moment chaud — sortie de cours]
      K((+ Capturer)) --> K1{Filmer ou noter}
      K1 --> K2[Contenu]
      K2 --> K3{Rattacher ?}
      K3 -->|je sais à quoi| K4[Technique existante<br/>ou créée à la volée]
      K3 -->|« plus tard »| K5[À rattacher<br/>capture sans nom]
    end

    subgraph froid [Moment froid — dans la semaine]
      B[Accueil = Reprendre<br/>fil des séances récentes] --> C[Fiche technique<br/>référentiel + mon carnet]
      B --> B2[À rattacher] -->|nom retrouvé| C
      B --> R[Recherche dans le référentiel] --> C
      C -->|techniques liées| C
    end

    K4 --> B
    K5 --> B2
    B --> E[Échanger<br/>export / import .movpack]
```

## 3. Écrans de l'incrément (révisés)

1. **Premier lancement** (D-017) — pas d'écran d'onboarding : l'accueil vide
   est lui-même actionnable (capturer / importer un pack / créer sa discipline).
2. **Accueil = Reprendre** — le fil des captures récentes par séance en tête
   (dont les « à rattacher », visibles et actionnables), puis recherche et
   accès au référentiel. Bouton « + Capturer » permanent.
3. **Feuille de capture** — 3 gestes maximum : contenu (filmer/noter) →
   rattachement **optionnel** (suggestion contextuelle si une fiche est
   ouverte, recherche, création à la volée, ou « plus tard ») → confirmation.
4. **Fiche technique** — une ou deux voix selon le cas : *Référentiel* (si la
   technique en vient) et *Mon carnet* ; techniques liées à inverse dérivé.
5. **Échanger** — export/import `.movpack` (bibliothèque ; l'import couvre le
   référentiel d'un club).

Le détail visuel : prototype (D-008), conçu pour être invalidé à bas coût.

## 4. Modèle de données de l'incrément (rappel visuel du contrat §2)

Le rattachement optionnel ne change pas le modèle : une capture non rattachée
est une contribution `personnel` dont la technique cible n'est pas encore
choisie (état « à rattacher » porté par la contribution, pas par une entité
nouvelle).

```mermaid
erDiagram
    DISCIPLINE ||--o{ TECHNIQUE : contient
    DISCIPLINE {
        string id ULID
        string nom
        json taxonomie "familles, niveaux"
    }
    TECHNIQUE ||--o{ CONTRIBUTION : recoit
    TECHNIQUE ||--o{ RELATION : source
    TECHNIQUE {
        string id ULID
        string nom
        string nomTraditionnel "optionnel"
        string famille
        string[] niveaux
    }
    CONTRIBUTION ||--o{ MEDIA : porte
    CONTRIBUTION {
        string id ULID
        string techniqueId "nullable : capture a rattacher"
        string provenance "referentiel | enseignement | ressource | personnel"
        string description
        string[] pointsCles
        string attribution "source, pour referentiel/ressource"
        date creeLe
    }
    MEDIA {
        string id ULID
        string type "local | lien | plateforme"
        string ref "ULID fichier + sha256, ou URL/id"
    }
    RELATION {
        string cible "id technique, absence toleree"
        string type "prepare | enchaine | contre | similaire"
    }
```

## 5. Critères de recette (Validation 4)

La recette mesure les hypothèses, pas seulement l'absence de bugs :

- **H1 (capture)** : sur plusieurs cours réels, la capture est effectivement
  faite, hors ligne, en < 1 min, sans agacement — **y compris sans connaître le
  nom** (le « plus tard » est utilisé et les captures sont réellement
  rattachées ensuite, pas abandonnées dans la boîte).
- **H2 (utile à l'ouverture)** : l'accueil « Reprendre » donne envie de rouvrir
  l'app dans la semaine ; la consultation référentiel tient pour le moment froid.
- **M3** : la séparation référentiel / carnet est comprise sans explication.
- **Portabilité** : export téléphone → import PC (web), round-trip sans perte.
- **Fondations** : checklist appareil (contrat §9.2.4) verte ; cohérence des
  données du pack converti.

## 6bis. Matrice de conservation des qualités (D-012)

> Règle : aucune qualité existante ne se perd « par défaut ». Ce tableau est
> tenu à jour à chaque lot ; « sacrifiée » exige une justification.

| Qualité (origine V2) | Sort en V3 | Détail / justification |
|---|---|---|
| Exploration visuelle (grille, miniatures) | **Conservée** (restaurée session 9) | Explorateur de discipline en grille à vignettes (miniatures YouTube pour les médias référencés ; initiale serif sinon). |
| Filtres cumulables (famille / niveau / recherche) | **Conservée** (restaurée session 9) | Chips ceinture + famille + filtre par nom, cumulables. |
| Couleurs de ceintures (identité visuelle des niveaux) | **Conservée** (perte silencieuse réparée) | Réintégrées au modèle (`Niveau.couleur/couleur2`), au convertisseur, aux données et à l'UI (pastilles). |
| Variantes sur la fiche | **Conservée** (perte silencieuse réparée) | Champ `Contribution.variantes`, affiché en italique sous les points clés. |
| Miniatures **hors ligne** (V2 : générées localement) | **Sacrifiée pour les contenus référencés** | Les vidéos Kodokan/club sont des références en ligne jamais téléchargées (invariant + droits) : leurs vignettes le sont aussi. Hors ligne → placeholder propre. Les captures locales pourront avoir une vignette locale générée (prévu, non fait). |
| Chapitres de vidéo | **Différée** | Aucune donnée réelle n'en contient (vérifié sur les deux packs). À modéliser quand un contenu en aura. |
| Types de vidéo (taxonomie `typesVideo`) | **Sacrifiée** | Une seule valeur réelle (`demo`) dans toutes les données V2 ; le label libre du média suffit. À rouvrir si un vrai besoin de typologie apparaît. |
| Favoris (cœur + filtre) | **Différée (incrément 3)** | La couche perso V3 (systèmes) englobe ce besoin ; le carnet couvre déjà « mes techniques » d'une autre façon. |
| Contrôles vidéo custom (vitesse, pas-à-pas) | **Différée** | V2 les avait pour vidéos locales. À évaluer après la recette (besoin réel ?). |
| Thème dual + accent | **Sacrifiée (pour l'instant)** | Un seul thème clair/sombre auto — refondu en D-020.6/D-021 (encre/washi, accent vermillon). La personnalisation d'accent reste du confort ; à rouvrir sur demande terrain. |
| Sauvegardes consultables / restauration UI | **Conservée (D-020, session 16)** | Snapshots automatiques + liste restaurable à l'Atelier ; l'état courant est lui-même snapshoté avant restauration. La vraie sauvegarde de long terme = « Exporter tout » (.movpack, restauration prouvée en e2e — R8 levé). |
| Plusieurs médias par technique + **choix du média principal** | **Conservée (D-020, session 16)** | `Technique.mediaPrincipalId` + sélecteur en édition de fiche ; fallback : premier média sourcé. |
| Édition complète d'une technique | **Conservée — contextuelle (D-020, session 16)** | Sur la fiche : nom, appellation, famille, niveaux, média principal, carnet ; taxonomies et types de relation à l'Atelier. Jamais de formulaire administratif général (choix assumé). |
| Gestion des médias manquants / orphelins | **Conservée — diagnostic (D-020, session 16)** | L'Atelier signale les vidéos locales référencées absentes de l'appareil, avec action (ouvrir la fiche, restaurer un export). |
| Import/export à plusieurs granularités | **Conservée en partie (D-020, session 16)** | Export complet restaurable + pack par discipline (sans carnet). **Différé** : export d'une technique seule ou d'une sélection — à ouvrir si la recette en montre le besoin. |
| Historique CSV des modifications | **Sacrifiée** | Fonction centrale de l'admin V2 sans décision associée ; la traçabilité passe par les snapshots (10) et l'origine des éléments importés. Un vrai journal de modifications reste possible plus tard si un besoin de gouvernance l'exige. |
| Modifications d'ensemble (masse) | **Différée** | L'Atelier v1 couvre taxonomies, types, diagnostics, publication ; le traitement en masse attend un corpus réel qui le réclame (éviter le produit-dans-le-produit). |
| Gouvernance (PIN, rôles, journal d'activité, auto-logout) | **Sacrifiée (D-006)** | Construite en V2 pour un contexte club jamais observé ; un appareil = un propriétaire. Réintroduction uniquement sur usage observé. |
| Curation lourde (construire/réorganiser taxonomies, médias, relations en masse — l'admin-panel V2) | **Tranchée par D-020.3 : Atelier v1 (session 16)** | L'Atelier existe (grand écran, même code, distinct du quotidien) : diagnostics actionnables, taxonomies, types de relation, publication, sauvegardes, réglages. La tension mobile/atelier (D-019) reste surveillée : les **modifications d'ensemble** sont différées jusqu'à un besoin réel (ligne dédiée). |
| Notice utilisateur embarquée (bouton « ? ») | **Différée** | Valeur réelle en diffusion ; l'incrément vise un utilisateur qui participe à la conception. À créer avant toute distribution à des tiers. |
| Avertissement sécurité de la pratique (contenu) | **Conservée (à poser)** | Décidé au contrat §8 ; à intégrer à l'app avant recette élargie ou diffusion. |
| Écran Accueil (V3 sessions 8-21 : Reprendre, recherche, import) | **Supprimé (lot 1, roadmap)** | Redistribué avant suppression (lot 1 §11) : recherche globale et disciplines → racine Bibliothèque ; import/création → Bibliothèque vide et Atelier ; compositions et captures « à rattacher » → Pratique ; réglages → Atelier. Aucune donnée créée depuis l'Accueil n'est supprimée. |
| Fil « Reprendre » des notes rattachées (historique récent) | **Sacrifiée (lot 1 §5)** | « À reprendre » (Pratique) ne liste que l'inachevé — jamais un historique de consultation ou de notes récentes (prescription explicite du lot). La préférence `repriseMasquees` est conservée dans les données. |
| Capture immédiate sur installation totalement vide | **Différée (lot 4 §2)** | Plus de bouton global « Capturer » (lot 1 §7) : sur une installation vide, créer/importer d'abord ; le lot 4 réintroduit « Filmer ou garder quelque chose » depuis la racine Bibliothèque. Dès qu'une discipline existe, « ＋ Ajouter » couvre la capture. |
| Bouton global « Capturer » (FAB permanent) | **Supprimé (lot 1 §7)** | Remplacé par l'action contextuelle par écran : « ＋ Ajouter » sur une discipline (flux existant, présélectionné), actions locales de la fiche — et, jusqu'à la boucle 5.7, capture-repère dans l'édition de composition (ligne dédiée). |
| Import/création en façade permanente de la racine Bibliothèque | **Retiré de la façade (lot 2 §3, boucle 2.0)** | Conservés dans l'état vide de la Bibliothèque, l'état vide d'une discipline (lot 2 §11) et l'Atelier (Protéger / Construire). |
| Fil « Reprendre » avec masquage ✓ (préférence `repriseMasquees`) | **Différée (lot 5)** | Donnée conservée ; l'UI du « fini » disparaît avec l'Accueil ; « À reprendre » (Pratique) ne liste que l'inachevé. |
| Vidéo en tête de fiche (V2) | **Conservée (lot 3 §3)** | Média principal en tête avec légende éditoriale « auteur · provenance » ; fallback actionnable si aucun média. |
| Plusieurs médias par technique (V2) | **Conservée (lot 3 §4-5)** | Galerie compacte + feuille « Ajouter un média » (filmer/fichier/lien) depuis la fiche ; « Utiliser comme aperçu principal » explicite. |
| Voix multiples par identité (V3) | **Conservée (lot 3 §7)** | Accordéon — une seule ouverte à la fois, titres « Provenance · auteur », ordre éditorial ; rien n'est fusionné. |
| Amendement inline des contributions sourcées (V3 sessions 8-21, D-024) | **Supprimée — remplacée (lot 3 §8, décision humaine D-027)** | L'original importé est intact (garde applicative comprise) ; le chemin de modification devient « Créer une adaptation locale » préremplie et attribuée, jamais écrasée au réimport. |
| Édition directe du carnet personnel | **Ajoutée (lot 3 §9)** | Note ajoutée/modifiée/supprimée sur la fiche sans passer par Capturer ; indexée par la recherche. |
| Formulaire monolithique d'édition (V2) | **Non repris (lot 3 §10/§16)** | Édition contextuelle sauvegardée au fil de l'eau, fermée par « Fermer » — le bouton « Terminer » est supprimé : il laissait croire à une sauvegarde différée qui n'existait pas. |
| Longue liste de relations en bas de fiche (V2) | **Transformée (lot 3 §11)** | Accès compact « Relations · N », aperçu de 3, « Voir toutes les relations ». |
| Actions destructrices en façade de fiche | **Déplacées (lot 3 §15)** | Retrait dans le menu ⋮ avec confirmation nommant les compositions dépendantes ; snapshot préalable. |
| « À rattacher » réservé au savoir personnel (increment-1 §2, invariant de validation) | **Remplacée (lot 4 §9)** | Une capture d'enseignement ou de ressource se garde aussi « pour plus tard » : provenance conservée, attribution toujours exigée pour le sourcé, jamais publiée automatiquement, reprise depuis Pratique > À reprendre. |
| Provenance demandée à CHAQUE capture (chips systématiques à l'étape note) | **Remplacée (lot 4 §8)** | Personnel par défaut, silencieusement ; « Ce contenu vient de quelqu'un d'autre » en action secondaire ouvre prof/club/ressource. Le rôle « référentiel » n'est pas offert à la capture (aucun rôle de curation représentable — cohérent D-062). |
| Création complète d'une technique (formulaire V2) | **Conservée sous forme progressive (lot 4 §4/§13)** | Nom seul suffit ; appellation et « Classer maintenant » facultatifs ; enrichissement ensuite depuis la fiche. Classification OBLIGATOIRE supprimée — l'incomplétude est acceptée, signalable à l'Atelier. |
| Capture rapide V3 (3 gestes) | **Conservée et renforcée (lot 4 §6)** | Le contenu d'abord ; un APERÇU s'intercale (Utiliser / Refilmer / Abandonner) — rien ne s'écrit avant la fin. |
| Rattachement différé (« à rattacher ») | **Conservé et complété (lot 4 §9)** | Reprise complète : consulter, modifier le texte, rattacher, supprimer avec confirmation ; ouvert à toute provenance. |
| Ajout direct depuis la fiche | **Conservé et étendu (lot 4 §11)** | « Ajouter un média » (lot 3) + « Ajouter une contribution » (texte et/ou média, de qui, attribution) — jamais de re-demande de technique. |
| Favoris (cœur + filtre) V2 | **Conservée (lot 5 §4-6)** | Marque-pages purs vers les identités : étoile sur la fiche, liste dans Pratique, sauvegardés/restaurés, jamais publiés. |
| Compositions V3 (8 types de blocs) | **Conservée et simplifiée (lot 5 §8)** | Deux ajouts visibles (technique / texte) ; les huit types restent en DONNÉES (anciens blocs lisibles, jamais migrés de force, préservés à l'export). |
| « À reprendre » | **Conservé, strictement inachevé (lot 5 §3)** | Jamais un historique de consultation ; aperçu compact + « Voir tout ». |
| Duplication de contenu dans les compositions | **Interdite explicitement (lot 5 §18)** | Dupliquer une composition crée de nouvelles RÉFÉRENCES ; aucune technique ni média copié. |
| PIN V2 (connexion Admin OBLIGATOIRE avant les opérations) | **Transformé (lot 7)** | Le PIN devient une protection FACULTATIVE d'appareil : modification libre par défaut (appareil personnel), deux protections indépendantes activables (modifications / suppressions et opérations sensibles), déverrouillage AU POINT D'ACTION avec reprise automatique — plus jamais d'écran de connexion. |
| Rôles Admin/Contributeur, gouvernance V2 | **Non repris (lot 7, D-006 confirmée)** | Ni comptes, ni profils, ni rôles : un seul PIN local, une session curateur temporaire. La tablette partagée est un PRÉRÉGLAGE des deux protections, pas un rôle. |
| Session Admin persistante (V2) | **Supprimée (lot 7 §8)** | La session curateur vit en mémoire seulement : inactivité 5/15 min ou jusqu'à l'arrière-plan, verrouillage manuel, jamais persistée ni sauvegardée. |
| Code de récupération V2 | **Non repris (lot 7 §13)** | Aucun besoin démontré ; « PIN oublié » = voie honnête (réinstaller + restaurer une sauvegarde, ou réinitialiser) — ni question secrète, ni porte dérobée. |
| Confirmation + sauvegarde avant destruction | **Conservées et renforcées (lot 7 §2)** | Le PIN ne remplace JAMAIS la confirmation destructive — il arrive AVANT elle ; les snapshots motivés restent. |
| Secrets dans les exports | **Exclus par construction (lot 7 §21)** | Les protections vivent dans les préférences d'appareil, jamais exportées (prouvé en unit) ; restaurer sur un autre appareil demande une reconfiguration. |
| Remise à zéro (V2 : dispersée) | **Unifiée (lot 7 §22)** | Réinitialisation complète : PIN si protégé, explication, sauvegarde proposée, confirmation renforcée — bibliothèque, vidéos, snapshots, préférences et PIN supprimés ensemble. |
| Tableau de bord Admin V2 (KPI denses, statistiques) | **Non repris (lot 6 §4)** | Remplacé par une SYNTHÈSE actionnable en tête d'Atelier : uniquement des problèmes cliquables ouvrant leur workflow ; sans problème, une mention compacte — jamais de KPI décoratif ni d'écran de tableau de bord. |
| Construction des disciplines, catégories et niveaux (Admin V2) | **Conservée et renforcée (lot 6 §5-8)** | Cartes de discipline (compteurs, sources, réordonnancement, ouverture Bibliothèque), taxonomies ordonnables avec couleurs de ceinture, suppression avec arbitrage des usages — jamais de référence invalide. |
| Suppression de discipline non vide (V2 : impossible / V3 : refus simple) | **Transformée (lot 6 §7, boucle 6.2)** | « Préparer la suppression… » : contenu réel présenté, export préalable proposé, confirmation renforcée, snapshot motivé ; notes personnelles préservées « à rattacher ». |
| Gestion des médias (Admin V2) | **Conservée sous forme sûre (lot 6 §13-14)** | Diagnostics d'intégrité + médiathèque (tailles, références, état) ; fichiers orphelins supprimables UN PAR UN après prévisualisation obligatoire ; un média référencé ne se supprime jamais. |
| Historique / export CSV détaillé (V2) | **Sacrifié comme fonction centrale (lot 6 §22)** | Les snapshots motivés lisibles + la sauvegarde complète .movpack couvrent le besoin réel ; aucun CSV reconstruit. |
| Rollback (V2) | **Conservé et rendu lisible (lot 6 §24)** | « ↺ date · motif » au lieu d'un id ; la confirmation explique ce qui sera remplacé, dit que les snapshots n'incluent PAS les vidéos (tracé 8C), et l'état courant est re-snapshoté (retour annulable). |
| Publication confondue avec l'export (V2/V3 précoce) | **Séparée explicitement (lot 6 §16/§19-21)** | Quatre gestes distincts ; publication = corpus distribuable borné aux sources maîtrisées avec métadonnées éditoriales et prévisualisation exacte ; sauvegarde = installation complète (favoris compris). |
| Réglages de sécurité / PIN (V2) | **Différée au lot 7 (lot 6 §25)** | L'état RÉEL est affiché (« Aucune protection active — modification libre ») sans aucun contrôle factice ; la sémantique V2 n'est pas reprise ici. |
| Suppression d'un type de relation UTILISÉ (rupture consentie : relations retirées en masse avec snapshot) | **Remplacée (lot 6 §10, boucle 6.4)** | La suppression n'est permise QUE si le type est inutilisé — refus actionnable sinon (« retire-les d'abord des fiches concernées ») : plus aucune suppression de relations en masse depuis l'Atelier. Renommage des libellés et bascule de symétrie (si inutilisé) ajoutés. |
| Capture-repère depuis l'éditeur de composition (lot 1 boucle 1.4) | **Supprimée (boucle 5.7, décision humaine 2026-07-13)** | L'éditeur n'expose que deux constructions (Ajouter une technique / Ajouter du texte). Les blocs repère EXISTANTS restent lisibles, exportés et intacts ; le workflow de capture du lot 4 est inchangé — la capture vit sur « ＋ Ajouter » (racine, discipline) et sur la fiche. |

## 6ter. Hors de l'incrément (rappel)

Préparation de grade (incrément 2), systèmes personnels (3), révision (4),
édition du contenu référentiel, provenances `enseignement`/`ressource` dans
l'UI de capture (le modèle les porte ; l'import de packs couvre `enseignement`),
scénario tablette de dojo (couvert par les packs, pas conçu — usage non observé).
Si cette réduction menace la démonstration de valeur en recette : proposer une
évolution de périmètre (D-007), pas s'y accrocher.
