> **ARCHIVE (session 22, 2026-07-12).** Protocole de session des phases de
> conception (1-7, jusqu'à la dictée de la roadmap). Remplacé à la racine par
> le protocole d'exécution autonome (`CLAUDE.md` + `docs/execution/`) pour la
> durée de la roadmap. **À restaurer une fois la roadmap terminée** (décision
> de Yahya, session 22).

# Movenso V3 — protocole de session (agents)

Dépôt de conception et développement de **Movenso V3** (bibliothèque
offline-first de techniques d'arts martiaux). La mission complète et son
autorité : [MISSION-movenso-v3.md](MISSION-movenso-v3.md).

## Démarrage de session — ordre de lecture obligatoire

1. **[docs/etat.md](docs/etat.md)** — phase courante, prochaines actions,
   questions ouvertes. Il désigne les lectures complémentaires ; ne rien lire
   d'autre par défaut.
2. [docs/conventions.md](docs/conventions.md) — règles du dépôt (statuts,
   marqueurs épistémiques, git, protocole de session) si non déjà connues.

Ne pas relire la mission ni les analyses V2 en entier à chaque session :
`etat.md` dit ce qui est nécessaire.

## Règles non négociables

- **Dépôt V2 (`prettozm/movenso`) : lecture seule absolue.** Pour l'analyser :
  le recloner, ou extraire `movenso-main.zip` (racine) dans le scratchpad —
  jamais dans ce dépôt.
- **Branche de travail** : `claude/movenso-v2-mission-ynb4ig`. Ne jamais pousser ailleurs.
- **Pousser avant toute fin de session, pause ou demande de validation.**
  Le conteneur est éphémère : tout travail non poussé est perdu.
- **Aucun contenu NON VALIDÉ ne se lit comme une décision.** Seul l'humain
  (Yahya) valide. Les décisions vivent dans [docs/decisions.md](docs/decisions.md).
- **Aucune copie mécanique de code ou d'architecture V2** (décision D-003) :
  tout emprunt conceptuel se justifie par sa valeur.
- Distinguer systématiquement `[FAIT] [DÉCISION V2] [DÉCISION] [DÉDUCTION]
  [HYPOTHÈSE] [RECO]` dans toute production d'analyse ou de proposition.

## Fin de session

1. Mettre à jour `docs/etat.md` (+ `docs/decisions.md` si décisions nouvelles).
2. Committer (messages français, préfixes `docs:` `decision:` `code:` `test:`
   `build:` `etat:`) et pousser avec `git push -u origin claude/movenso-v2-mission-ynb4ig`.
