> **ARCHIVE (S3.A13, 2026-08-02)** — copie intégrale de `docs/execution/STATE.md`
> tel qu'il était devenu : un historique-fleuve. Le présent vit désormais dans un
> `STATE.md` court ; RIEN n'a été perdu, tout est ici. Le journal des décisions
> (`docs/execution/DECISIONS.md`) reste la mémoire du POURQUOI.

# STATE — Mémoire de reprise

## Situation générale

- Branche : **`claude/movenso-v2-mission-ynb4ig`** (branche de travail désignée, repartie de `main`) — phase de finition bêta post-V3.
- Commit de départ (roadmap V3) : `d94e215`.
- Dernier commit vert : voir `git log` (dernier en date : **unification et mise à jour de toute la doc V3 — audit + carte documentaire unifiée + règle anti-retard, D-128** ; avant : partage embarque les techniques + opt-in séances perso, D-127 boucle 5).
- **Phase courante : STABILISATION V1 (D-161, 2026-08-01).** L'audit externe [`audit-stabilisation-v1.md`](audit-stabilisation-v1.md) est la référence, loti en 3 lots : **S1** (P0 — sécurité/intégrité/plateforme) → **S2** (P1 — parcours) → **S3** (P2-P4 — dette/publication/finitions), fichiers dans `lots/`. **Gel fonctionnel** tant que S1+S2 ne sont pas clos. **Lot courant : S1 — ARBITRÉ (D-162), exécution ouverte.** Ordre : S1.2 → S1.1 → S1.9 → S1.10 (instruction) → S1.3 → S1.4 → S1.5 (instruction) → S1.6 → S1.7 → S1.11 → S1.12 ; S1.8 en discussion. S1.2 **livré** (garde-fou dist, REC-S1-002). Arbitrages D-163 : S1.8 = option B (promesse réduite), plan S1.9 validé, S1.10 reporté en dossier séparé fin de lot. S1.1 **livré** (engines npm, artefact CI `movenso-web-<sha>` + SHA256SUMS, règle de publication versions.md §4, REC-S1-001). S1.9 boucle 1 **livrée** (constat corrigé : persist() était déjà demandé mais en aveugle — résultat désormais lu et affiché, carte Espace + bouton redemander, REC-S1-009). S1.9 boucle 2 **livrée** (instruction : capture et confirmations étaient couvertes, l'export et le staging d'import NON → garde avant le temporaire d'export au quota système, borne basse à l'import ; 8A.4 réécrit en préservant §10 ; REC-S1-009b). **S1.9 CLOS.** S1.3 **livré** (validateur central `securite/liens.ts`, https seul par défaut D-164, 5 puits gardés, 15 unit + e2e, REC-S1-003) — **S1.3 CLOS.** S1.4 **livré** (LIMITES_MOVPACK, chemins sûrs explicites, doublons refusés, liste blanche d'extensions + signatures exécutables, corpus hostile 11 tests, D-165, REC-S1-004) — **S1.4 CLOS.** S1.5 **ARBITRÉ B+C (porteur) et LIVRÉ** (rollback des médias promus sur échec de persistance + orphelins signalés au démarrage, D-166, REC-S1-005 ; limite ZIP64 à l'écriture consignée pour KNOWN_LIMITATIONS). **S1.5 CLOS.** S1.6 **livré** (certification e2e sur corpus de référence Unicode complet : restauration complète = identité objet par objet + SHA-256 des vidéos ; légère = données intactes, zéro vidéo ; tronquée refusée ; restauré/pas-restauré documenté, REC-S1-006) — **S1.6 CLOS.** S1.7 **livré** (7 tests unit à sentinelles par format + scan e2e du fichier réel : pseudo/PIN/preferences jamais dans l'archive, REC-S1-007) — **S1.7 CLOS.** S1.8 **livré** (promesse réduite exacte : À propos, package.json, kicker du site, systeme.md §1 ; confidentialité déjà exacte ; REC-S1-008) — **S1.8 CLOS.** S1.11 **livré** (connecteurs Mindmap en SVG typés — rendu identique, gel respecté ; garde statique verifier-sources dans verifier+CI : innerHTML/insertAdjacentHTML/document.write/eval interdits, exceptions vides ; REC-S1-011) — **S1.11 CLOS.** S1.12 **livré** (inventaire : replis légitimes partout ; complété par `dernierEchec` consigné aux catch critiques + erreurs non gérées, section « Dernier échec » du diagnostic, REC-S1-012) — **S1.12 CLOS. CHECKPOINT LOT S1 (2026-08-02) : `npm run verifier` COMPLET VERT — typecheck + garde sources + 201 unit + build + garde dist + e2e zéro erreur JS (commit `ef8aa01`, CI verte, app déployée). 11/11 chantiers exécutables clos. S1.10 **ARBITRÉ (porteur) : option 1 LIVRÉE** (garde généralisée getDirectory+createWritable, messages par plateforme, écran non-supporté propre, e2e deux simulations — D-167, REC-S1-010) ; options 2/3 restent à discuter (post-v1). **LOT S1 : 12/12 CLOS, checkpoint vert, app déployée.** États S2 re-vérifiés (S2.5 clos — préréglage déjà livré ; S2.13 largement fait par S1.9 ; S2.8 occurrences localisées). **Lot courant : S2 — ARBITRÉ (D-168), exécution ouverte sur les points approuvés.** S2.5 clos (code mort purgé) ; S2.13 rayé ; S2.1 (pour/contre) et S2.2 (détail) soumis au porteur. S2.8 **livré** (feuille Sauvegardes + aide À propos + recette-beta reformulées ; corbeille gardée sciemment ; REC-S2-008) — **S2.8 CLOS.** S2.11 **livré** (domaineDe testé ; les 2 seules sorties externes signalées : domaine visible + « Quitte Movenso » ; REC-S2-011) — **S2.11 CLOS.** S2.14 **livré** (accroche + vide-par-choix + localité + chemin de sauvegarde à l'état vide, e2e ; starter à étudier avec le porteur ; REC-S2-014) — **S2.14 CLOS.** S2.7 **livré** (inventaire : schéma cohérent conservé ; 3 écarts corrigés — snapshot→point de restauration, verbe discipline vide, durée corbeille dite « sans limite » ; REC-S2-007) — **S2.7 CLOS.** S2.4 boucle 1 **livrée** (bouton Annuler sur le voile : export/sauvegarde + lecture de pack — estAnnule branché, abandon propre ; REC-S2-004). S2.2 **livré** (Terminer au dernier pas, résumé durée réalisée, auto-conclusion du dernier pas minuté, D-169, REC-S2-002) — **S2.2 CLOS.** S2.1 **arbitré : option V** (un seul écrivain, détection par chemin — boucle à venir). S2.4 boucle 2 **livrée** (ingestion vidéo annulable — analyse + écriture, brouillon jeté, REC-S2-004 complété) — **S2.4 CLOS.** S2.1 **livré** (option V : écrivain unique #pousserNouvelleTechnique, garde de doublon exact dans l'explorateur, capture jamais interrompue ; REC-S2-001) — **S2.1 CLOS.** S2.6 **livré** (impacts externes dits avant fusion ; point de restauration/défusion/test entrantes existaient déjà ; REC-S2-006) — **S2.6 CLOS.** S2.3 **livré** (recette Samsung A36 : phase A 6/6, B/C dérive confirmée → décision porteur D-170 : arrière-plan = séance SUSPENDUE + verrou d'écran pendant l'entraînement, D-93 levé ; e2e ; REC-S2-003) — **S2.3 CLOS** (contre-recette appareil 4/4 OK — écran maintenu, verrouillage → pause+bandeau+reprise, changement d'app idem, pause manuelle intacte). S2.12 **livré** (total affiché + rattachement d'un média retrouvé, REC-S2-012) puis **complété** : suppression groupée des orphelins VÉRIFIÉS approuvée par le porteur (D-171, précision de D-107) et livrée (bouton dès 2 vérifiés, compte + taille, revérification à l'instant T, e2e) — **S2.12 CLOS**. S2.9 **livré** (constat corrigé : plus de flèches nulle part, le glisser était le seul chemin — poignée devenue bouton clavier + boutons ▲/▼ nommés + annonce aria-live sur les 4 sites ; no-op « descendre » de la primitive contourné ; REC-S2-009) — **S2.9 CLOS** (TalkBack appareil à confirmer en recette). S2.10 **LIVRÉ côté code** (inventaire + 3 tranches : noms accessibles partout + garde e2e `champsTousNommes` ; modales réellement modales — Échap, aria-modal, focus entrant/rendu ; contraste AA vérifié par calcul 2 thèmes × 5 tonalités, cibles ≥ 24 px, zoom 200 % e2e ; REC-S2-010) — reste la **tranche 4 recette appareil** (TalkBack + clavier, avec le porteur, adossée à la contre-recette S2.3). S2.15 **livré** (campagne e2e : 5 onglets + 13 sous-écrans de Plus sur installation vierge, mode avancé + bêta révélés, zéro erreur JS ; workflows sur vide déjà démontrés un à un — inventaire REC-S2-015) — **S2.15 CLOS**. S2.16 **livré** (`npm run campagne:charge` : jeu P1.16 complet — 2 000 techniques/10 000 relations —, zéro erreur JS, aucun goulot : démarrage ~1 s, tout le reste < 250 ms, 34 Mo ; restes consignés REC-S2-016) — **S2.16 CLOS. S2.10 tranche 4 : traversée TalkBack abandonnée par le porteur (« une plaie » à exécuter) — remontées utilisateur font foi (D-172), fluidité au doigt CONFIRMÉE (Mindmap/Carte fluides, Explorer instantané) — **S2.10 CLOS. CHECKPOINT LOT S2 (2026-08-02) : 16/16 chantiers traités (13 livrés, S2.5 clos par purge, S2.13 rayé), recettes appareil terminées, `npm run verifier` COMPLET VERT (203 unit + e2e zéro erreur JS, commit `a94c8d8`), doc = réel, app publique déployée. LOT S2 : CLOS.** Trois remontées de recette Relations consignées au **lot S3 volet D** (D-173 : recentrage Mindmap, retour au « point de départ », Explorer incomplet) — à arbitrer avec S3, rien codé (gel). **Lot courant : S3 — ARBITRÉ (D-174 : analyse et ordre validés sur le principe, questions posées étape par étape).** Ordre : D1 → D2 → A6 → A12 → A13 → A1/A3 → A4 → A5 → A7+A8 → A10 → C2 → C3 → C4 → C5 → volet B (B2/B11 d'abord) → B4. C1/C6 rayés, A11 fusionné A10. S3.D2 **livré** (🎲 « Changer de point de départ » dans l'en-tête Relations — rouvre l'écran d'entrée, retour nommé, e2e ; D-175, REC-S3-D2) — **S3.D2 CLOS.** S3.D1 **instruit : le recentrage Mindmap EXISTE** (toucher une carte recentre + loupe « Rechercher une technique à centrer » — démontré) → **question posée au porteur** (découvrabilité ? panne appareil ? autre attente ?), rien codé en attendant. S3.A6 **livré** (`sourceDe` remonté dans `domaine/modele.ts`, 5 consommateurs rebranchés ; ordre des couches `app → echange|stockage|securite → domaine` formalisé et GARDÉ par `verifier-sources` — test négatif démontré ; D-176) — **S3.A6 CLOS.** S3.A12 **livré** (anomalies instruites une à une : double-suppression NON confirmée, toast « dupliqué » = texte copié → factorisé, reliquat Reprendre purgé — 3 fonctions + préférence + CSS mort —, imports inutilisés : rien ; D-177) — **S3.A12 CLOS.** **Prochaine boucle : S3.A13 (STATE.md court, historique en archives).**** Phase précédente (FINITION BÊTA, D-067 → D-160) close ; sa mémoire est DECISIONS.md.
- **État bêta (2026-07-19)** : la **vidéo locale est autorisée** en bêta. Le fil rouge « fichier entier en RAM » est désormais **soldé** : capture/hash (D-111), sauvegarde/partage natifs par blocs (D-111), et **import/restauration en flux** (D-114, fflate `Unzip` → staging OPFS vérifié → promotion à la confirmation). Signature APK **éphémère** assumée (D-113 ; testeurs : exporter une sauvegarde avant chaque mise à jour). Commentaire de fiche **lecture seule dès qu'un PIN existe** (D-115).
- **Réserves connues non tenues à 100 %** (process) : QUALITY.md n'a pas de recettes pour la phase bêta ; couverture partielle sur quelques comportements natifs Android (non atteignables en e2e web : garde de démarrage D-110, enregistrement `Filesystem` D-106/D-111) ; e2e = un monolithe + sleeps mis à l'échelle (D-103, dette poll notée). Voir DECISIONS et note-modele-donnees §7bis (backlog).
- Correctif nav (2026-07-27) : onglet Relations qui rebondissait vers la Bibliothèque — cas `relations` oublié dans `#allerRacine`, corrigé + régression e2e (D-139).
- **Remise en ordre Relations (2026-07-29, D-140)** : (1) **rôles rétro-appliqués** aux types par défaut déjà persistés — **migration schéma 3 → 4** (`retroRolesDefaut`), sans quoi tout retombait sur `peer` (Explorer réduit à « comparer », « Enchaîné depuis » vide) sur les installs d'avant D-136 ; (2) **fil d'Ariane masqué dans la Liste** (doublon perçu avec les vraies relations, désormais visibles dans « Enchaîné depuis ») — conservé sur Carte/Explorer ; (3) **Carte réécrite en mindmap HTML** (vignettes + courbes colorées, lisible par défaut) avec **pan/zoom/pincement par `transform` CSS**, remplaçant le canevas 100 % SVG jugé illisible. `verifier` vert 166 + build + e2e ; confirmé visuellement (Explorer 4 intentions, « Enchaîné depuis » 11, Carte hub centré). **Schéma de données courant : 4.**
- **Comparaison UX Relations (2026-07-29, D-141→D-143)** : l'écran Relations a **4 onglets : Liste · Carte · Mindmap · Explorer** (id de vue `classique` pour la Mindmap ; `mindmap` = la Carte). La **Carte** (D-140) est la vue HTML pan/zoom ; la **Mindmap** est désormais **radiale fidèle au prototype** (D-143 structure → D-144 rendu) : technique au centre (hub + badge « N relations »), une **branche par rôle** autour (variantes haut · précurseurs gauche · suites droite · fondamentaux/kata + contres sous le centre), reliée par des **flèches courbes colorées**, **grandes cartes VERTICALES** (vignette + badge de rôle + nom + famille) et **libellés flottants colorés**, **sans numéros**, grille fluide (pas de scroll horizontal). Étapes rejetées par le porteur : timeline verticale (D-142, numéros + rail) puis radial trop « plat » (cartes horizontales, D-143). Les deux vues graphe (Carte D-140 / Mindmap) coexistent **temporairement** — arbitrage à venir. `verifier` vert 165 + build + e2e.
- Dernière mise à jour : **2026-08-01** (**D-161 : pivot STABILISATION V1 — audit adopté, roadmap écartée, lotissement S1/S2/S3 avec états vérifiés contre le code, gel fonctionnel, arbitrage point par point ; S1 soumis au porteur**) ; précédent **2026-07-31** (**D-160 : Carte passe 2 — texte vraiment complet (≈22 car./ligne, 8 lignes), anti-chevauchement CONVERGENT (séparation symétrique, 0 chevauchement à 40 cartes), « +N autres » déplié SUR PLACE (plus de renvoi vers la Liste), fil d'Ariane retiré de la Carte (Explorer seulement), cause racine des taps perdus corrigée (capture du pointeur au seuil de glissement, plus jamais dès pointerdown)** ; **D-159 : Carte — cartes qui grandissent avec leur raison (fini le tronqué), fond uni, ⊞ tout déplier/replier, chips légende+filtre par famille, interdiction de chevauchement (séparation déterministe)** ; **D-158 : Carte multi-niveaux — dépliage « +n »/« − » sur place (4 enfants max par nœud, plafond 40, jamais de doublon, niveau 2 atténué), couleurs before=vert/after=bleu alignées partout ; les DEUX vues graphe actées et spécialisées (Mindmap = synthèse, Carte = exploration)** ; **D-157 : import — conflits de liaisons détectés et arbitrés (la mienne / celle du pack / les deux), rapport d import + écran d arbitrage dans Plus › Relations** ; **D-156 : éditeur de relations — feuille « Lien » (créer/éditer/retirer une arête, raison + priorité) avec 4 portes d entrée : fiche, Relations›Liste, état vide, Plus›Relations ; reste la boucle import (arbitrage l un/l autre/les deux)** ; **D-155 : Mindmap — tailles de cartes UNIFORMES par palier d écran (--mm-sat/--mm-hub) + composition bornée et centrée (560/720 px) → propre sur PC, tablette et mobile** ; **D-154 : liaisons Mindmap affinées à 2 px** ; précédent **D-153 : Mindmap — liaisons SANS pointes de flèche, trait 4 px, extrémités glissées sous les cartes (contact net) — la position des familles donne le sens.** — précédent **D-152 : Mindmap — vraies flèches (retrait 4 px avant la cible + pointes en taille écran fixe) ; « +N » déplie SUR PLACE (mode exploration défilable, « réduire » = synthèse) au lieu de sauter vers la Liste ; positions/priorité/généricité disciplines documentées (placement par rôle sémantique, types sans rôle → « Autres liens »).** — précédent **D-151 : Mindmap — passe de fidélité n°2** : connecteurs bas = courts traits or + ligne Contre continue hub→carte (entre les Fondamentaux), labels latéraux sans icône, flèche → sur « Enchaînée depuis » (chips/badges). — précédent **D-150 : Mindmap — icônes enfin rendues (bug Lit : `<path>` créé en namespace HTML via le tag `html` imbriqué → fragment en tag `svg`) + scène MISE À L'ÉCHELLE du viewport réel (`transform:scale`, la barre d'URL Chrome réduisait la hauteur → débordement sous chips/nav) + espace des accolades latérales (colonne hub 120-132, gap 22).** Vérifié aux deux hauteurs 844/695, zéro collision ; icônes visibles chips/labels/badges/Liste. — précédent **D-149 : Mindmap — alignement visuel fin au prototype** : connecteurs FINS branchés (éventail/accolades/fourches, ~1,7 px), couleurs gauche/droite comme le proto (Enchaînée depuis VERT, Enchaîne vers BLEU, propres à la Mindmap), badges d'icône sur les vignettes, hub sous-titre en accent + pastille « N relations » en contour, titres de famille sans compteur, chips REMPLIES, recherche/recentrer en boutons d'en-tête. `verifier` vert 165 + build + e2e ; très proche du prototype confirmé 390×844 sombre. — précédent **D-148 : Mindmap — gabarit spatial FIXE + mapping DÉTERMINISTE par type métier (fondamentaux → zone Fondamentaux et non Similaires), chips légende/filtre, recherche par icône, hub ~38 % centré ; cas de recette O-soto-gari (Kihon-dosa/Ukemi) ajouté aux données** ; précédent D-147 : Mindmap — refonte du modèle de layout (zone-carte à hauteur FIXE, hub centré visible sans défiler, 2 cartes/famille + « +N », Fondamentaux en or, recherche compacte, connecteurs SVG derrière)** ; précédent D-146 : rollback D-145 — retour à la Mindmap D-144 (chips + compaction écartés, préférence porteur)** ; précédent D-145 (chips+compaction, écarté) ; **D-144 : Mindmap radiale fidèle au prototype — grandes cartes verticales à vignette + libellés flottants + hub « N relations »**) — précédent : (**D-143 : Mindmap remise en radial (structure)** ; **D-142 : timeline verticale (rejetée)** ; **D-141 : Mindmap remise en parallèle de la Carte** ; **D-140 : remise en ordre de l'écran Relations**. **R10 livré** : l'onglet « Mindmap » s'affiche désormais **« Carte »** (id interne `mindmap` conservé pour la persistance R3 et les sélecteurs) ; ordre Liste · Carte · Explorer inchangé ; option « bouton Naviguer » parquée ; `verifier` vert 164. **R2 livré** : écran « point de départ » aligné maquette — « Récemment consultées » (relibellé), **Favoris en chips**, recherche + « Explorer au hasard » conservés ; `verifier` vert 164. **R5/R19 livré** : section Relations de la fiche refaite (`sectionRelationsFiche`) — aperçu **groupé par rôle** (≈2 liens/rôle + raison), « Présente dans » à part ; **icône réseau → Carte**, **« Voir toutes les relations » → écran Relations en Liste** ; `ouvrirRelationsVisuelle(id, vue?)` + `definirVueRelations` ; ligne factorisée (`ligneRelation`, partagée fiche/Liste) ; dépliage sur place §19 retiré (décision) ; e2e adapté ; `verifier` vert 164. **R6/R7/R8 livré** : Carte refaite en **canevas SVG pannable/zoomable** (`vueCarte`/`poserCarte`/`fitCarte`) — nœuds placés par rôle (avant gauche/après droite/opposition bas/pair haut/contexte bas-gauche), courbes de Bézier colorées, **pan/zoom via viewBox** borné (lisibilité d'abord, débordement+déplacement au-delà de `MAX_FIT`), **fit** à l'ouverture/recentrage + double-toucher, **toucher un nœud recentre** (R4), raison en infobulle+texte, pastille ⚠️, nœud « +N » → Liste, **bouton plein écran ⛶** (fixed inset:0, masque tout le chrome) ; e2e exerce la Carte + plein écran ; confirmé visuellement ; `verifier` vert 164. **R14 livré — D-138 TERMINÉ** : Liste polie — carte centrale **collante** qui se **compacte** en bandeau au défilement (`installerCompaction`), chips de filtre sans barre grise (`scrollbar-width:none`) + retour auto sur le filtre actif (`scrollIntoView`) ; e2e (chips + sticky) ; confirmé visuellement ; `verifier` vert 164.) — précédent : (**D-137 : écran Relations — navigation déterministe + persistance + historique (R1/R3/R4)** — **R3 livré (boucle 1)** : le centre et le mode de lecture de Relations sont mémorisés entre sessions (`Preferences.relationsCentreId?`/`relationsVue?` — réglages d'appareil optionnels, migration-safe, jamais exportés) ; recentrage via `recentrerRelations()` (point unique qui persiste), vue persistée par `barreVues`, `techniqueCentreRelations()` intègre le centre mémorisé en étape 2 ; test préférences → 164 unit ; `verifier` vert. **R1 livré (boucle 2)** : `techniqueCentreRelations()` sans repli arbitraire (ordre strict centre explicite → mémorisé → dernière vue → `null`) ; sans centre, écran **« Choisis un point de départ »** rendu dans l'onglet (recherche + récents + favoris + « Explorer au hasard »), **aucune redirection** vers la Bibliothèque ; bibliothèque vide inchangée ; `verifier` vert 164. **R4 livré (boucle 3) — D-137 TERMINÉ** : pile d'historique de session des centres visités + **fil d'Ariane** discret en tête (`Ashi-garami › Seoi-nage › …`, tronqué à gauche si long, maillon cliquable = y revient, ← Revenir dépile) — **jamais de retour à la Bibliothèque** ; `pousser` = point unique de recentrage (revient sur un centre déjà dans la pile plutôt que dupliquer) ; Explorer avance désormais en recentrant (choix d'interprétation documenté) ; `verifier` vert 164. — précédent : **D-136 : dataset Judo nettoyé + rôles + alertes — Loop A/C livré** — l'outil porteur régénère le graphe : **505 → 275 liens** (prérequis génériques retirés — « fondamentaux hors carte » acté ; type `a_ne_pas_confondre` ajouté), **rôles sémantiques** sur les types (`after/before/peer/opposition/context` → l'UI placera d'après le rôle, pas le libellé), **alertes réglementaires** (`typesAlerte`+`alertes`, 4 techniques interdites IJF). Modèle étendu (role/ordre, TypeAlerteDef, Technique.alertes, Bibliotheque.typesAlerte — optionnels, schéma 3 inchangé) ; import/export/validation OK ; `kodokan.json` remplacé (drop-in 111/111) ; tests refondus 163 ; pack **Judo 0.4.0** republié. **D-136 TERMINÉ (Loops A-B-C)** : dataset nettoyé (275) + rôles + « à ne pas confondre » + alertes IJF ; UI = **carte de flux par rôle** (Mindmap ligne de temps avant-gauche/après-droite/contre-bas ; Liste/Explorer par rôle) ; **alertes** = bandeau fiche (⚠️ + réf. IJF) + pastille en navigation. Pack Judo 0.4.0. — précédent : **D-135 : refonte écran Relations — TERMINÉE (Liste + Mindmap + Explorer)** — sélecteur de trois vues d'un même graphe. Liste (raisons + tri + filtre) ; Mindmap **radiale fluide** (hub central + branches reliées par **connecteurs courbes** mesurés, remplit la largeur, Tout déplier/Centrer/voir plus) ; **Explorer** (entrée guidée « que veux-tu faire ? » → parcours court dérivé d'arêtes réelles, chaque flèche = la raison, **enregistrable comme composition** via `creerCompositionDepuisEtapes`). Code couleur par type. Ancienne vue à carrousels supprimée. Bug import/fusion (perte note/priorité) corrigé + test. `systeme.md`/`workflows.md` à jour. `verifier` vert 162, 3 vues confirmées visuellement. App web redéployée. Mermaid écarté. **Mindmap refaite en radiale fluide + connecteurs courbes** (retour porteur : « ce n'en est pas une », fit une page, courbes). **« Aller au sol » = écart de CONTENU identifié** : le pack a bien le sol (32 tech.) mais le dataset n'a quasiment aucune transition debout→sol (O-soto-gari : 0) — à trancher (type dédié + liens conventionnels beta, ou régénération du dataset). — précédent : **D-135 boucles 1-2/3 (Liste + Mindmap)** — sélecteur de vues **Liste | Mindmap** livré (Explorer en boucle 3). Liste = liens + raisons + tri + filtre ; Mindmap = hub + branches par type en clusters colorés + débordement « +N » + déplier/réduire. Code couleur par type unifié. Bug import/fusion (perte note/priorité) corrigé + test. `verifier` vert 162, confirmé visuellement. Reste : Explorer, `workflows.md`. — précédent : **D-135 boucle 1/3 (vue Liste)** — l'écran Relations passe d'une carte à carrousels à un sélecteur **Liste / Mindmap / Explorer** (Mermaid écarté, Carte abandonnée). **Boucle 1 livrée** : vue **Liste** (liens groupés par rôle + **raison** de chaque lien + tri pertinence + filtre + code couleur par type). **Bug corrigé** : l'import et la fusion de doublons perdaient `note`/`priorite` des relations (D-134 inopérant à l'usage) → préservés + test. `verifier` vert 162, confirmé visuellement. Reste : Mindmap, Explorer, `workflows.md`. — précédent : **D-134 : relations enrichies (raison + priorité)** — le modèle `Relation` gagne `note?`/`priorite?` optionnels (migration-safe, schéma 3 inchangé) ; l'inverse dérivé réutilise la note ; affichage = légende discrète sous chaque liaison en fiche + tri par priorité + infobulle dans la vue graphe ; les 505 arêtes Judo portent toutes raison + priorité ; pack **Judo 0.2.0 → 0.3.0** (vEdito 3) republié ; `verifier` vert 161. — précédent : **D-133 : navigation relationnelle Judo (bêta)** — jeu de données porteur `kodokan-rel-beta` (111 tech. / 825 relations) importé dans `donnees/kodokan.json` par rattachement au nom (111/111) ; **505 arêtes stockées** (enchaine/contre/kata/prerequis/similaire), les inverses `prepare`/`contre_de`/`contient` étant dérivés à l'affichage ; 2 types créés (`kata`, `prerequis`) qui voyagent dans le movpack ; `kodokan.json` porté au schéma 3 ; option **A (maillage seul)** — les *raisons* de l'audit non stockées (modèle `Relation = type+cibleId`), **option B (raisons via extension du modèle) proposée au porteur** ; `judo.movpack` régénéré (vEdito 2) et republié, pack **Judo 0.1.0 → 0.2.0** ; test « 0 relation » retourné en vérification positive du graphe ; `verifier` vert 160. — précédent : **D-132 : versionnage unifié 0.x** — app `0.9.0-rc.1` (package.json → À propos), packs tous `0.1.0`, formats internes schéma 3/movpack 4 gardés en entiers mais retirés de l'À propos, registre central [`docs/versions.md`](../versions.md) + process de propagation publication comprise. Site movenso-public mis à jour (packs.js, copy, bug burger corrigé) et app web régénérée. — précédent : **D-131 : consolidation** de la finition D-127 restée bloquée sur `feat/v3-finition-beta` (CI rouge au garde-fou etat.md, jamais fusionnée — cause racine de l'écart mémoire/code) : cherry-pick du **voile « … en cours »** (opérations longues) et de l'**avertissement « sauvegarde non chiffrée »** ; doublon À propos écarté (D-130 en place), écran Aide dédié non repris (aide déjà dans À propos). `verifier` vert 160 unit. **La branche de travail est désormais la seule complète et verte.** — précédent : **D-130 : finition « app terminée »** : version visible injectée au build (`src/app/version.ts` + `__APP_VERSION__` via Vite) + écran **Plus › À propos et aide** (version, nature bêta/debug, aide rapide, sauvegarde/restauration, partage ≠ sauvegarde) ; `verifier` vert 160 unit + build + e2e ; APK auto-rebuild sur le push. — précédent : **D-129 : nettoyage du dépôt** (retrait de `movenso-main.zip` 4,1 Mo redondant avec le repo V2 live, et de `spike/` + workflow `spike-apk` jetables ; références et garde-fou CI mis à jour) ; **D-128 : audit documentaire + unification**. Deux systèmes de doc concurrents réconciliés en **une source de vérité par sujet** (carte [conventions.md](../conventions.md) §2) : présent = ce fichier `STATE.md` (`etat.md` → pointeur figé) ; architecture = [systeme.md](../systeme.md) **remis à jour** (nav 4-5 onglets, `.movpack` v4, schéma v3, chrono de séance, « Plus » ≠ « Atelier », À traiter ≠ À reprendre) ; parcours = [workflows.md](../workflows.md) idem ; journal des décisions en deux segments assumés. Ère roadmap archivée (`docs/archives/`). **Règle anti-retard** : doc à jour au fil de l'eau, dans le même commit (conventions §12 + CLAUDE.md). Zéro changement de code produit. — précédent : refonte Compositions boucles 1-3 [D-124] + chrono de séance vivant [D-125 : décompte, passage auto, pause, voix réelle des annonces, type de bloc « pause » paramétrable, bips audibles sans TTS, transition de préparation réglable] + raffinements UX Compositions [D-126 : ▶ sur les cartes, sous-titre discret, barre à droite, unités s/min, entonnoir simplifié technique/saisie-libre, édition inline en lecture, coupure du chrono à la sortie, mini-feuille d'édition par pas, durée façon chrono min:s, **retrait du crayon → menu ⋮**] ; reste une boucle de clôture — recette bêta + workflows + APK).
- **À traiter en session suivante (porteur, 2026-07-23)** : **ajustements sur l'import de pack et la bibliothèque**. Jeux d'essai déposés dans `docs/recette/packs-test/` (4 référentiels discipline — Karaté Shotokan 109 tech., Jujitsu France Judo 162, JJB Gi/No-Gi 150, Taïso France Judo 114 ; + 1 pack **composition** — Taïso 12 séances + 95 tech., Yoga Hatha 72 tech., Yoga 12 séances + 62 tech. ; `movpack` v4 / schéma 3, sans médias). **Import confirmé OK par le porteur** sur les premiers packs. Distribution : une discipline et ses séances peuvent rester DEUX packs — l'export de la discipline embarque les séances jouables (D-127 b.4), pas de fusion manuelle. **D'autres packs suivront.**

<details><summary>Historique roadmap V3 (archivé — lots 1-10 clos)</summary>

- Lots 01 à 09 `ACCEPTABLE` (recettes humaines Android). Lot 08 : commit final `80efd65`, CI `29272785511`, APK `29272039028`. Lot 09 : commit `8d26c299`, CI `29279256402`, APK `29279256488`.
- **LOT 10 TERMINÉ — DÉCISION FINALE : GO AVEC RÉSERVES** (candidate `3.0.0-rc.1`). 10A audit (0 P0/P1) → 10B correction A1 (D-066) → 10C recette + `docs/archives/rapport-recette-v3.md`. Réserves = P2/P3 (backlog) + plateformes déclarées ; aucune sur données/PIN/restauration.
</details>

## Vérifications

- Test ciblé : e2e `parcours.mjs` (zéro erreur JS)
- `verify:fast` : n'existe pas encore
- `npm run verifier` : vert (clôture 8A)
- Build web : vert (CI 29208155024 / 29208164718)
- Build Android : vert (run apk 29208155025, artefact APK debug)
- État Git : propre, à jour avec origin

## Recette humaine du lot 01 (Yahya, 2026-07-12) — CONFIRMÉE

Résultats manuels Android validés par l'humain :

- retour fiche → discipline avec filtres et position conservés ✓
- retour avec clavier ouvert → fermeture du clavier en premier ✓
- discipline → racine Bibliothèque ✓
- racine Pratique ou Atelier → Bibliothèque ✓
- racine Bibliothèque → système ✓
- absence de boucle ou d'empilement infini entre les onglets ✓

→ **Lot 01 : ACCEPTABLE** (le lot ne sera pas rouvert ; retouches de
raccord traitées en boucle 2.0 sur instruction humaine).

## Recette humaine du lot 02 (Yahya, 2026-07-12) — VALIDÉE

Recette Android réelle, résultats confirmés par l'humain :

- Bibliothèque vide et import avec prévisualisation corrects ✓
- pack Kodokan importé : 111 identités ✓
- second pack importé dans la même discipline ✓
- compte des identités uniques cohérent ✓
- techniques communes non dupliquées ✓
- filtre par source fonctionnel ✓
- badge « 2 voix » présent sur les identités concernées ✓
- recherche et filtres cumulables ✓
- filtres et position restaurés après retour depuis une fiche ✓
- état conservé après changement d'onglet ✓
- premier retour avec clavier ouvert ferme le clavier ✓
- dernière rangée entièrement accessible malgré « Ajouter » et la barre basse ✓
- discipline vide sans impasse ✓
- racine alimentée sans action Importer permanente ✓

→ **Lot 02 : ACCEPTABLE.** Consignes pour le lot 3 : ne pas corriger ce
qui relève des Compositions/Favoris (lot 5), de l'Atelier (lot 6), du
graphisme général (lot 9) ; une régression des lots 1-2 ne se corrige que
si une boucle du lot 3 l'a directement provoquée.

## Découpage du lot 03 en boucles (fiche technique)

1. **3.1** — En-tête conforme §2 : retour + nom + appellation + menu ⋮
   (Modifier les informations générales / Retirer…) ; plus de crayon
   permanent ni de bouton « Terminer » (§16).
2. **3.2** — Média principal §3-4 : légende éditoriale (source ·
   provenance), fallback propre + « Ajouter un média » si aucun, galerie
   compacte des autres médias.
3. **3.3** — « Ajouter un média » complet depuis la fiche §5 : filmer /
   fichier / lien, sans redemander la technique. Plan : feuille dédiée
   `ajout-media.ts` en deux moments (contenu : Filmer maintenant / vidéo
   de l'appareil / coller un lien ; puis les seules questions utiles :
   qui l'a produit — Moi / prof ou club / ressource —, attribution,
   libellé facultatif) ; accès par le menu ⋮, par un ＋ dans la galerie
   et par l'état « Aucun média » ; après ajout le média devient le média
   AFFICHÉ (galerie + légende immédiates), retour sur la fiche ; retour
   Android ferme la feuille en premier ; complément §4 resté ouvert
   après 3.2 : action explicite « Utiliser comme aperçu principal de
   cette technique » quand le média affiché n'est pas le principal
   (réutilise `majTechnique`). Vérifié au passage (§4, risque du
   remplacement silencieux) : `rapprochement.ts` ne pose un
   `mediaPrincipalId` entrant QUE si l'identité locale n'en a pas.
4. **3.4** — Voix §7-8 selon la **décision D-027 (invariants 57-64)** :
   une seule ouverte à la fois, titres éditoriaux ; contribution importée
   INTACTE (jamais éditable directement) avec explication « Ce contenu
   vient de [source]. L'original reste intact… » ; actions : ajouter son
   repère personnel, ou **Créer une adaptation locale** (nouvelle
   contribution locale préremplie, attribuée « Adaptation locale d'après
   [source] », affichée séparément, jamais écrasée par une réimportation) ;
   les contributions locales restent directement modifiables.
5. **3.5** — Relations compactes §11 : « Relations · N », aperçu limité,
   « Voir toutes les relations ». Plan : en-tête « Relations · N »,
   aperçu de 3 lignes « libellé → cible » (la direction vit dans le
   libellé dérivé — jamais l'id interne du type), action « Voir toutes
   les relations » dépliant la vue groupée par libellé (état de session
   `relationsDepliees`, replié par défaut, reset à l'ouverture de fiche) ;
   toucher une cible ouvre sa fiche, le retour revient par la pile
   (existant). La « source de la relation » (§11 « lorsque disponible »)
   n'existe pas dans le modèle (`Relation` = type + cibleId) : omise,
   documenté. Au passage §12 : l'en-tête devient
   « Utilisée dans · N composition(s) » (accès déjà compact).
6. **3.6** — États particuliers §17, conservation §19 (voix/média de la
   session), scénarios A-I, docs, captures, checkpoint.

## État initial du lot 03 (Phase 1)

- Branche `claude/movenso-v2-mission-ynb4ig`, base a59b855, Git propre.
- Fiche actuelle (`vues.ts` : gabaritFiche/editionTechnique/voixReference/
  noteCarnet/gabaritMedia) : crayon d'en-tête basculant TOUT en édition
  (`editionFiche`), « Terminer les modifications », retrait au fond de
  l'édition, voix `<details>` toutes ouvrables (référence ouverte à
  l'index 0), amendement inline des contributions sourcées (D-024),
  carnet direct (＋note/🎞/🔗), relations en liste complète, « Utilisée
  dans » en puces.
- Contradiction D-024/§8 TRANCHÉE PAR L'HUMAIN (2026-07-12) : **D-027**
  (execution/DECISIONS.md §57-64) — original importé intact, adaptation
  locale distincte préremplissable et attribuée, réimport sans écrasement,
  local directement modifiable, pas de déduction de non-maîtrise depuis la
  seule origine, exclusions de publication précisées au lot 6, jamais de
  champ grisé sans explication.
- Non touché : compositions/favoris (lot 5), Atelier (lot 6), graphisme
  général (lot 9), modèle métier, `.movpack`, stockage.

## Découpage du lot 04 en boucles (création, capture et édition)

1. **4.1** — Panneau contextuel « Ajouter » (§2-3) : sur la racine
   Bibliothèque (Créer une technique / Filmer ou garder quelque chose —
   réintroduction prescrite de la capture sans discipline) et sur une
   discipline (Une technique / Filmer maintenant / Une vidéo ou un
   fichier / Un lien / Un mot ou commentaire, discipline présélectionnée) ;
   panneau court par gestes, aucun vocabulaire interne, fermeture sans
   effet ; retour Android le ferme en premier.
2. **4.2** — Création minimale d'une technique (§4) + prévention des
   doublons (§5) : nom obligatoire + appellation facultative, section
   « Classer maintenant » / « Je le ferai plus tard », discipline
   présélectionnée ou créée dans le même parcours ; suggestions pendant la
   saisie (« Utiliser cette technique » / « Créer quand même »),
   confirmation si correspondance exacte ; après création → fiche, la
   technique visible dans la grille.
3. **4.3** — Capture par le contenu (§6-7) : aperçu après filmer/choisir
   (Utiliser / Refilmer / Abandonner), lien conservé tel quel (aperçu ou
   domaine), mot libre ; puis « Sais-tu où le ranger ? » (existante /
   nouvelle / plus tard) et fins de parcours §21 (« Conservé dans
   Pratique > À reprendre », jamais de « Terminer »).
4. **4.4** — Personnel par défaut + « Ce contenu vient de quelqu'un
   d'autre » en action SECONDAIRE (§8, plus de chips systématiques) ;
   capture non rattachée complète (§9) : ouvrir/lire, rattacher, créer,
   modifier le libellé, supprimer avec confirmation — sans fausse
   technique vide.
5. **4.5** — « Ajouter une contribution » depuis la fiche (§11, distinct
   du carnet : de qui / quoi / attribution selon le cas) + retour Android
   par étapes dans le flux (§16 : clavier → panneau → étape précédente →
   « Que faire de cette capture ? » si un contenu existe) + médias
   temporaires sans orphelins (§14) + hors ligne (§19).
6. **4.6** — Clôture : scénarios A-K (§23), permissions §15 (alternatives
   au refus, documenté pour la WebView), docs §25 (workflows/systeme/
   matrice de conservation/etat), captures regardées (D-026), checkpoint
   + APK.

## État initial du lot 04 (Phase 1, 2026-07-13)

- Base `1ce1cd0`, Git propre, lots 01-03 ACCEPTABLE.
- Existant : feuille de capture 3 gestes (`capture.ts` : contenu →
  note+provenance → rattacher) avec création à la volée et « Plus tard »
  (personnel seulement) ; FAB « Ajouter » sur discipline UNIQUEMENT →
  ouvre directement la capture (pas de panneau, pas de chemin « créer une
  technique » de premier rang) ; racine Bibliothèque SANS action d'ajout
  (capture sans discipline impossible — hors périmètre observé du lot 1,
  réintroduction prescrite ici §2) ; discipline vide : « Créer la première
  technique » ; fiche : feuille « Ajouter un média » (lot 3) + carnet
  direct, mais pas d'« Ajouter une contribution » (texte d'enseignement) ;
  « À reprendre » : carte → rattachement seul (pas de suppression ni
  d'édition de libellé) ; provenance : chips TOUJOURS affichées à l'étape
  note (le lot veut personnel par défaut + action secondaire) ; retour
  Android : ferme la feuille de capture d'un coup (pas d'étape par étape,
  pas de « Que faire de cette capture ? ») ; pas d'aperçu après filmer ;
  pas de prévention de doublons à la création ; médias : le fichier reste
  en mémoire jusqu'à `terminerCapture` (écriture à la fin — pas d'orphelin
  sur abandon) mais `ajouterMediaFiche` écrit la vidéo AVANT de persister
  la contribution (orphelin possible si la persistance échoue — à traiter
  §14).
- Non touché (§22) : navigation principale, structure Bibliothèque,
  hiérarchie de fiche, modèle métier, rapprochement, `.movpack`, OPFS en
  profondeur, compositions, types de relation, Atelier, sécurité,
  publication, direction graphique.

## Découpage du lot 05 en boucles (Pratique, Favoris, Compositions)

1. **5.1** — Favoris (§4-6) : mécanisme minimal dans le modèle
   (`favoris: string[]` d'identifiants de techniques + validation des
   références + migration versionnée + inclusion sauvegarde intégrale +
   exclusion des packs publiés) ; étoile sur la fiche (ajout/retrait
   immédiat, réversible, sans confirmation, état pas couleur-seule) ;
   liste compacte dans Pratique (miniature, nom, appellation, discipline ;
   toucher → fiche ; retrait secondaire ; favori disparu → jamais d'écran
   cassé) ; états vides compacts §2.
2. **5.2** — Racine Pratique §2-3 : sections compactes (titres courts,
   aperçus, « Voir tout » si nombreux), À reprendre §3 raccordé (états
   compréhensibles — l'essentiel des actions vient du lot 4.4).
3. **5.3** — Éditeur de composition §8-13 : DEUX choix visibles seulement
   (Ajouter une technique / Ajouter du texte — les 8 types internes
   préservés en données, anciens blocs lisibles, nouveau texte = type le
   plus générique) ; création titre obligatoire + description facultative ;
   sélecteur de technique (recherche, discipline, favoris) ; menu
   contextuel d'un bloc technique (Voir la fiche / Remplacer / Ajouter du
   texte après / Retirer) ; texte avant/après §16.
4. **5.4** — Mode entraînement §14-15 : pas-à-pas plein écran (bloc
   courant, précédent/suivant, « 3 / 8 », grandes actions Précédent /
   Suivant / Quitter, barre basse masquée, fiche ouverte → retour au même
   bloc, ni chrono ni lecture auto ni maintien d'écran).
5. **5.5** — Liste §18-19 (compteurs, date de modification, brouillon,
   dupliquer — nouvelles références, jamais de copie —, recherche/tri
   simples), technique indisponible §17 (état + remplacer/retirer, jamais
   de suppression silencieuse), export §20 (granularité minimale SÛRE +
   rapport avant export), import §21 (références résolues par le
   rapprochement, « Technique à retrouver »), sauvegarde/restauration §22.
6. **5.6** — Clôture : scénarios A-K (§26), hors ligne §23, performance
   §24, docs §28, captures regardées (D-026), checkpoint + APK + recette.
7. **5.7** — Corrective (recette Android 2026-07-13), strictement limitée
   à : (1) notifications transitoires — un toast disparaît seul après une
   durée courte, est remplacé par le plus récent, ne survit PAS à un
   changement d'écran et n'apparaît JAMAIS dans le mode entraînement ;
   (2) l'éditeur de composition n'expose que DEUX constructions (Ajouter
   une technique / Ajouter du texte) — l'action « Filmer ou noter un
   repère » disparaît (captures existantes et compatibilité intactes,
   workflow de capture du lot 4 non modifié) ; (3) plus de libellé interne
   « ÉTAPE » sur les blocs de texte (type conservé en données, l'humain ne
   voit que son texte) ; (4) « Retirer » (composition) devient « Supprimer
   la composition », confirmation nommant la composition, traitement
   dangereux distinct d'« Exporter » et « Fermer ». Plan : `racine.ts`
   (cycle de vie du toast : effacement dans `#aller`/`#allerRacine`/
   `retour` + garde d'expiration + rendu supprimé sur l'écran
   entraînement), `compositions.ts` (retrait du bouton repère, nature de
   bloc muette pour les textes, action de suppression), e2e NR dédiées.
   Risque principal : effacer un toast légitime posé pendant une
   navigation programmée — vérifié : tous les flux naviguent PUIS
   affichent (l'ordre protège le toast). Non touché : Favoris, modèle des
   compositions, anciens types en données, fonctionnement du mode
   entraînement, Atelier, identité graphique.

## État initial du lot 05 (Phase 1, 2026-07-13)

- Base `5d838a2`, Git propre, lots 01-04 ACCEPTABLE.
- Existant : racine Pratique (À reprendre masquée si vide ✓, cartes
  complètes du lot 4.4 ; Favoris = état vide TEXTE SEUL, aucun mécanisme ;
  carte Compositions unique) ; compositions (création par titre, édition
  ajout-bloc : technique par recherche + texte libre + capture-repère,
  8 types de blocs EXPOSÉS à la lecture, Monter/Descendre, consultation
  en liste « gros blocs » — PAS de mode entraînement pas-à-pas §15, pas
  de progression, barre basse visible) ; « Utilisée dans · N » ✓ (lot 3) ;
  bloc « identité absente » affiché mais sans Remplacer ; export d'une
  composition .movpack (portée composition) existant, sans rapport avant
  export ni granularité B ; pas de duplication ; pas de recherche/tri de
  compositions ; sauvegarde intégrale existante SANS favoris (le champ
  n'existe pas — modification de modèle autorisée §25 : mécanisme minimal
  + migration).
- Non touché (§25) : navigation, Bibliothèque, fiche (hors étoile Favoris
  et navigation composition), capture, modèle identité/contribution,
  rapprochement, stockage physique, types de relation, Atelier, sécurité,
  publication disciplinaire, graphisme global.

## Découpage du lot 06 en boucles (Atelier)

1. **6.1** — Racine en quatre intentions (§2-4, §29) : exactement
   Construire / Médias et qualité / Échanger et protéger / Réglages et
   sécurité (accordéon, une seule ouverte — natif `name=` conservé),
   synthèse actionnable EN TÊTE uniquement s'il y a des problèmes (chaque
   élément cliquable ouvre le workflow ; sinon « Aucun problème détecté »
   compact, jamais un tableau de bord vide), état de l'Atelier conservé
   pendant la session (intention ouverte, défilement — aujourd'hui perdu à
   la bascule d'onglet), entrée unique vérifiée (« Vérifier dans
   l'Atelier » d'une vidéo absente ouvrira la bonne section en 6.5) ;
   anciennes routes Admin : inexistantes en V3 (rien à rediriger,
   documenté §2).
2. **6.2** — Construire > Disciplines (§5-7) : liste avec nom, nombre
   d'identités, taxonomies, sources présentes et problèmes actionnables ;
   créer (nom seul ✓ existant), renommer (vérifier qu'aucune identité de
   pack n'en dépend — `idDePack` ne sert qu'aux exports, à documenter),
   réordonner, « Ouvrir dans la Bibliothèque », retirer si vide ✓ ;
   discipline NON vide : présentation du contenu (techniques,
   contributions, médias, compositions concernées) et options réelles —
   sauvegarde préalable obligatoire avant toute suppression en masse,
   refus explicatif si non supporté (jamais de suppression complexe
   inventée).
3. **6.3** — Construire > Taxonomies (§8) : créer/renommer ✓, ORDONNER
   (manquant), couleur ✓ (niveaux) ; suppression avec contrôle des
   usages : nombre d'utilisations, techniques concernées, options
   « remplacer par une autre valeur / retirer la classification /
   annuler » — jamais de référence invalide (aujourd'hui : confirm sans
   contrôle d'usage).
4. **6.4** — Construire > Types de relation (§10), Techniques (§9) et
   Sources (§11) : types — libellé, inverse, symétrie, compteur d'usages,
   renommer/modifier l'inverse, suppression UNIQUEMENT si inutilisé
   (remplace la rupture consentie actuelle — prescription §10), jamais
   d'id interne ; Techniques — liste orientée gestion (recherche, état de
   classification/médias/problèmes, ouvrir la fiche), pas de seconde
   Bibliothèque, pas d'action de masse factice ; Sources — consultation
   éditoriale (auteur, version, contributions associées) sans registre
   complexe ni modification du manifeste tiers.
5. **6.5** — Médias et qualité (§12-15) : diagnostics existants
   réorganisés en « quel problème / quels contenus / que faire » ;
   ajouts : fichier sans référence (orphelin — suppression UNIQUEMENT
   avec prévisualisation et confirmation, jamais en masse), « technique
   sans média principal » distinguée des vraies erreurs ; médiathèque
   (miniature, type, taille si connue, références, état ; jamais de
   suppression d'un média référencé) ; qualité du corpus : distinguer
   erreur d'intégrité / à compléter / arbitrage / facultatif ; le lien
   « Vérifier dans l'Atelier » ouvre cette section.
6. **6.6** — Échanger et protéger (§16-24) : quatre gestes distincts
   (jamais synonymes) ; import orchestré — aperçu enrichi (nom, auteur,
   version, portée, compteurs, volume, conflits) puis RAPPORT après
   import (§18 : nouvelles/réunies/contributions/médias/à rapprocher +
   « Ouvrir la discipline ») ; publication §19-20 — nom éditorial,
   auteur, version, conditions, inclusion des médias, prévisualisation
   exacte (identités, contributions, sources, taille estimée, exclus),
   sortie réelle (nom du fichier, type, taille, résumé, Partager/
   Enregistrer selon le mécanisme existant) ; sauvegarde intégrale §21
   (« Sauvegarde complète de cette installation », date, taille, médias
   inclus ou non — jamais « complète » si les médias manquent) ;
   snapshots §22 (vue compacte : date, motif, taille) ; restauration §23
   et rollback §24 (libellé lisible ✓, expliquer ce qui sera remplacé,
   snapshot de sécurité ✓, limites médias dites honnêtement).
7. **6.7** — Réglages et sécurité (§25-27) + clôture : écran de démarrage
   ✓ avec information discrète si la discipline choisie a disparu
   (manquante), état réel des protections (mention lot 7, AUCUN contrôle
   factice), thème ✓/tonalité ✓ conservés ; scénarios A-M (§32), e2e
   vertical §33, responsive §28 vérifié, docs §34 (workflows avec Mermaid
   de l'architecture, systeme, matrice de conservation, etat), captures
   regardées (D-026), checkpoint + APK + recette Android (§33 : sélection
   de fichier, partages, restauration, accordéons, retour, clavier,
   tablette).

## État initial du lot 06 (Phase 1, 2026-07-13)

- Base `3d6b008`, Git propre, lots 01-05 ACCEPTABLE.
- Existant (`src/app/atelier.ts`, ~370 lignes) : QUATRE volets natifs
  `<details name="atelier">` (une seule section ouverte — natif) mais
  intitulés non conformes (« Construire le corpus », « Vérifier et
  résoudre · N », « Protéger et échanger », « Réglages ») et AUCUNE
  synthèse actionnable en tête (le compteur vit dans le titre du volet
  diagnostics) ; état des volets PERDU à la bascule d'onglet (DOM
  recréé) ; racine vide → message + création de discipline.
- Construire : cartes de discipline (renommer au crayon, familles/niveaux
  inline avec couleurs de ceinture bicolores, « Retirer cette discipline
  vide ») ; PAS de compteur de sources ni de problèmes par discipline,
  pas de réordonnancement, pas d'« Ouvrir dans la Bibliothèque » ;
  suppression d'une discipline non vide : refus avec toast actionnable
  (pas de présentation du contenu) ; taxonomies : suppression sur simple
  confirm SANS contrôle des usages (références invalides possibles —
  tolérées par la validation, diagnostiquées) ; types de relation :
  créer/supprimer, la suppression d'un type UTILISÉ est permise avec
  avertissement + snapshot (le lot 6 §10 prescrit le refus tant
  qu'utilisé), pas de renommage ni d'édition d'inverse/symétrie.
- Pas de sous-section Techniques de gestion, pas de vue Sources/auteurs.
- Diagnostics : 5 KPI actionnables (captures à rattacher → rattachement,
  relations cassées → fiches, vidéos locales manquantes
  (`app.mediasManquants`), techniques sans contenu, sans niveau) ; pas de
  médiathèque, pas de détection d'orphelins (fichier sans référence), pas
  de distinction erreur/à compléter/facultatif.
- Échanger : « Exporter tout » avec/sans vidéos ; import par contenu avec
  rapport calculé À BLANC avant confirmation ✓ (D-023) mais aperçu sans
  auteur/version/volume et AUCUN rapport après import (toast seul) ;
  publication par discipline avec sources cochées (jamais le carnet ✓,
  favoris exclus ✓) mais SANS nom/auteur/version/conditions ni
  prévisualisation détaillée ni écran de sortie (téléchargement direct +
  toast) ; snapshots : 10 derniers, motifs lisibles (« avant-import-x »),
  restauration avec snapshot préalable ✓ ; restauration complète
  uniquement sur installation vierge, refus explicite sinon ✓.
- Réglages : thème auto/clair/sombre ✓, tonalité (6 accents, existants
  sans coût — conservés §27), démarrage Bibliothèque/dernière/choisie ✓ ;
  fallback discipline disparue → Bibliothèque SANS information discrète
  (§26, à compléter) ; aucune protection (lot 7) — aucun contrôle factice
  à créer.
- Entrée unique ✓ : seul l'onglet ouvre l'Atelier ; « Vérifier dans
  l'Atelier » (vidéo locale absente) est une action locale qui ouvre la
  racine — sera raccordée à « Médias et qualité » en 6.5. Aucune route
  Admin/Réglages héritée n'existe en V3.
- Non touché (§31) : navigation principale, Bibliothèque, fiche, capture,
  Pratique/Compositions, modèle identité/contribution, rapprochement,
  stockage physique des médias, `.movpack` en profondeur, types de blocs,
  sécurité/PIN, direction graphique, plateformes/build Android.

## Découpage du lot 07 en boucles (Sécurité et modes d'usage)

1. **7.1** — Cœur cryptographique + politique centralisée (§4-5, §17) :
   module de sécurité PUR et testable — dérivation PBKDF2/SHA-256 (Web
   Crypto, sel aléatoire par installation, itérations documentées),
   stockage {sel, itérations, empreinte dérivée} SEULEMENT (jamais le PIN,
   jamais en clair, jamais dans les logs) ; règles de format (6-12
   chiffres, refus des valeurs évidentes : 000000, 123456, répétition) ;
   politique centralisée des actions (CONSULTATION / MODIFICATION /
   DESTRUCTION_OU_SENSIBLE → `autorise(action)`) — les composants
   INTERROGENT, aucune condition dispersée ; unit tests complets (§28 :
   dérivation, vérification, refus, pas de secret en clair).
2. **7.2** — Activation et désactivation des protections (§2-3, §12,
   §14) : section Protections réelle — deux réglages INDÉPENDANTS
   (modifications / suppressions et opérations sensibles), première
   activation = explication + création + confirmation du PIN (clavier
   numérique `inputmode`, masquer/révéler), second réglage sans nouveau
   PIN ; désactivation avec PIN, secret SUPPRIMÉ quand plus aucune
   protection n'est active ; préréglage « Tablette partagée » (les deux
   protections + délai court + verrouillage à l'arrière-plan + démarrage
   Bibliothèque) ; préférences = stockage appareil (jamais exportées —
   les secrets sont naturellement hors sauvegardes, décision §21).
3. **7.3** — Déverrouillage au point d'action + session curateur (§7-10,
   §16, §20) : panneau PIN contextuel (titre disant POURQUOI, contexte
   conservé, reprise automatique de l'action après succès, annulation =
   retour exact sans perte) ; session temporaire (5 min d'inactivité par
   défaut ; options 5/15/arrière-plan si simple), indicateur discret +
   « Verrouiller maintenant », UN seul PIN pour les deux niveaux ;
   temporisation progressive dès la 5e erreur (sans fuite d'information,
   compteur remis à zéro au succès) ; retour Android ferme le panneau
   sans exécuter l'action ; verrouillage à l'arrière-plan (heure
   mémorisée, jamais d'apparition furtive).
4. **7.4** — Matrice branchée sur les workflows (§2.A-B, §18-19) : toutes
   les actions de modification (créer/renommer/modifier techniques,
   taxonomies, contributions, médias, imports, compositions — et carnet/
   favoris/captures en mode partagé) et de destruction/sensible
   (suppressions, restauration, rollback, publication, sauvegarde
   complète, protections elles-mêmes) passent par la politique ; le PIN
   ne remplace JAMAIS la confirmation destructive ; opérations
   asynchrones autorisées au départ jamais interrompues par l'expiration ;
   formulaires jamais perdus (PIN demandé à l'enregistrement, brouillon
   conservé).
5. **7.5** — Sécurité des exports + réinitialisation + PIN oublié
   (§13, §21-23) : aucun secret dans les packs ni les sauvegardes
   (préférences non exportées — vérifié par test), restauration sur un
   autre appareil = protections à reconfigurer (documenté) ; remise à
   zéro complète (conséquences, sauvegarde proposée, PIN si actif,
   confirmation renforcée, ni hash ni session résiduels, retour
   Bibliothèque vide) ; « PIN oublié » expliqué honnêtement (réinstaller
   + restaurer une sauvegarde, ou réinitialiser — ni question secrète ni
   porte dérobée) ; journal minimal sans secret.
6. **7.6** — Clôture : scénarios A-L (§27), e2e vertical §28,
   accessibilité du panneau §24, limites réelles §25 documentées sans
   formulation anxiogène, docs §29 (workflows + Mermaid, systeme, matrice
   de conservation, etat), captures regardées (D-026), checkpoint + APK +
   recette Android (§28 : clavier numérique, arrière-plan, expiration,
   retour, orientation, tablette, fermeture forcée).

## État initial du lot 07 (Phase 1, 2026-07-13)

- Base `23e69c6` (+ commit d'ouverture), Git propre, lots 01-06
  ACCEPTABLE.
- Existant : AUCUNE protection dans V3 — `Preferences` (stockage/opfs.ts)
  ne porte ni PIN, ni hash, ni réglage Admin, ni session (version 1 :
  démarrage, dernière discipline, repriseMasquees, thème, tonalité) ; la
  section « Protections » de l'Atelier (6.7) affiche l'état réel sans
  contrôle ; TOUTES les actions sont libres, les suppressions confirmées
  (+ snapshots motivés) — le comportement « appareil personnel » (§1.A et
  §15) est DÉJÀ le défaut produit. Migration §6 : seul le cas « aucun PIN
  existant » existe (V3 n'importe pas les réglages V2 ; les sauvegardes
  V3 n'emportent pas les préférences) — à documenter, rien à migrer.
- Web Crypto (`crypto.subtle`) déjà utilisé (SHA-256 des manifestes
  .movpack) — PBKDF2 disponible dans les cibles (Chromium/WebView).
- Les préférences ne sont PAS incluses dans `exporterTout` (bibliothèque
  + vidéos seulement) : les secrets seront naturellement hors sauvegardes
  — la décision §21 documentera « aucun réglage de sécurité transporté ».
- Points d'accroche identifiés : actions de racine.ts (creer/maj/
  supprimer*, terminerCapture, ajouterMediaFiche, confirmerImport,
  confirmerRestauration, restaurerSauvegarde, publierPack, exporterTout,
  basculerFavori, ajouterNote…) — la politique s'insérera à CES points
  (services), pas dans les gabarits.
- Non touché (§26) : navigation, Bibliothèque, fiche, capture, Favoris,
  Compositions, architecture de l'Atelier hors section sécurité, modèle
  identité/contribution, rapprochement, `.movpack`, stockage des médias,
  plateformes, graphisme. Changements de modèle limités aux réglages de
  protection (préférences), paramètres de dérivation, état de session
  NON persistant. Ni comptes, ni rôles, ni biométrie, ni chiffrement
  intégral.

## Découpage du sous-lot 8A en boucles (Registre et cycle de vie des médias)

1. **8A.1** — Modèle logique + registre dérivé (§1-3) : métadonnées
   OPTIONNELLES sur `Media` local (mime, extension canonique, nom
   original, taille, ajouteLe, origine du média : caméra/fichier/import —
   rien d'obligatoire qu'on ne sait pas obtenir, jamais de fausse taille
   pour un lien) ; `registreMedias(b)` PURE : id → {références (contribs,
   blocs, mediaPrincipal), méta, où} — le registre se CALCULE (jamais un
   compteur maintenu à la main, §3) ; unit complet.
2. **8A.2** — Ingestion unique + déduplication (§5, scénario B) :
   pipeline `ingererVideo(File)` — métadonnées, SHA-256 (Web Crypto),
   recherche d'un identique (taille + empreinte, jamais le nom seul),
   déduplication (id existant réutilisé, nouvelle référence, UN SEUL
   fichier physique), sinon écriture ; branché sur capture ET
   ajout-média ; unit + e2e (deux fois le même fichier → une seule
   entrée physique, deux références).
3. **8A.3** — Références multiples sûres (§4, scénario A) : AUDIT de
   toute suppression physique (rollback de capture, suppression de
   contribution/composition/technique) — un fichier encore référencé
   ailleurs n'est JAMAIS supprimé ; retrait de référence → recalcul →
   orphelin (flux 6.5 existant) ; e2e scénario A complet.
4. **8A.4** — Nommage physique + arborescence + quota (§6-10) :
   `<mediaId>.<extension>` pour les NOUVEAUX fichiers, résolution
   rétrocompatible (les anciens fichiers nus restent lisibles — jamais de
   renommage en masse sans reprise) ; zone `staging/` pour les écritures ;
   estimation d'espace avant restauration/import volumineux
   (`navigator.storage.estimate`, honnête si non fiable) ; documentation
   des emplacements réels par cible (§8) et de la politique de
   miniatures (§9 : aucune miniature générée en V3 — vignettes rendues à
   la volée, rien à sauvegarder — documenté).
5. **8A.5** — Clôture 8A : scénarios A/B rejoués, docs (systeme :
   registre et cycle de vie ; workflows si besoin ; matrice), captures si
   UI touchée, checkpoint + APK + recette ciblée.

## État initial du sous-lot 8A (Phase 1, 2026-07-13)

- Base `c38a3fb` (+ commit d'ouverture), Git propre, lots 01-07
  ACCEPTABLE.
- Existant : `Media` = {id ULID, type local/lien/plateforme, ref,
  service?, sha256?, label?} — `sha256` DÉCLARÉ mais JAMAIS calculé
  (aucune déduplication réelle aujourd'hui) ; AUCUNE autre métadonnée
  (ni mime, ni taille, ni nom original, ni date) ; les fichiers OPFS
  s'écrivent sous `videos/<mediaId>` SANS extension (`ecrireVideo`) ;
  pas de zone temporaire (`staging/`) — `terminerCapture` garde le File
  en mémoire et n'écrit qu'à la fin (pas d'orphelin à l'abandon ✓),
  `ajouterMediaFiche` écrit puis persiste avec rollback (7.4/4.5) ;
  registre = néant (les diagnostics 6.5 recalculent références vs
  fichiers à l'ouverture de l'Atelier — la bonne base : en faire une
  fonction pure réutilisée) ; suppression physique directe : rollback de
  capture (`supprimerVideo` des vidéos qu'il vient d'écrire — sûr),
  `supprimerVideoOrpheline` (revérifie les références ✓) ; les AUTRES
  suppressions (contribution, technique, composition) ne touchent PAS
  les fichiers → orphelins diagnostiqués (6.5) — comportement déjà sûr
  côté « jamais supprimé si référencé », à prouver par scénario A.
- Miniatures : AUCUNE générée (les vignettes sont des rendus à la volée) —
  la politique §9 se documente, rien à migrer.
- Non touché (§39) : navigation, Bibliothèque, fiche, capture (UX),
  Favoris, Compositions (UX), Atelier (architecture), sécurité
  fonctionnelle, provenance, rapprochement, graphisme ; AUCUNE
  anticipation de 8B (manifeste/intégrité), 8C (transactions), 8D
  (Android/plateformes).

## Découpage du sous-lot 8B en boucles (.movpack, manifeste et intégrité)

1. **8B.1** — Manifeste complet + intégrité par fichier (§13-14, §28) :
   conteneur v4 — inventaire des fichiers {chemin canonique, taille,
   SHA-256} couvrant bibliotheque.json ET chaque média (algorithme dit),
   version éditoriale (défaut 1), options d'inclusion (médias, contenu
   personnel — dites, jamais devinées) ; vérification à la lecture :
   liste → tailles → empreintes, refus AVANT mutation sur tout écart
   (fichier manquant, taille ou empreinte différente) ; fichier inattendu
   ignoré AVEC avertissement (politique documentée) ; lecture
   rétrocompatible des conteneurs v3 (empreinte globale seule) ; unit +
   e2e. NOTE (Opus, reprise) : l'**identité stable au renommage** (le
   point « idDePack au renommage » tracé au lot 6) est un comportement
   distinct — EXTRAIT en micro-boucle dédiée **8B.1id** (elle touche la
   publication et peut exiger une décision de modèle : y arriver après
   8B.1, l'assesser honnêtement, jamais l'anticiper ici).
2. **8B.2** — Structure canonique + nature du conteneur (§11-12) :
   nouveaux conteneurs `medias/<mediaId>.<extension>` (extension du
   registre 8A), lecture rétrocompatible `videos/<id>` (v3 et
   historiques) ; MIME applicatif documenté
   (`application/vnd.movenso.movpack+zip`, repli `application/zip`) ;
   vérification de structure resserrée (signature ZIP + manifeste +
   version + structure attendue — jamais l'extension seule) ; unit + e2e
   réimport d'un conteneur v3 réel (fixture).
3. **8B.3** — Export à mémoire bornée (§15) : streaming fflate (API Zip
   incrémentale) — médias traités UN par UN, buffers libérés,
   progression affichée, annulation propre tant que l'état est cohérent
   (l'export n'écrit pas d'état : annuler = jeter le flux) ; jamais tout
   le ZIP en un tableau unique ; l'import reste tel quel (zone de
   préparation → 8C).
4. **8B.4** — Tailles de référence (§16) : épreuve outillée hors verifier
   (script navigateur dédié : centaines de techniques, ≥20 médias,
   ≥500 Mo cumulés, un média ≥150 Mo) — démontrer absence de chargement
   simultané, progression, pas de crash mémoire, résultat restaurable ;
   DOCUMENTER les limites réelles observées (pas de promesse illimitée).
5. **8B.5** — Pack publié, export de composition, JSON historiques
   (§24-26) : audit des références hors portée à la publication (jamais
   de relation cassée silencieuse — ajoutée, signalée ou exclue avec
   avertissement) ; réimport d'une composition exportée sans duplication
   d'identités (idempotence à prouver) ; JSON historique : l'aperçu
   d'import DIT « ni manifeste ni intégrité de conteneur » + rapport ;
   packs-demo : déjà de vrais .movpack ✓ (constaté à l'ouverture).
6. **8B.6** — Clôture 8B : scénarios D (intégrité) et C partiel (export
   volumineux côté conteneur) rejoués, docs (systeme §5 formats,
   workflows si besoin, matrice), checkpoint + APK + recette ciblée.

## Découpage du sous-lot 8D en boucles (Android et matrice des plateformes)

1. **8D.1** — Observabilité et diagnostic (§38) : builder PUR `diagnostic(b, …)`
   (`src/domaine/diagnostic.ts`) — identifiant d'app/format/schéma, plateforme,
   compteurs (disciplines/techniques/contributions/compositions/favoris/médias),
   santé médias (manquants, orphelins), estimation d'espace, versions ; JAMAIS
   de secret (ni PIN, ni empreinte de PIN, ni contenu personnel, ni octets
   média, ni URL sensible). Action Atelier « Exporter le diagnostic » (fichier
   texte). unit (builder pur, absence de secret) + e2e (l'action produit un
   diagnostic lisible sans secret).
2. **8D.2** — Reproductibilité du build (§37) : `.nvmrc` (Node 22), versions
   requises documentées (Node 22, Java 21, Android SDK via Capacitor 8, Gradle
   wrapper généré) alignées sur la CI ; confirmer la stratégie Android B
   (génération déterministe `npx cap add/sync`, rien de natif versionné —
   déjà prouvée par chaque run APK) ; README : reprise en 30 min, builds,
   artefacts, inspection `.movpack`, emplacements logiques.
3. **8D.3** — Identité Android, plateformes, matrice et clôture (§29-36) :
   §30 identité (appId `fr.prettozm.movenso.v3`, appName Movenso, versionName
   d'intention, permissions minimales — pas de stockage global, la caméra
   passe par l'intent système via `<input capture>` ; orientation libre,
   tablette prioritaire) ; §31 partage — mécanisme LIVRÉ = téléchargement
   WebView vers Téléchargements (accessible, DIT) ; share-sheet natif DIFFÉRÉ
   avec raison documentée (vérif appareil impossible ici + `@capacitor/
   filesystem` base64 non borné casserait la garantie mémoire 8B sur grosses
   sauvegardes) ; §33 chaîne release documentée (keystore hors dépôt, secrets
   CI) sans jamais committer de secret ; §34 « Web livré, PWA différée »
   (aucun manifeste installable ni service worker) ; §35 Electron ABSENT avec
   analyse de perte V2 (exécutable Windows portable) ; §36 matrice factuelle
   des cibles ; scénario M (matrice sans mention ambiguë) ; checkpoint 8D.

## État initial du sous-lot 8D (2026-07-13, session 24)

- Base : clôture 8C, Git propre, 8A/8B/8C clos.
- Android : AUCUN dossier `android/` versionné — généré en CI (apk.yml :
  `npx cap add android` + `npx cap sync android` + `gradlew assembleDebug`,
  APK debug en artefact). `capacitor.config.json` = {appId
  `fr.prettozm.movenso.v3`, appName Movenso, webDir dist}. Deps : @capacitor/
  core + @capacitor/app (retour Android / verrouillage arrière-plan) ;
  @capacitor/android (dev). Détection native déjà en place (`racine.ts` l.187).
- Partage : `telechargerFichier` = `<a download>` → Téléchargements de la
  WebView (déjà DIT dans la sortie ; partage système natif jamais implémenté —
  tracé au lot 6 §20, réserve reportée ici).
- PWA : aucun `manifest.webmanifest` ni service worker → « Web uniquement, PWA
  différée ». Electron : absent depuis le début de V3.
- Diagnostic : l'Atelier calcule déjà médias manquants/orphelins/tailles, mais
  AUCUNE action « Exporter le diagnostic » (§38).
- Non touché (§39) : tout le produit fonctionnel ; 8D ne touche que
  reproductibilité, diagnostic, partage, docs et config de plateforme.

## État initial du sous-lot 8B (2026-07-13)

- Base : clôture 8A (97657a4), Git propre.
- Existant (`src/echange/movpack.ts`, pur, fflate) : conteneur v3 ZIP =
  `manifeste.json + bibliotheque.json + videos/<ULID>` (fichiers de pack
  SANS extension — le nommage 8A ne touche que l'OPFS local) ; manifeste
  minimal {format, version=3, id, nom, portee complet/discipline/
  composition, auteur?, conditions?, creeLe, versionSchema, empreinte
  (SHA-256 de bibliotheque.json SEULEMENT), videos: liste d'ids nue —
  ni tailles ni empreintes par fichier ni options d'inclusion ni version
  éditoriale} ; lecture : signature ZIP par contenu (`estZip`), exigence
  manifeste+bibliotheque, refus des versions futures avec version
  minimale dite ✓, intégrité vérifiée sur bibliotheque.json seul,
  fichiers inattendus ignorés EN SILENCE, vidéos par préfixe `videos/` ;
  `idDePack(nom)` RECALCULÉ du nom à chaque publication (renommer =
  changer d'identité — point tracé au lot 6, à régler en 8B.1) ;
  `exporterMovpack` construit TOUT en mémoire (Map complète des vidéos +
  `zipSync` un seul tableau) — §15 non satisfait ; export de composition
  EXISTANT (même conteneur, portée `composition`) ; JSON nu détecté par
  contenu et importé (manifeste absent → l'aperçu ne dit PAS l'absence
  d'intégrité) ; packs-demo CI = vrais .movpack (kodokan, club-judo) ✓ ;
  progression d'export : AUCUNE (téléchargement d'un bloc).
- Non touché : import transactionnel/bascule d'état/échec (§17-19 → 8C),
  sauvegarde/restauration/snapshots/corbeille (§20-23 → 8C), Android/
  plateformes/partage natif (§29+ → 8D), compatibilité V2 outillée
  (§27 — outillage existant, audit éventuel en 8B.5 sans y toucher).

## Découpage du sous-lot 8C en boucles (transactions, sauvegarde, restauration)

1. **8C.1** — `amenderContribution` transactionnel (§18) : extraire une
   fonction PURE `appliquerAmendement(contribution, patch)` qui retourne une
   contribution amendée SANS muter l'original (donc capture d'état AVANT
   mutation de fait) ; le service applique le résultat puis persiste et, sur
   échec, restaure l'exemplaire d'origine COMPLET (aucune valeur modifiée ne
   réapparaît, y compris une clé ajoutée/supprimée). CORRIGE un bug réel : le
   `structuredClone(c)` de rollback était capturé APRÈS la mutation (rollback
   no-op) ; unit sur la fonction pure (description posée/effacée, attribution,
   original intact).
2. **8C.2** — Bascule d'état métier PROTÉGÉE (§18) + reprise au démarrage :
   `StockageOpfs.sauvegarder` n'écrase plus `bibliotheque.json` en place —
   écriture dans `bibliotheque.json.tmp`, relecture+validation, puis swap
   contrôlé (l'ancien conservé jusqu'au succès) ; au démarrage, un `.tmp`
   résiduel = commit inachevé → écarté, dernier état validé conservé, staging
   nettoyé. Marqueur minimal, jamais de prétention d'atomicité parfaite.
   E2E : reload avec `.tmp` injecté → état précédent valide, transaction
   inachevée nettoyée (scénario E côté état).
3. **8C.3** — Atomicité média+donnée métier UNIFIÉE sur tous les parcours
   (§17, §19) + concurrence : un helper commun (écrire médias neufs →
   persister → sur échec, retirer la contribution ET les fichiers NEUFS,
   jamais les dédupliqués) partagé par ajouterMediaFiche / terminerCapture /
   **terminerCaptureRepere** (trou actuel : la vidéo du repère reste orpheline
   si la persistance échoue) ; garde anti-double-appui généralisée (aujourd'hui
   seule `terminerCapture` la porte). Échecs injectés AVANT (validation),
   PENDANT (écriture média) et APRÈS (persistance) ; aucun orphelin, aucune
   référence fantôme, aucune duplication au réessai. E2E (échec de persistance
   simulé sur chaque parcours → aucun fichier neuf résiduel).
4. **8C.4** — Sauvegarde complète vs snapshot, rétention, promesse réconciliée
   (§20-23) : `exporterTout(avecVideos)` = conteneur `complet` — quand
   `avecVideos` et tous les médias présents → « Sauvegarde complète », sinon
   « Sauvegarde partielle » nommant les exclusions (jamais « complète » si des
   médias manquent, §20) ; DÉCISION D-065 : les préférences d'appareil
   (thème, tonalité, démarrage, protections/PIN) ne voyagent JAMAIS (invariant
   lot 7 §21 intact — garantie la plus forte contre toute fuite de secret) →
   la promesse est reformulée : le savoir et les médias sont restaurés à
   l'identique, les réglages d'appareil se reconfigurent (dit dans le rapport
   de restauration et la matrice) ; snapshots = état métier seul (stratégie B,
   §22), limite médias déjà dite — la rétention physique existe DE FACTO (la
   suppression physique d'un média n'arrive qu'à l'orphelin confirmé à
   l'Atelier, jamais immédiatement après une action métier : le rollback d'un
   snapshot retrouve donc les octets tant que l'orphelin n'a pas été purgé) —
   à documenter/prouver (§23). Un test + docs.
5. **8C.5** — Clôture 8C : scénarios E (interruption état+média) et G
   (snapshot : ce qui revient, limite média annoncée AVANT) rejoués en e2e ;
   docs (systeme §transactions/bascule/reprise, workflows interruption +
   sauvegarde + restauration, matrice de conservation snapshot vs sauvegarde) ;
   checkpoint 8C. Enchaîner 8D SANS arrêt (mandat humain).

## État initial du sous-lot 8C (2026-07-13, session 24)

- Base : clôture 8B (b4a884f), Git propre, 8A+8B clos.
- Transactions existantes : `#persister(b)` = `stockage.sauvegarder(b)` (valide,
  snapshot 1×/session, puis `ecrireTexte(bibliotheque.json)` — ÉCRITURE DIRECTE
  EN PLACE, §18 non satisfait : un crash mid-write peut corrompre l'état) +
  `this.bibliotheque = {...b}`. Médias : `ecrireVideo` passe par `staging/` puis
  `move` vers `videos/` (un fichier n'apparaît complet — bon), mais le COUPLE
  média+métier n'est pas journalisé : écrire la vidéo PUIS persister, avec
  rollback des fichiers NEUFS sur échec (ajouterMediaFiche ✓, terminerCapture ✓)
  — SAUF `terminerCaptureRepere` (écrit la vidéo, `modifierComposition` persiste,
  mais aucun rollback du fichier neuf → orphelin possible). `amenderContribution`
  a un rollback CASSÉ (clone après mutation). Anti-double-appui : seulement
  `terminerCapture` (`#terminaisonEnCours`). Import/restauration : proposés
  AVANT mutation (importEnAttente/restaurationEnAttente), snapshot préalable,
  refus d'espace avant écriture ✓ — mais pas de reprise au démarrage d'une
  écriture média interrompue (orphelins possibles → diagnostiqués à l'Atelier).
- Sauvegarde : `exporterTout(avecVideos)` = conteneur `complet` (= type
  sauvegarde). Préférences JAMAIS exportées (lot 7 §21). Snapshots = JSON état
  seul (rotation 10), motivés, sans octets vidéo (limite dite). Corbeille : pas
  de corbeille dédiée — mais suppression physique différée à l'orphelin confirmé
  (rétention de fait).
- Non touché (§39) : navigation, Bibliothèque, fiche, capture (UX), Favoris,
  Compositions (UX), Atelier (architecture), sécurité fonctionnelle, provenance,
  rapprochement, relations, graphisme ; AUCUNE anticipation de 8D. Modèle : les
  évolutions se limitent à transactions/versionnement/migrations (§39).

## Découpage du lot 09 en boucles (identité graphique et consolidation UX)

Lot de FINITION : aucune règle fonctionnelle ne change (§1/§39) ; adaptations
autorisées = mise en page, typo, couleurs, icônes, densité, responsive,
hiérarchie, libellés courts, placement d'actions DÉJÀ validées, feedback,
accessibilité. Toute faiblesse fonctionnelle = documentée, pas corrigée.

1. **9.1** — Système de tokens consolidé + coque/contenu (§2-8) : aligner les
   tokens existants (`--papier`/`--carte`/`--encre`/`--sourdine`/`--trait`/
   `--accent`…) sur la taxonomie du §4 (surface-shell/page/elevated/muted/media,
   text-primary/secondary/on-shell, border-subtle, accent-primary, state-danger/
   warning/success/info) ; établir « coque sombre / contenu clair » (barres
   sombres, contenu papier même en thème clair) ; échelles typographique (§6) et
   d'espacement (§7) ; limiter rayons/cartes (§8). Base de tout le reste — aucun
   écran refondu ici, seulement les fondations centralisées.
2. **9.2** — Coque : barre supérieure + navigation basse + action principale
   unique (§10-12) : hauteur stable, signaux multiples d'onglet actif (pas
   couleur seule), une seule action contextuelle par écran.
3. **9.3** — Bibliothèque (§13-15) : racine média-first, grille discipline dense
   (2 col téléphone / 3-6 tablette, miniatures à ratio commun, média manquant ≠
   sans média), recherche/filtres compacts (chips = sélections actives seules).
4. **9.4** — Fiche + provenance + carnet (§16-18) : hiérarchie média-first sans
   cartes imbriquées, voix (une développée, source identifiable), langage de
   provenance cohérent (libellé + icône + accent discret, JAMAIS couleur seule).
5. **9.5** — Pratique + éditeur de composition + mode entraînement (§19-21) :
   racine compacte (À reprendre en attention seulement si action, favoris en
   grille, compositions éditoriales), éditeur sobre, entraînement lisible à
   distance sur tablette.
6. **9.6** — Atelier + formulaires + dialogues + états vides + feedback + alertes
   (§22-28) : Atelier plus dense sans redevenir Admin, zone danger distincte,
   états vides standardisés (titre + 1 phrase + actions), rouge RÉSERVÉ
   (intégrité/suppression/perte), trois niveaux info/attention/erreur.
7. **9.7** — Responsive tablette/paysage + accessibilité + animations + perf
   (§29-32, §36) : densité tablette (panneaux côte à côte), paysage sans
   chevauchement des zones système, focus clavier visible, `prefers-reduced-
   motion`, un seul lecteur actif, listes fluides (corpus de centaines).
8. **9.8** — Icônes + libellés + identité Movenso + captures + tests visuels +
   docs + clôture (§9, §33-38, §41-43) : famille d'icônes unique (remplacer les
   emojis de production), passe de cohérence des libellés, marque sobre,
   corpus de captures de référence, tests de régression visuelle ciblés (si
   l'infra le permet), docs (systeme : tokens/thèmes/composants/responsive/
   a11y ; guide visuel ; matrice de conservation), checkpoint + APK + recette.

## État initial du lot 09 (Phase 1, 2026-07-13)

- Base : clôture 8 (`80efd65`), Git propre, lots 01-08 ACCEPTABLE.
- CSS : `src/styles/app.css` (~525 lignes) — DÉJÀ un socle de tokens
  (`--papier`, `--carte`, `--encre`, `--sourdine`, `--trait`, `--accent`/
  `--accent-fonce`/`--sur-accent`, `--indigo*`, `--ocre*`, `--ui`, `--serif`),
  thèmes `clair`/`sombre`/système (via `prefers-color-scheme` + `data-theme`),
  6 tonalités (`data-tonalite`, défaut vermillon `#B23A26` — chaude, cohérente,
  non-ceinture) ; styles composant inline dans `vues.ts`/`atelier.ts`/
  `compositions.ts`/`pratique.ts`/`video-locale.ts`/`racine.ts`.
- Écart à combler : pas de distinction explicite coque(sombre)/contenu(clair)
  formalisée en tokens ; taxonomie de surfaces à nommer (§4) ; densité tablette
  et responsive à renforcer ; emojis utilisés comme icônes (§9 interdit en prod) ;
  cartes/rayons à rationaliser (§8) ; échelles typo/espacement à centraliser.
- DÉCISION accent (§5) : accent primaire = **vermillon** (défaut existant,
  chaud/naturel, non-ceinture) ; le sélecteur de tonalité (6 accents) est une
  capacité VALIDÉE (D-025, conservée lot 6 §27) — §1 interdit de la retirer :
  conservée, ce n'est pas « un sélecteur complet de couleurs » (§5) mais 6
  accents curatés. Tokens centralisés, aucune valeur en dur dispersée.
- Non touché (§39) : modèle métier, stockage, `.movpack`, recherche,
  rapprochement, sécurité, capture, compositions (logique), publication,
  import, restauration, Android (cible), PWA/Electron. AUCUN nouvel écran/
  onglet/fonction ; toute modif fonctionnelle nécessaire REMONTÉE avant.

## Découpage du lot 10 (recette finale — MASTER §13, lot §3)

Lot de VÉRIFICATION et CLÔTURE : périmètre GELÉ, aucune nouvelle fonction, aucun
redesign. Trois sous-étapes, un commit dédié chacune.

1. **10A — Audit (sans correction fonctionnelle, §3/§5/§25)** : état initial
   (branche, commits, versions app/modèle/movpack/Node/npm/Java/Capacitor, OS,
   Git) ; exécuter installation propre + typecheck + unit + e2e + build web +
   build Android (CI) + packs démo + inspection `.movpack` ; matrice des
   capacités (§6, statuts démontré auto/manuel/partiel/non/échec/N-A) ; classer
   les anomalies (P0/P1/P2/P3, §4) ; plan de correction FERMÉ. **NE RIEN
   corriger. S'ARRÊTER après le rapport 10A → VALIDATION HUMAINE du plan P0/P1
   obligatoire avant 10B (§25).** Commit `lot-10a-audit`.
2. **10B — Stabilisation (§26-27)** : corriger UNIQUEMENT les P0/P1 validés (+
   P2 trivial sans risque) ; un test de non-régression par défaut ; cause
   racine + correction minimale ; ne pas refondre. Fin : aucun P0/P1 ouvert,
   build propre, APK produit, matrice à jour. Commit `lot-10b-stabilisation`.
3. **10C — Recette finale (§28-29)** : repartir d'un build/environnement PROPRE ;
   exécuter les 10 scénarios critiques + matrice complète sans toucher au code ;
   artefacts + checksums ; rapport final + comparaison V2/V3 + backlog post-V3 ;
   décision **GO / GO AVEC RÉSERVES / NO-GO** (D-056). Commit `lot-10c-recette`.

## État initial du lot 10 (Phase 1, 2026-07-13)

- Base : clôture 9 (8d26c299 + consignes), Git propre, lots 01-09 ACCEPTABLE.
- Réserves connues entrant dans l'audit (candidates P2/P3, à confirmer en 10A) :
  lot 8 — R2 partage-sheet natif différé, R3 relations hors périmètre à la
  publication (P2), R4 `majContribution` mutation en place (mineur), R5 PWA/
  Windows/Electron absents (déclarés), R6 V2 import in-app non premier rang ;
  lot 9 — V1 icônes SVG unifiées (§9), V2 tablette côte à côte (§31), V3 logo.
  AUCUN P0/P1 connu à ce stade — à confirmer par l'audit.
- Interdits (§40) : aucune fonction, aucun redesign, aucun changement de modèle
  hors nécessité P0/P1 prouvée, jamais de fusion/force-push/main.

## Boucles terminées

| Date | Lot | Boucle | Commit | Tests | Recette | Statut |
|---|---|---|---|---|---|---|
| 2026-07-13 | 10 | 10C RECETTE FINALE (environnement/build PROPRE, §28-39) : `rm -rf dist dist-packs` puis `npm run verifier` VERT (132 unit + e2e) sur build propre ; artefacts régénérés (build web, packs démo kodokan/club-judo, inspecteur INTÈGRE) + **checksums SHA-256** consignés ; audit de non-régression ciblé de la correction A1 (publication all-in-scope + import inchangés, e2e publication 8B.1id toujours vert) ; les 10 scénarios critiques (§29) couverts par e2e + recettes Android humaines lots 1-9 ; **rapport de recette `docs/archives/rapport-recette-v3.md`** (structure §38 A-I + comparaison V2/V3 §39 + backlog post-V3 §37). Candidate `3.0.0-rc.1`. **DÉCISION : GO AVEC RÉSERVES** (§31 — 0 P0, 0 P1, seulement P2/P3 connus, aucune réserve sur données/PIN/restauration). Arrêt à la décision finale | (ce commit) | verifier vert (132) sur build propre | rapport-recette-v3.md | VERT — DÉCISION RENDUE |
| 2026-07-13 | 10 | 10B STABILISATION — correction UNIQUE autorisée : P2 A1 (relations hors périmètre à la publication, D-066). `extrairePackDiscipline` filtre désormais les relations dont la cible est hors périmètre et retourne `{extrait, relationsExclues}` : la relation LOCALE n'est jamais modifiée, la cible jamais ajoutée, seule la relation est exclue du FICHIER ; l'aperçu de publication (atelier) ANNONCE le nombre + raison + détail actionnable (techniques concernées cliquables) ; le rapport final (`dernierFichier.resume`) rappelle les exclusions ; jamais de lien pendant publié. 7 assertions unit (`movpack.test.ts`, +2 tests → 132 total) + e2e (publier → pack sans relation pendante, local intact, rapport annonce l'exclusion). A2-A6 NON traités (réserves). Aucun autre changement | (ce commit) | typecheck+unit(132)+build+e2e verts | REC-010B (A1) | VERT |
| 2026-07-13 | 10 | 10A AUDIT (sans correction, §3/§5/§25) : état initial (b19179e, Git propre, Node 22 / Capacitor 8 / schéma v3 / movpack v4) ; suite exécutée VERTE — typecheck, unit **130/0**, e2e (scénarios A-M + 8A-D/9), build web, CI apk, `epreuve:export` (700 Mo→RSS +1 Mo), packs démo, inspecteur INTÈGRE ; matrice §3 (lots 1-9 ACCEPTABLE) ; anomalies classées — **P0 : AUCUN ; P1 : AUCUN** ; P2 : A1 relations hors périmètre à la publication, A2 tablette côte à côte, A3 import V2 in-app ; P3 : A4 icônes SVG, A5 logo, A6 majContribution ; plateformes différées déclarées. Plan P0/P1 FERMÉ = vide. Rapport dans QUALITY §4. **ARRÊT §25 — validation humaine du plan requise avant 10B** (dont : corriger A1 en 10B ou réserve ?). Aucun code modifié | (ce commit) | verifier vert (130) | rapport 10A (QUALITY §4) | AUDIT RENDU — EN ATTENTE VALIDATION |
| 2026-07-13 | 9 | 9.8 icônes, libellés, identité, docs, clôture (§9, §33-38, §42-43) : audit des emojis (§9) — les vrais emojis-icônes (🎞🎥🔗🔒🔓, flux capture/menus) tracés en LIMITE restante (migration SVG unifiée = consolidation plus large, non risquée en clôture, contrainte 10) ; glyphes monochromes (→✓✕↑↓★) conservés (cohérents, currentColor) ; docs — systeme.md §5quinquies (guide visuel : direction, tokens, thèmes, couleur, provenance, alertes, responsive, a11y, archi CSS, limites) ; captures de référence JOUR+NUIT tel+tab générées ; QUALITY REC-009-001 validé + REC-009-002 (incohérences corrigées, limites) ; checkpoint + verdict lot 9. Aucune logique métier touchée sur tout le lot 9 | (ce commit) | typecheck+unit(130)+build+e2e verts | captures final-jour/final-nuit | VERT |
| 2026-07-13 | 9 | 9.7 responsive + accessibilité + tonalités (§29-32, §36 ; contraintes 7-9) : VÉRIFIÉ en captures — thème SOMBRE cohérent (coque très sombre distincte du contenu, hiérarchie conservée, pas de mur de gris) ; tonalité indigo en NUIT fonctionne (accent + `--accent-sur-shell` s'adaptent via color-mix ; sémantiques FIXES) ; `:focus-visible` accent + `prefers-reduced-motion` déjà respectés ; zones sûres via `env(safe-area-inset-*)` sur coque/feuille/fab (inchangées). AMÉLIORATION tablette RETENUE (§6/§31, contrainte 9) : largeur de lecture maîtrisée (`.voix-corps p`/`.points` max 62ch) + vidéo non étirée (max 620px) — SANS sur-colonnage. Captures nuit + nuit-indigo produites. Landscape/clavier/petits téléphones : layout inchangé structurellement (positions en insets) → confirmation en recette Android | (ce commit) | typecheck+build+e2e verts (unit 130) | captures nuit/nuit-indigo | VERT |
| 2026-07-13 | 9 | 9.6 Atelier + états + alertes (§22-28 ; contraintes 4, 6) : CONTRAINTE 6 corrigée — les KPI « à compléter — pas des erreurs » (captures à rattacher, techniques sans contenu, **techniques sans niveau**) portaient un voyant ROUGE (n>0 → rouge) ; désormais voyant NEUTRE gris (`.voyant.neutre`, `kpi(..., completer=true)`), le rouge d'intégrité étant réservé aux vrais écarts (vidéos manquantes, relations cassées, orphelins) — §28 respecté (trois niveaux : ok/neutre/erreur) ; libellés de section de l'Atelier calmés (sans capitales, via 9.3). Aucune logique métier touchée | (ce commit) | typecheck+build+e2e verts (unit 130) | captures l96 | VERT |
| 2026-07-13 | 9 | 9.5 Pratique + éditeur composition + entraînement (§19-21 ; contraintes 2, 4) : blocs de composition distingués par la FORME (technique = bordure pleine + miniature ; texte = pointillés) et non plus par un filet bleu (`.bloc.technique` : indigo → neutre — le bleu reste à la provenance) ; `.bloc-nature` sans capitales ; Pratique déjà compacte (en-tête 9.2, étiquettes calmées 9.3). Mode entraînement (grandes actions, texte à distance) inchangé. Éditeur réel couvert par l'e2e composition. Aucune logique métier touchée | (ce commit) | typecheck+build+e2e verts (unit 130) | e2e composition | VERT |
| 2026-07-13 | 9 | 9.4 fiche + provenance + carnet (§16-18 ; contraintes 2, 4) : en-tête de voix RÉ-HIÉRARCHISÉ — le NOM de source est primaire (« Kodokan », graisse, couleur de texte), la provenance est un tag SECONDAIRE (« · Référentiel ») dont la couleur sémantique (indigo/ocre) ne vit QUE sur ce petit tag (l'indigo ne colore plus tout l'en-tête → moins de concurrence avec l'accent) ; filet latéral de provenance conservé (signal source documenté). Média-first et hiérarchie de fiche inchangés. Aucune logique métier touchée | (ce commit) | typecheck+unit(130)+build+e2e verts | captures l94 | VERT |
| 2026-07-13 | 9 | 9.3 Bibliothèque + audit des bleus + densité (§13-15 ; contraintes 2, 4, 9) : `.etiquette` n'est plus tout-en-capitales (casse normale, interlettrage 0 — la hiérarchie vient du tiret vermillon + graisse, §6/§223) ; initiales de repli (`.vignette-initiale`, `.carte-pack .kanji`) passées d'indigo décoratif à une teinte NEUTRE (le bleu reste réservé à la provenance/source — `.voix.reference`, `.carte-voix`, relations — jamais un second accent) ; grille discipline auto-fill conservée (colonnes lisibles sur tablette, pas de sur-colonnage). Vérifié en captures (titre d'écran lisible, plus de mur de capitales, bleu décoratif retiré). Aucune logique métier touchée | (ce commit) | typecheck+unit(130)+build+e2e verts | captures l93 | VERT |
| 2026-07-13 | 9 | 9.2 coque cohérente + contraste + en-tête Pratique (§10-12 ; contraintes 1 et 5) : `--text-on-shell-mute` relevé (jour `#D3CCBE`, nuit `#AEA695`) pour la lisibilité des textes secondaires sur la coque (marque, nav, titres) ; titre d'écran `.barre .contexte` en pleine couleur de coque + graisse 600 (secondaire mais clairement lisible) ; Pratique reçoit un en-tête `.barre` « Pratique » cohérent avec Bibliothèque (marque) et Atelier (titre). Aucune logique métier touchée | (ce commit) | typecheck+build+e2e verts | direction validée ; propagation | VERT |
| 2026-07-13 | 9 | 9.1 fondations visuelles + coque/contenu (§2-8) : taxonomie de tokens dans `app.css` (`--surface-shell/-2`, `--text-on-shell/-mute`, `--surface-page/-muted/-media`, `--text-primary/-secondary`, `--border-subtle`, `--accent-primary`, `--accent-sur-shell` = accent éclairci via `color-mix` pour lecture sur la coque, `--state-danger/-warning/-success/-info` FIXES et indépendants de la tonalité, `--space-1..6`, `--radius-sm/md/pill`, `--ombre-elevee`, `--t-*`) — anciens noms conservés en ALIAS (zéro composant cassé) ; COQUE SOMBRE (`.marque`/`.barre`/`.barre-nav`) / contenu clair ; onglet actif + logo en accent brillant sur la coque (suit la tonalité) ; couleurs sémantiques séparées de l'accent (`.action-danger`/`.menu-item.danger`/`.voyant.rouge`/`.synthese-atelier` (attention)/`.suppression-discipline`). Appliqué à l'ÉCHANTILLON (Bibliothèque, discipline, fiche, Pratique+composition, Atelier+section, import) ; captures avant/après tel+tab. **POINT D'ÉTAPE — arrêt pour validation humaine de la direction ; ne PAS enchaîner 9.2.** Findings documentés (hors 9.1) : voyant rouge sur « techniques sans niveau » (« à compléter ») → §28, à corriger en 9.6 ; Pratique sans en-tête de coque → 9.2 | (ce commit) | typecheck+unit(130)+build+e2e verts | direction à valider (captures) | VERT — EN ATTENTE VALIDATION |
| 2026-07-13 | 8C | 8C.6 corrections de l'AUDIT CONTRADICTOIRE (F1/F2) : **F1** — `terminerCaptureRepere` écrivait le fichier PUIS déléguait le PIN à `modifierComposition` ; sur session verrouillée, `#autorise` différait l'action et le fichier neuf était supprimé, l'action différée le re-référençant → orphelin + perte de la capture (contredisait §19). Corrigé : garde PIN à l'ENTRÉE (comme les jumelles) + transaction propre `#persisterAvecMediasNeufs` — sur PIN différé RIEN n'est écrit, la méthode entière est rejouée. **F2** — rollback de `amenderContribution` par index capturé, fragile si `b.contributions` est réassigné en concurrence : substitution désormais PAR ID (`findIndex`), no-op si disparue. e2e bloc 8C.6 (protection active + session verrouillée : aucun fichier avant PIN, capture ouverte, 0 bloc ; après PIN : 1 fichier + 1 bloc le référençant réellement) | (ce commit) | typecheck+unit(130)+build+e2e verts | REC-008C-006 AUTOMATISÉ | VERT |
| 2026-07-13 | 8D | 8D.3 identité Android, plateformes, matrice, clôture §29-36 : systeme.md §5quater — stratégie Android B (génération déterministe, prouvée CI ; bascule en A tracée si natif requis), identité (appId fr.prettozm.movenso.v3, appName Movenso, versionName 3.0.x, permissions minimales — pas de stockage global, caméra par intent système ; tablette prioritaire), partage LIVRÉ = téléchargement WebView (accessible, DIT) + share-sheet natif DIFFÉRÉ avec raison (vérif appareil + `@capacitor/filesystem` base64 casserait la mémoire bornée 8B), chaîne release documentée (keystore hors dépôt, secrets CI, jamais committé), Web LIVRÉ / PWA DIFFÉRÉE (ni manifeste ni service worker), Electron/Windows ABSENTS avec analyse de perte V2, MATRICE des 5 cibles (§36, statuts livré/démontré/différé/absent), scénario M (aucune mention ambiguë). Checkpoint 8D + verdict. Docs seulement | (ce commit) | typecheck+unit(130)+build+e2e verts (inchangés) | matrice §36 + REC-008D-001 | VERT |
| 2026-07-13 | 8D | 8D.2 reproductibilité du build §37 : `.nvmrc` (Node 22, aligné CI) ; README — tableau des versions requises (Node 22, Java 21 Temurin, Android SDK/Gradle via Capacitor 8, Chromium Playwright), reprise en 30 min (ci → test → build → e2e → APK → inspection → packs), stratégie Android B (génération déterministe, rien de natif versionné — prouvée par la CI), emplacements logiques renvoyés à systeme.md ; nouvel outil LOCAL `tools/inspecter-movpack.ts` (lecture seule, aucun secret) — manifeste + intégrité PAR FICHIER (taille+empreinte recalculée), testé sur `dist-packs/kodokan.movpack` (INTÈGRE ✓) | (ce commit) | typecheck vert ; inspecteur exécuté sur un vrai .movpack | outillage (§7) | VERT |
| 2026-07-13 | 8D | 8D.1 observabilité et diagnostic §38 : builder PUR `src/domaine/diagnostic.ts construireDiagnostic(e)` (plateforme, versions schéma/conteneur, compteurs, santé médias — références/présents/manquants/orphelins —, espace ou « indisponible » honnête) SANS aucun secret (ne reçoit ni PIN, ni contenu personnel, ni octets média) ; `app.exporterDiagnostic()` assemble les données réelles (`listerVideos`, `referencesVideosLocales`, `estimerEspace`, `Capacitor.getPlatform`) et télécharge un `.txt` ; action Atelier « Exporter le diagnostic » (Réglages et sécurité). 3 tests unit (130 au total) + e2e bloc 8D.1 | (ce commit) | typecheck+unit(130)+build+e2e verts | REC-008D-001 AUTOMATISÉ | VERT |
| 2026-07-13 | 8C | 8C.5 clôture 8C — scénario G (snapshot) + reprise média + docs + checkpoint : e2e — supprimer une contribution RETIENT son fichier (rétention §22-23, compteur vidéos inchangé), restaurer le snapshot le plus récent ramène la contribution ET sa vidéo ; un résidu de `staging/` est nettoyé au démarrage (§17, jamais un partiel promu). Docs : systeme.md §5ter (transactions/bascule/reprise/atomicité média+métier/snapshots+rétention/D-065), workflows.md §8 (sauvegarde complète vs partielle, transaction+interruption avec Mermaid, snapshot vs sauvegarde). Checkpoint 8C inscrit. VERDICT 8C : ACCEPTABLE (atomicité non parfaite dite ; interruption réelle appareil = recette) | (ce commit) | typecheck+unit(127)+build+e2e verts | REC-008C-005 AUTOMATISÉ | VERT |
| 2026-07-13 | 8C | 8C.4 sauvegarde complète honnête + promesse réconciliée + rétention §20-23 : fonction pure `src/domaine/sauvegarde.ts decrireSauvegarde({avecVideos, nbManquants})` — « complète » UNIQUEMENT si vidéos incluses ET aucune manquante, sinon « PARTIELLE » avec exclusions nommées ; `exporterTout` recompose son étiquette et son résumé dessus (compare `referencesVideosLocales` vs `listerVideos`). DÉCISION D-065 : réglages d'appareil (thème/démarrage/protections/PIN) JAMAIS exportés (invariant lot 7 §21 intact — garantie anti-fuite maximale) → promesse reformulée, dit dans la sortie de sauvegarde ET le rapport de restauration (« réglages d'appareil à reconfigurer »). Rétention (§22-23) : snapshots = état métier seul, suppression physique différée à l'orphelin confirmé (rollback retrouve les octets tant que non purgé) ; corbeille dédiée hors périmètre. BONUS : correction d'un hazard de concurrence introduit en 8C.2 — deux sauvegardes concurrentes se disputaient le `.tmp` de bascule → SÉRIALISATION par file d'attente `#chaineSauvegarde` (fire-and-forget `void #persister` ne peut plus rejeter). 4 tests unit (127 au total) + e2e bloc 8C.4 | (ce commit) | typecheck+unit(127)+build+e2e verts | REC-008C-004 AUTOMATISÉ | VERT |
| 2026-07-13 | 8C | 8C.3 atomicité média+métier UNIFIÉE + concurrence §17/§19 : helper commun `#persisterAvecMediasNeufs(b, fichiersNeufs, annulerMemoire)` (persiste ; sur échec retire les fichiers NEUFS — jamais un dédupliqué — et annule la mutation mémoire) partagé par `ajouterMediaFiche` et `terminerCapture` ; `modifierComposition` retourne désormais le succès pour que `terminerCaptureRepere` COMBLE son trou (le fichier filmé du repère restait orphelin si la persistance échouait — désormais retiré, la capture ne se ferme qu'au vrai succès) ; garde anti-double-appui UNIQUE `#ecritureMediaEnCours` posée synchronement à l'entrée des 3 parcours (remplace `#terminaisonEnCours` limité à terminerCapture). e2e bloc 8C.3 : échec injecté sur chaque parcours → aucune contribution/bloc fantôme, aucun orphelin ; double `terminerCapture` concurrent → 1 contribution + 1 fichier | (ce commit) | typecheck+unit(123)+build+e2e verts | REC-008C-003 AUTOMATISÉ | VERT |
| 2026-07-13 | 8C | 8C.2 bascule d'état PROTÉGÉE + reprise au démarrage §18 : `StockageOpfs.sauvegarder` n'écrase plus `bibliotheque.json` en place — écriture d'un `bibliotheque.json.tmp`, relecture, REVALIDATION (`migrerBibliotheque`+`validerBibliotheque`), PUIS bascule vers le fichier courant (swap OPFS au close), suppression du temporaire ; une erreur avant la bascule laisse l'état courant intact (le service remonte l'exception → rollback mémoire). `charger()` appelle `reprendreTransactionInachevee()` : un `.tmp` résiduel (commit interrompu) est écarté, le dernier état COURANT validé reste la vérité ; `reinitialiser` efface aussi le `.tmp`. Atomicité NON parfaite revendiquée (écrire-valider-basculer + écarter un résidu au démarrage). e2e scénario E côté état (bascule réussie sans temporaire ; `.tmp` tronqué injecté → écarté au reload, « Aïkido » survit, fichier courant inchangé) | (ce commit) | typecheck+build+e2e verts (unit 123) | REC-008C-002 AUTOMATISÉ | VERT |
| 2026-07-13 | 8C | 8C.1 amendement transactionnel d'une contribution §18 : fonction PURE `src/domaine/contribution.ts appliquerAmendement(contribution, patch)` retournant une NOUVELLE contribution sans jamais muter l'original ; `amenderContribution` (racine.ts) substitue l'amendé dans la liste, persiste, et sur exception remet l'exemplaire d'origine à son index — rollback fidèle (aucune valeur modifiée ne réapparaît, y compris une clé effacée/ajoutée). CORRIGE un bug réel : le `structuredClone(c)` de rollback était capturé APRÈS la mutation en place (no-op qui restaurait la version modifiée et ne réeffaçait pas une clé ajoutée). 5 tests unit (123 au total) | (ce commit) | typecheck+unit(123)+build+e2e verts | REC-008C-001 AUTOMATISÉ | VERT |
| 2026-07-13 | 8B | 8B.5 clôture §24-26 + verdict : JSON historique — l'aperçu d'import DIT « ni manifeste ni intégrité de conteneur » (avertissement, même canal que les fichiers inattendus) ; réimport de composition IDEMPOTENT prouvé (unit : double import → une seule composition) ; exclusions carnet/favoris à la publication déjà démontrées ; verdict technique 8B + checkpoint inscrits ; RÉSERVE §24 tracée P2 (relations hors périmètre à la publication : tolérées par le modèle, pas encore signalées) | (ce commit) | typecheck+unit(118)+build+e2e verts | REC-008B-005 AUTOMATISÉ (réserve §24) | VERT |
| 2026-07-13 | 8B | 8B.4 tailles de référence + preuve de mémoire §16 : harnais outillé `tests/epreuve-export-8b.ts` (`npm run epreuve:export`, HORS verifier) — A/correction (202 médias, ZIP relu, 203 empreintes vérifiées ; 2 exports successifs stables ; annulation et erreur à mi-export → rejet sans finalisation) + B/mémoire (blocs générés paresseusement, sortie jetée) : MESURES réelles — un gros média 200 Mo → RSS +61 Mo ; 700 Mo cumulés → RSS **+1 Mo** ; pic blocs=1, buffer max=1 bloc, INDÉPENDANT du volume ; aucun chemin `arrayBuffer` intégral. Distinction QUALITY : démontré structurellement + mesuré en harnais + à vérifier sur Android (recette). Limites documentées (pas de promesse illimitée, comportement OPFS/WebView à confirmer appareil) | (ce commit) | typecheck+unit(118)+build+e2e verts ; `epreuve:export` vert (mesures ci-contre) | REC-008B-004 AUTOMATISÉ (structure+harnais) | VERT |
| 2026-07-13 | 8B | 8B.3 export à mémoire BORNÉE PAR BLOCS §15 : pipeline de bout en bout — `stockage.lireMediaParBlocs(id, 1 Mio)` (Blob.slice→arrayBuffer, jamais le média entier) → `domaine/sha256.ts` SHA-256 INCRÉMENTAL (WebCrypto est one-shot ; conforme octet pour octet, testé sur toutes les bornes de bloc) → `exporterMovpackFlux` (fflate `Zip`/`ZipPassThrough` en flux, drain après chaque bloc) → fichier temporaire OPFS `staging/` (exposé au `close()` seulement) → téléchargement DEPUIS ce fichier adossé au disque (`telechargerFichier`, jamais de copie dans le tas) ; les 3 exports de l'app (`exporterTout`/`publierPack`/`exporterComposition`) rebranchés via `#exporterEnFlux` (+ `#idsMediasPresents` : média absent jamais transformé en entrée vide) ; cycle de vie du temporaire (balayé avant chaque export + au démarrage, supprimé à l'annulation/échec) ; annulation `estAnnule` entre blocs, refus borné si OPFS indisponible ; `exporterMovpack` en mémoire CONSERVÉ pour fixtures de test ; hachage unifié sur le module pur (lireMovpack aussi) ; 7 tests unit (118 au total : sha256 ×4, flux ×3) + e2e existants (export→restauration, corruption, renommage) via le flux | (ce commit) | typecheck+unit(118)+build+e2e verts | REC-008B-003 AUTOMATISÉ (structure ; mesure→8B.4) | VERT |
| 2026-07-13 | 8B | 8B.2 structure canonique + nature du conteneur §11-12 : `exporterMovpack` range les médias sous `medias/<mediaId>.<extension>` (extension dérivée du registre 8A via `registreMedias(b)` — aucun appelant touché, la bibliothèque était déjà passée ; `medias/<id>` nu si inconnue), inventaire d'intégrité aligné sur ces chemins ; lecture RÉTROCOMPATIBLE `medias/` ET `videos/` (helpers `estCheminMedia`/`idMediaDepuisChemin`, id logique retrouvé quels que soient dossier et extension) ; MIME `application/vnd.movenso.movpack+zip` + structure documentés (systeme §5), détection par contenu resserrée (déjà signature ZIP + manifeste + format + version) ; tests movpack ajustés (média sous medias/<id>.<ext>, vrai conteneur v3 sous videos/<id>) + e2e (l'export range sous medias/) | 5b1ce07 | typecheck+unit(111)+build+e2e verts ; CI 29264357059 + APK 29264357119 verts | REC-008B-002 AUTOMATISÉ | VERT |
| 2026-07-13 | 8B | 8B.1id identité de pack STABLE au renommage : l'identité technique du manifeste (clé d'idempotence D-013/D-015) se dérive de l'ULID de l'entité publiée (`idPackStable(d.id)` / `idPackStable(compo.id)`) au lieu du nom (`idDePack`), donc invariante au renommage — `idDePack(nom)` ne sert plus qu'au NOM DE FICHIER lisible ; AUCUN changement de modèle (l'ULID existant suffit — alternative « champ packId persistant » écartée) ; règle l'item hors-périmètre tracé au lot 6 ; 1 test unit (111 au total) + e2e (publier Boxe → renommer « Boxe anglaise » → republier : même manifeste.id porteur de l'ULID, nom de fichier différent) | 5f18e27 | typecheck+unit(111)+build+e2e verts ; CI 29263329620 + APK 29263329579 verts | REC-008B-001id AUTOMATISÉ | VERT |
| 2026-07-13 | 8B | 8B.1 manifeste complet + intégrité par fichier §13-14/§28 : conteneur **v4** — `src/echange/movpack.ts` porte un inventaire `fichiers[{chemin, taille, sha256}]` couvrant bibliotheque.json ET chaque média (`algorithme: "SHA-256"`), `versionEditoriale` (défaut 1), `inclusions` DITES {medias, contenuPersonnel} ; `empreinte` globale + `videos[]` conservés (repli/inspecteurs) ; lecture : vérif liste → tailles → empreintes, refus AVANT mutation (fichier manquant / taille ≠ / empreinte ≠, chemin fautif nommé), fichier inattendu → `ContenuMovpack.avertissements` (ignoré mais signalé, jamais exécuté), **rétrocompat v3** par repli sur l'empreinte globale ; avertissements remontés dans l'aperçu d'import et de restauration (`racine.ts`) ; 7 tests unit (110 au total) + e2e scénario D (octet vidéo altéré → refus « Intégrité », bibliothèque vierge non mutée, 0 média écrit) | 6ea24cd | typecheck+unit(110)+build+e2e verts ; CI 29262970313 + APK 29262970303 verts | REC-008B-001 AUTOMATISÉ | VERT |
| 2026-07-12 | 01 | 1.1 racine Bibliothèque (liste + recherche globale + état vide) | dc1452b | typecheck+unit+build+e2e verts | REC-001-001 AUTOMATISÉ | VERT |
| 2026-07-12 | 01 | 1.2 onglet Pratique (À reprendre inachevé / Favoris vide / Compositions) | 29720f8 | typecheck+unit+build+e2e verts | REC-001-002 AUTOMATISÉ | VERT |
| 2026-07-12 | 01 | 1.3 suppression de l'Accueil (route, onglet, démarrage Bibliothèque, migration préférence, capture « plus tard » → Pratique) | 66f04a9 | typecheck+unit(64)+build+e2e verts | REC-001-003 AUTOMATISÉ | VERT |
| 2026-07-12 | 01 | 1.4 FAB global Capturer supprimé — action contextuelle « Ajouter » sur discipline, capture-repère dans l'édition de composition, barre masquée sous les feuilles | 08e009b | typecheck+unit+build+e2e verts | REC-001-004 AUTOMATISÉ | VERT |
| 2026-07-12 | 01 | 1.5 conservation d'état par onglet (mémoire + pile avec défilement, second appui = racine) + retour Android ordonné §9 | f2b3b37 | typecheck+unit+build+e2e verts | REC-001-005 AUTOMATISÉ (retour Android : manuel) | VERT |
| 2026-07-12 | 01 | 1.6 docs (workflows/systeme/matrice/etat), vérif visuelle D-026 (onglet actif non-couleur-seule corrigé, Pratique dédoublonnée), checkpoint | 54563d8 | verifier complet vert | matrice lot 1 à jour | VERT |
| 2026-07-12 | 02 | 2.0 raccord Bibliothèque après lot 1 (6 points de la recette humaine) | b10d39f | typecheck+unit+build+e2e verts | REC-002-000 AUTOMATISÉ + mesure visuelle | VERT |
| 2026-07-12 | 02 | 2.1 cartes de disciplines : identités uniques · sources · plusieurs voix ; vide « prête à être complétée » ; jamais d'id de pack | c4b00c8 | typecheck+unit(66)+build+e2e verts | REC-002-001 AUTOMATISÉ | VERT |
| 2026-07-12 | 02 | 2.2 recherche globale : vignette + discipline + « N voix » sur chaque résultat ; requête et résultats conservés au retour | 303ec21 | typecheck+unit+build+e2e verts | REC-002-002 AUTOMATISÉ | VERT |
| 2026-07-12 | 02 | 2.3 filtres : « Réinitialiser les filtres » (si actif), état « Aucune technique ne correspond à ces filtres » distinct du vide | 5440134 | typecheck+build+e2e verts | REC-002-003 AUTOMATISÉ | VERT |
| 2026-07-12 | 02 | 2.4 discipline vide : état spécifique + « Créer la première technique » (focus le workflow existant) + « Importer un pack » — le texte périmé « + Capturer » disparaît | 8a8b8df | typecheck+unit+build+e2e verts | REC-002-004 AUTOMATISÉ | VERT |
| 2026-07-12 | 02 | 2.5 filtres conservés PAR discipline (`majFiltres` + mémoire de session, rouvrir restaure) | 6ac1f7e | typecheck+build+e2e verts | REC-002-005 AUTOMATISÉ | VERT |
| 2026-07-12 | 02 | 2.6 vignette privilégiant la source filtrée (§7, sans toucher au média principal) + badge « N voix » discret (§8) + e2e scénarios C et E | d3d01e7 | typecheck+unit+build+e2e verts | REC-002-006 AUTOMATISÉ | VERT |
| 2026-07-12 | 02 | 2.7 docs (workflows/systeme/matrice/etat), captures lot 2 regardées (racine compteurs, explorateur badge voix, aucun-résultat), checkpoint | cd329a1 | verifier complet vert | matrice lot 2 à jour | VERT |
| 2026-07-12 | 03 | 3.1 en-tête de fiche §2/§15/§16 : menu ⋮ (Modifier les informations générales, Retirer), plus de crayon permanent ni de « Terminer », retour Android ferme d'abord le menu | 2784855 | typecheck+unit(66)+build+e2e verts | REC-003-001 AUTOMATISÉ | VERT |
| 2026-07-12 | 03 | 3.2 média principal §3-4 : légende éditoriale (auteur · provenance, jamais un slug), galerie compacte avec média affiché en session (le média principal global ne change pas), fallback « Aucun média » actionnable | e13efe7 | typecheck+unit(66)+build+e2e verts | REC-003-002 AUTOMATISÉ | VERT |
| 2026-07-12 | 03 | 3.3 « Ajouter un média » depuis la fiche §5 (+ reste du §4) : feuille dédiée (Filmer maintenant / vidéo de l'appareil / coller un lien), questions utiles seulement (qui l'a produit, attribution, libellé), jamais « à quelle technique ? », média immédiatement affiché, retour sur la fiche, retour Android ferme la feuille ; action explicite « Utiliser comme aperçu principal de cette technique » | 58b9bbf | typecheck+unit(66)+build+e2e verts | REC-003-003 AUTOMATISÉ | VERT |
| 2026-07-12 | 03 | 3.4 voix §7-8 selon D-027 : une seule ouverte (accordéon piloté), titres éditoriaux « Provenance · auteur » (jamais un slug), ordre §7 (voix du média affiché d'abord puis référentiel→enseignement→ressource→personnel), voix importée intacte avec explication + « Créer une adaptation locale » (contribution personnelle attribuée, préremplie, ouverte, modifiable, sans `origine` — jamais écrasée au réimport), garde `amenderContribution` | 825bb9a | typecheck+unit(67)+build+e2e verts | REC-003-004 AUTOMATISÉ, NR-003-001 ACTIF | VERT |
| 2026-07-12 | 03 | 3.5 relations compactes §11 (+ en-tête §12) : « Relations · N », aperçu de 3 lignes « libellé → cible », « Voir toutes les relations » (session, replié par défaut), « Utilisée dans · N composition(s) » | 85fb706 | typecheck+unit(67)+build+e2e verts | REC-003-005 AUTOMATISÉ | VERT |
| 2026-07-12 | 03 | 3.6 clôture : conservation PAR fiche §19 (`#etatFiches` — voix/média/relations survivent aux navigations liées, au retour et à la bascule d'onglet, e2e), retrait §17.E nommant les compositions dépendantes, vidéo locale absente §17.D → « Vérifier dans l'Atelier », repli ▶ des miniatures hors ligne (défaut attrapé par la revue D-026 des captures), carnet vide sans renvoi à Capturer §9, docs (workflows/systeme/matrice de conservation/matrice QUALITY/etat), 8 captures regardées | dfcbc08 | verifier complet vert (67 unit + e2e) | matrice lot 3 à jour | VERT |
| 2026-07-13 | 03 | 3.7 corrective (recette Android) : en-tête fixe de fiche = nom de la technique (retour et ⋮ intacts, navigation inchangée) ; `nomEditorialSource` — le nom le plus précis, « Club » → « Club judo », jamais un slug, MÊME libellé dans le titre de voix, « Ce contenu vient de … », la légende et l'adaptation ; un seul lecteur média actif (dépliage exclusif + pause croisée des vidéos, NR-003-002) ; double lecture du média affiché impossible (déjà filtré de sa voix), redondance visuelle tracée pour le lot 9 | 2573724 | typecheck+unit(73)+build+e2e verts | REC-003-007 AUTOMATISÉ, NR-003-002 ACTIF | VERT |
| 2026-07-13 | 04 | 4.1 panneau contextuel « Ajouter » §2-3 : FAB sur la racine Bibliothèque (2 gestes : Une technique / Filmer ou garder quelque chose — capture sans discipline restaurée) et sur une discipline (5 gestes, présélectionnée, chaque geste ouvre la capture à la bonne étape) ; création minimale nom+discipline (choisie ou créée) → fiche ; aucun vocabulaire interne ; fermeture sans effet ; retour Android ferme le panneau en premier | 23fbca4 | typecheck+unit(73)+build+e2e verts | REC-004-001 AUTOMATISÉ | VERT |
| 2026-07-13 | 04 | 4.2 création enrichie §4 + doublons §5 : appellation facultative, « Classer maintenant » (famille/niveaux de la discipline, masqué si vides) + « Je le ferai plus tard » ; `doublonsPotentiels` (fonction pure à côté du moteur, non modifié) — suggestions pendant la saisie, « Utiliser « X » » ouvre la fiche, exact unique → confirmation explicite obligatoire, ambigu → candidates sans décision, jamais inter-disciplines | b679d80 | typecheck+unit(74)+build+e2e verts | REC-004-002 AUTOMATISÉ | VERT |
| 2026-07-13 | 04 | 4.3 capture par le contenu §6-7 + fins de parcours §21 : aperçu vidéo (Utiliser / Refilmer ou Choisir un autre / Abandonner — URL objet révoquée, rien d'écrit avant la fin), aperçu lien (service détecté, Modifier préremplie), « Geste 3/3 — sais-tu où le ranger ? », recherche cadrée à la discipline + « Chercher dans toutes les disciplines » (résultats avec vignette et discipline), « Garder pour plus tard » → « Conservé dans Pratique > À reprendre » ; le panneau « Ajouter » réutilise le MÊME chemin vidéo (défaut d'intégration attrapé par l'e2e, corrigé) | d91c6f2 | typecheck+unit(74)+build+e2e verts | REC-004-003 AUTOMATISÉ | VERT |
| 2026-07-13 | 04 | 4.4 personnel par défaut §8 + capture non rattachée complète §9 : plus aucune chip de provenance imposée (« Ce contenu vient de quelqu'un d'autre » en action secondaire, pas de « référentiel » à la capture) ; « Garder pour plus tard » ouvert aux enseignements/ressources — INVARIANT DE VALIDATION REMPLACÉ (increment-1 §2 → lot 4 §9, tracé dans la matrice de conservation), attribution toujours exigée pour le sourcé ; reprise complète : contenu consulté (texte/vidéo locale/lien), texte modifiable, provenance affichée, suppression avec confirmation ; carte « À reprendre » portant l'attribution | 56b0601 | typecheck+unit(74)+build+e2e verts | REC-004-004 AUTOMATISÉ | VERT |
| 2026-07-13 | 04 | 4.5 contribution depuis la fiche §11 (menu ⋮ « Ajouter une contribution » : de qui / texte et-ou média / attribution — jamais la technique) + retour par étapes §16 (`reculerCapture` : saisie de lien → étape précédente → « Que faire de cette capture ? » si contenu, sortie directe sinon) + écritures sûres §14 (anti double-geste, rollback persistance : contribution ressortie + fichier supprimé + capture conservée — chemin d'erreur non automatisé, tracé) + hors ligne §19 (tout local, lien sans réseau) | 6b9988e | typecheck+unit(74)+build+e2e verts | REC-004-005 AUTOMATISÉ (réserve §14 documentée) | VERT |
| 2026-07-13 | 8A | 8A.1 modèle + registre dérivé §1-3 : métadonnées OPTIONNELLES sur `Media` (mime, extension canonique, nomOriginal, taille, ajouteLe, origineMedia caméra/fichier/import — un lien ne porte jamais de fausse taille locale) ; `domaine/medias.ts` PUR : `registreMedias(b)` (id → méta + TOUTES les références : contributions, blocs, mediaPrincipalId — jamais un compteur maintenu à la main) + `referencesVideosLocales(b)` ; la duplication `#referencesVideos` de racine REMPLACÉE par le domaine ; 4 tests unit (89 au total) ; champs additifs optionnels — pas de migration de schéma nécessaire | 91a1073 | typecheck+unit(89)+build+e2e verts | REC-008A-001 AUTOMATISÉ | VERT |
| 2026-07-13 | 8A | 8A.2 ingestion unique + déduplication §5 : `domaine/ingestion.ts` (`empreinteSha256` Web Crypto un fichier à la fois ; `preparerVideo(b, File, origine)` → média complet à écrire OU id existant réutilisé) + `extensionCanonique` (le MIME décide, le nom n'est qu'un repli) et `mediaIdentique` (taille + SHA-256, JAMAIS le nom seul, jamais l'historique sans empreinte) dans `domaine/medias.ts` ; les TROIS sites d'écriture branchés (ajouterMediaFiche, terminerCaptureRepere, terminerCapture — origine caméra/fichier selon `capture.camera`) ; doublon exact → nouvelle référence, AUCUNE réécriture, métadonnées d'origine conservées ; rollback durci : `fichiersEcrits` — un fichier dédupliqué n'est JAMAIS supprimé à l'échec de persistance ; staging/validation type-taille/quota → 8A.4 ; 6 tests unit (95 au total) + e2e scénario B (même contenu renommé → 1 fichier OPFS, 2 références même id/empreinte ; même taille contenu différent → 2e fichier ; 3 références visibles) | 4763ac5 | typecheck+unit(95)+build+e2e verts | REC-008A-002 AUTOMATISÉ | VERT |
| 2026-07-13 | 8A | 8A.3 références multiples sûres §4 : AUDIT de toute suppression physique — `supprimerContribution` CORRIGÉ (seul site qui supprimait les fichiers sans recalcul : avec la dédup 8A.2 il aurait détruit un fichier partagé, et le snapshot « avant-retrait » pointait un fichier disparu) → retrait de référence seulement, le fichier devient orphelin (flux 6.5 : prévisualisation + confirmation) ; `supprimerTechnique`/`supprimerDisciplineEtContenu`/`supprimerComposition` ne touchent pas les fichiers ✓ ; `supprimerVideoOrpheline` revérifie à l'instant T ✓ ; rollbacks = fichiers neufs seulement ✓ ; `reinitialiserTout` = politique explicite ✓ ; unit « capture à rattacher = référence » (96 au total) + e2e scénario A complet (retrait d'une référence → fichier conservé et lisible ; dernière → orphelin diagnostiqué, jamais supprimé en silence ; suppression physique après Vérifier + confirm, l'autre fichier intact) | 66c6b3f | typecheck+unit(96)+build+e2e verts | REC-008A-003 AUTOMATISÉ | VERT |
| 2026-07-13 | 8A | 8A.4 nommage physique + staging + quota §6-10 : nouveaux fichiers `videos/<mediaId>.<extension-canonique>` (jamais le nom humain — il vit dans `nomOriginal`), résolution RÉTROCOMPATIBLE (id nu puis `<id>.<ext>`, jamais de renommage en masse), listers/suppression normalisés sur l'id logique ; écritures via `staging/` (fichier visible dans videos/ seulement une fois complet — move inter-dossiers sondé OK dans le Chromium e2e, repli copie+retrait pour WebView anciennes), staging vidé au démarrage et à la réinitialisation ; `domaine/espace.ts` PUR (`evaluerEspace` marge 10 %/plancher 16 Mo, honnête sans estimation) + `estimerEspace()` (storage.estimate) → refus AVANT mutation dans confirmerImport/confirmerRestauration avec les deux tailles dites, proposition conservée ; import/restauration écrivent avec l'extension du registre ; miniatures §9 : aucune (rendus à la volée, documenté) ; emplacements réels §8 documentés (systeme.md §5bis) ; 6 tests unit (102 au total) + e2e (noms .webm sans nom d'origine, ancien fichier nu lisible via flux orphelin, ctxD quota simulé : refus, tailles dites, zéro écriture) | 6d655c0 | typecheck+unit(102)+build+e2e verts | REC-008A-004 AUTOMATISÉ | VERT |
| 2026-07-13 | 8A | 8A.5 clôture du sous-lot : validation type/taille COMPLÉTÉE (étape 4 du §5 — renvoyée à 8A.4 puis restée ouverte : `refusFichierVideo` refuse vide et non-vidéo AVANT toute écriture aux 3 sites, type absent toléré pour les caméras Android) ; scénarios A/B rejoués (verifier complet), carte d'architecture systeme.md (registre/ingestion/espace au domaine, staging au stockage), matrice QUALITY 8A → AUTOMATISÉ, checkpoint du sous-lot ; AUCUNE capture D-026 : aucune UI nouvelle (les changements 8A sont invisibles hors textes de toast) ; workflows.md inchangé (cycle de vie des médias = mécanique interne, aucun geste utilisateur nouveau) | 97657a4 | typecheck+unit(103)+build+e2e verts ; CI 29260691359 + APK 29260691404 verts | recette Android ciblée DEMANDÉE | VERT |
| 2026-07-13 | 07 | 7.6 clôture : scénario G en e2e (PIN changé — l'ancien refusé, le nouveau accepté), audit scénarios A-L consigné (QUALITY — C expiration, E tablette, F temporisation, I arrière-plan, J formulaire : unit/construction + recette Android), docs §29 (workflows section 7bis avec Mermaid personnel/partagé, systeme — politique, dérivation, session, limites réelles —, matrice de conservation ×7 lignes sécurité V2, etat), matrice QUALITY lot 7, checkpoint + checklist de recette | (ce commit) | typecheck+unit(85)+build+e2e verts | audit A-L consigné | VERT |
| 2026-07-13 | 07 | 7.5 exports/réinitialisation/journal §13/§21-23 : preuve UNIT qu'un export complet ne transporte AUCUN réglage de sécurité (les protections vivent dans les préférences d'appareil, jamais lues par l'export — décision §21 : restaurer ailleurs = reconfigurer, le PIN ne voyage jamais) ; réinitialisation complète (`stockage.reinitialiser` + `reinitialiserTout` : bibliothèque/vidéos/snapshots/préférences/protections — PIN à l'entrée si protégé, explication, sauvegarde proposée, confirmation renforcée, ni hash ni session résiduels, retour Bibliothèque vide) ; « PIN oublié » renvoie à la réinitialisation (honnête) ; changement de PIN ferme la session active (§11) ; journal minimal EN MÉMOIRE de session (déverrouillages, verrouillages, échecs cumulés — jamais persisté ni exporté, jamais de secret) | (ce commit) | typecheck+unit(85)+build+e2e verts | REC-007-005 AUTOMATISÉ | VERT |
| 2026-07-13 | 07 | 7.4 matrice branchée §2/§18-19 : 36 GARDES de méthode (`#autorise` — arguments capturés, reprise après déverrouillage, rien de perdu §19) + gardes UI où l'ordre compte (FAB Ajouter, retrait de technique/composition/discipline, rollback — PIN AVANT la confirmation destructive qui reste due, scénario D) ; modification : disciplines/taxonomies/types/création/capture/reprise/médias/contributions/carnet/favoris/compositions/import ; destruction/sensible : retraits, restauration, rollback, publication, sauvegarde complète, export de composition ; consultation et entraînement sans AUCUNE garde ; opérations async : permission vérifiée AVANT le début, jamais interrompues (§18 — gardes à l'entrée seulement) ; pas de nouvelle UI (panneau 7.3 réutilisé — pas de captures nouvelles) | (ce commit) | typecheck+unit(84)+build+e2e verts | REC-007-004 AUTOMATISÉ | VERT |
| 2026-07-13 | 07 | 7.3 déverrouillage au point d'action + session §7-10/§16/§20 : `autoriser(catégorie, raison, action)` — point d'entrée unique qui exécute ou ouvre le panneau PIN contextuel (raison affichée, contexte conservé, REPRISE AUTOMATIQUE après succès, Annuler = retour exact) ; session curateur en mémoire seulement (`sessionActive` pure : 5/15 min d'inactivité ou jusqu'à l'arrière-plan — verrouillage immédiat sur `visibilitychange` dans ce mode), l'activité prolonge ; temporisation progressive branchée (compteur remis à zéro au succès, erreur sobre) ; indicateur discret 🔓 + « Verrouiller » (jamais un mode Admin, masqué sous feuilles et entraînement) ; retour Android ferme le panneau SANS exécuter ; PREMIÈRE action branchée : « Modifier les informations générales » de la fiche (le reste de la matrice en 7.4) | (ce commit) | typecheck+unit(84)+build+e2e verts | REC-007-003 AUTOMATISÉ | VERT |
| 2026-07-13 | 07 | 7.2 activation/désactivation §2-3/§11-12/§14 : `Preferences.protections` (appareil, JAMAIS exporté) ; section Protections réelle — deux réglages indépendants, première activation = explication + PIN + confirmation (numeric, masquer/révéler, confirmation différente → rien d'activé + erreur claire), seconde protection SANS nouveau PIN, désactivation avec PIN (mauvais → rien ne change), plus aucune protection → secret SUPPRIMÉ (dit), préréglage « Tablette partagée » (2 protections + délai court + démarrage Bibliothèque), délai de session (5/15/arrière-plan — appliqué en 7.3), « Changer le PIN » (nouveau sel, l'ancien reste valable sur échec), « PIN oublié » honnête ; rien d'ENFORCÉ encore (politique branchée en 7.4) | (ce commit) | typecheck+unit(83)+build+e2e verts | REC-007-002 AUTOMATISÉ | VERT |
| 2026-07-13 | 07 | 7.1 cœur du PIN + politique §4-5/§10/§17 : `src/securite/pin.ts` (PBKDF2/SHA-256 Web Crypto, 310 000 itérations documentées, sel aléatoire 16 octets par création, stockage {version, sel, itérations, empreinte} SEULEMENT, vérification à temps constant, format 6-12 chiffres avec refus des évidents — répétitions et suites, y compris avec passage par 0 —, temporisation pure progressive plafonnée) + `src/securite/politique.ts` (`autorisation(catégorie, protections, session)` — consultation JAMAIS bloquée, deux protections indépendantes, une session libère les deux niveaux) ; PUR et testable, rien de branché à l'UI (7.2-7.4), aucun secret dans les tests | (ce commit) | typecheck+unit(83)+build+e2e verts | REC-007-001 AUTOMATISÉ | VERT |
| 2026-07-13 | 06 | 6.7 Réglages et sécurité §25-27 + clôture : repli DISCRET du démarrage (discipline choisie disparue → Bibliothèque + toast, jamais de blocage), état RÉEL des protections (« Aucune protection active » + annonce du lot Sécurité, AUCUN contrôle factice), thème/tonalité/démarrage conservés ; e2e scénario L complet sur le contexte restauré ; audit scénarios A-M consigné (QUALITY) ; docs §34 (workflows section 7 refondue avec Mermaid 4 intentions + tableau des 12 workflows et niveaux de démonstration, systeme section Atelier, matrice de conservation ×8 lignes Admin V2, etat) ; captures 6.7 regardées | (ce commit) | typecheck+unit(76)+build+e2e verts | REC-006-007 AUTOMATISÉ | VERT |
| 2026-07-13 | 06 | 6.6 Échanger et protéger §16-24 : quatre gestes DISTINCTS (Importer / Publier / Sauvegarder / Restaurer) ; aperçu d'import avec contenu+volume (+manifeste pour un .movpack) ; RAPPORT après import (nouvelles/réunies/vidéos/à rapprocher, « Ouvrir la discipline »/« Fermer » — plus de toast seul) ; publication orchestrée (sources au nom éditorial, formulaire nom/auteur/conditions/vidéos, prévisualisation EXACTE avec exclus, sortie nom réel+taille+résumé, `publierPack(…, meta)`) ; « Sauvegarde complète de cette installation » vs légère qui DIT ne pas être complète, sortie décrite (`dernierFichier`) ; restauration complète PROPOSÉE avant écriture (feuille contenu/date/volume, annulable — `restaurationEnAttente`) ; rollback : confirmation expliquant le remplacement + vidéos non incluses dans les snapshots (dit) ; e2e scénarios H (publication), I/J (sauvegarde, aperçu, annuler, restaurer) ; TRACÉ : partage Android (8D), version éditoriale (8B), octets vidéo des snapshots (8C) | (ce commit) | typecheck+unit(76)+build+e2e verts | REC-006-006 AUTOMATISÉ | VERT |
| 2026-07-13 | 06 | 6.5 Médias et qualité §12-15 : « Problèmes à traiter — intégrité » (vidéos manquantes, relations cassées, FICHIERS SANS RÉFÉRENCE — détectés par `taillesVideos` OPFS vs références contributions+blocs) séparés d'« À compléter — pas des erreurs » (à rattacher → workflow, sans contenu, sans niveau + note explicite) ; orphelin : prévisualisation OBLIGATOIRE avant que la suppression n'existe, confirmation avec taille, référence REVÉRIFIÉE à l'instant de la suppression, un par un jamais en masse ; médiathèque (taille, références cliquables, état — jamais de suppression d'un référencé) ; « Vérifier dans l'Atelier » ouvre la section (`ouvrirSectionAtelier`) ; synthèse enrichie des orphelins | (ce commit) | typecheck+unit(76)+build+e2e verts | REC-006-005 AUTOMATISÉ | VERT |
| 2026-07-13 | 06 | 6.4 types de relation §10 + gestion §9 + sources §11 : lignes de types (libellé, inverse ou ⇄, compteur d'usages, « importé » — jamais l'id), renommage des libellés (`majTypeRelation` — l'id slug ne bouge jamais), bascule de symétrie SI inutilisé, suppression UNIQUEMENT si inutilisé (remplace la rupture consentie — tracé dans la matrice de conservation) ; « Techniques — gestion » : recherche + filtres (À compléter / Problèmes), étiquettes d'état, ouvrir la fiche, 15 max + invite, aucune masse factice ; « Sources et auteurs » : consultation éditoriale (nom éditorial, compteurs, disciplines) + local ; TRACÉ : création de relation sans chemin UI (décision humaine), version/conditions de pack absentes du modèle (8B) ; champs d'édition étroits sur téléphone (lot 9) | (ce commit) | typecheck+unit(76)+build+e2e verts | REC-006-004 AUTOMATISÉ | VERT |
| 2026-07-13 | 06 | 6.3 Construire > Taxonomies §8 : Monter/Descendre sur familles ET niveaux (le champ `ordre` suit le tableau), suppression avec CONTRÔLE DES USAGES — valeur inutilisée : confirm simple ; valeur utilisée : arbitrage (compte + techniques cliquables, « Remplacer par « X » » reclassant les fiches / « Retirer la classification » / « Annuler »), snapshot motivé dès qu'une fiche change, toast nommant le résultat, JAMAIS de référence invalide (`usagesTaxonomie`, `reordonnerTaxonomie`, `supprimerTaxonomie(…, resolution)`) | (ce commit) | typecheck+unit(76)+build+e2e verts | REC-006-003 AUTOMATISÉ | VERT |
| 2026-07-13 | 06 | 6.2 Construire > Disciplines §5-7 : carte enrichie (techniques · familles · niveaux · SOURCES + « N à vérifier » cliquable → Médias et qualité), réordonnancement ↑↓ (ordre persisté, suivi par la racine), « Ouvrir dans la Bibliothèque », suppression SÉCURISÉE d'une discipline non vide (« Préparer la suppression… » → contenu réel présenté — techniques, contributions, vidéos, compositions nommées, sort des notes personnelles — puis Annuler / Exporter tout d'abord / Supprimer avec confirmation renforcée + snapshot motivé ; notes personnelles → « à rattacher », sourcé part avec ses identités) ; risque `idDePack(nom)` au renommage TRACÉ pour le lot 8B | (ce commit) | typecheck+unit(76)+build+e2e verts | REC-006-002 AUTOMATISÉ | VERT |
| 2026-07-13 | 06 | 6.1 racine en quatre intentions §2-4/§29 : Construire · Médias et qualité · Échanger et protéger · Réglages et sécurité (exactement, accordéon natif une-seule-ouverte), intention ouverte CONSERVÉE pendant la session (état module + `?open` piloté — survit à la bascule d'onglet), synthèse actionnable en tête (captures à rattacher → rattachement direct, vidéos introuvables / relations à réparer → section Médias et qualité ; corpus sain → « Aucun problème détecté » compact ; installation vide → rien), création de discipline déplacée DANS Construire (racine stricte), helper e2e `ouvrirVolet` idempotent (l'état conservé aurait fait basculer les clics aveugles) | (ce commit) | typecheck+unit(76)+build+e2e verts | REC-006-001 AUTOMATISÉ | VERT |
| 2026-07-13 | 05 | 5.7 corrective (recette Android) : notifications transitoires — remplacement, péremption ~3,4 s, garde d'expiration au rendu (minuteurs gelés WebView), effacement à TOUT changement d'écran (`#aller`/`#allerRacine`/`retour`/retour Android), jamais rendues sur l'écran entraînement (les confirmations posées PAR une navigation programmée survivent : les flux naviguent puis affichent) ; éditeur réduit à DEUX constructions (capture-repère retirée sur décision humaine — blocs repère existants lisibles, capture lot 4 intacte) ; aucun libellé interne de type de bloc visible (« ÉTAPE » masqué, type conservé en données) ; « Supprimer la composition » (action danger distincte, confirmation et toast NOMMANT la composition) ; matrice QUALITY lot 5 complétée (écart de 5.6 corrigé) ; 4 captures regardées | (ce commit) | typecheck+unit(76)+build+e2e verts | REC-005-006 AUTOMATISÉ, NR-005-001/002 ACTIFS | VERT |
| 2026-07-13 | 05 | 5.6 clôture : scénario F du lot en unit (anciens types transition/consigne/durée intacts à l'import/réimport, textes lisibles), audit scénarios A-K (couverts web ; K hors ligne par construction — OPFS, zéro réseau requis ; tactile/tablette : recette), performance §24 (vignettes lazy, un bloc à la fois en entraînement, déplacements O(1)), docs §28 (workflows section 6 refondue avec niveaux de démonstration, systeme — dont correction de la ligne périmée « personnel seulement », matrice de conservation ×5, etat), captures 18-23 regardées (D-026) | (ce commit) | verifier complet vert (76 unit + e2e) | matrice lot 5 à jour | VERT |
| 2026-07-13 | 05 | 5.5 liste §18-19 (blocs/brouillon, date, miniature, ▶ direct, recherche+tri A→Z), duplication §18 (nouvelles références, origine de pack non suivie), technique indisponible §17 (libellé de secours, retrait nommant les compositions, Remplacer répare), export §20 avec rapport préalable honnête (identités seules, sans contributions, carnet jamais inclus), §22 renforcé en e2e (ordre/textes restaurés, entraînement fonctionnel après restauration) | c6b7857 | typecheck+unit(75)+build+e2e verts | REC-005-005 AUTOMATISÉ | VERT |
| 2026-07-13 | 05 | 5.4 mode entraînement §14-15 : écran `entrainement` (index DANS l'écran → la pile restaure le même bloc au retour d'une fiche), bloc courant en grand (vignette/nom/appellation/Voir la fiche ; texte sans métadonnée), « Ensuite : … », progression N/M, Précédent/Quitter/Suivant (bornes désactivées), barre basse masquée, ni chrono ni lecture auto ni maintien d'écran | 39b725d | typecheck+unit(75)+build+e2e verts | REC-005-004 AUTOMATISÉ | VERT |
| 2026-07-13 | 05 | 5.3 éditeur de composition §8-13 : deux gestes d'ajout (technique / texte — nouveau texte = type `etape` le plus générique, anciens types lisibles et intacts), description facultative, sélecteur avec favoris ★ et discipline des résultats, libellé de secours posé à l'ajout et au remplacement, menu contextuel de bloc technique (Voir la fiche / Remplacer / Ajouter du texte après — insertion ciblée / Retirer), bloc texte éditable en place, « Fermer » (plus de « Terminer ») | 388b439 | typecheck+unit(75)+build+e2e verts | REC-005-003 AUTOMATISÉ | VERT |
| 2026-07-13 | 05 | 5.2 racine Pratique compacte §2-3 : À reprendre en aperçu de 3 + « Voir tout (N) » (session), Favoris en aperçu de 4 + « Voir tout », état vide Compositions selon §2, indicateur 🎞 sur les cartes texte+média ; « discipline présélectionnée » non représentable — tracée hors périmètre | 76d1f6a | typecheck+unit(75)+build+e2e verts | REC-005-002 AUTOMATISÉ | VERT |
| 2026-07-13 | 05 | 5.1 favoris §4-6 : schéma v3 (`favoris: string[]`, migration 2→3 testée, validation ULID), étoile ☆/★ dans la barre de fiche (immédiat, réversible, sans confirmation, aria-pressed), liste compacte dans Pratique (vignette·nom·appellation·discipline, toucher → fiche, retrait secondaire), orphelins ignorés à l'affichage + nettoyés par `supprimerTechnique`, JAMAIS publiés (pack discipline + export composition : testés), inclus dans la sauvegarde intégrale (e2e restauration), états vides compacts §2 | 90788d1 | typecheck+unit(75)+build+e2e verts | REC-005-001 AUTOMATISÉ | VERT |
| 2026-07-13 | 04 | 4.6 clôture : scénarios C/D complétés en e2e (vidéo réelle rattachée immédiatement ; « Uppercut » créée DEPUIS une capture, vidéo sur la fiche, visible en grille), permissions §15 documentées (refus = geste sans résultat + alternatives, refus permanent non détectable depuis `input file` — recette), docs §25 (workflows refondus avec niveaux de démonstration, systeme, matrice de conservation ×5, matrice QUALITY lot 4, etat), 4 captures regardées (aperçu vidéo, « sais-tu où le ranger ? », À reprendre, contribution) | (ce commit) | verifier complet vert (74 unit + e2e) | matrice lot 4 à jour | VERT |

## Risques et anomalies ouverts

| ID | Sévérité | Description | Impact | Prochaine action |
|---|---|---|---|---|

## Hors périmètre observé

| Idée ou problème | Lot potentiel | Pourquoi non traité |
|---|---|---|
| Capture sans discipline sur installation totalement vide (plus de point d'entrée) | Lot 4 §2 (« Filmer ou garder quelque chose » à la racine) | Le lot 1 interdit le bouton global ; réintroduction prescrite au lot 4 |
| Préférence `repriseMasquees` + méthode `masquerReprise` sans UI (le « ✓ fini » vivait sur l'Accueil) | Lot 5 (À reprendre) | Donnée conservée ; « À reprendre » ne liste que l'inachevé (lot 1 §5) |
| Recherche globale absente quand la bibliothèque est vide | Lot 2 §4 | Rien à chercher ; le lot 2 précisera la racine |
| Barre basse pendant un futur mode entraînement | Lot 5 §14 | Le mode n'existe pas encore |
| Filtres d'explorateur globaux (non mémorisés PAR discipline) | Lot 2 §13 | Conservés au retour et à la bascule d'onglet (lot 1) ; par-discipline au lot 2 |
| « Discipline présélectionnée éventuelle » d'une capture à reprendre (lot 5 §3) : la contribution n'a pas de champ discipline | Lot 8 (formats) ou décision dédiée | §25 du lot 5 limite les changements de modèle au strict indispensable ; la carte affiche déjà texte/média/date/auteur/état — champ non ajouté, tracé |
| Pas de marqueur explicite « adaptation locale » dans le modèle (D-062 : reconnue par `personnel` + attribution, sans `origine`) | Lot 6 (exclusion de publication D-063) | §21 interdit de modifier le modèle contribution dans ce lot ; faiblesse documentée, pas corrigée silencieusement |
| Redondance visuelle : quand un AUTRE média est affiché en tête, le média principal réapparaît comme bouton dans sa voix (jamais de double lecture — mais deux mentions du même contenu) | Lot 9 (consolidation visuelle) | Boucle 3.7 point 4 : la double lecture est garantie impossible (média affiché filtré de sa voix + un seul lecteur actif) ; la réduction de redondance demanderait une refonte de la présentation des voix — hors périmètre 3.7 |
| Créer une RELATION entre techniques depuis l'interface : aucun chemin utilisateur n'existe (les relations viennent des packs ; le modèle et l'affichage sont complets) — « désactiver un type pour de nouvelles relations » (lot 6 §10) est donc sans objet aujourd'hui | Décision humaine (fiche ? Atelier ?) — hors roadmap actuelle | Lot 3 (fiche) ne l'a pas prescrite ; lot 6 §31 interdit de modifier la fiche ; capacité jamais construite en V3, pas une régression |
| Version et conditions d'un pack importé : non conservées par le modèle (`Origine` = pack + element seulement) — la vue Sources ne peut pas les consulter, ni corriger un nom d'affichage local ; la version ÉDITORIALE d'un pack publié n'est pas portée par le manifeste | Lot 8B (manifeste `.movpack`) | Lot 6 §11/§19 : ne pas créer de registre complexe ici ; consultation limitée à l'existant, limite dite dans la prévisualisation |
| Partage système Android d'un fichier produit (pack, sauvegarde) : non implémenté — le fichier va aux Téléchargements de l'appareil et la sortie le DIT (Web Share API avec fichiers non fiable en WebView) | Lot 8D (Android et plateformes) | Lot 6 §20 : « utiliser le mécanisme existant réellement fonctionnel… le documenter au lieu d'afficher un faux succès » |
| Snapshots locaux : données seules, JAMAIS les octets vidéo (dit dans la confirmation de rollback et sous la liste) ; taille des snapshots non affichée | Lot 8C (transactions, sauvegarde) | Lot 6 §24 : « l'indiquer explicitement ; ne pas promettre une restauration complète ; tracer le refactor » |
| ~~Renommer une discipline … l'identité d'un pack publié est calculée du nom~~ | ~~Lot 8B~~ | **RÉSOLU en 8B.1id (6ea24cd→ce commit)** : l'identité technique du pack se dérive désormais de l'ULID STABLE de la discipline/composition (`idPackStable`), invariante au renommage ; `idDePack(nom)` ne sert plus qu'au nom de fichier. Aucun changement de modèle |
| Champ « Ajouter du texte » de l'éditeur : sur les captures WEB D-026 de 5.7 il gardait son contenu affiché après l'ajout (dirty-check Lit sur `.value` — le bloc est bien créé et l'état vidé, un second « Ajouter » n'ajoute rien) ; la recette Android 5.7 l'a vu correctement VIDÉ (« champ visuellement vidé après insertion ✓ ») | Lot 9 (consolidation) | Divergence web/appareil à revérifier au lot 9 ; hors des 4 points prescrits — non corrigé silencieusement |

| Publication d'un pack : une technique incluse peut porter une relation vers une identité HORS périmètre — copiée telle quelle (cible absente TOLÉRÉE par le modèle D-020, jamais bloquante), mais NI ajoutée, NI signalée comme dépendance, NI exclue avec avertissement (§24) | Boucle dédiée ou lot 9 | Refinement de qualité éditoriale, pas de sûreté des données ; le modèle tolère déjà les cibles absentes ; à signaler proprement plus tard (réserve P2 du verdict 8B) |

## Outillage et frictions

| Friction | Fréquence / risque | Solution | Commande | Statut |
|---|---|---|---|---|
| Bruit console du Chromium CI : « Permissions policy violation: compute-pressure » collecté par la surveillance e2e (1 seul run rouge : ci 29239251831 sur 7b326a9 — vert local et sur tous les autres runs ; l'app n'utilise pas cette API) | rare (version de Chromium du runner) | Message PRÉCIS filtré dans `surveiller()` de parcours.mjs, comme le filtre existant des vignettes YouTube — cause identifiée et documentée, jamais un « relancer jusqu'au vert » (MASTER §8) | — | CORRIGÉ (commit d'ouverture du lot 07) |
| Test e2e 8C.6 INSTABLE (1 run ci rouge 29272038159 sur 29d0b2f ; vert local + sur c6fac0f, MÊME code) — cause EXACTE (`parcours.mjs:2225`) : après `validerDemandePin`, l'action différée est fire-and-forget (non attendable) ; le test attendait `blocs.length===1` (poussé AVANT la fin du persist) puis lisait `capture` aussitôt, alors que `capture=null` n'est posé qu'APRÈS le persist → course. Produit CORRECT, test lisant trop tôt | rare (timing du runner) | Attendre le VRAI signal de succès `capture===null` (posé en dernier) puis lire blocs/média ; vérifié 3× en local, stable (MASTER §8, jamais de relance aveugle) | — | CORRIGÉ (boucle 8C.6b) |
| Garde CI D-014 : un push touchant `src/donnees/tools/tests` SANS `docs/etat.md` échoue (2 runs rouges sur les pushes intermédiaires du lot 2 — process, pas produit : tout l'aval était sauté) | à chaque push intermédiaire | Règle de travail : pousser par checkpoint (etat.md inclus), ou toucher etat.md dans tout push produit | — | **RÉ-ENFREINTE AU LOT 4** (5 runs ci rouges 4.1→4.5, étape « etat.md à jour » seule en échec, vérifié sur les jobs). Règle DURCIE : toucher `docs/etat.md` dans CHAQUE commit de boucle contenant du produit, pas seulement au checkpoint |

## Checkpoints de lots

| Lot | Statut | Commit | Vérification complète | Artefacts | Réserves |
|---|---|---|---|---|---|
| **10 — Recette finale, stabilisation, clôture** | **DÉCISION : GO AVEC RÉSERVES** (candidate `3.0.0-rc.1`) | 10A `fc7039d` → 10B `5e19ec8` → 10C (ce commit) | 10A audit (0 P0/P1) ; 10B correction A1 (D-066, 7 tests + e2e) ; 10C build PROPRE `npm run verifier` vert (132 unit + e2e), artefacts + checksums, 10 scénarios critiques couverts (e2e + recettes Android lots 1-9) | build web ; packs démo (checksums consignés) ; inspecteur ; rapport `docs/archives/rapport-recette-v3.md` ; **CI verts : 10A `29281799362`, 10B `29283367124` + APK `29283367172`, 10C `29283658459`** | GO AVEC RÉSERVES : P2/P3 A2-A6 (backlog post-V3) + plateformes déclarées (partage natif différé, PWA/Windows/Electron absents) ; AUCUNE réserve sur perte de données, sécurité PIN ou restauration annoncée |
| **09 — Identité graphique et consolidation UX** | **ACCEPTABLE** — recette Android réelle **VALIDÉE par l'humain (2026-07-13, 12 points ci-dessous)**. Preuve : commit `8d26c299`, **CI 29279256402 verte + APK 29279256488 vert** ; différences ultérieures (consignes filet/libellé + docs) = visuel mineur + docs | 65acacb → 8d26c299 + consignes (boucles 9.1→9.8) | `npm run verifier` vert (130 unit + e2e — AUCUN sélecteur cassé) ; direction 9.1 validée humain ; captures jour/nuit tel+tab ; **aucune logique métier changée, aucune capacité retirée** (§1/§39) | captures final-jour/final-nuit ; guide visuel systeme.md §5quinquies ; APK 29279256488 | RÉSERVES visuelles tracées, non bloquantes : (V1) famille d'icônes SVG unique (§9) — emojis résiduels menus/capture ; (V2) vue tablette côte à côte (§31) non implémentée ; (V3) marque typographique, pas de nouveau logo (§33). DÉCISIONS de clôture consignées : filet bleu de la carte discipline CONSERVÉ (sémantique « discipline », contrainte 2) ; « filtres ceinture » → « filtres de niveau » (D-013, générique) |
| **08 — LOT COMPLET (formats, médias, stockage, plateformes)** | **ACCEPTABLE** — recette Android consolidée 8A→8D **VALIDÉE par l'humain (2026-07-13, 21 points ci-dessous)** ; réserves R1-R6 acceptées (annoncées honnêtement, aucune sur les données). Preuve : commit final `80efd65` (code final `29d0b2f`), **CI 29272785511 verte, APK 29272039028 vert** — les différences ultérieures ne portent QUE sur tests et documentation | c38a3fb → 5e535eb (sous-lots 8A→8D, ~20 boucles) | `npm run verifier` vert (130 unit + e2e couvrant scénarios A,B,C,D,E,G,H,I,M ; F/K/L = recette appareil) ; `epreuve:export` (mémoire bornée) ; inspecteur `.movpack` ; **tous les runs CI+APK verts** (dont clôtures 8C 29270358903/29270358932, 8D 29271135906/29271135920 ; **CI finale 5e535eb 29272785511 verte** ; APK du code final 29d0b2f 29272039028 vert) ; audit contradictoire passé (F1/F2 corrigés en 8C.6 ; test instable 8C.6b corrigé, vérifié 3× + CI verte) | APK de recette : run 29271135920 ; packs-demo réels ; inspecteur + diagnostic exportables | **RÉSERVES** : (R1, à lever par recette) borne mémoire gros fichiers + interruption réelle sur Android ; (R2, documentée) partage-sheet natif DIFFÉRÉ (téléchargement WebView livré et dit ; raison : vérif appareil + mémoire bornée) ; (R3, P2 depuis 8B) relations hors périmètre non signalées à la publication (tolérées, sans risque données) ; (R4, mineur) `majContribution` mutation en place ; (R5, documentée) PWA différée, Windows/Electron absents (déclarés) ; (R6) §27/scénario J V2 : migration OUTILLÉE (tools/convertir-movpack-v2 ; packs-demo dérivés de V2) mais pas de parcours d'import V2 in-app de premier rang — tracé |
| 08 — sous-lot 8D (Android et matrice des plateformes) | **CLOS TECHNIQUEMENT — AUTOMATISÉ/DOCUMENTÉ** ; recette Android consolidée 8A→8D à la clôture du lot 8 | a897e48 → ce5d00d (boucles 8D.1→8D.3) | `npm run verifier` vert (130 unit + e2e) ; diagnostic exportable (unit + e2e) ; inspecteur `.movpack` exécuté ; stratégie Android B prouvée par la CI apk (à chaque push) ; **CI de clôture 8D 29271135906 (ce5d00d) vert + APK 29271135920 vert** | APK de recette 8D : run 29271135920 (ce5d00d) vert | VERDICT : **ACCEPTABLE AVEC RÉSERVES** — (réserve, non-donnée) share-sheet natif Android DIFFÉRÉ (partage livré = téléchargement WebView accessible et dit ; raison : vérif appareil + mémoire bornée 8B) ; PWA différée ; Windows/Electron absents (déclarés, analyse de perte V2 faite) ; versionCode/Name debug = défauts Capacitor (release documentée non activée faute de secrets) |
| 08 — sous-lot 8C (transactions, sauvegarde et restauration) | **CLOS TECHNIQUEMENT — AUTOMATISÉ** ; recette Android consolidée 8A→8D à la clôture du lot 8 | b4a884f → a897e48 (boucles 8C.1→8C.5) | `npm run verifier` vert (127 unit + e2e) ; e2e enrichi : bascule d'état protégée + reprise commit interrompu ; échec de persistance injecté sur chaque parcours média (aucun orphelin) ; double-appui → 1 contribution ; sauvegarde PARTIELLE si vidéo absente ; snapshot + rétention → rollback vidéo comprise ; staging nettoyé au démarrage ; **CI de clôture 8C 29270358903 (a897e48) vert + APK 29270358932 vert** | APK de recette 8C : run 29270358932 (a897e48) vert | VERDICT : **ACCEPTABLE** — atomicité non parfaite REVENDIQUÉE honnêtement (OPFS sans rename transactionnel) ; interruption réelle pendant écriture à confirmer sur Android (recette) ; **audit contradictoire passé (8C.6) : F1 (orphelin repère sur PIN différé) et F2 (rollback amende par index) CORRIGÉS et testés** ; `majContribution` garde une mutation en place (mineur, tracé, sans média — non repris pour ne pas élargir le périmètre) |
| 08 — sous-lot 8B (.movpack, manifeste et intégrité) | **CLOS — checkpoint validé par l'humain (2026-07-13)** ; recette Android consolidée 8A→8D à la clôture du lot 8 | 86f8d27 → b4a884f (boucles 8B.1→8B.5) | `npm run verifier` vert (118 unit + e2e) ; `npm run epreuve:export` vert (202 médias vérifiés ; 700 Mo → RSS +1 Mo, pic blocs=1) ; **TOUS les runs 8B verts (CI+APK)** — 8B.1 29262970313/29262970303, 8B.1id 29263329620/29263329579, 8B.2 29264357059/29264357119, 8B.3 **29266084927/29266084799**, 8B.4 **29266434066/29266434125**, 8B.5 **29266719229/29266719256** | APK de recette 8B : run 29266719256 (b4a884f) vert | VERDICT : **ACCEPTABLE AVEC RÉSERVES** — (P2) §24 relations hors périmètre non signalées à la publication (tolérées, sans risque données) ; (à lever) mémoire bornée à confirmer PHYSIQUEMENT sur Android par recette consolidée |
| 08 — sous-lot 8A (registre et cycle de vie des médias) | **CLOS TECHNIQUEMENT — AUTOMATISÉ** ; recette humaine Android demandée (le lot 08 entier ne sera ACCEPTABLE qu'après ses 4 sous-lots + recettes) | 91a1073 → 97657a4 (boucles 8A.1→8A.5) | `npm run verifier` vert (103 unit + e2e scénarios A/B du lot + quota simulé) ; TOUS les runs du sous-lot verts — CI de clôture 8A.5 **29260691359 (97657a4) vert**, CI d'ouverture 8B 29261009263 (86f8d27) vert | APK de recette 8A : **run 29260691404 (97657a4) vert** ; aucune capture D-026 : aucune UI nouvelle | dédup inopérante sur les médias d'AVANT 8A.2 (sans empreinte — assumé, jamais de fausse dédup) ; partage Android natif → 8D |
| 07-securite | **ACCEPTABLE** (recette Android 2026-07-13 : 20 points validés) | c38a3fb (boucles 7.1→7.6) | `npm run verifier` vert (85 unit + e2e) ; CI de clôture 29249956402 (c38a3fb) vert ; runs du lot 13/13 verts | APK de recette : run 29249627530 (5fb43f8 — dernier commit produit ; la clôture ne touche que docs/tests) ; captures 7.2/7.3/7.5 regardées (D-026) | aucune — ne rouvrir les lots 1-7 que sur régression directement causée par le lot 8 |
| 06-atelier | **ACCEPTABLE** (recette Android 2026-07-13 : 16 points validés sur l'APK du run 29242569780) | 23e69c6 (boucles 6.1→6.7) | `npm run verifier` vert (76 unit + e2e enrichi : scénarios A-D, F-J, L du lot) ; CI de clôture 29242569648 vert ; runs du lot 13/14 verts — l'unique rouge (ci 29239251831, boucle 6.2) diagnostiqué : bruit du Chromium CI (« compute-pressure », API jamais utilisée par l'app), filtré dans la surveillance e2e comme les vignettes YouTube (voir Frictions) | APK de recette : run 29242569780 (23e69c6) ; captures 6.1→6.7 regardées (D-026) | aucune — ne rouvrir les lots 1-6 que sur régression directement causée par le lot 7 |
| 01-navigation | **ACCEPTABLE** (recette humaine 2026-07-12) | 54563d8 (+ docs 8dc8b5d) | `npm run verifier` vert ; CI 29208155024/29208164718 verts | APK debug : run apk 29208155025 (vert) ; captures 3 racines + sombre regardées | aucune — les 6 vérifications Android manuelles confirmées par l'humain |
| 02-bibliotheque | **ACCEPTABLE** (recette humaine Android 2026-07-12 : 14 points validés) | cd329a1 (+ a59b855) | CI complet vert (run 29209474931) | APK de recette : run 29209404845 (vert) ; captures lot 2 regardées | aucune |
| 03-fiche-technique | **ACCEPTABLE** (recette Android finale 2026-07-13 : 8 points validés sur l'APK du run 29217733902) | 2573724 (boucles 3.1→3.7 ; checkpoint dfcbc08) | `npm run verifier` vert (73 unit + e2e) ; CI 29217733868 vert ; APK 29217733902 vert | APK de recette : run 29217733902 ; 9 captures regardées (D-026) | aucune — ne rouvrir les lots 1-3 que sur régression directement causée par le lot 4 |
| 05-pratique-compositions | **ACCEPTABLE** (recette Android 15 points 2026-07-13 + recette finale 5.7 : 10 points validés sur l'APK du run 29236712324) | 3d6b008 (boucles 5.1→5.7 ; clôture c98f2ff) | `npm run verifier` vert (76 unit + e2e) ; TOUS les runs du lot verts (D-014 durcie : 7/7) — CI de 5.7 : 29236712342 (3d6b008) | APK de recette 5.7 : run 29236712324 (3d6b008) ; APK de la recette 15 points : run 29228928398 (c6b7857) ; captures 18-23 + 4 captures 5.7 regardées (D-026) | aucune — ne rouvrir les lots 1-5 que sur régression directement causée par le lot 6 |

### Recette Android du lot 07 (Yahya, 2026-07-13) — VALIDÉE

Sur l'APK du run 29249627530 (5fb43f8), confirmé par l'humain :

- appareil personnel entièrement utilisable sans PIN par défaut ✓
- consultation toujours libre ✓
- création du PIN uniquement lors de la première activation ✓
- protections des modifications et des suppressions indépendantes ✓
- clavier numérique, confirmation et refus des PIN invalides ✓
- déverrouillage demandé au point précis de l'action ✓
- reprise automatique de l'action après validation ✓
- annulation et Retour Android sans mutation ✓
- PIN demandé avant la confirmation destructive ✓
- session 5/15 minutes et verrouillage manuel fonctionnels ✓
- expiration réelle après délai, arrière-plan et fermeture forcée ✓
- aucune apparition furtive d'une action déverrouillée ✓
- temporisation progressive des mauvais PIN ✓
- changement de PIN : ancien refusé, nouveau accepté ✓
- désactivation indépendante et suppression du secret quand tout est libre ✓
- préréglage Tablette partagée : consultation libre, actions protégées ✓
- sauvegardes et exports sans PIN ni réglage de protection ✓
- boutons de réinitialisation accessibles au-dessus de la barre basse ✓
- sauvegarde préalable, annulation et confirmation renforcée ✓
- réinitialisation supprimant données, médias, snapshots, réglages, PIN
  et session ✓

→ **Lot 07 : ACCEPTABLE.** Consignes : ne rouvrir les lots 1-7 que sur
régression directement causée par le lot 8 ; exécuter les sous-lots
8A→8D SÉPARÉMENT, aucun n'anticipe le suivant.

### Recette Android consolidée du lot 08 (Yahya, 2026-07-13) — VALIDÉE

21 points confirmés sur l'APK de recette (run 29272039028, code 29d0b2f) :

- mise à jour sans perte des données existantes ✓
- anciens médias toujours lisibles ✓
- déduplication par taille et SHA-256, y compris après renommage ✓
- références partagées sûres et orphelins explicitement diagnostiqués ✓
- capture avec PIN différé sans fichier orphelin ni référence fantôme ✓ (F1)
- doubles appuis et opérations concurrentes maîtrisés ✓
- gros export réussi sur Android sans crash mémoire ✓ (lève R1 export)
- arrière-plan et fermeture forcée sans .movpack partiel présenté ✓ (lève R1 interruption)
- nettoyage des fichiers temporaires et nouvel export possible ✓
- inventaire, chemins, tailles et empreintes du .movpack cohérents ✓
- archive altérée refusée avant toute mutation ✓
- rétrocompatibilité v3 et JSON historique fonctionnelle ✓
- sauvegarde restaurée sur installation vierge avec données et vidéos ✓
- état restauré réexportable ✓
- identité de pack stable après renommage et republication ✓
- manque d'espace refusé avant mutation ✓
- rollback restaurant le bon objet indépendamment de son index ✓ (F2)
- PIN, hash de sécurité et session absents des sauvegardes ✓ (D-065)
- fonctionnement Android hors ligne, Retour, clavier, rotation et reprise corrects ✓
- diagnostic exporté sans secret ✓
- limites de partage et de plateformes annoncées honnêtement ✓ (R2/R5 acceptées)

→ **Lot 08 : ACCEPTABLE.** R1 (mémoire/interruption) levée par la recette ;
R2 (partage-sheet natif différé), R3 (relations hors périmètre à la
publication, P2), R4 (`majContribution` mutation en place, mineur), R5 (PWA
différée, Windows/Electron absents), R6 (V2 outillée sans import in-app)
acceptées comme réserves annoncées, aucune sur les données. Consignes : ne
rouvrir le lot 8 qu'en cas de régression directement provoquée par le lot 9.

### Recette Android réelle du lot 09 (Yahya, 2026-07-13) — VALIDÉE

12 points confirmés sur l'APK du lot 9 (commit 8d26c299) :

- cohérence visuelle Bibliothèque / Pratique / Atelier ✓
- coque sombre et contenu correctement hiérarchisés ✓
- téléphone petit, portrait et paysage sans contenu inaccessible ✓
- clavier et Retour Android corrects ✓
- zones sûres et barre basse sans recouvrement ✓
- tablette lisible à l'échelle native ✓
- fiches longues, Atelier et modales entièrement accessibles ✓
- modes jour et nuit cohérents ✓
- six tonalités lisibles ✓
- états danger, succès, information et contenu facultatif non ambigus ✓
- aucune régression fonctionnelle ou de performance ✓
- aucun flash ou écran non stylé ✓

→ **Lot 09 : ACCEPTABLE.** Consignes de clôture intégrées : (1) le **filet
bleu de la carte discipline est CONSERVÉ** — sémantique « discipline »
documentée (contrainte 2), seul le bleu décoratif (initiales de repli, filets
de bloc) ayant été neutralisé ; (2) « **filtres ceinture** » → « **filtres de
niveau** » (vocabulaire générique, D-013). Réserves visuelles V1-V3 (icônes
SVG §9, tablette côte à côte §31, logo §33) tracées, non bloquantes. Ne
rouvrir le lot 9 qu'en cas de régression directement provoquée par le lot 10.

### Recette humaine du lot 07 — checklist initiale (2026-07-13, historique)

Points Android à vérifier (lot 07 §28, sur l'APK du push de clôture) :

1. Appareil personnel : parcourir, créer, modifier, supprimer — ne JAMAIS
   rencontrer de PIN tant qu'aucune protection n'est activée.
2. Activation : le clavier NUMÉRIQUE s'ouvre pour le PIN ; masquer/révéler
   fonctionne ; une confirmation différente n'active rien.
3. Action protégée : le panneau dit pourquoi ; le bon PIN reprend
   l'action ; Retour Android ferme le panneau sans exécuter.
4. Session : après ~5 minutes d'inactivité, le PIN revient ; « Verrouiller
   maintenant » fonctionne ; l'indicateur 🔓 est discret.
5. Arrière-plan (mode « jusqu'à l'arrière-plan ») : quitter l'app
   verrouille — au retour, AUCUNE vue déverrouillée n'apparaît
   furtivement.
6. Fermeture forcée de l'app : au relancement, la session est verrouillée.
7. Changement d'orientation pendant le panneau PIN : rien ne se perd.
8. Tablette partagée : consultation, lecture vidéo, compositions et mode
   entraînement LIBRES ; ajouter/modifier/supprimer → PIN.
9. Mauvais PIN répétés : erreur sobre, temporisation à partir de la 5e,
   jamais de blocage définitif.
10. Réinitialisation complète : PIN → explication → confirmation →
    Bibliothèque vide, plus aucun PIN demandé ensuite.

### Recette Android du lot 06 (Yahya, 2026-07-13) — VALIDÉE

Sur l'APK du run 29242569780 (commit `23e69c6`), confirmé par l'humain :

- quatre intentions de l'Atelier et accordéon unique ✓
- synthèse actionnable et mise à jour après résolution ✓
- gestion des disciplines, compteurs et navigation Bibliothèque ✓
- suppression sécurisée d'une discipline avec export proposé,
  confirmation et snapshot ✓
- taxonomies créées, réordonnées et supprimées avec arbitrage des usages ✓
- aucune référence invalide après remplacement ou retrait de
  classification ✓
- types de relation cohérents et suppression protégée ✓
- fichiers orphelins inspectés et supprimés individuellement ✓
- média référencé impossible à supprimer ✓
- import Android avec aperçu, annulation sans mutation et rapport final ✓
- fichier invalide refusé sans mutation ✓
- publication conforme à son aperçu et exclusions respectées ✓
- sauvegarde complète restaurée sur une installation vierge ✓
- vidéos, Favoris, compositions, captures et contributions réellement
  restaurés ✓
- rollback fonctionnel avec limite sur les octets vidéo explicitement
  annoncée ✓
- clavier, Retour Android, défilement téléphone et affichage tablette
  corrects ✓

→ **Lot 06 : ACCEPTABLE.** Consignes : ne rouvrir les lots 1-6 que sur
régression directement causée par le lot 7 ; ne pas anticiper le
durcissement des formats et médias (lot 8) ni la consolidation graphique
(lot 9).

### Recette humaine du lot 06 — checklist initiale (2026-07-13, historique)

Points Android à vérifier (lot 06 §33, sur l'APK du push de clôture) :

1. Accordéons au doigt : quatre intentions, une seule ouverte, l'intention
   ouverte retrouvée après bascule d'onglet ; jamais de mur de texte.
2. Synthèse actionnable : une capture à rattacher → élément cliquable
   ouvrant le rattachement ; corpus sain → « Aucun problème détecté ».
3. Disciplines : renommer, réordonner, « Ouvrir dans la Bibliothèque » ;
   suppression sécurisée d'une discipline non vide (récap → export
   proposé → confirmation renforcée → notes revenues « à rattacher »).
4. Taxonomies : ordonner au doigt, supprimer une valeur utilisée →
   arbitrage (remplacer / retirer la classification / annuler).
5. Sélection de fichier : import d'un .movpack — aperçu (contenu, volume)
   puis rapport avec « Ouvrir la discipline ».
6. Publication : formulaire (nom, auteur), prévisualisation exacte,
   génération — le fichier arrive dans Téléchargements et la sortie
   affiche nom/taille/résumé.
7. Sauvegarde complète PUIS restauration sur une installation vierge
   (désinstall/réinstall ou second appareil) : aperçu avant, données
   vérifiées après (favoris, compositions, vidéos).
8. Rollback : restaurer un snapshot motivé — la confirmation explique le
   remplacement et l'absence des vidéos ; l'état revient.
9. Clavier et retour Android dans l'Atelier (champs de taxonomies,
   formulaires) : premier retour ferme le clavier, puis les feuilles.
10. Tablette : les quatre intentions restent lisibles et utilisables.

### Recette Android FINALE de la boucle 5.7 (Yahya, 2026-07-13) — VALIDÉE

Sur l'APK du commit `3d6b008` (run apk 29236712324), confirmé par l'humain :

- toast automatiquement disparu après sa durée ✓
- toast supprimé lors d'un changement d'écran ✓
- aucun toast hérité dans le mode entraînement ✓
- seulement « Ajouter une technique » et « Ajouter du texte » dans l'éditeur ✓
- anciens blocs repère toujours lisibles ✓
- aucun type interne de bloc visible ✓
- « Supprimer la composition » explicite, confirmée, précédée d'un snapshot ✓
- aucun libellé ambigu « Retirer » pour la composition entière ✓
- champ « Ajouter du texte » visuellement vidé après insertion ✓
- aucun doublon après un second appui ✓

→ **Lot 05 : ACCEPTABLE.** Consigne : ne rouvrir les lots précédents qu'en
cas de régression directement causée par le lot 6.

### Recette Android du lot 05 (Yahya, 2026-07-13) — POSITIVE (historique : 4 points corrigés en 5.7)

Résultats confirmés par l'humain sur Android réel (APK du run 29228928398) :

- favoris immédiats, réversibles, persistants et sans doublons ✓
- listes compactes et « Voir tout » fonctionnels dans Pratique ✓
- composition créée et éditée avec uniquement Technique et Texte ✓
- insertion, modification, remplacement et retrait des blocs corrects ✓
- réordonnancement tactile conservé après fermeture et relance ✓
- alternative de réordonnancement accessible ✓
- mode entraînement fonctionnel sur téléphone, paysage et tablette ✓
- retour depuis une fiche vers le même bloc ✓
- duplication sans modification de l'originale ni copie des techniques ✓
- technique retirée représentée honnêtement puis réparée par Remplacer ✓
- export précédé d'un rapport conforme à son contenu réel ✓
- réimport conservant titre, description, ordre et textes ✓
- aucun favori, carnet ou contenu non annoncé inclus dans l'export ✓
- sauvegarde intégrale et restauration des Favoris, captures et compositions ✓
- fonctionnement local validé en mode avion ✓

**Quatre points à corriger avant ACCEPTABLE** → boucle corrective **5.7 —
Simplification finale de l'éditeur et notifications transitoires**
(périmètre strict, voir le découpage du lot 05) :

1. durée de vie des notifications temporaires (le toast « Pack Judo
   installé — 111 nouvelles » persistait des dizaines de secondes,
   survivait au changement d'écran, apparaissait dans le mode
   entraînement) ;
2. retirer « Filmer ou noter un repère » de l'éditeur de composition
   (exactement deux constructions : technique / texte) ;
3. ne plus afficher le libellé interne « ÉTAPE » sur les blocs de texte ;
4. remplacer « Retirer » par « Supprimer la composition » (confirmation
   nommée, traitement dangereux distinct).

Interdits : Favoris, modèle des compositions, anciens types de blocs,
fonctionnement du mode entraînement, Atelier, identité graphique générale.
→ Après 5.7 + APK de recette pour ces quatre points : lot 05 ACCEPTABLE.

### Recette humaine du lot 05 — checklist initiale (2026-07-13, historique)

Points Android à vérifier (lot 05 §27, sur l'APK du push de clôture) :

1. Favoris : étoile sur la fiche (ajout/retrait immédiat), liste dans
   Pratique, toucher → fiche → retour avec position.
2. Racine Pratique : trois sections compactes, « Voir tout » quand il y a
   plus de 3 reprises / 4 favoris.
3. Éditeur : ajouter technique (favoris ★ visibles) et texte, réordonner
   au doigt (Monter/Descendre), menu d'un bloc (remplacer, texte après,
   retirer), modifier un texte en place.
4. Mode entraînement : lisible téléphone tenu ET posé + tablette au bord
   du tatami, grandes actions atteignables, barre basse absente, Voir la
   fiche → retour au MÊME bloc, retour Android = Quitter.
5. Dupliquer puis modifier la copie : l'originale intacte.
6. Retirer une technique utilisée : la confirmation nomme la composition ;
   le bloc « à retrouver » se remplace.
7. Export d'une composition : le rapport s'affiche avant ; le fichier
   produit se réimporte.
8. Hors ligne (mode avion) : favoris, édition, entraînement, sauvegarde.

| 04-creation-capture | **ACCEPTABLE** (recette Android 2026-07-13 : 17 points validés) | f6cbb92 (boucles 4.1→4.6) | `npm run verifier` vert (74 unit + e2e) ; CI de clôture : run 29220135697 (f6cbb92) vert ; APK : run 29219939637 (6b9988e — dernier code produit du lot ; f6cbb92 ne touche que docs/tests, l'APK n'y est pas déclenché) vert | APK de recette : run 29219939637 ; captures 10-17 regardées (D-026) | aucune — les runs `ci` intermédiaires 4.1→4.5 sont rouges par la SEULE garde D-014 (aval sauté, process pas produit — voir Frictions) |

### Recette Android du lot 04 (Yahya, 2026-07-13) — VALIDÉE

Résultats confirmés par l'humain sur Android réel :

- panneaux Ajouter corrects selon la racine ou la discipline ✓
- Retour Android et Annuler ferment sans mutation ✓
- refus puis acceptation de la permission caméra correctement gérés ✓
- enregistrement, aperçu, nouvelle prise et validation fonctionnels ✓
- aucune vidéo de durée nulle ou de zéro octet validable ✓
- aucun média temporaire ou fantôme après abandon ✓
- sélecteur de fichiers : annulation, fichier valide, erreur contrôlée ✓
- lien et commentaire correctement conservés ✓
- rattachement à une identité existante sans doublon ✓
- recherche dans toutes les disciplines fonctionnelle ✓
- suggestion de doublon et confirmation de création cohérentes ✓
- « Garder pour plus tard » survit à la fermeture, hors ligne compris ✓
- reprise, modification, rattachement et suppression confirmée ✓
- arrière-plan et retour par étapes sans perte silencieuse ✓
- contribution depuis la fiche sans redemander la technique ✓
- attribution personnelle / enseignement / ressource correcte ✓
- aucun double ajout après appuis répétés ✓

→ **Lot 04 : ACCEPTABLE.** Consignes : ne rouvrir les lots 1-4 que sur
régression directement causée par le lot 5 ; ne pas anticiper l'Atelier
(lot 6), la sécurité (lot 7) ni la consolidation graphique (lot 9).

### Recette humaine du lot 04 — checklist initiale (2026-07-13, historique)

Points Android à vérifier (lot 04 §24, sur l'APK du push de clôture) :

1. « Ajouter » (racine et discipline) : panneau court, gestes lisibles.
2. **Filmer maintenant** : permission caméra demandée, refus → alternatives
   (fichier/lien/mot) sans blocage ; l'aperçu se lit ; Refilmer relance.
3. **Une vidéo ou un fichier** : sélecteur système, aperçu, Utiliser.
4. Création minimale : nom seul → fiche ; doublon (« De Ashi Barai ») :
   suggestion, « Utiliser » et « Créer quand même » avec confirmation.
5. « Sais-tu où le ranger ? » : rattacher (recherche cadrée, élargir),
   créer, « Garder pour plus tard » → toast et Pratique > À reprendre.
6. Reprise : lire la vidéo hors ligne, modifier le texte, supprimer avec
   confirmation ; rien ne se perd après fermeture complète de l'app.
7. Mise en arrière-plan PENDANT une capture (appel, home) : au retour, la
   capture est toujours là ; le retour Android recule étape par étape et
   pose « Que faire de cette capture ? » quand un contenu existe.
8. Clavier : les champs restent visibles ; premier retour ferme le clavier.
9. « Ajouter une contribution » depuis une fiche : voix Enseignement
   correctement attribuée, jamais présentée comme personnelle.
10. Barre basse : aucun chevauchement avec les feuilles et leurs actions.

### Recette visuelle Android du lot 03 (Yahya, 2026-07-13) — GLOBALEMENT POSITIVE, lot NON CLÔTURÉ

Boucle corrective **3.7 — Contexte de fiche et libellés éditoriaux** demandée,
strictement limitée à :

1. En-tête fixe de la fiche : identifier la TECHNIQUE ouverte (ex.
   « Harai-goshi »), pas seulement « Judo » quand le grand titre est sorti
   de l'écran ; conserver retour et menu ⋮ ; ne rien changer à la navigation.
2. Résolution du nom des sources : nom éditorial réel (jamais « Club » seul
   si « Club judo » ou mieux existe ; jamais slug/UUID/originPackId visible) ;
   même libellé dans le titre de la voix ET dans « Ce contenu vient de … ».
3. Non-régression : UN SEUL lecteur média actif dans la fiche (média
   principal + média de voix compris) ; corriger si deux lecteurs peuvent
   jouer simultanément.
4. Média affiché = média principal dans une voix : garantir l'absence de
   double lecture ; tracer la réduction de redondance visuelle pour le lot 9
   si elle exige plus. Pas de refonte visuelle.

Interdits : Mon carnet (sauf régression directement causée), Relations,
Compositions, Atelier, identité graphique globale.
→ Après 3.7 + vérification Android : lot 03 ACCEPTABLE.

### Recette Android FINALE du lot 03 (Yahya, 2026-07-13) — VALIDÉE

Sur l'APK du run **29217733902** (commit `2573724`), confirmé par l'humain :

- en-tête fixe identifiant toujours la technique ouverte ✓
- libellé éditorial « Club judo » cohérent dans toute la voix ✓
- aucun identifiant technique visible ✓
- un seul lecteur média actif à la fois ✓
- menu, clavier et navigation liés correctement gérés par Retour Android ✓
- ajout de média sans élément fantôme après annulation ✓
- adaptation locale distincte, modifiable, sans altération de l'original ✓
- relations, compositions et actions accessibles au-dessus de la barre basse ✓

→ **Lot 03 : ACCEPTABLE.** Consigne : ne rouvrir les lots 1 à 3 qu'en cas
de régression directement causée par le lot 4.

### Recette humaine du lot 03 — checklist initiale (2026-07-12, historique)

Points Android à vérifier (lot 03 §23, sur l'APK du push de clôture) :

1. Fiche Harai-goshi : média principal en tête, légende « auteur ·
   provenance », lecture vidéo en ligne après geste explicite.
2. Galerie : miniatures horizontales, dernière atteignable, choisir un
   autre média (session), « Utiliser comme aperçu principal ».
3. « Ajouter un média » (menu ⋮ ou ＋) : **Filmer maintenant** (caméra),
   **Une vidéo de l'appareil** (sélecteur de fichier), **Coller un lien** —
   sans redemander la technique ; le média apparaît aussitôt.
4. Voix : une seule ouverte à la fois ; voix Kodokan non éditable avec
   explication ; « Créer une adaptation locale » → nouvelle voix
   modifiable ; l'original ne bouge pas.
5. Carnet : ajouter/modifier/supprimer une note au clavier (le clavier ne
   cache pas le champ ; premier retour ferme le clavier).
6. Relations : « Relations · N », « Voir toutes », navigation vers une
   technique liée puis retour — voix et média retrouvés (§19).
7. Retrait (menu ⋮) : la confirmation nomme les compositions dépendantes ;
   annuler ne change rien.
8. Barre basse : aucun chevauchement avec le bas de fiche.

## Condition de reprise

Relire les documents, vérifier le dernier commit, exécuter la vérification rapide et reprendre la boucle indiquée ci-dessus.
