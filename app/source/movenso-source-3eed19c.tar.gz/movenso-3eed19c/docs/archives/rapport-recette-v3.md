# Rapport de recette finale — Movenso V3 (lot 10C)

> **📦 ARCHIVÉ — figé (2026-07-24).** Instantané de la recette finale de la
> roadmap V3 (candidate `3.0.0-rc.1`), conservé comme **mémoire historique**.
> Le produit a évolué depuis (phase finition bêta) : pour l'état courant voir
> [`../execution/STATE.md`](../execution/STATE.md), pour la recette bêta active
> voir [`../recette-beta.md`](../recette-beta.md).

- **Version candidate** : `3.0.0-rc.1` (schéma projet ; versionCode Android = défaut Capacitor, chaîne release documentée non activée faute de secrets)
- **Branche** : `claude/movenso-v2-mission-ynb4ig`
- **Commit** : `5e19ec8` (lot-10b-stabilisation) — recette 10C exécutée sur build propre de ce commit
- **Modèle de données** : schéma **v3** · Conteneur **`.movpack` v4**
- **Date** : 2026-07-13
- **Décision** : **GO AVEC RÉSERVES**

## Résumé (≤ 10 lignes)

Movenso V3 est fonctionnellement cohérente et techniquement reproductible : les
neuf lots produit sont ACCEPTABLE avec recettes Android humaines. `npm run
verifier` est vert (132 tests unitaires + e2e Chromium sur OPFS réel), le build
web et l'APK CI sont verts, l'export est à mémoire bornée (700 Mo → +1 Mo RSS),
l'intégrité `.movpack` refuse toute corruption avant mutation, et
sauvegarde/restauration sur installation vierge sont démontrées vidéos comprises.
Aucun P0, aucun P1. Les réserves sont des P2/P3 documentés et des cibles de
plateforme déclarées absentes/différées, sans aucune réserve touchant la perte
de données, la sécurité du PIN ou la restauration annoncée. La candidate est
donc **GO AVEC RÉSERVES** (§31).

## A. Capacités démontrées

Toutes les capacités de la matrice (QUALITY §3) sont au statut ACCEPTABLE
(lots 1-9), recettes Android humaines consignées. Colonnes couvertes :
navigation (démarrage, 3 onglets, retour Android, états), Bibliothèque
(discipline vide, recherche globale/multisource, filtres cumulables, sans
doublon), fiche (média principal, voix multiples, carnet, relations,
compositions), création/capture (technique minimale, capture, rattachement,
reprise, annulation), Pratique (favoris, à reprendre, compositions,
réordonnancement, entraînement), Atelier (disciplines, taxonomies, diagnostics,
import, publication, sauvegarde, restauration), sécurité (appareil personnel,
protections séparées, PIN, expiration, tablette partagée, action destructive),
technique (média partagé, déduplication, `.movpack`, intégrité, transaction,
restauration vierge, mise à jour Android), UX (téléphone, tablette, paysage,
thèmes clair/sombre, accessibilité essentielle).

## B. Tests automatiques

- `npm run typecheck` : vert.
- `npm test` : **132 / 132** (domaine pur : modèle, migrations, rapprochement,
  recherche, médias, ingestion, sha256, espace, sécurité, movpack — dont 7
  assertions A1 —, contribution, sauvegarde, diagnostic, composition…).
- `npm run test:e2e` : parcours Chromium OPFS réel, « zéro erreur JS » —
  scénarios A,B,C,D,E,G,H,I,M + blocs 8A/8B/8C/8D/9/10B.
- `npm run epreuve:export` : mémoire bornée (200 Mo→+61 Mo ; 700 Mo→+1 Mo ; pic
  blocs = 1, indépendant du volume).
- Build web Vite : vert. Build Android : CI `apk` vert.

## C. Recette manuelle (Android réel)

Recettes humaines validées et consignées, lot par lot (STATE, sections
« Recette Android ») : lots 01-07 puis **08 (21 points)** et **09 (12 points)**
sur APK réels. Couvre : petits téléphones, portrait/paysage, clavier, retour
Android, zones sûres, tablette à l'échelle native, thèmes jour/nuit, 6
tonalités, gros export sans crash mémoire, interruption sans `.movpack` partiel,
restauration vidéos comprises, mise à jour APK sans perte, partage (téléchargement
WebView), diagnostic sans secret.

## D. Données (import / export / sauvegarde / restauration / intégrité / migrations)

- Sauvegarde complète (type `complet`) incluant réellement les médias ; étiquette
  « partielle » honnête si une vidéo manque (§20). Préférences/PIN jamais
  exportés (D-065).
- Restauration sur installation vierge : données ET vidéos, réexportables ;
  rapport annonçant les réglages d'appareil à reconfigurer.
- Intégrité par fichier (inventaire {chemin, taille, SHA-256}) : corruption
  (octet/média/taille/manquant) refusée AVANT toute mutation ; rétrocompat v3 ;
  JSON historique dit sans manifeste ni intégrité.
- Transactions (lot 8C) : bascule d'état protégée + reprise d'un commit
  interrompu ; atomicité média+métier sur tous les parcours (aucun orphelin,
  aucune référence fantôme) ; double-appui/concurrence maîtrisés.
- Publication (lot 10B, D-066) : relations hors périmètre exclues du fichier,
  jamais de lien pendant, local intact.
- Migrations : schéma 1→2→3 déterministes/testées ; V2 par outillage.

## E. Sécurité

Appareil personnel modifiable sans PIN par défaut ; protections modifications/
suppressions indépendantes ; PIN dérivé PBKDF2 (sel + empreinte, jamais en
clair, jamais dans les logs) ; session curateur + expiration + temporisation ;
tablette partagée ; aucun secret dans un pack publié ni une sauvegarde ;
réinitialisation complète. Diagnostic exportable sans secret.

## F. Performances

Export à mémoire bornée prouvé (harnais + recette). Un seul lecteur vidéo actif,
miniatures rendues à la volée (aucune vidéo entière chargée pour une vignette).
Bibliothèque de centaines de techniques fluide (recette lot 2/9). Aucune
opération interactive longue sans feedback (progression export/import).

## G. Anomalies restantes (P2/P3 — réserves)

| Réf | Sév | Anomalie | Contournement | Priorité |
|---|---|---|---|---|
| A1 | ~~P2~~ | relations hors périmètre à la publication | **CORRIGÉ en 10B (D-066)** | — |
| A2 | P2 | vue tablette côte à côte (fiche média-gauche/voix-droite, §31) non implémentée | contenu centré une colonne large, lisible | post-V3 |
| A3 | P2 | import V2 in-app non premier rang (§27) | migration outillée (`tools/`), packs-demo dérivés | post-V3 |
| A4 | P3 | famille d'icônes SVG unique (§9) : emojis résiduels menus/capture | glyphes monochromes cohérents ailleurs | post-V3 |
| A5 | P3 | pas de nouveau logo (§33) | marque typographique | post-V3 |
| A6 | P3 | `majContribution` mutation en place | autres parcours transactionnels (8C) ; sans média | post-V3 |

Plateformes déclarées (non-anomalies) : partage-sheet natif Android **différé**
(téléchargement WebView livré et dit) ; **PWA différée** ; **Windows/Electron
absents** (analyse de perte V2 faite : plus d'exécutable portable ; remplacé par
Web+Android hors ligne + export/sauvegarde souverains).

## H. Comparaison avec V2 (§39, sur preuves)

| Dimension | V2 | V3 | Gagnant | Réserve |
|---|---|---|---|---|
| Modèle du savoir (identité + voix multisource, provenance) | monolithique | identités uniques + contributions par source, relations génériques | **V3** | — |
| Exploration / Bibliothèque | riche | média-first, recherche multisource sans doublon, filtres | **V3** | — |
| Médias (registre, dédup, intégrité) | basique | registre calculé, dédup SHA-256, `.movpack` v4 vérifiable | **V3** | — |
| Sauvegarde / restauration / transactions | export global | complète (médias), transactionnelle, reprise après interruption | **V3** | interruption réelle = recette |
| Sécurité (PIN, tablette partagée) | — | protections facultatives, PIN dérivé, session | **V3** | — |
| Identité graphique / UX | dense mais daté | coque sombre / contenu clair, responsive, a11y | **V3** | icônes SVG, tablette côte à côte |
| Android | APK | APK reproductible (Capacitor, CI) | **V3** | partage natif différé |
| Windows portable / desktop | exécutable portable | absent (Web/Android) | **V2** | perte assumée, tracée |
| Reprise du projet | — | docs pilotes, reprise 30 min, build reproductible | **V3** | — |

Conclusion : **V3 supérieure globalement sur le modèle, les données, la
sécurité et l'UX** ; **V2 conserve l'avantage du Windows portable** (cible non
livrée en V3, déclarée). Pas de forçage : la seule dimension où V2 reste devant
est le desktop portable.

## I. Recommandation

**Continuer sur V3** comme nouvelle base du produit. Exploiter avec les réserves
documentées ; traiter le backlog post-V3 (A2-A6, partage natif, éventuel desktop)
selon les besoins réels. Ne pas revenir sur V2 (infériorité de modèle et de
maintenance), sauf besoin dur et immédiat d'un exécutable Windows portable — à
arbitrer séparément.

## Backlog post-V3 (§37)

| Entrée | Classe | Problème réel | Pourquoi après V3 |
|---|---|---|---|
| Famille d'icônes SVG unifiée (A4) | confort/cohérence | emojis hétérogènes dans quelques menus | esthétique, non bloquant |
| Vue tablette côte à côte (A2) | produit | mieux exploiter la largeur tablette | refonte de layout, hors gel |
| Import V2 in-app de premier rang (A3) | dette | migration V2 réservée à l'outillage | rare, contournement outillé |
| Robustesse `majContribution` (A6) | dette | mutation en place (sans média) | mineur, autres parcours sûrs |
| Partage système Android natif | plateforme | share-sheet vs téléchargement | vérif appareil + mémoire bornée à concilier |
| PWA / Windows portable | plateforme | cibles non livrées | décision produit dédiée |
| Nouveau logo / branding | produit | marque typographique temporaire | branding séparé |

## Décision finale : **GO AVEC RÉSERVES**

Critères §31 satisfaits : aucun P0 ; aucun P1 ; uniquement des P2/P3 connus ;
**aucune réserve ne touche la perte de données, la sécurité du PIN, ni la
restauration annoncée** ; limites visibles et documentées ; contournement
existant pour chacune. Les dix scénarios critiques (§29) sont couverts par les
tests e2e et les recettes Android humaines des lots 1-9. La candidate
`3.0.0-rc.1` peut être retenue comme nouvelle base du produit, réserves comprises.
