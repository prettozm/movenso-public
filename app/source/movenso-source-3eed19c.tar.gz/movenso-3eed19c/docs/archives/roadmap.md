# Roadmap Movenso — pilotage par lots

> **📦 ARCHIVÉ — figé (2026-07-24).** Cette roadmap (lots 1 à 10) a été
> **entièrement exécutée** ; elle est conservée comme **mémoire historique**
> de la commande de travail. Elle ne pilote plus rien. Pour l'état courant :
> [`../execution/STATE.md`](../execution/STATE.md) ; pour l'architecture réelle :
> [`../systeme.md`](../systeme.md) ; la phase active (finition bêta) est pilotée
> décision par décision dans [`../execution/DECISIONS.md`](../execution/DECISIONS.md).
> Les liens internes ci-dessous datent de la rédaction et peuvent être périmés.

> **Type : figé (historique)** · **Statut : LOTS 1 à 10 spécifiés intégralement
> (dictés par Yahya, session 22, 2026-07-12) — exécutés** — ce
> document est la commande de travail ; il prime sur toute initiative.
> Chaque lot est fermé, séquencé, et ne doit pas anticiper les lots suivants.
> L'exécution d'un lot ne commence que sur instruction humaine explicite.

## La cible : trois intentions

L'application s'organise autour de **trois intentions** seulement :

1. **consulter et enrichir** son savoir → onglet **Bibliothèque** ;
2. **utiliser et réutiliser** son savoir → onglet **Pratique** ;
3. **construire, gouverner et protéger** le corpus → onglet **Atelier**.

L'Accueil disparaît comme destination et comme passage obligé.

## Lots identifiés

| Lot | Périmètre | Statut |
|---|---|---|
| **1 — Navigation globale et démarrage** | Shell, routes, démarrage, redistribution de l'Accueil | **Spécifié intégralement ci-dessous — en attente du GO** |
| **2 — Bibliothèque** | Racine des disciplines, recherche globale, exploration, filtres cumulables, cartes techniques, discipline vide | **Spécifié intégralement ci-dessous — en attente du GO** |
| **3 — Fiche technique** | Structure de la fiche, média principal, galerie, voix et contributions, Mon carnet éditable, édition contextuelle, relations et compositions compactes, retrait sécurisé | **Spécifié intégralement ci-dessous — en attente du GO** |
| **4 — Création, capture et édition** | Trois intentions distinctes (créer/capturer/modifier), panneau `Ajouter` contextuel, création minimale, prévention des doublons, capture rapide (filmer/fichier/lien/mot), rattachement différé, provenance personnelle par défaut, capture non rattachée, gestion des médias temporaires, hors ligne | **Spécifié intégralement ci-dessous — en attente du GO** |
| **5 — Pratique, Favoris et Compositions** | Racine Pratique (À reprendre/Favoris/Compositions), modèle minimal des favoris, simplification des blocs de composition à deux choix (technique/texte) avec compatibilité des anciens types, réordonnancement, mode entraînement, export/import, sauvegarde/restauration | **Spécifié intégralement ci-dessous — en attente du GO** |
| **6 — Atelier** | Refonte en quatre intentions : Construire (disciplines/taxonomies/techniques/relations/sources) · Médias et qualité (diagnostics/médiathèque/qualité du corpus) · Échanger et protéger (import/publication/sauvegarde/restauration/rollback) · Réglages et sécurité (démarrage/apparence, protections différées) | **Spécifié intégralement ci-dessous — en attente du GO** |
| **7 — Sécurité et modes d'usage** | Appareil personnel sans PIN par défaut, deux protections indépendantes (modifications / suppressions-opérations sensibles), PIN local dérivé (PBKDF2/SHA-256, jamais en clair), session temporaire de curateur, préréglage Tablette partagée, matrice centralisée des actions, exclusion des secrets des exports | **Spécifié intégralement ci-dessous — en attente du GO** |
| **8 — Formats, médias, stockage et plateformes** | Lot de durcissement technique : registre média central, références multiples sans suppression accidentelle, nommage physique stable, `.movpack` versionné avec intégrité SHA-256 par fichier, export à mémoire bornée, import/restauration transactionnels avec zone de préparation, sauvegarde complète distincte du snapshot et du pack publié, projet Android reproductible, matrice honnête des plateformes (Web/PWA/Windows/Electron) | **Spécifié intégralement ci-dessous — en attente du GO** |
| **9 — Identité graphique et consolidation UX** | Aucune évolution fonctionnelle : direction « coque sombre, contenu vivant », système de tokens centralisé, réduction des cartes arrondies, densité différenciée téléphone/tablette, une seule action contextuelle par écran, cohérence des libellés, accessibilité, captures et tests de régression visuelle | **Spécifié intégralement ci-dessous — en attente du GO** |
| **10 — Recette finale, stabilisation et clôture** | Gel du périmètre, audit (10A) → stabilisation P0/P1 uniquement (10B) → recette à blanc depuis un environnement propre (10C), matrice des capacités, dix scénarios critiques de bout en bout, comparaison factuelle V2/V3, décision GO / GO AVEC RÉSERVES / NO-GO | **Spécifié intégralement ci-dessous — en attente du GO** |

---

# LOT 1 — NAVIGATION GLOBALE ET DÉMARRAGE

## Contexte

Movenso V3 possède actuellement quatre destinations principales :

- Accueil ;
- Bibliothèque ;
- Compositions ;
- Atelier.

L'Accueil mélange recherche, reprise personnelle, compositions, import et
accès aux disciplines. Il crée un passage supplémentaire sans porter une
fonction suffisamment distincte.

La cible validée est désormais une application organisée autour de trois
intentions seulement :

1. consulter et enrichir son savoir ;
2. utiliser et réutiliser son savoir ;
3. construire, gouverner et protéger le corpus.

Ce lot porte **exclusivement** sur le shell de navigation, les routes, le
démarrage, la conservation de l'état et la redistribution des fonctions
actuellement placées sur l'Accueil.

Il ne doit **pas** anticiper la refonte détaillée de la Bibliothèque, des
fiches, des compositions ou de l'Atelier, qui feront l'objet de lots séparés.

## Objectif unique

Supprimer l'Accueil comme destination et comme passage obligatoire, puis
mettre en place une navigation stable à trois onglets :

- Bibliothèque ;
- Pratique ;
- Atelier.

L'application doit ouvrir directement sur la Bibliothèque et chaque fonction
actuellement accessible depuis l'Accueil doit conserver une destination
claire, **sans duplication ni perte silencieuse**.

## 1. Navigation principale

Mettre en place une barre de navigation basse contenant exactement trois
entrées :

- Bibliothèque ;
- Pratique ;
- Atelier.

La barre doit respecter les zones sûres Android et rester utilisable sur
téléphone comme sur tablette.

Ordre obligatoire :

1. Bibliothèque ;
2. Pratique ;
3. Atelier.

Utiliser des icônes simples et distinctes :

- Bibliothèque : livre, collection ou bibliothèque ;
- Pratique : assemblage, parcours ou entraînement ;
- Atelier : outil ou clé.

Ne pas conserver d'icône Accueil.

La destination active doit être immédiatement identifiable, **sans reposer
uniquement sur la couleur** : icône, libellé ou contraste doivent également
traduire l'état actif.

## 2. Suppression de l'Accueil

Supprimer l'Accueil :

- de la barre basse ;
- des routes de navigation normales ;
- du comportement de démarrage ;
- des liens de retour ;
- des préférences de démarrage ;
- de la documentation des workflows actifs.

Ne pas seulement masquer l'écran : **redistribuer ses capacités avant de
supprimer sa route**.

Les anciennes routes ou préférences pointant vers l'Accueil doivent être
migrées ou redirigées vers la Bibliothèque.

**Aucune donnée créée depuis l'ancien Accueil ne doit être supprimée.**

## 3. Démarrage

Au premier lancement, après une mise à jour et après une fermeture complète
de l'application, la destination par défaut est la **Bibliothèque**.

Deux états doivent être possibles.

**Bibliothèque contenant des disciplines :**

- afficher immédiatement la liste des disciplines ;
- ne pas imposer une recherche, une reprise ou une étape intermédiaire.

**Bibliothèque vide :**

- expliquer en une phrase que la bibliothèque est prête à recevoir du contenu ;
- proposer directement :
  - Importer un pack ;
  - Créer une discipline.

Ces actions peuvent encore utiliser leurs workflows actuels dans ce lot.
Leur refonte détaillée appartient au lot Bibliothèque.

Ne pas recréer un écran d'onboarding distinct.

Si une ancienne préférence de démarrage désigne l'Accueil, la **migrer
automatiquement** vers la Bibliothèque.

## 4. Onglet Bibliothèque

La Bibliothèque devient le **centre de consultation** du produit.

Dans ce lot, conserver ses capacités actuelles et y rendre accessibles les
fonctions de l'ancien Accueil qui relèvent réellement de la consultation :

- liste des disciplines ;
- recherche multi-discipline ou multi-pack déjà existante ;
- import d'un pack lorsque la bibliothèque est vide ;
- création d'une discipline lorsque la bibliothèque est vide.

Ne pas redessiner encore :

- les cartes ;
- les filtres ;
- les fiches ;
- les sources ;
- les médias ;
- les workflows de création.

Ces sujets appartiennent aux lots suivants.

La navigation doit cependant permettre :

```
Bibliothèque
→ discipline
→ liste des techniques
→ fiche technique
→ retour à la même liste, avec filtres et position conservés.
```

## 5. Onglet Pratique

Créer une destination principale **Pratique**.

Elle réunit les usages personnels et de réutilisation du savoir sans les
mélanger avec la gestion du corpus.

La racine de Pratique doit donner accès à :

- **Favoris** ;
- **Compositions**.

Les compositions actuellement accessibles comme onglet principal deviennent
une sous-destination de Pratique :

```
Pratique
→ Compositions
→ composition
→ consultation ou édition.
```

Les anciennes routes directes vers Compositions doivent être conservées par
redirection ou migration vers la nouvelle route.

**Favoris** doit disposer d'une entrée réelle dans Pratique.

Si le modèle V3 ne possède pas encore de favoris, **ne pas inventer un faux
comportement et ne pas modifier le modèle dans ce lot**. Créer seulement la
destination et son état vide explicite, puis tracer l'implémentation
fonctionnelle pour le lot Pratique.

Une section **À reprendre** peut être affichée uniquement lorsqu'il existe
une action réellement inachevée, par exemple :

- une capture non rattachée ;
- un brouillon de composition ;
- une action interrompue explicitement sauvegardée comme brouillon.

Ne pas utiliser « À reprendre » comme simple historique de consultation ou
comme liste de notes récentes.

Si aucun élément actionnable n'existe, la section n'apparaît pas.

Ne pas conserver le texte actuel centré sur « ton carnet est vide ».

## 6. Onglet Atelier

Conserver l'Atelier comme troisième destination principale.

Dans ce lot :

- ne pas refondre encore ses sections internes ;
- ne pas modifier ses capacités métier ;
- ne pas modifier le stockage, les packs ou les diagnostics ;
- conserver l'accès aux fonctions déjà présentes.

La refonte en quatre intentions sera faite dans le **lot Atelier** :

- Construire ;
- Médias et qualité ;
- Échanger et protéger ;
- Réglages et sécurité.

La clé à molette et l'onglet Atelier ne doivent pas constituer deux entrées
concurrentes.

Après la mise en place de la barre basse :

- supprimer toute clé à molette globale qui ne ferait qu'ouvrir l'Atelier ;
- garder une clé uniquement lorsqu'elle représente une action réellement
  locale à un écran.

## 7. Actions contextuelles

Supprimer le bouton flottant global `Capturer` du shell de l'application.

Il ne doit plus apparaître automatiquement :

- sur l'Atelier ;
- sur les compositions ;
- sur tous les écrans sans distinction.

Prévoir dans le shell un emplacement pour une **action contextuelle**,
définie par l'écran courant.

Pour ce lot, réutiliser les actions existantes sans refondre leurs workflows :

**Bibliothèque ou discipline :**

- action `Ajouter` ou `Nouvelle technique` lorsqu'une discipline est connue ;
- possibilité d'accéder au flux existant de capture ou de création.

**Fiche technique :**

- les actions restent locales à la fiche ;
- ne pas afficher un bouton global qui masque le contenu.

**Pratique, racine :**

- aucune action globale obligatoire.

**Liste des compositions :**

- action `Nouvelle composition`.

**Composition ouverte :**

- les actions d'ajout et d'édition appartiennent à la composition, pas au
  shell global.

**Atelier :**

- aucun bouton flottant générique.

Les libellés doivent décrire l'action réelle. Ne pas utiliser `Capturer`
lorsqu'il s'agit en réalité de créer une composition, modifier une taxonomie
ou publier un pack.

## 8. Conservation de l'état

Chaque onglet doit conserver son état pendant la session.

Exemples :

**Bibliothèque :**

- discipline ouverte ;
- recherche ;
- filtres ;
- position de défilement ;
- fiche précédemment ouverte lorsque le retour est demandé.

**Pratique :**

- sous-section Favoris ou Compositions ;
- composition ouverte ;
- position de liste.

**Atelier :**

- section ouverte ;
- position de défilement.

Changer d'onglet ne doit pas réinitialiser inutilement les écrans ni recréer
leurs données.

Un second appui sur l'onglet déjà actif peut revenir à sa racine ou remonter
en haut de la liste, à condition que ce comportement soit constant et
documenté.

## 9. Comportement du bouton retour Android

Le comportement doit être déterministe.

Ordre de priorité :

1. fermer le clavier ;
2. fermer une modale, un panneau ou un menu temporaire ;
3. quitter un workflow d'édition avec gestion explicite des modifications
   non enregistrées ;
4. remonter d'une fiche vers sa liste ;
5. remonter d'une sous-section vers la racine de son onglet ;
6. depuis la racine de Pratique ou Atelier, revenir à la Bibliothèque ;
7. depuis la racine de la Bibliothèque, laisser Android fermer ou mettre
   l'application en arrière-plan.

Le changement d'onglet ne doit pas empiler une infinité d'entrées dans
l'historique.

Un retour depuis une fiche doit restaurer les filtres et la position de la
bibliothèque.

## 10. Affichage de la barre basse

Afficher la barre basse sur :

- la racine Bibliothèque ;
- la liste d'une discipline ;
- la racine Pratique ;
- la liste des compositions ;
- la racine Atelier.

Elle peut être masquée pendant :

- capture guidée ;
- édition plein écran ;
- import ou restauration en cours ;
- confirmation destructive ;
- lecture immersive d'un média ;
- mode d'utilisation d'une composition pendant l'entraînement.

Ne pas la masquer arbitrairement sur les écrans de consultation courante.

## 11. Capacités de l'ancien Accueil à redistribuer

Avant suppression définitive de l'Accueil, vérifier la destination de
chaque capacité :

- recherche globale → Bibliothèque ;
- liste des disciplines → Bibliothèque ;
- import d'un pack → Bibliothèque vide et Atelier ;
- création d'une discipline → Bibliothèque vide et Atelier ;
- compositions → Pratique ;
- favoris → Pratique ;
- captures non rattachées → Pratique « À reprendre » ou futur espace de
  vérification de l'Atelier ;
- réglages → Atelier ;
- capture rapide → action contextuelle adaptée, jamais bouton global
  permanent.

Ne conserver aucune fonction uniquement parce qu'elle existait sur
l'Accueil.

Ne supprimer aucune fonction simplement parce que l'Accueil disparaît.

## 12. Limites strictes du lot

Ne pas modifier dans ce lot :

- le modèle de données métier ;
- le rapprochement des identités ;
- le modèle de provenance ;
- le format `.movpack` ;
- le stockage OPFS ;
- la gestion des médias ;
- la structure des compositions ;
- les types de relations ;
- le contenu interne détaillé de l'Atelier ;
- la fiche technique ;
- la direction graphique générale ;
- les règles de sécurité ou de PIN.

Les changements techniques autorisés sont limités à :

- routes ;
- shell ;
- navigation ;
- redirections ;
- état de navigation ;
- migration des préférences de démarrage ;
- déplacement des points d'entrée existants ;
- adaptations minimales nécessaires à la barre basse.

Toute amélioration identifiée hors périmètre doit être **tracée, pas
implémentée**.

## 13. Critères d'acceptation

Le lot est accepté uniquement si les scénarios suivants fonctionnent
réellement.

**Scénario A — démarrage avec contenu :**

1. lancer l'application ;
2. arriver directement sur Bibliothèque ;
3. voir les disciplines ;
4. ouvrir Judo ;
5. appliquer un filtre ;
6. ouvrir une technique ;
7. revenir ;
8. retrouver le filtre et la position.

**Scénario B — navigation :**

1. ouvrir Bibliothèque ;
2. passer à Pratique ;
3. ouvrir Compositions ;
4. revenir à Pratique ;
5. passer à Atelier ;
6. revenir à Bibliothèque ;
7. vérifier que les états précédents sont conservés.

**Scénario C — installation vide :**

1. lancer sans contenu ;
2. arriver sur la Bibliothèque vide ;
3. voir Importer un pack et Créer une discipline ;
4. utiliser chacun des deux points d'entrée sans repasser par un Accueil.

**Scénario D — bouton retour :**

1. Bibliothèque → discipline → fiche ;
2. retour vers la discipline avec état conservé ;
3. passage vers Atelier ;
4. retour Android vers Bibliothèque ;
5. retour Android depuis Bibliothèque vers le système.

**Scénario E — actions contextuelles :**

- aucun bouton Capturer dans l'Atelier ;
- aucune action Nouvelle composition dans la Bibliothèque ;
- création de composition accessible depuis Pratique ;
- ajout de technique accessible depuis une discipline ;
- aucune action globale ambiguë.

**Scénario F — compatibilité :**

- une ancienne route Accueil redirige vers Bibliothèque ;
- une ancienne route Compositions ouvre Pratique > Compositions ;
- une ancienne préférence de démarrage Accueil est migrée ;
- aucune donnée existante n'est perdue.

## 14. Tests

Ajouter ou adapter les tests automatisés pour couvrir :

- route initiale ;
- redirections ;
- trois onglets seulement ;
- restauration de l'état ;
- navigation Android simulée lorsque possible ;
- ancien lien Compositions ;
- ancienne préférence Accueil ;
- disparition du bouton global dans l'Atelier.

Compléter par une vérification manuelle Android lorsque le comportement du
bouton retour ou du clavier ne peut pas être prouvé par le navigateur.

`npm run verifier` doit être vert.

## 15. Documentation

Mettre à jour les sources existantes, sans créer un nouveau document :

- **`docs/workflows.md`** :
  - carte Mermaid de la navigation à trois onglets ;
  - destinations de l'ancien Accueil ;
  - comportement du bouton retour ;
  - statut réellement démontré de chaque parcours ;
- **`docs/systeme.md`** :
  - shell et routes réels ;
- **matrice de conservation** :
  - Accueil supprimé avec justification ;
  - fonctions redistribuées ;
  - aucune capacité perdue silencieusement ;
- **`docs/etat.md`** :
  - lot terminé ;
  - tests ;
  - limites connues ;
  - prochain lot.

La documentation doit refléter l'implémentation réelle et non la cible
future.

## 16. Livrable

À la fin du lot :

- commit et push dédiés au lot 1 ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- trois captures montrant les racines :
  - Bibliothèque ;
  - Pratique ;
  - Atelier ;
- rapport compact contenant :
  - fichiers modifiés ;
  - routes supprimées ou redirigées ;
  - comportement du bouton retour ;
  - capacités de l'Accueil redistribuées ;
  - anomalies restantes strictement hors périmètre.

**N'interprète pas ce lot comme une autorisation à modifier les autres
onglets ou à anticiper les étapes suivantes.**

**Aucune fonctionnalité métier nouvelle, aucune refonte de fiche, aucune
modification du modèle et aucune réorganisation détaillée de l'Atelier ne
doivent être réalisées dans ce lot.**

---

> **Statut** : texte du LOT 1 reçu **intégralement** (session 22,
> 2026-07-12). Le lot est **spécifié en entier** — reste en attente d'un
> **GO explicite** de Yahya avant toute exécution.

---

# LOT 2 — BIBLIOTHÈQUE : EXPLORER, CHERCHER ET PEUPLER UN CORPUS

## Contexte

Le lot 1 a supprimé l'Accueil et installé trois destinations principales :

- Bibliothèque ;
- Pratique ;
- Atelier.

La Bibliothèque est désormais la destination de démarrage et le centre de
consultation de Movenso.

La V3 possède déjà plusieurs qualités à conserver :

- une grille visuelle efficace ;
- des identités techniques réunissant plusieurs contributions ;
- une recherche multi-source ;
- des filtres de familles et de niveaux ;
- des miniatures vidéo ;
- une navigation discipline → techniques → fiche ;
- des disciplines pouvant exister sans contenu embarqué.

Cependant, plusieurs ambiguïtés subsistent :

- discipline, pack, source et provenance ne sont pas toujours clairement
  distingués dans l'interface ;
- une discipline vide peut mener à une impasse ;
- les identifiants techniques de packs peuvent apparaître comme des
  libellés utilisateur ;
- l'import et la création de discipline occupent parfois inutilement le
  premier plan ;
- les filtres et états de navigation doivent être conservés de manière
  fiable ;
- une identité réunissant plusieurs voix ne doit jamais réapparaître
  plusieurs fois dans les résultats.

Ce lot porte **exclusivement** sur la Bibliothèque :

- racine des disciplines ;
- recherche globale ;
- exploration d'une discipline ;
- filtres ;
- cartes techniques ;
- états vides ;
- accès à la création d'une première technique.

Il ne refond pas encore :

- la fiche technique ;
- le workflow détaillé de création ou de capture ;
- les favoris ;
- les compositions ;
- l'Atelier ;
- le modèle des médias ;
- la sécurité ;
- la direction graphique générale.

## Objectif unique

Faire de la Bibliothèque un espace immédiatement compréhensible et complet
pour :

1. choisir une discipline ;
2. rechercher dans l'ensemble du savoir installé ;
3. explorer visuellement les techniques ;
4. filtrer sans perdre les identités réunies ;
5. comprendre la différence entre discipline et source ;
6. commencer à peupler une discipline vide sans impasse.

## 1. Hiérarchie conceptuelle à respecter

L'interface doit respecter strictement les distinctions suivantes.

**Discipline :**

- représente l'art martial ou le champ de pratique ;
- exemples : Judo, Boxe, Karaté, JJB ;
- apparaît à la racine de la Bibliothèque.

**Identité technique :**

- représente une technique unique ;
- exemples : Ashi-guruma, Crochet gauche ;
- apparaît une seule fois dans la grille, même si plusieurs sources la
  décrivent.

**Source :**

- indique l'auteur ou le corpus d'origine d'une contribution ;
- exemples : Kodokan, Club X, Sensei Y, Moi ;
- sert de filtre ou d'information secondaire ;
- ne crée jamais une discipline parallèle.

**Pack :**

- est une unité d'import, d'export, de versionnement et de distribution ;
- son nom technique ou son identifiant interne ne doit pas devenir
  automatiquement un libellé d'interface ;
- un pack peut contribuer à une discipline existante.

**Provenance :**

- qualifie la nature d'une contribution :
  - référentiel ;
  - enseignement ;
  - ressource ;
  - personnel ;
- ne remplace ni la discipline, ni le nom du pack, ni son auteur.

Ne pas introduire dans ce lot une nouvelle entité métier `Collection`.

Si le besoin d'une collection distincte apparaît, le tracer comme question
ouverte sans modifier le modèle.

## 2. Racine de la Bibliothèque

La racine affiche la liste des disciplines présentes.

Chaque discipline apparaît une seule fois.

Une carte de discipline contient au minimum :

- son nom utilisateur ;
- le nombre d'identités techniques uniques ;
- éventuellement le nombre de sources présentes ;
- éventuellement le nombre de techniques possédant plusieurs voix.

Exemple acceptable :

```
Judo
136 techniques · 2 sources · 24 à plusieurs voix
```

Ne pas afficher comme sous-titre générique :

- « référentiel » ;
- « pack club » ;
- un identifiant tel que `club-judo` ;
- une addition brute du nombre d'éléments de chaque pack.

Les compteurs doivent porter sur les identités réellement visibles dans la
discipline, pas sur le total des contributions.

Une discipline vide doit apparaître clairement :

```
Boxe
0 technique · prête à être complétée
```

La carte reste ouvrable.

## 3. Actions à la racine

**Bibliothèque contenant au moins une discipline :**

- ne pas afficher en permanence de grandes actions `Importer un pack` ou
  `Créer une discipline` ;
- ces fonctions restent disponibles dans l'Atelier ;
- ne pas ajouter de bouton flottant global.

**Bibliothèque totalement vide :**

afficher un état vide contenant :

- une phrase courte ;
- `Importer un pack` ;
- `Créer une discipline`.

Exemple :

```
Ta bibliothèque est vide.
Importe un corpus existant ou commence ta propre discipline.
```

Une fois la première discipline créée ou le premier pack importé, cet écran
disparaît au profit de la liste normale.

Ne pas créer d'onboarding supplémentaire.

## 4. Recherche globale

La Bibliothèque doit proposer une recherche globale clairement accessible
depuis sa racine.

Elle interroge l'ensemble des disciplines et sources installées.

La recherche doit couvrir au minimum :

- nom principal de la technique ;
- nom traditionnel ;
- appellations ou alias disponibles ;
- texte personnel indexable ;
- libellés utiles déjà pris en charge par le moteur de recherche actuel.

Elle doit être :

- insensible à la casse ;
- tolérante aux accents ;
- tolérante aux espaces et traits d'union ;
- compatible avec les variantes simples de romanisation déjà gérées.

Exemples :

- `de ashi` retrouve `De-ashi-harai` ;
- `banane` retrouve une technique contenant ce repère personnel ;
- une appellation traditionnelle retrouve la technique concernée.

Une identité apparaît une seule fois dans les résultats, même si plusieurs
contributions correspondent à la recherche.

Chaque résultat affiche suffisamment de contexte :

- nom ;
- nom traditionnel si disponible ;
- discipline ;
- miniature ou fallback ;
- sources ou nombre de voix lorsque cela est pertinent.

Ouvrir un résultat puis revenir doit restaurer :

- la requête ;
- les résultats ;
- la position de défilement.

Ne pas afficher l'intégralité des descriptions dans les résultats.

## 5. Explorateur d'une discipline

Conserver la grille visuelle actuelle de la V3 comme base.

Sur téléphone :

- deux colonnes lorsque la largeur le permet ;
- cartes lisibles sans textes tronqués de façon incohérente.

Sur tablette ou grand écran :

- augmenter naturellement le nombre de colonnes ;
- ne pas étirer les cartes sur toute la largeur.

En tête de l'explorateur :

- retour vers la liste des disciplines ;
- nom de la discipline ;
- nombre d'identités techniques uniques ;
- recherche locale ;
- filtres de sources ;
- filtres de niveaux ;
- filtres de familles ou catégories.

Ne pas afficher les packs comme s'ils étaient des disciplines.

## 6. Filtre par source

Ajouter ou conserver un filtre de source au sein de la discipline.

Exemples de libellés :

- Toutes les sources ;
- Kodokan ;
- Club de Castres ;
- Moi.

Ne jamais afficher directement un identifiant technique tel que :

- `club-judo` ;
- `pack-kodokan-v1` ;
- un UUID ;
- un slug interne.

Le libellé provient en priorité :

1. du nom éditorial du manifeste ;
2. du nom de l'auteur ou de l'organisation ;
3. d'un fallback lisible explicitement construit.

Si deux sources portent le même nom, les différencier avec une information
compréhensible :

- auteur ;
- organisation ;
- version ;
- origine.

Ne pas utiliser leurs identifiants bruts comme solution d'interface.

Sémantique du filtre :

- `Toutes les sources` affiche chaque identité une seule fois ;
- sélectionner une source affiche les identités possédant au moins une
  contribution issue de cette source ;
- une identité ayant plusieurs contributions issues de la même source reste
  affichée une seule fois ;
- `Moi` sélectionne les identités possédant une contribution personnelle.

Le filtre de source ne supprime ni ne duplique les identités.

## 7. Représentation d'une technique selon le filtre de source

En vue `Toutes les sources` :

- utiliser le média principal de l'identité lorsque disponible ;
- sinon utiliser le meilleur média disponible selon les règles existantes ;
- indiquer discrètement lorsqu'une technique contient plusieurs voix.

En vue filtrée par une source :

- privilégier pour l'aperçu un média provenant de la source sélectionnée
  lorsqu'il existe ;
- sinon conserver le média principal avec une indication claire que
  l'aperçu vient d'une autre source ;
- ne pas modifier le média principal global simplement parce qu'un filtre
  est actif.

Ne pas exposer toute la provenance sur la carte.

Une indication compacte suffit, par exemple :

- `2 voix` ;
- un petit badge de source ;
- un filet visuel ;
- une icône accompagnée d'un libellé accessible.

L'utilisateur doit comprendre le résultat sans transformer chaque carte en
fiche détaillée.

## 8. Cartes techniques

Chaque carte contient au minimum :

- miniature ou fallback ;
- nom principal ;
- nom traditionnel lorsqu'il existe ;
- niveaux pertinents sous forme compacte ;
- indication de pluralité des voix lorsque nécessaire.

La famille peut être affichée uniquement si elle ne surcharge pas la carte.

Fallback sans média :

- initiale du nom principal ;
- appellation traditionnelle ;
- symbole générique non disciplinaire.

Ne pas coder en dur :

- kanji de judo ;
- icône propre à une discipline ;
- couleur de ceinture universelle.

Ne pas ajouter sur chaque vignette :

- crayon d'édition ;
- suppression ;
- menu administratif permanent ;
- bouton de capture.

Toucher la carte ouvre la fiche.

Les modifications et actions détaillées appartiennent à la fiche ou aux
workflows contextuels des lots suivants.

Les éventuels favoris ne sont pas implémentés dans ce lot.

Si des données de favoris existent déjà :

- les préserver ;
- ne pas les supprimer ;
- ne pas refondre leur UX avant le lot Pratique.

## 9. Filtres cumulables

Les filtres doivent fonctionner ensemble.

Dimensions minimales :

- recherche ;
- source ;
- famille ou catégorie ;
- niveau.

Sémantique :

- entre dimensions : ET ;
- plusieurs choix au sein d'une même dimension, si le moteur le permet : OU.

Exemple :

```
Source = Club
ET
Niveau = Jaune ou Orange
ET
Famille = Ashi-waza
ET
Recherche = gari
```

Les résultats et leur compteur se mettent à jour immédiatement.

Les filtres actifs doivent être visibles.

Prévoir une action compacte :

- `Réinitialiser les filtres`

uniquement lorsqu'au moins un filtre est actif.

Lorsque aucun résultat ne correspond :

afficher :

- la phrase `Aucune technique ne correspond à ces filtres` ;
- les filtres actifs ;
- l'action de réinitialisation.

Ne pas afficher une bibliothèque vide ambiguë lorsqu'il s'agit uniquement
d'un filtre trop restrictif.

## 10. Niveaux et taxonomies

Les niveaux, familles et catégories sont issus des données de la
discipline.

Le moteur ne suppose pas :

- des ceintures ;
- un ordre de grades universel ;
- une nomenclature japonaise ;
- une seule famille par technique.

Afficher les couleurs lorsqu'elles existent dans les données.

Un niveau sans couleur reste utilisable et visible.

Le libellé du filtre doit provenir de la donnée et non d'un vocabulaire
codé dans l'interface.

Ne pas modifier dans ce lot :

- la création ;
- le renommage ;
- la suppression ;
- l'ordre des taxonomies.

Ces opérations restent dans l'Atelier et seront traitées dans son lot.

## 11. Discipline vide

Ouvrir une discipline vide ne doit plus produire seulement :

- une grille vide ;
- `Rien avec ces filtres` ;
- un bouton Capturer demandant ensuite une technique inexistante.

Afficher un état vide spécifique :

```
Boxe ne contient encore aucune technique.
```

Action principale :

- `Créer la première technique`

Action secondaire possible :

- `Importer un pack`

L'action principale doit ouvrir le workflow de création de technique
existant.

Dans ce lot, ne pas refondre entièrement ce workflow.

Cependant, vérifier qu'il permet au minimum :

- de préselectionner la discipline ouverte ;
- de créer la technique ;
- de revenir dans cette discipline ;
- de voir immédiatement la nouvelle technique.

Si le workflow actuel ne permet pas ce parcours minimal, effectuer
uniquement les adaptations nécessaires pour supprimer l'impasse.

Le workflow complet de création, capture et édition sera traité au lot
correspondant.

## 12. Action contextuelle dans une discipline

Lorsqu'une discipline contient déjà des techniques et que les
modifications sont autorisées, proposer une action contextuelle claire :

- `+ Technique`
ou
- `Nouvelle technique`

Ne pas utiliser le libellé générique `Capturer` pour cette action.

Cette action ouvre le workflow existant de création ou de capture avec la
discipline préselectionnée.

Lorsqu'une protection interdit les modifications, l'action doit être :

- masquée ;
ou
- présentée comme protégée avec un comportement cohérent.

Ne pas implémenter ou refondre le PIN dans ce lot.

Respecter simplement l'état d'autorisation existant.

## 13. Conservation de l'état

Pour chaque discipline, conserver pendant la session :

- recherche ;
- source sélectionnée ;
- familles sélectionnées ;
- niveaux sélectionnés ;
- position de défilement.

Changer d'onglet puis revenir ne doit pas effacer ces éléments.

Ouvrir une fiche puis revenir doit restaurer exactement l'explorateur.

Revenir à la racine Bibliothèque puis rouvrir une discipline peut restaurer
son dernier état pendant la session.

Après fermeture complète de l'application, conserver uniquement ce qui est
déjà prévu par les préférences existantes.

Ne pas ajouter de persistance permanente de tous les filtres sans besoin
démontré.

## 14. Performance

La Bibliothèque doit rester fluide avec :

- plusieurs disciplines ;
- plusieurs centaines de techniques ;
- plusieurs sources par identité ;
- miniatures locales ou distantes.

Éviter :

- recalcul complet non nécessaire à chaque frappe ;
- reconstruction de toutes les miniatures à chaque filtre ;
- duplication des identités dans des tableaux intermédiaires persistants ;
- chargement complet des médias vidéo pour afficher une vignette.

Utiliser les index et métadonnées existants.

Ne pas refondre le modèle de stockage dans ce lot.

## 15. Limites strictes du lot

Ne pas modifier :

- le modèle identité/contribution ;
- le rapprochement inter-packs ;
- le format `.movpack` ;
- le stockage OPFS ;
- le modèle des médias ;
- la fiche technique ;
- les compositions ;
- les favoris ;
- l'organisation interne de l'Atelier ;
- la sécurité et le PIN ;
- la direction graphique globale ;
- la publication des packs ;
- les relations.

Les changements métier autorisés sont limités à ce qui est nécessaire pour :

- rechercher ;
- filtrer ;
- présenter sans duplication ;
- ouvrir une discipline vide ;
- créer sa première technique avec le workflow existant.

Toute autre amélioration détectée doit être **tracée, pas implémentée**.

## 16. Critères d'acceptation

**Scénario A — racine :**

1. ouvrir Bibliothèque ;
2. voir une seule carte Judo ;
3. vérifier que Kodokan et Club ne sont pas affichés comme disciplines
   séparées ;
4. vérifier que le nombre affiché correspond aux identités uniques ;
5. ouvrir Judo.

**Scénario B — exploration :**

1. voir la grille visuelle ;
2. filtrer par famille ;
3. ajouter un niveau ;
4. ajouter une source ;
5. saisir une recherche ;
6. vérifier que tous les filtres se cumulent ;
7. réinitialiser ;
8. retrouver la grille complète.

**Scénario C — multi-source :**

1. afficher Toutes les sources ;
2. vérifier qu'Ashi-guruma n'apparaît qu'une fois ;
3. filtrer Kodokan ;
4. vérifier qu'Ashi-guruma reste visible avec l'aperçu approprié ;
5. filtrer Club ;
6. vérifier qu'elle reste unique ;
7. ne voir aucun identifiant technique de pack dans l'interface.

**Scénario D — recherche globale :**

1. revenir à la racine ;
2. chercher une technique présente dans plusieurs sources ;
3. obtenir un seul résultat ;
4. ouvrir la fiche ;
5. revenir ;
6. retrouver la requête et la position.

**Scénario E — recherche personnelle :**

1. créer ou utiliser un repère personnel existant ;
2. le rechercher depuis la Bibliothèque ;
3. retrouver la technique concernée ;
4. vérifier qu'aucune autre contribution n'est dupliquée.

**Scénario F — discipline vide :**

1. ouvrir Boxe vide ;
2. voir l'état vide spécifique ;
3. choisir Créer la première technique ;
4. créer Crochet gauche avec le workflow existant ;
5. revenir automatiquement dans Boxe ;
6. voir Crochet gauche dans la grille.

**Scénario G — retour et état :**

1. Judo ;
2. activer plusieurs filtres ;
3. faire défiler ;
4. ouvrir une fiche ;
5. revenir ;
6. retrouver filtres et position ;
7. aller dans Pratique ;
8. revenir dans Bibliothèque ;
9. retrouver le même état.

**Scénario H — bibliothèque totalement vide :**

1. démarrer sans discipline ;
2. voir Importer un pack et Créer une discipline ;
3. créer une discipline ;
4. arriver sur son état vide ;
5. ne jamais passer par un Accueil ou un onboarding.

## 17. Tests

Ajouter ou adapter les tests pour couvrir :

- disciplines uniques ;
- compte des identités et non des contributions ;
- recherche globale sans doublons ;
- recherche dans les contributions personnelles ;
- filtre par source ;
- labels de source éditoriaux ;
- absence d'identifiants internes dans l'interface ;
- cumul des filtres ;
- discipline vide ;
- création d'une première technique ;
- conservation des filtres et du scroll ;
- retour fiche → explorateur ;
- absence de régression sur l'import des deux packs Judo.

Ajouter un scénario E2E minimal :

```
installation vide
→ création Boxe
→ création Crochet gauche
→ apparition dans la grille
→ recherche
→ ouverture de la fiche
→ retour avec état conservé.
```

`npm run verifier` doit être vert.

Une vérification Android réelle reste obligatoire pour :

- défilement ;
- clavier ;
- retour ;
- position restaurée ;
- fluidité de la grille.

## 18. Documentation

Mettre à jour les documents existants uniquement.

`docs/workflows.md` :

- Bibliothèque vide ;
- Bibliothèque contenant plusieurs disciplines ;
- recherche globale ;
- exploration d'une discipline ;
- filtres cumulables ;
- filtre par source ;
- création de la première technique ;
- niveaux de démonstration réels.

`docs/systeme.md` :

- construction de la vue Bibliothèque ;
- source des compteurs ;
- règles de déduplication ;
- règles de libellé des sources ;
- état conservé par discipline.

Matrice de conservation :

- grille visuelle V2/V3 conservée ;
- filtres cumulables conservés ;
- packs retirés de la racine et transformés en filtres de source ;
- import/création retirés de la façade normale mais conservés dans les
  états vides et l'Atelier ;
- édition par vignette non reprise ;
- favoris préservés mais différés au lot Pratique.

`docs/etat.md` :

- lot terminé ;
- tests ;
- limites restantes ;
- prochain lot : fiche technique.

Ne pas documenter comme implémenté ce qui appartient encore aux lots
suivants.

## 19. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures de :
  - racine Bibliothèque ;
  - discipline avec grille et filtres ;
  - source sélectionnée ;
  - discipline vide ;
  - résultat de recherche globale.

Rapport compact :

- fichiers modifiés ;
- règles de discipline/source appliquées ;
- champs indexés par la recherche ;
- comportement des filtres ;
- état conservé ;
- adaptations minimales faites pour créer la première technique ;
- anomalies hors périmètre.

N'anticipe pas le lot Fiche technique.

Ne refonds pas les médias, la capture, les compositions, l'Atelier ou le
modèle métier dans ce lot.

**La réussite de ce lot se mesure à une chose : un utilisateur peut entrer
dans sa bibliothèque, comprendre ce qu'il possède, retrouver une technique
sans doublons et commencer une discipline vide sans rencontrer d'impasse.**

---

> **Statut** : texte du LOT 2 reçu **intégralement** (session 22,
> 2026-07-12). Le lot est **spécifié en entier** — reste en attente d'un
> **GO explicite** de Yahya avant toute exécution.

---

# LOT 3 — FICHE TECHNIQUE : CONSULTER, COMPRENDRE ET ENRICHIR UNE TECHNIQUE

## Contexte

Le lot 1 a mis en place une navigation à trois onglets :

- Bibliothèque ;
- Pratique ;
- Atelier.

Le lot 2 a fait de la Bibliothèque le centre d'exploration :

- disciplines uniques ;
- recherche globale ;
- grille visuelle ;
- filtres cumulables ;
- filtres par source ;
- création d'une première technique dans une discipline vide.

La fiche technique actuelle possède de bonnes fondations :

- identité technique commune ;
- contributions séparées par provenance ;
- média principal ;
- carnet personnel ;
- relations ;
- compositions utilisant la technique ;
- édition contextuelle partielle.

Cependant, l'expérience actuelle reste insatisfaisante :

- le média n'est pas toujours suffisamment dominant ;
- la succession verticale des voix, relations et actions produit un écran
  long ;
- des libellés techniques ou génériques comme « Club » ne donnent pas
  clairement l'autorité réelle ;
- l'utilisateur doit parfois passer par `Capturer` pour modifier un simple
  commentaire personnel ;
- l'édition ne rend pas toujours explicite ce qui est modifiable et
  pourquoi ;
- le workflow d'ajout de plusieurs vidéos n'est pas visible ;
- `Retirer` et `Terminer` sont exposés comme des actions normales alors
  qu'ils ne le sont pas ;
- les relations prennent trop de place ou reposent sur un vocabulaire
  difficile à comprendre ;
- les compositions utilisant la technique ne disposent pas encore d'un
  accès compact et naturel.

Ce lot porte **exclusivement** sur la fiche technique et ses actions
directement liées :

- consultation ;
- hiérarchie visuelle ;
- médias ;
- voix et sources ;
- contribution personnelle ;
- édition contextuelle ;
- relations compactes ;
- compositions utilisant la technique ;
- actions secondaires et destructrices.

Il ne refond pas :

- le workflow global de capture non rattachée ;
- le modèle physique des médias ;
- le modèle des relations ;
- le modèle des compositions ;
- l'Atelier ;
- la sécurité et le PIN ;
- la publication des packs ;
- la direction graphique globale de toute l'application.

## Objectif unique

Produire une fiche technique immédiatement utile pendant la pratique,
permettant de :

1. voir et lire le média principal sans défiler ;
2. identifier la technique et ses classifications essentielles ;
3. comprendre qui affirme quoi ;
4. consulter les différentes voix sans les mélanger ;
5. modifier directement ses propres contenus ;
6. ajouter plusieurs médias à la technique ;
7. accéder aux relations et compositions sans créer un mur vertical ;
8. protéger les contenus sourcés et les actions destructrices.

## 1. Structure générale de la fiche

La fiche doit suivre cette hiérarchie :

1. en-tête compact ;
2. média principal ;
3. informations essentielles ;
4. voix et contenus ;
5. accès compact aux relations et compositions ;
6. actions secondaires.

L'utilisateur ne doit pas traverser de longs blocs textuels avant
d'atteindre la vidéo.

Éviter une structure constituée uniquement d'une succession de grandes
cartes arrondies.

La fiche doit rester lisible :

- sur téléphone en portrait ;
- sur tablette ;
- avec ou sans média ;
- avec une seule voix ;
- avec plusieurs voix ;
- avec ou sans contribution personnelle ;
- avec ou sans relations ;
- avec ou sans composition associée.

## 2. En-tête

L'en-tête contient :

- bouton retour ;
- nom principal de la technique ;
- nom traditionnel ou appellation secondaire lorsqu'il existe ;
- action secondaire compacte de type menu `⋮`.

Ne pas afficher dans l'en-tête :

- un bouton `Retirer` ;
- un bouton `Terminer` ;
- un bouton global `Capturer` ;
- plusieurs icônes d'administration alignées sans libellé.

Le retour doit restaurer exactement l'état de l'explorateur :

- filtres ;
- recherche ;
- source sélectionnée ;
- position de défilement.

Le menu secondaire peut contenir selon les droits :

- Modifier les informations générales ;
- Partager ou exporter ;
- Gérer les médias ;
- Retirer de la bibliothèque.

Les actions non disponibles ne doivent pas apparaître comme actives.

## 3. Média principal en tête

Afficher le média principal immédiatement sous l'en-tête.

Il doit être visible sans défilement significatif sur un téléphone
standard.

Le composant média doit gérer :

- vidéo locale ;
- vidéo de plateforme ;
- image ou miniature ;
- absence de média ;
- erreur de lecture ;
- média local manquant.

Afficher sous le média une légende compacte indiquant :

- source ou auteur ;
- provenance ;
- éventuellement le libellé du média.

Exemples :

```
Vidéo Kodokan · Référentiel officiel
Démonstration de Sensei Martin · Enseignement
Ma vidéo · Personnel
```

Ne pas afficher uniquement :

- `Club` ;
- `Référentiel` ;
- `Source externe` ;

lorsqu'un nom éditorial plus précis existe.

En cas d'absence de média principal :

- afficher un fallback discret ;
- proposer une action `Ajouter un média` si l'utilisateur possède les
  droits nécessaires ;
- ne pas afficher un grand rectangle vide sans explication.

## 4. Choix du média principal

La fiche doit permettre de consulter les autres médias associés.

Sous le média principal, afficher un accès compact :

- miniatures horizontales ;
- compteur `3 médias` ;
- ou bouton `Voir les médias`.

Ne pas afficher toutes les vidéos en pleine taille les unes sous les
autres.

L'utilisateur doit pouvoir :

- ouvrir un autre média ;
- voir sa source et sa provenance ;
- le lire ;
- revenir au média principal ;
- définir comme média principal un média qu'il maîtrise, selon les règles
  existantes ;
- ajouter un nouveau média.

Ne pas modifier dans ce lot les règles internes de stockage ou de
propriété.

Si le choix du média principal est global à l'identité, rendre
explicitement visible l'effet de l'action :

`Utiliser comme aperçu principal de cette technique`

Ne pas laisser croire que cela modifie le média officiel d'un pack source.

Si le comportement actuel permet à un pack importé de remplacer
silencieusement le média principal, tracer le risque et empêcher l'action
silencieuse dans l'interface.

## 5. Ajouter un média depuis la fiche

Ajouter une action clairement visible :

`Ajouter un média`

Elle doit être accessible :

- sous le média principal ;
- ou dans la galerie des médias ;
- ou dans le menu secondaire.

Elle ne doit pas nécessiter de quitter la fiche pour lancer un flux
générique `Capturer`.

Le workflow doit proposer selon les capacités existantes :

- Filmer maintenant ;
- Choisir une vidéo ou un fichier de l'appareil ;
- Coller un lien ;
- éventuellement choisir un média déjà présent dans la bibliothèque si
  cette capacité existe réellement.

Après ajout :

- le média apparaît immédiatement dans la galerie ;
- l'utilisateur voit la provenance et l'auteur appliqués ;
- le média peut être choisi comme principal ;
- le retour reste sur la fiche.

Si une information est nécessaire, poser uniquement les questions
utiles :

- qui a produit ce média ?
- quelle nature de contribution ?
- quel libellé facultatif ?

Ne pas demander à nouveau la technique : la fiche ouverte la détermine
déjà.

## 6. Informations essentielles

Sous le média, afficher de manière compacte :

- discipline ;
- familles ou catégories ;
- niveaux ;
- alias ou appellations utiles ;
- éventuelle pluralité des voix.

Ne pas afficher des identifiants techniques.

Ne pas afficher toutes les métadonnées du modèle dans la vue principale.

Les niveaux et taxonomies utilisent les données réelles :

- libellés ;
- ordre ;
- couleurs lorsqu'elles existent.

L'utilisateur doit pouvoir ouvrir une édition contextuelle des
informations générales lorsqu'il possède les droits nécessaires.

Cette édition porte uniquement sur les propriétés réellement modifiables
au niveau de l'identité ou de son propre corpus.

Ne pas permettre de réécrire silencieusement les informations
appartenant à un référentiel importé.

## 7. Voix et contributions

La fiche doit rendre perceptible le principe :

**Une technique, plusieurs voix.**

Cependant, elle ne doit pas afficher toutes les contributions sous forme
de grandes cartes intégralement ouvertes.

Présenter les voix dans une zone compacte, par exemple :

- liste repliable ;
- onglets ;
- accordéon ;
- sélecteur de source ;
- aperçu suivi de `Lire la suite`.

Une seule voix peut être ouverte à la fois par défaut.

Ordre recommandé :

1. voix correspondant au média principal ou à la source sélectionnée
   depuis la Bibliothèque ;
2. référentiel ;
3. enseignement ;
4. ressource ;
5. personnel.

Cet ordre peut être adapté si les données ou le contexte indiquent une
meilleure hiérarchie.

Chaque voix affiche au minimum :

- auteur ou organisation ;
- nom éditorial de la source ;
- provenance ;
- texte ou points clés ;
- médias propres à cette contribution ;
- possibilité de modification uniquement lorsque l'utilisateur la
  maîtrise.

Ne pas utiliser le seul mot `Club` comme titre lorsque le nom du club ou
du pack est disponible.

Exemples :

```
Enseignement · Judo Club de Castres
Référentiel · Kodokan
Ressource · Jean Dupont
Personnel · Moi
```

## 8. Modification des voix

Une contribution sourcée importée reste protégée.

L'utilisateur ne modifie pas directement :

- une contribution Kodokan importée ;
- une contribution fédérale ;
- une contribution issue d'un pack tiers non maîtrisé.

Il peut :

- ajouter sa propre contribution ;
- ajouter une contribution de club ou de sensei s'il en est le curateur ;
- créer une adaptation distincte ;
- masquer localement un contenu si cette capacité existe déjà ;
- corriger les métadonnées qu'il maîtrise.

L'interface doit expliquer la règle sans jargon.

Exemple :

```
Ce contenu vient du pack Kodokan et n'est pas modifiable ici.
Tu peux ajouter une note ou une contribution distincte.
```

Ne pas désactiver silencieusement un champ sans explication.

## 9. Mon carnet

`Mon carnet` est une zone personnelle directement éditable depuis la
fiche.

L'utilisateur ne doit pas être obligé de lancer `Capturer` pour :

- ajouter un mot ;
- saisir une phrase ;
- corriger son commentaire ;
- effacer une note personnelle.

Comportement attendu :

- état vide : `Ajouter un repère personnel` ;
- état rempli : texte visible avec action d'édition discrète ;
- appui : édition directe ou panneau léger ;
- sauvegarde : automatique ou action `Enregistrer` clairement localisée ;
- annulation : comportement explicite.

Le texte peut être :

- un mot ;
- un moyen mnémotechnique ;
- une phrase ;
- une explication développée.

Ne pas imposer :

- deux lignes ;
- une taxonomie ;
- un type `note`, `repère` ou `commentaire`.

Le stockage reste une contribution personnelle selon le modèle actuel.

Le texte personnel doit rester indexé par la recherche de la
Bibliothèque.

La suppression du texte personnel ne supprime jamais la technique.

## 10. Édition contextuelle

Distinguer clairement trois types d'édition.

**A. Informations générales de l'identité**

Exemples :

- nom local ;
- nom traditionnel ;
- familles ;
- niveaux ;
- média principal.

Accessible uniquement selon les droits et les règles du modèle.

**B. Contribution maîtrisée**

Exemples :

- texte du club ;
- points clés du sensei ;
- média d'une contribution locale ;
- attribution.

**C. Contenu personnel**

Exemples :

- note ;
- repère ;
- média personnel.

L'interface ne doit pas présenter un unique grand formulaire mélangeant
ces trois responsabilités.

Privilégier :

- édition au point d'usage ;
- panneaux ciblés ;
- formulaires courts ;
- sauvegarde explicite uniquement lorsque nécessaire.

Ne pas placer un crayon sur chaque carte de la Bibliothèque.

La fiche est le point d'entrée principal de l'édition contextuelle.

## 11. Relations

Les relations restent visibles, mais dans une zone compacte.

Afficher par exemple :

```
Relations · 6
```

avec un aperçu limité :

- 2 ou 3 relations ;
- nom de la relation ;
- technique cible ;
- flèche ou direction compréhensible.

Une action `Voir toutes les relations` ouvre :

- un panneau ;
- une sous-vue ;
- ou une section développée.

Ne pas afficher toutes les relations en pleine longueur en bas de fiche.

Chaque relation doit montrer :

- libellé utilisateur ;
- direction ;
- technique cible ;
- éventuelle source ou auteur lorsque disponible.

Ne pas afficher les identifiants internes des types de relation.

Toucher une technique liée ouvre sa fiche.

Le bouton retour revient à la fiche précédente sans perdre le contexte.

Ne pas modifier le modèle des types de relation dans ce lot.

Ne pas créer de nouvelles relations automatiques.

## 12. Compositions utilisant la technique

Afficher un accès compact :

```
Utilisée dans · 3 compositions
```

L'aperçu peut montrer :

- nom des compositions ;
- position ou contexte lorsque disponible ;
- type éditorial facultatif si le modèle le porte déjà.

Toucher une composition ouvre sa consultation dans l'onglet Pratique.

Le retour revient à la fiche technique.

Ne pas afficher toutes les étapes des compositions sur la fiche.

Ne pas confondre :

- relations du graphe ;
- transitions dans une composition ;
- présence de la technique dans une composition.

Si aucune composition n'utilise la technique, la section peut être
absente.

Ne pas ajouter depuis cette zone un workflow complexe de création de
composition dans ce lot.

## 13. Favoris

Si le modèle de favoris existe déjà, permettre depuis la fiche :

- ajouter aux favoris ;
- retirer des favoris.

L'action doit être simple et immédiatement compréhensible.

Elle ne doit pas modifier la technique elle-même.

Les favoris seront organisés dans l'onglet Pratique lors du lot
correspondant.

Si le modèle de favoris n'existe pas encore :

- ne pas le créer dans ce lot ;
- ne pas afficher un bouton factice ;
- tracer le besoin pour le lot Pratique.

## 14. Partage et export de la technique

Si le workflow actuel permet réellement l'export d'une technique :

- rendre l'action accessible dans le menu secondaire ;
- utiliser un libellé explicite : `Exporter cette technique` ou `Partager
  cette technique`.

Avant export, indiquer ce qui sera inclus :

- identité ;
- contributions sélectionnées ;
- médias ;
- carnet personnel ou non.

Le carnet personnel ne doit jamais être partagé par défaut.

Si le workflow V3 ne permet pas encore une exportation sûre à cette
granularité :

- ne pas créer un bouton qui promet plus que ce qui existe ;
- tracer la capacité comme différée ;
- ne pas modifier le format `.movpack` dans ce lot.

## 15. Action de retrait

`Retirer` ne doit jamais apparaître comme action principale à côté de
l'édition.

La placer dans :

- menu secondaire ;
- section danger ;
- ou écran de gestion approprié.

Le libellé doit expliquer précisément l'effet.

Exemples selon le comportement réel :

```
Retirer cette technique de ma bibliothèque
Supprimer uniquement mon contenu personnel
Retirer les contenus issus de cette source
```

Ne pas employer un terme ambigu si l'action peut :

- détacher des notes ;
- supprimer une identité ;
- supprimer des médias ;
- affecter des compositions ;
- retirer une contribution importée.

Avant confirmation, afficher :

- les données concernées ;
- les compositions ou relations impactées ;
- l'existence d'une sauvegarde automatique ;
- le comportement de restauration.

Toute action destructive doit respecter les protections existantes :

- confirmation ;
- snapshot ou sauvegarde préalable ;
- absence de suppression silencieuse ;
- refus si l'opération est incohérente.

Ne pas refondre le PIN dans ce lot.

## 16. Suppression du bouton `Terminer`

Supprimer `Terminer` de la fiche stable.

Ce libellé n'a de sens que dans un workflow temporaire.

Utiliser selon le contexte :

- Enregistrer ;
- Annuler ;
- Fermer ;
- retour automatique après sauvegarde.

Si l'édition est inline avec sauvegarde automatique, afficher une
confirmation discrète :

```
Enregistré
```

Ne pas ajouter un bouton de validation permanent en bas de la fiche de
consultation.

## 17. États particuliers

**A. Technique avec une seule voix et aucun média**

- nom ;
- informations essentielles ;
- fallback média ;
- voix unique ;
- action d'ajout selon les droits.

**B. Technique à plusieurs voix**

- une seule identité ;
- média principal ;
- sélecteur de voix ;
- sources claires ;
- aucune duplication du nom ou de la fiche.

**C. Technique personnelle uniquement**

- ne pas la présenter comme un référentiel ;
- permettre modification complète des contenus maîtrisés.

**D. Média local manquant**

- expliquer le problème ;
- ne pas afficher un lecteur cassé sans message ;
- proposer selon les capacités : remplacer ; retirer la référence ;
  ouvrir le diagnostic dans l'Atelier.

**E. Technique utilisée dans une composition**

- empêcher une suppression silencieuse ;
- informer des dépendances.

**F. Contribution sans auteur explicite**

- utiliser un fallback lisible ;
- ne jamais afficher `undefined`, UUID ou slug brut.

## 18. Accessibilité et ergonomie

Les actions principales doivent avoir :

- libellé accessible ;
- zone tactile suffisante ;
- retour visuel ;
- contraste correct.

Ne pas reposer uniquement sur :

- une couleur de provenance ;
- une icône sans texte ;
- un filet coloré ;
- une position visuelle.

Les sections repliables doivent indiquer :

- état ouvert ou fermé ;
- titre ;
- nombre d'éléments lorsque pertinent.

Le lecteur vidéo doit être accessible au clavier sur web et utilisable au
toucher sur Android.

Les textes longs doivent rester lisibles sans largeur excessive sur
tablette.

## 19. Conservation de l'état

La fiche conserve pendant la session :

- voix ouverte ;
- média sélectionné ;
- position de défilement si l'utilisateur ouvre temporairement une
  relation ou composition ;
- état d'édition non enregistré lorsque le système le permet.

Retour vers la Bibliothèque :

- restaure l'explorateur ;
- ne réinitialise pas les filtres ;
- ne recharge pas inutilement les médias.

Navigation vers une technique liée puis retour :

- revient à la fiche précédente ;
- conserve le média et la voix précédemment consultés.

## 20. Performance

Ne pas charger toutes les vidéos en mémoire à l'ouverture de la fiche.

Charger :

- métadonnées ;
- miniatures ;
- média sélectionné lorsque nécessaire.

Ne pas instancier plusieurs lecteurs vidéo actifs simultanément.

Les voix repliées ne doivent pas déclencher inutilement le chargement de
tous leurs médias.

Ne pas modifier le stockage OPFS dans ce lot.

## 21. Limites strictes du lot

Ne pas modifier :

- le modèle métier identité/contribution ;
- le rapprochement inter-packs ;
- le modèle physique des médias ;
- le format `.movpack` ;
- les compositions ;
- les types de relation ;
- la sécurité et le PIN ;
- la publication ;
- la Bibliothèque ;
- l'architecture détaillée de l'Atelier ;
- la direction graphique globale de l'application.

Les adaptations autorisées concernent uniquement :

- présentation de la fiche ;
- actions contextuelles ;
- galerie des médias ;
- édition des contenus déjà supportés ;
- ajout de médias via les services existants ;
- navigation vers relations et compositions ;
- clarification des actions destructrices.

Toute faiblesse du modèle identifiée doit être documentée, pas corrigée
silencieusement dans ce lot.

## 22. Critères d'acceptation

**Scénario A — consultation immédiate**

1. ouvrir une technique depuis la Bibliothèque ;
2. voir le média principal sans défiler ;
3. lire son origine ;
4. voir le nom, l'appellation et les niveaux ;
5. revenir ;
6. retrouver l'explorateur inchangé.

**Scénario B — plusieurs voix**

1. ouvrir Harai-goshi ;
2. voir une seule fiche ;
3. identifier clairement Kodokan et le club ;
4. ouvrir chaque voix ;
5. vérifier que les contenus ne sont pas fusionnés ;
6. ne voir aucun identifiant technique de pack.

**Scénario C — carnet personnel**

1. ouvrir une technique sans note personnelle ;
2. choisir Ajouter un repère personnel ;
3. saisir `coup de volant` ;
4. enregistrer sans passer par Capturer ;
5. revenir dans la Bibliothèque ;
6. rechercher `coup de volant` ;
7. retrouver la technique ;
8. réouvrir et modifier directement le texte.

**Scénario D — plusieurs médias**

1. ouvrir une fiche ;
2. voir le média principal ;
3. choisir Ajouter un média ;
4. ajouter un lien ;
5. ajouter une vidéo locale ou filmer ;
6. voir les deux médias dans la galerie ;
7. lire chacun ;
8. choisir l'un comme média principal ;
9. revenir après relance et retrouver le choix.

**Scénario E — contribution protégée**

1. ouvrir une voix Kodokan ;
2. constater qu'elle n'est pas directement modifiable ;
3. comprendre pourquoi ;
4. ajouter une contribution personnelle distincte ;
5. vérifier que la source originale reste intacte.

**Scénario F — relations**

1. ouvrir une technique possédant plusieurs relations ;
2. voir un aperçu compact ;
3. ouvrir toutes les relations ;
4. naviguer vers une technique liée ;
5. revenir à la fiche d'origine.

**Scénario G — compositions**

1. ouvrir une technique utilisée dans `Ma spéciale` ;
2. voir `Utilisée dans · 1` ;
3. ouvrir la composition ;
4. revenir ;
5. retrouver la fiche dans son état précédent.

**Scénario H — retrait**

1. ouvrir le menu secondaire ;
2. choisir l'action destructive ;
3. lire précisément ce qui sera retiré ;
4. annuler sans modification ;
5. recommencer et confirmer ;
6. vérifier la sauvegarde préalable ;
7. vérifier l'absence de suppression incohérente.

**Scénario I — média manquant**

1. simuler ou utiliser une référence locale absente ;
2. ouvrir la fiche ;
3. voir un état explicite ;
4. accéder à une action de résolution ;
5. ne pas avoir de lecteur cassé silencieux.

## 23. Tests

Ajouter ou adapter les tests pour couvrir :

- média principal en tête ;
- fallback sans média ;
- libellé de source éditorial ;
- plusieurs voix sur une seule identité ;
- protection d'une contribution importée ;
- édition directe du carnet personnel ;
- recherche après modification du carnet ;
- ajout de plusieurs médias ;
- choix du média principal ;
- galerie sans duplication ;
- relations compactes ;
- navigation vers une technique liée ;
- compositions utilisant la technique ;
- menu destructif ;
- suppression du bouton `Terminer` ;
- absence de bouton global `Capturer` sur la fiche ;
- retour vers l'explorateur avec état conservé.

Ajouter un scénario E2E vertical :

```
import Kodokan + club
→ ouvrir une technique réunie
→ consulter les deux voix
→ ajouter un repère personnel
→ ajouter un média
→ choisir le média principal
→ naviguer vers une relation
→ revenir
→ ouvrir une composition utilisatrice
→ revenir
→ vérifier que tout est conservé.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- lecteur vidéo ;
- capture caméra ;
- sélection d'un fichier ;
- clavier et édition du carnet ;
- galerie horizontale ;
- retour Android ;
- absence de chevauchement avec la barre basse.

## 24. Documentation

Mettre à jour les documents existants uniquement.

`docs/workflows.md` :

- consultation d'une technique ;
- changement de voix ;
- ajout d'un repère personnel ;
- ajout de plusieurs médias ;
- choix du média principal ;
- navigation par relations ;
- navigation vers une composition ;
- retrait sécurisé ;
- niveaux de démonstration réels.

Ajouter un schéma Mermaid compact :

```
Bibliothèque
→ Fiche
→ Média principal
→ Voix
→ Carnet personnel
→ Relations / Compositions
→ Retour Bibliothèque
```

`docs/systeme.md` :

- construction de la fiche ;
- responsabilité des composants ;
- sélection du média principal ;
- règles d'édition selon la maîtrise de la contribution ;
- chargement différé des médias ;
- navigation contextuelle.

Matrice de conservation :

- vidéo en tête V2 conservée ;
- plusieurs médias V2 conservés ;
- voix V3 conservées ;
- édition directe du carnet ajoutée ;
- formulaire monolithique V2 non repris ;
- longue liste de relations V2 transformée en accès compact ;
- actions destructrices déplacées ;
- `Terminer` supprimé avec justification.

`docs/etat.md` :

- lot terminé ;
- tests ;
- limites restantes ;
- éventuelles faiblesses du modèle révélées mais non corrigées ;
- prochain lot : création, capture et édition.

## 25. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures montrant :
  - fiche avec média principal ;
  - fiche à plusieurs voix ;
  - édition directe de Mon carnet ;
  - galerie avec plusieurs médias ;
  - relations compactes ;
  - compositions utilisant la technique ;
  - menu secondaire avec action destructive.

Rapport compact :

- fichiers modifiés ;
- hiérarchie finale de la fiche ;
- règles de choix et d'affichage du média principal ;
- règles de modification selon la source ;
- workflow d'ajout de médias ;
- comportement de Mon carnet ;
- comportement du retour ;
- anomalies découvertes hors périmètre.

N'anticipe pas le lot Création, capture et édition globale.

Ne refonds pas le stockage des médias, le modèle des compositions, les
relations, la sécurité ou l'Atelier.

**La réussite de ce lot se mesure à une chose : un pratiquant ouvre une
technique, voit immédiatement le geste, comprend qui lui parle, enrichit
directement ce qu'il maîtrise et accède au reste sans traverser un mur de
texte.**

---

> **Statut** : texte du LOT 3 reçu **intégralement** (session 22,
> 2026-07-12). Le lot est **spécifié en entier** — reste en attente d'un
> **GO explicite** de Yahya avant toute exécution.

---

# LOT 4 — CRÉATION, CAPTURE ET ÉDITION : AJOUTER DU SAVOIR SANS FORMULAIRE MONOLITHIQUE

## Contexte

Le lot 1 a installé trois destinations principales :

- Bibliothèque ;
- Pratique ;
- Atelier.

Le lot 2 a rendu la Bibliothèque exploitable :

- disciplines uniques ;
- recherche globale ;
- grille visuelle ;
- filtres cumulables ;
- sources ;
- discipline vide ;
- création d'une première technique.

Le lot 3 a refondu la fiche technique :

- média principal en tête ;
- voix distinctes ;
- contribution personnelle directement éditable ;
- plusieurs médias ;
- édition contextuelle ;
- relations et compositions compactes ;
- actions destructrices déplacées.

La V3 possède actuellement plusieurs flux qui se chevauchent :

- créer une technique ;
- filmer ;
- choisir une vidéo ;
- coller un lien ;
- écrire un mot ;
- rattacher à une technique ;
- créer une contribution ;
- modifier une fiche.

Ces flux exposent encore parfois le modèle métier à l'utilisateur :

- demande de rattachement alors qu'aucune technique n'existe ;
- sélection de provenance ou d'auteur trop tôt ;
- formulaire trop long pour conserver une simple vidéo ;
- passage obligatoire par `Capturer` pour modifier une fiche connue ;
- création d'une technique, d'une contribution et d'un média confondues ;
- bouton global dont le sens varie selon l'écran.

Ce lot doit produire des workflows complets, distincts et cohérents pour :

1. créer une technique connue ;
2. capturer rapidement quelque chose pendant l'entraînement ;
3. rattacher immédiatement ou plus tard ;
4. créer une technique à partir d'une capture ;
5. modifier un contenu existant sans relancer le flux de capture.

## Objectif unique

Permettre à un utilisateur de créer, capturer, rattacher et modifier du
contenu sans impasse, sans formulaire monolithique et sans devoir
comprendre les objets internes de Movenso.

Le parcours doit notamment permettre :

- création minimale d'une technique ;
- capture d'une vidéo, d'un fichier, d'un lien ou d'un texte ;
- classement immédiat facultatif ;
- conservation comme brouillon à structurer ;
- création d'une technique depuis une capture ;
- contribution personnelle par défaut ;
- contribution d'enseignement ou de ressource sur choix explicite ;
- reprise et finalisation ultérieures ;
- absence de fichiers ou données orphelins après annulation ou échec.

## 1. Distinction des trois intentions

L'interface doit distinguer trois intentions.

**A. Créer une technique**

L'utilisateur sait ce qu'il veut ajouter au corpus.

Exemple : Créer `Crochet gauche` dans Boxe.

Résultat :

- une identité technique existe ;
- elle apparaît dans la Bibliothèque ;
- elle peut être enrichie immédiatement ou plus tard.

**B. Capturer quelque chose**

L'utilisateur veut conserver rapidement :

- une vidéo ;
- un fichier ;
- un lien ;
- un mot ou un commentaire.

Il ne sait pas nécessairement :

- le nom exact de la technique ;
- si la technique existe déjà ;
- comment la classifier ;
- si ce contenu deviendra personnel, club ou ressource.

Résultat possible :

- rattachement à une technique existante ;
- création d'une nouvelle technique ;
- conservation dans `À reprendre`.

**C. Modifier une technique ou contribution existante**

L'utilisateur connaît déjà la destination.

Exemples :

- corriger son commentaire personnel ;
- ajouter une seconde vidéo ;
- modifier un enseignement local ;
- corriger le nom ou les niveaux d'une technique qu'il maîtrise.

Ce parcours reste contextuel à la fiche et ne doit pas relancer le flux
générique de capture.

Ne pas présenter ces trois intentions comme une seule opération
`Capturer`.

## 2. Points d'entrée

Aucun bouton global permanent `Capturer` ne doit réapparaître dans le
shell.

**Bibliothèque — racine**

Prévoir une action contextuelle `Ajouter`.

Elle peut ouvrir un panneau compact contenant :

- Créer une technique ;
- Filmer ou garder quelque chose.

Si aucune discipline n'existe :

- `Créer une technique` commence par le choix ou la création d'une
  discipline ;
- `Filmer ou garder quelque chose` permet une capture sans discipline, à
  structurer plus tard.

**Bibliothèque — discipline ouverte**

Action contextuelle `Ajouter` ou `+`.

Options :

- Nouvelle technique ;
- Filmer maintenant ;
- Choisir un média ;
- Coller un lien ;
- Ajouter un repère.

La discipline ouverte est préselectionnée.

**Fiche technique**

Les actions sont locales :

- Ajouter un média ;
- Ajouter ou modifier mon repère ;
- Ajouter une contribution ;
- Modifier ce que je maîtrise.

Ne pas redemander la discipline ou la technique.

**Pratique**

Les captures personnelles non rattachées peuvent apparaître dans
`À reprendre`.

Ne pas ajouter dans ce lot un nouveau bouton global de capture dans
Pratique.

**Atelier**

Aucune action de capture générique.

L'Atelier pourra ultérieurement traiter les contenus à vérifier ou à
publier.

## 3. Panneau contextuel `Ajouter`

Le panneau `Ajouter` doit être court et orienté vers les gestes.

Exemple dans une discipline :

```
Que veux-tu ajouter ?

- Une technique
- Filmer maintenant
- Une vidéo ou un fichier
- Un lien
- Un mot ou commentaire
```

Ne pas afficher dans ce premier panneau :

- identité ;
- contribution ;
- provenance ;
- origine ;
- pack ;
- manifeste ;
- média plateforme.

Les choix techniques sont déduits plus tard par l'application.

La fermeture du panneau ne modifie aucune donnée.

## 4. Création minimale d'une technique

Le workflow de création doit permettre de créer une technique avec le
minimum suivant :

- discipline ;
- nom.

Si le workflow est lancé depuis une discipline :

- discipline préselectionnée ;
- ne pas la redemander.

Si aucune discipline n'existe :

- permettre de créer la discipline dans le même parcours ;
- revenir ensuite à la création de la technique ;
- ne pas perdre les informations déjà saisies.

Champs immédiatement visibles :

- Nom de la technique — obligatoire ;
- Appellation traditionnelle ou secondaire — facultative.

Classification facultative :

- famille ou catégorie ;
- niveau ;
- autres taxonomies existantes.

Ces informations doivent être dans une section facultative
`Classer maintenant` avec possibilité explicite `Je le ferai plus tard`.

Ne pas empêcher la création si aucune famille ou aucun niveau n'existe.

Après création, proposer sans imposer :

- Ajouter un média ;
- Ajouter une explication ;
- Ouvrir la fiche.

Le résultat par défaut est :

- création ;
- ouverture de la fiche ;
- technique immédiatement visible dans la discipline.

## 5. Prévention des doublons

Pendant la saisie du nom, rechercher les identités existantes dans la
même discipline.

Afficher des suggestions compactes :

```
Technique similaire déjà présente :
- Seoi-nage
- Morote-seoi-nage
```

Actions possibles :

- Utiliser cette technique ;
- Créer quand même une technique distincte.

Ne jamais fusionner automatiquement sur une simple ressemblance.

Si le nom normalisé correspond exactement à une identité unique :

- recommander de l'ouvrir ou de lui ajouter une contribution ;
- permettre la création séparée uniquement après confirmation explicite.

Si plusieurs correspondances sont ambiguës :

- ne prendre aucune décision silencieuse ;
- présenter les candidats ;
- laisser l'utilisateur choisir.

Ne pas modifier le moteur de rapprochement dans ce lot.

## 6. Capture rapide

Le workflow de capture rapide doit commencer par le contenu, pas par les
métadonnées.

**A. Filmer maintenant**

1. demander l'autorisation caméra si nécessaire ;
2. filmer ;
3. afficher un aperçu ;
4. proposer : Utiliser ; Refilmer ; Abandonner.

**B. Choisir un média**

1. ouvrir le sélecteur système ;
2. choisir le fichier ;
3. afficher un aperçu ou ses métadonnées ;
4. proposer : Utiliser ; Choisir un autre fichier ; Abandonner.

**C. Coller un lien**

1. saisir ou coller l'URL ;
2. détecter le service lorsque possible ;
3. afficher un aperçu ou le domaine ;
4. conserver l'URL originale ;
5. proposer : Utiliser ; Modifier ; Abandonner.

**D. Ajouter un mot ou commentaire**

1. afficher un champ libre ;
2. accepter un seul mot comme un texte long ;
3. ne pas imposer de nombre de lignes ;
4. ne pas imposer de taxonomie.

Exemples de libellés :

- Un mot à toi peut suffire
- Ce que tu veux retrouver plus tard

Ne pas demander la technique avant que le contenu soit capturé.

## 7. Décision de rattachement

Après capture du contenu, poser une question simple :

`Sais-tu où le ranger ?`

Trois possibilités : Rattacher à une technique existante ; Créer une
nouvelle technique ; Garder pour plus tard.

**A. Technique existante**

- rechercher dans la discipline présélectionnée ;
- permettre d'élargir à toutes les disciplines ;
- montrer nom, discipline et miniature ;
- rattacher le contenu ;
- ouvrir la fiche ou revenir au contexte initial.

**B. Nouvelle technique**

- reprendre le workflow minimal de création ;
- conserver la capture en mémoire pendant le parcours ;
- préselectionner la discipline connue ;
- créer l'identité ;
- rattacher le contenu ;
- ouvrir la fiche.

**C. Garder pour plus tard**

- créer une capture non rattachée ;
- conserver le média ou le texte ;
- indiquer où elle sera retrouvée : `Pratique > À reprendre` ;
- ne pas obliger à choisir une discipline ;
- permettre facultativement d'ajouter un libellé court.

Ne jamais perdre une capture parce que l'utilisateur ne connaît pas
encore le nom de la technique.

## 8. Contenu personnel par défaut

Le comportement par défaut d'une capture rapide est :

- auteur : Moi ;
- provenance : Personnel.

Ne pas demander systématiquement : auteur ; organisation ; provenance ;
source.

Prévoir une action secondaire :

`Ce contenu vient de quelqu'un d'autre`

Elle ouvre des choix simples :

- Enseignement d'un professeur ou d'un club ;
- Ressource externe ;
- Référentiel ou source officielle, uniquement si l'utilisateur possède
  réellement ce rôle de curation.

En cas d'enseignement, demander uniquement ce qui est nécessaire : nom du
professeur, du club ou de l'auteur ; commentaire facultatif.

En cas de ressource : auteur ou organisation ; lien ou attribution si
nécessaire.

Ne pas utiliser le nom du pack comme auteur par défaut.

Ne pas qualifier automatiquement une vidéo filmée sur le tatami comme
personnelle si l'utilisateur indique qu'elle montre l'enseignement du
professeur.

## 9. Capture non rattachée

Une capture non rattachée doit conserver :

- son identifiant ;
- type de contenu ;
- média ou texte ;
- date ;
- auteur ;
- provenance ;
- éventuelle discipline présélectionnée ;
- éventuel libellé ;
- état : à reprendre.

Elle ne doit pas créer une fausse technique vide.

Dans `Pratique > À reprendre`, l'utilisateur doit pouvoir :

- ouvrir la capture ;
- la lire ou la consulter ;
- la rattacher à une technique existante ;
- créer une technique ;
- modifier son libellé ou son texte personnel ;
- supprimer la capture avec confirmation.

Si le contenu n'est pas personnel mais relève d'un enseignement ou d'une
ressource :

- conserver la provenance choisie ;
- ne pas publier automatiquement ;
- permettre sa reprise ultérieure.

La réorganisation définitive de `À reprendre` appartient au lot Pratique,
mais le workflow doit déjà fonctionner.

## 10. Créer une technique à partir d'une capture

Ce parcours doit être atomique du point de vue utilisateur :

```
capture
→ nouvelle technique
→ rattachement
→ fiche.
```

Si la création échoue :

- la capture reste disponible ;
- aucun fichier média ne disparaît ;
- aucune identité partielle ne reste visible.

Si le rattachement échoue après création :

- proposer de réessayer ;
- conserver la technique et la capture dans un état cohérent ;
- ne pas dupliquer le fichier au prochain essai.

Si l'utilisateur annule la création :

- revenir au choix : rattacher ; garder pour plus tard ; abandonner.

## 11. Ajout de contribution à une technique existante

Depuis une fiche, permettre `Ajouter une contribution`.

Ce parcours est distinct de `Mon carnet`.

Exemples :

- enseignement du club ;
- explication du sensei ;
- ressource externe ;
- contribution personnelle plus développée.

Questions minimales :

1. De qui vient ce contenu ?
2. Que veux-tu ajouter ? (texte ; média ; texte et média)
3. Attribution facultative ou obligatoire selon le cas.

La technique ouverte est déjà connue.

Ne pas demander : discipline ; technique ; pack cible ; identifiant de
source.

Une contribution ajoutée par l'utilisateur ne modifie jamais une
contribution importée.

## 12. Édition d'une technique existante

Les opérations d'édition doivent réutiliser les composants ciblés du
lot 3.

**A. Modifier les informations générales**

- nom ; appellation ; familles ; niveaux ; média principal.

**B. Modifier une contribution maîtrisée**

- texte ; auteur ; attribution ; médias de cette contribution.

**C. Modifier son carnet**

- édition directe ; aucun assistant complet.

**D. Gérer les médias**

- ajouter ; retirer une référence maîtrisée ; changer le média principal ;
  modifier un libellé.

Ne pas réintroduire un formulaire unique comportant tous les champs du
modèle.

Ne pas obliger l'utilisateur à parcourir toutes les étapes lorsqu'il
corrige un seul champ.

## 13. Classification progressive

Une technique peut être créée sans : famille ; niveau ; description ;
média ; contribution longue.

L'application doit accepter cette incomplétude.

Elle peut signaler dans l'Atelier : technique sans famille ; technique
sans niveau ; technique sans média ; technique sans source claire.

Mais elle ne bloque pas la création.

Depuis la fiche ou l'Atelier, l'utilisateur peut enrichir progressivement.

Ne pas afficher des alertes anxiogènes pendant le geste de capture.

## 14. Gestion des médias pendant le flux

Utiliser les services de stockage existants.

Le workflow doit éviter :

- duplication d'un même fichier après double clic ;
- fichier orphelin après annulation ;
- référence enregistrée sans fichier ;
- perte après fermeture intempestive ;
- média ajouté deux fois après réessai.

Pendant une capture :

- utiliser un état temporaire jusqu'à confirmation ;
- ne rattacher définitivement qu'après validation ;
- nettoyer l'état temporaire après abandon lorsque cela est possible ;
- conserver une capture récupérable si l'écriture physique a réussi mais
  que le rattachement échoue.

Ne pas refondre dans ce lot tout le modèle physique des médias.

Toute faiblesse structurelle empêchant un comportement sûr doit être
documentée et isolée, pas masquée.

## 15. Permissions Android

Gérer clairement : autorisation caméra ; accès aux fichiers ; refus
temporaire ; refus permanent ; interruption par Android ; application
mise en arrière-plan.

En cas de refus :

- expliquer l'action nécessaire ;
- proposer une alternative : choisir un fichier ; coller un lien ; écrire
  un mot.

Ne pas bloquer tout le workflow parce qu'une permission est refusée.

Après retour depuis les réglages Android, reprendre le parcours lorsque
possible.

## 16. Annulation et retour

Le bouton retour Android suit cette priorité :

1. fermer le clavier ;
2. fermer le sélecteur ou panneau courant ;
3. revenir à l'étape précédente ;
4. proposer de conserver ou abandonner une capture déjà réalisée ;
5. quitter le workflow.

Si aucun contenu n'a été produit : quitter sans confirmation inutile.

Si une vidéo, un fichier ou un texte existe, afficher :

`Que faire de cette capture ?`

- Garder pour plus tard ;
- Continuer ;
- Abandonner.

Ne pas perdre silencieusement le contenu.

Ne pas enregistrer automatiquement comme contribution finale un contenu
abandonné.

## 17. Libellés

Utiliser un vocabulaire concret.

Préférer :

- Nouvelle technique ;
- Filmer maintenant ;
- Choisir une vidéo ;
- Coller un lien ;
- Ajouter un repère ;
- Rattacher ;
- Créer la technique ;
- Garder pour plus tard ;
- Ajouter une contribution.

Éviter dans l'interface courante :

- Instancier une identité ;
- Créer une contribution ;
- Sélectionner la provenance ;
- Élément source ;
- Média plateforme ;
- Flux de rattachement.

Le mot `Contribution` peut être utilisé dans la fiche ou l'Atelier
lorsque le contexte l'explique, mais pas comme première question au bord
du tatami.

## 18. Accessibilité et ergonomie

Les choix principaux doivent être utilisables : d'une main ; avec des
gants fins ou doigts humides ; sur téléphone ; sur tablette posée au bord
du tatami.

Prévoir :

- zones tactiles suffisantes ;
- libellés visibles ;
- pas uniquement des icônes ;
- pas de boutons principaux collés à la barre système ;
- progression compréhensible ;
- indication claire de l'étape lorsqu'il y en a plusieurs.

Limiter le nombre de choix simultanés.

Ne pas afficher toutes les options avancées par défaut.

## 19. Mode hors ligne

Tous les parcours locaux doivent fonctionner sans réseau : création ;
vidéo locale ; fichier local ; texte ; rattachement ; technique ;
contribution ; reprise.

Un lien externe peut être enregistré hors ligne même si son aperçu n'est
pas disponible.

L'absence de réseau ne doit pas empêcher la sauvegarde du lien.

Indiquer simplement : `Aperçu indisponible hors connexion`

Ne pas transformer une absence de réseau en erreur de données.

## 20. Conservation du contexte

Depuis une discipline :

- la discipline reste présélectionnée ;
- après création, revenir dans cette discipline ou ouvrir la fiche ;
- les filtres précédents restent conservés.

Depuis une fiche :

- la technique reste connue ;
- après ajout, rester sur la fiche ;
- le média ou la contribution nouvellement créé apparaît immédiatement.

Depuis une recherche globale :

- après création ou rattachement, le retour restaure la recherche.

Depuis `À reprendre` :

- après rattachement, retirer l'élément de la liste ;
- ouvrir la fiche ou revenir à la liste selon le choix utilisateur.

## 21. Actions de fin de parcours

Après création d'une technique :

- `Ouvrir la fiche`
- éventuellement `Ajouter autre chose`

Après rattachement d'une capture :

- `Voir la technique`
- `Retourner à la bibliothèque`

Après conservation pour plus tard, message court :

`Conservé dans Pratique > À reprendre`

Ne pas utiliser un bouton générique `Terminer`.

Ne pas créer un écran de succès inutile lorsque le retour direct suffit.

## 22. Limites strictes du lot

Ne pas modifier :

- la navigation principale ;
- la structure générale de la Bibliothèque ;
- la hiérarchie complète de la fiche ;
- le modèle identité/contribution ;
- le rapprochement inter-packs ;
- le format `.movpack` ;
- le stockage OPFS en profondeur ;
- le modèle des compositions ;
- les types de relation ;
- la structure interne de l'Atelier ;
- la sécurité et le PIN ;
- la publication ;
- la direction graphique globale.

Les adaptations métier autorisées sont limitées à :

- finaliser les workflows de création ;
- finaliser les captures non rattachées ;
- rattacher à une technique ;
- créer une technique depuis une capture ;
- ajouter une contribution ;
- réutiliser les éditions contextuelles ;
- garantir la cohérence des annulations et reprises.

Toute nouvelle idée hors périmètre doit être **tracée, pas implémentée**.

## 23. Critères d'acceptation

**Scénario A — création minimale**

1. ouvrir Judo ;
2. choisir Nouvelle technique ;
3. saisir uniquement `Nouvelle projection` ;
4. ignorer famille et niveau ;
5. créer ;
6. voir la fiche ;
7. revenir ;
8. retrouver la technique dans la grille.

**Scénario B — discipline créée de zéro**

1. installation vide ;
2. créer Boxe ;
3. choisir Créer la première technique ;
4. créer `Crochet gauche` ;
5. ajouter un repère facultatif ;
6. voir la technique dans Boxe ;
7. ne rencontrer aucune demande de rattachement incohérente.

**Scénario C — vidéo rattachée immédiatement**

1. ouvrir Judo ;
2. Filmer maintenant ;
3. filmer ;
4. choisir Rattacher à une technique existante ;
5. chercher O-goshi ;
6. rattacher ;
7. ouvrir la fiche ;
8. lire la vidéo dans la galerie.

**Scénario D — création depuis une capture**

1. ouvrir Boxe ;
2. filmer une technique inconnue ;
3. choisir Créer une nouvelle technique ;
4. nommer `Uppercut` ;
5. créer ;
6. voir la vidéo attachée ;
7. revenir ;
8. retrouver Uppercut dans la grille.

**Scénario E — garder pour plus tard**

1. filmer depuis la Bibliothèque ;
2. choisir Garder pour plus tard ;
3. fermer l'application ;
4. relancer ;
5. ouvrir Pratique ;
6. retrouver la capture dans À reprendre ;
7. la rattacher ;
8. vérifier qu'elle disparaît de la file et apparaît sur la fiche.

**Scénario F — mot personnel**

1. choisir Ajouter un repère ;
2. saisir `la banane` ;
3. rattacher à une technique ;
4. ouvrir la fiche ;
5. voir le texte dans Mon carnet ;
6. rechercher `la banane` depuis la Bibliothèque ;
7. retrouver la technique.

**Scénario G — enseignement**

1. filmer une démonstration ;
2. indiquer qu'elle vient d'un professeur ;
3. saisir son nom ;
4. rattacher à une technique ;
5. ouvrir la fiche ;
6. voir une voix Enseignement correctement attribuée ;
7. vérifier que le contenu n'apparaît pas comme personnel.

**Scénario H — annulation**

1. filmer ;
2. commencer le rattachement ;
3. appuyer sur retour ;
4. choisir Garder pour plus tard ;
5. vérifier que la vidéo n'est pas perdue ;
6. recommencer avec Abandonner ;
7. vérifier l'absence de capture et de technique fantôme.

**Scénario I — doublon potentiel**

1. créer `De Ashi Barai` dans Judo ;
2. voir la suggestion `De-ashi-harai` ;
3. choisir l'identité existante ;
4. ajouter le contenu ;
5. vérifier qu'aucune nouvelle identité n'est créée ;
6. recommencer et choisir explicitement Créer séparément ;
7. vérifier qu'une confirmation est nécessaire.

**Scénario J — ajout depuis une fiche**

1. ouvrir une technique ;
2. ajouter un média ;
3. ne jamais sélectionner à nouveau la discipline ou la technique ;
4. ajouter une contribution d'enseignement ;
5. revenir à la fiche ;
6. voir immédiatement les nouveaux contenus.

**Scénario K — hors ligne**

1. couper le réseau ;
2. créer une technique ;
3. filmer ;
4. saisir un repère ;
5. coller un lien externe ;
6. sauvegarder ;
7. relancer ;
8. retrouver tous les éléments locaux.

## 24. Tests

Ajouter ou adapter les tests pour couvrir :

- création avec nom uniquement ;
- discipline préselectionnée ;
- discipline créée dans le même parcours ;
- classification facultative ;
- suggestions de doublons ;
- absence de fusion automatique ;
- capture vidéo ;
- sélection fichier ;
- lien hors ligne ;
- texte personnel ;
- rattachement existant ;
- création depuis capture ;
- conservation pour plus tard ;
- reprise après relance ;
- provenance personnelle par défaut ;
- enseignement explicitement attribué ;
- annulation avec conservation ;
- abandon et nettoyage ;
- absence de fichiers orphelins dans les cas couverts ;
- absence de duplication après réessai ;
- retour vers le contexte d'origine.

Ajouter un scénario E2E vertical :

```
installation vide
→ créer Boxe
→ filmer
→ créer Crochet gauche depuis la capture
→ ajouter un mot personnel
→ fermer
→ relancer
→ retrouver la fiche
→ effectuer une seconde capture non rattachée
→ la reprendre
→ la rattacher
→ vérifier l'absence de doublon.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- caméra ;
- permissions ;
- sélecteur de fichiers ;
- mise en arrière-plan ;
- clavier ;
- bouton retour ;
- conservation d'une vidéo après interruption ;
- absence de chevauchement avec la barre basse.

## 25. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- création minimale ;
- capture vidéo ;
- sélection de fichier ;
- ajout de lien ;
- ajout d'un repère ;
- rattachement immédiat ;
- création depuis une capture ;
- conservation pour plus tard ;
- reprise ;
- contribution d'enseignement ;
- annulation.

Chaque workflow doit indiquer :

- entrée ;
- étapes ;
- sortie ;
- données créées ;
- niveau réel de démonstration : test unitaire ; e2e ; Android manuel ;
  validation terrain en attente.

Ajouter un Mermaid compact :

```
Ajouter
→ Technique
ou
→ Capture
   → Technique existante
   → Nouvelle technique
   → À reprendre
```

`docs/systeme.md` :

- composants partagés de création ;
- cycle de vie temporaire d'une capture ;
- rattachement ;
- reprise ;
- règles de provenance par défaut ;
- comportement en cas d'échec.

Matrice de conservation :

- création complète V2 conservée sous forme progressive ;
- formulaire monolithique V2 supprimé ;
- capture rapide V3 conservée ;
- rattachement différé conservé ;
- bouton Capturer global supprimé ;
- ajout direct depuis la fiche conservé ;
- classification obligatoire supprimée ;
- attribution explicite conservée lorsque nécessaire.

`docs/etat.md` :

- lot terminé ;
- scénarios démontrés ;
- limites connues ;
- éventuels risques médias non corrigés dans ce lot ;
- prochain lot : Pratique et Compositions.

## 26. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures ou courte vidéo montrant :
  - panneau Ajouter ;
  - création minimale ;
  - capture vidéo ;
  - choix de rattachement ;
  - création depuis une capture ;
  - capture À reprendre ;
  - contribution d'enseignement.

Rapport compact :

- fichiers modifiés ;
- points d'entrée ;
- étapes des différents workflows ;
- règles par défaut de provenance ;
- comportement des annulations ;
- gestion des captures temporaires ;
- tests réalisés ;
- anomalies hors périmètre.

N'anticipe pas le lot Pratique et Compositions.

Ne refonds pas le stockage média, l'Atelier, le format d'échange, les
relations ou la sécurité.

**La réussite de ce lot se mesure à une chose : au bord du tatami, un
utilisateur peut garder immédiatement une vidéo ou un mot, décider
maintenant ou plus tard où le ranger, et ne jamais perdre son contenu ni
remplir un formulaire inutile.**

---

> **Statut** : texte du LOT 4 reçu **intégralement** (session 22,
> 2026-07-12). Le lot est **spécifié en entier** — reste en attente d'un
> **GO explicite** de Yahya avant toute exécution.

---

# LOT 5 — PRATIQUE, FAVORIS ET COMPOSITIONS : RETROUVER ET RÉUTILISER SON SAVOIR

## Contexte

Le lot 1 a installé trois destinations principales :

- Bibliothèque ;
- Pratique ;
- Atelier.

Le lot 2 a rendu la Bibliothèque exploitable :

- disciplines uniques ;
- exploration visuelle ;
- recherche globale ;
- filtres cumulables ;
- filtres par source ;
- création d'une première technique.

Le lot 3 a refondu la fiche technique :

- média principal en tête ;
- voix distinctes ;
- carnet personnel directement éditable ;
- plusieurs médias ;
- relations compactes ;
- accès aux compositions utilisant la technique.

Le lot 4 a distingué :

- création d'une technique ;
- capture rapide ;
- rattachement immédiat ou différé ;
- modification contextuelle.

L'onglet Pratique doit maintenant devenir un espace personnel réellement
utile.

Il ne doit pas reproduire la Bibliothèque ni devenir un nouvel écran
d'accueil générique.

Il doit réunir trois usages :

1. reprendre les quelques contenus réellement inachevés ;
2. retrouver rapidement ses techniques favorites ;
3. construire, modifier et utiliser ses propres compositions.

La V3 possède déjà un modèle de composition riche avec plusieurs natures
de blocs. Cette richesse ne doit pas être exposée telle quelle à
l'utilisateur lors de chaque ajout.

Ce lot porte **exclusivement** sur :

- la racine de Pratique ;
- les Favoris ;
- la file `À reprendre` ;
- les Compositions ;
- la création et l'édition d'une composition ;
- le mode de consultation pendant l'entraînement ;
- l'export, la sauvegarde et la restauration des compositions.

Il ne refond pas :

- la Bibliothèque ;
- la fiche technique ;
- le workflow général de capture ;
- l'Atelier ;
- le format physique des médias ;
- la sécurité ;
- la publication d'un pack disciplinaire ;
- l'identité graphique globale.

## Objectif unique

Faire de Pratique un espace personnel simple permettant de :

- reprendre un contenu réellement inachevé ;
- retrouver ses favoris ;
- créer `Ma spéciale`, `Mon enchaînement`, `Mon kata libre` ou tout autre
  support personnel ;
- ajouter des techniques et du texte libre ;
- réordonner les éléments ;
- consulter la composition pendant la pratique ;
- modifier sans perdre le contexte ;
- exporter, sauvegarder et restaurer sans dupliquer les techniques.

## 1. Raison d'être de l'onglet Pratique

Pratique contient ce que l'utilisateur sélectionne ou construit pour son
propre usage.

Il ne contient pas :

- toutes les techniques ;
- toutes les disciplines ;
- tous les packs ;
- les fonctions d'administration ;
- les diagnostics ;
- la publication d'un corpus ;
- un historique exhaustif des consultations.

Pratique répond à trois questions :

- Qu'est-ce que je dois encore ranger ?
- Qu'est-ce que je veux retrouver rapidement ?
- Qu'est-ce que je suis en train de construire ou travailler ?

## 2. Racine de Pratique

La racine de Pratique comporte au maximum trois sections :

- À reprendre ;
- Favoris ;
- Compositions.

Ordre recommandé :

1. À reprendre, uniquement si la section n'est pas vide ;
2. Favoris ;
3. Compositions.

Ne pas afficher de section vide sous forme d'un grand bloc inutile.

Si aucune capture n'est à reprendre : la section `À reprendre` n'apparaît
pas.

Si aucun favori n'existe, afficher dans la zone Favoris un état vide
compact :

`Ajoute une technique à tes favoris depuis sa fiche.`

Si aucune composition n'existe, afficher :

`Crée ton premier enchaînement, cours ou parcours personnel.`

avec l'action `Nouvelle composition`.

La racine ne doit pas devenir une longue succession de grandes cartes
explicatives.

Privilégier :

- titres courts ;
- aperçus compacts ;
- accès `Voir tout` lorsqu'il existe plusieurs éléments.

## 3. À reprendre

La section `À reprendre` contient uniquement des actions inachevées ou
des brouillons nécessitant une décision.

Exemples valides :

- capture non rattachée ;
- contenu dont le rattachement a échoué ;
- brouillon de composition explicitement enregistré comme incomplet ;
- média capturé mais non encore classé.

Ne pas y mettre automatiquement :

- dernière technique consultée ;
- dernière note créée ;
- historique de navigation ;
- toutes les contributions personnelles ;
- compositions simplement existantes.

Chaque élément affiche au minimum :

- aperçu du média ou du texte ;
- date ;
- provenance ou auteur si nécessaire ;
- discipline présélectionnée éventuelle ;
- état compréhensible.

Actions disponibles :

- Reprendre ;
- Rattacher à une technique ;
- Créer une technique ;
- Modifier le libellé ou le texte ;
- Supprimer avec confirmation.

Après rattachement réussi :

- l'élément disparaît immédiatement de `À reprendre` ;
- le contenu apparaît dans la fiche cible ;
- aucun doublon ne subsiste.

Si la capture est supprimée :

- expliquer si un fichier local sera également supprimé ;
- respecter sauvegarde et confirmation existantes.

Ne pas ajouter de nouvelle logique de publication dans cette section.

## 4. Favoris — modèle et sémantique

Un favori est un marque-page personnel vers une identité technique.

Il ne crée :

- ni nouvelle technique ;
- ni nouvelle contribution ;
- ni copie du contenu ;
- ni modification d'un pack.

Un favori référence l'identifiant stable de la technique.

Le statut favori est :

- personnel ;
- local à l'installation ;
- inclus dans la sauvegarde intégrale ;
- restauré avec la bibliothèque ;
- exclu par défaut des packs publiés.

Si le modèle ne possède pas encore de favoris, ajouter uniquement le
mécanisme minimal nécessaire :

- collection d'identifiants de techniques favorites ;
- validation des références ;
- migration du modèle ;
- sauvegarde et restauration.

Ne pas créer pour ce lot :

- dossiers de favoris ;
- tags de favoris ;
- ordre manuel complexe ;
- partage public des favoris ;
- favoris collaboratifs.

## 5. Ajout et retrait d'un favori

Depuis la fiche technique, permettre :

- Ajouter aux favoris ;
- Retirer des favoris.

L'action doit être immédiate et réversible.

Utiliser :

- une étoile ou un marque-page ;
- un libellé accessible ;
- un état visuel qui ne repose pas uniquement sur la couleur.

Après ajout, confirmation discrète : `Ajouté aux favoris` — la technique
apparaît dans Pratique.

Après retrait :

- elle disparaît de Favoris ;
- elle reste intacte dans la Bibliothèque ;
- aucune contribution ou donnée n'est supprimée.

Ne pas demander de confirmation pour ajouter ou retirer un favori.

## 6. Liste des favoris

Afficher les favoris sous une forme visuelle cohérente avec la
Bibliothèque, mais plus compacte.

Chaque favori contient :

- miniature ou fallback ;
- nom ;
- appellation traditionnelle facultative ;
- discipline ;
- éventuellement niveau ou famille.

Toucher ouvre la fiche technique.

Le retour revient dans Pratique avec :

- position ;
- recherche éventuelle ;
- état de la section.

Prévoir une recherche uniquement si le nombre d'éléments le justifie.

Ne pas dupliquer tous les filtres avancés de la Bibliothèque.

Une action secondaire peut permettre : Retirer des favoris.

Ne pas afficher :

- suppression de la technique ;
- édition administrative ;
- source technique brute ;
- identifiant du pack.

Si une technique favorite n'existe plus :

- ne pas casser l'écran ;
- afficher un élément indisponible ou nettoyer la référence selon les
  règles validées ;
- tracer le comportement ;
- ne pas recréer une technique fantôme.

## 7. Composition — définition utilisateur

Une composition est un support personnel ordonné permettant d'assembler :

- des techniques existantes ;
- du texte libre.

Exemples possibles :

- Ma spéciale ;
- Mes enchaînements ;
- Mon kata libre ;
- Mon cours ;
- Ma séance ;
- Préparation 2e dan ;
- Travail de la semaine.

Ces exemples ne sont pas une taxonomie obligatoire.

L'utilisateur choisit librement le titre.

Le système ne lui demande pas de classer immédiatement la composition
comme : kata ; cours ; grade ; enchaînement ; système ; prestation.

Une telle classification pourra être ajoutée ultérieurement si un besoin
réel est observé.

## 8. Simplification des blocs visibles

Dans l'interface d'ajout, exposer exactement deux choix :

- Ajouter une technique ;
- Ajouter du texte.

Ne pas exposer comme choix séparés : étape ; transition ; consigne ;
objectif ; durée ; repère ; média.

Le texte libre peut servir à écrire : une transition ; une consigne ; une
durée ; un objectif ; un titre de partie ; un repère ; une attaque ; un
contexte.

Exemples :

```
Tirer la manche puis avancer
3 répétitions de chaque côté
Attaque : Hadaka-jime
Transition au sol
Partie 1 — projections
Faire lentement
```

Le modèle interne peut conserver ses types existants pour compatibilité.

Règles :

- les anciens blocs doivent rester lisibles ;
- aucun contenu existant ne doit être perdu ;
- l'interface peut les présenter comme texte libre ;
- ne pas effectuer de migration destructrice vers un type unique ;
- ne pas supprimer les informations de type existantes à l'export.

Lorsque l'utilisateur crée un nouveau bloc texte, utiliser le type
interne le plus générique prévu par le modèle.

## 9. Création d'une composition

Point d'entrée :

```
Pratique
→ Compositions
→ Nouvelle composition.
```

Étape minimale : titre obligatoire.

Champ facultatif : description courte ou objectif général.

Ne pas demander au départ : provenance ; type de composition ; discipline ;
durée totale ; niveau ; pack ; auteur si l'utilisateur courant est déjà
connu.

Par défaut :

- auteur : Moi ;
- usage : personnel ;
- non publiée.

Après création :

- ouvrir immédiatement l'éditeur ;
- afficher une composition vide ;
- proposer : Ajouter une technique ; Ajouter du texte.

Une composition vide peut être conservée comme brouillon.

Ne pas imposer un écran de confirmation supplémentaire.

## 10. Ajouter une technique

L'action `Ajouter une technique` ouvre un sélecteur utilisant la
Bibliothèque.

Le sélecteur doit permettre :

- recherche globale ;
- choix d'une discipline ;
- filtres simples si nécessaires ;
- accès aux favoris ;
- sélection d'une technique.

Chaque technique sélectionnée est ajoutée comme référence à son identité
stable.

Ne pas copier dans la composition : nom complet comme donnée autonome
faisant foi ; description ; vidéo ; contribution ; taxonomies.

La composition peut conserver un libellé de secours pour la résilience de
l'affichage, mais l'identité technique reste la référence principale.

Après sélection :

- revenir immédiatement à la composition ;
- afficher le nouvel élément ;
- permettre d'ajouter un texte juste après ;
- permettre d'ajouter une autre technique.

Ne pas fermer l'éditeur ni revenir à la racine Pratique à chaque ajout.

## 11. Ajouter du texte

L'action `Ajouter du texte` ouvre un champ simple.

Accepter : un mot ; une phrase ; plusieurs lignes courtes.

Ne pas demander quel type de texte il s'agit.

Prévoir facultativement un style d'affichage léger, seulement si cela
reste simple : texte normal ; titre ou séparateur.

Ne pas exposer les huit types métier comme un choix.

Après validation :

- le bloc est ajouté à la position choisie ;
- il est directement modifiable ;
- l'utilisateur reste dans l'éditeur.

## 12. Ordre et réorganisation

Chaque élément de composition doit être réordonnable.

Sur téléphone :

- poignée de déplacement ;
- boutons Monter / Descendre accessibles ;
- ou glisser-déposer avec alternative accessible.

Sur tablette et web :

- glisser-déposer possible ;
- conserver une alternative clavier ou boutons.

Le réordonnancement doit être :

- immédiatement visible ;
- sauvegardé ;
- stable après fermeture et relance.

Ne pas déclencher une sauvegarde lourde ou un rechargement de tous les
médias à chaque déplacement.

Ne pas dupliquer une étape après plusieurs déplacements rapides.

## 13. Modifier une composition

L'utilisateur peut modifier : titre ; description ; ordre des éléments ;
texte libre ; références techniques ; ajout ou suppression d'éléments.

Toucher un bloc texte : édition directe ou panneau léger.

Toucher un bloc technique en mode édition, ouvrir un menu contextuel :

- Voir la fiche ;
- Remplacer la technique ;
- Ajouter du texte après ;
- Retirer de la composition.

Retirer un bloc technique de la composition ne supprime jamais la
technique de la Bibliothèque.

Supprimer une composition :

- demander confirmation ;
- effectuer une sauvegarde préalable selon les règles existantes ;
- ne supprimer aucune technique ou média source.

## 14. Mode édition et mode entraînement

Distinguer deux usages.

**A. Mode Édition**

Permet : ajouter ; modifier ; réordonner ; supprimer des blocs ; modifier
le titre.

Il affiche les poignées et actions contextuelles.

**B. Mode Entraînement**

Permet de suivre la composition sans éléments d'administration.

Il affiche :

- titre ;
- progression ;
- bloc courant ;
- bloc précédent ou suivant selon le contexte ;
- accès à la technique référencée ;
- texte associé ;
- navigation simple.

Le mode entraînement doit pouvoir être utilisé : téléphone tenu en main ;
téléphone posé ; tablette au bord du tatami.

Prévoir de grandes actions : Précédent ; Suivant ; Quitter.

La barre basse peut être masquée dans ce mode.

Ne pas imposer un chronomètre ou une lecture automatique.

## 15. Présentation du mode entraînement

Le mode entraînement doit privilégier la lisibilité.

Pour un bloc technique :

- nom ;
- appellation traditionnelle facultative ;
- miniature ou média principal si disponible ;
- texte adjacent ou suivant ;
- action `Voir la fiche`.

Pour un bloc texte :

- texte lisible en grand ;
- aucune métadonnée technique inutile.

Navigation :

- balayage horizontal facultatif ;
- boutons toujours présents ;
- indication : `3 / 8`.

Depuis une fiche ouverte dans ce contexte :

- retour vers la même position de la composition ;
- ne pas revenir à la Bibliothèque.

La mise en veille peut continuer à suivre les règles système dans ce lot.

Ne pas ajouter de maintien d'écran actif sans décision explicite sur la
batterie.

## 16. Relation entre texte et technique

Le texte libre reste un bloc indépendant.

L'utilisateur peut naturellement composer :

```
Technique A
→ Texte de transition
→ Technique B
→ Texte de consigne.
```

Ne pas rendre obligatoire l'attachement d'un texte à une technique
précise.

Pour faciliter la lecture, permettre dans l'éditeur : ajouter un texte
avant ; ajouter un texte après.

Mais le stockage reste une séquence ordonnée de blocs.

Ne pas transformer le texte en relation objective du graphe.

## 17. Compositions utilisant une technique

La fiche technique doit continuer à afficher :

`Utilisée dans · N`

Le calcul porte sur les références réelles présentes dans les
compositions.

Ouvrir une composition depuis une fiche :

- ouvre sa consultation dans Pratique ;
- positionne si possible sur l'étape utilisant la technique ;
- retour vers la fiche.

Si une technique est retirée de la Bibliothèque :

- détecter les compositions concernées ;
- empêcher la disparition silencieuse de leur référence ;
- afficher un état `Technique indisponible` avec le libellé de secours ;
- permettre de remplacer ou retirer la référence.

Ne pas supprimer automatiquement le bloc de toutes les compositions.

## 18. Liste des compositions

Dans Pratique, la liste affiche pour chaque composition :

- titre ;
- nombre d'éléments ;
- date de dernière modification ;
- éventuellement miniature de la première technique ;
- état brouillon si vide ou incomplet.

Actions principales : ouvrir ; démarrer le mode entraînement.

Actions secondaires : modifier ; dupliquer ; exporter ; supprimer.

La duplication crée :

- une nouvelle composition ;
- de nouvelles références vers les mêmes techniques ;
- aucune copie des techniques ni médias.

Ne pas afficher un grand bouton d'administration sur chaque carte.

## 19. Recherche et tri des compositions

Prévoir une recherche par titre si plusieurs compositions existent.

Tri minimal : récemment modifiées ; ordre alphabétique.

Ne pas ajouter : catégories complexes ; tags ; dossiers ; statistiques
d'usage ; notation.

Les compositions favorites ou épinglées peuvent être différées.

## 20. Export d'une composition

Rendre l'action accessible depuis le menu de la composition :

`Exporter la composition`

Avant export, expliquer ce qui sera produit.

Deux usages possibles :

**A. Composition seule**

Inclut : composition ; références techniques ; libellés de secours ;
métadonnées minimales.

Ne duplique pas nécessairement les techniques si le destinataire possède
déjà la bibliothèque compatible.

**B. Composition avec les techniques nécessaires**

Inclut : composition ; identités référencées ; contributions
sélectionnées ; médias selon le choix et les capacités du format.

Si le format `.movpack` actuel ne supporte pas proprement ces deux
granularités :

- implémenter la granularité minimale sûre ;
- ne pas afficher une option non fonctionnelle ;
- documenter précisément ce qui est inclus.

Le carnet personnel n'est jamais exporté par défaut.

Avant tout export, afficher : composition incluse ; nombre de techniques
référencées ; médias inclus ou non ; contenu personnel inclus ou non.

Ne pas modifier profondément le format `.movpack` sans nécessité.

Toute évolution nécessaire doit :

- être versionnée ;
- être migrable ;
- conserver les anciens exports ;
- avoir des tests d'import/restauration.

## 21. Import d'une composition

Lorsqu'un `.movpack` contient une composition :

- importer la composition ;
- relier ses références aux identités existantes lorsque possible ;
- utiliser les règles de rapprochement existantes ;
- signaler les références non résolues ;
- ne pas créer silencieusement plusieurs copies d'une même technique.

Si une technique référencée manque :

- conserver le bloc ;
- afficher `Technique à retrouver` ;
- proposer : rattacher à une technique existante ; importer le corpus
  nécessaire ; retirer ce bloc.

Ne pas perdre la structure de la composition parce qu'une technique
manque.

## 22. Sauvegarde et restauration

La sauvegarde intégrale doit inclure :

- favoris ;
- compositions ;
- ordre des blocs ;
- textes libres ;
- références techniques ;
- états à reprendre.

Après restauration sur une installation vierge :

- les favoris pointent vers les bonnes techniques ;
- les compositions gardent leur ordre ;
- les textes sont intacts ;
- les techniques référencées s'ouvrent ;
- le mode entraînement fonctionne ;
- les captures à reprendre restent accessibles.

Les packs publiés par discipline n'incluent pas automatiquement : favoris ;
compositions personnelles ; captures à reprendre.

La sauvegarde personnelle et la publication d'un corpus restent deux
opérations différentes.

## 23. Hors ligne

Toutes les fonctions de Pratique doivent fonctionner hors ligne : Favoris ;
création de composition ; ajout de technique locale ; texte ;
réorganisation ; mode entraînement ; sauvegarde locale.

Un média distant peut être indisponible hors connexion.

Dans ce cas :

- afficher la miniature mise en cache si disponible ;
- sinon un fallback ;
- ne pas bloquer la progression dans la composition.

## 24. Performance

Ne pas charger à l'ouverture de Pratique : tous les médias des favoris ;
toutes les vidéos de toutes les compositions ; toutes les fiches
techniques complètes.

Charger : métadonnées ; miniatures ; contenu nécessaire à l'écran courant.

En mode entraînement :

- préparer éventuellement le bloc suivant ;
- ne pas instancier tous les lecteurs vidéo simultanément.

Les opérations de réordonnancement doivent rester fluides avec au moins
cinquante blocs.

## 25. Limites strictes du lot

Ne pas modifier :

- la navigation à trois onglets ;
- la structure de la Bibliothèque ;
- la fiche technique hors intégration Favoris et navigation Composition ;
- le workflow global de capture ;
- le modèle identité/contribution ;
- le rapprochement inter-packs ;
- le stockage physique des médias ;
- les types de relation ;
- l'Atelier ;
- la sécurité et le PIN ;
- la publication disciplinaire ;
- l'identité graphique globale.

Les modifications de modèle autorisées sont limitées à :

- favoris personnels ;
- adaptations indispensables aux compositions ;
- compatibilité/migration des anciens blocs ;
- sauvegarde et restauration des données de Pratique.

Toute idée supplémentaire doit être **tracée, pas implémentée**.

## 26. Critères d'acceptation

**Scénario A — Favoris**

1. ouvrir une fiche ;
2. ajouter la technique aux favoris ;
3. ouvrir Pratique ;
4. retrouver la technique ;
5. ouvrir sa fiche ;
6. revenir ;
7. retirer des favoris ;
8. vérifier que la technique reste dans la Bibliothèque.

**Scénario B — À reprendre**

1. créer une capture non rattachée ;
2. ouvrir Pratique ;
3. voir la section À reprendre ;
4. rattacher la capture ;
5. vérifier qu'elle disparaît ;
6. vérifier le contenu dans la fiche.

**Scénario C — création simple**

1. ouvrir Compositions ;
2. créer `Ma spéciale` ;
3. ne saisir que le titre ;
4. ajouter O-goshi ;
5. ajouter le texte `tirer la main` ;
6. ajouter Juji-gatame ;
7. voir trois blocs dans l'ordre.

**Scénario D — réorganisation**

1. créer cinq blocs ;
2. déplacer le dernier en deuxième position ;
3. fermer ;
4. relancer ;
5. vérifier l'ordre ;
6. modifier un texte ;
7. vérifier la sauvegarde.

**Scénario E — mode entraînement**

1. ouvrir Ma spéciale ;
2. démarrer ;
3. naviguer bloc par bloc ;
4. ouvrir la fiche O-goshi ;
5. revenir au même bloc ;
6. poursuivre jusqu'à la fin ;
7. quitter vers la composition.

**Scénario F — blocs existants V3**

1. ouvrir une ancienne composition contenant transition, consigne et
   durée ;
2. vérifier que tous les textes restent visibles ;
3. les modifier sans perte ;
4. exporter ;
5. restaurer ;
6. vérifier que les types internes ne sont pas détruits.

**Scénario G — technique indisponible**

1. utiliser une technique dans une composition ;
2. retirer la technique de la Bibliothèque ;
3. ouvrir la composition ;
4. voir la référence indisponible ;
5. remplacer la technique ;
6. vérifier que la composition reste cohérente.

**Scénario H — duplication**

1. dupliquer Ma spéciale ;
2. modifier la copie ;
3. vérifier que l'original reste inchangé ;
4. vérifier qu'aucune technique n'est dupliquée.

**Scénario I — export et import**

1. exporter une composition ;
2. importer sur installation vierge ;
3. vérifier son titre, son ordre et ses textes ;
4. vérifier les références résolues ;
5. afficher clairement les références absentes.

**Scénario J — sauvegarde intégrale**

1. créer favoris, composition et capture à reprendre ;
2. effectuer une sauvegarde complète ;
3. vider ou réinstaller ;
4. restaurer ;
5. vérifier les trois catégories ;
6. démarrer le mode entraînement.

**Scénario K — hors ligne**

1. couper le réseau ;
2. ouvrir les favoris ;
3. modifier une composition ;
4. utiliser le mode entraînement ;
5. fermer ;
6. relancer ;
7. retrouver les modifications.

## 27. Tests

Ajouter ou adapter les tests pour couvrir :

- ajout/retrait de favori ;
- absence de duplication ;
- technique favorite supprimée ;
- inclusion dans sauvegarde ;
- exclusion des packs publiés ;
- création d'une composition avec titre seul ;
- ajout de référence technique ;
- ajout de texte libre ;
- réordonnancement ;
- modification ;
- duplication ;
- suppression ;
- ancienne composition avec types riches ;
- navigation mode entraînement ;
- retour fiche → composition ;
- calcul `Utilisée dans` ;
- référence technique manquante ;
- export/import ;
- restauration intégrale ;
- fonctionnement hors ligne.

Ajouter un E2E vertical :

```
importer Judo
→ mettre O-goshi en favori
→ créer Ma spéciale
→ ajouter O-goshi
→ ajouter un texte
→ ajouter Juji-gatame
→ réordonner
→ mode entraînement
→ ouvrir une fiche
→ revenir
→ exporter
→ restaurer dans un contexte vierge
→ vérifier favoris et composition.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- réordonnancement tactile ;
- mode entraînement ;
- retour Android ;
- ouverture/retour d'une fiche ;
- lisibilité sur téléphone ;
- utilisation sur tablette ;
- absence de chevauchement avec la barre système.

## 28. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- racine Pratique ;
- Favoris ;
- À reprendre ;
- création d'une composition ;
- ajout d'une technique ;
- ajout d'un texte ;
- réordonnancement ;
- mode entraînement ;
- export/import ;
- sauvegarde/restauration.

Chaque workflow doit indiquer : entrée ; étapes ; sortie ; données créées ;
niveau réel de démonstration.

Ajouter un Mermaid compact :

```
Pratique
├── À reprendre
│   └── Rattacher / Créer / Supprimer
├── Favoris
│   └── Fiche technique
└── Compositions
    ├── Édition
    │   ├── Technique
    │   └── Texte
    └── Mode entraînement
```

`docs/systeme.md` :

- modèle des favoris ;
- références de techniques ;
- compatibilité des anciens blocs ;
- mode entraînement ;
- gestion des références absentes ;
- sauvegarde et export.

Matrice de conservation :

- favoris V2 conservés ;
- compositions V3 conservées et simplifiées ;
- huit types de blocs masqués dans l'interface mais préservés dans les
  données ;
- deux ajouts visibles retenus ;
- `À reprendre` conservé uniquement pour les actions inachevées ;
- historique de consultation non transformé en pseudo-reprise ;
- duplication des techniques explicitement interdite.

`docs/etat.md` :

- lot terminé ;
- scénarios démontrés ;
- limites connues ;
- choix d'export réellement implémenté ;
- prochain lot : Atelier.

## 29. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures ou courte vidéo montrant :
  - racine Pratique ;
  - Favoris ;
  - À reprendre ;
  - création de Ma spéciale ;
  - éditeur avec technique et texte ;
  - réordonnancement ;
  - mode entraînement ;
  - retour fiche → composition.

Rapport compact :

- fichiers modifiés ;
- modèle minimal des favoris ;
- compatibilité des anciens blocs ;
- comportement des références techniques ;
- export réellement implémenté ;
- comportement de sauvegarde et restauration ;
- limites hors périmètre.

N'anticipe pas le lot Atelier.

Ne refonds pas la Bibliothèque, la fiche, la capture, les médias, la
sécurité ou la publication disciplinaire.

**La réussite de ce lot se mesure à une chose : l'utilisateur peut
retrouver ce qu'il a choisi, reprendre ce qu'il n'a pas encore rangé et
construire un parcours utilisable pendant l'entraînement, sans transformer
Movenso en outil de gestion de projet.**

---

> **Statut** : texte du LOT 5 reçu **intégralement** (session 22,
> 2026-07-12). Le lot est **spécifié en entier** — reste en attente d'un
> **GO explicite** de Yahya avant toute exécution.

---

# LOT 6 — ATELIER : CONSTRUIRE, VÉRIFIER, ÉCHANGER ET PROTÉGER LE CORPUS

## Contexte

Le lot 1 a installé trois destinations principales :

- Bibliothèque ;
- Pratique ;
- Atelier.

Le lot 2 a rendu la Bibliothèque exploitable :

- disciplines uniques ;
- recherche globale ;
- filtres ;
- sources ;
- états vides ;
- création d'une première technique.

Le lot 3 a refondu la fiche technique :

- média principal ;
- plusieurs voix ;
- édition contextuelle ;
- carnet personnel ;
- médias ;
- relations et compositions compactes.

Le lot 4 a distingué :

- création d'une technique ;
- capture rapide ;
- rattachement ;
- modification contextuelle.

Le lot 5 a rendu Pratique fonctionnel :

- À reprendre ;
- Favoris ;
- Compositions ;
- mode entraînement ;
- sauvegarde et restauration des données personnelles.

L'Atelier actuel contient déjà plusieurs fonctions utiles, mais son
organisation expose encore trop directement le modèle interne :

- disciplines ;
- taxonomies ;
- types de relation ;
- diagnostics ;
- import ;
- publication ;
- sauvegardes ;
- réglages.

Présentées dans une longue page, ces fonctions produisent un mur de texte
et obligent l'utilisateur à savoir à l'avance quel objet technique il
recherche.

La V2 possédait de nombreuses capacités de gouvernance réelles :

- construction des disciplines, catégories et niveaux ;
- gestion des médias ;
- diagnostics ;
- import et export ;
- sauvegardes ;
- restauration ;
- historique ;
- rollback ;
- protections par PIN.

L'objectif n'est pas de reproduire son ancien panneau Admin, mais de
conserver ses capacités derrière une architecture d'usage plus claire.

## Objectif unique

Transformer l'Atelier en espace de curation compréhensible, organisé
autour de quatre intentions :

1. Construire ;
2. Médias et qualité ;
3. Échanger et protéger ;
4. Réglages et sécurité.

Chaque intention doit mener à des workflows complets, sans exposer
inutilement le modèle interne et sans dupliquer les usages quotidiens de
la Bibliothèque.

## 1. Positionnement de l'Atelier

L'Atelier sert à agir sur le corpus dans son ensemble.

Il permet notamment de :

- structurer une discipline ;
- administrer ses taxonomies ;
- rechercher les éléments incomplets ou incohérents ;
- réparer les problèmes de médias ;
- importer un corpus ;
- publier ce que l'utilisateur maîtrise ;
- sauvegarder l'installation ;
- restaurer ou revenir en arrière ;
- configurer l'application ;
- activer ultérieurement les protections.

Il ne doit pas devenir le passage obligatoire pour :

- consulter une technique ;
- ajouter un repère personnel ;
- ajouter un média à une fiche connue ;
- mettre une technique en favori ;
- créer une composition ;
- utiliser Movenso pendant l'entraînement.

Ces actions restent dans Bibliothèque, Fiche ou Pratique.

## 2. Entrée unique

L'onglet inférieur `Atelier` est l'unique entrée globale vers cet espace.

Supprimer toute clé à molette globale qui ouvre exactement la même
destination.

Une clé ou icône d'outil peut rester uniquement lorsqu'elle représente
une action locale, par exemple :

- gérer les médias d'une fiche ;
- modifier la structure d'une discipline précise.

Elle ne doit pas constituer une seconde navigation vers l'Atelier
général.

Les anciennes routes Admin ou Réglages doivent rediriger vers la section
appropriée de l'Atelier.

## 3. Architecture de la racine

La racine contient exactement quatre intentions principales :

- Construire ;
- Médias et qualité ;
- Échanger et protéger ;
- Réglages et sécurité.

Sur téléphone :

- utiliser des sections repliables ;
- une seule section principale ouverte à la fois ;
- l'ouverture d'une section referme la précédente ;
- conserver l'état de la section active pendant la session.

Sur tablette et grand écran, utiliser au choix :

- menu latéral et panneau de contenu ;
- onglets internes ;
- ou accordéon large.

La structure et les libellés restent identiques à ceux du téléphone.

Ne pas afficher les quatre sections entièrement développées les unes sous
les autres.

## 4. Synthèse actionnable

En haut de l'Atelier, afficher une synthèse uniquement lorsqu'une action
est réellement nécessaire.

Exemples :

- 3 captures à rattacher ;
- 2 vidéos introuvables ;
- 1 rapprochement à arbitrer ;
- 4 techniques sans classification ;
- sauvegarde jamais effectuée.

Chaque élément est cliquable et ouvre directement le workflow
correspondant.

Ne pas afficher :

- nombre total de techniques sans décision associée ;
- nombre total de disciplines comme KPI ;
- nombre de visites ;
- statistiques décoratives ;
- graphiques sans action possible.

Si aucun problème n'est détecté, afficher au maximum une mention
compacte : `Aucun problème détecté`.

Ne pas occuper un écran complet avec un tableau de bord vide.

## 5. Section Construire

La section `Construire` regroupe la structure du corpus.

Sous-sections recommandées :

- Disciplines ;
- Taxonomies ;
- Techniques ;
- Relations ;
- Sources et auteurs, uniquement si le modèle existant permet une gestion
  utile.

Ne pas afficher toutes les sous-sections en même temps sur téléphone.

Une navigation interne ou un second niveau d'accordéon est autorisé.

## 6. Gestion des disciplines

Afficher la liste des disciplines avec :

- nom ;
- nombre d'identités techniques ;
- nombre de taxonomies ;
- nombre de sources présentes ;
- éventuels problèmes actionnables.

Actions disponibles :

- créer ;
- renommer ;
- réordonner ;
- ouvrir dans la Bibliothèque ;
- gérer la structure ;
- retirer si elle est vide ;
- préparer une suppression sécurisée si elle contient des données.

Créer une discipline demande au minimum : nom.

Informations facultatives : description ; icône ou initiale ; métadonnées
déjà supportées par le modèle.

Ne pas demander : pack ; provenance ; familles obligatoires ; système de
niveaux obligatoire.

Une discipline nouvellement créée peut rester vide.

Action proposée après création :

- Créer la première technique ;
- Structurer la discipline ;
- Ouvrir dans la Bibliothèque.

Renommer une discipline ne doit pas :

- recréer les techniques ;
- casser les références des compositions ;
- changer silencieusement l'identité d'un pack existant ;
- perdre ses médias.

Si le modèle actuel calcule une identité de pack à partir du nom de
discipline, signaler clairement ce risque et le tracer pour le lot
technique au lieu de le masquer.

## 7. Suppression d'une discipline

Une discipline vide peut être retirée avec confirmation simple.

Une discipline contenant des techniques ne doit jamais être supprimée en
un clic.

Présenter :

- nombre de techniques ;
- contributions ;
- médias ;
- compositions concernées ;
- relations ;
- sources ou packs concernés.

Options possibles selon les capacités réelles :

- annuler ;
- exporter ou sauvegarder avant ;
- retirer uniquement une source ;
- déplacer ou détacher certains contenus ;
- supprimer la discipline et son contenu après confirmation renforcée.

Une sauvegarde préalable est obligatoire avant suppression en masse.

Ne pas implémenter dans ce lot une suppression complexe non supportée par
le modèle.

Dans ce cas :

- refuser l'opération ;
- expliquer ce qui doit être traité ;
- proposer les actions disponibles.

## 8. Taxonomies

Les taxonomies appartiennent aux données de la discipline.

La section doit permettre de gérer : familles ; catégories ; niveaux ;
autres taxonomies déjà supportées.

Pour chaque taxonomie :

- créer ;
- renommer ;
- ordonner ;
- modifier une couleur facultative ;
- supprimer ou fusionner avec contrôle des usages.

Ne pas présupposer : ceintures ; grades ; catégories judo ; nomenclature
japonaise ; hiérarchie universelle.

Lorsqu'un élément est utilisé par des techniques, afficher avant
suppression :

- nombre d'utilisations ;
- techniques concernées ;
- actions possibles.

Options possibles : remplacer par une autre valeur ; retirer la
classification ; annuler.

Ne pas laisser une suppression créer des références invalides.

## 9. Gestion des techniques dans l'Atelier

Ne pas créer une seconde Bibliothèque complète dans l'Atelier.

La sous-section Techniques sert à :

- rechercher une technique à administrer ;
- repérer les techniques incomplètes ;
- traiter plusieurs problèmes similaires ;
- ouvrir une fiche en mode édition ;
- détecter les doublons ou rapprochements en attente.

Afficher une liste orientée gestion avec :

- nom ;
- discipline ;
- sources ;
- état de classification ;
- état des médias ;
- éventuel problème.

Actions :

- ouvrir la fiche ;
- modifier ce que l'utilisateur maîtrise ;
- traiter un problème ;
- sélectionner plusieurs éléments uniquement si une vraie action de masse
  est supportée.

Ne pas implémenter de modifications de masse factices.

Si les opérations de masse restent différées, afficher des actions
unitaires et tracer ce manque.

## 10. Types de relation

Les types de relation sont des données administrables, mais ils ne
doivent pas être exposés comme un schéma technique brut.

Afficher pour chaque type :

- libellé principal ;
- libellé inverse éventuel ;
- caractère dirigé ou symétrique ;
- nombre de relations utilisant ce type ;
- origine ou source lorsqu'elle existe.

Permettre selon les capacités actuelles :

- créer ;
- renommer ;
- modifier l'inverse ;
- modifier la symétrie ;
- désactiver pour de nouvelles relations ;
- supprimer uniquement lorsqu'il n'est pas utilisé.

Ne pas permettre une modification qui rend les relations existantes
incohérentes sans avertissement et migration explicite.

Les quatre types historiques restent disponibles après migration.

Ne pas afficher leur identifiant interne.

## 11. Sources et auteurs

La distinction suivante doit rester claire : source ou corpus ; auteur ou
organisation ; provenance ; pack ; discipline.

Si le modèle possède déjà des informations éditoriales utilisables,
permettre de :

- corriger un nom d'affichage local ;
- consulter l'auteur ;
- consulter la version ;
- consulter les conditions ;
- retrouver les contributions associées.

Ne pas permettre de modifier le manifeste original d'un pack tiers comme
s'il appartenait à l'utilisateur.

Une adaptation locale doit rester distincte de la source importée.

Ne pas créer un registre d'auteurs complexe dans ce lot s'il n'existe pas
encore.

## 12. Section Médias et qualité

Cette section regroupe les contrôles et réparations.

Sous-sections possibles :

- Problèmes à traiter ;
- Médiathèque ;
- Aperçus et miniatures ;
- Qualité du corpus.

Ne pas exposer une liste technique de fichiers sans contexte.

Chaque anomalie doit répondre à trois questions : quel est le problème ?
quels contenus sont concernés ? que peut faire l'utilisateur ?

## 13. Diagnostics médias

Détecter ou conserver les diagnostics existants :

- fichier local introuvable ;
- référence média sans fichier ;
- fichier sans référence ;
- miniature absente ou invalide ;
- média dupliqué ;
- média non lisible ;
- technique sans média principal ;
- contribution pointant vers un média manquant.

Ne pas présenter `technique sans vidéo` comme une erreur bloquante.

La distinguer des vrais problèmes d'intégrité.

Pour chaque problème, proposer uniquement les actions réellement
disponibles :

- retrouver ou remplacer le fichier ;
- retirer la référence cassée ;
- ouvrir la fiche ;
- régénérer l'aperçu ;
- supprimer un fichier orphelin ;
- ignorer ou marquer comme traité.

Ne jamais supprimer automatiquement tous les fichiers détectés comme
orphelins.

Une prévisualisation et une confirmation sont obligatoires.

## 14. Médiathèque

La médiathèque offre une vue de gestion des médias existants.

Afficher :

- miniature ;
- type ;
- taille si connue ;
- source ;
- nombre de références ;
- état du fichier ;
- techniques ou contributions associées.

Actions possibles selon les capacités réelles :

- ouvrir ;
- voir les utilisations ;
- remplacer ;
- modifier le libellé ;
- choisir comme média principal depuis la fiche concernée ;
- retirer une référence ;
- supprimer le fichier uniquement s'il n'est plus utilisé.

Ne pas supposer qu'un média n'est utilisé qu'une seule fois.

Si le modèle média actuel ne protège pas correctement les références
multiples :

- empêcher la suppression globale depuis l'interface ;
- documenter le risque ;
- réserver le refactor au lot technique.

## 15. Qualité du corpus

Afficher les informations incomplètes de manière actionnable :

- capture à rattacher ;
- technique sans famille ;
- technique sans niveau ;
- contribution sans auteur lisible ;
- relation invalide ;
- rapprochement ambigu ;
- média manquant ;
- référence de composition indisponible.

Ces éléments ne sont pas tous des erreurs.

Distinguer : erreur d'intégrité ; contenu à compléter ; arbitrage humain ;
information facultative.

Permettre :

- ouvrir l'élément ;
- corriger ;
- ignorer lorsqu'il est réellement facultatif ;
- regrouper les arbitrages compatibles dans un lot compact.

Ne pas transformer Movenso en outil de notation de qualité avec un score
global arbitraire.

## 16. Section Échanger et protéger

Cette section regroupe quatre gestes distincts :

- Importer ;
- Publier ;
- Sauvegarder ;
- Restaurer ou revenir en arrière.

Ces gestes ne doivent jamais être présentés comme des synonymes.

## 17. Importer un pack

Workflow attendu :

1. choisir un fichier ;
2. identifier son format ;
3. valider le manifeste ou le contenu ;
4. afficher un aperçu ;
5. signaler les conflits ou rapprochements ;
6. confirmer ;
7. importer ;
8. afficher un rapport.

L'aperçu doit montrer au minimum :

- nom du pack ;
- auteur ou organisation ;
- version ;
- discipline ou portée ;
- conditions éventuelles ;
- nombre de techniques ;
- nombre de contributions ;
- nombre de médias ;
- volume total lorsque connu ;
- nouveaux éléments ;
- éléments réunis ;
- suggestions à arbitrer ;
- erreurs bloquantes.

Ne pas afficher les identifiants internes comme information principale.

Un import invalide doit être refusé avant mutation autant que le
permettent les services actuels.

Si l'import n'est pas complètement atomique :

- ne pas prétendre qu'il l'est ;
- créer une sauvegarde préalable ;
- tracer le besoin pour le lot technique ;
- présenter clairement le comportement réel.

Les JSON de démonstration peuvent rester compatibles techniquement, mais
l'interface de production doit privilégier les vrais conteneurs
`.movpack`.

## 18. Rapport d'import

Après import, afficher un rapport compact :

- nouvelles techniques ;
- identités réunies ;
- contributions ajoutées ;
- médias ajoutés ;
- relations ajoutées ;
- éléments à rapprocher ;
- erreurs ou avertissements.

Actions : Ouvrir la discipline ; Traiter les rapprochements ; Fermer.

Ne pas renvoyer automatiquement vers l'Accueil.

Ne pas afficher un simple message `Import réussi` sans expliquer ce qui a
changé.

## 19. Publier un pack

Publier signifie créer un corpus destiné à être distribué.

Ce n'est pas une sauvegarde complète de l'installation.

Le workflow doit empêcher la republication silencieuse de contenus
tiers.

L'utilisateur choisit au minimum :

- discipline ;
- source ou contributions qu'il maîtrise ;
- nom éditorial du pack ;
- auteur ou organisation ;
- version ;
- conditions ou note de diffusion ;
- inclusion des médias.

Par défaut, exclure :

- carnet personnel ;
- favoris ;
- captures à reprendre ;
- compositions personnelles ;
- contributions provenant de packs tiers ;
- réglages ;
- sauvegardes.

Les contributions d'un référentiel importé ne doivent pas être incluses
simplement parce qu'elles appartiennent à la même discipline.

Avant génération, afficher une prévisualisation exacte :

- nombre d'identités ;
- contributions incluses ;
- sources incluses ;
- médias ;
- taille estimée ;
- éléments exclus ;
- avertissements.

Si le modèle actuel ne sait pas représenter de manière sûre la propriété
éditoriale d'une contribution :

- ne pas publier toute la discipline ;
- limiter la publication aux origines explicitement sélectionnées et
  maîtrisées ;
- documenter la limite.

Ne pas introduire une nouvelle entité Collection sans nécessité démontrée
dans ce lot.

## 20. Sortie du pack publié

Après génération :

- afficher le nom réel du fichier ;
- son type ;
- sa taille ;
- sa version ;
- un résumé du contenu ;
- proposer Partager ou Enregistrer.

Sur Android, utiliser le mécanisme existant réellement fonctionnel.

Ne pas afficher un chemin de fichier inaccessible à l'utilisateur comme
unique résultat.

Si le partage Android n'est pas fiable, le documenter et le réserver au
lot technique au lieu d'afficher un faux succès.

## 21. Sauvegarde intégrale

La sauvegarde personnelle protège l'installation de l'utilisateur.

Elle inclut selon les capacités validées :

- disciplines ;
- techniques ;
- contributions ;
- sources ;
- taxonomies ;
- relations ;
- médias ;
- captures à reprendre ;
- favoris ;
- compositions ;
- paramètres utiles ;
- protections ;
- historique ou snapshots nécessaires.

Elle ne doit pas être confondue avec un pack publiable.

Afficher clairement : `Sauvegarde complète de cette installation`

Le workflow montre :

- date ;
- taille estimée ;
- présence des médias ;
- emplacement ou mode de partage ;
- éventuelles limites.

Après sauvegarde, proposer : Enregistrer ; Partager ; Vérifier.

Si les médias ne sont pas réellement inclus, ne pas employer le terme
sauvegarde complète.

## 22. Sauvegardes locales et historique

Conserver ou introduire une vue compacte des snapshots existants.

Pour chaque snapshot :

- date ;
- motif ;
- version du modèle ;
- taille si connue ;
- action à l'origine.

Exemples de motifs :

- Avant suppression d'une discipline ;
- Avant import du pack Kodokan ;
- Avant restauration ;
- Sauvegarde manuelle.

Actions : Voir le contenu ; Restaurer ; Supprimer l'ancien snapshot si
autorisé.

Ne pas reconstruire l'export CSV détaillé de la V2 comme fonction
centrale.

Un historique technique peut rester accessible dans une vue secondaire de
diagnostic.

## 23. Restauration

Distinguer deux opérations.

**A. Restaurer une sauvegarde complète**

Utilisée notamment sur une installation vierge.

Avant restauration, afficher : contenu ; version ; disciplines ; médias ;
favoris ; compositions ; paramètres concernés.

**B. Revenir à un snapshot local**

Utilisé après une erreur ou une action destructive.

Avant toute restauration :

- créer un snapshot de l'état courant lorsque possible ;
- prévenir des éléments remplacés ;
- permettre l'annulation avant exécution ;
- afficher le résultat.

Si la restauration complète n'est supportée que sur une installation
vierge :

- l'indiquer clairement ;
- ne pas laisser choisir un fichier pour échouer en fin de parcours ;
- proposer de vider de manière sécurisée ou d'utiliser une autre
  opération, uniquement si supporté.

Ne pas implémenter silencieusement une fusion de sauvegardes sans modèle
clair.

## 24. Rollback

Le rollback doit être compréhensible.

Ne pas afficher uniquement : `Restaurer snapshot 01HZX...`

Afficher : `Revenir à l'état avant l'import du 12 juillet à 18:42`

Avant confirmation :

- expliquer ce qui sera remplacé ;
- indiquer si les médias sont réellement restaurés ;
- signaler les données créées depuis ce point ;
- créer une sauvegarde de sécurité de l'état courant.

Si les snapshots ne contiennent pas les octets des médias :

- l'indiquer explicitement ;
- ne pas promettre une restauration complète ;
- tracer le refactor pour le lot technique.

## 25. Section Réglages et sécurité

Cette section accueille les préférences générales et l'entrée vers les
protections.

Dans ce lot, traiter :

- écran de démarrage ;
- thème ;
- préférences d'affichage existantes utiles ;
- état actuel des protections ;
- accès au futur réglage de sécurité.

Ne pas implémenter encore la refonte complète du PIN.

Le lot 7 définira :

- édition autorisée par défaut ;
- protection facultative des modifications ;
- protection facultative des suppressions ;
- création du PIN lors de l'activation ;
- comportement tablette partagée.

Ne pas créer de contrôles factices avant le lot 7.

Si les anciens réglages de sécurité existent :

- les conserver ;
- les regrouper visuellement ;
- indiquer leur état réel ;
- ne pas changer leur sémantique dans ce lot.

## 26. Écran de démarrage

La valeur par défaut reste : Bibliothèque.

Permettre facultativement de choisir parmi les destinations réellement
supportées :

- Bibliothèque ;
- dernière discipline consultée ;
- discipline choisie ;
- Pratique.

Ne jamais proposer : Accueil ; ancien écran Admin ; route supprimée ;
fiche ou workflow temporaire.

Si la discipline choisie n'existe plus :

- revenir automatiquement à Bibliothèque ;
- informer discrètement l'utilisateur ;
- ne pas bloquer le lancement.

## 27. Thème et apparence

Conserver uniquement les réglages apportant une vraie valeur : thème
système ; clair ; sombre.

Les couleurs d'accent personnalisées sont différées sauf si elles
existent déjà sans coût de maintenance.

Ne pas entamer dans ce lot la refonte graphique générale.

L'Atelier doit cependant être lisible dans les thèmes réellement
supportés.

## 28. Responsive et grand écran

Sur téléphone :

- une seule intention principale ouverte ;
- listes compactes ;
- actions en panneau ou écran secondaire ;
- éviter les tableaux larges.

Sur tablette :

- liste à gauche ;
- détail à droite lorsque pertinent ;
- conservation de la navigation basse principale.

Sur web/grand écran :

- navigation latérale interne possible ;
- tableaux uniquement pour les workflows qui bénéficient réellement d'une
  vue dense ;
- gestion des taxonomies et médias facilitée ;
- ne pas créer une application différente.

Le même modèle et les mêmes règles métier s'appliquent sur toutes les
plateformes.

## 29. Conservation de l'état

L'Atelier conserve pendant la session :

- intention principale ouverte ;
- sous-section active ;
- recherche ;
- filtres ;
- élément sélectionné ;
- position de défilement.

Changer d'onglet puis revenir ne doit pas ramener systématiquement en
haut de la racine.

Après une action :

- revenir au contexte pertinent ;
- mettre à jour les compteurs ;
- retirer les problèmes résolus ;
- ne pas réinitialiser toute la navigation.

## 30. Actions destructrices

Toute action destructive depuis l'Atelier doit appliquer :

- libellé précis ;
- conséquences visibles ;
- confirmation ;
- sauvegarde préalable lorsque nécessaire ;
- résultat explicite ;
- possibilité de restauration lorsque réellement supportée.

Ne pas utiliser un bouton générique `Supprimer` lorsque plusieurs niveaux
sont possibles.

Préférer :

- Retirer cette taxonomie ;
- Supprimer ce fichier inutilisé ;
- Retirer cette discipline vide ;
- Restaurer cette sauvegarde ;
- Retirer les contenus issus de cette source.

Le détail des protections par PIN appartient au lot 7.

## 31. Limites strictes du lot

Ne pas modifier :

- la navigation principale ;
- la Bibliothèque ;
- la fiche technique ;
- le workflow de capture ;
- Pratique et Compositions ;
- le modèle identité/contribution ;
- le rapprochement inter-packs ;
- le modèle physique des médias ;
- le format `.movpack` en profondeur ;
- les types de blocs des compositions ;
- la logique de sécurité et de PIN ;
- la direction graphique globale ;
- les plateformes ou le build Android.

Les adaptations autorisées concernent :

- architecture de l'Atelier ;
- workflows de structure ;
- diagnostics existants ;
- présentation et orchestration de l'import ;
- sélection sûre pour la publication ;
- sauvegarde et restauration avec les services existants ;
- réglages généraux existants ;
- redirections des anciennes routes Admin.

Toute faiblesse structurelle de format, stockage ou transaction doit être
**tracée pour le lot technique** et ne pas être masquée par l'interface.

## 32. Critères d'acceptation

**Scénario A — navigation Atelier**

1. ouvrir Atelier ;
2. voir quatre intentions seulement ;
3. ouvrir Construire ;
4. ouvrir Médias et qualité ;
5. vérifier que Construire se referme ;
6. passer à Échanger et protéger ;
7. quitter vers Bibliothèque ;
8. revenir et retrouver la section active.

**Scénario B — discipline**

1. ouvrir Construire > Disciplines ;
2. créer Karaté ;
3. renommer en Karaté Shotokan ;
4. ouvrir dans la Bibliothèque ;
5. revenir ;
6. retirer une discipline vide ;
7. tenter de retirer une discipline non vide ;
8. obtenir une explication actionnable sans perte.

**Scénario C — taxonomies**

1. créer une famille ;
2. créer un niveau ;
3. modifier leur ordre ;
4. utiliser les deux dans une technique ;
5. tenter de les supprimer ;
6. voir les utilisations ;
7. remplacer ou annuler ;
8. vérifier l'intégrité de la fiche.

**Scénario D — relation**

1. ouvrir les types de relation ;
2. voir les quatre types migrés ;
3. créer un type symétrique ;
4. l'utiliser ;
5. vérifier l'affichage de son libellé ;
6. empêcher sa suppression tant qu'il est utilisé.

**Scénario E — média manquant**

1. ouvrir Médias et qualité ;
2. voir une référence locale manquante ;
3. ouvrir la fiche concernée ;
4. remplacer ou retirer la référence ;
5. revenir ;
6. constater la disparition du problème.

**Scénario F — média orphelin**

1. lancer l'analyse ;
2. voir un fichier non référencé ;
3. ouvrir son détail ;
4. annuler la suppression ;
5. confirmer ensuite ;
6. vérifier qu'aucun média utilisé n'est supprimé.

**Scénario G — import**

1. choisir un `.movpack` ;
2. voir manifeste, auteur, version et contenu ;
3. voir les rapprochements ;
4. annuler sans mutation ;
5. recommencer ;
6. importer ;
7. lire le rapport ;
8. ouvrir la discipline.

**Scénario H — publication**

1. choisir Judo ;
2. sélectionner uniquement les contributions du club ;
3. vérifier que Kodokan et Mon carnet sont exclus ;
4. renseigner nom, auteur et version ;
5. voir la prévisualisation ;
6. générer ;
7. inspecter le rapport du pack ;
8. ne trouver aucun contenu tiers non sélectionné.

**Scénario I — sauvegarde**

1. créer une sauvegarde complète ;
2. voir les éléments et médias inclus ;
3. obtenir un fichier partageable ;
4. vérifier le nom, la taille et la date ;
5. ne pas confondre cette action avec Publier.

**Scénario J — restauration**

1. ouvrir une sauvegarde ;
2. voir son contenu avant action ;
3. annuler sans changement ;
4. restaurer sur installation compatible ;
5. vérifier Bibliothèque, Favoris, Compositions et médias ;
6. voir un rapport final.

**Scénario K — rollback**

1. modifier une discipline ;
2. utiliser un snapshot préalable ;
3. lire les conséquences ;
4. restaurer ;
5. vérifier l'état ;
6. conserver un snapshot de l'état abandonné si supporté.

**Scénario L — écran de démarrage**

1. choisir dernière discipline ;
2. fermer complètement ;
3. relancer ;
4. arriver sur cette discipline ;
5. supprimer la discipline ;
6. relancer ;
7. revenir automatiquement à Bibliothèque.

**Scénario M — téléphone**

1. parcourir toutes les sections ;
2. ne jamais avoir quatre blocs ouverts simultanément ;
3. ne pas rencontrer de mur de texte ;
4. toujours comprendre comment revenir.

## 33. Tests

Ajouter ou adapter les tests pour couvrir :

- quatre intentions exactement ;
- accordéon à une section ouverte ;
- redirection ancienne route Admin ;
- création, renommage et retrait de discipline vide ;
- refus de suppression non vide ;
- création et ordre de taxonomies ;
- dépendances avant suppression ;
- types de relation ;
- diagnostics médias ;
- absence de suppression d'un média référencé ;
- prévisualisation d'import ;
- annulation sans mutation ;
- rapport d'import ;
- sélection des contributions publiables ;
- exclusion du carnet et des sources tierces ;
- sauvegarde distincte de publication ;
- restauration ;
- snapshots ;
- préférence de démarrage ;
- fallback si la discipline choisie disparaît.

Ajouter un E2E vertical :

```
installation vide
→ Atelier
→ créer Judo
→ créer familles et niveaux
→ importer un pack
→ consulter le rapport
→ détecter un problème média
→ le traiter
→ publier uniquement une source maîtrisée
→ créer une sauvegarde
→ restaurer dans un contexte vierge
→ vérifier les données.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- sélection de fichier ;
- partage du pack ;
- partage de sauvegarde ;
- restauration ;
- accordéons ;
- retour Android ;
- clavier ;
- comportement sur tablette.

## 34. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- architecture de l'Atelier ;
- création et gestion d'une discipline ;
- taxonomies ;
- diagnostics médias ;
- import ;
- publication ;
- sauvegarde ;
- restauration ;
- rollback ;
- réglages de démarrage.

Ajouter un Mermaid compact :

```
Atelier
├── Construire
│   ├── Disciplines
│   ├── Taxonomies
│   ├── Techniques
│   └── Relations
├── Médias et qualité
│   ├── Problèmes
│   ├── Médiathèque
│   └── Qualité du corpus
├── Échanger et protéger
│   ├── Importer
│   ├── Publier
│   ├── Sauvegarder
│   └── Restaurer
└── Réglages et sécurité
    ├── Démarrage
    ├── Apparence
    └── Protections — lot 7
```

Pour chaque workflow, indiquer :

- entrée ;
- étapes ;
- sortie ;
- données affectées ;
- niveau réel de démonstration ;
- limites techniques connues.

`docs/systeme.md` :

- responsabilités de l'Atelier ;
- orchestration des services ;
- distinction publication/sauvegarde ;
- diagnostics ;
- règles de suppression ;
- gestion des états.

Matrice de conservation :

- capacités Admin V2 conservées ;
- tableau de bord dense supprimé ;
- KPI décoratifs supprimés ;
- disciplines et taxonomies conservées ;
- gestion média conservée ;
- historique CSV sacrifié comme fonction centrale ;
- rollback conservé ;
- publication séparée de la sauvegarde ;
- sécurité déplacée dans Atelier et différée au lot 7.

`docs/etat.md` :

- lot terminé ;
- workflows réellement démontrés ;
- limites ;
- risques techniques réservés au lot 8 ;
- prochain lot : Sécurité et modes d'usage.

## 35. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures ou vidéo montrant :
  - racine Atelier ;
  - les quatre intentions ;
  - Construire ;
  - diagnostic média ;
  - aperçu avant import ;
  - aperçu avant publication ;
  - sauvegardes et restauration ;
  - réglage de démarrage.

Rapport compact :

- fichiers modifiés ;
- anciennes routes redirigées ;
- architecture finale de l'Atelier ;
- fonctions V2 conservées ;
- fonctions transformées ;
- fonctions volontairement différées ;
- contenu exact d'un pack publié ;
- contenu exact d'une sauvegarde ;
- limites transactionnelles ou médias restant au lot technique.

N'anticipe pas le lot 7 Sécurité.

Ne refonds pas la Bibliothèque, la fiche, la capture, Pratique, le
stockage média ou les plateformes.

**La réussite de ce lot se mesure à une chose : un utilisateur qui
souhaite construire, vérifier, échanger ou protéger son corpus trouve
immédiatement le bon parcours, sans connaître l'architecture interne de
Movenso et sans traverser un panneau d'administration monolithique.**

---

> **Statut** : texte du LOT 6 reçu **intégralement** (session 22,
> 2026-07-12, en deux temps — sections 1-25 puis 26-35). Le lot est
> **spécifié en entier** — reste en attente d'un **GO explicite** de Yahya
> avant toute exécution.

---

# LOT 7 — SÉCURITÉ ET MODES D'USAGE : APPAREIL PERSONNEL, TABLETTE PARTAGÉE ET SESSION CURATEUR

## Contexte

Le lot 1 a installé trois destinations :

- Bibliothèque ;
- Pratique ;
- Atelier.

Les lots suivants ont fermé les principaux workflows :

- exploration et création d'un corpus ;
- fiche technique et médias ;
- capture et rattachement ;
- favoris et compositions ;
- construction, diagnostic, import, publication, sauvegarde et
  restauration dans l'Atelier.

La V2 imposait une logique de connexion Admin par PIN avant certaines
opérations. Cette protection répondait à un vrai besoin de tablette
collective, mais elle créait une friction inutile sur un appareil
personnel et exposait une gouvernance plus complexe que les usages
réellement observés.

La cible est désormais :

- appareil personnel : modification autorisée par défaut, sans PIN ;
- tablette partagée : consultation libre, actions choisies protégées ;
- curateur ou sensei : déverrouillage temporaire permettant d'effectuer
  les opérations protégées.

Le système ne doit pas introduire :

- de comptes ;
- de profils utilisateurs ;
- de serveur ;
- de rôles collaboratifs complexes ;
- d'authentification obligatoire au démarrage.

Ce lot porte sur :

- les modes d'usage ;
- l'activation facultative des protections ;
- la création et la vérification du PIN ;
- la session temporaire de curateur ;
- le verrouillage automatique ;
- la matrice des opérations protégées ;
- le comportement sur tablette partagée ;
- la migration des anciens réglages de sécurité.

Il ne porte pas sur :

- le chiffrement intégral des données ;
- la sécurité physique du terminal ;
- les comptes multiples ;
- la synchronisation distante ;
- les permissions éditoriales fines entre plusieurs personnes ;
- le modèle de propriété des packs.

## Objectif unique

Permettre à Movenso de fonctionner naturellement dans deux contextes :

1. appareil personnel entièrement modifiable sans PIN ;
2. appareil partagé librement consultable, dont les modifications et
   opérations sensibles sont protégées par un PIN local.

La consultation, la lecture des médias et l'utilisation des compositions
ne doivent jamais être bloquées par défaut.

## 1. Modes d'usage

L'interface peut présenter deux configurations compréhensibles.

**A. Appareil personnel**

Valeur par défaut après installation.

Comportement :

- consultation libre ;
- création et modification libres ;
- suppressions confirmées mais sans PIN ;
- Atelier accessible ;
- aucun écran de connexion ;
- aucun badge Admin ;
- aucun PIN exigé.

**B. Appareil partagé**

Préréglage proposé dans :

```
Atelier
→ Réglages et sécurité
→ Protections.
```

Comportement recommandé :

- consultation libre ;
- Bibliothèque utilisable ;
- médias lisibles ;
- recherche et filtres libres ;
- Favoris et compositions consultables ;
- modifications protégées ;
- suppressions et opérations sensibles protégées ;
- déverrouillage temporaire par PIN.

Le préréglage `Appareil partagé` active les protections recommandées,
mais les deux protections restent configurables séparément.

Ne pas créer deux applications ni deux interfaces différentes.

Le mode d'usage ne modifie pas les données métier.

## 2. Deux protections seulement

Proposer deux réglages indépendants.

**A. Protéger les modifications**

Lorsque cette protection est active, un PIN est nécessaire pour :

- créer ou renommer une discipline ;
- créer, modifier ou retirer une technique ;
- modifier les taxonomies ;
- ajouter, modifier ou retirer une relation ;
- ajouter ou modifier une contribution ;
- modifier un contenu de club ou de sensei ;
- ajouter ou retirer un média ;
- changer le média principal ;
- importer un pack ;
- traiter un rapprochement ;
- créer, modifier ou supprimer une composition ;
- modifier les réglages structurants du corpus.

Les actions purement personnelles peuvent suivre la même protection en
mode partagé afin d'éviter qu'un visiteur modifie l'appareil collectif :

- carnet personnel local ;
- favoris ;
- captures à reprendre.

Ne pas introduire un troisième niveau de permissions dans ce lot.

**B. Protéger les suppressions et opérations sensibles**

Lorsque cette protection est active, un PIN est nécessaire pour :

- supprimer une discipline ;
- retirer une technique ;
- supprimer une contribution ;
- supprimer un média ou un fichier orphelin ;
- supprimer une composition ;
- supprimer une sauvegarde ;
- restaurer une sauvegarde ;
- effectuer un rollback ;
- réinitialiser la bibliothèque ;
- modifier ou désactiver les protections ;
- changer le PIN ;
- publier ou partager un pack ;
- exporter une sauvegarde complète contenant des données personnelles.

Les confirmations et sauvegardes préalables restent obligatoires même
après saisie du PIN.

Le PIN ne remplace jamais la confirmation destructive.

## 3. Activation des protections

Aucun PIN ne doit être demandé tant qu'aucune protection n'est activée.

Lors de la première activation de l'une des deux protections :

1. expliquer brièvement ce qui sera protégé ;
2. demander la création d'un PIN ;
3. demander sa confirmation ;
4. enregistrer le secret de manière sécurisée ;
5. activer la protection ;
6. proposer facultativement le préréglage `Appareil partagé`.

Si la confirmation diffère :

- ne rien activer ;
- conserver l'écran ;
- afficher une erreur claire.

Ne jamais enregistrer temporairement un PIN incomplet ou non confirmé.

Si un PIN existe déjà, activer la seconde protection ne doit pas demander
d'en créer un nouveau.

## 4. Format du PIN

Utiliser un PIN numérique local.

Règles recommandées :

- minimum 6 chiffres ;
- maximum raisonnable, par exemple 12 chiffres ;
- refus des valeurs trop évidentes si cela peut être fait sans complexité
  excessive : 000000 ; 123456 ; répétition d'un même chiffre.

Ne pas imposer : majuscule ; caractère spécial ; mot de passe
alphanumérique ; compte distant.

Le clavier numérique doit être demandé sur mobile.

L'interface doit permettre de masquer ou révéler temporairement les
chiffres saisis si cela reste cohérent avec le composant utilisé.

## 5. Stockage du PIN

Le PIN ne doit jamais être stocké en clair : ni dans LocalStorage ; ni
dans IndexedDB ; ni dans le JSON principal ; ni dans un fichier de
configuration ; ni dans les logs ; ni dans les sauvegardes exportées sous
forme lisible.

Utiliser l'API Web Crypto disponible dans les cibles actuelles.

Mécanisme minimal attendu :

- sel aléatoire propre à l'installation ;
- dérivation PBKDF2 avec SHA-256 ;
- nombre d'itérations documenté et suffisamment élevé pour l'appareil
  cible ;
- stockage uniquement du sel, des paramètres et du résultat dérivé ;
- comparaison sans journalisation du PIN.

Ne pas introduire une bibliothèque cryptographique lourde si Web Crypto
répond au besoin.

Les tests ne doivent jamais contenir le PIN de production ni imprimer les
secrets.

## 6. Migration de la sécurité existante

Analyser les paramètres de sécurité déjà présents dans la V3 et, le cas
échéant, dans les données migrées de V2.

Cas à gérer :

- aucun PIN existant ;
- ancien PIN stocké selon un autre format ;
- protection activée sans données de vérification valides ;
- ancien réglage `Admin requis` ;
- session Admin précédemment persistée.

Stratégie :

- ne pas conserver une session Admin permanente après migration ;
- migrer un ancien hash uniquement si sa vérification reste sûre ;
- sinon désactiver les protections et demander une nouvelle activation
  explicite ;
- ne jamais convertir un ancien PIN en clair ;
- documenter le comportement réel.

Une migration invalide ne doit pas bloquer l'accès en consultation.

## 7. Déverrouillage au point d'action

Ne pas demander le PIN au démarrage de l'application.

Lorsqu'un utilisateur déclenche une action protégée :

1. conserver le contexte de l'action ;
2. afficher un panneau ou écran de déverrouillage ;
3. indiquer pourquoi le PIN est demandé ;
4. vérifier le PIN ;
5. reprendre automatiquement l'action initiale si le déverrouillage
   réussit.

Exemples :

```
Modification protégée
Saisis le PIN pour modifier cette technique.

Opération sensible
Saisis le PIN pour restaurer cette sauvegarde.
```

Ne pas renvoyer l'utilisateur vers une page générale de connexion.

Après annulation :

- revenir exactement au contexte précédent ;
- ne modifier aucune donnée ;
- ne perdre aucun formulaire non enregistré.

## 8. Session temporaire de curateur

Une saisie correcte ouvre une session temporaire de curateur.

Pendant cette session :

- les actions couvertes par le niveau déverrouillé ne redemandent pas
  immédiatement le PIN ;
- un indicateur discret permet de comprendre que les modifications sont
  temporairement déverrouillées ;
- l'utilisateur peut verrouiller manuellement.

Ne pas afficher un gros mode Admin permanent.

Durée par défaut recommandée : 5 minutes d'inactivité.

Prévoir dans les réglages, uniquement si simple : 5 minutes ; 15 minutes ;
jusqu'à la mise en arrière-plan.

Ne pas permettre une session permanente par défaut sur un appareil
partagé.

La session doit se verrouiller lorsque :

- le délai d'inactivité est dépassé ;
- l'utilisateur appuie sur `Verrouiller maintenant` ;
- l'application reste en arrière-plan au-delà du seuil prévu ;
- l'appareil est redémarré ;
- l'application est complètement fermée ;
- le PIN est modifié ou les protections sont reconfigurées.

La session ne doit pas être incluse dans une sauvegarde.

## 9. Niveau de déverrouillage

Si seule la protection des modifications est activée :

- une saisie correcte autorise les modifications ;
- les suppressions suivent leur réglage propre.

Si les deux protections sont activées :

- une saisie correcte peut déverrouiller les deux niveaux pour la
  session ;
- ne pas demander deux PIN distincts.

Ne pas créer : PIN de modification ; PIN de suppression ; PIN de
publication ; plusieurs comptes.

Un seul PIN local suffit.

## 10. Échecs et temporisation

Après un PIN incorrect :

- afficher une erreur claire ;
- ne pas révéler la longueur ou la proximité du PIN correct ;
- conserver le contexte de l'action.

Introduire une temporisation progressive après plusieurs échecs
consécutifs.

Exemple :

- 1 à 4 erreurs : nouvelle tentative immédiate ;
- à partir de la 5e : attente courte croissante.

Ne pas verrouiller définitivement les données après quelques erreurs.

Réinitialiser le compteur après une vérification réussie.

Ne pas écrire les PIN tentés dans les logs.

Un journal technique peut conserver : date d'un déverrouillage réussi ;
nombre d'échecs agrégé ; verrouillage manuel — sans valeur secrète ni
contenu personnel.

## 11. Changement du PIN

Accessible dans :

```
Atelier
→ Réglages et sécurité
→ Changer le PIN.
```

Workflow :

1. vérifier le PIN actuel ;
2. saisir le nouveau PIN ;
3. confirmer ;
4. réécrire les données de vérification avec un nouveau sel ;
5. fermer toutes les sessions actives ;
6. confirmer le changement.

En cas d'échec après vérification de l'ancien PIN :

- conserver l'ancien PIN ;
- ne jamais laisser l'installation sans vérification valide.

## 12. Désactivation des protections

Désactiver une protection exige le PIN actuel.

Si les deux protections sont désactivées :

- proposer de supprimer les données de vérification du PIN ;
- expliquer qu'aucune action ne sera plus protégée ;
- fermer la session active.

Comportement recommandé :

- supprimer les données de PIN lorsque plus aucune protection n'est
  active ;
- ne pas conserver un secret inutile par inertie.

Ne pas demander le PIN au prochain lancement.

## 13. PIN oublié

Movenso est hors ligne et ne possède ni compte ni serveur de
récupération.

L'interface doit l'expliquer honnêtement.

Ne pas créer : de question secrète ; de PIN maître caché ; de porte
dérobée ; de récupération par e-mail fictive.

Prévoir une voie de récupération réaliste selon les capacités
existantes :

- réinstaller l'application puis restaurer une sauvegarde connue ;
- ou réinitialiser entièrement les données locales après avertissement
  explicite.

Si un ancien code de récupération V2 existe et est conservé :

- le traiter comme un secret distinct ;
- ne jamais le stocker en clair ;
- l'afficher une seule fois lors de sa création ;
- documenter précisément son rôle.

Ne pas réintroduire ce code uniquement pour reproduire la V2 si aucun
besoin n'est démontré.

La sécurité applicative ne peut pas empêcher le propriétaire physique du
terminal de désinstaller l'application.

## 14. Mode tablette partagée

Le préréglage `Tablette partagée` doit être accessible dans les
protections.

Activation recommandée :

- protéger les modifications ;
- protéger les suppressions et opérations sensibles ;
- délai de session court ;
- verrouillage à la mise en arrière-plan ;
- Bibliothèque comme écran de démarrage.

Dans ce mode, sans déverrouillage :

autorisé :

- parcourir les disciplines ;
- rechercher ;
- filtrer ;
- ouvrir les fiches ;
- lire les médias ;
- consulter les relations ;
- consulter les compositions ;
- utiliser le mode entraînement.

protégé :

- créer ;
- éditer ;
- capturer ;
- mettre en favori si les favoris appartiennent à l'appareil collectif ;
- modifier une composition ;
- importer ;
- publier ;
- sauvegarder ou restaurer ;
- accéder aux réglages sensibles.

L'Atelier peut rester visible, mais ses actions protégées déclenchent le
PIN.

Ne pas masquer complètement l'Atelier si cela empêche de comprendre
l'état ou les diagnostics.

## 15. Appareil personnel

Sur un appareil personnel sans protection :

- aucun cadenas permanent ;
- aucun bandeau `Mode Admin` ;
- aucune demande de PIN ;
- tous les workflows restent accessibles ;
- les suppressions conservent confirmation et sauvegarde préalable.

L'utilisateur peut activer les protections ultérieurement sans migrer ses
données.

Le fonctionnement personnel est le défaut produit, pas un mode avancé.

## 16. Indications visuelles

Les actions protégées doivent rester compréhensibles.

Avant déverrouillage, utiliser selon le contexte : petit cadenas ;
libellé `Protégé` ; explication au déclenchement.

Ne pas griser toutes les actions sans expliquer pourquoi.

Préférer : action visible ; demande de PIN lorsqu'elle est utilisée.

Cela permet à un utilisateur de tablette partagée de comprendre les
possibilités sans pouvoir les exécuter.

Lorsque la session curateur est ouverte :

- afficher une indication discrète dans l'Atelier ou la barre
  supérieure ;
- proposer `Verrouiller maintenant`.

Ne pas utiliser uniquement la couleur pour signaler l'état.

## 17. Matrice des actions

Créer dans le code une matrice ou politique centralisée des actions
protégées.

Ne pas disperser des conditions telles que `if (pinActif)` dans chaque
composant.

La politique doit pouvoir répondre à :

- action demandée ;
- protection activée ;
- session déverrouillée ou non ;
- autorisation résultante.

Catégories minimales :

- CONSULTATION ;
- MODIFICATION ;
- DESTRUCTION_OU_SENSIBLE.

Exemples :

- lire une fiche → CONSULTATION ;
- ajouter une note → MODIFICATION ;
- supprimer une technique → DESTRUCTION_OU_SENSIBLE ;
- restaurer → DESTRUCTION_OU_SENSIBLE ;
- changer le thème → CONSULTATION ou préférence non protégée ;
- changer les protections → DESTRUCTION_OU_SENSIBLE.

Les composants demandent une autorisation au service central et ne
réimplémentent pas les règles.

## 18. Opérations asynchrones

Une opération protégée déjà lancée après autorisation ne doit pas être
interrompue au milieu par l'expiration de session.

Exemples : import ; export ; restauration ; génération d'un pack ;
écriture d'une vidéo.

La permission est vérifiée avant le début.

L'expiration pendant l'opération :

- laisse l'opération se terminer ;
- verrouille les actions suivantes ;
- ne corrompt pas les données.

Ne jamais demander à nouveau le PIN au milieu d'une restauration.

## 19. Modifications non enregistrées

Si la session expire pendant un formulaire ouvert :

- ne pas effacer les données saisies ;
- empêcher uniquement l'enregistrement final si une nouvelle
  autorisation est nécessaire ;
- demander le PIN au moment d'enregistrer ;
- reprendre ensuite la sauvegarde.

Si l'utilisateur annule le déverrouillage :

- conserver le brouillon lorsque le workflow le permet ;
- ou proposer de quitter sans enregistrer.

Ne pas perdre silencieusement un commentaire ou une taxonomie en cours
d'édition.

## 20. Retour Android et arrière-plan

Lorsqu'un panneau PIN est ouvert :

- le bouton retour ferme le panneau ;
- revient au contexte précédent ;
- n'exécute pas l'action protégée.

Lors du passage en arrière-plan :

- mémoriser l'heure ;
- appliquer les règles de verrouillage au retour ;
- ne pas afficher brièvement un écran d'édition déverrouillé avant de se
  verrouiller.

Si l'application est capturée dans les applications récentes, éviter
d'exposer une vue sensible uniquement si les capacités Android actuelles
le permettent sans refactor lourd.

Tracer cette possibilité pour le lot plateforme si elle nécessite du
natif.

## 21. Sécurité des exports

Distinguer : pack publiable ; sauvegarde intégrale ; partage d'une
technique ; export d'une composition.

Lorsque la protection des opérations sensibles est active :

- publication et export complet exigent le PIN ;
- sauvegarde intégrale exige le PIN ;
- export d'un contenu personnel exige le PIN ;
- export public clairement limité à un corpus maîtrisé suit les règles de
  publication.

Ne pas inclure par défaut dans un pack publié : PIN ; hash ; sel ;
préférences de sécurité ; session ; historique d'échecs ; carnet
personnel.

Une sauvegarde intégrale ne doit pas permettre de lire le PIN en clair.

Décider et documenter si elle inclut :

- les réglages de protection sans secret ;
- ou aucun réglage de sécurité.

Recommandation :

- restaurer les données ;
- demander une nouvelle configuration des protections sur le nouvel
  appareil ;
- ne pas transporter automatiquement un PIN entre appareils.

## 22. Réinitialisation

La remise à zéro complète est une opération sensible.

Workflow :

1. expliquer ce qui sera supprimé ;
2. recommander ou proposer une sauvegarde ;
3. demander le PIN si la protection est active ;
4. demander une confirmation renforcée ;
5. supprimer les données ;
6. supprimer les réglages de sécurité ;
7. revenir à la Bibliothèque vide.

Ne pas laisser un ancien hash ou une session après réinitialisation.

Ne pas appeler cette opération simplement `Déconnexion`.

## 23. Journal et traçabilité

Conserver une trace minimale des événements de sécurité utiles au
diagnostic :

- protections activées ou désactivées ;
- PIN modifié ;
- déverrouillage réussi ;
- nombre agrégé d'échecs ;
- verrouillage manuel ;
- réinitialisation.

Ne jamais enregistrer : PIN ; hash complet dans un export de logs ;
contenu des formulaires ; texte personnel ; nom des vidéos comme
information de sécurité.

L'historique détaillé de type CSV de la V2 ne doit pas être recréé comme
fonction centrale.

## 24. Accessibilité

Le panneau PIN doit être utilisable : au clavier ; au tactile ; avec
lecteur d'écran.

Prévoir :

- titre décrivant l'action ;
- champ correctement étiqueté ;
- bouton Valider ;
- bouton Annuler ;
- message d'erreur annoncé ;
- zone tactile suffisante.

Ne pas déclencher automatiquement la validation avant que l'utilisateur
ait terminé si cela crée des erreurs de saisie.

## 25. Limites de la protection

Afficher dans la documentation et éventuellement dans l'aide courte :

- le PIN protège les actions dans Movenso ;
- il ne chiffre pas nécessairement toutes les données au repos ;
- il ne protège pas contre un utilisateur ayant accès au système de
  fichiers, au compte Android ou à la désinstallation ;
- la sécurité du terminal reste nécessaire.

Ne pas présenter Movenso comme un coffre-fort certifié.

Ne pas utiliser de formulation anxiogène dans l'interface courante.

## 26. Limites strictes du lot

Ne pas modifier :

- la navigation principale ;
- la Bibliothèque ;
- la fiche ;
- la capture ;
- les Favoris ;
- les Compositions ;
- l'architecture de l'Atelier hors section sécurité ;
- le modèle identité/contribution ;
- le rapprochement ;
- le format `.movpack` en profondeur ;
- le stockage des médias ;
- les plateformes ;
- la direction graphique générale.

Les changements de modèle autorisés sont limités à :

- réglages des protections ;
- paramètres de dérivation du PIN ;
- état de session non persistant ;
- éventuelle migration des anciens réglages.

Ne pas créer : comptes ; rôles multiples ; profils ; biométrie ;
synchronisation ; récupération distante ; chiffrement complet de la
bibliothèque.

Toute demande hors périmètre doit être **tracée pour un lot ultérieur**.

## 27. Critères d'acceptation

**Scénario A — appareil personnel**

1. installation vierge ;
2. ouvrir Movenso ;
3. créer une discipline ;
4. créer une technique ;
5. modifier une fiche ;
6. supprimer après confirmation ;
7. ne jamais rencontrer de PIN.

**Scénario B — première activation**

1. Atelier > Réglages et sécurité ;
2. activer Protéger les modifications ;
3. créer et confirmer un PIN ;
4. quitter l'Atelier ;
5. tenter de modifier une technique ;
6. voir la demande de PIN ;
7. annuler ;
8. vérifier qu'aucune donnée n'a changé.

**Scénario C — session curateur**

1. déclencher une modification ;
2. saisir le bon PIN ;
3. modifier la technique ;
4. modifier une seconde technique sans nouvelle demande immédiate ;
5. attendre l'expiration ;
6. tenter une troisième modification ;
7. voir la demande de PIN.

**Scénario D — protections distinctes**

1. protéger uniquement les suppressions ;
2. modifier une note sans PIN ;
3. tenter de supprimer la technique ;
4. saisir le PIN ;
5. voir ensuite la confirmation destructive ;
6. annuler ;
7. vérifier que la technique existe toujours.

**Scénario E — tablette partagée**

1. activer le préréglage Tablette partagée ;
2. relancer ;
3. explorer la Bibliothèque ;
4. lire une vidéo ;
5. consulter une composition ;
6. tenter d'ajouter une note ;
7. voir la demande de PIN ;
8. annuler et continuer la consultation.

**Scénario F — mauvais PIN**

1. saisir plusieurs PIN incorrects ;
2. voir une erreur sans fuite d'information ;
3. constater une temporisation progressive ;
4. saisir le bon PIN ;
5. retrouver l'action initiale.

**Scénario G — changement**

1. déverrouiller ;
2. changer le PIN ;
3. vérifier l'ancien PIN refusé ;
4. vérifier le nouveau accepté ;
5. vérifier la session précédente fermée.

**Scénario H — désactivation**

1. désactiver la protection des modifications ;
2. conserver celle des suppressions ;
3. modifier librement ;
4. supprimer avec PIN ;
5. désactiver la dernière protection ;
6. vérifier que le PIN n'est plus demandé.

**Scénario I — arrière-plan**

1. déverrouiller ;
2. mettre l'application en arrière-plan ;
3. attendre au-delà du seuil ;
4. revenir ;
5. tenter une modification ;
6. voir la demande de PIN ;
7. ne jamais voir brièvement une opération protégée exécutée.

**Scénario J — formulaire en cours**

1. ouvrir l'édition ;
2. saisir un texte ;
3. laisser la session expirer ;
4. enregistrer ;
5. saisir le PIN ;
6. vérifier que le texte est conservé et enregistré une seule fois.

**Scénario K — sauvegarde et restauration**

1. activer les protections ;
2. créer une sauvegarde intégrale ;
3. vérifier l'absence de PIN en clair ;
4. restaurer sur une installation vierge ;
5. vérifier que les données sont présentes ;
6. vérifier qu'une nouvelle configuration de sécurité est demandée ou que
   les protections sont désactivées selon la décision documentée.

**Scénario L — réinitialisation**

1. activer les deux protections ;
2. lancer la remise à zéro ;
3. lire les conséquences ;
4. saisir le PIN ;
5. annuler ;
6. recommencer et confirmer ;
7. vérifier bibliothèque vide et absence d'ancien PIN.

## 28. Tests

Ajouter ou adapter les tests pour couvrir :

- installation sans PIN ;
- activation au premier réglage ;
- confirmation du PIN ;
- absence de stockage en clair ;
- vérification correcte ;
- mauvais PIN ;
- temporisation ;
- protections indépendantes ;
- politique centralisée ;
- session temporaire ;
- expiration ;
- verrouillage manuel ;
- arrière-plan ;
- changement de PIN ;
- désactivation partielle et totale ;
- reprise d'une action après déverrouillage ;
- formulaire non perdu ;
- opération asynchrone non interrompue ;
- exclusion des secrets des exports ;
- restauration sans transport du secret ;
- migration des anciens réglages ;
- réinitialisation.

Ajouter un E2E vertical :

```
installation personnelle
→ modifier sans PIN
→ activer Tablette partagée
→ consulter librement
→ tenter une modification
→ déverrouiller
→ effectuer plusieurs modifications
→ expiration
→ tentative de suppression
→ PIN
→ confirmation
→ sauvegarde
→ inspection de l'absence de secret.
```

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire pour :

- clavier numérique ;
- arrière-plan ;
- expiration ;
- bouton retour ;
- changement d'orientation ;
- tablette partagée ;
- absence d'apparition furtive d'un contenu protégé ;
- session après fermeture forcée.

## 29. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- appareil personnel ;
- activation des protections ;
- tablette partagée ;
- action protégée ;
- session curateur ;
- expiration ;
- changement du PIN ;
- désactivation ;
- réinitialisation.

Ajouter un Mermaid compact :

```
Appareil personnel
→ aucune protection
→ modification directe

Appareil partagé
→ consultation libre
→ action protégée
→ PIN
→ session curateur temporaire
→ expiration ou verrouillage
```

`docs/systeme.md` :

- politique centralisée d'autorisation ;
- stockage du PIN ;
- dérivation ;
- session temporaire ;
- événements de verrouillage ;
- matrice des opérations ;
- exclusions des exports ;
- limites réelles de la sécurité.

Matrice de conservation :

- PIN V2 conservé comme protection facultative ;
- connexion Admin obligatoire supprimée ;
- modification autorisée par défaut ;
- tablette partagée conservée ;
- rôles Admin/Contributeur non repris ;
- confirmation et sauvegarde avant destruction conservées ;
- secret non exporté ;
- code de récupération non repris sauf justification explicite.

`docs/etat.md` :

- lot terminé ;
- protections réellement démontrées ;
- paramètres cryptographiques ;
- migrations ;
- limites ;
- prochain lot : formats, médias et plateformes.

## 30. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- captures ou vidéo montrant :
  - Réglages et sécurité sans protection ;
  - activation du mode partagé ;
  - création du PIN ;
  - demande de déverrouillage contextuelle ;
  - session curateur ouverte ;
  - action de verrouillage manuel ;
  - suppression avec PIN puis confirmation.

Rapport compact :

- fichiers modifiés ;
- matrice réelle des actions ;
- algorithme de dérivation utilisé ;
- comportement de la session ;
- migration des anciens réglages ;
- contenu de sécurité inclus ou exclu des sauvegardes ;
- limites explicites ;
- anomalies réservées au lot technique.

N'anticipe pas le lot 8 Formats, médias et plateformes.

Ne refonds pas les workflows métier ni l'identité graphique.

**La réussite de ce lot se mesure à une chose : Movenso reste
immédiatement consultable et modifiable sur un appareil personnel, tout
en devenant une tablette collective sûre et prévisible dès que son
propriétaire active volontairement les protections.**

---

> **Statut** : texte du LOT 7 reçu **intégralement** (session 22,
> 2026-07-12). Le lot est **spécifié en entier** — reste en attente d'un
> **GO explicite** de Yahya avant toute exécution.

---

# LOT 8 — FORMATS, MÉDIAS, STOCKAGE ET PLATEFORMES : RENDRE LA PORTABILITÉ RÉELLE ET LE BUILD REPRODUCTIBLE

## Contexte

Les lots précédents ont fermé les principaux workflows métier :

- navigation ;
- Bibliothèque ;
- fiche technique ;
- création et capture ;
- Favoris et Compositions ;
- Atelier ;
- protections facultatives.

La V3 possède déjà :

- un stockage local fondé sur OPFS ;
- des données métier sérialisées ;
- des médias locaux ;
- des exports `.movpack` sous forme de conteneur ZIP ;
- un manifeste ;
- une empreinte SHA-256 partielle ;
- un export et une restauration testés ;
- un build web Vite ;
- une cible Android Capacitor ;
- une génération d'APK en CI.

Cependant, plusieurs risques techniques restent ouverts :

- métadonnées média insuffisantes ;
- noms physiques opaques ou sans extension ;
- fichiers potentiellement supprimés alors qu'ils sont encore
  référencés ;
- snapshots ne restaurant pas nécessairement les octets des médias ;
- export ZIP construit entièrement en mémoire ;
- intégrité ne couvrant pas tous les fichiers ;
- import ou restauration non totalement transactionnels ;
- fichiers temporaires ou orphelins possibles après échec ;
- différence insuffisamment claire entre pack publié, sauvegarde et
  snapshot ;
- compatibilité JSON historique contournant le manifeste ;
- projet Android et procédure de release à clarifier ;
- PWA ou Windows parfois évoqués sans cible réellement livrée ;
- absence d'une cartographie simple des emplacements et noms de
  fichiers.

Ce lot est un **lot de durcissement**.

Il ne doit pas ajouter de nouvelle fonction produit.

## Objectif unique

Rendre Movenso techniquement prévisible et portable en garantissant :

1. un registre média sûr ;
2. un stockage physique documenté ;
3. des références multiples sans suppression accidentelle ;
4. un format `.movpack` versionné et vérifiable ;
5. des exports à mémoire bornée ;
6. des imports et restaurations préparés avant mutation ;
7. une sauvegarde complète incluant réellement les médias ;
8. une cible Android reproductible ;
9. un statut honnête des cibles web, PWA, Windows et Electron.

## 1. Source de vérité des données

Établir et conserver une seule source de vérité pour chaque catégorie.

**Données métier :**

- disciplines ;
- identités techniques ;
- contributions ;
- sources et origines ;
- taxonomies ;
- relations ;
- captures à reprendre ;
- favoris ;
- compositions ;
- réglages non secrets.

**Registre média :**

- métadonnées de tous les médias connus ;
- emplacement logique ;
- empreinte ;
- type ;
- état ;
- références.

**Fichiers binaires :**

- vidéos ;
- images ;
- aperçus ou miniatures ;
- éventuels fichiers associés.

Ne pas laisser plusieurs copies indépendantes d'un index média dans
différentes couches.

Le registre média doit être cohérent avec le stockage physique, mais le
fichier physique ne doit pas devenir la seule source de métadonnées.

## 2. Modèle logique d'un média

Chaque média local doit porter au minimum :

- identifiant stable ;
- type fonctionnel : vidéo ; image ; autre fichier supporté ;
- MIME réel ;
- extension canonique ;
- nom original lorsqu'il existe ;
- taille en octets ;
- empreinte SHA-256 ;
- date d'ajout ;
- origine : caméra ; fichier local ; import ; génération interne ;
- service externe lorsque pertinent ;
- référence externe originale lorsqu'il s'agit d'un lien ;
- libellé facultatif ;
- état : disponible ; manquant ; temporaire ; à vérifier ;
- éventuelles dimensions ou durée si elles sont déjà accessibles sans
  coût excessif.

Ne pas rendre obligatoires des métadonnées impossibles à obtenir de
manière fiable.

Ne pas stocker une vidéo distante comme fichier local si elle n'a pas été
réellement téléchargée.

Un média externe conserve : URL originale ; service détecté ; identifiant
distant éventuel ; aucune fausse taille locale.

## 3. Registre central des médias

Introduire ou consolider un registre central des médias.

Une contribution, une identité, une composition ou une capture référence
un média par identifiant.

Elles ne possèdent pas directement le fichier.

Le registre permet de déterminer :

- combien de références utilisent le média ;
- où il est utilisé ;
- si le fichier existe ;
- s'il peut être supprimé ;
- s'il est inclus dans un export ;
- s'il est orphelin.

Ne pas maintenir manuellement un compteur susceptible de dériver s'il
peut être calculé de manière fiable.

Si un compteur mis en cache est utilisé :

- le recalculer ou le valider régulièrement ;
- ne jamais l'utiliser seul pour une suppression destructive.

## 4. Références multiples

Un même média peut être utilisé par : plusieurs contributions ;
plusieurs techniques ; une composition ; une capture à reprendre ; un
média principal ; une miniature.

Retirer une référence ne supprime jamais immédiatement le fichier
physique si une autre référence existe.

Comportement attendu :

- suppression d'une contribution → retrait de ses références ;
- recalcul des usages ;
- fichier conservé tant qu'il reste utilisé ;
- fichier sans référence → marqué orphelin ;
- suppression physique uniquement après confirmation ou politique
  explicite.

Ne pas déduire la propriété du fichier de la première contribution qui
l'a créé.

## 5. Ingestion d'un média

Tout média local entrant suit un pipeline unique :

1. réception dans une zone temporaire ;
2. lecture des métadonnées ;
3. calcul de l'empreinte ;
4. validation du type et de la taille ;
5. recherche d'un média identique ;
6. déduplication ou création ;
7. déplacement vers le stockage définitif ;
8. écriture du registre ;
9. création de la référence métier ;
10. nettoyage du temporaire.

En cas de doublon exact :

- réutiliser l'identifiant existant lorsque cela est sûr ;
- créer une nouvelle référence ;
- ne pas dupliquer le fichier physique.

Ne pas dédupliquer uniquement sur le nom d'origine.

Utiliser au minimum : taille ; SHA-256.

En cas d'échec avant rattachement :

- conserver la capture récupérable lorsque l'utilisateur a choisi
  `Garder pour plus tard` ;
- sinon nettoyer le temporaire ;
- ne pas créer une référence vers un fichier inexistant.

## 6. Nommage physique

Définir une convention stable et documentée.

Exemple acceptable : `<mediaId>.<extension-canonique>`

Le nom physique ne dépend pas : du nom de la technique ; du titre de la
composition ; du nom du pack ; du nom original fourni par l'utilisateur.

Ces valeurs peuvent changer.

Conserver le nom original dans les métadonnées.

Ne pas stocker les nouveaux médias sans extension lorsque l'extension
est connue.

Le nom physique doit être :

- sûr pour Android, navigateur et futur desktop ;
- sans caractères spéciaux dépendants de la plateforme ;
- indépendant de la langue ;
- stable après renommage d'une technique.

Les médias existants sans extension doivent rester lisibles.

Prévoir une migration réversible ou une résolution de chemin compatible :
ancien emplacement ; nouvel emplacement.

Ne pas renommer tous les fichiers sans stratégie de reprise en cas
d'interruption.

## 7. Arborescence logique

Documenter une arborescence logique claire.

Exemple :

```
state/          — bibliothèque courante, version du modèle
media/          — originaux
thumbnails/     — aperçus régénérables
staging/        — imports et écritures temporaires
snapshots/      — états locaux
exports/        — uniquement si conservation interne réellement nécessaire
```

L'arborescence exacte peut différer selon les contraintes OPFS et
Capacitor.

Elle doit toutefois respecter les responsabilités suivantes : état
courant ; médias définitifs ; temporaires ; miniatures ; snapshots.

Ne pas mélanger fichiers temporaires et définitifs dans le même espace
sans marqueur fiable.

## 8. Emplacement réel et cycle de vie

Documenter pour chaque cible :

**Android :**

- stockage privé de l'application ;
- visibilité ou non par l'utilisateur ;
- conservation lors d'une mise à jour ;
- suppression lors d'une désinstallation ;
- méthode utilisée pour partager ou exporter un fichier hors de l'espace
  privé.

**Navigateur :**

- OPFS propre à l'origine ;
- conséquences d'un effacement des données du site ;
- quota ;
- comportement en navigation privée ;
- persistance demandée ou non.

**PWA si réellement livrée :**

- origine utilisée ;
- même stockage que la version navigateur ;
- comportement après désinstallation de la PWA ;
- différence entre désinstallation de l'icône et effacement des données
  du site.

Ne pas présenter OPFS comme un dossier visible dans l'explorateur
Android.

La propriété des données repose sur l'export et la sauvegarde, pas sur
l'accès manuel au stockage privé.

## 9. Miniatures et aperçus

Les aperçus sont dérivables.

Ils ne constituent pas la copie de référence du média.

Chaque aperçu doit pouvoir être : régénéré ; supprimé sans perdre
l'original ; associé clairement au média source.

La sauvegarde complète peut choisir : d'inclure les miniatures ; ou de
les régénérer après restauration.

Ce choix doit être explicite.

Recommandation :

- ne pas inclure les miniatures régénérables dans la sauvegarde ;
- les reconstruire progressivement ;
- ne pas bloquer l'application pendant leur régénération.

Un aperçu absent n'est pas une perte de donnée.

## 10. Quota et espace disponible

Avant une opération volumineuse (import ; restauration ; capture
longue ; duplication physique éventuelle), estimer lorsque possible :
taille à écrire ; espace disponible ; marge de sécurité.

Si l'estimation n'est pas fiable, l'indiquer sans promettre une garantie
absolue.

En cas d'espace insuffisant :

- refuser avant mutation lorsque possible ;
- conserver l'état existant ;
- nettoyer les temporaires ;
- afficher la taille requise et l'espace estimé disponible.

Ne pas laisser une erreur de quota produire une bibliothèque
partiellement restaurée.

## 11. Nature du `.movpack`

Un `.movpack` est un conteneur ZIP versionné portant une extension
dédiée.

Il ne s'agit pas : d'un JSON simplement renommé ; d'un dossier ; d'un
format implicite dépendant du code courant.

Définir un type logique et un MIME documenté.

Exemple :

- extension : `.movpack`
- conteneur : ZIP
- MIME applicatif recommandé : `application/vnd.movenso.movpack+zip`
- fallback de partage : `application/zip` ou `application/octet-stream`
  selon les limites Android.

Ne pas se fier uniquement à l'extension lors de l'import.

Vérifier : signature ZIP ; présence du manifeste ; version ; structure
attendue.

## 12. Structure canonique du conteneur

Définir et documenter une structure canonique.

Elle peut conserver les noms actuels s'ils sont cohérents.

Exemple conceptuel :

```
manifeste.json
bibliotheque.json
medias/
  <mediaId>.<extension>
apercus/        — optionnel
```

Le manifeste ne doit pas dupliquer intégralement les données métier.

Il décrit le conteneur.

Les anciens conteneurs utilisant par exemple `videos/` doivent rester
importables au moyen d'un lecteur compatible.

Ne pas casser les `.movpack` déjà produits par la V3 sans migration ou
lecture rétrocompatible.

## 13. Manifeste

Le manifeste doit contenir au minimum :

- identifiant stable du pack ou de la sauvegarde ;
- version du format ;
- version du modèle de données ;
- type d'objet : pack publié ; sauvegarde complète ; export de
  composition ; autre portée explicitement supportée ;
- nom éditorial ;
- auteur ou organisation ;
- date de création ;
- version éditoriale ;
- portée ;
- conditions ou note de diffusion lorsque pertinent ;
- inventaire des fichiers ;
- tailles ;
- empreintes ;
- algorithme utilisé ;
- options d'inclusion : médias ; contenu personnel ; réglages ;
- éventuelles dépendances ou références externes.

L'identifiant stable ne doit pas être recalculé uniquement à partir du
nom de discipline.

Renommer un pack ne doit pas créer une nouvelle identité technique du
pack par accident.

## 14. Intégrité

L'intégrité doit couvrir : le fichier de données métier ; chaque média
inclus ; éventuellement les autres fichiers non régénérables.

Pour chaque fichier, conserver : chemin canonique ; taille ; SHA-256.

À l'import :

1. lire le manifeste ;
2. vérifier la liste ;
3. vérifier les tailles ;
4. vérifier les empreintes ;
5. refuser avant mutation en cas d'écart.

Ne pas vérifier uniquement `bibliotheque.json`.

Une miniature régénérable peut être exclue de la validation principale
si elle est explicitement optionnelle.

Un fichier supplémentaire inattendu doit être ignoré avec avertissement,
ou refusé selon la politique documentée.

Ne jamais l'exécuter ni le rendre accessible arbitrairement.

## 15. Export à mémoire bornée

L'export ne doit plus :

- charger toutes les vidéos en mémoire simultanément ;
- construire l'intégralité du ZIP sous forme d'un unique tableau avant
  écriture ;
- encoder les vidéos en base64 dans le JSON.

Utiliser une stratégie de streaming ou d'écriture incrémentale
compatible avec les cibles.

Comportement attendu :

- traiter les médias un par un ;
- libérer les buffers intermédiaires ;
- afficher une progression ;
- permettre l'annulation tant que l'état reste cohérent ;
- supprimer le fichier temporaire en cas d'abandon.

Si la bibliothèque ZIP actuelle ne permet pas ce comportement :

- utiliser son API streaming ;
- ou remplacer uniquement la couche d'archive par une solution légère et
  maintenue.

Ne pas remplacer toute la pile technique.

## 16. Tailles de référence

Le système doit être éprouvé avec au minimum :

- plusieurs centaines de techniques ;
- vingt médias ;
- au moins 500 Mo de fichiers cumulés ;
- un média individuel d'au moins 150 Mo.

La valeur exacte peut être adaptée à la capacité du terminal de recette.

L'objectif n'est pas une promesse de taille illimitée.

L'objectif est de démontrer : absence de chargement simultané de tous
les médias ; progression ; absence de crash mémoire ; résultat
restaurable.

Documenter les limites réelles observées.

## 17. Import en zone de préparation

Un import suit un workflow transactionnel autant que la plateforme le
permet.

Étapes :

1. copier ou lire le conteneur en zone de préparation ;
2. vérifier structure et intégrité ;
3. analyser les données ;
4. appliquer les migrations en mémoire ou dans une zone temporaire ;
5. produire le plan de rapprochement ;
6. estimer les médias à écrire ;
7. créer un snapshot préalable ;
8. écrire les nouveaux médias dans une zone temporaire ;
9. préparer le nouvel état métier ;
10. basculer vers le nouvel état ;
11. finaliser les médias ;
12. nettoyer.

Aucune modification durable ne doit intervenir avant : validation ;
confirmation utilisateur.

Si une atomicité parfaite n'est pas réalisable dans OPFS :

- utiliser un journal de transaction ou marqueur d'opération ;
- rendre l'opération reprenable ou annulable au prochain lancement ;
- ne pas prétendre qu'elle est atomique.

## 18. Bascule de l'état métier

Éviter l'écriture directe non protégée sur le fichier d'état courant.

Stratégie recommandée :

- écrire le nouvel état dans un fichier temporaire ;
- le relire et le valider ;
- conserver l'ancien état ;
- basculer l'indicateur ou remplacer de manière contrôlée ;
- supprimer l'ancien uniquement après succès.

Si le remplacement de fichier n'est pas atomique sur la plateforme :

- utiliser deux emplacements et un pointeur de version ;
- ou un journal de commit minimal.

Au démarrage :

- détecter une transaction inachevée ;
- choisir le dernier état validé ;
- proposer ou effectuer le nettoyage sûr.

## 19. Échec d'import

En cas d'échec :

- l'état précédent reste utilisable ;
- les médias temporaires sont supprimés ou identifiés ;
- le snapshot préalable est conservé ;
- aucun élément partiel n'apparaît dans la Bibliothèque ;
- un rapport indique l'étape et la cause ;
- l'utilisateur peut réessayer.

Ne pas laisser : discipline vide fantôme ; contribution sans média ;
fichier sans registre ; registre sans fichier ; moitié d'un pack
importée.

## 20. Sauvegarde complète

Une sauvegarde complète est un conteneur `.movpack` de type `sauvegarde`.

Elle inclut réellement :

- état métier complet ;
- registre média ;
- médias locaux non régénérables ;
- disciplines ;
- techniques ;
- contributions ;
- sources ;
- taxonomies ;
- relations ;
- captures à reprendre ;
- favoris ;
- compositions ;
- paramètres fonctionnels retenus ;
- informations nécessaires aux migrations.

Elle exclut :

- session curateur ;
- PIN en clair ;
- secret dérivé transportable si la décision du lot 7 prévoit une
  reconfiguration ;
- temporaires ;
- cache ;
- miniatures régénérables, sauf décision documentée ;
- logs non nécessaires.

Si certains médias ne peuvent pas être inclus :

- l'opération ne doit pas être appelée `sauvegarde complète` ;
- afficher une sauvegarde partielle avec liste précise des exclusions.

## 21. Restauration complète

La restauration complète doit fonctionner sur une installation vierge.

Étapes :

1. sélectionner le fichier ;
2. vérifier manifeste et intégrité ;
3. vérifier la version ;
4. migrer vers le modèle courant ;
5. afficher le contenu ;
6. estimer l'espace ;
7. confirmer ;
8. écrire en zone temporaire ;
9. valider ;
10. basculer ;
11. régénérer les éléments dérivables ;
12. afficher un rapport.

Après restauration, vérifier : nombres d'identités et contributions ;
médias disponibles ; sources ; taxonomies ; relations ; favoris ;
compositions ; captures à reprendre ; préférences retenues.

La restauration sur installation non vide ne doit pas effectuer une
fusion implicite.

Options acceptables : réservée à une installation vierge ; remplacement
complet après sauvegarde préalable ; opération de fusion distincte
clairement nommée.

Ne pas mélanger ces comportements.

## 22. Snapshots locaux

Un snapshot local est un mécanisme de retour arrière rapide.

Il n'est pas nécessairement une sauvegarde exportable complète.

Deux stratégies sont acceptables.

**A. Snapshot avec médias** — plus lourd, mais rollback complet.

**B. Snapshot état métier uniquement** — plus léger, mais ne restaure pas
un fichier supprimé physiquement.

Si la stratégie B est conservée :

- le nommer clairement ;
- indiquer ses limites ;
- ne pas promettre un rollback média complet ;
- éviter la suppression physique immédiate des médias après une action
  métier ;
- conserver éventuellement une corbeille temporaire.

Ne pas appeler `sauvegarde complète` un snapshot sans médias.

## 23. Corbeille média temporaire

Pour les opérations destructrices, envisager une corbeille locale
temporaire :

- média retiré du registre actif ;
- fichier conservé pendant une durée ou jusqu'à validation du snapshot ;
- restauration possible ;
- nettoyage ultérieur.

Ne pas implémenter une corbeille complexe si elle dépasse le lot.

Mais si les snapshots restent sans médias, une stratégie de rétention
physique est nécessaire pour que le rollback ait un sens.

Toute suppression définitive doit être clairement distinguée.

## 24. Pack publié

Un pack publié contient uniquement le corpus sélectionné et maîtrisé.

Il ne s'agit pas d'une sauvegarde.

Il inclut :

- manifeste éditorial ;
- identités nécessaires ;
- contributions sélectionnées ;
- taxonomies requises ;
- relations valides dans la portée ;
- médias sélectionnés ;
- éventuelles compositions explicitement incluses.

Il exclut par défaut :

- carnet personnel ;
- favoris ;
- captures à reprendre ;
- réglages ;
- PIN ;
- snapshots ;
- autres packs tiers ;
- contributions non sélectionnées.

Les références vers des identités non incluses doivent être : soit
ajoutées explicitement ; soit conservées comme dépendances signalées ;
soit exclues avec avertissement.

Ne pas produire silencieusement des relations cassées.

## 25. Export de composition

Un export de composition doit utiliser le même conteneur et le même
mécanisme d'intégrité.

Il peut proposer :

- composition seule avec références ;
- composition avec les techniques nécessaires ;
- médias inclus ou non.

Ne pas créer un second format parallèle.

Le manifeste précise la portée.

Une composition exportée ne duplique pas silencieusement les identités
lorsqu'elle est réimportée.

## 26. JSON historiques et démonstration

Conserver la lecture des JSON historiques uniquement comme compatibilité
contrôlée.

Lorsqu'un JSON sans manifeste est importé :

- le détecter comme format historique ;
- afficher qu'il ne possède ni manifeste ni intégrité de conteneur ;
- analyser et valider son schéma ;
- convertir vers le modèle courant ;
- produire un rapport.

Ne pas présenter un JSON historique comme un `.movpack`.

Les artefacts `packs-demo` doivent contenir en priorité de vrais
`.movpack`.

Les JSON peuvent rester comme fixtures de tests ou outils de
développement.

Ils ne doivent pas être le chemin normal présenté à l'utilisateur.

## 27. Compatibilité V2

Établir précisément les formats V2 réellement supportés :

- JSON de bibliothèque ;
- ZIP `.movpack` V2 ;
- export technique ;
- export discipline ;
- export bibliothèque ;
- médias.

Ne pas annoncer une migration complète si certains éléments sont perdus.

Pour chaque format, documenter : détecté ; importable ; migré ; ignoré ;
perdu ; nécessitant un outil externe.

Le code de migration V2 reste dans l'outillage ou une couche dédiée.

Il ne contamine pas le domaine V3.

Ajouter des fixtures représentatives réelles.

## 28. Versionnement et migrations

Distinguer : version du format conteneur ; version du modèle métier ;
version éditoriale du pack ; version de l'application.

Une migration doit être : déterministe ; testée ; idempotente lorsque
applicable ; non destructive ; explicite sur les valeurs perdues ou
transformées.

Ne pas utiliser un même champ `version` pour les quatre notions.

En cas de format futur non supporté :

- refuser proprement ;
- ne pas tenter une lecture partielle hasardeuse ;
- afficher la version minimale requise.

## 29. Projet Android

La cible Android doit être reproductible depuis le dépôt.

Décider et appliquer l'une des stratégies suivantes.

**A. Projet Android versionné**

Recommandée si des réglages natifs, permissions ou plugins sont
nécessaires.

Le dépôt contient : dossier Android ; Gradle ; manifeste ; ressources ;
configuration Capacitor ; éventuels plugins locaux.

**B. Projet généré de manière déterministe**

Acceptable uniquement si :

- toutes les modifications sont appliquées par scripts versionnés ;
- la CI et une machine neuve produisent exactement le même projet ;
- aucune modification manuelle n'est nécessaire.

Ne pas dépendre d'un projet généré puis modifié manuellement hors Git.

Documenter la stratégie retenue.

## 30. Identité et configuration Android

Confirmer et versionner :

- application ID ;
- nom affiché ;
- versionCode ;
- versionName ;
- icônes ;
- permissions ;
- orientations supportées ;
- politiques de stockage ;
- FileProvider ou mécanisme équivalent si utilisé ;
- partage ;
- sélection de fichiers ;
- caméra ;
- règles de sauvegarde Android.

Ne pas ajouter de permission de stockage globale si le sélecteur système
suffit.

Respecter le stockage cloisonné moderne.

## 31. Export et partage Android

Après création d'un `.movpack` ou d'une sauvegarde :

- proposer le partage Android ;
- ou enregistrer via le sélecteur système ;
- afficher un résultat compréhensible.

Ne pas afficher seulement un chemin interne inaccessible.

Le fichier partagé doit posséder : nom lisible ; extension `.movpack` ;
MIME approprié ; taille ; accès valide pendant le partage.

Tester avec : Google Drive ; Files ; partage local ; messagerie
autorisant le type de fichier.

Si une application refuse le MIME personnalisé :

- utiliser un fallback sûr ;
- conserver l'extension.

## 32. Installation, mise à jour et désinstallation

Démontrer :

**Mise à jour APK :**

- conserve l'état OPFS ;
- conserve les médias ;
- applique les migrations ;
- ne demande pas un nouvel import.

**Désinstallation :**

- supprime le stockage privé conformément au comportement Android ;
- n'est jamais présentée comme une sauvegarde ;
- nécessite une restauration depuis un fichier exporté.

**Réinstallation :**

- démarre vide ;
- permet de restaurer ;
- retrouve les données et médias.

Documenter ce comportement dans la recette.

## 33. Signature et release Android

Le workflow actuel peut continuer à produire un APK debug pour la
recette.

Préparer néanmoins une chaîne release documentée : build release ;
signature ; keystore externe au dépôt ; secrets CI ; versionnement ;
artefact APK ou AAB ; vérifications.

Ne jamais committer : keystore ; mot de passe ; secret.

Si les secrets ne sont pas encore disponibles :

- le workflow peut rester désactivé ou documenté ;
- mais la procédure doit être reproductible.

## 34. Web et PWA

Distinguer clairement :

**Web :**

- application ouverte dans un navigateur ;
- OPFS ;
- fonctionnement local après chargement selon le cache réel.

**PWA :**

- manifeste installable ;
- service worker ;
- cache de l'application ;
- démarrage hors ligne ;
- stratégie de mise à jour ;
- icônes ;
- comportement installable.

Ne pas appeler la cible `PWA` si ces éléments n'existent pas.

Décider pour ce lot : soit livrer une PWA minimale réelle ; soit
documenter `Web uniquement, PWA différée`.

Ne pas créer un service worker fragile uniquement pour cocher une case.

Si la PWA est livrée, tester : installation ; lancement hors ligne ;
mise à jour ; conservation OPFS ; erreur contrôlée pour les médias
distants.

## 35. Windows et Electron

Établir un statut explicite.

Electron est soit : présent et maintenu ; absent et différé ; abandonné
au profit d'une PWA ; à réintroduire dans un lot futur.

Ne pas introduire Electron automatiquement dans ce lot sans décision
justifiée.

Si Electron reste absent :

- le documenter clairement ;
- identifier la perte par rapport à la V2 : exécutable Windows portable ;
  accès fichier plus direct ; stockage à côté de l'application ;
- expliquer ce que le web ou la PWA remplace réellement et ce qu'elle ne
  remplace pas.

Ne pas déclarer la PWA équivalente à un ZIP portable Windows sans
démonstration.

Si une cible Windows portable reste un besoin dur, produire un arbitrage
humain compact avant d'ajouter Electron.

## 36. Matrice des plateformes

Maintenir une matrice factuelle.

Pour chaque cible (Android ; navigateur desktop ; PWA ; Windows
portable ; Electron), indiquer : statut ; commande de build ; stockage ;
import ; export ; caméra ; fichiers ; hors ligne ; partage ; signature ;
limites.

Utiliser des statuts tels que : livré ; démontré ; partiel ; différé ;
absent.

Ne pas utiliser `supporté` sans préciser ce qui l'est.

## 37. Build reproductible

Depuis une machine neuve, un développeur doit pouvoir :

1. cloner ;
2. installer les dépendances ;
3. lancer les tests ;
4. produire le build web ;
5. produire l'APK debug ;
6. inspecter un `.movpack` ;
7. lancer les migrations ;
8. créer les packs de démonstration.

Documenter les versions requises : Node ; npm ; Java ; Android SDK ;
Gradle ; Capacitor ; navigateurs de test.

Éviter les dépendances globales non documentées.

Ajouter si utile : `.nvmrc` ; version dans `package.json` ; vérification
de l'environnement.

## 38. Observabilité et diagnostic

Les erreurs techniques doivent être compréhensibles sans exposer les
secrets.

Pour une opération d'import, export ou stockage, produire : identifiant
d'opération ; étape ; message utilisateur ; détail technique
exportable ; fichiers temporaires concernés ; action de reprise.

Ne pas journaliser : PIN ; contenu personnel complet ; URL signée
sensible ; octets média.

Prévoir une action dans l'Atelier : `Exporter le diagnostic` — contenant
uniquement les informations techniques nécessaires.

Ne pas reconstruire un historique CSV exhaustif.

## 39. Limites strictes du lot

Ne pas modifier :

- navigation ;
- Bibliothèque ;
- présentation de la fiche ;
- workflows de capture ;
- Favoris ;
- UX des Compositions ;
- architecture de l'Atelier ;
- règles fonctionnelles de sécurité ;
- modèle de provenance ;
- rapprochement métier ;
- relations ;
- identité graphique générale.

Les évolutions de modèle autorisées concernent uniquement : registre
média ; métadonnées média ; versionnement ; manifeste ; intégrité ;
transactions ; migrations nécessaires.

Ne pas ajouter de nouvelle fonctionnalité utilisateur hors : progression ;
messages d'erreur ; actions nécessaires au partage, export et
restauration.

## 40. Critères d'acceptation

**Scénario A — média partagé**

1. ajouter la même vidéo à deux contributions ;
2. vérifier un seul fichier physique ;
3. retirer une contribution ;
4. vérifier que la vidéo reste lisible dans l'autre ;
5. retirer la dernière référence ;
6. vérifier que le fichier devient orphelin ;
7. supprimer physiquement uniquement après confirmation.

**Scénario B — déduplication**

1. importer deux fois le même fichier ;
2. vérifier la même empreinte ;
3. ne pas créer deux fichiers physiques ;
4. conserver deux références si les usages sont distincts.

**Scénario C — export volumineux**

1. préparer au moins 500 Mo de médias ;
2. exporter une sauvegarde complète ;
3. observer la progression ;
4. ne pas charger tous les médias simultanément ;
5. annuler une première fois ;
6. vérifier le nettoyage ;
7. recommencer ;
8. obtenir un fichier valide.

**Scénario D — intégrité**

1. produire un `.movpack` ;
2. modifier un octet d'un média ;
3. tenter l'import ;
4. voir l'erreur d'intégrité ;
5. vérifier qu'aucune donnée n'a changé.

**Scénario E — interruption**

1. lancer une restauration ;
2. interrompre l'application pendant la préparation ou l'écriture ;
3. relancer ;
4. retrouver l'état précédent valide ;
5. voir la transaction inachevée ;
6. nettoyer ou reprendre sans corruption.

**Scénario F — installation vierge**

1. créer une sauvegarde complète ;
2. désinstaller ;
3. réinstaller ;
4. restaurer ;
5. vérifier toutes les données ;
6. lire les médias ;
7. utiliser Favoris et Compositions.

**Scénario G — snapshot**

1. créer un snapshot ;
2. supprimer une contribution et un média ;
3. restaurer ;
4. vérifier exactement ce qui revient ;
5. si le média ne revient pas, voir la limite explicitement annoncée
   avant action.

**Scénario H — pack publié**

1. publier les contributions du club ;
2. vérifier le manifeste ;
3. vérifier tous les fichiers ;
4. confirmer l'absence du carnet, du PIN, des favoris et des
   contributions Kodokan non sélectionnées.

**Scénario I — JSON historique**

1. importer un JSON de démonstration ;
2. voir l'avertissement format historique ;
3. convertir ;
4. produire ensuite un vrai `.movpack` ;
5. réimporter ce conteneur avec contrôle d'intégrité.

**Scénario J — V2**

1. importer au moins une fixture V2 représentative ;
2. afficher le rapport de migration ;
3. vérifier les techniques ;
4. vérifier les médias ;
5. afficher les données non migrées ou perdues.

**Scénario K — Android**

1. construire l'APK depuis une machine neuve ou la CI ;
2. installer ;
3. filmer ;
4. exporter ;
5. partager vers Files ou Drive ;
6. réimporter ;
7. mettre à jour l'APK ;
8. vérifier les données.

**Scénario L — réseau coupé**

1. couper le réseau ;
2. lancer l'application ;
3. consulter les données ;
4. créer une sauvegarde ;
5. restaurer ;
6. utiliser les médias locaux ;
7. ne pas dépendre d'un service distant.

**Scénario M — plateforme**

1. lire la matrice ;
2. vérifier que chaque cible annoncée dispose d'une commande ou est
   marquée absente ;
3. ne trouver aucune mention Electron ou PWA ambiguë.

## 41. Tests

Ajouter ou adapter les tests pour couvrir :

- validation des métadonnées média ;
- calcul SHA-256 ;
- déduplication ;
- références multiples ;
- suppression de la dernière référence ;
- détection d'orphelins ;
- chemins et extensions ;
- migration des anciens médias ;
- manifeste ;
- inventaire ;
- intégrité de chaque fichier ;
- conteneur corrompu ;
- version future refusée ;
- export à traitement incrémental ;
- annulation ;
- import en staging ;
- bascule ;
- reprise après interruption ;
- nettoyage des temporaires ;
- sauvegarde complète ;
- publication filtrée ;
- export de composition ;
- JSON historique ;
- fixtures V2 ;
- mise à jour du modèle ;
- build Android reproductible.

Ajouter un E2E vertical :

```
installation vide
→ importer un vrai `.movpack`
→ ajouter deux références vers un même média
→ sauvegarde complète
→ restauration dans un contexte vierge
→ vérifier les médias
→ exporter un pack filtré
→ vérifier son manifeste
→ corrompre un média
→ vérifier le refus sans mutation.
```

`npm run verifier` doit être vert.

Ajouter des tests d'intégration spécifiques au stockage lorsque
Playwright seul ne suffit pas.

Une vérification Android réelle est obligatoire pour :

- caméra ;
- fichier volumineux ;
- partage ;
- import depuis Files ;
- quota ;
- mise à jour ;
- désinstallation/réinstallation ;
- interruption pendant export ou restauration.

## 42. Documentation

Mettre à jour uniquement les documents existants.

`docs/workflows.md` :

- ingestion média ;
- média partagé ;
- export ;
- import ;
- sauvegarde complète ;
- restauration ;
- interruption ;
- publication ;
- partage Android.

`docs/systeme.md` :

- diagramme réel des couches ;
- registre média ;
- arborescence logique ;
- nommage ;
- transactions ;
- format `.movpack` ;
- manifeste ;
- intégrité ;
- migrations ;
- plateformes ;
- build.

Ajouter un Mermaid compact :

```
Entrée média
→ Staging
→ Validation + SHA
→ Déduplication
→ Registre
→ Stockage définitif
→ Référence métier
```

et :

```
.movpack
→ Vérification
→ Migration
→ Plan
→ Staging
→ Validation
→ Bascule
→ Nettoyage
```

Matrice de conservation :

- maturité média V2 réintroduite ;
- identités et contributions V3 conservées ;
- JSON brut rétrocompatible mais non format principal ;
- ZIP en mémoire remplacé ;
- sauvegarde complète distinguée du snapshot ;
- Electron explicitement présent, différé ou absent ;
- Windows portable déclaré honnêtement ;
- PWA uniquement si réellement livrée.

`docs/etat.md` :

- lot terminé ;
- format courant ;
- version du modèle ;
- limites de taille observées ;
- stratégie Android ;
- statut des plateformes ;
- risques restant ouverts ;
- prochain lot : identité graphique et consolidation UX.

README :

- procédure de reprise en trente minutes ;
- builds ;
- artefacts ;
- inspection d'un `.movpack` ;
- emplacements logiques des données.

## 43. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- vrais `.movpack` de démonstration ;
- un pack volumineux de test non distribué publiquement ;
- rapport d'inspection d'un conteneur ;
- matrice des plateformes ;
- captures ou vidéo montrant :
  - export avec progression ;
  - rapport d'intégrité ;
  - refus d'un conteneur corrompu ;
  - restauration ;
  - partage Android ;
  - diagnostics média.

Rapport compact :

- fichiers modifiés ;
- modèle média final ;
- arborescence ;
- convention de nommage ;
- format exact ;
- stratégie d'intégrité ;
- stratégie transactionnelle ;
- tailles testées ;
- comportement Android ;
- statut Electron, Windows, Web et PWA ;
- limites encore ouvertes.

N'anticipe pas le lot 9 Identité graphique.

Ne modifie pas les workflows produit déjà validés.

**La réussite de ce lot se mesure à une chose : un utilisateur peut
confier ses vidéos et son corpus à Movenso, les exporter, perdre son
installation, les restaurer et vérifier leur intégrité sans dépendre
d'une promesse implicite, d'un chemin mystérieux ou d'un format que seul
le code courant sait relire.**

---

> **Statut** : texte du LOT 8 reçu **intégralement** (session 22,
> 2026-07-12). Le lot est **spécifié en entier** — reste en attente d'un
> **GO explicite** de Yahya avant toute exécution.
>
> Note de fidélité : la dictée se termine par un fragment répété de la
> section 25 (« Il peut proposer : composition seule avec références ;
> composition avec »), tronqué juste après la phrase de clôture du lot.
> C'est manifestement un doublon de copier-coller et non un ajout
> intentionnel — il n'a pas été reporté ici.

---

# LOT 9 — IDENTITÉ GRAPHIQUE ET CONSOLIDATION UX : DONNER À MOVENSO UNE EXPRESSION VISUELLE COHÉRENTE, SOBRE ET PROFESSIONNELLE

## Contexte

Les lots précédents ont défini et stabilisé :

- une navigation à trois onglets ;
- une Bibliothèque centrée sur les disciplines et les médias ;
- une fiche technique organisée autour du geste et des différentes
  voix ;
- des workflows contextuels de création et de capture ;
- un espace Pratique avec Favoris et Compositions ;
- un Atelier organisé autour de quatre intentions ;
- des protections facultatives ;
- des formats, médias, imports, sauvegardes et plateformes durcis.

L'application ne doit plus évoluer fonctionnellement dans ce lot.

La V3 actuelle présente plusieurs qualités :

- cohérence générale ;
- navigation basse ;
- composants modernes ;
- interface sombre ;
- langage visuel homogène.

Mais elle présente également des limites :

- surfaces sombres uniformes réduisant la respiration et la priorité
  donnée aux médias ;
- accumulation de cartes arrondies ;
- hiérarchie parfois portée presque uniquement par les conteneurs ;
- densité insuffisamment différenciée entre téléphone et tablette ;
- textes d'aide trop présents ;
- boutons ou badges trop nombreux dans certains écrans ;
- faible contraste entre consultation quotidienne et gestion du corpus ;
- identité Movenso encore générique ;
- rupture avec la richesse visuelle et l'efficacité de la Bibliothèque
  V2.

La direction cible reprend les qualités reconnues de la V2 sans recopier
son code ni ses lourdeurs :

- coque et navigation sombres ;
- contenu principalement clair ;
- grille visuelle dense ;
- médias fortement valorisés ;
- informations lisibles rapidement ;
- administration reléguée derrière l'Atelier ;
- sensation d'application martiale professionnelle, non folklorique.

## Objectif unique

Appliquer une identité graphique cohérente et consolider l'ergonomie de
tous les workflows validés, sans modifier leurs règles fonctionnelles.

Le résultat doit donner l'impression d'un produit :

- abouti ;
- stable ;
- immédiatement compréhensible ;
- adapté au bord du tatami ;
- lisible sur téléphone ;
- particulièrement efficace sur tablette ;
- générique pour toutes les disciplines ;
- sobre, distinctif et durable.

## 1. Interdiction de reconcevoir le produit

Ce lot ne doit modifier aucune décision métier validée.

Ne pas :

- recréer un Accueil ;
- ajouter un nouvel onglet ;
- déplacer les Favoris hors de Pratique ;
- exposer davantage les types internes de composition ;
- réintroduire un bouton global Capturer ;
- modifier le modèle identité/contribution ;
- changer les workflows de sécurité ;
- modifier les formats ;
- réorganiser fonctionnellement l'Atelier ;
- créer de nouvelles fonctionnalités.

Les adaptations autorisées concernent :

- mise en page ;
- typographie ;
- couleurs ;
- icônes ;
- densité ;
- responsive ;
- hiérarchie visuelle ;
- libellés courts ;
- placement des actions déjà validées ;
- feedback ;
- accessibilité ;
- cohérence entre écrans.

Si une faiblesse fonctionnelle est découverte :

- la documenter ;
- ne pas la corriger dans ce lot sauf blocage visuel strict.

## 2. Direction générale

Adopter une direction dite `coque sombre, contenu vivant`.

La coque comprend : barre supérieure ; barre basse ; navigation interne
structurante ; éventuellement panneau latéral sur grand écran.

Elle utilise une surface sombre et stable.

Le contenu principal utilise par défaut :

- fonds clairs ou très légèrement teintés ;
- surfaces médias franches ;
- typographie sombre ;
- séparateurs discrets ;
- couleur d'accent limitée.

L'application ne doit pas ressembler : à un tableau de bord SaaS ; à un
thème gaming ; à un dojo japonais décoratif ; à une application de
fitness générique ; à un panneau d'administration sombre uniforme.

Éviter : motifs de tatami ; calligraphie décorative ; drapeaux ; kanji
codés en dur ; silhouettes de combat omniprésentes ; flammes, néons ou
effets métalliques ; couleurs de ceinture utilisées comme langage global.

L'identité martiale vient : du contenu ; des gestes ; des médias ; de la
précision ; de la structure ; du rythme visuel.

## 3. Thèmes

Conserver trois réglages lorsque déjà supportés : Système ; Clair ;
Sombre.

Thème clair recommandé comme référence principale de conception : coque
sombre ; contenu clair ; médias contrastés.

Thème sombre :

- conserver la même hiérarchie ;
- ne pas simplement inverser chaque couleur ;
- éviter l'enchaînement de cartes légèrement différentes sur un fond
  noir ;
- utiliser des séparateurs, de l'espace et des changements de surface
  mesurés.

Le thème système suit le terminal.

Tous les composants doivent être lisibles dans les deux thèmes.

Aucun texte ou badge ne doit devenir invisible selon le thème.

## 4. Système de tokens

Centraliser les valeurs visuelles dans un système de tokens.

Catégories minimales : surfaces ; textes ; accent ; états ; provenance ;
bordures ; ombres ; rayons ; espacements ; dimensions tactiles ;
typographie ; navigation ; médias.

Ne pas disperser des valeurs hexadécimales et dimensions arbitraires dans
chaque composant.

Limiter le nombre de niveaux de surfaces.

Exemple conceptuel :

```
surface-shell
surface-page
surface-elevated
surface-muted
surface-media
text-primary
text-secondary
text-on-shell
border-subtle
accent-primary
state-danger
state-warning
state-success
```

Ne pas créer un token pour chaque écran.

## 5. Couleur d'accent

Choisir une couleur principale sobre et suffisamment distinctive.

Elle sert à : destination active ; action principale ; focus ;
sélection ; progression ; liens utiles.

Elle ne doit pas colorer : tous les titres ; toutes les icônes ; toutes
les cartes ; toutes les bordures.

Conserver éventuellement une nuance chaude ou naturelle cohérente avec
Movenso, sans imiter une couleur de ceinture.

La décision exacte doit être appliquée de manière centralisée et
documentée.

Ne pas proposer un sélecteur complet de couleurs dans ce lot.

## 6. Typographie

Utiliser une typographie système ou embarquée déjà compatible avec les
plateformes.

Ne pas ajouter une police exotique ni un poids lourd inutile.

Définir une échelle limitée : titre de page ; titre de section ; titre de
technique ; texte courant ; métadonnée ; libellé d'action ; légende.

Les noms de techniques doivent être particulièrement lisibles.

Les appellations traditionnelles doivent être : secondaires ;
immédiatement associées au nom principal ; suffisamment grandes pour
rester utiles ; sans style pseudo-calligraphique.

Éviter : textes tout en capitales ; corps trop petits ; titres coupés sur
une ligne alors que l'espace permet deux lignes ; contrastes faibles pour
les métadonnées.

Les textes longs de contributions doivent avoir une largeur de lecture
maîtrisée sur tablette.

## 7. Espacement et densité

Créer une échelle d'espacements cohérente.

**Téléphone :**

- actions tactiles confortables ;
- marges suffisantes ;
- contenu non collé aux bords ;
- deux colonnes visuelles lorsque pertinent.

**Tablette :**

- réduire les grandes zones vides ;
- augmenter le nombre de colonnes ;
- utiliser des panneaux côte à côte ;
- éviter d'étirer une carte téléphone sur toute la largeur.

**Grand écran :**

- largeur maximale du contenu ;
- densité accrue ;
- navigation interne latérale lorsque déjà prévue ;
- fiche ou détail affichable à côté d'une liste lorsque cela ne modifie
  pas la navigation fonctionnelle.

Ne pas appliquer une largeur fixe unique à tous les écrans.

## 8. Rayons et cartes

Réduire l'usage systématique des cartes arrondies.

Utiliser une carte lorsque l'élément est réellement : autonome ;
ouvrable ; déplaçable ; sélectionnable ; comparable à ses voisins.

Utiliser plutôt : espace ; titre ; séparateur ; changement léger de
fond ; alignement — pour structurer : métadonnées ; sections d'une
fiche ; réglages ; explications ; listes simples.

Limiter les rayons à deux ou trois valeurs.

Les grandes cartes imbriquées dans d'autres cartes sont interdites sauf
nécessité démontrée.

Ne pas entourer chaque ligne de réglage d'un rectangle.

## 9. Icônes

Utiliser une seule famille d'icônes cohérente.

Les icônes doivent être : simples ; reconnaissables ; non décoratives ;
accompagnées d'un libellé lorsque le sens n'est pas évident.

Éviter plusieurs symboles différents pour la même action.

Standardiser notamment : Bibliothèque ; Pratique ; Atelier ; Favori ;
Ajouter ; Filmer ; Média ; Modifier ; Supprimer ; Importer ; Publier ;
Sauvegarder ; Restaurer ; Protéger ; Verrouiller.

Ne pas utiliser des emojis comme icônes de production.

## 10. Barre supérieure

La barre supérieure appartient à la coque sombre.

Elle affiche selon le contexte : retour ; titre court ; action
contextuelle secondaire ; menu supplémentaire.

Ne pas afficher simultanément : titre très long ; plusieurs badges ;
trois boutons ; menu ; explication.

Sur une racine d'onglet :

- titre Movenso ou nom de la destination ;
- action réellement utile seulement.

Sur une fiche :

- retour ;
- nom de la technique ;
- menu secondaire.

Sur tablette, le titre peut être plus riche si l'espace le permet.

La barre ne doit pas changer brutalement de hauteur entre les écrans.

## 11. Navigation basse

Conserver exactement : Bibliothèque ; Pratique ; Atelier.

La navigation basse reste sombre.

L'onglet actif est identifiable par plusieurs signaux : icône ;
libellé ; contraste ou fond ; éventuellement indicateur.

Ne pas utiliser uniquement une légère variation de couleur.

Respecter : zones sûres Android ; hauteur tactile ; textes non tronqués ;
orientation paysage ; clavier.

Ne pas ajouter : Accueil ; Capturer ; Réglages ; Compositions comme
quatrième destination.

## 12. Action contextuelle principale

Une seule action principale visible au maximum par écran.

Exemples :

- discipline → Ajouter ;
- liste Compositions → Nouvelle composition ;
- discipline vide → Créer la première technique ;
- fiche sans média → Ajouter un média ;
- Atelier → aucune action globale générique.

Sur mobile, elle peut prendre la forme : bouton flottant ; bouton dans la
barre ; bouton plein dans un état vide.

Le choix doit dépendre du contexte, mais rester cohérent.

Le bouton flottant ne doit pas masquer : la navigation basse ; une
vidéo ; une action destructive ; le dernier élément d'une liste.

Ne pas afficher plusieurs boutons flottants.

## 13. Bibliothèque — racine

La racine Bibliothèque doit exprimer immédiatement la richesse du
contenu.

Conserver : recherche globale visible ; disciplines ; compteurs utiles ;
aperçu visuel.

Les cartes de disciplines peuvent utiliser : mosaïque légère de
miniatures ; média représentatif ; initiale sobre en fallback ; nom ;
compte d'identités ; sources ou voix lorsque pertinent.

Ne pas utiliser une grande icône disciplinaire générique occupant
l'essentiel de la carte si des médias existent.

La racine ne doit pas ressembler à un panneau de configuration.

État vide : illustration facultative très simple ; une phrase ; deux
actions ; aucun long paragraphe.

## 14. Bibliothèque — discipline

La grille technique est le cœur visuel du produit.

Priorités :

1. média ;
2. nom ;
3. appellation ;
4. niveaux ou informations utiles ;
5. pluralité des voix.

Les cartes doivent rester suffisamment grandes pour lire le geste.

Éviter : métadonnées trop nombreuses ; multiples badges empilés ;
boutons d'administration ; texte descriptif.

Sur téléphone : deux colonnes lorsque réaliste ; une colonne uniquement
lorsque l'accessibilité ou le contenu l'exige.

Sur tablette : trois à six colonnes selon la largeur ; carte de largeur
stable ; alignement propre.

Les miniatures doivent avoir : ratio commun ; recadrage cohérent ;
fallback visuel homogène ; état média manquant distinct d'une technique
sans média.

## 15. Recherche et filtres

La recherche reste immédiatement visible.

Les filtres actifs doivent être compréhensibles sans occuper la moitié de
l'écran.

Utiliser : rangée horizontale scrollable ; panneau inférieur ; bouton
Filtres avec compteur ; chips uniquement pour les sélections actives.

Ne pas afficher en permanence toutes les familles, sources et niveaux
sous forme de dizaines de boutons.

Les chips ne doivent pas devenir le seul langage de l'application.

État aucun résultat :

- distinguer bibliothèque vide et filtres trop restrictifs ;
- montrer la possibilité de réinitialiser ;
- conserver la requête visible.

## 16. Fiche technique

La fiche doit suivre la hiérarchie validée : média principal ; identité ;
classifications ; voix ; carnet ; relations ; compositions ; actions
secondaires.

Le média principal doit être le premier élément visuel majeur.

Ne pas enfermer le lecteur dans plusieurs couches de cartes.

La galerie secondaire doit être compacte et tactile.

Les informations générales utilisent : lignes ; groupes ; badges
limités ; séparateurs.

Les voix sont présentées dans une section claire avec une seule voix
développée.

La source ouverte doit être immédiatement identifiable.

Les autres voix restent visibles comme choix, pas comme grands blocs
empilés.

## 17. Provenance et sources

Définir un langage visuel cohérent pour : Référentiel ; Enseignement ;
Ressource ; Personnel.

La provenance peut utiliser : libellé ; icône ; accent discret.

Ne jamais reposer uniquement sur une couleur.

Ne pas attribuer une couleur forte différente à chaque source ou pack.

Le nom de la source ou de l'auteur reste prioritaire : Kodokan ; Judo
Club de Castres ; Sensei Martin ; Moi.

La provenance est secondaire : `Kodokan · Référentiel`

## 18. Mon carnet

Mon carnet doit être identifiable comme espace personnel sans sembler
détaché de la fiche.

État vide : invitation discrète ; action locale.

État rempli : texte lisible ; modification simple ; signal personnel
compact.

Ne pas utiliser une grande carte colorée pour un seul mot.

Le texte doit pouvoir être très court sans donner l'impression d'un
composant vide.

## 19. Pratique

La racine de Pratique doit être compacte et personnelle.

**À reprendre :**

- mise en avant uniquement lorsqu'une action existe ;
- accent modéré de type attention ;
- pas de rouge si aucune erreur.

**Favoris :**

- grille ou carrousel visuel ;
- accès rapide ;
- cohérence avec la Bibliothèque.

**Compositions :**

- cartes plus éditoriales ;
- titre ;
- aperçu d'étapes ;
- dernière modification ;
- action Démarrer facilement identifiable.

Ne pas présenter Favoris, À reprendre et Compositions comme trois énormes
panneaux de même poids.

## 20. Éditeur de composition

L'éditeur doit rester simple.

Actions visibles : Ajouter une technique ; Ajouter du texte.

Les blocs utilisent deux traitements distincts mais sobres.

**Technique :** miniature ; nom ; poignée ; menu.

**Texte :** texte ; poignée ; édition.

Ne pas afficher le type interne du bloc.

Le réordonnancement doit être lisible sans transformer chaque bloc en
grande carte.

Les actions de suppression restent secondaires.

## 21. Mode entraînement

Le mode entraînement est une rupture visuelle volontaire.

Il privilégie : contenu ; lisibilité ; grandes actions ; distraction
minimale.

Masquer : navigation basse ; commandes d'administration ; informations
techniques.

Afficher : progression ; technique ou texte courant ; média lorsque
pertinent ; Précédent ; Suivant ; Quitter.

Le mode doit fonctionner à plusieurs mètres sur tablette.

Prévoir une taille de texte et des actions adaptées.

Ne pas utiliser un carrousel décoratif complexe.

## 22. Atelier

L'Atelier doit être visuellement plus dense que la Bibliothèque, sans
redevenir un panneau Admin.

**Racine :**

- quatre intentions clairement distinctes ;
- pictogramme sobre ;
- description d'une ligne maximum ;
- problème éventuel.

**Dans une intention :**

- titre ;
- sous-navigation ;
- listes d'actions ;
- indicateurs actionnables.

Éviter : paragraphes introductifs permanents ; cartes imbriquées ;
boutons de même poids pour toutes les opérations.

**Actions sensibles :**

- poids visuel distinct ;
- jamais en action principale par défaut ;
- zone danger lorsque nécessaire.

## 23. Formulaires

Les formulaires doivent être ciblés.

Règles :

- labels persistants ;
- aide courte ;
- erreurs près du champ ;
- champs facultatifs indiqués ;
- clavier adapté ;
- bouton principal clair ;
- annulation disponible.

Ne pas utiliser uniquement des placeholders comme labels.

Les sections avancées restent repliées.

Les formulaires longs doivent être découpés seulement lorsque cela
correspond à de vraies étapes, pas artificiellement.

Éviter les boutons Terminer ; Continuer — lorsque l'action réelle peut
être nommée : Créer ; Ajouter ; Importer ; Restaurer ; Publier ;
Enregistrer.

## 24. Dialogues et panneaux

Utiliser : panneau inférieur pour choix courts sur mobile ; dialogue pour
confirmation ; écran complet pour workflow complexe ; panneau latéral
sur tablette si utile.

Ne pas utiliser un dialogue étroit pour : importer un pack ; éditer une
longue contribution ; inspecter une sauvegarde.

Une confirmation destructive contient : objet ; conséquences ;
possibilité de restauration ; action clairement nommée.

Le bouton dangereux ne doit pas être placé là où l'utilisateur attend le
bouton principal habituel sans distinction.

## 25. États vides

Standardiser les états vides.

Ils contiennent au maximum : titre ; une phrase ; action principale ;
action secondaire éventuelle.

Exemples distincts : bibliothèque vide ; discipline vide ; aucun favori ;
aucune composition ; aucun résultat de filtre ; aucun problème Atelier ;
aucune capture à reprendre.

Ne pas répéter le même texte générique partout.

Ne pas afficher une illustration différente lourde pour chaque cas.

## 26. Chargements

Éviter les écrans blancs ou les spinners globaux lorsque le contenu peut
être affiché progressivement.

Utiliser : skeletons simples ; progression ; état média en cours de
chargement ; indicateur local.

**Import, export, sauvegarde et restauration :**

- progression déterminée lorsque possible ;
- étape courante ;
- volume traité ;
- possibilité d'annuler si sûre.

Ne pas afficher un spinner indéfini pour une opération pouvant durer
plusieurs minutes.

## 27. Feedback et messages

Les confirmations légères utilisent : toast ; message inline ;
changement visuel immédiat.

Exemples : Ajouté aux favoris ; Repère enregistré ; Média ajouté ;
Capture conservée.

Les opérations structurantes utilisent un rapport : import ;
restauration ; publication ; sauvegarde.

Éviter les messages techniques : `Entity updated` ; `OPFS write
successful` ; `Contribution created`.

Les erreurs doivent indiquer : ce qui n'a pas fonctionné ; si les données
sont préservées ; l'action possible.

## 28. Erreurs et alertes

Définir trois niveaux visuels : information ; attention ; erreur ou
danger.

Ne pas utiliser le rouge pour : contenu incomplet facultatif ; absence de
média ; capture à reprendre ; technique sans niveau.

Le rouge est réservé à : intégrité rompue ; suppression ; échec
bloquant ; risque de perte.

Les avertissements doivent être accompagnés d'un texte ou d'une icône
accessible.

## 29. Accessibilité

Respecter au minimum : contraste des textes ; contraste des actions ;
focus clavier visible ; zones tactiles ; libellés lecteurs d'écran ;
ordre de navigation ; alternatives aux gestes ; états non représentés
uniquement par la couleur ; réduction des animations si le système le
demande.

Les vidéos doivent permettre : lecture ; pause ; contrôle du volume
lorsque pertinent ; navigation clavier sur web.

Les glisser-déposer disposent d'une alternative.

Les textes peuvent être agrandis sans rendre l'écran inutilisable.

## 30. Animations

Utiliser des animations courtes pour : ouverture de panneau ; changement
d'onglet ; insertion ou déplacement ; expansion de section ; feedback.

Ne pas utiliser : transitions longues ; parallaxe ; zooms spectaculaires ;
animations permanentes ; effets de rebond excessifs.

Respecter `prefers-reduced-motion`.

Le produit doit rester fluide sur un terminal Android moyen.

## 31. Tablette

La tablette est une cible prioritaire de Movenso.

**Bibliothèque :**

- grille plus dense ;
- filtres accessibles ;
- aperçu ou fiche éventuellement côte à côte si la navigation reste
  compréhensible.

**Fiche :**

- média à gauche ou en largeur maîtrisée ;
- voix et carnet à droite lorsque l'espace le permet ;
- pas d'immense vidéo étirée inutilement.

**Pratique :**

- favoris et compositions dans une grille ;
- mode entraînement lisible à distance.

**Atelier :**

- menu interne à gauche ;
- détail à droite ;
- listes plus denses.

Ne pas simplement agrandir les composants téléphone.

## 32. Paysage

Tester téléphone et tablette en paysage.

La barre basse, les panneaux et les médias ne doivent pas : chevaucher
les zones système ; masquer les actions ; occuper toute la hauteur.

Le mode entraînement doit particulièrement bénéficier du paysage.

Ne pas imposer une seule orientation sauf nécessité technique déjà
validée.

## 33. Identité Movenso

Le nom Movenso doit être visible avec sobriété.

Ne pas répéter le logo sur chaque écran.

L'identité peut reposer sur : contraste coque/contenu ; accent ; forme
simple ; rythme typographique ; traitement des médias.

Ne pas créer dans ce lot un nouveau logo complexe ou une mascotte.

Utiliser le logo existant s'il est suffisamment propre.

Sinon :

- conserver une marque typographique temporaire ;
- documenter le besoin de branding séparé ;
- ne pas ralentir le produit.

## 34. Cohérence des libellés

Faire une passe complète sur les libellés visibles.

Uniformiser : Ajouter une technique ; Ajouter un média ; Nouvelle
composition ; Importer un pack ; Publier un pack ; Créer une
sauvegarde ; Restaurer ; Protéger les modifications ; Protéger les
suppressions.

Éliminer les termes incohérents : pack utilisé comme synonyme de
discipline ; collection non définie ; Capturer pour toute action ;
Retirer sans objet ; Terminer hors workflow ; Club lorsqu'un nom précis
existe ; Admin lorsque Atelier ou Curateur suffit.

Ne pas réécrire les textes métier des contributions.

## 35. CSS et architecture des composants

Éviter un nouveau monolithe CSS.

Organiser : tokens globaux ; styles de coque ; composants primitifs ;
dispositions ; styles propres aux fonctionnalités.

Créer ou consolider des composants réutilisables uniquement lorsqu'ils
portent une vraie cohérence : bouton ; icône ; champ ; badge ; chip ;
carte média ; état vide ; dialogue ; panneau ; barre d'actions ; lecteur ;
grille.

Ne pas transformer chaque élément en composant abstrait générique.

Ne pas déplacer la logique métier dans les composants de design.

## 36. Performance visuelle

Conserver : rendu progressif ; miniatures ; lazy loading ; un seul
lecteur actif ; listes fluides.

Éviter : ombres lourdes ; filtres CSS coûteux ; arrière-plans floutés sur
toute la page ; animations sur de grandes listes ; recalculs de layout à
chaque défilement.

Tester une Bibliothèque avec plusieurs centaines de techniques.

Les changements visuels ne doivent pas dégrader les temps d'ouverture
validés.

## 37. Captures de référence

Créer un corpus de captures de référence pour les écrans clés :
Bibliothèque vide ; racine Bibliothèque ; discipline ; filtres actifs ;
fiche avec média ; fiche multi-voix ; Pratique ; Favoris ; Composition en
édition ; mode entraînement ; Atelier ; diagnostic ; import ; sécurité ;
thème sombre ; téléphone ; tablette.

Ne pas utiliser les captures comme tests uniques.

Elles servent : à détecter les incohérences ; à documenter le produit ;
à comparer les régressions futures.

## 38. Tests de régression visuelle

Ajouter des tests visuels ciblés si l'infrastructure actuelle le permet.

Résolutions minimales : téléphone étroit ; téléphone standard ; tablette
portrait ; tablette paysage ; desktop.

Tester : thème clair ; thème sombre sur quelques écrans principaux ;
texte long ; nom long ; absence de média ; plusieurs sources ; données
vides ; erreur.

Ne pas créer une suite fragile couvrant chaque pixel de chaque écran.

Cibler les structures majeures.

## 39. Limites strictes du lot

Ne pas modifier :

- modèle métier ;
- stockage ;
- format `.movpack` ;
- recherche ;
- règles de rapprochement ;
- sécurité ;
- workflow de capture ;
- logique des compositions ;
- publication ;
- import ;
- restauration ;
- cible Android ;
- PWA ou Electron.

Ne pas ajouter : nouvel écran fonctionnel ; nouvel onglet ; nouvelle
taxonomie ; nouvelle provenance ; nouvelles statistiques ; nouveau rôle.

Toute modification fonctionnelle nécessaire doit être **remontée avant
implémentation**.

## 40. Critères d'acceptation

**Scénario A — identité globale**

1. lancer l'application ;
2. voir une coque sombre cohérente ;
3. voir un contenu clair et visuel ;
4. naviguer dans les trois onglets ;
5. conserver une identité constante ;
6. ne rencontrer aucun écran sombre uniforme sans hiérarchie.

**Scénario B — Bibliothèque**

1. ouvrir une discipline avec plus de cent techniques ;
2. voir une grille média-first ;
3. lire les noms ;
4. utiliser recherche et filtres ;
5. ne pas voir de badges ou actions superflus ;
6. défiler sans perte de fluidité.

**Scénario C — fiche**

1. ouvrir une fiche avec plusieurs voix et médias ;
2. voir le média immédiatement ;
3. identifier la source ;
4. changer de voix ;
5. modifier Mon carnet ;
6. consulter relations et compositions ;
7. ne pas traverser une succession de cartes imbriquées.

**Scénario D — Pratique**

1. ouvrir Pratique avec À reprendre, Favoris et Compositions ;
2. distinguer les trois usages immédiatement ;
3. ouvrir une composition ;
4. l'éditer ;
5. lancer le mode entraînement ;
6. lire l'écran à distance sur tablette.

**Scénario E — Atelier**

1. ouvrir Atelier ;
2. identifier les quatre intentions ;
3. entrer dans Médias et qualité ;
4. traiter un problème ;
5. ouvrir Échanger et protéger ;
6. ne jamais rencontrer de mur de texte ou de tableau de bord décoratif.

**Scénario F — action contextuelle**

1. Bibliothèque → action Ajouter ;
2. Pratique → Nouvelle composition ;
3. Atelier → aucune action générique ;
4. fiche → Ajouter un média ;
5. ne jamais voir Capturer comme bouton universel.

**Scénario G — téléphone**

1. tester portrait et paysage ;
2. utiliser tous les workflows principaux ;
3. ne rencontrer aucun chevauchement ;
4. conserver des zones tactiles suffisantes ;
5. ne pas devoir zoomer.

**Scénario H — tablette**

1. ouvrir Bibliothèque ;
2. voir une densité supérieure au téléphone ;
3. ouvrir une fiche ;
4. exploiter la largeur ;
5. utiliser le mode entraînement ;
6. administrer dans l'Atelier sans écrans inutilement étirés.

**Scénario I — thème sombre**

1. activer le thème sombre ;
2. parcourir les écrans principaux ;
3. vérifier les contrastes ;
4. distinguer les niveaux de surface ;
5. ne pas voir une accumulation de rectangles gris.

**Scénario J — accessibilité**

1. navigation clavier web ;
2. lecteur d'écran sur actions critiques ;
3. réduction des animations ;
4. agrandissement du texte ;
5. alternative au glisser-déposer ;
6. états compréhensibles sans couleur.

## 41. Tests

Ajouter ou adapter les tests pour couvrir :

- trois destinations ;
- action principale unique ;
- absence de Capturer global ;
- thèmes ;
- responsive ;
- zones sûres ;
- affichage de noms longs ;
- états vides ;
- erreurs ;
- sources ;
- provenance ;
- composants principaux ;
- navigation clavier ;
- `prefers-reduced-motion`.

Ajouter une série de tests visuels ciblés.

`npm run verifier` doit être vert.

Une vérification Android réelle est obligatoire sur :

- petit téléphone ;
- téléphone standard ;
- tablette portrait ;
- tablette paysage ;
- thème système clair ;
- thème système sombre ;
- taille de texte agrandie ;
- gestes et retour Android.

## 42. Documentation

Mettre à jour uniquement les documents existants.

`docs/systeme.md` :

- tokens ;
- thèmes ;
- composants ;
- responsive ;
- architecture CSS ;
- règles d'accessibilité.

`docs/workflows.md` :

- mettre à jour les captures ;
- ne pas modifier les flux ;
- vérifier que les schémas correspondent toujours aux écrans.

Créer ou mettre à jour la section de guide visuel existante avec :
principes ; coque ; surfaces ; typographie ; accent ; états ; provenance ;
cartes ; grilles ; actions ; responsive.

Matrice de conservation :

- force visuelle et médias de la V2 conservés ;
- navigation basse V3 conservée ;
- mur sombre uniforme supprimé ;
- accumulation de cartes réduite ;
- panneau Admin V2 non repris ;
- densité tablette renforcée ;
- logique métier inchangée.

`docs/etat.md` :

- lot terminé ;
- écrans couverts ;
- écrans restant à polir ;
- résultats des tests visuels ;
- prochain lot : recette et clôture.

## 43. Livrable

À la fin du lot :

- commit et push dédiés ;
- `npm run verifier` vert ;
- workflow APK vert ;
- APK de recette disponible ;
- corpus complet de captures téléphone et tablette ;
- comparaison avant/après sur les principaux écrans ;
- inventaire des tokens ;
- rapport d'accessibilité ;
- résultats des tests visuels.

Rapport compact :

- fichiers modifiés ;
- composants créés ou consolidés ;
- règles visuelles retenues ;
- éléments V2 réinterprétés ;
- éléments V3 conservés ;
- nombre de valeurs CSS remplacées par des tokens ;
- éventuelles incohérences fonctionnelles découvertes mais non
  modifiées ;
- performances avant et après.

N'anticipe pas le lot 10 Recette finale.

Ne modifie aucun workflow déjà validé.

**La réussite de ce lot se mesure à une chose : Movenso doit sembler
évident à utiliser, professionnel à présenter et suffisamment sobre pour
laisser les gestes, les sources et le savoir martial occuper la première
place.**

---

> **Statut** : texte du LOT 9 reçu **intégralement** (session 22,
> 2026-07-12). Le lot est **spécifié en entier** — reste en attente d'un
> **GO explicite** de Yahya avant toute exécution.

---

# LOT 10 — RECETTE FINALE, STABILISATION ET CLÔTURE DE MOVENSO V3

## Contexte

Les lots 1 à 9 ont défini et implémenté la cible Movenso V3 :

**Lot 1 :** suppression de l'Accueil ; navigation Bibliothèque, Pratique,
Atelier ; démarrage sur la Bibliothèque ; actions contextuelles.

**Lot 2 :** disciplines uniques ; recherche globale ; recherche
multisource ; filtres ; grille visuelle ; discipline vide.

**Lot 3 :** fiche technique média-first ; plusieurs voix ; carnet
personnel ; galerie ; relations et compositions compactes.

**Lot 4 :** création minimale ; capture rapide ; rattachement immédiat ou
différé ; contenus à reprendre ; contribution contextualisée.

**Lot 5 :** Favoris ; À reprendre ; Compositions ; blocs Technique et
Texte ; mode entraînement.

**Lot 6 :** Atelier organisé en quatre intentions ; disciplines et
taxonomies ; diagnostics ; import ; publication ; sauvegarde ;
restauration.

**Lot 7 :** appareil personnel modifiable par défaut ; protections
facultatives ; PIN local ; session curateur ; tablette partagée.

**Lot 8 :** registre média ; format `.movpack` ; intégrité ; transactions ;
sauvegarde complète ; Android et plateformes.

**Lot 9 :** identité graphique ; coque sombre et contenu clair ;
responsive ; accessibilité ; consolidation UX.

Le périmètre produit est maintenant **gelé**.

Ce lot ne sert pas à améliorer la vision, ajouter des fonctions ou
poursuivre une refonte.

Il sert à répondre objectivement à trois questions :

1. les workflows promis fonctionnent-ils réellement ?
2. les données survivent-elles aux opérations et aux incidents prévus ?
3. l'application peut-elle être reprise, construite et recettée par
   quelqu'un d'autre ?

## Objectif unique

Produire une version candidate de Movenso V3 :

- fonctionnellement cohérente ;
- techniquement reproductible ;
- testée de bout en bout ;
- installable sur Android ;
- utilisable hors ligne ;
- restaurable ;
- documentée ;
- sans défaut bloquant connu ;
- accompagnée d'un rapport honnête de ses limites.

Le lot se termine obligatoirement par une décision explicite : **GO** ;
**GO AVEC RÉSERVES** ; **NO-GO**.

## 1. Règles de sécurité du travail

Travailler uniquement sur la branche explicitement approuvée pour
Movenso V3.

Interdictions :

- ne pas modifier `main` directement ;
- ne pas fusionner dans `main` ;
- ne pas effectuer de force-push ;
- ne pas réécrire l'historique ;
- ne pas supprimer une branche distante ;
- ne pas modifier V2 ;
- ne pas publier de release publique ;
- ne pas modifier des secrets CI ;
- ne pas utiliser les données personnelles réelles comme fixtures ;
- ne pas effectuer de test destructif sur l'unique installation de
  l'utilisateur.

Avant toute opération :

- relever la branche courante ;
- relever le dernier commit ;
- vérifier l'état Git ;
- signaler les fichiers non suivis ou modifications préexistantes ;
- créer un point de retour identifié.

Les tests destructifs utilisent : un profil isolé ; une installation de
recette ; des fixtures dédiées ; ou une sauvegarde vérifiée.

## 2. Gel du périmètre

Aucune nouvelle fonctionnalité n'est autorisée.

Sont notamment interdits : nouvel onglet ; nouvel écran métier ; nouvelle
provenance ; nouveau type de composition visible ; nouvelle entité
Collection ; compte utilisateur ; synchronisation ; cloud ;
statistiques ; gamification ; biométrie ; nouvelle cible desktop ;
nouveau modèle d'autorité ; nouvelle taxonomie ; nouveau workflow
d'import.

Une correction est autorisée uniquement si elle :

- répare un comportement déjà promis ;
- empêche une perte de données ;
- corrige une incohérence d'interface ;
- restaure une compatibilité explicitement annoncée ;
- corrige un défaut de sécurité ;
- permet le build, le test ou la reprise.

Toute autre idée rejoint la liste post-V3.

## 3. Exécution en trois sous-étapes

**10A — Audit**

- ne pas effectuer de correction fonctionnelle ;
- exécuter les tests ;
- inspecter les workflows ;
- établir la matrice ;
- classer les anomalies ;
- proposer un plan de correction fermé.

**10B — Stabilisation**

- corriger uniquement les P0 et P1 validés ;
- corriger éventuellement un P2 trivial s'il ne modifie pas le
  périmètre ;
- ajouter un test de non-régression pour chaque défaut corrigé ;
- ne pas refondre les zones voisines.

**10C — Recette finale**

- repartir d'un build propre ;
- exécuter la matrice complète ;
- produire les artefacts ;
- documenter les preuves ;
- rendre la décision Go/No-Go.

Un commit distinct est attendu après chacune des trois sous-étapes.

## 4. Classification des anomalies

**P0 — Bloquant absolu**

Exemples : perte ou corruption de données ; application impossible à
lancer ; build impossible ; sauvegarde prétendument réussie mais
inutilisable ; restauration détruisant l'état existant ; média supprimé
alors qu'il reste utilisé ; secret stocké en clair ; action destructive
sans confirmation ; APK inutilisable.

Décision : correction obligatoire ; No-Go tant que présent.

**P1 — Majeur**

Exemples : workflow principal incomplet ; impasse utilisateur ; retour
Android cassé ; import ou export courant impossible ; capture perdue
après interruption prévue ; fiche ou composition inutilisable ;
protection contournable depuis un point d'entrée normal ; régression
importante par rapport à une capacité validée.

Décision : correction obligatoire avant Go.

**P2 — Modéré**

Exemples : information secondaire incorrecte ; mise en page dégradée
dans un cas non bloquant ; texte ambigu ; diagnostic incomplet ;
performance médiocre sur un corpus extrême ; compatibilité partielle
clairement annoncée.

Décision : correction uniquement si courte et sans risque ; sinon
réserve documentée.

**P3 — Mineur**

Exemples : détail graphique ; animation ; alignement ; optimisation
facultative ; amélioration de confort.

Décision : ne pas corriger dans ce lot ; enregistrer dans le backlog.

## 5. Lot 10A — état initial

Avant toute correction, produire un état initial comprenant :

- branche ;
- commit ;
- version applicative ;
- version du modèle ;
- version du format `.movpack` ;
- version Node ;
- version npm ;
- version Java ;
- version Android SDK ;
- version Capacitor ;
- système d'exploitation de build ;
- état de Git ;
- liste des commandes disponibles.

Exécuter au minimum : installation propre des dépendances ; typecheck ;
lint si présent ; tests unitaires ; tests d'intégration ; E2E ; tests
visuels ciblés ; build web ; build Android ; génération des packs de
démonstration ; inspection d'un `.movpack`.

Ne pas modifier le code pour faire disparaître un échec pendant cette
étape.

Consigner chaque résultat.

## 6. Matrice des capacités

Créer ou mettre à jour une matrice unique avec les statuts suivants :
Démontré automatiquement ; Démontré manuellement ; Partiellement
démontré ; Non démontré ; Échec ; Non applicable.

Chaque ligne doit inclure : capacité ; lot d'origine ; test ou scénario ;
plateforme ; preuve ; anomalie éventuelle ; décision.

Capacités minimales :

**Navigation :** démarrage Bibliothèque ; trois onglets ; retour
Android ; conservation des états.

**Bibliothèque :** discipline vide ; recherche globale ; multisource ;
filtres cumulables ; absence de doublons.

**Fiche :** média principal ; plusieurs voix ; carnet ; plusieurs
médias ; relations ; compositions utilisatrices.

**Création :** technique minimale ; capture ; rattachement ; capture à
reprendre ; création depuis capture ; annulation.

**Pratique :** Favoris ; À reprendre ; composition ; réordonnancement ;
mode entraînement.

**Atelier :** discipline ; taxonomie ; diagnostics ; import ; publication ;
sauvegarde ; restauration.

**Sécurité :** appareil personnel ; protections séparées ; PIN ;
expiration ; tablette partagée ; action destructive.

**Technique :** média partagé ; déduplication ; `.movpack` ; intégrité ;
transaction ; restauration vierge ; mise à jour Android.

**UX :** téléphone ; tablette ; paysage ; thème clair ; thème sombre ;
accessibilité essentielle.

## 7. Corpus de recette

Préparer des jeux de données non personnels.

**A. Installation vide** — aucune discipline ; aucun réglage ; aucun
PIN.

**B. Corpus personnel minimal** — une discipline ; trois techniques ; un
média ; un repère ; un favori ; une composition.

**C. Corpus multisource** — une même identité avec au moins deux voix ;
référentiel ; enseignement ; personnel ; médias distincts ; relations.

**D. Corpus volumineux** — plusieurs centaines de techniques ; plusieurs
sources ; au moins vingt médias ; volume média défini au lot 8 ;
compositions longues.

**E. Corpus dégradé contrôlé** — média manquant ; miniature absente ;
référence de composition indisponible ; taxonomie utilisée ; capture non
rattachée.

**F. Formats historiques** — fixture V2 réellement représentative ; JSON
historique V3 ; ancien `.movpack` ; format courant.

**G. Conteneurs invalides** — manifeste absent ; version future ; JSON
invalide ; média corrompu ; hash incorrect ; ZIP tronqué ; fichier
supplémentaire non attendu.

Ne jamais construire les preuves uniquement autour du pack heureux.

## 8. Recette du démarrage

**Scénario installation vide**

1. installer ;
2. lancer ;
3. arriver sur Bibliothèque ;
4. voir les deux actions prévues ;
5. créer une discipline ;
6. créer la première technique ;
7. fermer complètement ;
8. relancer ;
9. retrouver la discipline.

**Scénario avec données**

1. lancer ;
2. arriver sur la destination configurée ;
3. naviguer dans les trois onglets ;
4. fermer depuis Bibliothèque ;
5. relancer ;
6. vérifier l'état attendu.

**Scénario migration**

1. installer une version précédente compatible ;
2. créer des données ;
3. mettre à jour l'APK ;
4. lancer ;
5. appliquer la migration ;
6. vérifier les données et médias.

## 9. Recette Bibliothèque

Vérifier : une discipline par art martial ; packs non affichés comme
disciplines ; compte des identités uniques ; recherche nom ; recherche
alias ; recherche dans Mon carnet ; recherche multisource sans doublon ;
filtre source ; filtre niveau ; filtre famille ; filtres cumulés ; état
aucun résultat ; réinitialisation ; retour fiche vers position
précédente ; changement d'onglet et restauration.

Tester : nom long ; technique sans média ; technique à plusieurs voix ;
source sans nom parfait ; plusieurs centaines de cartes ; hors ligne.

## 10. Recette fiche technique

Vérifier : média principal immédiatement visible ; fallback propre ;
lecture vidéo locale ; lien distant hors connexion ; galerie ;
changement de média principal ; sources lisibles ; plusieurs voix non
fusionnées ; contribution importée protégée ; Mon carnet éditable ;
recherche actualisée après édition ; ajout de plusieurs médias ; média
manquant ; relations ; navigation vers une technique liée ; compositions
utilisatrices ; favori ; retrait sécurisé.

Aucun identifiant interne ne doit apparaître dans l'interface normale.

## 11. Recette création et capture

Vérifier : création avec nom seul ; classification facultative ;
suggestion de doublon ; absence de fusion automatique ; caméra ; fichier ;
lien ; texte ; rattachement à une technique ; création depuis capture ;
provenance personnelle par défaut ; enseignement attribué ; garder pour
plus tard ; fermeture et relance ; reprise ; abandon ; nettoyage ; refus
de permission Android ; interruption en arrière-plan ; mode hors ligne.

Aucun contenu validé ne doit disparaître après un retour Android normal.

## 12. Recette Pratique

**Favoris :** ajouter ; ouvrir ; revenir ; retirer ; restaurer.

**À reprendre :** afficher uniquement une action réelle ; rattacher ;
créer ; supprimer ; disparaître après résolution.

**Compositions :** créer avec titre seul ; ajouter technique ; ajouter
texte ; réordonner ; modifier ; dupliquer ; supprimer ; relancer ; mode
entraînement ; ouvrir une fiche ; revenir au bon bloc ; technique
indisponible ; export ; import ; restauration.

Tester une composition d'au moins cinquante blocs.

## 13. Recette Atelier

**Construire :** créer discipline ; renommer ; retirer une discipline
vide ; bloquer une suppression incohérente ; créer et réordonner les
taxonomies ; contrôler leurs usages ; gérer les types de relation.

**Médias et qualité :** média manquant ; média orphelin ; média partagé ;
miniature ; contribution sans auteur ; rapprochement ambigu ; référence
de composition invalide.

**Échanger et protéger :** import valide ; annulation avant mutation ;
import corrompu ; rapport ; publication filtrée ; exclusion du
personnel ; sauvegarde complète ; restauration ; rollback.

**Réglages :** démarrage ; thème ; protection ; fallback d'une
destination supprimée.

## 14. Recette sécurité

**Appareil personnel :** aucune demande de PIN ; modification directe ;
confirmation destructive conservée.

**Protection des modifications :** activation ; création du PIN ; action
protégée ; annulation ; déverrouillage ; session ; expiration.

**Protection des suppressions :** modification libre si configurée
ainsi ; PIN avant destruction ; confirmation après PIN ; sauvegarde
préalable.

**Tablette partagée :** consultation libre ; médias lisibles ; mode
entraînement utilisable ; modifications protégées ; arrière-plan
verrouillant ; verrouillage manuel.

Vérifier : aucun PIN en clair ; aucune valeur secrète dans les logs ;
aucun secret dans un pack publié ; restauration ne transportant pas
automatiquement le secret ; temporisation après erreurs ; changement du
PIN ; désactivation ; réinitialisation.

## 15. Recette médias

Cas obligatoires : même fichier utilisé deux fois ; retrait de la
première référence ; fichier encore disponible ; retrait de la dernière
référence ; statut orphelin ; suppression après confirmation ;
restauration selon la stratégie documentée.

**Déduplication :** deux imports du même fichier ; même empreinte ; une
seule copie physique ; plusieurs références logiques.

**Échec :** quota ; interruption ; fichier non lisible ; type incorrect ;
média absent ; registre incohérent.

Après chaque échec : état métier valide ; aucun média fantôme ; aucun
fichier temporaire non diagnostiqué ; possibilité de reprendre ou
nettoyer.

## 16. Recette `.movpack`

Pour chaque conteneur courant : vérifier signature ZIP ; lire le
manifeste ; valider version ; valider inventaire ; valider tailles ;
valider empreintes ; vérifier les médias ; importer ; comparer les
données.

Tester : pack publié ; sauvegarde complète ; export de composition ;
format historique ; version future ; corruption ; fichier manquant ;
fichier supplémentaire ; média modifié ; JSON brut.

Un import refusé ne doit produire aucune mutation visible.

## 17. Recette sauvegarde et restauration

**Scénario de référence**

1. créer plusieurs disciplines ;
2. ajouter plusieurs sources ;
3. ajouter vidéos et notes ;
4. ajouter Favoris ;
5. créer Compositions ;
6. créer une capture à reprendre ;
7. créer une sauvegarde complète ;
8. inspecter son manifeste ;
9. désinstaller l'application de recette ;
10. réinstaller ;
11. restaurer ;
12. comparer l'état.

Comparer au minimum : disciplines ; identités ; contributions ; sources ;
taxonomies ; relations ; médias ; Favoris ; Compositions ; blocs et
ordre ; captures à reprendre ; paramètres fonctionnels annoncés.

Lire réellement plusieurs vidéos après restauration.

Une simple égalité des compteurs ne suffit pas.

## 18. Recette publication

Créer un pack de club contenant uniquement les données maîtrisées.

Vérifier : auteur ; organisation ; version ; discipline ; contributions
sélectionnées ; médias sélectionnés ; relations valides ; aucune note
personnelle ; aucun favori ; aucune capture à reprendre ; aucun PIN ;
aucune sauvegarde ; aucune contribution tierce non sélectionnée.

Importer le pack sur une installation vierge.

Vérifier que le corpus reste utilisable sans les données privées de
l'émetteur.

## 19. Recette Android

Construire depuis un environnement propre.

Tester sur appareil réel : installation ; premier lancement ;
permissions ; caméra ; sélection de fichiers ; partage ; import depuis
Files ; retour Android ; clavier ; arrière-plan ; orientation ; mise à
jour APK ; désinstallation ; restauration ; hors ligne ; tablette si
disponible.

Relever : modèle de terminal ; version Android ; taille écran ;
orientation ; résultat.

Ne pas déclarer Android validé uniquement sur émulateur.

## 20. Recette web et plateformes

**Navigateur desktop :** lancement ; stockage ; import ; export ; lecture
média ; clavier ; hors ligne selon capacité réelle.

**PWA :** tester uniquement si elle est déclarée livrée ; installation ;
lancement hors ligne ; mise à jour ; stockage.

**Windows/Electron :** tester uniquement si réellement livré ; sinon
maintenir le statut `absent` ou `différé`.

La matrice de plateformes doit correspondre aux preuves.

## 21. Recette visuelle

Résolutions minimales : petit téléphone ; téléphone standard ; tablette
portrait ; tablette paysage ; desktop.

États : clair ; sombre ; système ; texte agrandi ; réduction des
animations ; nom long ; contenu vide ; contenu riche ; erreur ; média
manquant.

Vérifier : aucun chevauchement ; aucune action sous la barre système ;
aucune carte coupée ; aucun bouton inaccessible ; navigation basse
stable ; une seule action principale ; pas de Capturer global ; Atelier
sans mur de texte ; grille média-first ; mode entraînement lisible à
distance.

## 22. Accessibilité

Vérifier au minimum : focus visible ; navigation clavier ; libellé des
actions ; boutons iconiques accessibles ; contraste ; taille tactile ;
erreur annoncée ; état ouvert des accordéons ; alternatives au
glisser-déposer ; contenu compréhensible sans couleur ; réduction des
animations.

Documenter les limites restantes.

Ne pas déclarer une conformité complète à un référentiel sans audit
dédié.

## 23. Performance

Établir une ligne de base avant correction : lancement ; ouverture
Bibliothèque ; recherche ; filtrage ; ouverture fiche ; galerie ;
ouverture Pratique ; réordonnancement ; ouverture Atelier ; export ;
restauration.

Mesurer sur : petit corpus ; corpus volumineux ; appareil Android réel
lorsque possible.

Règles : aucune opération interactive longue sans feedback ; aucune
vidéo complète chargée pour une simple miniature ; un seul lecteur
actif ; export à mémoire bornée ; pas de régression manifeste après les
corrections.

Ne pas effectuer une optimisation générale sans anomalie démontrée.

## 24. Nettoyage avant release

Retirer du build de production : logs de débogage excessifs ; secrets ou
valeurs de test ; routes mortes visibles ; boutons factices ; données
personnelles ; fichiers de test lourds ; JSON de développement présentés
comme contenu produit ; dépendances inutilisées manifestes ; feature
flags abandonnés ; textes `TODO` visibles ; identifiants internes
affichés.

Ne pas supprimer : fixtures nécessaires aux tests ; migrations
historiques ; lecteurs rétrocompatibles ; diagnostics utiles.

Faire la distinction entre : code mort prouvé ; code de compatibilité.

## 25. Lot 10A — rapport d'audit

À la fin de 10A, produire : résultats de toutes les commandes ; matrice
des capacités ; liste des anomalies ; sévérité ; reproduction ; lot
concerné ; données touchées ; proposition de correction ; risque de
correction ; estimation relative ; décision recommandée.

Ne corriger aucun P2 ou P3 pendant l'audit.

S'arrêter après le rapport 10A.

**La suite ne commence qu'après validation humaine du plan fermé de
P0/P1.**

## 26. Lot 10B — règle de correction

Pour chaque P0 ou P1 validé :

1. ajouter ou isoler un scénario reproductible ;
2. identifier la cause racine ;
3. proposer la correction minimale ;
4. vérifier les données existantes ;
5. implémenter ;
6. ajouter le test de non-régression ;
7. exécuter les tests voisins ;
8. documenter ;
9. committer.

Ne pas profiter d'un bug pour : renommer toute une architecture ;
déplacer plusieurs modules ; remplacer une bibliothèque ; réécrire un
workflow ; modifier le modèle hors nécessité.

Une modification de modèle exige : migration ; test d'ancienne donnée ;
justification ; preuve de non-perte.

## 27. Critères de sortie de 10B

10B peut se terminer lorsque : aucun P0 ouvert ; aucun P1 ouvert ; tests
de non-régression ajoutés ; build propre ; données de fixtures migrées ;
APK produit ; matrice mise à jour.

Les P2 et P3 restent dans un backlog séparé.

Ne pas les corriger pour obtenir artificiellement une liste vide.

## 28. Lot 10C — recette à blanc

Repartir de zéro : nouveau clone ou espace propre ; installation
propre ; aucune donnée de développement ; génération des artefacts ;
installation APK ; jeu de recette versionné.

Exécuter la totalité des scénarios critiques sans intervenir dans le
code.

Toute correction pendant cette phase :

- invalide la recette ;
- nécessite un nouveau commit ;
- impose de relancer les scénarios affectés ;
- produit une nouvelle version candidate.

## 29. Scénarios critiques de bout en bout

**Scénario 1 — installation vide**

```
installation
→ Bibliothèque
→ créer discipline
→ créer technique
→ ajouter média
→ relancer.
```

**Scénario 2 — import multisource**

```
importer référentiel
→ importer club
→ identité réunie
→ deux voix
→ recherche
→ filtre source.
```

**Scénario 3 — pratique personnelle**

```
ouvrir fiche
→ ajouter repère
→ favori
→ composition
→ mode entraînement
→ retour fiche.
```

**Scénario 4 — capture terrain**

```
filmer
→ garder pour plus tard
→ fermer
→ relancer
→ rattacher
→ lire sur la fiche.
```

**Scénario 5 — tablette partagée**

```
activer protections
→ consulter
→ tenter modification
→ déverrouiller
→ modifier
→ expiration.
```

**Scénario 6 — publication**

```
sélectionner source maîtrisée
→ prévisualiser
→ publier
→ importer sur installation vierge
→ vérifier les exclusions.
```

**Scénario 7 — perte de l'installation**

```
sauvegarder
→ désinstaller
→ réinstaller
→ restaurer
→ lire médias
→ utiliser composition.
```

**Scénario 8 — corruption**

```
modifier un fichier du conteneur
→ importer
→ refus
→ état existant inchangé.
```

**Scénario 9 — mise à jour**

```
installer version précédente
→ créer données
→ installer candidate
→ migrer
→ vérifier.
```

**Scénario 10 — média partagé**

```
deux références
→ retirer une
→ média conservé
→ retirer la dernière
→ diagnostic orphelin
→ suppression confirmée.
```

## 30. Critères GO

La décision `GO` exige :

- aucun P0 ;
- aucun P1 ;
- tous les scénarios critiques réussis ;
- build reproductible ;
- APK installable ;
- navigation Android correcte ;
- sauvegarde complète démontrée ;
- restauration complète démontrée ;
- intégrité `.movpack` démontrée ;
- import corrompu sans mutation ;
- absence de secret en clair ;
- publication filtrée ;
- données conservées après mise à jour ;
- documentation alignée sur le réel ;
- plateforme annoncée réellement démontrée.

## 31. Critères GO AVEC RÉSERVES

`GO AVEC RÉSERVES` est possible uniquement si :

- aucun P0 ;
- aucun P1 ;
- uniquement des P2 connus ;
- aucune réserve ne concerne la perte de données ;
- aucune réserve ne concerne la sécurité du PIN ;
- aucune réserve ne concerne la restauration annoncée ;
- les limites sont visibles et documentées ;
- une solution de contournement existe.

Exemples possibles : PWA différée ; Windows portable absent ; aperçu
d'un service distant indisponible hors ligne ; import d'un format
historique partiel et clairement annoncé.

## 32. Critères NO-GO

Décision `NO-GO` si au moins un élément persiste : P0 ; P1 ; corruption ;
perte média ; sauvegarde inutilisable ; restauration non démontrée ;
import partiel invisible ; action destructive non maîtrisée ; protection
facilement contournable ; APK non reproductible ; migration cassée ;
workflow essentiel en impasse ; documentation affirmant une capacité non
démontrée.

Ne pas maquiller un No-Go en réserve.

## 33. Version et identification de la candidate

Produire une version candidate identifiable.

Utiliser le schéma déjà adopté par le projet.

À défaut : version applicative cohérente ; versionCode Android
incrémenté ; suffixe de candidate explicite ; commit associé ; date ;
version du modèle ; version du format.

Ne pas créer arbitrairement une version publique majeure.

Le rapport doit permettre d'associer sans ambiguïté : code ; APK ; packs
de démonstration ; documentation ; résultats de recette.

## 34. Artefacts finaux

Produire : build web ; APK debug de recette ; APK ou AAB release
uniquement si la chaîne de signature est disponible ; `.movpack` de
démonstration ; sauvegarde de démonstration ; export de composition ;
fixtures historiques ; rapport de tests ; matrice des capacités ;
matrice des plateformes ; rapport Go/No-Go ; checksums des artefacts
livrés.

Ne jamais inclure : keystore ; mot de passe ; secret CI ; données
personnelles ; PIN réel.

## 35. Documentation de reprise

Une personne ne connaissant pas le projet doit pouvoir en moins de trente
minutes :

1. comprendre le but de Movenso ;
2. cloner ;
3. installer ;
4. lancer ;
5. tester ;
6. construire le web ;
7. construire Android ;
8. importer un pack ;
9. créer une sauvegarde ;
10. comprendre les limites des plateformes.

Mettre à jour :

**README :** présentation ; prérequis ; commandes ; builds ; données ;
artefacts ; limitations.

**`docs/systeme.md` :** architecture réelle ; modèle ; stockage ;
médias ; transactions ; sécurité ; plateformes.

**`docs/workflows.md` :** workflows réellement démontrés ; captures à
jour ; niveaux de preuve.

**`docs/etat.md` :** version candidate ; résultat final ; anomalies
ouvertes ; décision ; prochaine étape éventuelle.

Matrice de conservation : capacités V2 conservées ; capacités V3
ajoutées ; capacités différées ; capacités abandonnées ; justification.

## 36. Documentation des limites

Créer une liste compacte et honnête.

Exemples : Windows portable non livré ; PWA non livrée ; snapshot ne
contenant pas les médias ; import V2 partiel ; taille maximale non
garantie ; lien externe non disponible hors ligne ; absence de
chiffrement complet.

Chaque limite contient : impact ; contournement ; risque ; priorité
future.

Ne pas dissimuler une limite dans un journal technique.

## 37. Backlog post-V3

Déplacer toutes les idées non nécessaires dans un backlog séparé.

Classer : dette critique future ; amélioration produit ; plateforme ;
confort ; recherche.

Ne pas inclure automatiquement toutes les suggestions accumulées.

Chaque entrée doit répondre à : quel problème réel ? qui est concerné ?
preuve ou observation ? pourquoi après V3 ? dépendances ?

Le backlog ne doit pas devenir une nouvelle roadmap exécutée pendant ce
lot.

## 38. Rapport final

Le rapport final commence par : version ; commit ; branche ; date ;
décision ; résumé en dix lignes maximum.

Puis :

**A. Capacités démontrées**

**B. Tests automatiques** — nombre ; résultats ; durées ; échecs
éventuels.

**C. Recette manuelle** — appareils ; plateformes ; scénarios ; preuves.

**D. Données** — import ; export ; sauvegarde ; restauration ;
intégrité ; migrations.

**E. Sécurité** — protections ; secret ; exports ; limites.

**F. Performances** — corpus ; observations ; limites.

**G. Anomalies restantes** — P2 ; P3 ; contournements.

**H. Comparaison avec V2** — objectivement supérieure ; équivalente ;
encore inférieure ; non comparable.

**I. Recommandation** — continuer V3 ; exploiter V3 avec réserves ;
revenir sur V2 ; différer une plateforme.

Ne pas conclure automatiquement que V3 est supérieure parce que les lots
sont terminés.

## 39. Comparaison finale V2 / V3

Comparer sur des preuves, pas sur l'architecture théorique.

Dimensions minimales : exploration ; médias ; capture ; création ;
personnalisation ; multisource ; provenance ; compositions ; curation ;
import/export ; sauvegarde/restauration ; Android ; Windows ; hors
ligne ; sécurité ; maintenance ; reprise du projet.

Pour chaque dimension : V2 ; V3 ; preuve ; gagnant actuel ; réserve.

La conclusion peut être : V3 supérieure globalement ; V3 supérieure sur
le modèle mais pas encore sur l'exploitation ; V2 encore supérieure
comme produit opérationnel ; choix dépendant de la plateforme.

Ne pas forcer un résultat favorable à V3.

## 40. Limites strictes du lot

Ne pas :

- ajouter de fonctionnalité ;
- changer la vision ;
- refondre le modèle ;
- refaire l'UX ;
- introduire une plateforme ;
- réorganiser les dossiers pour esthétique ;
- remplacer une dépendance sans nécessité ;
- modifier V2 ;
- fusionner dans main ;
- publier une release publique.

Les seules modifications autorisées sont : corrections P0/P1 validées ;
tests de non-régression ; documentation ; nettoyage strictement
nécessaire ; préparation d'artefacts.

## 41. Critères d'acceptation du lot

Le lot 10 est terminé uniquement lorsque :

- 10A est documenté ;
- le plan de corrections a été validé ;
- 10B ne contient aucun P0/P1 ouvert ;
- 10C a été exécuté depuis un environnement propre ;
- les dix scénarios critiques réussissent ;
- l'APK est disponible ;
- les sauvegardes et restaurations sont démontrées ;
- les artefacts sont identifiés ;
- les matrices sont à jour ;
- les limites sont explicites ;
- le rapport Go/No-Go est rendu ;
- aucune modification non committée ne subsiste.

## 42. Livrable

Produire trois commits dédiés :

- `lot-10a-audit`
- `lot-10b-stabilisation`
- `lot-10c-recette`

Adapter les messages aux conventions existantes du dépôt.

Ne pas fusionner.

Livrables finaux :

- APK de recette ;
- build web ;
- packs de démonstration ;
- sauvegarde démonstrative ;
- checksums ;
- matrice des capacités ;
- matrice des plateformes ;
- rapport de recette ;
- rapport V2/V3 ;
- décision Go/No-Go ;
- backlog hors périmètre.

**La réussite de ce lot se mesure à une chose : une personne extérieure
au développement peut installer Movenso, l'utiliser, lui confier des
données, sauvegarder ces données, perdre l'installation, les restaurer
et comprendre précisément ce qui est fiable, ce qui reste limité et
pourquoi la version peut — ou non — être retenue comme nouvelle base du
produit.**

---

> **Statut** : texte du LOT 10 reçu **intégralement** (session 22,
> 2026-07-12). Le lot est **spécifié en entier** — reste en attente d'un
> **GO explicite** de Yahya avant toute exécution.
>
> **LOT 10 est le lot de clôture** : il ne référence aucun lot suivant.
> À ce stade, la roadmap couvre l'intégralité du périmètre V3 tel que
> dicté par Yahya (session 22) — des lots 1 à 10.
