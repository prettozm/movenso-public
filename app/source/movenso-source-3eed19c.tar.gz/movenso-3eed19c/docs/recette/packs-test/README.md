# Packs de test — import & bibliothèque

Packs `.movpack` fournis par le porteur (2026-07-23) pour préparer une série
d'**ajustements sur l'import de pack et la bibliothèque** (à traiter en session
suivante). Mis de côté ici pour survivre au conteneur éphémère. **D'autres
suivront.**

Tous : `format movpack`, `version 4`, `versionSchema 3`, `portée discipline`,
**sans médias ni contenu personnel** (référentiels purs).

| Fichier | Contenu | Disciplines | Techniques |
| --- | --- | --- | --- |
| `karate-shotokan.movpack` | Karaté Shotokan — référentiel FFK | 1 | 109 |
| `jujitsu-france-judo.movpack` | Jujitsu — référentiel France Judo | 1 | 162 |
| `jjb-gi-nogi.movpack` | Jiu-jitsu brésilien — Gi & No-Gi | 1 | 150 |
| `taiso-france-judo.movpack` | Taïso — préparation du corps (France Judo) | 1 | 114 |
| `taiso-12-seances.movpack` | Taïso — 12 séances prêtes à dérouler (portée **composition**) | 1 | 95 |

> `taiso-12-seances.movpack` : portée **composition** — porte **12 séances**
> minutées (14 à 33 blocs, 30–41 min) + 95 techniques support. Idéal pour la
> recette du **pas-à-pas / chrono de séance** (D-125).

| `yoga-hatha-accessible.movpack` | Yoga — Hatha accessible | 1 | 72 |
| `yoga-12-seances.movpack` | Yoga — 12 séances guidées (portée **composition**) | 1 | 62 |

> `yoga-12-seances.movpack` : portée **composition** — 12 séances guidées + 62
> techniques support. Même schéma que le taïso (discipline + séances séparées) :
> à la distribution, l'export de la discipline « Yoga » embarque automatiquement
> les séances jouables (D-127 boucle 4) — pas de fusion manuelle nécessaire.

> Usage : jeux d'essai pour la recette d'import (rapprochement d'identités,
> volumétrie, affichage bibliothèque). Ne pas modifier — ce sont les originaux
> transmis.
