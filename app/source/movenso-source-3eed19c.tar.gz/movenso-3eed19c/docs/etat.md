# État de mission — Movenso V3

> **➡️ CE DOCUMENT A ÉTÉ REMPLACÉ (2026-07-24, D-128).** Le **présent** (phase
> courante, prochaines actions, réserves) vit désormais **uniquement** dans
> **[execution/STATE.md](execution/STATE.md)**. Ce fichier est **figé** : il
> conserve l'état de la mission tel qu'il était à la fin de la phase de
> conception (lots 1-10), comme mémoire historique. Ne plus l'écrire, ne plus
> s'y fier pour l'état courant.
>
> Architecture réelle : [systeme.md](systeme.md) · règles et carte documentaire :
> [conventions.md](conventions.md) §2.

> **Type : figé (historique — clôturé le 2026-07-24)** · Ancien document de
> pilotage (D-014), remplacé par `execution/STATE.md`.

**Dernière mise à jour** : 2026-07-12 (session 22 — **GO donné, exécution
autonome lancée**). La roadmap (LOTS 1 à 10, dictés intégralement) est la
commande de travail ; le protocole d'exécution vit désormais dans
**`CLAUDE.md` (remplacé) + `docs/execution/`** (MASTER/STATE/DECISIONS/
QUALITY + lots). L'ancien protocole de conception est archivé dans
`docs/archives/CLAUDE-protocole-conception.md` et sera **restauré une
fois la roadmap terminée** (décision Yahya, session 22). Pendant
l'exécution, la mémoire opérationnelle est `docs/execution/STATE.md` ;
etat.md reste la mémoire de mission, mise à jour aux checkpoints de
lots.

**Fils conducteurs permanents** : *synthèse, pas arbitrage* (D-012 — toute
qualité dégradée l'est par décision tracée, matrice increment-1.md §6bis) ·
*désirabilité* (D-009 — faire ressentir, pas expliquer ; l'ajout de
fonctionnalités n'est pas une réponse automatique au manque de valeur, D-019) ·
*réversibilité jusqu'à la recette tatami* (D-011) · *la question des dix ans*
(D-009) · *hypothèse en maturation* : Movenso comme **mémoire externe du
savoir martial incarné** — retrouver, se souvenir, réutiliser — candidate à la
question des dix ans, à laisser mûrir sans la fabriquer (D-016, D-019).

## Ajustements post-V3 (branche `feat/v3-ajustements`, 2026-07-13)

Après validation de la V3 comme nouvelle base (fusion dans `main`), un lot
d'ajustements produit est mené sur `feat/v3-ajustements` (hors roadmap 1-10,
close). Arbitrage humain **D-067 à D-070** :

- **Fin de la fusion automatique (D-067).** Deux packs de même nom → deux
  identités distinctes, chacune liée à son pack (consultable/modifiable/
  supprimable/exportable indépendamment). La réunion d'identités ne se fait plus
  que par une règle explicite ou l'outil « Doublons potentiels ». Réimport
  toujours idempotent ; disciplines toujours rejointes par nom. Domaine :
  `src/domaine/rapprochement.ts` (seule la jonction automatique par nom est
  retirée). Tests domaine réalignés (rapprochement, assemblage, composition,
  resume-discipline) — `npm test` vert.
- **Bibliothèque unifiée (D-068).** La racine affiche toutes les techniques de
  toutes les disciplines ; discipline = filtre (Toutes/…) au même titre que
  source, famille, niveau ; grille deux colonnes ; vignette avec aperçu, source,
  nom, famille, niveau et **cœur favori actionnable sans ouvrir la fiche** ; plus
  aucun vocabulaire « voix »/« contributions ». `src/app/vues.ts` (racine +
  écran discipline unifiés), `src/app/racine.ts` (filtres), `src/styles/app.css`.
- **Fiche mono-pack (D-069).** Hiérarchie V2 : nom + famille, actions compactes
  (modifier, favori, partager, fermer), niveaux, sélecteur de média horizontal,
  un média à la fois, présentation, points clés, relations, carnet à la demande.
  Fin de la fiche composite multisource, des textes de provenance, de la
  réimportation et de « créer une adaptation locale ». **Partage natif** (Web
  Share API, repli téléchargement) d'un `.movpack` individuel, avec ou sans
  vidéo : `partagerTechnique` + `extrairePackTechnique`.
- **Doublons potentiels (D-070).** Détection non bloquante des homonymies
  inter-packs, présentée dans l'Atelier (Médias et qualité) : par paire, noms +
  aperçu + différences ; quatre décisions (conserver les deux ; garder A ou B
  avec sauvegarde préalable ; fusion sélective sans empilement ni média
  dupliqué, origine conservée en interne) ; marquage « pas des doublons »
  persistant. `src/domaine/doublons.ts`, section Atelier, champ optionnel
  `doublonsIgnores` (sans migration de schéma). Tests : `tests/doublons.test.ts`.

- **Navigation à quatre onglets + « Plus » (D-071, 2026-07-14).** La barre
  basse devient Bibliothèque · Favoris · Compositions · Plus. « Pratique »
  disparaît : Favoris (grille deux colonnes, retrait depuis la carte, état vide
  simple) et Compositions deviennent des onglets ; « à rattacher » rejoint
  Plus › Médias. « Atelier » devient « Plus » — un menu simple (sections
  nommées, lignes icône + titre + valeur d'état + chevron), sans accordéons ni
  vocabulaire interne, chaque ligne ouvrant un sous-écran spécialisé. Toutes les
  capacités de l'Atelier sont ré-homées : Packs et disciplines · Doublons
  potentiels (liste compacte → détail) · Médias · Relations entre techniques ·
  Importer un pack · Créer ou exporter un pack · Sauvegardes · Sécurité ·
  Apparence · Diagnostic et maintenance. Aucune capacité retirée, aucun
  changement du modèle ni des mécanismes. Fichiers : `src/app/plus.ts` (menu +
  sous-écrans), `src/app/vues.ts` (`gabaritFavoris`), `src/app/atelier.ts`
  (builders `ecran*` exportés, accordéons retirés), `src/app/racine.ts` (Ecran,
  zones, onglets, dispatch), `src/app/compositions.ts` (racine), suppression de
  `src/app/pratique.ts`.

- **Pseudo + clarté des sous-écrans (D-072, 2026-07-14).** Un pseudo d'appareil
  (`preferences.pseudo`, jamais exporté) signe le contenu local (« Mon contenu »
  → le pseudo ; badge sur les fiches locales), saisi dans Plus › Packs et
  disciplines › Sources. « Sources et auteurs » → « Sources » sans jargon (nom +
  nombre de techniques). Disciplines : rangée de puces → une seule fiche de
  gestion affichée (tient à dix disciplines), plus d'empilement. Liste de gestion
  des techniques : discipline · famille. Fichiers : `atelier.ts`
  (`ecranPacksDisciplines`, `sectionSources`, `sectionTechniquesGestion`),
  `vues.ts` (badge pseudo), `racine.ts` (`changerPseudo`, `disciplineGestion`),
  `opfs.ts` (`Preferences.pseudo`).

- **Premier jet de tuning UI (D-073, 2026-07-14).** Passe présentation/interaction,
  sans réécriture du modèle (une seule addition optionnelle `Contribution.modifiePar`,
  sans migration) ni des mécanismes.
  - *Bibliothèque* : vignettes sans source ; filtres Discipline · Catégorie ·
    Niveau ; cœur `iconeCoeur` ; niveau sous le nom secondaire ; devise revue.
    (`src/app/vues.ts`).
  - *Fiche — toute source éditable (révise D-027)* : l'édition en place vaut aussi
    pour un contenu de pack ; l'`origine` reste, une signature `modifiePar`
    (pseudo, sinon « moi ») s'affiche « Modifié par … ». Édition : Titre /
    Sous-titre étiquetés, Discipline + Catégorie en menus déroulants (changer de
    discipline dénoue famille/niveaux), Niveaux en cases à cocher, Description +
    Points clés en zones de texte, titres de vidéos (`Media.label`) éditables.
    Stylo → **Enregistrer** (✓), croix → **Annuler** ; « Fermer » et « au fil de
    l'eau » retirés. « Retirer cette technique » déplacé vers **Plus › Techniques —
    gestion** (`.supprimer-technique`, PIN + confirm + snapshot). Fichiers :
    `src/domaine/modele.ts`, `src/domaine/contribution.ts`, `src/app/racine.ts`
    (`amenderContribution`, `majTechnique` + `disciplineId`, `majMediaLabel`),
    `src/app/vues.ts`, `src/app/atelier.ts` (`retirerTechnique`).
  - *Carnet → Commentaire* : une seule zone de texte (plus d'options vidéo/lien ni
    de suppression de note) ; les vidéos personnelles restent dans la zone média en
    tête de fiche.
  - *Favoris* : recherche + filtres dynamiques (déjà livré, D-045/tuning D).
  - *Compositions* : saisie + « Créer » en haut ; sections **Brouillons**
    (repliable, vides) et **Mes compositions** ; **mode entraînement retiré pour
    l'instant** (décision explicite — plus de point d'entrée, on garde la vue
    numérotée) ; réordonnancement par **glisser-déposer** (flèches retirées,
    `reordonnerBloc`) ; **Exporter** remplacé par une **icône Partager** (partage
    natif, `partagerComposition`) ; stylo → Enregistrer, « Fermer » retiré,
    Dupliquer/Supprimer conservés ; **capture vidéo/URL de présentation** rattachée
    à la seule composition (`ajouterMediaComposition`, bloc média). Fichiers :
    `src/domaine/composition.ts`, `src/app/racine.ts`, `src/app/compositions.ts`,
    `src/styles/app.css`.

Vérification : `npm run verifier` (typecheck + `npm test` 139 + build + e2e
Chromium) visé vert ; parcours e2e réaligné sur la nouvelle Bibliothèque, la
nouvelle fiche, et la nouvelle navigation (4 onglets, sous-écrans de « Plus »),
avec les scénarios de validation (deux Ashi-guruma distincts, favori depuis la
vignette, partage, filtres, suppression indépendante, deux colonnes, détection
et arbitrage des doublons, accès direct Favoris/Compositions, menu Plus court),
puis sur le tuning (fiche Titre/Sous-titre + menus déroulants + niveaux à cocher,
Commentaire, suppression déplacée dans Plus, compositions Brouillons/Mes
compositions + glisser-déposer + partage).

- **Deuxième passe de tuning + langage clair (D-074, 2026-07-14).** Retour d'usage
  tablette. Bibliothèque : nom secondaire sous le titre (taille corrigée), cœur
  favori simple sans rond blanc (grille + Favoris), **discipline = filtre** (plus
  de page), slogan « Ta mémoire du mouvement. ». **Purge du jargon** (identité,
  contribution, corpus, quasi-correspondance, voix) sur tous les écrans : aperçu
  et rapport d'import allégés (« N techniques seront ajoutées », homonymes →
  Plus › Doublons potentiels), aperçu de publication, état vide, menu Ajouter
  (Créer une technique + Capture rapide). Fiche : une seule action « Ajouter un
  média » ; points clés structurés (une ligne = un point). Plus › Médias :
  « aucune vidéo locale » au lieu de « 0 fichier ». Compositions : glisser-déposer
  réécrit en **pointer events** (tactile). Partage : commentaire exclu par défaut,
  média propre d'une composition inclus, et **feuille native Android** via
  `@capacitor/share` + `@capacitor/filesystem` (repli Web Share puis
  téléchargement localisé). Fichiers : `vues.ts`, `ajouter.ts`, `plus.ts`,
  `atelier.ts`, `ajout-media.ts`, `compositions.ts`, `racine.ts`
  (`#remettreFichierPartage`), `styles/app.css`, `package.json` (+2 plugins
  Capacitor). e2e réaligné (textes d'import, discipline-filtre, glisser tactile).

- **Sous-écran « Discipline » + doublons flous (D-075, 2026-07-14).** Plus ›
  « Packs et disciplines » devient **« Discipline »** (packs gérés ailleurs) et
  se décline en sections **Discipline** (sélecteur Toutes/une, compteurs à jour),
  **Techniques** (recherche + filtres À compléter/Problèmes, sans « gestion » ni
  accordéon), **Catégories**, **Niveaux** ; source masquée ; pseudo déménagé dans
  **Apparence**. Doublons : **détection floue** (`nomsProches` + Levenshtein
  borné dans `doublons.ts` — « De ashi barai » ≈ « De ashi harai »), **fusion qui
  conserve les deux textes par défaut**, source masquée (liste + détail), liste
  alignée (icône de tête), bouton **Rescanner** (`rescannerDoublons` — oublie les
  paires écartées). Note « Modifié par … » réduite (éditeur nommé seulement, sans
  « d'après »). Fichiers : `atelier.ts`, `plus.ts`, `racine.ts`, `vues.ts`,
  `domaine/doublons.ts`, `styles/app.css`, test `tests/doublons.test.ts` (140).

- **« Discipline » en sections + Techniques séparé + glisser généralisé (D-076,
  2026-07-14).** Techniques devient une **entrée de menu Plus** distincte (recherche
  + filtre discipline + À compléter/Problèmes) ; le sous-écran « Discipline » ne
  garde que Discipline / Catégories / Niveaux. Sélecteur de discipline **sans
  « Toutes »** (une discipline toujours choisie ; compteurs dans sa carte).
  **Encarts à titre + bouton ＋** (création derrière le ＋, plus de champ
  permanent). Suppression d'une discipline = **poubelle** près du crayon
  (avertissement + export conservés). **Glisser-déposer généralisé** (disciplines,
  catégories, niveaux) via poignée `⠿` — helper tactile partagé `src/app/glisser.ts`
  (Pointer Events), flèches retirées, ordre persisté au relâcher
  (`deplacerDisciplineVers`, `deplacerTaxonomieVers`, `enregistrerReordre`). Couleur
  de niveau : **aperçu splitté** + seconde couleur **à la sélection**. Fichiers :
  `glisser.ts` (nouveau), `atelier.ts`, `plus.ts`, `racine.ts` (+`reordreGlisse`),
  `styles/app.css`.

- **Vue visuelle des relations + 5e onglet (D-077, 2026-07-15).** Carte mentale
  en lecture : technique au centre (clic → fiche), une zone par type de lien
  (Prépare/Enchaîne/Contré/Similaire) avec vignettes cliquables (niveau 1, « +N »),
  clic sur un nœud → recentrage. Accès par un **5e onglet « Relations »** (révise
  D-071 ; barre à cinq onglets, libellés ellipsés) et un bouton **« Voir en
  graphe »** sur la fiche ; centre par défaut = dernière technique vue, sinon la
  première reliée ; sélecteur de recherche pour recentrer. La « vue liste » de
  gestion reste dans Plus › Relations entre techniques. **Drapeau
  `RELATIONS_VISUELLES`** (`src/app/fonctionnalites.ts`) désactive toute la
  fonctionnalité sans supprimer de code. Fichiers : `fonctionnalites.ts`,
  `relations-visuelle.ts` (nouveaux), `racine.ts` (Zone/Ecran/nav/`ouvrirRelationsVisuelle`/
  `techniqueCentreRelations`/`derniereTechniqueVue`), `vues.ts`, `styles/app.css`.
  Vérifié au runtime (smoke Playwright jetable : nav 5 onglets, centre, zone,
  nœud, recentrage, clic centre → fiche, zéro erreur JS) ; e2e ajusté (5 onglets).

- **Discipline affinée + refonte export de pack (D-078, 2026-07-15).** Discipline :
  hints « glisse la poignée » retirés ; ＋ ⇄ − ; création auto-refermée (+ sélection
  de la nouvelle) ; nom éditable en place (plus de crayon) + poubelle à droite ;
  liste Techniques : taille du nom corrigée + badges à la ligne. Export : refonte —
  plus de choix de source, formulaire unique (puces discipline, Tout/choix de
  techniques, avec/sans vidéos, Auteur du pack, Note de diffusion), bouton
  **Valider** → carte « Pack prêt » avec **taille** + **Enregistrer localement** /
  **Partager**. `extrairePackDiscipline(+techniquesChoisies)`, `#exporterEnFlux`
  renvoie `{taille,fichier}` (option `telecharger`), `preparerPublication` /
  `enregistrerPublicationLocale` / `partagerPublication` / `publicationPrete`.
  Différé (décision humaine) : « créé par / modifié par » (pseudo) dans le JSON.
  Fichiers : `atelier.ts`, `racine.ts`, `echange/movpack.ts`, `styles/app.css`.
  Vérifié au runtime (smoke jetable : formulaire export, Valider → Pack prêt +
  taille + local/partage, discipline nom éditable + poubelle + ＋/−).

- **Médiathèque façon V2 + relations dépliables + corbeille (D-079/080/081,
  2026-07-16).** Analyse « vidéo V2 / média V3 » actée. **Médias** : la Médiathèque
  passe en tête, toujours dépliée, **filtre par discipline** (≥ 2 disciplines),
  une ligne par média **tous types** (nom = `label`/`nomOriginal`/dérivé, taille ou
  URL, références, **▶ Aperçu**, **✎ Renommer**) ; un média référencé ne se supprime
  jamais d'ici. **Relations** : chaque type se **déplie sur ses instances**
  (`A ⇄/→ B`, clic → fiche, ✕ retrait direct via `retirerRelation`) ; l'encart
  « À réparer » est retiré (plus de liens cassés en usage normal). **Corbeille**
  (D-081) : la suppression d'une fiche la met en corbeille (`Bibliotheque.corbeille`,
  optionnel, jamais publié) ; écran **Plus › Corbeille** (Restaurer / supprimer
  définitivement / Vider) ; la cascade (nettoyage des liens entrants, notes perso
  « à rattacher », savoir sourcé retiré) n'a lieu **qu'au vidage**, snapshot pris
  avant ; les fichiers des fiches en corbeille restent référencés (jamais orphelins).
  Fichiers : `domaine/modele.ts`, `domaine/medias.ts`, `app/racine.ts`,
  `app/atelier.ts`, `app/plus.ts`, `styles/app.css`, e2e `parcours.mjs`.
  `npm run verifier` vert (typecheck + 140 tests + build + e2e).

- **Médias en tableau de bord filtrable (D-082, 2026-07-16).** Correctif +
  refonte de Plus › Médias : **double médiathèque supprimée** ; **KPI/voyants en
  tête** (Vidéos locales, Médias en ligne, Techniques sans vidéo), les deux
  premiers **cliquables = filtre** (la liste détaillée ne s'affiche qu'au clic,
  filtre discipline à l'intérieur — jamais 160 d'un coup) ; **ligne de média** =
  nom de technique (→ fiche) + libellé, plus jamais l'id/ref ; KPI de problèmes
  regroupés dans « Problèmes à traiter » ; mention « ne se supprime jamais d'ici »
  retirée. Différés (humain) : régénérer une miniature ; remplacer la miniature
  d'une technique par une image choisie (médias + édition de fiche). Fichiers :
  `app/atelier.ts`, `styles/app.css`, e2e `parcours.mjs`. `npm run verifier` vert.

- **Miniature personnalisée par technique (D-083, 2026-07-16).** `Technique.couverture`
  (dans le modèle, donc sauvegardé/exporté sans toucher au stockage vidéo) : soit une
  **image importée** réduite en vignette (≤ 480 px, JPEG data-URL), soit un **renvoi**
  vers un média présent (miniature YouTube). **Retrait** possible. UI : bloc « Vignette »
  dans l'édition de fiche (importer / désigner / retirer + aperçu) et action « ★ Vignette »
  sur les médias en ligne de l'écran Médias. `vignetteTechnique` honore la couverture
  partout. Différé (humain) : régénérer une miniature depuis une vidéo locale. Fichiers :
  `domaine/modele.ts`, `app/racine.ts`, `app/vues.ts`, `app/atelier.ts`, `styles/app.css`,
  e2e `parcours.mjs`. `npm run verifier` vert.

- **Mode avancé + vue relation en bêta (D-084, 2026-07-16).** Deux réglages
  d'appareil dans Apparence › « Réglages avancés » (off par défaut, jamais
  exportés) : **Mode avancé** masque/révèle les outils de curation du menu Plus
  (Doublons, Médias, Relations entre techniques, Diagnostic) — le reste (Discipline,
  Techniques, Corbeille, import/export, sauvegardes, sécurité, apparence) reste
  toujours visible ; **Vue relation (bêta)** remplace l'onglet permanent — barre
  basse revenue à **4 onglets**, bouton « Voir en graphe » sur la fiche seulement
  si l'option est active. Réversible, aucune suppression de code. Fichiers :
  `stockage/opfs.ts`, `app/racine.ts`, `app/plus.ts`, `app/atelier.ts`, `app/vues.ts`,
  `styles/app.css`, e2e `parcours.mjs`. `npm run verifier` vert (smoke visuel : les
  deux interrupteurs + révélation des entrées avancées).

## Phase courante

### Point d'entrée courant (2026-07-19) — finition beta (analyse captures, point par point)

La V3 est fusionnée dans `main` ; le travail vit sur **`feat/v3-ajustements`**
(hors roadmap 1-10, close). Après une longue série d'ajustements produit
(**D-067 → D-088**, cf. `execution/DECISIONS.md`), l'objectif présent est de
**figer cette branche et sortir une beta grand public** (plan :
`execution/plan-beta.md`).

- **Livré cette phase (extraits) :** navigation 4 onglets + « Plus » ;
  Discipline/Techniques/Catégories/Niveaux en sections ; doublons flous ;
  relations dépliables ; **corbeille** (D-081) ; **médiathèque en tableau de bord
  filtrable** (D-082) ; **miniature personnalisée par technique** (D-083) ;
  **mode avancé** + **vue relation en bêta** (D-084/086, relations OFF par
  défaut) ; **Apparence en cartes** (D-085) ; **densité de grille** (D-087,
  révisée D-090) ; outillage **miniatures Kodokan** (D-088, images livrées en
  artefact CI) ; harmonisation des pages de Plus (D-089).
- **En cours — passe finition sur analyse de captures (point par point,
  `execution/analyse-captures-chatgpt.md`) :**
  - **Point 1 traité (D-090)** — densité en **curseur dans Apparence** (« Auto »
    par défaut, 1..6, cap 6), **cœur-filtre** retiré de la barre, **fondu de
    bord** sur les filtres qui débordent, FAB « + » inchangé.
  - **Points 2 (favoris) et 3 (rectangle média) clos** — sans changement.
  - **Point 4 traité (D-091, maquette SVG validée)** — zone médias en **édition**
    refondue : **un bloc par média** (titre → vidéo → vidéo principale badge/bouton
    + retrait), « Ajouter » en tête, Vignette après les médias ; méthode
    `retirerMedia`. Consultation inchangée.
  - **Point 5 traité (D-092)** — **feuille de pré-partage conditionnelle** : un
    reçu + le choix « inclure les vidéos locales » **n'apparaissent que s'il y a
    une vidéo locale à embarquer** ; sinon partage direct (un tap, inchangé).
  - **Points 6, 7, 8, 9, 10, 11, 14, 15 clos** — déjà couverts ou parti pris
    assumé (détail dans `analyse-captures-chatgpt.md`).
  - **Point 12 traité (D-093)** — **mode pas-à-pas réactivé** : bouton ▶
    « Passer en revue » sur une composition en lecture (le mode existait mais
    était débranché).
  - **Point 13 traité (D-094)** — libellés Plus explicités (Disciplines et
    classement · Gestion des techniques · Médias et intégrité).
  - **Point 16 traité (D-095)** — export pack : choix vidéos explicité (« vidéos
    locales » + liens toujours inclus) + estimation de taille avant Valider.
  - **Robustesse média (hors ChatGPT, demande Yahya) :** garde-fou d'espace
    étendu à l'ajout/capture (**D-096**) et **limite d'espace volontaire réglable**
    (curseur Apparence, défaut 5 Go, **D-097**).
  - **Item 3b traité (D-098)** — **panneau de progression** à l'écriture d'un
    média (Analyse… puis Enregistrement… % réel + durée restante mesurée).
  - **À faire ensuite :** reprendre le balayage à la **vue 17** (Sauvegardes/
    vocabulaire → 24).
- **Backlog consigné (`note-modele-donnees.md`) :** partage vidéo perso
  (élève→sensei), modèles de compositions, actions groupées, **onboarding +
  packs préchargés/communautaires** (tension « jamais d'onboarding » à trancher).
- **Repère APK :** build de HEAD `96ef18d` en cours au 2026-07-19 (run apk
  29681337978, artefact APK debug).
- **Reste avant beta :** liste de **nettoyage cosmétique** (attendue de Yahya) ;
  **illustration par défaut** (contenu produit par Yahya) ; **fusion packs
  Kodokan+Judo** (Yahya) ; gel + APK. Distribution = **build local (WSL de
  Yahya)** ; **iOS hors beta** ; cible Android + PWA.
- **Reporté après la beta :** refonte du **modèle de données en couches**
  (packs/perso/réglages), **catalogue multidiscipline**, **enchaînements**,
  rôle d'écriture pratiquant/éditeur → tout dans `execution/note-modele-donnees.md`.

Le bloc historique ci-dessous (Phase 7 / roadmap) reste la trace de la mission.

---

**Phase 7 — Exécution autonome de la ROADMAP ([roadmap.md](roadmap.md) +
[execution/](execution/), session 22 — GO donné).** **LOT 1 : ACCEPTABLE**
(recette humaine + Android du 2026-07-12 — les 6 vérifications du retour
§9 confirmées ; APK vert run 29208155025). **LOT 2 (Bibliothèque) :
boucles 2.0→2.7 livrées** — raccord post-recette (import hors racine
peuplée, placeholder court, barrette d'onglet, Favoris neutre, FAB mesuré
sans chevauchement, « X noir » hors app), compteurs d'identités/sources/
voix sur les cartes, recherche globale contextualisée conservée au retour,
« Réinitialiser les filtres » + état « aucun résultat » distinct,
discipline vide sans impasse (Créer la première technique / Importer),
filtres mémorisés PAR discipline, aperçu selon la source filtrée + badge
« N voix », scénarios C/E automatisés, captures regardées (D-026).
**LOT 2 : ACCEPTABLE** (recette humaine Android du 2026-07-12, 14 points
validés — dont 111 identités Kodokan, fusion sans doublon, filtre par
source, clavier, dernière rangée accessible). **LOT 3 (fiche technique) :
ACCEPTABLE** (boucles 3.1-3.7 ; recette Android finale du 2026-07-13,
8 points validés sur l'APK du run 29217733902, commit 2573724 — CI
29217733868 vert). Ce qui existe : en-tête compact avec menu ⋮ (Modifier
les informations générales / Ajouter un média / Retirer avec dépendances
nommées), plus de crayon permanent ni de bouton « Terminer » (édition
sauvegardée au fil de l'eau, « Fermer ») ; média principal avec légende
éditoriale (auteur · provenance, jamais un slug), galerie compacte à
repli ▶ hors ligne (média affiché = choix de session, le principal global
ne bouge pas), fallback « Aucun média » actionnable ; feuille « Ajouter
un média » depuis la fiche (filmer / fichier / lien, questions utiles
seulement, jamais « à quelle technique ? ») + « Utiliser comme aperçu
principal de cette technique » ; voix selon l'arbitrage humain **D-027**
(remplace D-024) : une seule ouverte à la fois, titres éditoriaux
« Provenance · auteur », voix importée INTACTE (garde applicative
comprise) avec explication et « Créer une adaptation locale » — jamais
écrasée par une réimportation (e2e + test de rapprochement) ; relations
compactes « Relations · N » (aperçu de 3, « Voir toutes ») et « Utilisée
dans · N composition(s) » ; conservation PAR fiche (§19 : voix, média,
relations dépliées survivent à une navigation liée et au retour) ;
vidéo locale absente → message + « Vérifier dans l'Atelier ». Tests :
67 unit + e2e complet (`npm run verifier` vert). **Limites restantes** :
« choisir un média déjà présent dans la bibliothèque » non offert (la
capacité de sélection transverse n'existe pas encore) ; position de
défilement de la fiche restaurée par la pile, pas par onglet croisé.
**Faiblesse de modèle documentée (non corrigée, §21)** : pas de marqueur
explicite « adaptation locale » (reconnue par `personnel` + attribution,
sans `origine`) — à traiter au lot 6 pour l'exclusion de publication.
Boucle corrective **3.7** (issue de la première recette Android) :
en-tête fixe de fiche identifiant la technique, noms de sources
éditoriaux (« Club judo », jamais « Club » seul ni un slug, libellé
identique partout), un seul lecteur média actif à la fois (dépliage
exclusif + pause croisée) ; double lecture du même média impossible,
redondance visuelle résiduelle tracée pour le lot 9.
**LOT 4 (création, capture et édition) : ACCEPTABLE** (boucles 4.1-4.6 ;
recette Android du 2026-07-13, 17 points validés — dont permission caméra
refusée puis acceptée, vidéo vide non validable, aucun média fantôme,
aucun double ajout ; APK de recette : run 29219939637, CI de clôture
29220135697 vert). Ce qui existe : panneau « Ajouter » contextuel (racine : Une technique / Filmer
ou garder quelque chose — la capture sans discipline est restaurée ;
discipline : 5 gestes présélectionnés) ; création minimale (nom suffit,
appellation et « Classer maintenant » facultatifs, « Je le ferai plus
tard ») avec prévention des doublons (suggestions pendant la saisie,
« Utiliser » / « Créer quand même », confirmation exigée pour l'exact,
fonction pure `doublonsPotentiels` — moteur d'import intact) ; capture
par le contenu (aperçu vidéo/lien : Utiliser / Refilmer / Modifier /
Abandonner — rien d'écrit avant la fin), « Sais-tu où le ranger ? »
(existante — recherche cadrée élargissable —, nouvelle — parcours
atomique —, « Garder pour plus tard » → « Conservé dans Pratique > À
reprendre ») ; Moi · Personnel par défaut, « Ce contenu vient de
quelqu'un d'autre » en secondaire ; capture non personnelle gardable
(invariant increment-1 §2 remplacé, tracé) ; reprise complète (lire,
modifier, rattacher, supprimer avec confirmation) ; « Ajouter une
contribution » depuis la fiche (de qui / texte et-ou média /
attribution) ; retour par étapes avec « Que faire de cette capture ? » ;
écritures sûres (anti double-geste, rollback — chemin d'erreur revu à la
main, non automatisé, tracé). Tests : 74 unit + e2e complet, scénarios
A-K couverts côté web (caméra, permissions, clavier, arrière-plan :
recette Android). **LOT 5 (Pratique et Compositions) : ACCEPTABLE —
recette Android 15 points (2026-07-13) puis recette finale de la boucle
corrective 5.7 : 10 points validés sur l'APK du commit 3d6b008
(notifications transitoires éphémères et liées à l'écran, éditeur réduit
à deux constructions — capture-repère retirée sur décision humaine —,
aucun type interne de bloc visible, « Supprimer la composition »
explicite et nommé). LOT 6 (Atelier) : EN COURS — 6.1 livrée (racine en
quatre intentions exactement : Construire / Médias et qualité / Échanger
et protéger / Réglages et sécurité, accordéon à une seule section
ouverte, intention conservée pendant la session, synthèse actionnable en
tête — cliquable, sinon « Aucun problème détecté » compact) ; 6.2 livrée
(cartes de discipline avec sources et problèmes actionnables,
réordonnancement, ouverture dans la Bibliothèque, suppression sécurisée
d'une discipline non vide : contenu présenté, export préalable proposé,
confirmation renforcée, snapshot, notes personnelles préservées « à
rattacher ») ; 6.3 livrée (taxonomies ordonnables, suppression avec
arbitrage des usages : remplacer / retirer la classification / annuler —
jamais de référence invalide) ; 6.4 livrée (types de relation renommables,
symétrie et suppression seulement si inutilisé — plus de rupture en
masse —, liste de gestion des techniques avec états, vue Sources
éditoriale) ; 6.5 livrée (Médias et qualité : intégrité distinguée du
« à compléter », fichiers orphelins détectés et supprimables un par un
après prévisualisation obligatoire, médiathèque avec tailles et
références — jamais de suppression d'un média référencé) ; 6.6 livrée
(quatre gestes distincts : import avec aperçu enrichi ET rapport après
import actionnable, publication orchestrée — nom éditorial, auteur,
conditions, prévisualisation exacte avec exclusions, sortie honnête —,
« Sauvegarde complète de cette installation » distincte de la légère,
restauration proposée avant toute écriture, rollback expliquant que les
snapshots n'incluent pas les vidéos) ; 6.7 livrée (démarrage avec repli
discret si la discipline choisie disparaît, état réel des protections
sans contrôle factice, docs et matrices du lot). LOT 6 : ACCEPTABLE —
recette Android 2026-07-13, 16 points validés sur l'APK du run
29242569780 (accordéons, suppression sécurisée, arbitrages, orphelins,
import/publication/restauration réels — vidéos comprises —, rollback avec
limite annoncée, tablette). Limites tracées vers les lots techniques :
partage système Android (8D), version éditoriale et manifeste (8B),
octets vidéo hors snapshots (8C), création de relation sans chemin UI
(décision humaine). LOT 7 (Sécurité et modes d'usage) : EN COURS — 7.1
livrée (cœur du PIN : PBKDF2/SHA-256, 310 000 itérations, jamais de
secret en clair ; politique centralisée des actions — consultation
jamais bloquée, deux protections indépendantes, un seul PIN) ; 7.2 livrée
(section Protections réelle : activation avec explication + PIN +
confirmation, seconde protection sans nouveau PIN, désactivation au PIN,
secret supprimé quand plus rien n'est protégé, préréglage Tablette
partagée, délai de session, changement de PIN) ; 7.3 livrée
(déverrouillage au point d'action : panneau contextuel disant pourquoi,
reprise automatique de l'action, session curateur temporaire avec
indicateur discret et verrouillage manuel/arrière-plan, temporisation
progressive) ; 7.4 livrée (matrice complète branchée : 36 gardes de
méthode + gardes d'interface, PIN avant la confirmation destructive qui
reste due, consultation et entraînement jamais gardés, appareil personnel
sans protection = zéro PIN sur tout le parcours) ; 7.5 livrée (aucun
réglage de sécurité dans les exports — prouvé —, réinitialisation
complète avec PIN/explication/confirmation renforcée, PIN oublié honnête,
journal minimal de session sans secret) ; 7.6 clôture (scénarios A-L
audités, docs). LOT 7 : ACCEPTABLE — recette Android 2026-07-13, 20
points validés (APK du run 29249627530). Paramètres cryptographiques :
PBKDF2/SHA-256, 310 000 itérations, sel 16 octets, vérification à temps
constant. Migration : aucune. Limites : le PIN ne chiffre pas les données
au repos ni ne protège du terminal (dit) ; masquage des vues sensibles
dans les applications récentes Android = natif, tracé lot 8D. LOT 8
(Formats, médias et plateformes) : OUVERT — sous-lot 8A CLOS
TECHNIQUEMENT (CI 29260691359 + APK de recette 29260691404 verts,
recette humaine Android en attente), sous-lot 8B ouvert ;
sous-lots exécutés séparément ; 8A.1 livrée (métadonnées optionnelles de
média, registre central DÉRIVÉ pur — références des contributions, blocs
et médias principaux recalculées, jamais un compteur maintenu) ; 8A.2
livrée (ingestion UNIQUE : métadonnées réelles + empreinte SHA-256 sur
capture caméra, choix de fichier et ajout-fiche ; déduplication par
taille + empreinte — jamais le nom seul : doublon exact → id réutilisé,
nouvelle référence, un seul fichier physique ; rollback qui ne supprime
que les fichiers NEUFS, jamais un dédupliqué) ; 8A.3 livrée (références
multiples SÛRES : retirer une référence ne supprime jamais un fichier
encore utilisé ; la dernière référence retirée laisse un orphelin
diagnostiqué dans l'Atelier — suppression physique uniquement après
prévisualisation + confirmation ; `supprimerContribution` ne détruit
plus les fichiers, les snapshots « avant-retrait » restent restaurables
vidéo comprise) ; 8A.4 livrée (nommage physique
`<mediaId>.<extension-canonique>` avec résolution rétrocompatible des
anciens fichiers nus — jamais de renommage en masse ; écritures via
`staging/` vidé au démarrage ; estimation d'espace honnête avant
restauration/import — refus AVANT mutation avec les deux tailles dites ;
emplacements réels par cible et politique « aucune miniature »
documentés dans systeme.md §5bis) ; 8A.5 clôture (validation type/taille
à l'ingestion complétée — vide et non-vidéo refusés avant toute
écriture, type absent toléré ; sous-lot 8A CLOS TECHNIQUEMENT, recette
Android ciblée demandée). Sous-lot 8B (.movpack, manifeste et intégrité)
EN COURS : 8B.1 livrée (conteneur v4 — manifeste avec inventaire par
fichier {chemin, taille, SHA-256} couvrant bibliotheque.json ET chaque
média, version éditoriale, inclusions dites ; lecture vérifiant liste →
tailles → empreintes et refusant AVANT toute mutation tout fichier
manquant, redimensionné ou corrompu ; fichier inattendu signalé, jamais
exécuté ; conteneurs v3 lus par repli sur l'empreinte globale) ; 8B.1id
livrée (identité technique d'un pack dérivée de l'ULID stable de la
discipline/composition, invariante au renommage — le nom ne sert plus
qu'au nom de fichier ; aucun changement de modèle) ; 8B.2 livrée
(structure canonique du conteneur : médias rangés sous
`medias/<mediaId>.<extension>`, conteneurs v3 en `videos/<id>` restés
importables ; MIME `application/vnd.movenso.movpack+zip` et structure
documentés ; détection par contenu) ; 8B.3 livrée (export à MÉMOIRE
BORNÉE PAR BLOCS : lecture média par blocs de 1 Mio → SHA-256 incrémental
→ écriture progressive de l'entrée ZIP → fichier temporaire OPFS, puis
téléchargement depuis ce fichier adossé au disque ; ni le média entier ni
l'archive entière en mémoire ; temporaire nettoyé avant export/au
démarrage, refus borné si OPFS indisponible ; démontré
STRUCTURELLEMENT) ; 8B.4 livrée (harnais `npm run epreuve:export`, hors
verifier : correction à 202 médias avec relecture et vérification de
chaque empreinte ; preuve mémoire — 700 Mo exportés pour +1 Mo de RSS,
pic de blocs = 1 indépendant du volume, aucun chemin arrayBuffer
intégral ; limites documentées) ; 8B.5 clôture (JSON historique dit sans
manifeste ni intégrité ; réimport de composition idempotent prouvé ;
verdict technique 8B). SOUS-LOT 8B : CLOS — checkpoint validé par
l'humain (2026-07-13), tous runs CI+APK verts consignés ; verdict
ACCEPTABLE AVEC RÉSERVES (P2 : relations hors périmètre non signalées à
la publication ; borne mémoire à confirmer sur Android). SOUS-LOT 8C
EN COURS (mandat humain : boucler 8B→8C→8D d'un seul tenant) : 8C.1
livrée — amendement de contribution transactionnel (§18), fonction pure
`appliquerAmendement` non destructive, rollback fidèle sur échec de
persistance ; corrige un rollback cassé (clone capturé après mutation).
8C.2 livrée — bascule d'état protégée (§18) : écriture d'un temporaire,
relecture, revalidation, puis bascule vers le fichier courant ; reprise
au démarrage (un commit interrompu est écarté, le dernier état valide
conservé). Atomicité non parfaite revendiquée honnêtement. 8C.3 livrée —
atomicité média+métier unifiée (§17/§19) : helper commun de persistance
avec rollback des fichiers neufs, trou du repère de composition comblé,
garde anti-double-appui unique sur tous les parcours d'écriture. 8C.4
livrée — « sauvegarde complète » honnête (§20) : PARTIELLE si une vidéo
manque, exclusions nommées ; décision D-065 (réglages d'appareil jamais
exportés, promesse reformulée) ; sérialisation des sauvegardes (mutex).
8C.5 clôture — scénario G (snapshot + rétention → rollback vidéo comprise),
reprise d'une écriture média interrompue (staging nettoyé), docs systeme/
workflows. SOUS-LOT 8C : CLOS TECHNIQUEMENT — verdict ACCEPTABLE
(atomicité non parfaite dite ; interruption réelle = recette Android).
Sous-lot suivant : 8D (Android et matrice des plateformes). SOUS-LOT 8D
EN COURS : 8D.1 livrée — diagnostic technique exportable (§38), builder
pur sans secret + action Atelier « Exporter le diagnostic ». 8D.2 livrée —
reproductibilité (§37) : `.nvmrc` (Node 22), versions requises et reprise
en 30 min documentées au README, stratégie Android B confirmée, nouvel
inspecteur `.movpack` local (`tools/inspecter-movpack.ts`). 8D.3 clôture —
identité Android (§30), partage livré = téléchargement WebView + share-sheet
natif différé (raison documentée), Web livré / PWA différée / Electron et
Windows portable absents avec analyse de perte V2, MATRICE des plateformes
(systeme.md §5quater), chaîne release documentée. SOUS-LOT 8D : CLOS
TECHNIQUEMENT — verdict ACCEPTABLE AVEC RÉSERVES (share natif différé, PWA
différée, Windows/Electron absents — tous déclarés, aucun risque données).
Audit contradictoire passé (boucle 8C.6) : F1 (orphelin d'un repère filmé
si le PIN est demandé pendant l'écriture) et F2 (rollback d'amendement par
index fragile en concurrence) CORRIGÉS et testés. Boucle 8C.6b : un run CI
e2e rouge diagnostiqué comme TEST instable (lecture anticipée de `capture`
avant la fin du persist ; produit correct) — corrigé (attente du vrai
signal `capture===null`), vérifié 3× stable. **LOT 08 : ACCEPTABLE** —
recette Android consolidée 8A→8D validée par l'humain (2026-07-13, 21
points) ; preuve : commit final 80efd65 (code 29d0b2f), CI 29272785511,
APK 29272039028 ; différences ultérieures = tests et docs uniquement.
Réserves R1-R6 acceptées (aucune sur les données). **LOT 09 (identité
graphique et consolidation UX) OUVERT** : lot de finition visuelle, aucune
règle fonctionnelle ne change ; découpage 9.1→9.8 dans STATE.md. **9.1 LIVRÉE
(fondations : tokens, coque sombre/contenu clair, sémantique de couleur fixe,
accent vermillon + 6 tonalités) — POINT D'ÉTAPE : captures avant/après
produites, EN ATTENTE de validation humaine de la direction avant 9.2→9.8.**
DIRECTION VALIDÉE par l'humain (coque sombre / contenu clair / vermillon) ;
propagation autonome 9.2→9.8 en cours avec 10 contraintes (contraste coque,
audit des bleus, densité, en-tête Pratique, voyant « sans niveau », zones
sûres, 6 tonalités jour/nuit, tablette). 9.2 livrée (contraste coque +
en-tête Pratique) ; 9.3 livrée (audit des bleus : initiales de repli
neutralisées, bleu réservé à la provenance ; étiquettes sans capitales) ;
9.4 livrée (en-tête de voix source-first, §17) ; 9.5 livrée (blocs de
composition distingués par la forme, bleu retiré des blocs) ; 9.6 livrée
(voyant « à compléter » neutre au lieu de rouge — §28/contrainte 6 ;
libellés Atelier calmés) ; 9.7 livrée (thème sombre + 6 tonalités jour/nuit
vérifiés ; largeur de lecture tablette maîtrisée, sans sur-colonnage) ;
9.8 livrée (clôture : guide visuel systeme.md, captures de référence
jour/nuit, limites tracées). **LOT 9 : ACCEPTABLE** — recette Android réelle
validée humain (2026-07-13, 12 points) ; preuve commit 8d26c299 / CI
29279256402 / APK 29279256488 ; consignes de clôture intégrées (filet bleu
de la carte discipline CONSERVÉ = sémantique « discipline » ; « filtres
ceinture » → « filtres de niveau »). **LOT 10 (recette finale) OUVERT** —
commence par un AUDIT (10A) sans correction, PUIS corrections P0/P1 (10B)
après validation humaine du plan, PUIS recette finale environnement propre
(10C) → décision Go/Go avec réserves/No-Go. Périmètre GELÉ, aucune fonction,
aucun redesign. **10A (audit) RENDU : suite verte (130 tests, e2e, build,
CI apk, mémoire bornée, inspecteur) ; AUCUN P0, AUCUN P1 ; P2 (A1 relations
hors périmètre publication, A2 tablette côte à côte, A3 import V2 in-app) +
P3 (icônes SVG, logo, majContribution) ; plateformes différées déclarées.
Rapport dans QUALITY §4. Verrou §25 VALIDÉ par l'humain (plan P0/P1 vide).
**10B STABILISATION : unique correction autorisée = P2 A1 (relations hors
périmètre à la publication, règle produit D-066) — `extrairePackDiscipline`
filtre les relations dont la cible est hors périmètre (local jamais modifié,
cible jamais ajoutée), aperçu + rapport annoncent les exclusions, jamais de
lien pendant publié ; 7 tests unit + e2e ; verifier vert (132). A2-A6 restent
réserves. 10B livré (A1 corrigé). **10C RECETTE FINALE : build propre vert (132 tests +
e2e), artefacts + checksums, 10 scénarios critiques couverts, rapport
`docs/rapport-recette-v3.md`. CANDIDATE `3.0.0-rc.1`. DÉCISION FINALE : GO
AVEC RÉSERVES (§31) — 0 P0, 0 P1 ; réserves P2/P3 (backlog post-V3) +
plateformes déclarées ; aucune réserve sur données, PIN ou restauration. LA
ROADMAP V3 (lots 1-10) EST CLOSE.** Ne rouvrir un lot antérieur que sur
régression directe.**
Ce qui existe :
favoris (schéma v3 migré, étoile sur la fiche, liste compacte dans
Pratique, jamais publiés, sauvegardés/restaurés) ; racine Pratique
compacte (aperçus de 3/4 + « Voir tout (N) », états vides courts) ;
éditeur de composition à deux gestes (technique / texte), menu de bloc
(voir/remplacer/texte après/retirer), favoris dans le sélecteur,
description facultative, libellés de secours ; mode entraînement
pas-à-pas plein écran (progression, bloc en grand, retour au même bloc
depuis une fiche, barre basse masquée) ; liste enrichie (date,
miniature, ▶, recherche/tri), duplication sans copie, technique
indisponible réparable (libellé de secours + Remplacer), export de
composition avec rapport préalable. Clôture : anciens types de blocs
prouvés intacts à l'import/réimport (unit), scénarios A-K couverts côté
web, hors ligne par construction, docs et matrices à jour, captures
regardées. **Limites tracées** : « discipline présélectionnée » d'une
capture à reprendre non représentable (pas de champ) ; export de
composition = identités seules sans contributions (granularité sûre,
annoncée) ; réordonnancement par boutons (pas de glisser-déposer — les
boutons SONT l'alternative accessible prescrite). **Prochain lot : 06 —
Atelier** (après recette).
Consignes : ne rouvrir les lots 1-4 que sur régression directement causée
par le lot 5 ; ne pas anticiper l'Atelier (lot 6), la sécurité (lot 7) ni
la consolidation graphique (lot 9).
Détail : `docs/execution/STATE.md`. Le contenu détaillé des dix lots vit dans
[roadmap.md](roadmap.md) et `docs/execution/lots/` — il n'est plus résumé
ici. Les phases 5-6 (D-020→D-026) sont l'historique immédiat ;
leur détail vit dans le journal et les décisions.

## Plan des quatre fermetures (session 18)

| # | Fermeture | Contenu | État |
|---|---|---|---|
| 0 | Socle navigation | **Pile de navigation** (retour = d'où l'on vient, bouton Android compris) + **barre de navigation basse** (Accueil / Bibliothèque / Compositions / Atelier) | **fait (session 18)** |
| 1 | Corpus de bout en bout | « ＋ Ajouter une technique » dans l'explorateur (état vide accueillant → fiche en édition) ; étape « rattacher » : trois chemins TOUJOURS visibles (existante / créer avec son propre champ nom / plus tard) ; e2e : Aïkido vide → Ikkyo → grille | **fait (session 18)** |
| 2 | Sources & publication maîtrisée | **Pas de nouvelle entité** (source importée = vue dérivée de l'`origine` ; sélection/programme = composition) ; **publication par périmètre de sources** (local par défaut, opt-in explicite par source — testé) ; **prévisualisation d'import** (rapport calculé à blanc → Installer/Annuler, e2e adapté). vue « par source » dans l'explorateur (chips Mon contenu / kodokan / club…) | **fait (session 18)** |
| 3 | Atelier en parcours | Sections par intention faites : **Construire** (corpus + liens entre techniques expliqués par l'exemple, suppression des types inutilisés) · **Vérifier et résoudre** · **Publier une sélection maîtrisée** (chips de sources) · **Protéger et restaurer** (snapshots **motivés** affichés : « avant import kodokan ») · Réglages. packs-demo produits en vrais `.movpack` (tools/emballer-packs.ts, artefact CI) | **fait (session 18)** |
| 4 | Compositions terminées | Mode lecture entraînement (vignettes, gros blocs) ; fiche ↔ composition aller-retour (pile) ; Capturer depuis une composition → « ajouter comme repère » ; export d'une composition (.movpack portée composition) + **import multi-disciplines** du rapprochement (testé) ; Reprendre : « fini » masquable (préférence d'appareil), « à rattacher » toujours visible | **fait (session 18)** |

## État réel du produit (ce qui existe et fonctionne — synthèse D-020)

- **Domaine pur** (`src/domaine/`, schéma **v2**) : identités / contributions /
  provenances ; **types de relation en données** (D-020.2, H5 levée) à inverse
  dérivé ; **compositions** à blocs ordonnés (D-020.1) référençant les
  identités ; média principal ; migrations versionnées (1→2 testée) ;
  recherche tolérante **incluant les mots personnels** ; rapprochement à
  l'import (6 propriétés D-015, compositions et types compris).
- **Échange** (`src/echange/movpack.ts`) : conteneur **`.movpack` v3**
  (manifeste : identité, auteur, portée, version, intégrité SHA-256,
  conditions — D-018.1), détection par contenu. **Export complet →
  restauration sur installation vierge prouvée en e2e** (R8 levé) ;
  publication de pack par discipline, jamais le carnet.
- **Stockage unique OPFS** (validé sur appareil, D-011) : bibliothèque +
  vidéos en flux + snapshots restaurables + préférences d'appareil.
- **Application** (Lit + Vite) : démarre **vide mais jamais bloquée** (D-017) ;
  accueil « Reprendre » ; explorateur grille/filtres cumulables ; **fiche
  refondue** (média principal en tête, voix repliables par provenance,
  édition contextuelle, « Utilisée dans ») ; **capture guidée** (filmer /
  vidéo existante / lien / mot ; nature + auteur) à rattachement optionnel ;
  **compositions** (« Ma spéciale » : créer → ajouter → réordonner →
  consulter → modifier) ; **Atelier** (diagnostics actionnables, taxonomies,
  types de relation, publication, export/restauration, sauvegardes,
  **réglage de démarrage** D-020.4) ; **identité visuelle propre**
  (encre/washi, accent vermillon, filets de provenance — D-021), clair et
  sombre, grand écran.
- **Qualité** : 58 tests domaine/données/échange + e2e Chromium 4 scénarios
  (vide-actionnable, fusion des voix, composition verticale, **export →
  restauration sur contexte vierge**) ; CI (typecheck, tests, build, e2e,
  garde D-014) ; workflow `apk` → APK debug (`fr.prettozm.movenso.v3`).
- Fixtures : Judo réuni (136 identités, 24 fiches à deux voix), packs
  distribués séparément (artefact `packs-demo`), 7 suggestions en attente
  d'arbitrage. Spike S1/S2 : terminé (D-011).

## Validations de mission

| # | Validation | État |
|---|---|---|
| 1 | Compréhension du produit | **Validée** (D-004) |
| 2 | Vision produit V3 | **Validée** (D-006 + D-007, §7 inclus) |
| 3 | Contrat de construction | **Validée** (D-007 ; hypothèse stockage §4 levée par D-011) |
| 4 | Premier incrément utilisable | **APK livré — recette tatami en attente** |
| 5 | Élargissement par lots autonomes | À faire (après V4) |

*Phase 5 (D-020) : terminée — jalons 0→7 livrés en session 16, release
candidate `d3a0579` (D-022). Le détail vit dans le journal des sessions et
les décisions ; les retours terrain qui ouvrent la phase 6 sont dans D-023.*

Arbitrages humains toujours ouverts (n'arrêtent pas l'exécution) :

1. **[Humain]** Lot de rapprochements ci-dessous → règles dans
   `donnees/rapprochements-judo.json` (l'Atelier les signalera comme
   « rapprochements en attente »).

   | Club → cible Kodokan | Confiance |
   |---|---|
   | De Ashi Barai → De-ashi-harai | haute (romanisation b/h) |
   | Kuzure Gesa Gatame → Kuzure-kesa-gatame | haute (gesa/kesa) |
   | Ushiro Gesa Gatame → Ushiro-kesa-gatame | haute |
   | Hon Gesa Gatame → Kesa-gatame | haute (hon = forme fondamentale) |
   | Juji/Ude/Waki/Hara/Hiza Gatame → Ude-hishigi-…-gatame | haute (noms courts vs officiels) |
   | Clef de catcheur → Ude-garami | moyenne |
   | Morote Seoi Nage → Seoi-nage | moyenne (variante morote) |
   | Yoko Tomoe Nage → Tomoe-nage | moyenne (variante yoko) |

   **Laisser distincts (recommandé)** : les 3 chutes (le Kodokan n'a qu'un
   « Ukemi » global), les 5 retournements ne-waza (savoir club), Ashi Gatame
   Jime, Morote Jime, et les 2 groupes de Nage-no-Kata (granularité club à
   préserver — [DÉDUCTION] ils **suggèrent** un besoin de regroupement
   structuré ou de composition, sans le démontrer à eux seuls — D-016,
   requalifié D-019).
2. **[Humain]** Recette réelle Android ([recette.md](recette.md)) — après le
   jalon 7, sur l'APK de la synthèse.

Résolus par la mission D-020 : le fond de D-016 (composition = capacité
explicite, D-020.1) ; H5 (relations = mécanisme générique de données,
D-020.2) ; la tension curation mobile/atelier (Atelier décidé, D-020.3).
L'export/restauration (ex-action 5) est le jalon 6.

## Questions ouvertes

1. Lot de rapprochements à arbitrer (données judo uniquement).
2. Résultats de la recette réelle (trois niveaux, D-010) — après jalon 7.
3. Consultation d'une composition **pendant** l'entraînement : la lecture
   simple suffit-elle (pas de mode « lecteur » dédié) ? — recette.

## Risques actifs

- **R4** — « Cimetière des apps de notes » (H1 : la capture sera-t-elle
  réellement faite ?) — seul juge : la recette tatami.
- **R6 (réduit)** — Fragmentation des identités : traitée par le rapprochement ;
  résiduel = les 7 quasi-correspondances en attente d'arbitrage.
- **R7** — Liens YouTube périssables (contrat §12) : assumé, affichage dégradé.
- **R9 (conditionnel — hérité V2, réactivé à toute diffusion)** — volet
  juridique : responsabilité en cas de blessure (l'avertissement ne l'écarte
  pas en droit français), usage de la marque Kodokan, conditions d'utilisation
  des packs (exigence D-018.1). Dormant tant que l'usage reste personnel.

*Fermés* : R-S1/R3 (OPFS et surface non testable — levés par D-011 et la CI
e2e) ; R2 (ancrage V2 — les validations 1-3 l'ont traité) ; R5 (ancrage
prototype — le produit réel a divergé du prototype là où il le fallait) ;
**R8 (session 16)** — export complet + restauration testée existent et sont
prouvés en e2e sur installation vierge (D-018.2, jalon 6).

## Dettes acceptées

- Sacrifices et différés tracés dans la **matrice** (increment-1.md §6bis) :
  vignettes hors ligne des contenus référencés, favoris, thème dual, contrôles
  vidéo custom, UI de restauration des snapshots, vignettes locales des captures.
- Pré-acceptées au contrat (§12) : pas de sync multi-appareils, n=1, liens externes périssables.
- Restes à construire de l'incrément 1 (requalifiés par la relecture
  mission, session 14) : **export/import `.movpack` v3 = DANS l'incrément**
  (portabilité exigée par la Validation 4) ; PWA installable web — après.
- Engagements du contrat vérifiés en session 14 : CSP stricte (§8) et
  `navigator.storage.persist()` (§4) étaient non implémentés et non tracés —
  **corrigés** (meta CSP + persist au démarrage, e2e vert).

## Hypothèses actives

- **H1** (capture réellement faite, < 1 min, sans agacement) — recette.
- **H2** (reformulée par D-017 : l'app vide est actionnable et l'import en un
  geste la rend riche ; « Reprendre » donne envie de rouvrir) — recette.
- **H3** (les compositions personnelles seront-elles utilisées ?) — le jalon 5
  la rend observable ; la recette la mesure.

*Levées* : OPFS/WebView (D-011, spike S1/S2 complets) ; H4 (téléphone primaire
sans sacrifier le grand écran — le web/PWA même code couvre le PC, D-006/D-007) ;
H5 (tranchée par D-020.2 : les types de relation deviennent des **données** —
libellé, inverse éventuel, symétrie, origine, règles — les quatre types actuels
migrés comme défauts).

## Journal des sessions

| Session | Date | Résumé |
|---|---|---|
| 1 | 2026-07-10 | Analyse V2, système documentaire, documents fondateurs, Validation 1 présentée. |
| 2 | 2026-07-10 | Validation 1 acquise (D-004, D-005). Visions candidates, recommandation Vision A ; Validation 2 présentée. |
| 3 | 2026-07-10 | Validation 2 acquise (D-006). Situations d'usage + provenance (vision §7) ; contrat de construction ; Validation 3 présentée. |
| 4 | 2026-07-10 | Validation 3 acquise (D-007) ; convention visuelle (D-008). Conception incrément 1 + prototype cliquable. |
| 5 | 2026-07-10 | Challenge humain : M1 reformulé, parcours « Reprendre », rattachement optionnel. Prototype rév. 2. |
| 6 | 2026-07-10 | D-009 (désirabilité, question des dix ans). Socle projet : domaine pur, 29 tests, CI. |
| 7 | 2026-07-11 | D-010 (boucle de recette). Spike S1/S2 + APK vert. Convertisseur v2→V3, Kodokan converti. recette.md. |
| 8 | 2026-07-11 | D-011 (spikes validés, pack club en enseignement). App incrément 1 : deux contenus, capture, Capacitor + workflow apk. |
| 9 | 2026-07-11 | D-012 (« synthèse, pas arbitrage ») : exploration restaurée (grille, filtres, ceintures), pertes de conversion réparées, matrice des qualités. |
| 10 | 2026-07-11 | D-013 proposée (rencontre des voix : constat 24 doublons, reco rapprochement). D-014 : réconciliation documentaire + garde-fou CI etat.md. |
| 11 | 2026-07-11 | D-015 (D-013/014 validées) : rapprochement implémenté (6 propriétés testées), bibliothèque réunie (136 identités, 24 fiches à deux voix), lot de 12 fusions à arbitrer. D-016 proposée (composition, indices de récupération). |
| 12 | 2026-07-11 | D-017 (moteur générique) : audit des hypothèses judo/pack, 7 contaminations corrigées — zéro contenu embarqué, vide-mais-actionnable (import 1 geste, créer discipline, capture avec discipline à la volée), Media.service, copies génériques. Packs = artefact packs-demo. |
| 13 | 2026-07-11 | Capitalisation : lot d'arbitrage intégré à etat.md, contradictions figées annotées, matrice complétée, pièges de code en conventions, docs/systeme.md. Fusion vers main (autorisée). D-018 : distillation du corpus externe (PDF) — exigences movpack v3, R8 propriété/restauration, atelier de curation différé, H5 relations, recette œil neuf. |
| 14 | 2026-07-11 | Relecture de la mission à la lumière du chantier : portabilité requalifiée DANS l'incrément (V4), gel .movpack v3 découplé du lot, engagements contrat tenus (CSP + persist implémentés), R9 juridique conditionnel, humain/automatisé consolidé (conventions §11), format de validation à auto-critique réinstauré. |
| 15 | 2026-07-12 | Distillation de la connaissance produit (principes, tensions, connaissances négatives, hypothèses). D-019 validée : hypothèse « mémoire externe du savoir incarné » rendue visible (fils conducteurs), pièges de conception (conventions §8), curation lourde = tension permanente (matrice), consolidation de la vision différée à V4→V5 ; corrections de statut (finalité ≠ provenance, Nage-no-Kata requalifiés, indices personnels = sobriété actuelle, désirabilité non absolue). |
| 16 | 2026-07-12 | **Mission d'exécution D-020 : jalons 0→7 livrés.** Schéma v2 (relations en données — H5 levée —, compositions, média principal, migration testée) ; Atelier + réglage de démarrage ; fiche refondue (média en tête, voix repliables, édition contextuelle) ; capture guidée (vidéo existante, lien, nature+auteur) ; composition verticale « Ma spéciale » ; `.movpack` v3 + export complet → restauration vierge **prouvée en e2e** (R8 levé) ; identité visuelle encre/washi/vermillon (D-021) ; docs alignées (workflows, systeme, matrice, README). Reste : recette réelle Android (jalon 8, humain). |
| 22 | 2026-07-12 | **Roadmap complète dictée (lots 1-10) + GO d'exécution autonome.** Protocole `CLAUDE.md`+`docs/execution/` installé. **LOT 1 exécuté en 6 boucles vertes puis ACCEPTABLE en recette humaine** (retour Android §9 confirmé, APK vert). **LOT 2 exécuté en 8 boucles vertes (2.0 raccord humain → 2.7 checkpoint)** : compteurs d'identités/sources/voix, recherche globale contextualisée, Réinitialiser + aucun-résultat, discipline vide sans impasse, filtres par discipline, aperçu par source, badge voix. Recette humaine lot 2 en attente. |
| 21 | 2026-07-12 | **D-026 : finitions sur constat terrain (48 h).** Champs vidés + anti-doublon, titres réels + crayon, FAB hors Atelier/édition, sous-volets sobres, explication repliée, style destructif distinct, placeholders courts. Règle permanente : vérification VISUELLE des écrans modifiés (état réel, sombre) avant toute livraison — le e2e clique, il ne voit pas. |
| 20 | 2026-07-12 | **D-025 : reprise de l'Atelier sur retours terrain.** Volets fermés par défaut ; Réglages jour/nuit + 6 tonalités ; export .movpack uniquement (avec/sans vidéos), publication fusionnée dans « Protéger et échanger », packs-demo en .movpack seuls ; « Vérifier » = tableau de voyants (5 contrôles) ; taxonomies éditables (renommer, doubles couleurs V2, retirer) ; suppression de lien avec avertissement de rupture chiffré + cascade snapshotée. |
| 19 | 2026-07-12 | **Passe contrariante D-024** (critique UX humaine) : accueil maigre (création → Atelier, clé à molette supprimée), cartes de packs dans l'onglet Bibliothèque (liste si >1), carnet direct sur la fiche (＋ note/vidéo/lien), voix sourcées amendables, composition à deux gestes (technique/commentaire), Atelier en accordéon, boutons clarifiés, sources humanisées. e2e réaligné, 60 tests verts. |
| 18 | 2026-07-12 | **D-023 : fermeture fonctionnelle.** Pile de navigation + barre basse ; corpus de bout en bout (technique depuis l'explorateur, création toujours visible à la capture) ; compositions terminées (lecture entraînement, capture-repère, export .movpack, import multi-disciplines) ; publication par périmètre de sources (testée) ; import = proposition confirmée ; Atelier en 4 parcours ; types de relation expliqués + supprimables ; snapshots motivés ; Reprendre masquable. Puis passe d'analyse : vue par source, packs-demo .movpack, suppressions (technique avec notes → « à rattacher » ; discipline vide), workflows.md au format entrée/étapes/sortie/démontré. |
| 17 | 2026-07-12 | **D-022 : release candidate reconnue, périmètre GELÉ.** Commit de référence `d3a0579`, run apk 29181115999 (artefacts vérifiés, expiration 2026-08-11). Workflows requalifiés « implémentés techniquement, validation terrain en attente ». Six points d'observation de recette enregistrés (recette.md) — aucune correction avant le retour humain, sauf blocage d'installation/recette. |

- **Densité de la grille Bibliothèque (D-087, 2026-07-17).** Contrôle zoom −/+
  dans la barre d'outils : 1 à 4 colonnes, mémorisé dans les préférences
  (`densiteBibliotheque`), persistant. Bibliothèque uniquement ; défaut = grille
  responsive inchangée. Fichiers : `stockage/opfs.ts`, `app/racine.ts`,
  `app/vues.ts`, `styles/app.css`, e2e `parcours.mjs`. `npm run verifier` vert.
