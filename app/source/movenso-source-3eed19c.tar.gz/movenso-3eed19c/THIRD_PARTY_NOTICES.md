# Third-party notices — composants embarqués

> **Type : vivant** (S3.B11, D-218). Movenso est publié sous **GNU GPL v3**
> (voir [LICENSE](LICENSE)). L'application DISTRIBUE (bundle web et APK) les
> composants ci-dessous, sous leurs licences respectives — compatibles GPLv3.
> Les textes complets sont dans `node_modules/<paquet>/LICENSE` du dépôt de
> chaque projet. Mettre à jour cette liste quand une dépendance d'exécution
> entre ou sort (`package.json`).

| Composant | Licence | Copyright |
|---|---|---|
| [Lit](https://lit.dev) | BSD-3-Clause | © 2017 Google LLC |
| [fflate](https://github.com/101arrowz/fflate) | MIT | © Arjun Barrett |
| [Capacitor](https://capacitorjs.com) (`@capacitor/core`, `app`, `filesystem`, `share`, plateforme Android) | MIT | © 2017-present Drifty Co. |
| [@capacitor-community/text-to-speech](https://github.com/capacitor-community/text-to-speech) | MIT | © Capacitor Community |

Outillage NON distribué (build et tests seulement) : Vite (MIT),
TypeScript (Apache-2.0), Playwright (Apache-2.0), knip (ISC).

## Contenus

- **Packs officiels** (noms, classifications, niveaux, notes, liens) :
  **CC BY-NC-SA 4.0** — attribution « Movenso », pas d'usage commercial,
  repartage sous la même licence.
- **Vidéos liées** : elles restent la propriété de leurs auteurs et de leurs
  chaînes — l'application et les packs n'en font que des **liens** (lecture
  chez l'hébergeur), jamais de copie ni de redistribution.
