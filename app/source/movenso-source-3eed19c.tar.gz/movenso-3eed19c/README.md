# Movenso V3

Conception et développement de **Movenso V3** — système souverain de savoir
martial : structurer, gouverner, diffuser, consulter, enrichir et réutiliser
son savoir (identités + voix par provenance, packs `.movpack` échangeables par
fichiers, compositions, hors ligne, sans compte ni cloud). Nouveau projet,
indépendant de la
[V2](https://github.com/prettozm/movenso) (qui reste en lecture seule et sert
de source d'enseignements).

Ce dépôt est aussi la **mémoire de la mission** : la documentation pilote le
projet, et doit permettre à un nouvel agent ou développeur de reprendre le
travail sans historique de conversation.

## Reprendre le projet

1. Lire **[docs/execution/STATE.md](docs/execution/STATE.md)** — phase courante,
   prochaines actions, réserves. C'est **la seule source de l'état courant**.
2. Pour comprendre le système : **[docs/systeme.md](docs/systeme.md)**
   (architecture réelle) et **[docs/workflows.md](docs/workflows.md)** (parcours).
3. Suivre les règles de **[docs/conventions.md](docs/conventions.md)** — dont la
   **carte documentaire** §2 (une source de vérité par sujet) et la règle §12
   (doc à jour au fil de l'eau).
4. Agents : le protocole de session condensé est dans [CLAUDE.md](CLAUDE.md).

## Carte du dépôt

| Chemin | Rôle |
|---|---|
| [MISSION-movenso-v3.md](MISSION-movenso-v3.md) | Mission d'origine (figée, autorité du projet) |
| [docs/execution/STATE.md](docs/execution/STATE.md) | **Le présent** — phase, prochaines actions, réserves (seule source d'état courant) |
| [docs/execution/DECISIONS.md](docs/execution/DECISIONS.md) · [docs/decisions.md](docs/decisions.md) | **Journal des décisions** : segment finition (D-028→) et segment conception (D-001→D-027) — voir conventions §5 |
| [docs/systeme.md](docs/systeme.md) | **Architecture telle que construite** (structure, modèle, flux, plateformes) |
| [docs/workflows.md](docs/workflows.md) | Carte des parcours utilisateur (statuts implémenté/différé) |
| [docs/conventions.md](docs/conventions.md) | Règles du dépôt (+ carte documentaire §2) |
| [docs/execution/](docs/execution/) | Mémoire opérationnelle : `MASTER` (protocole agent), `STATE`, `DECISIONS`, `QUALITY` (recette/capacités), notes |
| [docs/vision-v3.md](docs/vision-v3.md) · [docs/contrat-construction.md](docs/contrat-construction.md) | Vision et contrat de construction (figés, validés) |
| [docs/recette-beta.md](docs/recette-beta.md) · [docs/recette.md](docs/recette.md) | Check-lists testeurs bêta et protocole appareil réel |
| [docs/archives/](docs/archives/) · [docs/v2/](docs/v2/) | Historique : roadmap des lots exécutée, conception d'incrément, rapport `rc.1` · analyses de la V2 |
| `src/` | Application Lit : `domaine/` (métier pur), `stockage/` (OPFS), `echange/` (`.movpack`), `securite/` (PIN), `app/` (UI), `styles/` |
| `donnees/` | Packs convertis — fixtures de test et contenus **distribués séparément**, jamais embarqués (D-017) |
| `tools/` | Outillage (conversion et inspection des packs) |
| `tests/`, `tests-navigateur/` | Tests domaine (node:test) et parcours e2e (Playwright) |

Développement : `npm ci` puis `npm run verifier` (typecheck + tests + build +
contrôle du contenu de `dist/` + e2e). APK Android : workflow GitHub `apk`
(artefact `movenso-apk`). Build web officiel : artefact CI `movenso-web-<sha>`
avec empreintes `SHA256SUMS` — seul un artefact CI est publiable en RC/release
(règle S1.1, [docs/versions.md](docs/versions.md) §4). L'état d'avancement
fait foi dans [docs/execution/STATE.md](docs/execution/STATE.md).

## Build reproductible et versions (lot 8, §37)

Versions requises (alignées sur la CI) :

| Outil | Version | Où |
|---|---|---|
| Node | 22 (voir `.nvmrc`) | `ci.yml`, `apk.yml` |
| npm | fourni avec Node 22 | — |
| Java (JDK) | 21 (Temurin) | `apk.yml` (build Android) |
| Android SDK / Gradle | fournis par Capacitor 8 + wrapper Gradle généré | `npx cap add android` |
| Capacitor | 8 (`@capacitor/*`) | `package.json` |
| Navigateur de test | Chromium (Playwright) | `test:e2e` |

Reprise en 30 minutes depuis une machine neuve :

1. `nvm use` (Node 22) puis `npm ci`.
2. `npm test` — tests domaine (node:test).
3. `npm run build` — build web Vite (`dist/`).
4. `npm run test:e2e` — parcours Chromium (OPFS réel).
5. APK debug : déclencher le workflow `apk` À LA MAIN (Actions → Run
   workflow — jamais automatique, D-197) **ou** localement `npm run build` puis
   `npx cap add android && npx cap sync android && (cd android && ./gradlew assembleDebug)`.
6. Inspecter un `.movpack` :
   `node --experimental-strip-types tools/inspecter-movpack.ts <fichier.movpack>`
   (manifeste + intégrité par fichier, lecture seule, aucun secret).
7. Packs publics : `node --experimental-strip-types tools/publier.ts` (source unique `publication/packs.json`)
   → `dist-packs/*.movpack` (vrais conteneurs).

**Stratégie Android : projet généré déterministe (§29-B)** — aucun dossier
`android/` n'est versionné ; il est régénéré à l'identique par `npx cap add` +
`npx cap sync` (aucune modification native manuelle requise). La CI le prouve à
chaque push.

**Emplacements logiques des données** — voir
[docs/systeme.md](docs/systeme.md) §5bis (OPFS : `bibliotheque.json`,
`preferences.json`, `videos/`, `staging/`, `sauvegardes/`) et §8 par cible. La
propriété des données repose sur l'export/sauvegarde `.movpack`, jamais sur
l'accès manuel au stockage privé.

## Licences (S3.B11, D-218/D-220)

- **Code et documentation du dépôt** : [GNU GPL v3](LICENSE).
- **Composants embarqués** : [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)
  (Lit BSD-3-Clause, fflate MIT, Capacitor MIT).
- **Packs officiels** (contenus) : **CC BY-NC-SA 4.0**, attribution
  « Movenso », pas d'usage commercial.
- **Vidéos liées** : propriété de leurs auteurs — les packs n'en font que des
  **liens**, jamais de copie ni de redistribution.
