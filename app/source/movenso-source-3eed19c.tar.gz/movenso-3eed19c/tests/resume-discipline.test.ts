/**
 * Résumé d'une discipline sur la racine Bibliothèque (lot 2 §2) : les
 * compteurs portent sur les IDENTITÉS réellement visibles — jamais
 * l'addition brute des contributions de chaque pack.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { bibliothequeVide } from "../src/domaine/modele.ts";
import { migrerBibliotheque } from "../src/domaine/migrations.ts";
import { importerDansBibliotheque } from "../src/domaine/rapprochement.ts";
import { resumeDiscipline } from "../src/app/vues.ts";

function lire(nom: string): unknown {
  return JSON.parse(readFileSync(new URL(`../donnees/${nom}`, import.meta.url), "utf8"));
}

test("le résumé compte les identités et les sources ; sans fusion automatique (D-067) aucune identité n'a plusieurs voix", () => {
  let b = bibliothequeVide();
  // Chemin RÉEL de l'application : import sans règles → aucune fusion (D-067).
  for (const { fichier, packId } of [
    { fichier: "kodokan.json", packId: "kodokan" },
    { fichier: "club-judo.json", packId: "club-judo" },
  ]) {
    b = importerDansBibliotheque(b, migrerBibliotheque(lire(fichier)), { packId }).bibliotheque;
  }
  const judo = b.disciplines[0]!;
  const resume = resumeDiscipline(b, judo.id);
  assert.equal(resume.identites, b.techniques.length, "le compte porte sur les identités, pas les contributions brutes");
  assert.equal(resume.sources, 2, "deux sources : kodokan et club-judo");
  assert.equal(resume.plurivoix, 0, "sans fusion automatique, chaque identité n'a qu'une seule source");
});

test("une discipline vide compte zéro sans planter ; une discipline locale a une seule source", () => {
  const b = bibliothequeVide();
  b.disciplines.push({ id: "d1", nom: "Boxe", familles: [], niveaux: [] });
  assert.deepEqual(resumeDiscipline(b, "d1"), { identites: 0, sources: 0, plurivoix: 0 });
  b.techniques.push({ id: "t1", disciplineId: "d1", nom: "Crochet gauche", niveauxIds: [], relations: [] });
  b.contributions.push({
    id: "c1", techniqueId: "t1", provenance: "personnel", pointsCles: [],
    creeLe: new Date().toISOString(), medias: [],
  });
  const r = resumeDiscipline(b, "d1");
  assert.equal(r.identites, 1);
  assert.equal(r.sources, 1, "technique locale + note locale = une seule source");
  assert.equal(r.plurivoix, 0);
});
