import { test } from "node:test";
import assert from "node:assert/strict";
import { ErreurValidation, estCheminRelatifSur, validerBibliotheque } from "../src/domaine/validation.ts";
import { genererUlid } from "../src/domaine/ulid.ts";
import { bibliotheque, contribution, disciplineJudo, technique } from "./aide.ts";

test("une bibliothèque cohérente passe la validation", () => {
  validerBibliotheque(bibliotheque());
});

test("une version de schéma inattendue est rejetée (passer par les migrations)", () => {
  const b = bibliotheque({ versionSchema: 99 });
  assert.throws(() => validerBibliotheque(b), ErreurValidation);
});

test("les ids en double sont rejetés", () => {
  const judo = disciplineJudo();
  const t = technique(judo.id);
  const b = bibliotheque({ disciplines: [judo], techniques: [t, { ...t }], contributions: [] });
  assert.throws(() => validerBibliotheque(b), /en double/);
});

test("une technique référençant une famille absente est rejetée", () => {
  const judo = disciplineJudo();
  const t = technique(judo.id, { familleId: "inexistante" });
  const b = bibliotheque({ disciplines: [judo], techniques: [t], contributions: [] });
  assert.throws(() => validerBibliotheque(b), /famille/);
});

test("une technique minimale (créée à la volée) est valide sans famille ni niveaux", () => {
  const judo = disciplineJudo();
  const { familleId: _sansFamille, ...t } = technique(judo.id, { niveauxIds: [], nom: "Balayage du randori" });
  validerBibliotheque(bibliotheque({ disciplines: [judo], techniques: [t], contributions: [] }));
});

test("une relation vers une cible absente est tolérée (jamais bloquante)", () => {
  const judo = disciplineJudo();
  const t = technique(judo.id, { relations: [{ type: "contre", cibleId: genererUlid() }] });
  validerBibliotheque(bibliotheque({ disciplines: [judo], techniques: [t], contributions: [] }));
});

test("« à rattacher » (techniqueId null) : toute provenance depuis le lot 4 §9 — l'attribution reste exigée pour le sourcé", () => {
  const b = bibliotheque();
  b.contributions = [contribution(null)]; // personnel : OK
  validerBibliotheque(b);
  b.contributions = [contribution(null, { provenance: "enseignement", attribution: "Sensei Dupont" })];
  validerBibliotheque(b); // enseignement gardé pour plus tard : OK (lot 4 §9)
  b.contributions = [contribution(null, { provenance: "ressource" })];
  assert.throws(() => validerBibliotheque(b), /attribution/); // le sourcé reste attribué
});

test("un savoir de référence ou une ressource exige une attribution (sourcé)", () => {
  const b = bibliotheque();
  const idTech = b.techniques[0]!.id;
  b.contributions = [contribution(idTech, { provenance: "referentiel" })];
  assert.throws(() => validerBibliotheque(b), /attribution/);
  b.contributions = [contribution(idTech, { provenance: "referentiel", attribution: "Kodokan" })];
  validerBibliotheque(b);
});

test("un média local au chemin dangereux est rejeté", () => {
  const b = bibliotheque();
  const idTech = b.techniques[0]!.id;
  b.contributions = [
    contribution(idTech, {
      medias: [{ id: genererUlid(), type: "local", ref: "../videos/x.mp4" }],
    }),
  ];
  assert.throws(() => validerBibliotheque(b), /dangereux/);
});

test("estCheminRelatifSur", () => {
  assert.ok(estCheminRelatifSur("videos/01ABC.mp4"));
  assert.equal(estCheminRelatifSur("/etc/passwd"), false);
  assert.equal(estCheminRelatifSur("videos/../../x"), false);
  assert.equal(estCheminRelatifSur("C:/windows"), false);
  assert.equal(estCheminRelatifSur(""), false);
});
