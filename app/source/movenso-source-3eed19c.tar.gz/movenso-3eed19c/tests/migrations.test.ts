import { test } from "node:test";
import assert from "node:assert/strict";
import {
  ErreurMigration,
  migrerBibliotheque,
  _enregistrerMigrationPourTests,
} from "../src/domaine/migrations.ts";
import { VERSION_SCHEMA } from "../src/domaine/modele.ts";
import { bibliotheque } from "./aide.ts";

test("une bibliothèque à la version courante passe telle quelle", () => {
  const b = bibliotheque();
  assert.deepEqual(migrerBibliotheque(b), b);
});

test("une version future est refusée avec un message actionnable", () => {
  assert.throws(
    () => migrerBibliotheque({ versionSchema: VERSION_SCHEMA + 1 }),
    /mettre à jour l'application/,
  );
});

test("des données illisibles sont refusées", () => {
  assert.throws(() => migrerBibliotheque("n'importe quoi"), ErreurMigration);
  assert.throws(() => migrerBibliotheque({ pasDeVersion: true }), ErreurMigration);
  assert.throws(() => migrerBibliotheque({ versionSchema: 0 }), ErreurMigration);
});

test("le mécanisme applique une chaîne n → n+1 (migrations factices vers une cible de test)", () => {
  const cible = VERSION_SCHEMA + 2;
  const retirer1 = _enregistrerMigrationPourTests(VERSION_SCHEMA, (d) => ({
    ...d,
    versionSchema: VERSION_SCHEMA + 1,
    etape1: true,
  }));
  const retirer2 = _enregistrerMigrationPourTests(VERSION_SCHEMA + 1, (d) => ({
    ...d,
    versionSchema: VERSION_SCHEMA + 2,
    etape2: true,
  }));
  try {
    const resultat = migrerBibliotheque(bibliotheque(), cible) as unknown as Record<string, unknown>;
    assert.equal(resultat["versionSchema"], cible);
    assert.equal(resultat["etape1"], true);
    assert.equal(resultat["etape2"], true);
  } finally {
    retirer1();
    retirer2();
  }
});

test("un trou dans la chaîne de migrations est refusé", () => {
  assert.throws(() => migrerBibliotheque(bibliotheque(), VERSION_SCHEMA + 1), /Aucune migration/);
});

test("une migration qui n'incrémente pas la version est refusée", () => {
  const retirer = _enregistrerMigrationPourTests(VERSION_SCHEMA, (d) => ({ ...d }));
  try {
    assert.throws(() => migrerBibliotheque(bibliotheque(), VERSION_SCHEMA + 1), /n'a pas incrémenté/);
  } finally {
    retirer();
  }
});
