/** Fabriques de données de test — un mini-monde judo cohérent. */

import type { Bibliotheque, Composition, Contribution, Discipline, Technique } from "../src/domaine/modele.ts";
import { TYPES_RELATION_DEFAUT, VERSION_SCHEMA } from "../src/domaine/modele.ts";
import { genererUlid } from "../src/domaine/ulid.ts";

export function disciplineJudo(surcharge: Partial<Discipline> = {}): Discipline {
  return {
    id: genererUlid(),
    nom: "Judo",
    familles: [{ id: "ashi-waza", nom: "Ashi-waza" }],
    niveaux: [{ id: "gokyo-1", nom: "Gokyo 1", ordre: 1 }],
    ...surcharge,
  };
}

export function technique(disciplineId: string, surcharge: Partial<Technique> = {}): Technique {
  return {
    id: genererUlid(),
    disciplineId,
    nom: "O-soto-gari",
    familleId: "ashi-waza",
    niveauxIds: ["gokyo-1"],
    relations: [],
    ...surcharge,
  };
}

export function contribution(techniqueId: string | null, surcharge: Partial<Contribution> = {}): Contribution {
  return {
    id: genererUlid(),
    techniqueId,
    provenance: "personnel",
    pointsCles: [],
    creeLe: new Date("2026-07-10T20:00:00Z").toISOString(),
    medias: [],
    ...surcharge,
  };
}

export function composition(surcharge: Partial<Composition> = {}): Composition {
  return {
    id: genererUlid(),
    nom: "Ma spéciale",
    provenance: "personnel",
    creeLe: new Date("2026-07-12T09:00:00Z").toISOString(),
    blocs: [],
    ...surcharge,
  };
}

export function bibliotheque(surcharge: Partial<Bibliotheque> = {}): Bibliotheque {
  const judo = disciplineJudo();
  const osoto = technique(judo.id);
  return {
    versionSchema: VERSION_SCHEMA,
    typesRelation: TYPES_RELATION_DEFAUT.map((t) => ({ ...t })),
    favoris: [],
    disciplines: [judo],
    techniques: [osoto],
    contributions: [contribution(osoto.id)],
    compositions: [],
    ...surcharge,
  };
}
