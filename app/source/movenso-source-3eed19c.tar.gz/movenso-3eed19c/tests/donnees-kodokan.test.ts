/**
 * Cohérence du référentiel distribué (leçon V2 : la donnée se teste comme le
 * code, sinon on peuple une base incohérente sans le voir).
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import type { Bibliotheque } from "../src/domaine/modele.ts";
import { migrerBibliotheque } from "../src/domaine/migrations.ts";
import { validerBibliotheque } from "../src/domaine/validation.ts";

const kodokan: Bibliotheque = migrerBibliotheque(
  JSON.parse(readFileSync(new URL("../donnees/kodokan.json", import.meta.url), "utf8")),
);

test("le référentiel Kodokan migre et valide", () => {
  validerBibliotheque(kodokan);
});

test("111 entrées, toutes dans la discipline Judo", () => {
  assert.equal(kodokan.techniques.length, 111);
  assert.equal(kodokan.disciplines.length, 1);
  const disc = kodokan.disciplines[0]!;
  assert.equal(disc.nom, "Judo"); // discipline = la pratique (D-013)
  assert.ok(kodokan.techniques.every((t) => t.disciplineId === disc.id));
});

test("chaque technique a exactement une contribution référentiel, sourcée, avec vidéo", () => {
  for (const t of kodokan.techniques) {
    const refs = kodokan.contributions.filter((c) => c.techniqueId === t.id && c.provenance === "referentiel");
    assert.equal(refs.length, 1, `technique « ${t.nom} »`);
    const ref = refs[0]!;
    assert.equal(ref.attribution, "Kodokan");
    assert.ok(ref.medias.length >= 1, `« ${t.nom} » sans vidéo`);
    assert.ok(
      ref.medias.every((m) => m.type === "plateforme" || m.type === "lien"),
      `« ${t.nom } » : vidéos référencées uniquement (jamais locales dans le référentiel distribué)`,
    );
  }
});

test("les noms sont uniques et les noms traditionnels majoritairement présents", () => {
  const noms = kodokan.techniques.map((t) => t.nom);
  assert.equal(new Set(noms).size, noms.length, "noms en double");
  const avecTraditionnel = kodokan.techniques.filter((t) => t.nomTraditionnel).length;
  assert.ok(avecTraditionnel / noms.length > 0.9, `${avecTraditionnel}/${noms.length} noms traditionnels`);
});

test("navigation relationnelle : graphe nettoyé cohérent (D-136)", () => {
  const parType: Record<string, number> = {};
  const ids = new Set(kodokan.techniques.map((t) => t.id));
  for (const t of kodokan.techniques) {
    for (const r of t.relations) {
      parType[r.type] = (parType[r.type] ?? 0) + 1;
      assert.ok(ids.has(r.cibleId), `cible inexistante dans « ${t.nom} »`);
      assert.notEqual(r.cibleId, t.id, `auto-lien sur « ${t.nom} »`);
    }
  }
  // ÉPURATION PORTEUR (D-241) : 315 → 67 arêtes. Le porteur a retiré ce qu'il
  // ne validait pas techniquement — l'essentiel des « enchaîne » (150 → 5) et
  // des « similaire » (100 → 8), la moitié des « contre », et le type
  // « fondamentaux » avec ses 2 arêtes. Restent INTACTS les 30 « kata » et les
  // 15 « à ne pas confondre ». Ce compteur est un GARDE-FOU de contenu : il se
  // change par une décision, jamais en subissant un import.
  assert.deepEqual(parType, { enchaine: 5, similaire: 8, a_ne_pas_confondre: 15, contre: 9, kata: 30 });
  // Placement piloté par le RÔLE, pas par le libellé (D-136).
  const role = Object.fromEntries(kodokan.typesRelation.map((t) => [t.id, t.role]));
  assert.equal(role.enchaine, "after");
  assert.equal(role.contre, "opposition");
  assert.equal(role.kata, "context");
  assert.equal(role.a_ne_pas_confondre, "peer");
  // « fondamentaux » a disparu avec l'épuration D-241 : le type n'est plus
  // déclaré par le pack. Les cinq types restants suffisent au placement.
  assert.equal(role.similaire, "peer");
});

test("alertes réglementaires : déclarées et portées (D-136)", () => {
  const types = kodokan.typesAlerte ?? [];
  assert.ok(types.some((a) => a.id === "interdit_competition"), "type d'alerte non déclaré");
  const avec = kodokan.techniques.filter((t) => (t.alertes ?? []).length).map((t) => t.nom).sort();
  assert.deepEqual(avec, ["Ashi-garami", "Do-jime", "Kani-basami", "Kawazu-gake"]);
  for (const t of kodokan.techniques) {
    for (const a of t.alertes ?? []) assert.ok(types.some((x) => x.id === a.type), `alerte « ${a.type} » non déclarée (${t.nom})`);
  }
});

test("chaque relation Kodokan porte une raison et une priorité (D-134)", () => {
  const toutes = kodokan.techniques.flatMap((t) => t.relations);
  assert.equal(toutes.length, 67); // épuration porteur D-241 (315 → 67)
  for (const r of toutes) {
    assert.ok(typeof r.note === "string" && r.note.trim().length > 0, `relation ${r.type}→${r.cibleId} sans raison`);
    assert.ok(typeof r.priorite === "number", `relation ${r.type}→${r.cibleId} sans priorité`);
  }
});
