/** Lot 8A boucle 8A.2 — ingestion unique + déduplication (REC-008A-002). */

import { test } from "node:test";
import assert from "node:assert/strict";
import { bibliothequeVide, type Media } from "../src/domaine/modele.ts";
import { genererUlid } from "../src/domaine/ulid.ts";
import { extensionCanonique, mediaIdentique } from "../src/domaine/medias.ts";
import { empreinteSha256, preparerVideo, refusFichierVideo } from "../src/domaine/ingestion.ts";
import { contribution, disciplineJudo, technique } from "./aide.ts";

function bibliothequeAvec(media: Media) {
  const b = bibliothequeVide();
  const d = disciplineJudo();
  const t = technique(d.id, { nom: "Harai-goshi" });
  b.disciplines.push(d);
  b.techniques.push(t);
  b.contributions.push({ ...contribution(t.id), medias: [media] });
  return b;
}

test("extensionCanonique : le MIME réel décide, le nom d'origine n'est qu'un repli", () => {
  assert.equal(extensionCanonique("video/webm", "prise.mp4"), "webm", "le MIME prime toujours sur le nom");
  assert.equal(extensionCanonique("video/webm;codecs=vp9", "prise"), "webm", "les paramètres codecs s'ignorent");
  assert.equal(extensionCanonique("video/quicktime"), "mov");
  assert.equal(extensionCanonique("application/octet-stream", "Kata Final.MOV"), "mov", "repli sur le nom, en minuscules");
  assert.equal(extensionCanonique("", "sans-extension"), undefined, "indécidable → jamais inventée");
  assert.equal(extensionCanonique(undefined, undefined), undefined);
});

test("empreinteSha256 : vecteur connu, stable", async () => {
  const abc = new Blob(["abc"]);
  assert.equal(
    await empreinteSha256(abc),
    "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
    "SHA-256 de « abc »",
  );
});

test("empreinteSha256 EN FLUX = digest one-shot WebCrypto (D-111), y compris multi-blocs", async () => {
  const refHex = async (o: Uint8Array) =>
    [...new Uint8Array(await crypto.subtle.digest("SHA-256", o.buffer as ArrayBuffer))].map((x) => x.toString(16).padStart(2, "0")).join("");
  // bornes de bloc SHA (55/56/63/64/65) + vide + gros contenu multi-chunks (~1,5 Mo)
  for (const n of [0, 1, 55, 56, 63, 64, 65, 200, 1_500_000]) {
    const octets = new Uint8Array(n);
    for (let i = 0; i < n; i++) octets[i] = (i * 1103515245 + 12345) & 0xff;
    assert.equal(await empreinteSha256(new Blob([octets])), await refHex(octets), `taille ${n}`);
  }
});

test("mediaIdentique : taille ET empreinte — jamais le nom seul, jamais l'historique sans empreinte", () => {
  const empreinte = "a".repeat(64);
  const complet: Media = { id: genererUlid(), type: "local", ref: "videos/x", sha256: empreinte, taille: 10, nomOriginal: "kata.webm" };
  const b = bibliothequeAvec(complet);
  assert.equal(mediaIdentique(b, 10, empreinte)?.id, complet.id, "taille + empreinte identiques → trouvé");
  assert.equal(mediaIdentique(b, 11, empreinte), undefined, "même empreinte mais taille différente → jamais");
  assert.equal(mediaIdentique(b, 10, "b".repeat(64)), undefined, "même taille mais empreinte différente → jamais");
  // un média d'avant 8A.2 (ni taille ni empreinte) ne matche jamais, même
  // si son NOM d'origine coïncide : pas de fausse déduplication.
  const historique: Media = { id: genererUlid(), type: "local", ref: "videos/y", nomOriginal: "kata.webm" };
  assert.equal(mediaIdentique(bibliothequeAvec(historique), 10, empreinte), undefined);
});

test("refusFichierVideo (§5 étape 4) : vide et non-vidéo refusés, type absent toléré", () => {
  assert.ok(refusFichierVideo(new File([], "vide.webm", { type: "video/webm" })), "un fichier vide est refusé");
  assert.ok(refusFichierVideo(new File(["x"], "notes.pdf", { type: "application/pdf" })), "un type déclaré non-vidéo est refusé");
  assert.equal(refusFichierVideo(new File(["x"], "prise", { type: "" })), null, "un type ABSENT est toléré (caméras Android)");
  assert.equal(refusFichierVideo(new File(["x"], "prise.webm", { type: "video/webm" })), null);
});

test("preparerVideo : fichier neuf → média complet, à écrire", async () => {
  const fichier = new File([new Uint8Array([1, 2, 3, 4])], "Uchi Mata.webm", { type: "video/webm" });
  const { media, dejaPresent } = await preparerVideo(bibliothequeVide(), fichier, "camera");
  assert.equal(dejaPresent, false);
  assert.equal(media.type, "local");
  assert.equal(media.ref, `videos/${media.id}`);
  assert.equal(media.taille, 4);
  assert.equal(media.mime, "video/webm");
  assert.equal(media.extension, "webm");
  assert.equal(media.nomOriginal, "Uchi Mata.webm");
  assert.equal(media.origineMedia, "camera");
  assert.equal(media.sha256, await empreinteSha256(fichier));
  assert.ok(media.ajouteLe && !Number.isNaN(Date.parse(media.ajouteLe)));
});

test("preparerVideo : même contenu sous un AUTRE nom → id réutilisé, rien à écrire", async () => {
  const premier = new File([new Uint8Array([9, 9, 9])], "original.webm", { type: "video/webm" });
  const initial = await preparerVideo(bibliothequeVide(), premier, "fichier");
  const b = bibliothequeAvec(initial.media);
  const copie = new File([new Uint8Array([9, 9, 9])], "copie renommée.mp4", { type: "video/mp4" });
  const { media, dejaPresent } = await preparerVideo(b, copie, "fichier");
  assert.equal(dejaPresent, true, "un doublon exact se reconnaît quel que soit son nom");
  assert.equal(media.id, initial.media.id, "l'id existant est RÉUTILISÉ");
  assert.equal(media.nomOriginal, "original.webm", "les métadonnées d'ORIGINE sont conservées");
  assert.notEqual(media, initial.media, "chaque référence porte son propre objet");
});

test("preparerVideo : même taille mais contenu différent → média distinct (jamais la taille seule)", async () => {
  const premier = new File([new Uint8Array([1, 1, 1])], "a.webm", { type: "video/webm" });
  const initial = await preparerVideo(bibliothequeVide(), premier, "fichier");
  const b = bibliothequeAvec(initial.media);
  const autre = new File([new Uint8Array([2, 2, 2])], "a.webm", { type: "video/webm" });
  const { media, dejaPresent } = await preparerVideo(b, autre, "fichier");
  assert.equal(dejaPresent, false);
  assert.notEqual(media.id, initial.media.id);
});
