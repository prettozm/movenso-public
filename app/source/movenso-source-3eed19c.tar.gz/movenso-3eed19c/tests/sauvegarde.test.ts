/** Lot 8C boucle 8C.4 — qualification d'une sauvegarde (§20) : « complète »
 *  seulement si les vidéos sont incluses ET aucune ne manque ; sinon PARTIELLE
 *  avec exclusions nommées. Les réglages d'appareil sont TOUJOURS exclus (D-065). */

import { test } from "node:test";
import assert from "node:assert/strict";
import { decrireSauvegarde } from "../src/domaine/sauvegarde.ts";

test("vidéos incluses et aucune manquante → complète", () => {
  const d = decrireSauvegarde({ avecVideos: true, nbManquants: 0 });
  assert.equal(d.complete, true);
  assert.match(d.role, /complète/);
});

test("vidéos incluses mais des vidéos manquent → PARTIELLE, exclusion nommée (§20)", () => {
  const d = decrireSauvegarde({ avecVideos: true, nbManquants: 3 });
  assert.equal(d.complete, false);
  assert.match(d.role, /PARTIELLE/);
  assert.ok(d.exclusions.some((e) => /3 vidéos absentes/.test(e)), "les vidéos absentes sont nommées");
});

test("sans vidéos → PARTIELLE (fichier léger), jamais « complète »", () => {
  const d = decrireSauvegarde({ avecVideos: false, nbManquants: 0 });
  assert.equal(d.complete, false);
  assert.ok(d.exclusions.some((e) => /toutes les vidéos/.test(e)));
});

test("les réglages d'appareil sont TOUJOURS exclus (D-065), même d'une sauvegarde complète", () => {
  for (const d of [decrireSauvegarde({ avecVideos: true, nbManquants: 0 }), decrireSauvegarde({ avecVideos: false, nbManquants: 2 })]) {
    assert.ok(d.exclusions.some((e) => /réglages d'appareil/.test(e)), "l'exclusion des réglages d'appareil est toujours dite");
  }
});
