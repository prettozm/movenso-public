// Non-divulgation PAR FORMAT d'export (S1.7, audit P0.7) — on n'inspecte pas
// la fonction d'extraction : on OUVRE l'archive réellement produite (unzip)
// et on y cherche des SENTINELLES plantées dans chaque donnée privée. Une
// sentinelle retrouvée = une fuite.
import { test } from "node:test";
import assert from "node:assert/strict";
import { unzipSync } from "fflate";
import {
  exporterMovpack,
  extrairePackDiscipline,
  extrairePackTechnique,
  extrairePackComposition,
  type MetaExport,
  type ManifesteMovpack,
} from "../src/echange/movpack.ts";
import { bibliothequeVide, type Bibliotheque } from "../src/domaine/modele.ts";
import { construireDiagnostic } from "../src/domaine/diagnostic.ts";
import { genererUlid } from "../src/domaine/ulid.ts";

const CARNET = "SENTINELLE_CARNET_9f2c";
const CARNET_HORS_CHOIX = "SENTINELLE_HORS_CHOIX_71ab";
const COMPO_PERSO = "SENTINELLE_COMPO_PERSO_e04d";
const ATRAITER = "SENTINELLE_A_RATTACHER_55e1";

/** Bibliothèque SENSIBLE : chaque donnée privée porte une sentinelle unique.
 *  Deux techniques (une locale, une choisie/écartée), carnet personnel,
 *  enseignement sourcé, favori, composition personnelle et partagée. */
function bibliothequeSensible() {
  const b = bibliothequeVide();
  const dId = genererUlid();
  const tA = genererUlid(); // locale — publiée
  const tB = genererUlid(); // locale — écartable par le choix de techniques
  b.disciplines.push({ id: dId, nom: "Discipline d'épreuve", familles: [], niveaux: [] });
  b.techniques.push({ id: tA, disciplineId: dId, nom: "Technique A", niveauxIds: [], relations: [{ type: "enchaine", cibleId: tB, note: "raison publiable", priorite: 1 }] });
  b.techniques.push({ id: tB, disciplineId: dId, nom: "Technique B", niveauxIds: [], relations: [] });
  // carnet PERSONNEL sur A (jamais publié), enseignement sourcé sur A (publiable),
  // enseignement sur B (présent seulement si B est choisie), capture à rattacher.
  b.contributions.push({ id: genererUlid(), techniqueId: tA, provenance: "personnel", description: CARNET, pointsCles: [], creeLe: "2026-08-02T00:00:00.000Z", medias: [] });
  b.contributions.push({ id: genererUlid(), techniqueId: tA, provenance: "enseignement", attribution: "Prof public", description: "consigne publiable", pointsCles: [], creeLe: "2026-08-02T00:00:00.000Z", medias: [] });
  b.contributions.push({ id: genererUlid(), techniqueId: tB, provenance: "enseignement", attribution: "Prof B", description: CARNET_HORS_CHOIX, pointsCles: [], creeLe: "2026-08-02T00:00:00.000Z", medias: [] });
  b.contributions.push({ id: genererUlid(), techniqueId: null, provenance: "personnel", description: ATRAITER, pointsCles: [], creeLe: "2026-08-02T00:00:00.000Z", medias: [] });
  b.favoris.push(tB);
  b.compositions.push({ id: genererUlid(), nom: "Séance privée", provenance: "personnel", blocs: [{ id: genererUlid(), type: "repere", texte: COMPO_PERSO, medias: [] }], creeLe: "2026-08-02T00:00:00.000Z" });
  b.compositions.push({ id: genererUlid(), nom: "Kata partageable", provenance: "enseignement", blocs: [{ id: genererUlid(), type: "technique", techniqueId: tA, medias: [] }], creeLe: "2026-08-02T00:00:00.000Z" });
  return { b, dId, tA, tB };
}

/** Ouvre l'archive RÉELLE et rend le JSON de bibliotheque.json + le manifeste. */
async function ouvrir(b: Bibliotheque, meta: MetaExport): Promise<{ texte: string; manifeste: ManifesteMovpack; bib: Bibliotheque }> {
  const octets = await exporterMovpack(b, meta, new Map());
  const entrees = unzipSync(octets);
  const texte = new TextDecoder().decode(entrees["bibliotheque.json"]);
  const manifeste = JSON.parse(new TextDecoder().decode(entrees["manifeste.json"])) as ManifesteMovpack;
  return { texte, manifeste, bib: JSON.parse(texte) as Bibliotheque };
}

test("non-divulgation : pack de DISCIPLINE — carnet, à-rattacher, favoris et compos perso absents du fichier", async () => {
  const { b, dId } = bibliothequeSensible();
  const { extrait } = extrairePackDiscipline(b, dId);
  const { texte, manifeste, bib } = await ouvrir(extrait, { id: "p", nom: "P", portee: "discipline" });
  for (const s of [CARNET, ATRAITER, COMPO_PERSO]) assert.ok(!texte.includes(s), `fuite : ${s}`);
  assert.deepEqual(bib.favoris, [], "favoris jamais publiés");
  assert.equal(manifeste.inclusions?.contenuPersonnel, false, "le manifeste DIT qu'aucun contenu personnel n'est inclus");
  assert.ok(texte.includes("consigne publiable"), "le contenu publiable, lui, voyage");
});

test("non-divulgation : pack de discipline avec OPT-IN compos perso — la compo voyage, le carnet JAMAIS", async () => {
  const { b, dId, tA } = bibliothequeSensible();
  b.compositions[0]!.blocs.push({ id: genererUlid(), type: "technique", techniqueId: tA, medias: [] });
  const { extrait } = extrairePackDiscipline(b, dId, new Set(["local"]), undefined, { compositionsPersonnelles: true });
  const { texte } = await ouvrir(extrait, { id: "p", nom: "P", portee: "discipline" });
  assert.ok(texte.includes(COMPO_PERSO), "l'opt-in explicite embarque la composition personnelle (D-127)");
  assert.ok(!texte.includes(CARNET), "le carnet reste privé même avec l'opt-in compositions");
  assert.ok(!texte.includes(ATRAITER), "une capture à rattacher ne voyage jamais");
});

test("non-divulgation : pack PARTIEL (choix de techniques) — les notes des techniques écartées restent", async () => {
  const { b, dId, tA } = bibliothequeSensible();
  const { extrait } = extrairePackDiscipline(b, dId, new Set(["local"]), new Set([tA]));
  const { texte } = await ouvrir(extrait, { id: "p", nom: "P", portee: "discipline" });
  assert.ok(!texte.includes(CARNET_HORS_CHOIX), "la contribution d'une technique NON choisie ne fuit pas");
  assert.ok(!texte.includes(CARNET), "carnet absent");
});

test("non-divulgation : TECHNIQUE seule — ni carnet, ni favoris, ni autres identités", async () => {
  const { b, tA } = bibliothequeSensible();
  const { extrait } = extrairePackTechnique(b, tA);
  const { texte, bib } = await ouvrir(extrait, { id: "t", nom: "T", portee: "discipline" });
  for (const s of [CARNET, CARNET_HORS_CHOIX, ATRAITER, COMPO_PERSO]) assert.ok(!texte.includes(s), `fuite : ${s}`);
  assert.deepEqual(bib.favoris, []);
  assert.equal(bib.techniques.length, 1, "une seule identité voyage");
});

test("non-divulgation : COMPOSITION — jamais de carnet ni de favoris", async () => {
  const { b } = bibliothequeSensible();
  const compoPartagee = b.compositions.find((c) => c.provenance !== "personnel")!;
  const extrait = extrairePackComposition(b, compoPartagee.id);
  const { texte, bib } = await ouvrir(extrait, { id: "c", nom: "C", portee: "composition" });
  for (const s of [CARNET, CARNET_HORS_CHOIX, ATRAITER, COMPO_PERSO]) assert.ok(!texte.includes(s), `fuite : ${s}`);
  assert.deepEqual(bib.favoris, []);
  assert.deepEqual(bib.contributions, [], "un pack de composition ne transporte pas de carnet");
});

test("sauvegarde COMPLÈTE : le contenu personnel est inclus VOULU et DIT par le manifeste", async () => {
  const { b } = bibliothequeSensible();
  const { texte, manifeste } = await ouvrir(b, { id: "sauvegarde", nom: "Sauvegarde", portee: "complet" });
  assert.ok(texte.includes(CARNET) && texte.includes(ATRAITER) && texte.includes(COMPO_PERSO), "une sauvegarde intégrale embarque le carnet — c'est sa promesse");
  assert.equal(manifeste.inclusions?.contenuPersonnel, true, "le manifeste le DIT (inclusions.contenuPersonnel)");
  // Structurel : ni PIN, ni pseudo, ni réglage d'appareil ne PEUVENT y être —
  // ils vivent dans preferences.json, jamais passé aux exporteurs (types).
  assert.ok(!/pin|pbkdf2|protections/i.test(texte), "aucune trace de protection dans les données exportées");
});

test("diagnostic : compteurs seuls — le type d'entrée ne PEUT pas porter un secret", () => {
  const sortie = construireDiagnostic({
    genereLe: "2026-08-02T00:00:00.000Z", plateforme: "web", versionApp: "dev+local", versionSchema: 4, versionMovpack: 4,
    disciplines: 2, techniques: 5, contributions: 4, compositions: 2, favoris: 1,
    mediasReferences: 3, mediasPresents: 2, mediasManquants: 1, orphelins: 0,
    espace: { usage: 100_000_000, quota: 1_000_000_000 },
  });
  assert.ok(/diagnostic/i.test(sortie) && sortie.includes("techniques"), "le diagnostic reste informatif");
  for (const s of [CARNET, "pseudo", "PIN", "/home/"]) assert.ok(!sortie.includes(s), `le diagnostic ne contient jamais : ${s}`);
});
