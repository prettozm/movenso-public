/**
 * S4.2bis — migration 4 → 5 : l'illustration de FAMILLE remonte sur la famille.
 *
 * Jusqu'au schéma 4, le modèle ne connaissait d'image que par technique : une
 * carte de famille était donc RECOPIÉE sur chacune de ses techniques (D-244).
 * 16 images du jujitsu occupaient 162 exemplaires, 12 du JJB en occupaient 150.
 *
 * C'est la SEULE migration de ce lot qui touche les bibliothèques déjà
 * installées : elle est donc testée sur ce qu'elle doit faire, sur ce qu'elle
 * ne doit PAS faire, et sur sa répétition.
 */

import test from "node:test";
import assert from "node:assert/strict";
import { migrerBibliotheque } from "../src/domaine/migrations.ts";
import { validerBibliotheque } from "../src/domaine/validation.ts";
import { VERSION_SCHEMA } from "../src/domaine/modele.ts";
import { bibliotheque, disciplineJudo, technique } from "./aide.ts";

const IMG = (n: string) => `data:image/jpeg;base64,${n}`;

/** Une bibliothèque en schéma 4 : la famille n'a pas de couverture, les
 *  techniques portent chacune une copie de l'image. */
function enSchema4(images: (string | null)[], familleId = "ashi-waza") {
  const judo = disciplineJudo();
  const techniques = images.map((img, i) => {
    const t = technique(judo.id, { nom: `Technique ${i + 1}`, familleId } as never);
    if (img) (t as { couverture?: unknown }).couverture = { type: "image", dataUrl: img };
    return t;
  });
  const b = bibliotheque({ disciplines: [judo], techniques, contributions: [] });
  return { ...b, versionSchema: 4 } as unknown as Record<string, unknown>;
}

const familleDe = (b: ReturnType<typeof migrerBibliotheque>) => b.disciplines[0]!.familles[0]!;
/** L'image d'une couverture, quel qu'en soit le type — les tests portent sur
 *  des couvertures d'image, mais le type union impose de le dire. */
const imageDe = (c: { type: string; dataUrl?: string } | undefined) => (c?.type === "image" ? c.dataUrl : undefined);

test("une image partagée par plusieurs techniques remonte sur la famille", () => {
  const b = migrerBibliotheque(enSchema4([IMG("carte"), IMG("carte"), IMG("carte")]));
  assert.equal(b.versionSchema, VERSION_SCHEMA);
  assert.deepEqual(familleDe(b).couverture, { type: "image", dataUrl: IMG("carte") },
    "la famille porte désormais l'image");
  assert.equal(b.techniques.filter((t) => t.couverture).length, 0,
    "aucune technique ne garde la copie — la dérivation remplace la recopie");
  validerBibliotheque(b);
});

test("une image UNIQUE à une technique n'est jamais déplacée", () => {
  const b = migrerBibliotheque(enSchema4([IMG("propre-1"), IMG("propre-2"), IMG("propre-3")]));
  assert.equal(familleDe(b).couverture, undefined, "rien n'est partagé : la famille reste sans image");
  assert.equal(b.techniques.filter((t) => t.couverture).length, 3, "les trois illustrations propres sont intactes");
});

test("le mélange est traité au cas par cas : la partagée monte, la propre reste", () => {
  const b = migrerBibliotheque(enSchema4([IMG("carte"), IMG("carte"), IMG("specifique"), null]));
  assert.equal(imageDe(familleDe(b).couverture), IMG("carte"));
  const restantes = b.techniques.filter((t) => t.couverture);
  assert.equal(restantes.length, 1, "seule l'illustration spécifique subsiste sur sa technique");
  assert.equal(imageDe(restantes[0]!.couverture), IMG("specifique"));
});

test("migrer deux fois ne change rien de plus (idempotence)", () => {
  const une = migrerBibliotheque(enSchema4([IMG("carte"), IMG("carte")]));
  const deux = migrerBibliotheque(JSON.parse(JSON.stringify(une)) as unknown);
  assert.deepEqual(deux, une, "une bibliothèque déjà migrée traverse la migration sans bouger");
});

test("une couverture DÉJÀ posée sur la famille n'est jamais écrasée", () => {
  const brut = enSchema4([IMG("carte"), IMG("carte")]);
  const d = (brut["disciplines"] as Record<string, unknown>[])[0]!;
  (d["familles"] as Record<string, unknown>[])[0]!["couverture"] = { type: "image", dataUrl: IMG("choisie") };
  const b = migrerBibliotheque(brut);
  assert.equal(imageDe(familleDe(b).couverture), IMG("choisie"), "le choix éditorial existant prime");
});

test("des données brutes biscornues traversent sans casser", () => {
  // Un pack tiers peut porter n'importe quoi : la migration laisse en l'état
  // ce qu'elle ne comprend pas plutôt que de le corriger au jugé.
  const brut = enSchema4([IMG("carte"), IMG("carte")]);
  (brut["techniques"] as unknown[]).push(null, "pas une technique", { familleId: 42 });
  assert.doesNotThrow(() => migrerBibliotheque(brut));
});
