import { test } from "node:test";
import assert from "node:assert/strict";
import { chercherTechniques, normaliserPourRecherche } from "../src/domaine/recherche.ts";
import { bibliotheque, disciplineJudo, technique } from "./aide.ts";

function mondeRecherche() {
  const judo = disciplineJudo();
  const noms = ["O-soto-gari", "O-soto-otoshi", "Ko-soto-gake", "Uchi-mata", "Sasae-tsuri-komi-ashi"];
  const techniques = noms.map((nom) => technique(judo.id, { nom }));
  techniques[3]!.nomTraditionnel = "内股";
  return bibliotheque({ disciplines: [judo], techniques, contributions: [] });
}

test("« o soto », « osoto » et « Ō-soto » trouvent les mêmes techniques", () => {
  const b = mondeRecherche();
  for (const q of ["o soto", "osoto", "Ō-soto", "O-SOTO"]) {
    const noms = chercherTechniques(b, q).map((t) => t.nom);
    assert.deepEqual(noms, ["O-soto-gari", "O-soto-otoshi", "Ko-soto-gake"], `requête « ${q} »`);
  }
});

test("le préfixe du nom passe avant la sous-chaîne", () => {
  const b = mondeRecherche();
  const noms = chercherTechniques(b, "soto").map((t) => t.nom);
  // aucun préfixe : ordre alphabétique stable
  assert.deepEqual(noms, ["Ko-soto-gake", "O-soto-gari", "O-soto-otoshi"]);
});

test("le nom traditionnel est cherché aussi", () => {
  const b = mondeRecherche();
  assert.deepEqual(chercherTechniques(b, "内股").map((t) => t.nom), ["Uchi-mata"]);
});

test("requête vide → aucun résultat ; limite respectée", () => {
  const b = mondeRecherche();
  assert.deepEqual(chercherTechniques(b, "   "), []);
  assert.equal(chercherTechniques(b, "o", 2).length, 2);
});

test("normaliserPourRecherche neutralise accents, tirets, espaces, apostrophes", () => {
  assert.equal(normaliserPourRecherche("Ō-sotō  GARI"), "osotogari");
  assert.equal(normaliserPourRecherche("l'épaule"), "lepaule");
});

test("un mot personnel retrouve sa technique — indice de récupération (D-016/D-020)", async () => {
  const { contribution } = await import("./aide.ts");
  const b = mondeRecherche();
  const uchimata = b.techniques.find((t) => t.nom === "Uchi-mata")!;
  b.contributions.push(contribution(uchimata.id, { description: "penser à la banane, coup de volant" }));
  assert.deepEqual(chercherTechniques(b, "banane").map((t) => t.nom), ["Uchi-mata"]);
  assert.deepEqual(chercherTechniques(b, "volant").map((t) => t.nom), ["Uchi-mata"]);
  // les mots personnels ne polluent pas : score derrière les correspondances de nom
  assert.equal(chercherTechniques(b, "uchi")[0]!.nom, "Uchi-mata");
});
