/** Doublons potentiels (D-068) : détection non bloquante + fusion sélective. */

import { test } from "node:test";
import assert from "node:assert/strict";
import type { Bibliotheque, Media } from "../src/domaine/modele.ts";
import { genererUlid } from "../src/domaine/ulid.ts";
import { clePaire, defusionnerDoublons, detecterDoublons, differencesDoublon, fusionnerDoublons } from "../src/domaine/doublons.ts";
import { validerBibliotheque } from "../src/domaine/validation.ts";
import { bibliotheque, contribution, disciplineJudo, technique } from "./aide.ts";

function media(ref: string): Media {
  return { id: genererUlid(), type: "plateforme", service: "youtube", ref };
}

/** Deux fiches « Ashi-guruma » homonymes, de deux packs, dans la même discipline. */
function deuxAshiGuruma(): { b: Bibliotheque; aId: string; bId: string } {
  const judo = disciplineJudo({ nom: "Judo" });
  const a = technique(judo.id, { nom: "Ashi-guruma", niveauxIds: ["gokyo-1"], origine: { pack: "kodokan", element: "e0" } });
  const z = technique(judo.id, { nom: "Ashi guruma", niveauxIds: [], origine: { pack: "club", element: "e0" } });
  const partage = media("SHARED-VID"); // même vidéo des deux côtés → doit se dédupliquer
  const cA = contribution(a.id, {
    provenance: "enseignement", attribution: "Kodokan", description: "Version Kodokan.", pointsCles: ["kuzushi avant"],
    origine: { pack: "kodokan", element: "e0" }, medias: [{ ...partage }, media("VID-A")],
  });
  const cB = contribution(z.id, {
    provenance: "enseignement", attribution: "Clubjudo", description: "Version du club.", pointsCles: ["balayage"],
    origine: { pack: "club", element: "e0" }, medias: [{ ...partage }, media("VID-B")],
  });
  const b = bibliotheque({ disciplines: [judo], techniques: [a, z], contributions: [cA, cB] });
  return { b, aId: a.id, bId: z.id };
}

test("détection : deux packs de même nom, même discipline, sources différentes → une paire", () => {
  const { b, aId, bId } = deuxAshiGuruma();
  const paires = detecterDoublons(b);
  assert.equal(paires.length, 1);
  assert.equal(clePaire(paires[0]!.aId, paires[0]!.bId), clePaire(aId, bId));
});

test("détection : jamais entre disciplines différentes, ni au sein d'une même source", () => {
  const { b, aId, bId } = deuxAshiGuruma();
  // Même nom mais autre discipline : jamais un doublon.
  const karate = disciplineJudo({ nom: "Karaté", familles: [], niveaux: [] });
  b.disciplines.push(karate);
  b.techniques.push(technique(karate.id, { nom: "Ashi-guruma", familleId: undefined as never, niveauxIds: [], origine: { pack: "kodokan", element: "k0" } }));
  const paires = detecterDoublons(b);
  assert.equal(paires.length, 1, "l'homonyme d'une autre discipline n'est pas un doublon");
  assert.equal(clePaire(paires[0]!.aId, paires[0]!.bId), clePaire(aId, bId));
  // Toute paire proposée oppose bien deux SOURCES différentes (jamais même pack).
  const src = (id: string) => b.techniques.find((t) => t.id === id)!.origine?.pack ?? "local";
  assert.ok(paires.every((p) => src(p.aId) !== src(p.bId)), "jamais deux fiches d'une même source");
});

test("détection floue : noms proches (variantes de romanisation) → une paire", () => {
  const judo = disciplineJudo({ nom: "Judo" });
  // « barai » vs « harai » : une seule lettre d'écart — même geste, deux romanisations.
  const a = technique(judo.id, { nom: "De ashi barai", niveauxIds: [], origine: { pack: "kodokan", element: "e1" } });
  const z = technique(judo.id, { nom: "De ashi harai", niveauxIds: [], origine: { pack: "club", element: "e1" } });
  // Un nom nettement différent de la même discipline ne doit PAS matcher.
  const autre = technique(judo.id, { nom: "Seoi-nage", niveauxIds: [], origine: { pack: "club", element: "e2" } });
  const b = bibliotheque({ disciplines: [judo], techniques: [a, z, autre], contributions: [] });
  const paires = detecterDoublons(b);
  assert.equal(paires.length, 1, "les noms proches forment une paire, pas les noms distincts");
  assert.equal(clePaire(paires[0]!.aId, paires[0]!.bId), clePaire(a.id, z.id));
});

test("une paire marquée « pas des doublons » n'est plus proposée", () => {
  const { b, aId, bId } = deuxAshiGuruma();
  const paires = detecterDoublons(b, [clePaire(aId, bId)]);
  assert.equal(paires.length, 0);
});

test("différences : chaque côté avec sa source, ses textes, ses médias, ses niveaux, ses relations", () => {
  const { b, aId, bId } = deuxAshiGuruma();
  const diff = differencesDoublon(b, aId, bId)!;
  assert.equal(diff.a.source, "kodokan");
  assert.equal(diff.b.source, "club");
  assert.equal(diff.a.medias.length, 2);
  assert.equal(diff.b.medias.length, 2);
  assert.match(diff.a.description, /Kodokan/);
  assert.match(diff.b.description, /club/);
});

test("fusion sélective : textes d'un seul côté (pas d'empilement), médias dédupliqués, niveaux/relations réunis", () => {
  const { b, aId, bId } = deuxAshiGuruma();
  const fusionnee = fusionnerDoublons(b, aId, bId, { titre: "a", textes: "a", medias: "deux", niveaux: "deux", relations: "deux" });
  validerBibliotheque(fusionnee);
  // Une seule identité subsiste (B retirée), l'id de A conservé.
  assert.equal(fusionnee.techniques.length, 1);
  const t = fusionnee.techniques[0]!;
  assert.equal(t.id, aId);
  assert.equal(t.nom, "Ashi-guruma", "titre pris du côté A");
  // Médias : la vidéo partagée n'est comptée qu'UNE fois (SHARED + VID-A + VID-B = 3).
  const contribs = fusionnee.contributions.filter((c) => c.techniqueId === t.id && c.provenance !== "personnel");
  const refs = contribs.flatMap((c) => c.medias.map((m) => m.ref));
  assert.deepEqual([...refs].sort(), ["SHARED-VID", "VID-A", "VID-B"], "médias dédupliqués, jamais empilés en double");
  // Textes : seul le côté A subsiste ; le côté B n'empile pas son texte.
  const descriptions = contribs.map((c) => c.description ?? "").filter(Boolean);
  assert.ok(descriptions.some((d) => /Kodokan/.test(d)), "le texte A est conservé");
  assert.ok(!descriptions.some((d) => /club/.test(d)), "le texte B n'est pas empilé");
});

test("fusion : toutes les références externes (favoris, relations entrantes, compositions) passent de B à A", () => {
  const { b, aId, bId } = deuxAshiGuruma();
  // Un favori, une relation entrante et un bloc de composition pointent B.
  b.favoris = [bId];
  const autre = technique(b.disciplines[0]!.id, { nom: "Harai-goshi", niveauxIds: [], origine: { pack: "kodokan", element: "e5" } });
  autre.relations = [{ type: "enchaine", cibleId: bId }];
  b.techniques.push(autre);
  b.compositions.push({
    id: genererUlid(), nom: "Séquence", provenance: "personnel", creeLe: new Date("2026-07-12T09:00:00Z").toISOString(),
    blocs: [{ id: genererUlid(), type: "technique", techniqueId: bId, medias: [] }],
  });
  const f = fusionnerDoublons(b, aId, bId, { titre: "a", textes: "deux", medias: "deux", niveaux: "deux", relations: "deux" });
  assert.deepEqual(f.favoris, [aId], "le favori suit l'identité fusionnée");
  assert.equal(f.techniques.find((t) => t.nom === "Harai-goshi")!.relations[0]!.cibleId, aId, "la relation entrante est réécrite");
  assert.equal(f.compositions[0]!.blocs[0]!.techniqueId, aId, "le bloc de composition est réécrit");
  assert.ok(!f.techniques.some((t) => t.id === bId), "l'identité B n'existe plus");
});

test("fusion : « textes : les deux » réunit explicitement les deux textes (opt-in, jamais par défaut)", () => {
  const { b, aId, bId } = deuxAshiGuruma();
  const f = fusionnerDoublons(b, aId, bId, { titre: "b", textes: "deux", medias: "a", niveaux: "a", relations: "a" });
  const contribs = f.contributions.filter((c) => c.techniqueId === aId && c.provenance !== "personnel");
  const descriptions = contribs.map((c) => c.description ?? "").filter(Boolean);
  assert.ok(descriptions.some((d) => /Kodokan/.test(d)) && descriptions.some((d) => /club/.test(d)), "les deux textes conservés sur demande");
  assert.equal(f.techniques[0]!.nom, "Ashi guruma", "titre pris du côté B");
});

test("défusion (voie H, D-101) : rétablit les deux fiches d'origine et leurs textes séparés", () => {
  const { b, aId, bId } = deuxAshiGuruma();
  const f = fusionnerDoublons(b, aId, bId, { titre: "a", textes: "deux", medias: "deux", niveaux: "deux", relations: "deux" });
  // L'app pose l'entrée de fusion (bundle pré-fusion) ; on la reproduit ici.
  const bundle = (id: string) => ({
    technique: structuredClone(b.techniques.find((t) => t.id === id)!),
    contributions: b.contributions.filter((c) => c.techniqueId === id).map((c) => structuredClone(c)),
    etaitFavori: b.favoris.includes(id),
  });
  f.fusions = [{ fusionneeLe: new Date("2026-07-19T10:00:00Z").toISOString(), fusionneeId: aId, a: bundle(aId), b: bundle(bId) }];
  assert.equal(f.techniques.length, 1, "après fusion : une seule fiche");
  // Le texte combiné montre bien les deux (rien de masqué).
  const combineee = f.contributions.filter((c) => c.techniqueId === aId).map((c) => c.description ?? "").join(" ");
  assert.ok(/Kodokan/.test(combineee) && /club/.test(combineee), "voie H : les deux textes visibles sur la fiche fusionnée");

  const def = defusionnerDoublons(f, aId);
  validerBibliotheque(def);
  assert.equal(def.techniques.length, 2, "défusion : les deux fiches reviennent");
  assert.ok(def.techniques.some((t) => t.id === aId) && def.techniques.some((t) => t.id === bId), "A et B rétablies avec leurs ids");
  const descA = def.contributions.filter((c) => c.techniqueId === aId).map((c) => c.description ?? "").join(" ");
  const descB = def.contributions.filter((c) => c.techniqueId === bId).map((c) => c.description ?? "").join(" ");
  assert.match(descA, /Kodokan/, "A retrouve son texte d'origine");
  assert.match(descB, /club/, "B retrouve son texte d'origine");
  assert.ok(!descA.includes("club"), "les textes sont de nouveau séparés");
  assert.ok(!def.fusions || def.fusions.length === 0, "l'entrée de fusion est retirée après défusion");
});
