import { test } from "node:test";
import assert from "node:assert/strict";
import { estUlid, genererUlid } from "../src/domaine/ulid.ts";

test("un ULID généré a la bonne forme", () => {
  const id = genererUlid();
  assert.equal(id.length, 26);
  assert.ok(estUlid(id));
});

test("les ULID sont uniques et triables par ordre de génération", () => {
  const ids = Array.from({ length: 1000 }, () => genererUlid());
  assert.equal(new Set(ids).size, ids.length);
  const tries = ids.slice().sort();
  assert.deepEqual(tries, ids); // monotone, même à la même milliseconde
});

test("estUlid rejette les formes invalides", () => {
  assert.equal(estUlid(""), false);
  assert.equal(estUlid("pas-un-ulid"), false);
  assert.equal(estUlid("ILOU".repeat(7).slice(0, 26)), false); // lettres exclues de Crockford
  assert.equal(estUlid(genererUlid().toLowerCase()), false);
});

test("l'horodatage encodé est croissant entre deux millisecondes distinctes", () => {
  const a = genererUlid(1_000_000);
  const b = genererUlid(2_000_000);
  assert.ok(a.slice(0, 10) < b.slice(0, 10));
});
