/**
 * ÉPREUVE outillée du lot 8B.4 — tailles de référence + preuve de mémoire de
 * l'export à mémoire bornée (§15-16). HORS du verifier rapide (volumes lourds).
 *
 * Lancer : `npm run epreuve:export`
 *
 * Deux parties distinctes (règle de preuve §4) :
 *  A — CORRECTION à échelle modérée : on accumule la sortie, on relit le ZIP
 *      et on vérifie CHAQUE empreinte ; annulation, erreur à mi-export, deux
 *      exports successifs, de nombreux petits médias.
 *  B — MÉMOIRE à grande échelle : la sortie est jetée (comptée), les blocs
 *      sont générés paresseusement (le média n'existe jamais en entier) ; on
 *      instrumente le pic de blocs détenus + la taille max d'un buffer + la
 *      RSS, pour prouver qu'aucun chemin intégral ne subsiste.
 *
 * La vérification PHYSIQUE sur Android reste la recette humaine ciblée.
 */

import assert from "node:assert/strict";
import { exporterMovpackFlux, lireMovpack, type MetaExport } from "../src/echange/movpack.ts";
import { sha256Hex } from "../src/domaine/sha256.ts";
import { bibliothequeVide, type Bibliotheque } from "../src/domaine/modele.ts";
import { genererUlid } from "../src/domaine/ulid.ts";

const CREE_LE = "2026-07-13T00:00:00.000Z";
const TAILLE_BLOC = 1 << 20; // 1 Mio — identique à l'app
const Mo = 1_000_000;

/** Bibliothèque minimale VALIDE portant N médias locaux sur une contribution. */
function bibliothequeAvecMedias(ids: string[], extension = "webm"): Bibliotheque {
  const b = bibliothequeVide();
  const disciplineId = genererUlid();
  const techniqueId = genererUlid();
  b.disciplines.push({ id: disciplineId, nom: "Épreuve", familles: [], niveaux: [] });
  b.techniques.push({ id: techniqueId, disciplineId, nom: "Média", niveauxIds: [], relations: [] });
  b.contributions.push({
    id: genererUlid(),
    techniqueId,
    provenance: "personnel",
    pointsCles: [],
    creeLe: CREE_LE,
    medias: ids.map((id) => ({ id, type: "local" as const, ref: `videos/${id}`, extension })),
  });
  return b;
}

const meta: MetaExport = { id: "epreuve", nom: "Épreuve", portee: "complet" };

/** Bloc déterministe sans conserver le média entier (motif dépendant de l'index). */
function bloc(graine: number, taille: number): Uint8Array {
  const u = new Uint8Array(taille);
  for (let i = 0; i < taille; i++) u[i] = (graine + i * 31) & 0xff;
  return u;
}

/* ============================ Partie A — correction ============================ */

async function correction(): Promise<void> {
  // médias réels (petits/moyens) : on peut tout garder pour relire et vérifier
  const petits = Array.from({ length: 200 }, () => genererUlid());
  const moyens = [genererUlid(), genererUlid()];
  const ids = [...petits, ...moyens];
  const contenus = new Map<string, Uint8Array>();
  petits.forEach((id, i) => contenus.set(id, bloc(i + 1, 1500))); // 200 × ~1,5 Ko
  moyens.forEach((id, i) => contenus.set(id, bloc(500 + i, 3 * Mo + 123))); // 2 × ~3 Mo, non alignés au bloc
  const b = bibliothequeAvecMedias(ids);

  const chunks: Uint8Array[] = [];
  const manifeste = await exporterMovpackFlux(
    b,
    meta,
    ids,
    async function* (id) {
      const c = contenus.get(id)!;
      for (let p = 0; p < c.length; p += TAILLE_BLOC) yield c.subarray(p, Math.min(p + TAILLE_BLOC, c.length));
    },
    { ecrire: async (c) => void chunks.push(c.slice()) },
    { creeLe: CREE_LE },
  );
  const total = concat(chunks);
  const relu = await lireMovpack(total);
  assert.equal(relu.videos.size, ids.length, "tous les médias présents à la relecture");
  for (const id of ids)
    assert.deepEqual([...relu.videos.get(id)!], [...contenus.get(id)!], `octets conservés pour ${id}`);
  // CHAQUE empreinte de l'inventaire correspond aux octets réels
  for (const f of manifeste.fichiers!) {
    if (f.chemin === "bibliotheque.json") continue;
    const id = f.chemin.slice("medias/".length).split(".")[0]!;
    assert.equal(f.sha256, sha256Hex(contenus.get(id)!), `empreinte inventaire == octets réels (${id})`);
  }
  console.log(`A1 ✓ ${ids.length} médias (dont 200 petits) : ZIP relu, ${manifeste.fichiers!.length} empreintes vérifiées`);

  // deux exports successifs → conteneurs équivalents (mêmes empreintes)
  const empreintes = () => manifeste.fichiers!.map((f) => f.sha256).join();
  const chunks2: Uint8Array[] = [];
  const manifeste2 = await exporterMovpackFlux(b, meta, ids,
    async function* (id) { const c = contenus.get(id)!; for (let p = 0; p < c.length; p += TAILLE_BLOC) yield c.subarray(p, Math.min(p + TAILLE_BLOC, c.length)); },
    { ecrire: async (c) => void chunks2.push(c.slice()) }, { creeLe: CREE_LE });
  assert.equal(manifeste2.fichiers!.map((f) => f.sha256).join(), empreintes(), "deux exports successifs : empreintes identiques");
  console.log("A2 ✓ deux exports successifs : empreintes stables");

  // annulation à mi-export → rejet, aucune finalisation
  let blocs = 0, annule = false, finalise = false;
  await assert.rejects(
    () => exporterMovpackFlux(bibliothequeAvecMedias(moyens), meta, moyens,
      async function* (id) { const c = contenus.get(id)!; for (let p = 0; p < c.length; p += TAILLE_BLOC) { blocs++; if (blocs >= 2) annule = true; yield c.subarray(p, Math.min(p + TAILLE_BLOC, c.length)); } },
      { ecrire: async () => {} }, { creeLe: CREE_LE, estAnnule: () => annule, surProgression: (f, t) => { if (f === t) finalise = true; } }),
    (e: Error) => /annulé/.test(e.message),
  );
  assert.equal(finalise, false, "annulation : jamais finalisé");
  console.log("A3 ✓ annulation à mi-export : rejet sans finalisation");

  // erreur de lecture à mi-export → rejet propagé, aucune finalisation
  await assert.rejects(
    () => exporterMovpackFlux(bibliothequeAvecMedias(moyens), meta, moyens,
      async function* () { yield bloc(1, TAILLE_BLOC); throw new Error("disque illisible à mi-parcours"); },
      { ecrire: async () => {} }, { creeLe: CREE_LE }),
    (e: Error) => /illisible/.test(e.message),
  );
  console.log("A4 ✓ erreur de lecture à mi-export : propagée, aucune finalisation");
}

/* ============================ Partie B — mémoire ============================ */

async function memoire(): Promise<void> {
  // Un GROS média, puis PLUSIEURS gros (volume total nettement supérieur),
  // générés PARESSEUSEMENT : le média n'est jamais matérialisé en entier.
  const scenarios: { nom: string; medias: { id: string; octets: number }[] }[] = [
    { nom: "un gros média (200 Mo)", medias: [{ id: genererUlid(), octets: 200 * Mo }] },
    {
      nom: "plusieurs gros médias (700 Mo cumulés, un de 200)",
      medias: [200, 180, 170, 150].map((mo) => ({ id: genererUlid(), octets: mo * Mo })),
    },
    { nom: "de nombreux petits médias (2000 × 4 Ko)", medias: Array.from({ length: 2000 }, () => ({ id: genererUlid(), octets: 4096 })) },
  ];

  for (const sc of scenarios) {
    const ids = sc.medias.map((m) => m.id);
    const tailleParId = new Map(sc.medias.map((m) => [m.id, m.octets]));
    const b = bibliothequeAvecMedias(ids);
    const volume = sc.medias.reduce((n, m) => n + m.octets, 0);

    let blocsVivants = 0, picBlocs = 0, maxBuffer = 0, octetsSortis = 0, picRss = 0;
    const rssBase = process.memoryUsage().rss;
    const echantillonner = () => { picRss = Math.max(picRss, process.memoryUsage().rss - rssBase); };

    await exporterMovpackFlux(
      b,
      meta,
      ids,
      async function* (id) {
        const taille = tailleParId.get(id)!;
        for (let p = 0; p < taille; p += TAILLE_BLOC) {
          const t = Math.min(TAILLE_BLOC, taille - p);
          const bl = bloc(p / TAILLE_BLOC + 1, t); // bloc frais, jamais le média entier
          blocsVivants++; picBlocs = Math.max(picBlocs, blocsVivants);
          maxBuffer = Math.max(maxBuffer, bl.length);
          echantillonner();
          yield bl;
          blocsVivants--;
        }
      },
      { ecrire: async (c) => { octetsSortis += c.length; echantillonner(); } }, // sortie JETÉE (comptée) : rien n'accumule
      { creeLe: CREE_LE },
    );

    // Preuves STRUCTURELLES (déterministes)
    assert.ok(maxBuffer <= TAILLE_BLOC, `aucun chemin intégral : buffer max ${maxBuffer} ≤ ${TAILLE_BLOC}`);
    assert.ok(picBlocs <= 2, `pic de blocs générés simultanément borné : ${picBlocs} (indépendant du volume)`);
    assert.ok(octetsSortis >= volume, "toute la sortie a bien été écrite au fil de l'eau");
    // Preuve de MÉMOIRE (corroboration, non déterministe) : la RSS ne suit JAMAIS le volume
    const picMo = picRss / Mo, volumeMo = volume / Mo;
    assert.ok(picRss < 200 * Mo, `RSS bornée : +${picMo.toFixed(0)} Mo pour ${volumeMo.toFixed(0)} Mo exportés`);
    console.log(
      `B ✓ ${sc.nom} : volume ${volumeMo.toFixed(0)} Mo | pic blocs ${picBlocs} | buffer max ${(maxBuffer / Mo).toFixed(2)} Mo | RSS +${picMo.toFixed(0)} Mo`,
    );
  }
}

function concat(morceaux: Uint8Array[]): Uint8Array {
  const total = new Uint8Array(morceaux.reduce((n, c) => n + c.length, 0));
  let o = 0;
  for (const c of morceaux) { total.set(c, o); o += c.length; }
  return total;
}

console.log("=== Épreuve 8B.4 — export à mémoire bornée ===");
await correction();
await memoire();
console.log("=== Épreuve 8B.4 : OK ===");
