/** Lot 8D boucle 8D.1 — diagnostic technique (§38) : lisible, complet, et
 *  SANS aucun secret (le builder pur ne reçoit ni PIN, ni contenu personnel). */

import { test } from "node:test";
import assert from "node:assert/strict";
import { construireDiagnostic, CODES_ECHEC } from "../src/domaine/diagnostic.ts";

const base = {
  genereLe: "2026-07-13T10:00:00.000Z",
  plateforme: "android",
  versionApp: "1.2.3-rc.4+abc1234",
  versionSchema: 3,
  versionMovpack: 4,
  disciplines: 2,
  techniques: 40,
  contributions: 111,
  compositions: 5,
  favoris: 7,
  mediasReferences: 20,
  mediasPresents: 19,
  mediasManquants: 1,
  orphelins: 0,
  espace: { usage: 50 * (1 << 20), quota: 500 * (1 << 20) },
};

test("le diagnostic rapporte plateforme, versions, compteurs et médias", () => {
  const t = construireDiagnostic(base);
  assert.match(t, /plateforme : android/);
  assert.match(t, /version de l'application : 1\.2\.3-rc\.4\+abc1234/);
  assert.match(t, /version du schéma : 3/);
  assert.match(t, /techniques : 40/);
  assert.match(t, /vidéos manquantes.*: 1/);
  assert.match(t, /50\.0 Mo \/ quota estimé : 500\.0 Mo/);
});

test("estimation d'espace indisponible : dit honnêtement, pas de fausse valeur", () => {
  const t = construireDiagnostic({ ...base, espace: null });
  assert.match(t, /estimation indisponible/);
});

test("aucun secret : ni PIN, ni empreinte, ni mot de passe dans la sortie", () => {
  const t = construireDiagnostic(base).toLowerCase();
  for (const interdit of ["pin", "mot de passe", "password", "sel", "pbkdf", "hash", "empreinte de"]) {
    // « empreinte » seule est autorisée (intégrité de fichier) ; on interdit les
    // formulations liées au secret. « pin » ne doit pas apparaître comme un champ.
    if (interdit === "pin") assert.ok(!/\bpin\b/.test(t), "le mot « pin » ne doit pas apparaître");
    else assert.ok(!t.includes(interdit), `le diagnostic ne doit pas contenir « ${interdit} »`);
  }
});

test("S1.12 : le dernier échec apparaît dans le diagnostic — code + opération + message, jamais une stack", () => {
  const base = {
    genereLe: "2026-08-02T00:00:00.000Z", plateforme: "web", versionApp: "dev+local", versionSchema: 4, versionMovpack: 4,
    disciplines: 1, techniques: 1, contributions: 0, compositions: 0, favoris: 0,
    mediasReferences: 0, mediasPresents: 0, mediasManquants: 0, orphelins: 0, espace: null,
  };
  const sans = construireDiagnostic(base);
  assert.ok(sans.includes("Dernier échec :"), "la section existe toujours");
  assert.ok(sans.includes("aucun depuis le démarrage"), "honnête quand tout va bien");
  const avec = construireDiagnostic({ ...base, dernierEchec: { quand: "2026-08-02T01:00:00.000Z", code: "MOV-E03", operation: "installation d'un pack", message: "écriture simulée refusée" } });
  assert.ok(avec.includes("[MOV-E03] installation d'un pack — écriture simulée refusée"), "code stable, opération et cause lisibles");
  assert.ok(!avec.includes("    at "), "jamais une stack trace");
});

test("P2.14 (D-217) : codes stables cohérents et opération longue rapportée honnêtement", () => {
  // Chaque code référence UN libellé d'opération, non vide — la table est le contrat.
  for (const [code, operation] of Object.entries(CODES_ECHEC)) {
    assert.match(code, /^MOV-E\d{2}$/, `format stable du code ${code}`);
    assert.ok(operation.length > 0, `libellé non vide pour ${code}`);
  }
  // Opération longue : absente, terminée, ou ENCORE en cours (blocage dit tel quel).
  const sans = construireDiagnostic(base);
  assert.match(sans, /Opération longue :\n  aucune depuis le démarrage/);
  const finie = construireDiagnostic({ ...base, operationLongue: { libelle: "Installation du pack…", debut: "2026-08-03T10:00:00.000Z", fin: "2026-08-03T10:00:04.000Z" } });
  assert.ok(finie.includes("Installation du pack… — terminée (2026-08-03T10:00:00.000Z → 2026-08-03T10:00:04.000Z)"));
  const bloquee = construireDiagnostic({ ...base, operationLongue: { libelle: "Restauration en cours…", debut: "2026-08-03T10:00:00.000Z", fin: null } });
  assert.ok(bloquee.includes("Restauration en cours… — ENCORE EN COURS au moment du diagnostic (démarrée 2026-08-03T10:00:00.000Z)"));
});

/* ---------- Enrichissement D-234 ---------- */

test("D-234 — le diagnostic situe les sources, les sauvegardes, la plateforme et les réglages", () => {
  const t = construireDiagnostic({
    ...base,
    packs: [{ id: "karate-shotokan", techniques: 109 }, { id: "local", techniques: 2 }],
    sauvegardes: { nombre: 12, derniere: "2026-08-07__avant-import.json" },
    relations: 315,
    compositionsARoles: 3,
    capacites: { "stockage OPFS": true, "stockage persistant accordé": false, langue: "fr-FR" },
    reglages: { thème: "sombre", "bêta Compositions": "oui" },
  });
  assert.match(t, /karate-shotokan : 109 techniques/);
  assert.match(t, /local : 2 techniques/, "« local » distingue ce qui a été créé sur l'appareil");
  assert.match(t, /sauvegardes internes : 12 \(dernière : 2026-08-07__avant-import\.json\)/);
  assert.match(t, /relations entre techniques : 315/);
  assert.match(t, /dont 3 à plusieurs rôles/);
  assert.match(t, /stockage persistant accordé : non/, "un booléen se lit en toutes lettres");
  assert.match(t, /langue : fr-FR/);
  assert.match(t, /thème : sombre/);
  // La garde « aucun secret » vaut aussi sur le rapport ENRICHI.
  assert.ok(!/\bpin\b|mot de passe|empreinte de/i.test(t), "aucun secret, même avec le contexte enrichi");
});

test("D-234 — sans contexte enrichi, le diagnostic reste celui d'avant (aucune section vide)", () => {
  const t = construireDiagnostic(base);
  assert.ok(!t.includes("Sources du contenu"), "pas de section sans données");
  assert.ok(!t.includes("Capacités de la plateforme"));
  assert.ok(!t.includes("Réglages actifs"));
  assert.ok(!t.includes("sauvegardes internes"));
  assert.match(t, /Contenu :/, "le socle historique est intact");
});
