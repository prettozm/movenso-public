/** Lot 7 — cœur du PIN et politique centralisée (REC-007-001).
 *  AUCUN test ne contient de PIN de production ni n'imprime de secret. */

import { test } from "node:test";
import assert from "node:assert/strict";
import {
  ITERATIONS_PBKDF2,
  creerVerification,
  delaiApresEchecs,
  validerFormatPin,
  verifierPin,
} from "../src/securite/pin.ts";
import { PROTECTIONS_INACTIVES, autorisation, sessionActive } from "../src/securite/politique.ts";
import { bibliothequeVide } from "../src/domaine/modele.ts";
import { exporterMovpack, lireMovpack } from "../src/echange/movpack.ts";

const PIN_ESSAI = "731905"; // valeur de test, jamais un secret réel

test("format §4 : 6 à 12 chiffres seulement, message clair sinon", () => {
  assert.equal(validerFormatPin(PIN_ESSAI), null);
  assert.equal(validerFormatPin("730915482634"), null); // 12 chiffres
  assert.match(validerFormatPin("12345") ?? "", /6 à 12 chiffres/); // trop court
  assert.match(validerFormatPin("7309154826341") ?? "", /6 à 12 chiffres/); // trop long
  assert.match(validerFormatPin("abc123") ?? "", /6 à 12 chiffres/); // lettres
  assert.match(validerFormatPin("73 1905") ?? "", /6 à 12 chiffres/); // espace
});

test("format §4 : les valeurs trop évidentes sont refusées", () => {
  assert.match(validerFormatPin("000000") ?? "", /évident/);
  assert.match(validerFormatPin("777777777") ?? "", /évident/);
  assert.match(validerFormatPin("123456") ?? "", /évidente/);
  assert.match(validerFormatPin("456789") ?? "", /évidente/);
  assert.match(validerFormatPin("987654") ?? "", /évidente/);
  assert.match(validerFormatPin("9012345678") ?? "", /évidente/); // suite avec passage par 0
  assert.equal(validerFormatPin("121212"), null); // motif, mais ni suite ni répétition d'UN chiffre : accepté (§4)
});

test("création §5 : jamais le PIN — sel aléatoire, itérations documentées, empreinte dérivée seulement", async () => {
  const v = await creerVerification(PIN_ESSAI);
  const serialise = JSON.stringify(v);
  assert.ok(!serialise.includes(PIN_ESSAI), "le PIN ne doit apparaître nulle part");
  assert.equal(v.iterations, ITERATIONS_PBKDF2);
  assert.equal(v.sel.length, 32, "sel de 16 octets (hex)");
  assert.equal(v.empreinte.length, 64, "empreinte SHA-256 dérivée (hex)");
  const v2 = await creerVerification(PIN_ESSAI);
  assert.notEqual(v.sel, v2.sel, "un sel aléatoire PAR création");
  assert.notEqual(v.empreinte, v2.empreinte, "le même PIN dérive différemment avec un autre sel");
});

test("création : un PIN au format refusé ne crée RIEN", async () => {
  await assert.rejects(() => creerVerification("123456"), /évidente/);
});

test("vérification : bon PIN accepté, mauvais refusé, empreinte altérée refusée", async () => {
  const v = await creerVerification(PIN_ESSAI);
  assert.equal(await verifierPin(PIN_ESSAI, v), true);
  assert.equal(await verifierPin("731906", v), false);
  assert.equal(await verifierPin("", v), false);
  const alteree = { ...v, empreinte: v.empreinte.slice(0, -1) + (v.empreinte.endsWith("0") ? "1" : "0") };
  assert.equal(await verifierPin(PIN_ESSAI, alteree), false);
});

test("politique §17 : consultation toujours libre, chaque protection suit SON réglage", () => {
  // aucune protection : tout est libre, session ou pas (§15 appareil personnel)
  for (const session of [false, true]) {
    assert.equal(autorisation("consultation", PROTECTIONS_INACTIVES, session), "libre");
    assert.equal(autorisation("modification", PROTECTIONS_INACTIVES, session), "libre");
    assert.equal(autorisation("destruction_ou_sensible", PROTECTIONS_INACTIVES, session), "libre");
  }
  // protections indépendantes (§2 / scénario D)
  const suppressionsSeules = { modifications: false, suppressions: true };
  assert.equal(autorisation("modification", suppressionsSeules, false), "libre");
  assert.equal(autorisation("destruction_ou_sensible", suppressionsSeules, false), "pin_requis");
  const modificationsSeules = { modifications: true, suppressions: false };
  assert.equal(autorisation("modification", modificationsSeules, false), "pin_requis");
  assert.equal(autorisation("destruction_ou_sensible", modificationsSeules, false), "libre");
  // la consultation n'est JAMAIS bloquée, même tout protégé
  const tout = { modifications: true, suppressions: true };
  assert.equal(autorisation("consultation", tout, false), "libre");
  // une session déverrouillée libère les deux niveaux — un seul PIN (§9)
  assert.equal(autorisation("modification", tout, true), "libre");
  assert.equal(autorisation("destruction_ou_sensible", tout, true), "libre");
});

test("session §8 : expire par inactivité selon le mode ; « arrière-plan » ne dépend pas du temps", () => {
  const t0 = 1_000_000;
  assert.equal(sessionActive(null, "5min", t0), false, "jamais déverrouillée sans geste");
  assert.equal(sessionActive(t0, "5min", t0 + 4 * 60_000), true);
  assert.equal(sessionActive(t0, "5min", t0 + 5 * 60_000), false, "5 minutes d'inactivité verrouillent");
  assert.equal(sessionActive(t0, "15min", t0 + 14 * 60_000), true);
  assert.equal(sessionActive(t0, "15min", t0 + 15 * 60_000), false);
  assert.equal(sessionActive(t0, "arriere-plan", t0 + 999 * 60_000), true, "seul l'arrière-plan (ou le verrou manuel) ferme ce mode");
  assert.equal(sessionActive(null, "arriere-plan", t0), false);
});

test("§21 : un export complet ne transporte AUCUN réglage de sécurité", async () => {
  // Les protections vivent dans les préférences d'APPAREIL ; la bibliothèque
  // exportée ne peut structurellement pas les contenir — prouvé ici.
  const octets = await exporterMovpack(bibliothequeVide(), { id: "essai", nom: "Essai", portee: "complet" }, new Map());
  const contenu = await lireMovpack(octets);
  const bibliotheque = JSON.stringify(contenu.bibliotheque).toLowerCase();
  for (const interdit of ["protections", "verification", "pbkdf", "verrouillage", '"sel"'])
    assert.ok(!bibliotheque.includes(interdit), `« ${interdit} » ne doit jamais voyager dans une sauvegarde`);
});

test("temporisation §10 : immédiat jusqu'à 4 erreurs, croissante ensuite, plafonnée", () => {
  assert.equal(delaiApresEchecs(0), 0);
  assert.equal(delaiApresEchecs(4), 0);
  assert.ok(delaiApresEchecs(5) > 0, "la 5e erreur attend");
  assert.ok(delaiApresEchecs(6) > delaiApresEchecs(5), "l'attente croît");
  assert.equal(delaiApresEchecs(20), delaiApresEchecs(50), "plafonnée — jamais de verrouillage définitif");
});
