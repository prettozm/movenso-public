/** Lot 8B — SHA-256 incrémental (§15) : conformité octet pour octet contre
 *  WebCrypto, y compris en découpant en blocs arbitraires. */

import { test } from "node:test";
import assert from "node:assert/strict";
import { Sha256, sha256Hex } from "../src/domaine/sha256.ts";

const hexWebCrypto = async (octets: Uint8Array): Promise<string> => {
  const h = await crypto.subtle.digest("SHA-256", octets as BufferSource);
  return [...new Uint8Array(h)].map((o) => o.toString(16).padStart(2, "0")).join("");
};

test("vecteurs connus FIPS 180-4", () => {
  assert.equal(sha256Hex(new Uint8Array(0)), "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
  assert.equal(sha256Hex(new TextEncoder().encode("abc")), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  assert.equal(
    sha256Hex(new TextEncoder().encode("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq")),
    "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1",
  );
});

test("conformité WebCrypto sur tailles variées (bornes de bloc 55/56/63/64/65, multi-blocs)", async () => {
  for (const n of [0, 1, 55, 56, 63, 64, 65, 100, 127, 128, 1000, 4096, 100_000]) {
    const octets = new Uint8Array(n);
    for (let i = 0; i < n; i++) octets[i] = (i * 31 + 7) & 0xff;
    assert.equal(sha256Hex(octets), await hexWebCrypto(octets), `taille ${n}`);
  }
});

test("update par blocs arbitraires = digest one-shot (le découpage n'affecte jamais l'empreinte)", async () => {
  const total = new Uint8Array(50_000);
  for (let i = 0; i < total.length; i++) total[i] = (i * 131 + 17) & 0xff;
  const attendu = await hexWebCrypto(total);
  for (const taille of [1, 7, 64, 100, 4096, 9973]) {
    const h = new Sha256();
    for (let i = 0; i < total.length; i += taille) h.update(total.subarray(i, Math.min(i + taille, total.length)));
    assert.equal(h.digestHex(), attendu, `blocs de ${taille}`);
  }
});

test("digest() ne peut être appelé qu'une fois, update() interdit après", () => {
  const h = new Sha256().update(new Uint8Array([1, 2, 3]));
  h.digestHex();
  assert.throws(() => h.digestHex());
  assert.throws(() => h.update(new Uint8Array([4])));
});
