/**
 * S4.2/D-263 — un conteneur ne choisit pas la rigueur qu'on lui applique.
 *
 * Le repli « empreinte globale » était sélectionné sur le seul fait que
 * `fichiers` soit absent, SANS regarder la version déclarée. Un conteneur
 * annonçant `version: 4` pouvait donc omettre son inventaire et retomber en
 * silence sur le contrôle le plus faible : le `bibliotheque.json` restait
 * couvert par l'empreinte globale, mais **les médias voyageaient sans aucune
 * empreinte**, et aucun avertissement ne le disait.
 *
 * Les deux lecteurs sont couverts — celui en mémoire ET celui en flux, qui
 * est le chemin d'import réel de l'application.
 */

import test from "node:test";
import assert from "node:assert/strict";
import { zipSync } from "fflate";
import { lireMovpack, ErreurMovpack, VERSION_MOVPACK } from "../src/echange/movpack.ts";
import { sha256Hex } from "../src/domaine/sha256.ts";
import { bibliotheque } from "./aide.ts";

const BIB = new TextEncoder().encode(JSON.stringify(bibliotheque()));
const MEDIA = new TextEncoder().encode("contenu de media");
const CHEMIN_MEDIA = "medias/01JZZZZZZZZZZZZZZZZZZZZZZZ.mp4";

function manifesteBase(surcharge: Record<string, unknown> = {}) {
  return {
    format: "movpack", version: VERSION_MOVPACK, id: "pack-essai", nom: "Essai",
    portee: "discipline", creeLe: new Date("2026-08-09T10:00:00Z").toISOString(),
    versionSchema: 4, versionEditoriale: 1, auteur: "essai",
    empreinte: sha256Hex(BIB), videos: [], algorithme: "SHA-256",
    ...surcharge,
  };
}

function conteneur(manifeste: Record<string, unknown>, avecMedia = true) {
  const entrees: Record<string, Uint8Array> = {
    "manifeste.json": new TextEncoder().encode(JSON.stringify(manifeste)),
    "bibliotheque.json": BIB,
  };
  if (avecMedia) entrees[CHEMIN_MEDIA] = MEDIA;
  return zipSync(entrees);
}

const inventaireComplet = () => [
  { chemin: "bibliotheque.json", taille: BIB.length, sha256: sha256Hex(BIB) },
  { chemin: CHEMIN_MEDIA, taille: MEDIA.length, sha256: sha256Hex(MEDIA) },
];

test("v4 sans inventaire : REFUSÉ (plus de repli silencieux vers le contrôle v3)", async () => {
  // Exactement le conteneur qui était accepté avant D-263 : v4 déclaré,
  // `fichiers` absent, média retenu sans qu'aucune empreinte le couvre.
  await assert.rejects(
    () => lireMovpack(conteneur(manifesteBase())),
    (e: Error) => {
      assert.ok(e instanceof ErreurMovpack, "un refus de conteneur, pas une erreur technique");
      assert.match(e.message, /v4 incomplet|inventaire/i, "le refus dit ce qui manque");
      return true;
    },
  );
});

test("v4 avec un inventaire complet : accepté, et le média est vérifié", async () => {
  const lu = await lireMovpack(conteneur(manifesteBase({ fichiers: inventaireComplet() })));
  assert.equal(lu.manifeste.version, 4);
  assert.equal(lu.videos.size, 1, "le média déclaré et vérifié est retenu");
});

test("v4 : une entrée d'inventaire mal formée est refusée avant toute lecture", async () => {
  const cas: [string, unknown][] = [
    ["entrée non-objet", ["bibliotheque.json"]],
    ["chemin manquant", [{ taille: 1, sha256: "a".repeat(64) }]],
    ["taille négative", [{ chemin: "bibliotheque.json", taille: -1, sha256: "a".repeat(64) }]],
    ["empreinte tronquée", [{ chemin: "bibliotheque.json", taille: BIB.length, sha256: "abc" }]],
  ];
  for (const [quoi, fichiers] of cas) {
    await assert.rejects(
      () => lireMovpack(conteneur(manifesteBase({ fichiers }))),
      ErreurMovpack,
      `${quoi} doit être refusé`,
    );
  }
});

test("v4 : un algorithme d'intégrité inconnu est refusé, jamais supposé", async () => {
  await assert.rejects(
    () => lireMovpack(conteneur(manifesteBase({ fichiers: inventaireComplet(), algorithme: "MD5" }))),
    (e: Error) => {
      assert.match(e.message, /algorithme/i, "le refus nomme l'algorithme");
      return true;
    },
  );
});

test("v3 reste lisible : le repli n'est pas supprimé, il est RÉSERVÉ", async () => {
  const lu = await lireMovpack(conteneur(manifesteBase({ version: 3, algorithme: undefined }), false));
  assert.equal(lu.manifeste.version, 3, "un vrai v3 continue de s'importer");
});

test("v3 : une empreinte globale mal formée est refusée (elle est le seul contrôle)", async () => {
  await assert.rejects(
    () => lireMovpack(conteneur(manifesteBase({ version: 3, empreinte: "trop-court" }), false)),
    ErreurMovpack,
  );
});

test("v3 qui apporte un inventaire : honoré plutôt que puni", async () => {
  const lu = await lireMovpack(conteneur(manifesteBase({ version: 3, fichiers: inventaireComplet() })));
  assert.equal(lu.videos.size, 1, "un conteneur qui en dit plus est vérifié davantage");
});
