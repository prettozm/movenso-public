// Validation centrale des URL externes (S1.3, audit P0.3) — chaque protocole
// refusé a son test ; YouTube est reconnu par liste blanche d'hôtes + id strict.
import { test } from "node:test";
import assert from "node:assert/strict";
import { analyserLien, idYoutubeValide, urlSure, domaineDe } from "../src/securite/liens.ts";

test("analyserLien : https accepté et NORMALISÉ avant stockage", () => {
  const a = analyserLien("  HTTPS://Exemple.org/cours?x=1 ");
  assert.ok(a.ok);
  assert.equal(a.type, "lien");
  assert.equal(a.ref, "https://exemple.org/cours?x=1");
});

test("analyserLien : http refusé avec un message actionnable (décision S1.3)", () => {
  const a = analyserLien("http://exemple.org/video");
  assert.ok(!a.ok);
  assert.match(a.raison, /https/);
});

for (const [lien, quoi] of [
  ["javascript:alert(1)", "javascript"],
  ["data:text/html,<script>1</script>", "data"],
  ["file:///etc/passwd", "file"],
  ["blob:https://exemple.org/x", "blob"],
  ["vbscript:msgbox(1)", "vbscript"],
  ["ftp://exemple.org/f", "ftp"],
  ["about:blank", "about"],
] as const) {
  test(`analyserLien : protocole actif ou inconnu REFUSÉ — ${quoi}:`, () => {
    const a = analyserLien(lien);
    assert.ok(!a.ok, `${quoi}: doit être refusé`);
    assert.match(a.raison, /refusé|https/i);
  });
}

test("analyserLien : chaîne invalide refusée (jamais un href brut)", () => {
  for (const brut of ["", "   ", "pas une url", "//exemple.org", "exemple.org/x"]) {
    const a = analyserLien(brut);
    assert.ok(!a.ok, `« ${brut} » doit être refusé`);
  }
});

test("analyserLien : YouTube strict — toutes les formes d'URL vidéo donnent le même id", () => {
  const formes = [
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "https://youtube.com/watch?t=42&v=dQw4w9WgXcQ",
    "https://m.youtube.com/watch?v=dQw4w9WgXcQ",
    "https://youtu.be/dQw4w9WgXcQ?t=10",
    "https://www.youtube.com/shorts/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/live/dQw4w9WgXcQ",
    "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ",
  ];
  for (const f of formes) {
    const a = analyserLien(f);
    assert.ok(a.ok && a.type === "plateforme" && a.service === "youtube", f);
    assert.equal(a.ref, "dQw4w9WgXcQ", f);
  }
});

test("analyserLien : un hôte NON listé n'est jamais un embed, même avec ?v=", () => {
  const a = analyserLien("https://youtube.exemple.org/watch?v=dQw4w9WgXcQ");
  assert.ok(a.ok);
  assert.equal(a.type, "lien"); // lien nu — jamais interpolé dans un embed
});

test("analyserLien : lien YouTube sans vidéo identifiable = lien nu https", () => {
  for (const f of ["https://www.youtube.com/@chaine", "https://www.youtube.com/playlist?list=PL123", "https://youtu.be/"]) {
    const a = analyserLien(f);
    assert.ok(a.ok && a.type === "lien", f);
  }
});

test("idYoutubeValide : borne la SEULE forme interpolée dans embed/vignette", () => {
  assert.ok(idYoutubeValide("dQw4w9WgXcQ"));
  assert.ok(!idYoutubeValide("abc")); // trop court
  assert.ok(!idYoutubeValide("dQw4w9WgXcQ/../../x")); // traversée
  assert.ok(!idYoutubeValide("id?autoplay=1")); // injection de paramètre
  assert.ok(!idYoutubeValide(""));
});

test("urlSure : re-contrôle d'affichage — https seul devient cliquable", () => {
  assert.equal(urlSure("https://exemple.org/x"), "https://exemple.org/x");
  assert.equal(urlSure("http://exemple.org/x"), null);
  assert.equal(urlSure("javascript:alert(1)"), null);
  assert.equal(urlSure("data:text/html,x"), null);
  assert.equal(urlSure("pas une url"), null);
  assert.equal(urlSure(undefined), null);
  assert.equal(urlSure(null), null);
  assert.equal(urlSure(""), null);
});

test("domaineDe : signale où mène une sortie — www retiré, null si non sûr (S2.11)", () => {
  assert.equal(domaineDe("https://www.youtube.com/watch?v=dQw4w9WgXcQ"), "youtube.com");
  assert.equal(domaineDe("https://exemple.org/x?y=1"), "exemple.org");
  assert.equal(domaineDe("http://exemple.org/x"), null); // jamais de domaine pour un lien non cliquable
  assert.equal(domaineDe("javascript:alert(1)"), null);
  assert.equal(domaineDe(undefined), null);
});
