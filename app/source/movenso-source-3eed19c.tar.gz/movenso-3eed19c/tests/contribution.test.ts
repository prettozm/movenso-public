/** Lot 8C boucle 8C.1 — amendement transactionnel d'une contribution (§18) :
 *  la fonction pure ne mute JAMAIS l'original, ce qui rend le rollback du
 *  service infaillible (aucune valeur modifiée ne réapparaît). */

import { test } from "node:test";
import assert from "node:assert/strict";
import type { Contribution } from "../src/domaine/modele.ts";
import { appliquerAmendement } from "../src/domaine/contribution.ts";

function base(): Contribution {
  return {
    id: "01AAA",
    techniqueId: "01TTT",
    provenance: "personnel",
    description: "texte initial",
    pointsCles: [],
    creeLe: "2026-01-01T00:00:00.000Z",
    medias: [],
  };
}

test("pose une nouvelle description (rognée) sans muter l'original", () => {
  const original = base();
  const amende = appliquerAmendement(original, { description: "  nouveau  " });
  assert.equal(amende.description, "nouveau");
  assert.equal(original.description, "texte initial", "l'original ne doit jamais être muté");
  assert.notEqual(amende, original, "une nouvelle contribution est retournée");
});

test("une description vide EFFACE la clé (absente), l'original garde la sienne", () => {
  const original = base();
  const amende = appliquerAmendement(original, { description: "   " });
  assert.ok(!("description" in amende), "la description doit être absente, pas vide");
  assert.equal(original.description, "texte initial");
});

test("description absente du patch : inchangée", () => {
  const amende = appliquerAmendement(base(), { attribution: "Coach" });
  assert.equal(amende.description, "texte initial");
});

test("attribution posée (rognée) ; attribution vide ignorée", () => {
  assert.equal(appliquerAmendement(base(), { attribution: "  Coach Léa " }).attribution, "Coach Léa");
  assert.ok(!("attribution" in appliquerAmendement(base(), { attribution: "   " })), "une attribution vide n'est pas posée");
});

test("un rollback (réutiliser l'original non muté) restaure l'état exact", () => {
  const original = base();
  const avant = structuredClone(original);
  // simulation du service : on substitue l'amendé puis on « échoue » et on
  // remet l'original — qui doit être identique à sa capture initiale.
  appliquerAmendement(original, { description: "raté", attribution: "raté" });
  assert.deepEqual(original, avant, "l'original sert de point de rollback : jamais altéré");
});
