/** Lot 8A — registre dérivé des médias (REC-008A-001). */

import { test } from "node:test";
import assert from "node:assert/strict";
import { bibliothequeVide, type Media } from "../src/domaine/modele.ts";
import { genererUlid } from "../src/domaine/ulid.ts";
import { referencesVideosLocales, registreMedias } from "../src/domaine/medias.ts";
import { contribution, disciplineJudo, technique } from "./aide.ts";

function mediaLocal(extras: Partial<Media> = {}): Media {
  return { id: genererUlid(), type: "local", ref: "", ...extras };
}

test("registre : même média dans deux contributions → UNE entrée, DEUX références", () => {
  const b = bibliothequeVide();
  const d = disciplineJudo();
  const t = technique(d.id, { nom: "Harai-goshi" });
  b.disciplines.push(d);
  b.techniques.push(t);
  const partage = mediaLocal();
  b.contributions.push(
    { ...contribution(t.id), medias: [partage] },
    { ...contribution(t.id), medias: [{ ...partage }] },
  );
  const registre = registreMedias(b);
  assert.equal(registre.size, 1, "un média partagé = une seule entrée");
  const entree = registre.get(partage.id)!;
  assert.equal(entree.references.length, 2);
  assert.ok(entree.references.every((r) => r.ou === "contribution" && r.nom === "Harai-goshi"));
});

test("registre : bloc de composition et média principal comptent comme références", () => {
  const b = bibliothequeVide();
  const d = disciplineJudo();
  const t = technique(d.id, { nom: "Uchi-mata" });
  const media = mediaLocal();
  b.disciplines.push(d);
  b.techniques.push({ ...t, mediaPrincipalId: media.id });
  b.contributions.push({ ...contribution(t.id), medias: [media] });
  b.compositions.push({
    id: genererUlid(),
    nom: "Ma spéciale",
    provenance: "personnel",
    creeLe: new Date().toISOString(),
    blocs: [{ id: genererUlid(), type: "repere", medias: [{ ...media, id: genererUlid() }] }],
  });
  const registre = registreMedias(b);
  const entree = registre.get(media.id)!;
  assert.deepEqual(
    entree.references.map((r) => r.ou).sort(),
    ["contribution", "media-principal"],
    "le média principal est une référence, jamais un propriétaire",
  );
  const duBloc = [...registre.values()].find((e) => e.references[0]?.ou === "bloc")!;
  assert.ok(duBloc.references[0]!.nom.includes("Ma spéciale"), "le bloc nomme sa composition");
});

test("registre : un lien ne porte ni taille ni extension locales ; vide → vide", () => {
  const b = bibliothequeVide();
  const d = disciplineJudo();
  const t = technique(d.id, { nom: "Kouchi-gari" });
  b.disciplines.push(d);
  b.techniques.push(t);
  const lien: Media = { id: genererUlid(), type: "lien", ref: "https://exemple.org/v" };
  b.contributions.push({ ...contribution(t.id), medias: [lien] });
  const entree = registreMedias(b).get(lien.id)!;
  assert.equal(entree.media.taille, undefined, "jamais de fausse taille locale pour un lien");
  assert.equal(entree.media.extension, undefined);
  assert.equal(referencesVideosLocales(b).size, 0, "un lien n'est pas un fichier local");
  assert.equal(registreMedias(bibliothequeVide()).size, 0);
});

test("registre : une capture À RATTACHER (techniqueId null) est une référence qui protège le fichier (§4)", () => {
  const b = bibliothequeVide();
  const media = mediaLocal();
  b.contributions.push({ ...contribution(null), medias: [media] });
  const entree = registreMedias(b).get(media.id)!;
  assert.equal(entree.references.length, 1);
  assert.equal(entree.references[0]!.nom, "capture à rattacher");
  assert.ok(referencesVideosLocales(b).has(media.id), "le fichier d'une capture à reprendre n'est JAMAIS orphelin");
});

test("referencesVideosLocales : seuls les médias LOCAUX comptent, toutes sources confondues", () => {
  const b = bibliothequeVide();
  const d = disciplineJudo();
  const t = technique(d.id, { nom: "Seoi-nage" });
  b.disciplines.push(d);
  b.techniques.push(t);
  const local = mediaLocal();
  b.contributions.push({ ...contribution(t.id), medias: [local, { id: genererUlid(), type: "plateforme", ref: "abc", service: "youtube" }] });
  const refs = referencesVideosLocales(b);
  assert.deepEqual([...refs], [local.id]);
});
