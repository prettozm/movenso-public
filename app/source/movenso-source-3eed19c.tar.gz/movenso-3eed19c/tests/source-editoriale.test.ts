/** Boucle 3.7 — nom éditorial d'une source : la valeur la plus précise,
 *  jamais un slug/UUID/id de pack visible (lot 3 §7/§17.F). */

import { test } from "node:test";
import assert from "node:assert/strict";
import { nomEditorialSource } from "../src/app/vues.ts";

test("une attribution vague contenue dans le nom du pack cède au nom du pack", () => {
  assert.equal(nomEditorialSource({ attribution: "Club", origine: { pack: "club-judo" } }), "Club judo");
});

test("une attribution plus précise que le nom du pack est conservée", () => {
  assert.equal(
    nomEditorialSource({ attribution: "Judo Club de Castres", origine: { pack: "club-judo" } }),
    "Judo Club de Castres",
  );
});

test("attribution et pack équivalents : l'attribution telle quelle", () => {
  assert.equal(nomEditorialSource({ attribution: "Kodokan", origine: { pack: "kodokan" } }), "Kodokan");
});

test("sans attribution : le nom humanisé du pack, jamais le slug brut", () => {
  assert.equal(nomEditorialSource({ origine: { pack: "club-judo" } }), "Club judo");
  assert.ok(!nomEditorialSource({ origine: { pack: "club-judo" } }).includes("club-judo"));
});

test("contribution locale sans attribution : « Moi »", () => {
  assert.equal(nomEditorialSource({}), "Moi");
});

test("adaptation locale (attribution sans origine) : l'attribution", () => {
  assert.equal(
    nomEditorialSource({ attribution: "Adaptation locale d'après Kodokan" }),
    "Adaptation locale d'après Kodokan",
  );
});
