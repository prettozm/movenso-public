/** Lot 8A boucle 8A.4 — espace disponible (§10) et nommage physique (§6). */

import { test } from "node:test";
import assert from "node:assert/strict";
import { evaluerEspace, margeSecurite, tailleEnClair } from "../src/domaine/espace.ts";
import { nomPhysiqueVideo } from "../src/stockage/opfs.ts";

test("evaluerEspace : refus AVANT mutation quand l'estimation fiable est insuffisante", () => {
  const v = evaluerEspace(100_000_000, { usage: 950_000_000, quota: 1_000_000_000 });
  assert.equal(v.suffisant, false);
  assert.equal(v.fiable, true);
  assert.equal(v.requis, 100_000_000);
  assert.equal(v.disponible, 50_000_000);
});

test("evaluerEspace : accepte quand l'écriture + la marge tiennent", () => {
  const v = evaluerEspace(100_000_000, { usage: 0, quota: 1_000_000_000 });
  assert.equal(v.suffisant, true);
  // la marge protège aussi les snapshots : 10 %, plancher 16 Mo
  assert.equal(margeSecurite(100_000_000), 16_000_000);
  assert.equal(margeSecurite(1_000_000_000), 100_000_000);
});

test("evaluerEspace : sans estimation, HONNÊTE — on procède sans inventer ni refus ni garantie", () => {
  const v = evaluerEspace(100_000_000, null);
  assert.equal(v.suffisant, true, "jamais un refus inventé");
  assert.equal(v.fiable, false, "jamais une garantie inventée");
  assert.equal(v.disponible, null);
});

test("evaluerEspace : un usage supérieur au quota ne produit jamais un disponible négatif", () => {
  const v = evaluerEspace(1, { usage: 2_000_000, quota: 1_000_000 });
  assert.equal(v.disponible, 0);
  assert.equal(v.suffisant, false);
});

test("tailleEnClair : Ko, Mo, Go lisibles", () => {
  assert.equal(tailleEnClair(2048), "2 Ko");
  assert.equal(tailleEnClair(64 * 1024), "66 Ko");
  assert.equal(tailleEnClair(12_400_000), "12.4 Mo");
  assert.equal(tailleEnClair(3_200_000_000), "3.2 Go");
});

test("nomPhysiqueVideo (§6) : <id>.<extension> quand connue, id nu sinon — jamais un nom humain", () => {
  assert.equal(nomPhysiqueVideo("01ARZ3NDEKTSV4RRFFQ69G5FAV", "webm"), "01ARZ3NDEKTSV4RRFFQ69G5FAV.webm");
  assert.equal(nomPhysiqueVideo("01ARZ3NDEKTSV4RRFFQ69G5FAV"), "01ARZ3NDEKTSV4RRFFQ69G5FAV");
});
