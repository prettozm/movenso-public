/**
 * Doublons potentiels (arbitrage humain 2026-07-13, D-068) — AIDE, jamais
 * contrainte. Depuis D-067, deux packs de même nom produisent deux identités
 * distinctes ; ce module DÉTECTE ces homonymies fortes (même discipline,
 * sources différentes, nom normalisé identique) et les présente comme des
 * paires à arbitrer — jamais une fusion subie, jamais un blocage à l'import.
 *
 * Décisions possibles (traitées par l'application) : conserver les deux (défaut),
 * garder l'une (avec sauvegarde préalable), fusionner sélectivement, ou marquer
 * « ce ne sont pas des doublons » (paire ignorée, persistée, jamais reproposée).
 *
 * Fonctions PURES : rien n'est muté, la fusion retourne une nouvelle
 * bibliothèque. L'origine de chaque élément est conservée dans les données
 * (contributions et médias gardent leur `origine`/id) sans jamais être exposée
 * dans la fiche normale.
 */

import type { Bibliotheque, Media, Technique } from "./modele.ts";
import { normaliserPourRecherche as norm } from "./recherche.ts";
import { sourceDe } from "./modele.ts";
import { validerBibliotheque } from "./validation.ts";

export interface PaireDoublon {
  aId: string;
  bId: string;
}

/** Clé STABLE d'une paire (indépendante de l'ordre) — sert de marque « ignorée ». */
export function clePaire(id1: string, id2: string): string {
  return [id1, id2].sort().join("|");
}

/** Distance de Levenshtein bornée : arrête dès que le seuil est dépassé
 *  (renvoie alors `seuil + 1`). Suffit pour « ces deux noms sont-ils proches ». */
function distanceBornee(a: string, z: string, seuil: number): number {
  if (Math.abs(a.length - z.length) > seuil) return seuil + 1;
  let prec = Array.from({ length: z.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) {
    const cour = [i, ...new Array<number>(z.length).fill(0)];
    let minLigne = cour[0]!;
    for (let j = 1; j <= z.length; j++) {
      const cout = a[i - 1] === z[j - 1] ? 0 : 1;
      cour[j] = Math.min(prec[j]! + 1, cour[j - 1]! + 1, prec[j - 1]! + cout);
      if (cour[j]! < minLigne) minLigne = cour[j]!;
    }
    if (minLigne > seuil) return seuil + 1; // toute la ligne dépasse : inutile de continuer
    prec = cour;
  }
  return prec[z.length]!;
}

/** Deux noms sont « proches » : normalisés identiques, ou à faible distance
 *  d'édition (variantes de romanisation type « barai » / « harai », coquilles).
 *  Le seuil croît doucement avec la longueur ; sous 4 caractères, seule
 *  l'égalité exacte compte (trop de collisions autrement). */
function nomsProches(a: string, z: string): boolean {
  const na = norm(a);
  const nz = norm(z);
  if (na === nz) return true;
  const L = Math.max(na.length, nz.length);
  if (L < 4) return false;
  const seuil = Math.min(3, Math.max(1, Math.floor(L * 0.2)));
  return distanceBornee(na, nz, seuil) <= seuil;
}

/**
 * Détecte les paires de fiches en forte homonymie : même discipline, SOURCES
 * différentes (deux packs, ou local vs pack), nom normalisé identique OU proche
 * (variantes de romanisation, coquilles — cf. `nomsProches`). Les paires
 * marquées « pas des doublons » (`ignorees`) sont écartées. Résultat
 * déterministe (trié).
 */
export function detecterDoublons(b: Bibliotheque, ignorees: Iterable<string> = []): PaireDoublon[] {
  const ign = new Set(ignorees);
  const paires: PaireDoublon[] = [];
  const parDiscipline = new Map<string, Technique[]>();
  for (const t of b.techniques) parDiscipline.set(t.disciplineId, [...(parDiscipline.get(t.disciplineId) ?? []), t]);
  for (const groupe of parDiscipline.values()) {
    for (let i = 0; i < groupe.length; i++) {
      for (let j = i + 1; j < groupe.length; j++) {
        const a = groupe[i]!;
        const z = groupe[j]!;
        if (sourceDe(a) === sourceDe(z)) continue; // même source : pas un doublon inter-pack
        if (!nomsProches(a.nom, z.nom)) continue; // nom identique OU proche (variantes de romanisation, coquilles)
        if (ign.has(clePaire(a.id, z.id))) continue;
        paires.push({ aId: a.id, bId: z.id });
      }
    }
  }
  paires.sort((p, q) => clePaire(p.aId, p.bId).localeCompare(clePaire(q.aId, q.bId)));
  return paires;
}

export interface CoteDoublon {
  technique: Technique;
  source: string;
  description: string;
  pointsCles: string[];
  medias: Media[];
  niveaux: string[];
  relations: number;
}

export interface DifferencesDoublon {
  a: CoteDoublon;
  b: CoteDoublon;
}

/** Différences essentielles d'une paire (pour l'affichage) : textes, médias,
 *  niveaux, relations — jamais une décision, juste de quoi arbitrer. */
export function differencesDoublon(b: Bibliotheque, aId: string, bId: string): DifferencesDoublon | null {
  const cote = (id: string): CoteDoublon | null => {
    const technique = b.techniques.find((t) => t.id === id);
    if (!technique) return null;
    const contribs = b.contributions.filter((c) => c.techniqueId === id && c.provenance !== "personnel");
    return {
      technique,
      source: sourceDe(technique),
      description: contribs.map((c) => c.description ?? "").filter(Boolean).join("\n\n"),
      pointsCles: contribs.flatMap((c) => c.pointsCles),
      medias: contribs.flatMap((c) => c.medias),
      niveaux: technique.niveauxIds,
      relations: technique.relations.length,
    };
  };
  const a = cote(aId);
  const b2 = cote(bId);
  if (!a || !b2) return null;
  return { a, b: b2 };
}

type Cote = "a" | "b";
type CoteOuLesDeux = "a" | "b" | "deux";

/** Choix de fusion sélective — chaque dimension arbitrée séparément (jamais un
 *  empilement automatique). */
export interface ChoixFusion {
  titre: Cote; // nom, appellation traditionnelle, famille
  textes: CoteOuLesDeux;
  medias: CoteOuLesDeux;
  niveaux: CoteOuLesDeux;
  relations: CoteOuLesDeux;
}

/** Identité d'un média pour la déduplication : son empreinte si connue, sinon
 *  son type+référence (deux fois la même vidéo YouTube ne comptent qu'une fois). */
function idMediaLogique(m: Media): string {
  return m.sha256 ? `sha:${m.sha256}` : `${m.type}:${m.ref}`;
}

/**
 * Fusionne deux fiches homonymes en UNE seule, cohérente, selon `choix`. Ne
 * duplique jamais un média (déduplication par empreinte/référence) et n'empile
 * jamais les textes (seuls les côtés choisis survivent ; un côté gardé
 * uniquement pour ses médias voit son texte neutralisé). Toutes les références
 * externes (relations entrantes, favoris, blocs de composition) sont réécrites
 * de B vers l'identité fusionnée. L'origine de chaque contribution/média est
 * conservée. Fonction pure : retourne une nouvelle bibliothèque.
 */
export function fusionnerDoublons(b: Bibliotheque, aId: string, bId: string, choix: ChoixFusion): Bibliotheque {
  const nb = structuredClone(b);
  const a = nb.techniques.find((t) => t.id === aId);
  const z = nb.techniques.find((t) => t.id === bId);
  if (!a || !z) throw new Error("Fusion impossible : identité introuvable");
  if (a.disciplineId !== z.disciplineId) throw new Error("Fusion impossible : disciplines différentes");

  const titreSrc = choix.titre === "a" ? a : z;
  const coteDe = (id: string): Cote => (id === a.id ? "a" : "b");

  // 1) Contributions retenues + médias dédupliqués, selon les choix.
  const contribsA = nb.contributions.filter((c) => c.techniqueId === a.id && c.provenance !== "personnel");
  const contribsZ = nb.contributions.filter((c) => c.techniqueId === z.id && c.provenance !== "personnel");
  const personnelles = nb.contributions.filter(
    (c) => (c.techniqueId === a.id || c.techniqueId === z.id) && c.provenance === "personnel",
  );
  const mediasPris = new Set<string>();
  const garderMediaDeCote = (cote: Cote) => choix.medias === "deux" || choix.medias === cote;
  const garderTexteDeCote = (cote: Cote) => choix.textes === "deux" || choix.textes === cote;

  const retenues = [];
  for (const c of [...contribsA, ...contribsZ]) {
    const cote = coteDe(c.techniqueId!);
    // Médias du côté, dédupliqués globalement (jamais deux fois le même fichier).
    const medias = garderMediaDeCote(cote)
      ? c.medias.filter((m) => {
          const cle = idMediaLogique(m);
          if (mediasPris.has(cle)) return false;
          mediasPris.add(cle);
          return true;
        })
      : [];
    const garderTexte = garderTexteDeCote(cote);
    if (!garderTexte && medias.length === 0) continue; // rien à conserver de cette contribution
    const nc = structuredClone(c);
    nc.techniqueId = a.id; // toutes rattachées à l'identité fusionnée (id de A conservé)
    nc.medias = medias;
    if (!garderTexte) {
      // conservée uniquement pour ses médias → texte neutralisé (pas d'empilement)
      delete nc.description;
      nc.pointsCles = [];
      delete nc.variantes;
    }
    retenues.push(nc);
  }
  // Voie H (D-101) : quand on garde les deux textes, on les COMBINE en une seule
  // présentation (priorité A puis B) — la fiche mono-présentation les affiche
  // alors tous, rien n'est masqué. Points clés en union (A d'abord, dédupliqués).
  if (choix.textes === "deux") {
    const refs = retenues.filter((c) => c.provenance !== "personnel");
    if (refs.length > 1) {
      const cible = refs[0]!;
      const descriptions: string[] = [];
      const pointsCles: string[] = [];
      for (const c of refs) {
        const d = (c.description ?? "").trim();
        if (d && !descriptions.includes(d)) descriptions.push(d);
        for (const p of c.pointsCles) {
          const pt = p.trim();
          if (pt && !pointsCles.includes(pt)) pointsCles.push(pt);
        }
      }
      if (descriptions.length) cible.description = descriptions.join("\n\n");
      else delete cible.description;
      cible.pointsCles = pointsCles;
      for (const c of refs) if (c !== cible) { delete c.description; c.pointsCles = []; delete c.variantes; }
    }
  }
  // Carnet personnel : jamais détruit, rattaché à l'identité fusionnée.
  for (const c of personnelles) c.techniqueId = a.id;

  // 2) Identité fusionnée (garde l'id de A) : titre/métadonnées, niveaux, relations.
  a.nom = titreSrc.nom;
  if (titreSrc.nomTraditionnel !== undefined) a.nomTraditionnel = titreSrc.nomTraditionnel;
  else delete a.nomTraditionnel;
  if (titreSrc.familleId !== undefined) a.familleId = titreSrc.familleId;
  else delete a.familleId;

  const niveaux = new Set<string>();
  if (choix.niveaux !== "b") for (const n of a.niveauxIds) niveaux.add(n);
  if (choix.niveaux !== "a") for (const n of z.niveauxIds) niveaux.add(n);
  a.niveauxIds = [...niveaux];

  const relations = [];
  const vues = new Set<string>();
  const sources = [
    ...(choix.relations !== "b" ? a.relations : []),
    ...(choix.relations !== "a" ? z.relations : []),
  ];
  for (const r of sources) {
    const cible = r.cibleId === z.id ? a.id : r.cibleId; // une relation vers B pointe désormais A
    if (cible === a.id) continue; // pas d'auto-référence
    const cle = `${r.type}|${cible}`;
    if (vues.has(cle)) continue;
    vues.add(cle);
    relations.push({ ...r, cibleId: cible }); // conserve note/priorité (D-134)
  }
  a.relations = relations;

  // Média principal : rester sur un média réellement conservé.
  const idsMediasRetenus = new Set(retenues.flatMap((c) => c.medias.map((m) => m.id)));
  if (!a.mediaPrincipalId || !idsMediasRetenus.has(a.mediaPrincipalId)) {
    const premier = retenues.flatMap((c) => c.medias)[0];
    if (premier) a.mediaPrincipalId = premier.id;
    else delete a.mediaPrincipalId;
  }

  // 3) Réécrire toutes les références externes de B vers A (jamais d'orphelin).
  nb.contributions = [
    ...nb.contributions.filter((c) => c.techniqueId !== a.id && c.techniqueId !== z.id),
    ...retenues,
    ...personnelles,
  ];
  nb.techniques = nb.techniques.filter((t) => t.id !== z.id);
  for (const t of nb.techniques) {
    if (t.id === a.id) continue;
    const vus = new Set<string>();
    t.relations = t.relations
      .map((r) => ({ ...r, cibleId: r.cibleId === z.id ? a.id : r.cibleId })) // conserve note/priorité (D-134)
      .filter((r) => {
        if (r.cibleId === t.id) return false;
        const cle = `${r.type}|${r.cibleId}`;
        if (vus.has(cle)) return false;
        vus.add(cle);
        return true;
      });
  }
  nb.favoris = [...new Set(nb.favoris.map((id) => (id === z.id ? a.id : id)))];
  for (const compo of nb.compositions) {
    for (const bloc of compo.blocs) if (bloc.type === "technique" && bloc.techniqueId === z.id) bloc.techniqueId = a.id;
  }
  // La paire fusionnée n'a plus lieu d'être ignorée/reproposée : B n'existe plus.
  if (nb.doublonsIgnores) nb.doublonsIgnores = nb.doublonsIgnores.filter((cle) => cle !== clePaire(aId, bId));

  validerBibliotheque(nb);
  return nb;
}

/**
 * Défusion (D-101, voie H) : rétablit les DEUX fiches d'origine depuis le bundle
 * `EntreeFusion`. La fiche fusionnée courante (et ses contributions) est retirée
 * et remplacée par les états PRÉ-fusion de A et de B (technique, contributions,
 * favori). Limite assumée : les liens ENTRANTS redirigés vers la fiche fusionnée
 * (relations d'autres fiches, blocs de composition) restent sur la fiche A ; les
 * modifications faites sur la fiche fusionnée depuis la fusion ne sont pas
 * conservées. Fonction pure : retourne une nouvelle bibliothèque.
 */
export function defusionnerDoublons(b: Bibliotheque, fusionneeId: string): Bibliotheque {
  const nb = structuredClone(b);
  const idx = (nb.fusions ?? []).findIndex((f) => f.fusionneeId === fusionneeId);
  if (idx < 0) throw new Error("Défusion impossible : fusion introuvable");
  const f = nb.fusions![idx]!;
  const aId = f.a.technique.id;
  const bId = f.b.technique.id;
  // Retire la fiche fusionnée courante (id de A) et toutes ses contributions.
  nb.techniques = nb.techniques.filter((t) => t.id !== aId);
  nb.contributions = nb.contributions.filter((c) => c.techniqueId !== aId);
  // Rétablit les deux fiches d'origine (structuredClone : ids et contenus intacts).
  nb.techniques.push(structuredClone(f.a.technique), structuredClone(f.b.technique));
  nb.contributions.push(...f.a.contributions.map((c) => structuredClone(c)), ...f.b.contributions.map((c) => structuredClone(c)));
  // Favoris d'origine des deux fiches.
  nb.favoris = nb.favoris.filter((id) => id !== aId && id !== bId);
  if (f.a.etaitFavori) nb.favoris.push(aId);
  if (f.b.etaitFavori) nb.favoris.push(bId);
  nb.fusions!.splice(idx, 1);
  if (nb.fusions!.length === 0) delete nb.fusions;
  validerBibliotheque(nb);
  return nb;
}
