/**
 * Rapprochement des identités à l'import d'un pack (D-013/D-015, révisé par
 * l'arbitrage humain D-067) : une discipline = une pratique du mouvement. Depuis D-067, un
 * pack importé NE FUSIONNE PLUS automatiquement avec les identités existantes :
 * deux packs contenant une technique de même nom produisent DEUX identités
 * distinctes (« Ashi-guruma · Kodokan » et « Ashi-guruma · Clubjudo »), chacune
 * liée à son pack, consultable / modifiable / supprimable / exportable
 * indépendamment. Ni leurs textes, ni leurs médias, ni leurs relations ne sont
 * mêlés en silence.
 *
 * Propriétés garanties (testées dans tests/rapprochement.test.ts) :
 * 1. AUCUNE fusion automatique : un homonyme d'un autre pack crée une identité
 *    distincte ; la réunion réelle passe uniquement par une `regle` explicite
 *    (arbitrage), seule dans la même discipline ;
 * 2. aucune fusion silencieuse — homonymies et quasi-correspondances sont
 *    exposées comme INDICES (suggestions), jamais subies ; les contributions
 *    gardent leur origine ;
 * 3. traçabilité : chaque identité créée et chaque contribution importée
 *    porte `origine { pack, element }` ;
 * 4. réimport idempotent : même pack réimporté → même bibliothèque
 *    (contributions remplacées par clé d'origine, ids conservés, éléments
 *    disparus retirés s'ils ne portent plus rien) ;
 * 5. réunion explicite : une `regle` déterministe réutilisable (table
 *    versionnée) rejoint une identité cible, ou échoue franchement ;
 * 6. relations réécrites vers les identités du pack (ou réunies par règle),
 *    résultat validé.
 */

import type { Bibliotheque, ConflitLiaison, Discipline, Relation, Technique } from "./modele.ts";
import { normaliserPourRecherche as norm } from "./recherche.ts";
import { validerBibliotheque } from "./validation.ts";

/** Règle arbitrée : « le nom `de` (du pack) désigne l'identité `vers` ». */
export interface RegleRapprochement {
  de: string;
  vers: string;
}

interface SuggestionRapprochement {
  nom: string; // nom importé, resté identité distincte
  candidats: string[]; // identités existantes proches
  motif: "quasi-correspondance" | "ambigu";
}

export interface RapportImport {
  discipline: string;
  rejointes: string[]; // noms des techniques ayant rejoint une identité
  creees: string[];
  retirees: string[]; // éléments du pack disparus au réimport
  suggestions: SuggestionRapprochement[];
  /** Liaisons dont le pack propose une raison/priorité DIFFÉRENTE de l'existant
   *  (D-157) — détectées, jamais appliquées ni écartées en silence : à arbitrer
   *  (la mienne / celle du pack / les deux). */
  conflitsLiaisons: number;
  /** Liaisons que ce pack avait apportées et que sa NOUVELLE version ne déclare
   *  plus (D-243) — proposées au retrait, jamais retirées d'office. Compté à
   *  part de `conflitsLiaisons` : ce n'est pas le même geste, ni la même
   *  phrase à écrire à l'utilisateur. */
  retraitsProposes: number;
}

export class ErreurRapprochement extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ErreurRapprochement";
  }
}

/** Distance d'édition bornée (suffit pour départager « proche » / « pas proche »). */
function distance(a: string, b: string, max: number): number {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let precedente = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const courante = [i];
    for (let j = 1; j <= b.length; j++) {
      courante[j] = Math.min(
        (precedente[j] ?? 0) + 1,
        (courante[j - 1] ?? 0) + 1,
        (precedente[j - 1] ?? 0) + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
    precedente = courante;
  }
  return precedente[b.length] ?? max + 1;
}

/** Doublons potentiels à la CRÉATION d'une technique (lot 4 §5) — même
 *  notion de proximité que l'import, sans modifier le moteur : une
 *  correspondance exacte (nom normalisé, même discipline) se recommande,
 *  les quasi-correspondances (distance ≤ 2 ou inclusion) se suggèrent.
 *  Plusieurs correspondances exactes = ambigu : présentées en candidates,
 *  jamais de décision silencieuse. */
export function doublonsPotentiels(
  b: Bibliotheque,
  disciplineId: string,
  nom: string,
): { exacte: Technique | null; proches: Technique[] } {
  const q = norm(nom);
  if (q.length < 3) return { exacte: null, proches: [] };
  const dansD = b.techniques.filter((t) => t.disciplineId === disciplineId);
  const exactes = dansD.filter((t) => norm(t.nom) === q);
  const exacte = exactes.length === 1 ? exactes[0]! : null;
  const proches = [
    ...(exactes.length > 1 ? exactes : []),
    ...dansD.filter((t) => {
      const n = norm(t.nom);
      return n !== q && (distance(n, q, 2) <= 2 || n.includes(q) || q.includes(n));
    }),
  ].slice(0, 4);
  return { exacte, proches };
}

function fusionnerTaxonomie<T extends { id: string; nom: string }>(
  existants: T[],
  importes: T[],
  packId: string,
): Map<string, string> {
  const correspondance = new Map<string, string>();
  for (const entrant of importes) {
    const present = existants.find((e) => norm(e.nom) === norm(entrant.nom));
    if (present) {
      correspondance.set(entrant.id, present.id);
    } else {
      const id = existants.some((e) => e.id === entrant.id) ? `${packId}-${entrant.id}` : entrant.id;
      existants.push({ ...entrant, id });
      correspondance.set(entrant.id, id);
    }
  }
  return correspondance;
}

/**
 * Importe un pack (bibliothèque à une seule discipline) dans une bibliothèque.
 * Fonction pure : ne modifie pas ses arguments.
 */
export function importerDansBibliotheque(
  existante: Bibliotheque,
  pack: Bibliotheque,
  options: { packId: string; regles?: RegleRapprochement[] },
): { bibliotheque: Bibliotheque; rapport: RapportImport } {
  if (pack.disciplines.length === 0) {
    throw new ErreurRapprochement("Un pack importable contient au moins une discipline");
  }
  const b = structuredClone(existante);
  const packId = options.packId;
  const regles = new Map((options.regles ?? []).map((r) => [norm(r.de), norm(r.vers)]));
  const rapport: RapportImport = {
    discipline: pack.disciplines.map((d) => d.nom).join(" + "),
    rejointes: [],
    creees: [],
    retirees: [],
    suggestions: [],
    conflitsLiaisons: 0,
    retraitsProposes: 0,
  };

  // 2bis. Types de relation (données depuis D-020.2) : rejoignent par id ;
  // l'existant fait foi (déterministe), un type inconnu est ajouté avec origine.
  for (const type of pack.typesRelation ?? []) {
    const existant = b.typesRelation.find((t) => t.id === type.id);
    if (!existant) {
      b.typesRelation.push({ ...structuredClone(type), origine: { pack: packId, element: type.id } });
    } else {
      // Enrichit les champs SÉMANTIQUES manquants (D-136 : rôle/ordre) sans
      // toucher aux libellés existants (l'existant fait foi pour le reste).
      if (existant.role === undefined && type.role !== undefined) existant.role = type.role;
      if (existant.ordre === undefined && type.ordre !== undefined) existant.ordre = type.ordre;
    }
  }
  // 2ter. Types d'alerte (D-136) : rejoignent par id, l'existant fait foi.
  if (pack.typesAlerte?.length) {
    b.typesAlerte ??= [];
    for (const ta of pack.typesAlerte) {
      if (!b.typesAlerte.some((x) => x.id === ta.id)) b.typesAlerte.push(structuredClone(ta));
    }
  }

  const idVers = new Map<string, string>(); // id du pack → id final
  const elementsPresents = new Set<string>();
  // Identités déjà créées par ce pack (toutes disciplines) — clé d'idempotence.
  const parOrigineGlobal = new Map(
    b.techniques.filter((t) => t.origine?.pack === packId).map((t) => [t.origine!.element, t]),
  );

  // Chaque discipline du pack est traitée indépendamment (propriété 1 :
  // aucun rapprochement de techniques entre disciplines différentes).
  for (const disciplinePack of pack.disciplines) {
    // 1. Discipline : rejoint par nom normalisé, à défaut par ULID identique (même
    //    discipline renommée localement puis pack réimporté — jamais un doublon
    //    d'id, D-116b), sinon créée.
    let discipline =
      b.disciplines.find((d) => norm(d.nom) === norm(disciplinePack.nom)) ??
      b.disciplines.find((d) => d.id === disciplinePack.id);
    if (!discipline) {
      discipline = structuredClone(disciplinePack);
      b.disciplines.push(discipline);
    }
    const cible: Discipline = discipline;

    // 2. Taxonomies : familles et niveaux rejoignent par nom normalisé.
    const familleVers = fusionnerTaxonomie(cible.familles, disciplinePack.familles, packId);
    const niveauVers = fusionnerTaxonomie(cible.niveaux, disciplinePack.niveaux, packId);

    // 3. Identités de technique de cette discipline.
    const dansDiscipline = () => b.techniques.filter((t) => t.disciplineId === cible.id);
    const parNom = new Map<string, Technique[]>();
    for (const t of dansDiscipline()) {
      const cle = norm(t.nom);
      parNom.set(cle, [...(parNom.get(cle) ?? []), t]);
    }

    for (const entrante of pack.techniques.filter((t) => t.disciplineId === disciplinePack.id)) {
      const element = entrante.origine?.element ?? entrante.id;
      elementsPresents.add(element);

      // Réimport du même élément : c'est la même identité, quoi qu'en dise le nom.
      const dejaLa = parOrigineGlobal.get(element);
      if (dejaLa) {
        idVers.set(entrante.id, dejaLa.id);
        completer(dejaLa, entrante, familleVers, niveauVers);
        // L'élément source fait foi pour sa propre identité (D-118/D-222) : un
        // réimport MET À JOUR le nom, le sous-titre et la couverture FOURNIS
        // par le pack propriétaire ; un champ que le pack n'apporte pas ne
        // retire rien (une couverture posée localement survit à un pack qui
        // n'en publie pas). La VOIX locale (contributions), elle, reste
        // intouchable (D-027).
        dejaLa.nom = entrante.nom;
        if (entrante.nomTraditionnel) dejaLa.nomTraditionnel = entrante.nomTraditionnel;
        if (entrante.couverture) dejaLa.couverture = structuredClone(entrante.couverture);
        rapport.rejointes.push(entrante.nom);
        continue;
      }

      // MÊME ULID qu'une identité déjà présente = la MÊME identité (un ULID est
      // unique) : typiquement un pack EXPORTÉ depuis cette bibliothèque, réimporté
      // alors que les originaux locaux sont encore là. On rejoint sans écraser le
      // nom local — jamais un doublon d'id (D-116b). Distinct de l'homonymie D-067
      // (mêmes NOMS, ids différents → identités distinctes).
      const memeId = b.techniques.find((x) => x.id === entrante.id);
      if (memeId) {
        idVers.set(entrante.id, memeId.id);
        completer(memeId, entrante, familleVers, niveauVers);
        rapport.rejointes.push(entrante.nom);
        continue;
      }

      const aRegle = regles.has(norm(entrante.nom));
      const cleVoulue = regles.get(norm(entrante.nom)) ?? norm(entrante.nom);
      const candidates = (parNom.get(cleVoulue) ?? []).filter((t) => t.origine?.pack !== packId);
      if (aRegle) {
        // Fusion DÉTERMINISTE et EXPLICITE (arbitrage humain via `regles`) : le
        // SEUL chemin de réunion d'identités entre packs distincts (D-067).
        if (candidates.length === 0) {
          throw new ErreurRapprochement(
            `Règle « ${entrante.nom} » → « ${cleVoulue} » : aucune identité cible dans « ${cible.nom} »`,
          );
        }
        if (candidates.length === 1) {
          const identite = candidates[0]!;
          idVers.set(entrante.id, identite.id);
          completer(identite, entrante, familleVers, niveauVers);
          rapport.rejointes.push(entrante.nom);
          continue;
        }
        // Règle ambiguë (plusieurs cibles possibles) : jamais de choix silencieux.
        rapport.suggestions.push({ nom: entrante.nom, candidats: candidates.map((c) => c.nom), motif: "ambigu" });
      } else {
        // AUCUNE fusion automatique (arbitrage humain 2026-07-13, D-067) : deux
        // packs de même nom donnent deux identités DISTINCTES, chacune liée à
        // son pack (consultable, modifiable, supprimable, exportable
        // indépendamment). On expose seulement des INDICES d'homonymie — jamais
        // une fusion, jamais une action subie ; une réunion réelle exige une
        // `regle` explicite.
        if (candidates.length > 1) {
          rapport.suggestions.push({ nom: entrante.nom, candidats: candidates.map((c) => c.nom), motif: "ambigu" });
        } else if (candidates.length === 0) {
          const proches = dansDiscipline()
            .filter((t) => t.origine?.pack !== packId && distance(norm(t.nom), norm(entrante.nom), 2) <= 2)
            .map((t) => t.nom);
          if (proches.length) {
            rapport.suggestions.push({ nom: entrante.nom, candidats: proches, motif: "quasi-correspondance" });
          }
        }
        // candidates.length === 1 : homonyme exact d'un autre pack → identité
        // distincte, silencieuse (le cas nominal des deux packs de même nom).
      }
      const creee: Technique = {
        ...structuredClone(entrante),
        disciplineId: cible.id,
        niveauxIds: entrante.niveauxIds.map((n) => niveauVers.get(n) ?? n),
        relations: [], // posées après remappage global
        origine: { pack: packId, element },
      };
      if (entrante.familleId) creee.familleId = familleVers.get(entrante.familleId) ?? entrante.familleId;
      else delete creee.familleId;
      b.techniques.push(creee);
      parNom.set(norm(creee.nom), [...(parNom.get(norm(creee.nom)) ?? []), creee]);
      idVers.set(entrante.id, creee.id);
      rapport.creees.push(entrante.nom);
    }
  }

  // 4. Retraits (idempotence, propriété 4) : les identités créées par ce pack
  //    dont l'élément a disparu, si plus rien d'autre ne s'y rattache.
  for (const [element, t] of parOrigineGlobal) {
    if (elementsPresents.has(element)) continue;
    b.contributions = b.contributions.filter(
      (c) => !(c.origine?.pack === packId && c.origine.element === element),
    );
    const encoreUtile = b.contributions.some((c) => c.techniqueId === t.id);
    if (!encoreUtile) {
      b.techniques = b.techniques.filter((x) => x.id !== t.id);
      rapport.retirees.push(t.nom);
    }
  }

  // 5. Contributions : remplacées par clé d'origine (ids conservés), sinon ajoutées.
  for (const entrante of pack.contributions) {
    const element = entrante.origine?.element ?? entrante.id;
    const techniqueId = entrante.techniqueId ? idVers.get(entrante.techniqueId) ?? null : null;
    const existanteMeme = b.contributions.find(
      // par clé d'origine, OU par ULID identique (round-trip d'un pack exporté
      // d'ici : on remplace au lieu de dupliquer l'id — D-116b).
      (c) => (c.origine?.pack === packId && c.origine.element === element) || c.id === entrante.id,
    );
    if (existanteMeme) {
      Object.assign(existanteMeme, structuredClone(entrante), {
        id: existanteMeme.id,
        techniqueId,
        origine: { pack: packId, element },
      });
    } else {
      b.contributions.push({
        ...structuredClone(entrante),
        techniqueId,
        origine: { pack: packId, element },
      });
    }
  }

  // 5bis. Compositions : mêmes règles que les contributions (remplacées par
  // clé d'origine, retirées si disparues) ; leurs blocs « technique » sont
  // réécrits vers les identités réunies — une composition référence, ne
  // duplique jamais (D-020.1).
  const compoParOrigine = new Map(
    b.compositions.filter((c) => c.origine?.pack === packId).map((c) => [c.origine!.element, c]),
  );
  const compoPresentes = new Set<string>();
  for (const entrante of pack.compositions ?? []) {
    const element = entrante.origine?.element ?? entrante.id;
    compoPresentes.add(element);
    const blocs = entrante.blocs.map((bl) =>
      bl.type === "technique" && bl.techniqueId
        ? { ...structuredClone(bl), techniqueId: idVers.get(bl.techniqueId) ?? bl.techniqueId }
        : structuredClone(bl),
    );
    // par clé d'origine, OU par ULID identique (round-trip — jamais un doublon d'id, D-116b).
    const deja = compoParOrigine.get(element) ?? b.compositions.find((c) => c.id === entrante.id);
    if (deja) {
      Object.assign(deja, structuredClone(entrante), { id: deja.id, blocs, origine: { pack: packId, element } });
    } else {
      b.compositions.push({ ...structuredClone(entrante), blocs, origine: { pack: packId, element } });
    }
  }
  for (const [element, c] of compoParOrigine) {
    if (!compoPresentes.has(element)) b.compositions = b.compositions.filter((x) => x.id !== c.id);
  }

  // 6. Relations du pack : réécrites vers les identités réunies, dédoublonnées
  // (propriété 6). Une arête déjà présente avec un CONTENU différent (raison /
  // priorité) n'est ni écrasée ni ignorée en silence (D-157) : la proposition du
  // pack est consignée dans `conflitsLiaisons`, à arbitrer par l'humain.
  const cleConflit = (c: { pack: string; sourceId: string; cibleId: string; type: string }) =>
    `${c.pack}|${c.sourceId}|${c.cibleId}|${c.type}`;
  const conflits = new Map((b.conflitsLiaisons ?? []).map((c) => [cleConflit(c), c]));
  for (const entrante of pack.techniques) {
    const idFinal = idVers.get(entrante.id)!;
    const technique = b.techniques.find((t) => t.id === idFinal)!;
    for (const r of entrante.relations) {
      const relation: Relation = { type: r.type, cibleId: idVers.get(r.cibleId) ?? r.cibleId };
      // Conserver la note/priorité de l'arête (D-134) à travers le remappage.
      if (r.note !== undefined) relation.note = r.note;
      if (r.priorite !== undefined) relation.priorite = r.priorite;
      if (relation.cibleId === technique.id) continue; // auto-référence après fusion
      const existante = technique.relations.find((x) => x.type === relation.type && x.cibleId === relation.cibleId);
      if (!existante) { technique.relations.push(relation); continue; }
      const cle = cleConflit({ pack: packId, sourceId: technique.id, cibleId: relation.cibleId, type: relation.type });
      const differe =
        (relation.note !== undefined || relation.priorite !== undefined) &&
        (relation.note !== existante.note || relation.priorite !== existante.priorite);
      if (differe) {
        // Remplace une éventuelle proposition antérieure du même pack sur la même
        // arête (réimport : une seule entrée par arête, la plus récente).
        conflits.set(cle, {
          pack: packId, sourceId: technique.id, cibleId: relation.cibleId, type: relation.type,
          ...(relation.note !== undefined ? { note: relation.note } : {}),
          ...(relation.priorite !== undefined ? { priorite: relation.priorite } : {}),
          detecteLe: new Date().toISOString(),
        });
      } else {
        conflits.delete(cle); // plus de désaccord : l'entrée périmée disparaît
      }
    }
  }
  // 6bis. RETRAITS PROPOSÉS (D-243) : les arêtes que ce pack avait apportées et
  // que sa nouvelle version NE DÉCLARE PLUS. Elles ne sont pas supprimées — une
  // arête ne porte pas d'origine, donc rien ne distingue celle du pack de celle
  // que l'humain a tracée, et la retirer d'office détruirait son travail. Elle
  // est donc PROPOSÉE au retrait, comme une raison divergente l'est depuis
  // D-157. Sans cela une mise à jour n'ajoutait que des liens : une épuration
  // éditoriale (D-241 : 315 → 67) n'atteignait que les installations neuves.
  //
  // Périmètre volontairement ÉTROIT : les deux extrémités doivent venir de ce
  // pack. Un lien que l'humain a tiré vers SES propres techniques n'est jamais
  // proposé au retrait — il n'a rien à voir avec le pack.
  const duPack = new Set(b.techniques.filter((t) => t.origine?.pack === packId).map((t) => t.id));
  const declarees = new Set<string>();
  for (const entrante of pack.techniques) {
    const src = idVers.get(entrante.id);
    for (const r of entrante.relations) {
      const cible = idVers.get(r.cibleId) ?? r.cibleId;
      if (src) declarees.add(`${src}|${cible}|${r.type}`);
    }
  }
  for (const t of b.techniques) {
    if (!duPack.has(t.id)) continue;
    for (const r of t.relations) {
      if (!duPack.has(r.cibleId)) continue; // arête vers du contenu hors pack
      if (declarees.has(`${t.id}|${r.cibleId}|${r.type}`)) continue; // toujours déclarée
      conflits.set(cleConflit({ pack: packId, sourceId: t.id, cibleId: r.cibleId, type: r.type }), {
        pack: packId, sourceId: t.id, cibleId: r.cibleId, type: r.type,
        sens: "retrait", detecteLe: new Date().toISOString(),
      });
    }
  }
  // Une proposition de retrait devenue caduque disparaît (le pack redéclare
  // l'arête, ou l'arête n'existe plus) — réimporter deux fois donne le même
  // état, comme pour le reste (propriété 4).
  for (const [cle, c] of conflits) {
    if (c.sens !== "retrait" || c.pack !== packId) continue; // jamais les propositions d'un AUTRE pack
    const source = b.techniques.find((t) => t.id === c.sourceId);
    const existe = source?.relations.some((x) => x.type === c.type && x.cibleId === c.cibleId);
    if (!existe || declarees.has(`${c.sourceId}|${c.cibleId}|${c.type}`)) conflits.delete(cle);
  }

  if (conflits.size > 0) b.conflitsLiaisons = [...conflits.values()];
  else delete b.conflitsLiaisons;
  const tous = [...conflits.values()];
  rapport.conflitsLiaisons = tous.filter((c) => c.sens !== "retrait").length;
  rapport.retraitsProposes = tous.filter((c) => c.sens === "retrait").length;

  validerBibliotheque(b);
  return { bibliotheque: b, rapport };
}

/** Complète l'identité rejointe sans jamais écraser l'existant (déterministe). */
function completer(
  identite: Technique,
  entrante: Technique,
  familleVers: Map<string, string>,
  niveauVers: Map<string, string>,
): void {
  if (!identite.nomTraditionnel && entrante.nomTraditionnel) identite.nomTraditionnel = entrante.nomTraditionnel;
  if (!identite.couverture && entrante.couverture) identite.couverture = structuredClone(entrante.couverture);
  if (!identite.mediaPrincipalId && entrante.mediaPrincipalId) identite.mediaPrincipalId = entrante.mediaPrincipalId;
  if (!identite.familleId && entrante.familleId) {
    identite.familleId = familleVers.get(entrante.familleId) ?? entrante.familleId;
  }
  for (const n of entrante.niveauxIds) {
    const nid = niveauVers.get(n) ?? n;
    if (!identite.niveauxIds.includes(nid)) identite.niveauxIds.push(nid);
  }
}

/** Applique l'arbitrage d'UN conflit de liaison (D-157) — fonction PURE (mute
 *  la bibliothèque passée). `choix` :
 *  - "local" : la version locale reste, la proposition du pack est écartée ;
 *  - "pack"  : la raison/priorité du pack remplacent les locales ;
 *  - "deux"  : les DEUX raisons sont conservées ensemble dans la note (locale
 *    puis pack) ; la priorité locale prime (celle du pack sert de repli) ;
 *  - "retirer" (D-243) : l'arête elle-même est supprimée — le seul choix qui
 *    DÉTRUIT quelque chose, réservé aux propositions de sens « retrait ». Son
 *    inverse est "local" (« je garde mon lien »), qui ne fait que classer la
 *    proposition sans toucher à l'arête.
 *  L'entrée est retirée de `conflitsLiaisons` dans tous les cas. Si l'arête ou
 *  les techniques ont disparu entre-temps, l'entrée est simplement retirée. */
export function arbitrerConflitLiaison(
  b: Bibliotheque,
  conflit: ConflitLiaison,
  choix: "local" | "pack" | "deux" | "retirer",
): void {
  const meme = (c: ConflitLiaison) =>
    c.pack === conflit.pack && c.sourceId === conflit.sourceId && c.cibleId === conflit.cibleId && c.type === conflit.type;
  const restants = (b.conflitsLiaisons ?? []).filter((c) => !meme(c));
  if (restants.length > 0) b.conflitsLiaisons = restants;
  else delete b.conflitsLiaisons;

  // « retirer » (D-243) : l'humain accepte le retrait proposé — l'arête part.
  // « local » sur un retrait proposé = « je garde mon lien », et c'est déjà
  // fait : l'entrée vient de disparaître, l'arête n'a pas bougé.
  if (choix === "retirer") {
    const src = b.techniques.find((t) => t.id === conflit.sourceId);
    if (src) src.relations = src.relations.filter((x) => !(x.type === conflit.type && x.cibleId === conflit.cibleId));
    return;
  }
  if (choix === "local") return;
  const source = b.techniques.find((t) => t.id === conflit.sourceId);
  const r = source?.relations.find((x) => x.type === conflit.type && x.cibleId === conflit.cibleId);
  if (!r) return; // arête disparue : rien à appliquer
  if (choix === "pack") {
    if (conflit.note !== undefined) r.note = conflit.note; else delete r.note;
    if (conflit.priorite !== undefined) r.priorite = conflit.priorite; else delete r.priorite;
    return;
  }
  // "deux" : concatène les raisons (locale d'abord), garde la priorité locale.
  const notes = [r.note, conflit.note].filter((n): n is string => n !== undefined && n.trim() !== "");
  const fusion = [...new Set(notes)].join("\n\n");
  if (fusion !== "") r.note = fusion; else delete r.note;
  if (r.priorite === undefined && conflit.priorite !== undefined) r.priorite = conflit.priorite;
}
