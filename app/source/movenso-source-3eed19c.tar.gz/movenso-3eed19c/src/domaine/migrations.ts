/**
 * Migrations de schéma n → n+1, exécutées à l'ouverture (contrat §2.3).
 * Leçon V2 : un schéma versionné sans chemin de migration rejette ses propres
 * données futures. Le mécanisme existe donc dès la version 1, même vide.
 */

import type { Bibliotheque } from "./modele.ts";
import { TYPES_RELATION_DEFAUT, VERSION_SCHEMA } from "./modele.ts";

type Migration = (donnees: Record<string, unknown>) => Record<string, unknown>;

/** Registre : MIGRATIONS[n] fait passer de la version n à n+1. */
const MIGRATIONS: Record<number, Migration> = {
  // 1 → 2 (D-020) : les types de relation deviennent des données (les quatre
  // types historiques sont semés — les relations existantes les référencent
  // déjà par id) ; les compositions apparaissent, vides.
  1: (d) => ({
    ...d,
    versionSchema: 2,
    typesRelation: TYPES_RELATION_DEFAUT.map((t) => ({ ...t })),
    compositions: [],
  }),
  // 2 -> 3 (lot 5 §4) : les favoris personnels apparaissent, vides — de purs
  // marque-pages vers des identités, rien d'autre ne change.
  2: (d) => ({
    ...d,
    versionSchema: 3,
    favoris: [],
  }),
  // 3 -> 4 (D-140) : les rôles sémantiques (D-136) sont rétro-appliqués aux
  // types de relation par défaut déjà persistés SANS rôle. Sans ça, l'écran
  // Relations les traite tous comme « peer » (placement Carte faussé, Explorer
  // réduit au seul « comparer », « Enchaîné depuis » jamais peuplé) sur les
  // installations antérieures à D-136. On ne touche qu'aux types par défaut, et
  // seulement quand le rôle manque — un choix éditorial explicite est préservé.
  3: (d) => ({
    ...d,
    versionSchema: 4,
    typesRelation: retroRolesDefaut(d["typesRelation"]),
  }),
  // 4 -> 5 (S4.2bis) : l'illustration de FAMILLE remonte sur la famille.
  //
  // Jusqu'ici le modèle ne connaissait d'image que par technique, donc une
  // carte de famille était RECOPIÉE sur chacune de ses techniques (D-244) :
  // 16 images du jujitsu occupaient 162 exemplaires, 12 du JJB en occupaient
  // 150. Une information a un lieu — la famille est ce lieu, la technique la
  // dérive à l'affichage.
  //
  // Règle de reconnaissance, volontairement conservatrice : une image est
  // « de famille » si elle est PARTAGÉE par au moins deux techniques d'une
  // MÊME famille. Une image unique à une technique n'est jamais déplacée —
  // c'est son illustration propre, et elle continue de primer.
  4: (d) => ({ ...d, versionSchema: 5, ...remonterImagesDeFamille(d) }),
};

/** Remonte sur chaque famille l'image que partagent au moins deux de ses
 *  techniques, et la retire de ces techniques. Défensif : les données migrées
 *  sont BRUTES (un pack tiers peut porter n'importe quoi), donc chaque forme
 *  inattendue est laissée telle quelle plutôt que corrigée au jugé. */
function remonterImagesDeFamille(d: Record<string, unknown>): Record<string, unknown> {
  const disciplines = d["disciplines"];
  const techniques = d["techniques"];
  if (!Array.isArray(disciplines) || !Array.isArray(techniques)) return {};

  const estObjet = (v: unknown): v is Record<string, unknown> =>
    typeof v === "object" && v !== null && !Array.isArray(v);
  const imageDe = (t: Record<string, unknown>): string | null => {
    const c = t["couverture"];
    return estObjet(c) && c["type"] === "image" && typeof c["dataUrl"] === "string" ? c["dataUrl"] : null;
  };

  // Combien de techniques partagent telle image, dans telle famille ?
  const parFamille = new Map<string, Map<string, number>>();
  for (const t of techniques) {
    if (!estObjet(t)) continue;
    const famille = t["familleId"];
    const image = imageDe(t);
    if (typeof famille !== "string" || !image) continue;
    if (!parFamille.has(famille)) parFamille.set(famille, new Map());
    const compte = parFamille.get(famille)!;
    compte.set(image, (compte.get(image) ?? 0) + 1);
  }

  // L'image de la famille est la plus partagée, à condition d'être partagée.
  const retenue = new Map<string, string>();
  for (const [famille, compte] of parFamille) {
    let gagnante: string | null = null;
    let max = 1; // strictement plus d'une technique
    for (const [image, n] of compte) if (n > max) { max = n; gagnante = image; }
    if (gagnante) retenue.set(famille, gagnante);
  }
  if (retenue.size === 0) return {};

  const disciplinesMaj = disciplines.map((disc) => {
    if (!estObjet(disc) || !Array.isArray(disc["familles"])) return disc;
    return {
      ...disc,
      familles: disc["familles"].map((f) => {
        if (!estObjet(f) || typeof f["id"] !== "string") return f;
        const image = retenue.get(f["id"]);
        // Une couverture déjà posée sur la famille n'est jamais écrasée.
        if (!image || f["couverture"] !== undefined) return f;
        return { ...f, couverture: { type: "image", dataUrl: image } };
      }),
    };
  });

  const techniquesMaj = techniques.map((t) => {
    if (!estObjet(t)) return t;
    const famille = t["familleId"];
    const image = imageDe(t);
    if (typeof famille !== "string" || !image || retenue.get(famille) !== image) return t;
    const { couverture: _retiree, ...reste } = t; // la technique dérive désormais de sa famille
    return reste;
  });

  return { disciplines: disciplinesMaj, techniques: techniquesMaj };
}

/** Rétro-applique `role` (et `ordre` si présent) aux types de relation par
 *  défaut dépourvus de rôle — par id stable, sans écraser un rôle déjà défini. */
function retroRolesDefaut(brut: unknown): unknown {
  if (!Array.isArray(brut)) return brut;
  const defauts = new Map(TYPES_RELATION_DEFAUT.map((t) => [t.id, t]));
  return brut.map((type) => {
    if (!type || typeof type !== "object" || Array.isArray(type)) return type;
    const t = type as Record<string, unknown>;
    const def = defauts.get(t["id"] as string);
    if (!def || t["role"] !== undefined) return type;
    return def.ordre !== undefined ? { ...t, role: def.role, ordre: def.ordre } : { ...t, role: def.role };
  });
}

export class ErreurMigration extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ErreurMigration";
  }
}

/**
 * Amène des données persistées à la version courante du schéma.
 * Ne valide pas les invariants métier : appeler validerBibliotheque ensuite.
 * `versionCible` n'est paramétrable que pour tester le mécanisme de chaîne.
 */
export function migrerBibliotheque(brut: unknown, versionCible: number = VERSION_SCHEMA): Bibliotheque {
  if (typeof brut !== "object" || brut === null) {
    throw new ErreurMigration("Données illisibles : la bibliothèque n'est pas un objet");
  }
  let donnees = brut as Record<string, unknown>;
  const versionLue = donnees["versionSchema"];
  if (typeof versionLue !== "number" || !Number.isInteger(versionLue) || versionLue < 1) {
    throw new ErreurMigration(`Version de schéma absente ou invalide : ${String(versionLue)}`);
  }
  let version: number = versionLue;
  if (version > versionCible) {
    throw new ErreurMigration(
      `Bibliothèque en version ${version}, plus récente que l'application (${versionCible}) — mettre à jour l'application plutôt que risquer une perte`,
    );
  }
  while (version < versionCible) {
    const migration = MIGRATIONS[version];
    if (!migration) {
      throw new ErreurMigration(`Aucune migration enregistrée depuis la version ${version}`);
    }
    donnees = migration(donnees);
    const suivante = donnees["versionSchema"];
    if (typeof suivante !== "number" || suivante !== version + 1) {
      throw new ErreurMigration(`La migration ${version} → ${version + 1} n'a pas incrémenté la version`);
    }
    version = suivante;
  }
  return donnees as unknown as Bibliotheque;
}

/** Visible pour les tests : permet d'enregistrer une migration factice. */
export function _enregistrerMigrationPourTests(depuis: number, m: Migration): () => void {
  MIGRATIONS[depuis] = m;
  return () => {
    delete MIGRATIONS[depuis];
  };
}
