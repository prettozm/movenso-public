/**
 * SHA-256 INCRÉMENTAL (lot 8B §15) — WebCrypto (`crypto.subtle.digest`) est
 * one-shot : il exige le message entier en mémoire. Pour hacher un média par
 * blocs de taille fixe sans jamais le charger en entier, il faut un hachage
 * qui accepte `update(bloc)` répété puis `digest()`.
 *
 * Implémentation de référence (FIPS 180-4), pure et testable en Node ;
 * conformité vérifiée octet pour octet contre `crypto.subtle` (tests).
 */

// Constantes de ronde (racines cubiques des 64 premiers nombres premiers).
const K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);

const rotr = (x: number, n: number): number => (x >>> n) | (x << (32 - n));

export class Sha256 {
  #h = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
  #tampon = new Uint8Array(64); // bloc partiel en attente (< 64 octets)
  #enTampon = 0;
  #longueur = 0; // total d'octets absorbés (pour le padding final)
  #w = new Uint32Array(64);
  #fini = false;

  /** Absorbe un fragment de taille quelconque — appelable en boucle. */
  update(octets: Uint8Array): this {
    if (this.#fini) throw new Error("Sha256 : digest() déjà appelé");
    this.#longueur += octets.length;
    let i = 0;
    // complète le bloc partiel courant
    if (this.#enTampon > 0) {
      while (i < octets.length && this.#enTampon < 64) this.#tampon[this.#enTampon++] = octets[i++]!;
      if (this.#enTampon === 64) {
        this.#comprimer(this.#tampon, 0);
        this.#enTampon = 0;
      }
    }
    // blocs pleins directement depuis l'entrée (aucune copie superflue)
    for (; i + 64 <= octets.length; i += 64) this.#comprimer(octets, i);
    // reste → tampon
    while (i < octets.length) this.#tampon[this.#enTampon++] = octets[i++]!;
    return this;
  }

  /** Finalise (padding FIPS) et rend l'empreinte hexadécimale (64 caractères). */
  digestHex(): string {
    if (this.#fini) throw new Error("Sha256 : digest() déjà appelé");
    this.#fini = true;
    const bitsLen = this.#longueur * 8;
    // padding : 0x80 puis des zéros jusqu'à 56 mod 64, puis la longueur en bits (64 bits BE)
    const reste = this.#enTampon;
    const pad = new Uint8Array(reste < 56 ? 64 : 128);
    pad.set(this.#tampon.subarray(0, reste));
    pad[reste] = 0x80;
    // longueur sur 64 bits big-endian (les octets de poids fort sont nuls en pratique < 2^53)
    const dv = new DataView(pad.buffer);
    dv.setUint32(pad.length - 8, Math.floor(bitsLen / 0x100000000));
    dv.setUint32(pad.length - 4, bitsLen >>> 0);
    for (let i = 0; i < pad.length; i += 64) this.#comprimer(pad, i);
    let hex = "";
    for (let i = 0; i < 8; i++) hex += this.#h[i]!.toString(16).padStart(8, "0");
    return hex;
  }

  #comprimer(bloc: Uint8Array, offset: number): void {
    const w = this.#w;
    for (let t = 0; t < 16; t++) {
      const j = offset + t * 4;
      w[t] = ((bloc[j]! << 24) | (bloc[j + 1]! << 16) | (bloc[j + 2]! << 8) | bloc[j + 3]!) >>> 0;
    }
    for (let t = 16; t < 64; t++) {
      const s0 = rotr(w[t - 15]!, 7) ^ rotr(w[t - 15]!, 18) ^ (w[t - 15]! >>> 3);
      const s1 = rotr(w[t - 2]!, 17) ^ rotr(w[t - 2]!, 19) ^ (w[t - 2]! >>> 10);
      w[t] = (w[t - 16]! + s0 + w[t - 7]! + s1) >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = this.#h as unknown as [number, number, number, number, number, number, number, number];
    for (let t = 0; t < 64; t++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + K[t]! + w[t]!) >>> 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e;
      e = (d + temp1) >>> 0;
      d = c; c = b; b = a;
      a = (temp1 + temp2) >>> 0;
    }
    const H = this.#h;
    H[0] = (H[0]! + a) >>> 0; H[1] = (H[1]! + b) >>> 0; H[2] = (H[2]! + c) >>> 0; H[3] = (H[3]! + d) >>> 0;
    H[4] = (H[4]! + e) >>> 0; H[5] = (H[5]! + f) >>> 0; H[6] = (H[6]! + g) >>> 0; H[7] = (H[7]! + h) >>> 0;
  }
}

/** Empreinte hexadécimale d'un contenu déjà en mémoire (petit JSON). */
export function sha256Hex(octets: Uint8Array): string {
  return new Sha256().update(octets).digestHex();
}
