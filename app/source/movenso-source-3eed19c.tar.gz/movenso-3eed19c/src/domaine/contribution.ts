/**
 * Amendement d'une contribution LOCALE (lot 8C §18) — logique PURE, sans E/S.
 *
 * Le service (racine.ts) applique le résultat puis persiste ; en cas d'échec
 * de persistance il restaure l'exemplaire d'origine, INTACT parce qu'il n'a
 * jamais été muté (transaction : capture d'état AVANT mutation de fait). Une
 * fonction pure retournant une NOUVELLE contribution rend ce rollback
 * infaillible — aucune valeur modifiée ne peut réapparaître, pas même une clé
 * ajoutée ou supprimée.
 */

import type { Contribution } from "./modele.ts";

/** Champs éditoriaux amendables d'une contribution. */
export interface PatchContribution {
  description?: string;
  attribution?: string;
  /** Points clés — remplacent la liste entière (déjà rognée, sans lignes vides). */
  pointsCles?: string[];
  /** Signature d'édition d'un contenu importé (« Modifié par … »). */
  modifiePar?: string;
}

/**
 * Retourne une copie de `contribution` avec `patch` appliqué, sans jamais
 * muter l'original. Sémantique (conforme à l'existant) :
 *  - `description` fournie non vide → posée (rognée) ; fournie vide → effacée
 *    (clé absente) ; absente du patch → inchangée ;
 *  - `attribution` fournie non vide → posée (rognée) ; vide ou absente →
 *    inchangée (l'effacement d'attribution n'est pas un geste exposé) ;
 *  - `pointsCles` fournis → remplacent la liste (chaque entrée rognée, les
 *    vides retirées) ; absents → inchangés ;
 *  - `modifiePar` fourni non vide → posé (rognée) ; sinon inchangé.
 */
export function appliquerAmendement(contribution: Contribution, patch: PatchContribution): Contribution {
  const amende: Contribution = { ...contribution };
  if (patch.description !== undefined) {
    const propre = patch.description.trim();
    if (propre) amende.description = propre;
    else delete amende.description;
  }
  if (patch.attribution !== undefined && patch.attribution.trim()) {
    amende.attribution = patch.attribution.trim();
  }
  if (patch.pointsCles !== undefined) {
    amende.pointsCles = patch.pointsCles.map((p) => p.trim()).filter((p) => p.length > 0);
  }
  if (patch.modifiePar !== undefined && patch.modifiePar.trim()) {
    amende.modifiePar = patch.modifiePar.trim();
  }
  return amende;
}
