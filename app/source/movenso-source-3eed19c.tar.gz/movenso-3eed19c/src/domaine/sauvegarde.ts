/**
 * Qualification d'une sauvegarde (lot 8C §20) — logique PURE.
 *
 * Une sauvegarde n'est « complète » que si elle inclut les vidéos ET qu'aucune
 * vidéo référencée ne manque au stockage. Dans tout autre cas c'est une
 * sauvegarde PARTIELLE, dont les exclusions sont nommées — jamais l'étiquette
 * « complète » sur un contenu amputé.
 *
 * Les réglages d'appareil (thème, démarrage, protections/PIN) ne voyagent dans
 * AUCUNE sauvegarde (D-065, invariant lot 7 §21) : c'est une exclusion
 * permanente, dite honnêtement, jamais une promesse implicite de restauration
 * « à l'identique » de l'appareil.
 */

export interface DescriptionSauvegarde {
  complete: boolean;
  role: string;
  exclusions: string[];
}

export function decrireSauvegarde(opts: { avecVideos: boolean; nbManquants: number }): DescriptionSauvegarde {
  const { avecVideos, nbManquants } = opts;
  const complete = avecVideos && nbManquants === 0;
  const exclusions: string[] = [];
  if (!avecVideos) exclusions.push("toutes les vidéos (fichier léger)");
  else if (nbManquants > 0) exclusions.push(`${nbManquants} vidéo${nbManquants > 1 ? "s" : ""} absente${nbManquants > 1 ? "s" : ""} du stockage`);
  exclusions.push("les réglages d'appareil (thème, démarrage, protections — se reconfigurent après restauration)");
  return {
    complete,
    role: complete ? "Sauvegarde complète de cette installation" : "Sauvegarde PARTIELLE de cette installation",
    exclusions,
  };
}
