/**
 * ULID (26 caractères Crockford base32, triable, monotone) — identifiants de
 * toutes les entités (contrat §2.3 : « ULID string partout »).
 * Implémentation propre, sans dépendance ; monotone au sein d'un même
 * processus pour garantir l'ordre d'insertion même à la même milliseconde.
 */

const ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; // Crockford, sans I L O U
const LONGUEUR_TEMPS = 10;
const LONGUEUR_ALEA = 16;

let dernierTemps = -1;
let derniersAleas: number[] = [];

function encoderTemps(ms: number): string {
  let s = "";
  for (let i = LONGUEUR_TEMPS - 1; i >= 0; i--) {
    s = ALPHABET[ms % 32] + s;
    ms = Math.floor(ms / 32);
  }
  return s;
}

function aleas(): number[] {
  const octets = new Uint8Array(LONGUEUR_ALEA);
  globalThis.crypto.getRandomValues(octets);
  return Array.from(octets, (o) => o % 32);
}

/** Incrémente la partie aléatoire (comportement monotone du spec ULID). */
function incrementer(a: number[]): number[] {
  const r = a.slice();
  for (let i = r.length - 1; i >= 0; i--) {
    const v = r[i] ?? 0;
    if (v < 31) {
      r[i] = v + 1;
      return r;
    }
    r[i] = 0;
  }
  return r; // débordement improbable (2^80 tirages dans la même ms)
}

export function genererUlid(maintenant: number = Date.now()): string {
  let partieAlea: number[];
  if (maintenant === dernierTemps) {
    partieAlea = incrementer(derniersAleas);
  } else {
    partieAlea = aleas();
    dernierTemps = maintenant;
  }
  derniersAleas = partieAlea;
  return encoderTemps(maintenant) + partieAlea.map((v) => ALPHABET[v]).join("");
}

const FORME_ULID = /^[0-9A-HJKMNP-TV-Z]{26}$/;

export function estUlid(valeur: string): boolean {
  return FORME_ULID.test(valeur);
}
