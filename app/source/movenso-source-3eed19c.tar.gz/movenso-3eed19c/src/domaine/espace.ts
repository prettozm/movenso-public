/**
 * Espace disponible avant opération volumineuse (lot 8A §10) — décision
 * PURE : l'estimation vient de l'appelant (navigator.storage.estimate),
 * le verdict se calcule et se teste ici. Honnête : sans estimation
 * fiable, on n'invente ni refus ni garantie — on procède en le disant.
 */

export interface VerdictEspace {
  /** false UNIQUEMENT sur une estimation fiable insuffisante. */
  suffisant: boolean;
  /** false : le navigateur n'a pas su répondre — aucune garantie promise. */
  fiable: boolean;
  requis: number;
  disponible: number | null;
}

/** Marge de sécurité : 10 % de l'écriture, plancher 16 Mo — l'espace
 *  résiduel sert aussi aux snapshots et à l'état courant. */
export function margeSecurite(tailleAEcrire: number): number {
  return Math.max(16_000_000, Math.round(tailleAEcrire * 0.1));
}

export function evaluerEspace(
  tailleAEcrire: number,
  estimation: { usage: number; quota: number } | null,
): VerdictEspace {
  if (estimation === null) return { suffisant: true, fiable: false, requis: tailleAEcrire, disponible: null };
  const disponible = Math.max(0, estimation.quota - estimation.usage);
  return {
    suffisant: tailleAEcrire + margeSecurite(tailleAEcrire) <= disponible,
    fiable: true,
    requis: tailleAEcrire,
    disponible,
  };
}

/** Formatage lisible pour les messages d'espace. */
export function tailleEnClair(octets: number): string {
  if (octets >= 1_000_000_000) return `${(octets / 1_000_000_000).toFixed(1)} Go`;
  if (octets >= 1_000_000) return `${(octets / 1_000_000).toFixed(1)} Mo`;
  return `${Math.max(1, Math.round(octets / 1000))} Ko`;
}
