/**
 * Ingestion d'une vidéo locale (lot 8A §5) — UN SEUL pipeline pour la
 * capture ET l'ajout de fichier : métadonnées réelles du fichier,
 * empreinte SHA-256 (Web Crypto), déduplication par taille + empreinte.
 * Quand un fichier identique existe déjà, son id est RÉUTILISÉ : la
 * nouvelle référence pointe le même fichier physique, rien n'est réécrit.
 */

import type { Bibliotheque, Media, OrigineMedia } from "./modele.ts";
import { genererUlid } from "./ulid.ts";
import { extensionCanonique, mediaIdentique } from "./medias.ts";
import { Sha256 } from "./sha256.ts";

/** Empreinte SHA-256 hexadécimale d'un contenu — UN fichier à la fois (§5),
 *  hachée EN FLUX (D-111) : jamais le fichier entier en mémoire. Une longue
 *  vidéo (1-2 Go) chargée d'un bloc via `arrayBuffer()` faisait planter la
 *  WebView AVANT même le garde-fou d'espace ; on lit par blocs via le flux du
 *  Blob et on alimente le SHA-256 incrémental. Repli one-shot si le flux n'est
 *  pas disponible (environnement sans `Blob.stream`). */
/** Annulation VOLONTAIRE d'une ingestion (S2.4/D-168) — un choix, jamais un
 *  échec : l'appelant la reconnaît par son nom et ne la consigne pas. */
export class AnnulationIngestion extends Error {
  constructor() {
    super("Ajout annulé");
    this.name = "AnnulationIngestion";
  }
}

export async function empreinteSha256(contenu: Blob, estAnnule?: () => boolean): Promise<string> {
  if (typeof contenu.stream !== "function") {
    const octets = await contenu.arrayBuffer();
    const hachage = await crypto.subtle.digest("SHA-256", octets);
    return [...new Uint8Array(hachage)].map((o) => o.toString(16).padStart(2, "0")).join("");
  }
  const h = new Sha256();
  const lecteur = (contenu.stream() as ReadableStream<Uint8Array>).getReader();
  for (;;) {
    if (estAnnule?.()) {
      await lecteur.cancel();
      throw new AnnulationIngestion();
    }
    const { done, value } = await lecteur.read();
    if (done) break;
    if (value) h.update(value);
  }
  return h.digestHex();
}

/** Validation d'entrée (§5, étape 4) : fichier vide ou type déclaré
 *  non-vidéo → motif de refus AVANT toute écriture. Un type ABSENT est
 *  toléré (des caméras Android n'en déclarent pas) — l'extension restera
 *  simplement indéterminée. */
export function refusFichierVideo(fichier: File): string | null {
  if (fichier.size === 0) return "Fichier vide — rien à enregistrer";
  if (fichier.type && !fichier.type.toLowerCase().startsWith("video/"))
    return "Ce fichier n'est pas une vidéo — seules les vidéos s'ajoutent ici";
  return null;
}

export interface VideoPreparee {
  media: Media;
  /** true : un fichier identique existe déjà — RIEN à écrire sur disque,
   *  et rien à supprimer en cas d'annulation (le fichier appartient aussi
   *  aux références existantes). */
  dejaPresent: boolean;
}

/** Prépare l'ingestion d'un fichier vidéo : lit les métadonnées, calcule
 *  l'empreinte, cherche un identique (taille + SHA-256). Doublon exact →
 *  l'id existant est réutilisé et ses métadonnées d'origine conservées ;
 *  sinon un média neuf, complet, prêt à être écrit par l'appelant. */
export async function preparerVideo(b: Bibliotheque, fichier: File, origine: OrigineMedia, estAnnule?: () => boolean): Promise<VideoPreparee> {
  const sha256 = await empreinteSha256(fichier, estAnnule);
  const identique = mediaIdentique(b, fichier.size, sha256);
  if (identique) return { media: { ...identique }, dejaPresent: true };
  const id = genererUlid();
  const extension = extensionCanonique(fichier.type, fichier.name);
  const media: Media = {
    id,
    type: "local",
    ref: `videos/${id}`,
    sha256,
    taille: fichier.size,
    ajouteLe: new Date().toISOString(),
    origineMedia: origine,
    ...(fichier.type ? { mime: fichier.type } : {}),
    ...(extension ? { extension } : {}),
    ...(fichier.name ? { nomOriginal: fichier.name } : {}),
  };
  return { media, dejaPresent: false };
}
