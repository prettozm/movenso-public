/**
 * Lecture du graphe de relations — l'inverse est TOUJOURS dérivé, jamais
 * saisi ni stocké (contrat §2.1 : évite le graphe asymétrique, leçon V2
 * conservée pour sa valeur démontrée).
 *
 * Depuis D-020.2 les types de relation sont des données : les libellés
 * (direct, inverse, symétrie) viennent de `bibliotheque.typesRelation`.
 */

import type { Bibliotheque, TypeRelationDef, RoleRelation } from "./modele.ts";

export interface RelationAffichee {
  /** Ce que la liaison dit DE la technique affichée — libellé du type (dérivé si entrant). */
  libelle: string;
  /** Id du type de relation (pour l'édition). */
  typeId: string;
  /** true si la liaison est portée par la fiche affichée (sens direct, éditable ici). */
  directe: boolean;
  techniqueId: string;
  /** false si la cible n'existe pas (ou plus) dans la bibliothèque : affichée, jamais bloquante. */
  presente: boolean;
  /** Explication pédagogique du lien (D-134), portée par le sens direct et
   *  réutilisée par l'inverse dérivé (elle décrit l'arête, pas le sens). */
  note?: string;
  /** Priorité éditoriale (D-134) : ordonne les liens d'un même rôle. */
  priorite?: number;
  /** Rôle sémantique AFFICHÉ (D-136) : pilote le placement (avant/après/…).
   *  L'inverse dérivé d'un lien `after` devient `before` (et vice-versa). */
  role: RoleRelation;
}

function libelleDirect(def: TypeRelationDef | undefined, typeId: string): string {
  return def?.libelle ?? typeId;
}

function libelleInverse(def: TypeRelationDef | undefined, typeId: string): string {
  if (!def) return typeId;
  if (def.symetrique) return def.libelle;
  return def.libelleInverse ?? `${def.libelle} (inverse)`;
}

/** Rôle AFFICHÉ (D-136) : l'inverse dérivé d'un `after` se lit `before` (ligne
 *  de temps) et réciproquement ; les autres rôles sont stables. Repli : `peer`. */
function roleAffiche(def: TypeRelationDef | undefined, directe: boolean): RoleRelation {
  const r = def?.role ?? "peer";
  if (directe) return r;
  if (r === "after") return "before";
  if (r === "before") return "after";
  return r;
}

/** Toutes les liaisons à afficher sur la fiche d'une technique :
 *  ses relations sortantes + les inverses dérivées des relations entrantes. */
export function relationsPourFiche(b: Bibliotheque, techniqueId: string): RelationAffichee[] {
  const defs = new Map(b.typesRelation.map((t) => [t.id, t]));
  const presentes = new Set(b.techniques.map((t) => t.id));
  const resultat: RelationAffichee[] = [];
  const vues = new Set<string>();
  const ajouter = (libelle: string, typeId: string, directe: boolean, id: string, note?: string, priorite?: number) => {
    const cle = `${libelle}:${id}`;
    if (vues.has(cle)) return; // dédoublonne (ex. symétrique déclaré des deux côtés)
    vues.add(cle);
    const item: RelationAffichee = { libelle, typeId, directe, techniqueId: id, presente: presentes.has(id), role: roleAffiche(defs.get(typeId), directe) };
    if (note !== undefined) item.note = note;
    if (priorite !== undefined) item.priorite = priorite;
    resultat.push(item);
  };

  const fiche = b.techniques.find((t) => t.id === techniqueId);
  for (const r of fiche?.relations ?? []) {
    ajouter(libelleDirect(defs.get(r.type), r.type), r.type, true, r.cibleId, r.note, r.priorite);
  }
  for (const autre of b.techniques) {
    if (autre.id === techniqueId) continue;
    for (const r of autre.relations) {
      if (r.cibleId === techniqueId) {
        // L'inverse dérivé réutilise la note/priorité de l'arête (portée par le sens direct).
        ajouter(libelleInverse(defs.get(r.type), r.type), r.type, false, autre.id, r.note, r.priorite);
      }
    }
  }
  return resultat;
}
