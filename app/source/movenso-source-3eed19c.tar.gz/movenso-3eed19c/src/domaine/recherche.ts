/**
 * Recherche tolérante par nom (increment-1.md, besoin B1) : accents, tirets,
 * espaces et casse indifférents — « o soto », « osoto » et « Ō-soto » se
 * rejoignent. Scan linéaire : suffisant à l'échelle d'une bibliothèque
 * personnelle (des centaines de techniques, pas des millions).
 */

import type { Bibliotheque, Technique } from "./modele.ts";

export function normaliserPourRecherche(texte: string): string {
  return texte
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "") // accents / macrons
    .replace(/[\s\-'’]/g, "");
}

export function chercherTechniques(b: Bibliotheque, requete: string, limite = 20): Technique[] {
  const q = normaliserPourRecherche(requete);
  if (q === "") return [];

  // Les mots personnels sont des indices de récupération (D-016/D-020) :
  // chercher « banane » doit retrouver la technique dont le carnet le contient.
  const motsPersonnels = new Map<string, string>(); // techniqueId → texte normalisé cumulé
  for (const c of b.contributions) {
    if (c.provenance !== "personnel" || !c.techniqueId || !c.description) continue;
    motsPersonnels.set(
      c.techniqueId,
      (motsPersonnels.get(c.techniqueId) ?? "") + " " + normaliserPourRecherche(c.description),
    );
  }

  const scores = new Map<string, number>();
  const resultats: Technique[] = [];
  for (const t of b.techniques) {
    const nom = normaliserPourRecherche(t.nom);
    const traditionnel = normaliserPourRecherche(t.nomTraditionnel ?? "");
    let score: number | null = null;
    if (nom.startsWith(q)) score = 0; // préfixe du nom d'abord
    else if (nom.includes(q)) score = 1;
    else if (traditionnel !== "" && traditionnel.includes(q)) score = 2;
    else if (motsPersonnels.get(t.id)?.includes(q)) score = 3; // mon mot à moi
    if (score !== null) {
      scores.set(t.id, score);
      resultats.push(t);
    }
  }
  return resultats
    .sort((a, z) => (scores.get(a.id)! - scores.get(z.id)!) || a.nom.localeCompare(z.nom, "fr"))
    .slice(0, limite);
}
