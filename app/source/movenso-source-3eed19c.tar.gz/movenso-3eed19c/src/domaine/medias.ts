/**
 * Registre CENTRAL des médias (lot 8A §3) — une vue DÉRIVÉE, jamais un
 * compteur maintenu à la main : les références se recalculent depuis la
 * bibliothèque (contributions, blocs de composition, média principal).
 * Fonctions pures, testables en Node.
 */

import type { Bibliotheque, Media } from "./modele.ts";

/** Où un média est utilisé — de quoi répondre à « quels contenus ? ». */
interface ReferenceMedia {
  ou: "contribution" | "bloc" | "media-principal";
  /** Id du conteneur (contribution, composition ou technique). */
  conteneurId: string;
  /** Identité concernée quand elle existe (fiche à ouvrir). */
  techniqueId: string | null;
  /** Libellé lisible du contexte (nom de technique ou de composition). */
  nom: string;
}

export interface EntreeRegistre {
  media: Media;
  references: ReferenceMedia[];
}

/** Le registre : id de média → métadonnées + toutes les références. */
export function registreMedias(b: Bibliotheque): Map<string, EntreeRegistre> {
  const registre = new Map<string, EntreeRegistre>();
  const nomsTechniques = new Map(b.techniques.map((t) => [t.id, t.nom]));
  const noter = (media: Media, ref: ReferenceMedia) => {
    const entree = registre.get(media.id);
    if (entree) entree.references.push(ref);
    else registre.set(media.id, { media, references: [ref] });
  };
  for (const c of b.contributions)
    for (const m of c.medias)
      noter(m, {
        ou: "contribution",
        conteneurId: c.id,
        techniqueId: c.techniqueId,
        nom: c.techniqueId ? (nomsTechniques.get(c.techniqueId) ?? "?") : "capture à rattacher",
      });
  for (const co of b.compositions)
    for (const bl of co.blocs)
      for (const m of bl.medias)
        noter(m, { ou: "bloc", conteneurId: co.id, techniqueId: null, nom: `composition « ${co.nom} »` });
  // Le média principal d'une technique est une RÉFÉRENCE supplémentaire vers
  // un média déjà porté par une contribution — jamais un propriétaire.
  for (const t of b.techniques) {
    if (!t.mediaPrincipalId) continue;
    const entree = registre.get(t.mediaPrincipalId);
    if (entree)
      entree.references.push({ ou: "media-principal", conteneurId: t.id, techniqueId: t.id, nom: t.nom });
  }
  return registre;
}

/** Ids des fichiers vidéo LOCAUX référencés — la question de sûreté des
 *  suppressions physiques (§4) : un id présent ici ne se supprime jamais.
 *  Inclut les médias des fiches EN CORBEILLE (D-081) : tant qu'une fiche est
 *  restaurable, ses fichiers ne sont ni « orphelins » ni supprimables. */
export function referencesVideosLocales(b: Bibliotheque): Set<string> {
  const refs = new Set<string>();
  for (const [id, entree] of registreMedias(b)) if (entree.media.type === "local") refs.add(id);
  for (const e of b.corbeille ?? [])
    for (const c of e.contributions)
      for (const m of c.medias) if (m.type === "local") refs.add(m.id);
  return refs;
}

/** MIME vidéo → extension CANONIQUE (§6) : une seule extension par type,
 *  quelle que soit celle du fichier d'origine. */
const EXTENSIONS_PAR_MIME: Record<string, string> = {
  "video/webm": "webm",
  "video/mp4": "mp4",
  "video/quicktime": "mov",
  "video/x-matroska": "mkv",
  "video/3gpp": "3gp",
  "video/ogg": "ogv",
  "video/x-msvideo": "avi",
};

/** Extension canonique d'un média local : dérivée du MIME réel ; le nom
 *  d'origine n'est qu'un REPLI quand le MIME est inconnu — jamais une
 *  source de vérité (§2, §6). Indécidable → undefined, jamais inventée. */
export function extensionCanonique(mime?: string, nomOriginal?: string): string | undefined {
  const base = mime?.split(";")[0]?.trim().toLowerCase() ?? "";
  const parMime = EXTENSIONS_PAR_MIME[base];
  if (parMime) return parMime;
  const duNom = nomOriginal?.match(/\.([a-z0-9]{1,5})$/i)?.[1];
  return duNom ? duNom.toLowerCase() : undefined;
}

/** Recherche d'un média local IDENTIQUE — taille ET empreinte SHA-256,
 *  JAMAIS le nom d'origine seul (§5). Un média historique sans empreinte
 *  ne matche jamais : aucune fausse déduplication. */
export function mediaIdentique(b: Bibliotheque, taille: number, sha256: string): Media | undefined {
  if (!sha256) return undefined;
  for (const { media } of registreMedias(b).values())
    if (media.type === "local" && media.sha256 === sha256 && media.taille === taille) return media;
  return undefined;
}
