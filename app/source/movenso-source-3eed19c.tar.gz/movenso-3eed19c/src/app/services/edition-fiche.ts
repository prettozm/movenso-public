/**
 * Service ÉDITION DE FICHE (S3.A10, extrait de racine.ts au budget de 2 000
 * lignes — code déménagé tel quel, aucun changement de comportement).
 *
 * Le contrat, c'est D-105 : entrer en édition prend un INSTANTANÉ restaurable
 * de la fiche (technique, ses contributions, son favori) ; la croix ✕ le
 * restaure, donc les auto-enregistrements faits pendant l'édition sont
 * défaits ; le ✓ le jette. Sans instantané (fiche fraîchement créée), ✕ ferme
 * simplement l'édition — il n'y a rien à quoi revenir.
 */

import type { MovensoApp } from "../racine.ts";

/** Entre en édition d'une fiche existante en capturant un instantané
 *  restaurable (technique + ses contributions). */
export function entrerEditionFiche(app: MovensoApp, techniqueId: string): void {
  const b = app.bibliotheque;
  const t = b?.techniques.find((x) => x.id === techniqueId);
  if (!b || !t) return;
  app.instantaneEdition = {
    techniqueId,
    technique: structuredClone(t),
    contributions: b.contributions.filter((c) => c.techniqueId === techniqueId).map((c) => structuredClone(c)),
    favori: b.favoris.includes(techniqueId),
  };
  app.editionFiche = true;
  app.requestUpdate();
}

/** Le ✓ : enregistre et ferme (les changements sont déjà persistés en auto). */
export function validerEditionFiche(app: MovensoApp): void {
  app.instantaneEdition = null;
  app.editionFiche = false;
  app.afficherToast("Modifications enregistrées ✓");
  app.requestUpdate();
}

/** La croix ✕ : restaure l'instantané pris à l'entrée → les modifications
 *  auto-enregistrées sont défaites. Sans instantané (fiche neuve), ferme
 *  simplement l'édition. */
export async function annulerEditionFiche(app: MovensoApp): Promise<void> {
  const snap = app.instantaneEdition;
  const b = app.bibliotheque;
  app.editionFiche = false;
  app.instantaneEdition = null;
  // Le champ de commentaire doit reprendre la valeur restaurée (D-249) : il
  // porte une note personnelle auto-enregistrée à la perte de focus, donc
  // aucun rendu ordinaire ne le réécrit — ce compteur est la seule reprise
  // en main, et elle n'a lieu que sur ce geste (D-251).
  app.generationCarnet++;
  if (!snap || !b) { app.requestUpdate(); return; }
  const i = b.techniques.findIndex((t) => t.id === snap.techniqueId);
  if (i >= 0) b.techniques[i] = structuredClone(snap.technique);
  b.contributions = b.contributions.filter((c) => c.techniqueId !== snap.techniqueId);
  b.contributions.push(...snap.contributions.map((c) => structuredClone(c)));
  // Le favori est aussi restauré (le cœur reste cliquable en édition, D-105).
  const estFavori = b.favoris.includes(snap.techniqueId);
  if (snap.favori && !estFavori) b.favoris.push(snap.techniqueId);
  else if (!snap.favori && estFavori) b.favoris = b.favoris.filter((id) => id !== snap.techniqueId);
  await app.persister(b);
  app.afficherToast("Modifications annulées");
  app.requestUpdate();
}
