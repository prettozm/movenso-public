/**
 * Service ÉTAT DE L'ATELIER (S3.A1, tranche T6 — extrait de racine.ts, code
 * déménagé tel quel) : persistance OPFS lue et affichée (S1.9), état calculé
 * des écrans Plus (tailles des vidéos, orphelins, manquants — rafraîchi à
 * l'ouverture), actions sur les orphelins (rattacher D-168, supprimer
 * individuellement D-107 ou en groupe vérifié D-171), restauration de
 * sauvegarde interne. C'est l'état que les écrans d'atelier.ts consomment.
 */

import type { MovensoApp } from "../racine.ts";
import { referencesVideosLocales } from "../../domaine/medias.ts";
import { empreinteSha256 } from "../../domaine/ingestion.ts";
import { genererUlid } from "../../domaine/ulid.ts";
import type { Bibliotheque, Contribution } from "../../domaine/modele.ts";

/** Évalue (et sur demande sollicite) la persistance du stockage — S1.9. */
export async function evaluerPersistance(app: MovensoApp, demander: boolean): Promise<void> {
  const capacitor = (window as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  if (capacitor?.isNativePlatform?.()) {
    app.persistanceStockage = "native"; // OPFS dans le bac à sable de l'app : pas d'éviction navigateur
  } else {
    const p = await app.stockage.persistanceStockage(demander);
    app.persistanceStockage = p === true ? "accordee" : p === false ? "refusee" : "inconnue";
  }
  app.requestUpdate();
}

/** Bouton « Demander la persistance » (carte Espace) : redemande et dit
 *  honnêtement le résultat — le navigateur décide, jamais Movenso. */
export async function redemanderPersistance(app: MovensoApp): Promise<void> {
  await evaluerPersistance(app, true);
  app.afficherToast(
    app.persistanceStockage === "accordee"
      ? "Persistance accordée — le navigateur ne purgera pas tes données."
      : "Persistance non accordée pour l'instant — le navigateur décide selon l'usage du site. Pense aux sauvegardes régulières.",
  );
}

/** Ids de TOUTES les références de médias locaux — registre dérivé du
 *  domaine (lot 8A §3), plus jamais un calcul dupliqué ici. */
export function referencesVideos(app: MovensoApp, b: Bibliotheque): Set<string> {
  return referencesVideosLocales(b);
}

export async function rafraichirAtelier(app: MovensoApp): Promise<void> {
  const b = app.bibliotheque;
  if (!b) return;
  app.taillesVideos = await app.stockage.taillesVideos();
  const presentes = new Set(app.taillesVideos.keys());
  app.mediasManquants = b.contributions.flatMap((c) =>
    c.medias
      .filter((m) => m.type === "local" && !presentes.has(m.id))
      .map(() => ({
        techniqueId: c.techniqueId,
        nom: c.techniqueId ? app.technique(c.techniqueId)?.nom ?? "?" : "capture à rattacher",
      })),
  );
  const refs = referencesVideos(app, b);
  app.videosOrphelines = [...app.taillesVideos.entries()]
    .filter(([id]) => !refs.has(id))
    .map(([id, taille]) => ({ id, taille }));
  app.sauvegardes = await app.stockage.listerSauvegardes();
  app.infoEspace = await app.stockage.estimerEspace();
  app.requestUpdate();
}

/** Rattache un fichier ORPHELIN retrouvé à une technique (S2.12/D-168) :
 *  une nouvelle contribution personnelle porte le média — le fichier
 *  physique ne bouge pas, il redevient simplement référencé. L'empreinte
 *  est recalculée (la déduplication future le reconnaîtra). */
export async function rattacherOrphelin(app: MovensoApp, fichierId: string, techniqueId: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour rattacher ce média.", () => void app.rattacherOrphelin(fichierId, techniqueId))) return;
  const b = app.bibliotheque;
  const t = b?.techniques.find((x) => x.id === techniqueId);
  if (!b || !t) return;
  const fichier = await app.stockage.fichierVideo(fichierId);
  if (!fichier) {
    app.afficherToast("Fichier introuvable — actualise la liste", "alerte");
    return;
  }
  const sha256 = await empreinteSha256(fichier);
  const extension = fichier.name.includes(".") ? fichier.name.slice(fichier.name.indexOf(".") + 1) : undefined;
  const contribution: Contribution = {
    id: genererUlid(),
    techniqueId,
    provenance: "personnel",
    description: "Média retrouvé et rattaché depuis la médiathèque",
    pointsCles: [],
    creeLe: new Date().toISOString(),
    medias: [{
      id: fichierId,
      type: "local",
      ref: `videos/${fichierId}`,
      sha256,
      taille: fichier.size,
      ajouteLe: new Date().toISOString(),
      ...(extension ? { extension } : {}),
    }],
  };
  b.contributions.push(contribution);
  try {
    await app.persister(b);
  } catch (e) {
    b.contributions = b.contributions.filter((x) => x.id !== contribution.id); // rien de mutant sur échec
    app.afficherToast(`Rattachement impossible : ${e instanceof Error ? e.message : "écriture refusée"}`, "alerte");
    return;
  }
  app.afficherToast(`Média rattaché à « ${t.nom} » ✓`);
  await rafraichirAtelier(app);
}

/** Supprime UN fichier orphelin — jamais en masse, revérifié à l'instant
 *  de la suppression : un fichier référencé n'est jamais supprimé (§13). */
export async function supprimerVideoOrpheline(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer ce fichier.", () => void app.supprimerVideoOrpheline(id))) return;
  const b = app.bibliotheque;
  if (!b) return;
  if (referencesVideos(app, b).has(id)) {
    app.afficherToast("Ce fichier est référencé — il ne sera pas supprimé", "alerte");
    return;
  }
  await app.stockage.supprimerVideo(id);
  app.afficherToast("Fichier inutilisé supprimé ✓");
  await rafraichirAtelier(app);
}

/** Suppression GROUPÉE des fichiers orphelins VÉRIFIÉS (S2.12/D-171 —
 *  précision de D-107 : la masse reste interdite pour les références et les
 *  fiches, mais des FICHIERS sans aucune référence, chacun prévisualisé,
 *  peuvent partir ensemble). Chaque fichier est RE-vérifié orphelin à
 *  l'instant de supprimer — jamais sur un état passé ; un fichier redevenu
 *  référencé entre-temps est conservé et compté à part. */
export async function supprimerOrphelinsVerifies(app: MovensoApp, ids: string[]): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer ces fichiers.", () => void app.supprimerOrphelinsVerifies(ids))) return;
  const b = app.bibliotheque;
  if (!b || ids.length === 0) return;
  const references = referencesVideos(app, b);
  let supprimes = 0;
  let conserves = 0;
  for (const id of ids) {
    if (references.has(id)) { conserves += 1; continue; }
    await app.stockage.supprimerVideo(id);
    supprimes += 1;
  }
  app.afficherToast(
    conserves
      ? `${supprimes} fichier${supprimes > 1 ? "s" : ""} supprimé${supprimes > 1 ? "s" : ""} — ${conserves} redevenu${conserves > 1 ? "s" : ""} référencé${conserves > 1 ? "s" : ""}, conservé${conserves > 1 ? "s" : ""}`
      : `${supprimes} fichiers inutilisés supprimés ✓`,
  );
  await rafraichirAtelier(app);
}

export async function restaurerSauvegarde(app: MovensoApp, nom: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour restaurer cet état.", () => void app.restaurerSauvegarde(nom))) return;
  try {
    const b = await app.occuperPendant("Restauration en cours…", () => app.stockage.restaurerSauvegarde(nom));
    app.bibliotheque = { ...b };
    app.afficherToast("Sauvegarde restaurée ✓ — l'état précédent est lui-même sauvegardé");
    void rafraichirAtelier(app);
  } catch (e) {
    app.consignerEchec("MOV-E05", e);
    app.afficherToast(`Restauration impossible : ${e instanceof Error ? e.message : "sauvegarde illisible"}`, "alerte");
  }
}
