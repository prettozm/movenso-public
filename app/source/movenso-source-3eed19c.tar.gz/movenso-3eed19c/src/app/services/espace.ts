/**
 * Service ESPACE (S3.A1, tranche T1 — extrait de racine.ts, code déménagé tel
 * quel) : gardes d'espace disque avant écriture, limite volontaire D-097,
 * message de refus unique. Fonctions recevant `app` — l'état (préférences,
 * stockage, toasts) reste porté par la racine.
 */

import type { MediaStreame } from "../../echange/movpack.ts";
import { evaluerEspace, tailleEnClair } from "../../domaine/espace.ts";
import type { MovensoApp } from "../racine.ts";

/** Contrôle d'espace AVANT de rendre une restauration/un import DÉFINITIFS
 *  (lot 8A §10) : refus au moment de la confirmation quand l'estimation est
 *  fiable et insuffisante — la bibliothèque LIVE (videos/ + état) n'est jamais
 *  mutée, la proposition reste, les deux tailles sont dites. Les médias déjà
 *  en staging (D-114) sont jetés à l'annulation. */
export function espaceSuffisant(app: MovensoApp, aEcrire: number, estimation: { usage: number; quota: number } | null): boolean {
  const verdict = evaluerEspace(aEcrire, estimation);
  if (verdict.suffisant) return true;
  toastEspaceInsuffisant(app, verdict);
  return false;
}

/** LE message de refus d'espace — un seul texte pour tous les chemins
 *  (S3.A12 : le « toast dupliqué » de l'audit était ce texte copié dans
 *  deux gardes ; jamais deux toasts au même moment). */
function toastEspaceInsuffisant(app: MovensoApp, verdict: { requis: number; disponible?: number | null }): void {
  app.afficherToast(
    `Espace insuffisant : ${tailleEnClair(verdict.requis)} à écrire, environ ${tailleEnClair(verdict.disponible ?? 0)} disponibles — libère de l'espace d'abord, rien n'a été écrit`,
    "alerte",
  );
}

/** Total des octets des médias d'un conteneur (déjà connu, sans les relire). */
export function octetsMedias(medias: MediaStreame[]): number {
  return medias.reduce((s, m) => s + m.taille, 0);
}

/** Limite d'espace volontaire (D-097), en octets — ou `null` si illimité.
 *  Préférence absente = défaut 5 Go ; valeur 0 = illimité. */
export function limiteEspaceOctets(app: MovensoApp): number | null {
  const mo = app.preferences.limiteEspaceMo ?? 5000;
  return mo <= 0 ? null : mo * 1_000_000;
}

/** Estimation d'espace bornée par la limite volontaire (D-097) : le quota
 *  effectif est le plus petit du quota système et de la limite choisie —
 *  toute la chaîne (import, restauration, ajout, capture) la respecte. */
export async function estimationEspace(app: MovensoApp): Promise<{ usage: number; quota: number } | null> {
  const sys = await app.stockage.estimerEspace();
  if (sys === null) return null;
  const limite = limiteEspaceOctets(app);
  return limite === null ? sys : { usage: sys.usage, quota: Math.min(sys.quota, limite) };
}

/** Fixe la limite d'espace volontaire (D-097). `mo <= 0` = illimité ; sinon
 *  borné à un plancher de 200 Mo. Réglage d'appareil, persistant. */
export async function changerLimiteEspace(app: MovensoApp, mo: number): Promise<void> {
  const borne = mo <= 0 ? 0 : Math.max(200, Math.round(mo));
  app.preferences = { ...app.preferences, limiteEspaceMo: borne };
  void app.stockage.sauvegarderPreferences(app.preferences);
  app.requestUpdate();
}

/** Garde-fou d'espace pour l'ajout/capture d'UN fichier (D-096) — même règle
 *  que l'import : refus AVANT écriture quand l'estimation est fiable et
 *  insuffisante. Retourne true si l'écriture doit être abandonnée (toast posé). */
export async function espaceInsuffisantPour(app: MovensoApp, fichier: File): Promise<boolean> {
  const verdict = evaluerEspace(fichier.size, await estimationEspace(app));
  if (verdict.suffisant) return false;
  toastEspaceInsuffisant(app, verdict);
  return true;
}
