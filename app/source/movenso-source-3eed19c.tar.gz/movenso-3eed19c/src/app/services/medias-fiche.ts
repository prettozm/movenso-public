/**
 * Service MÉDIAS DE FICHE + INGESTION (S3.A1, tranche T4 — extrait de
 * racine.ts, code déménagé tel quel) : notes et médias d'une contribution,
 * liens externes validés (S1.3), couverture, ingestion vidéo annulable
 * (analyse + écriture, brouillon jeté), persistance transactionnelle avec
 * rollback des médias neufs. Les drapeaux d'annulation et d'écriture vivent ici.
 */

import type { MovensoApp } from "../racine.ts";
import { espaceInsuffisantPour } from "./espace.ts";
import { preparerVideo, refusFichierVideo, AnnulationIngestion } from "../../domaine/ingestion.ts";
import { appliquerAmendement } from "../../domaine/contribution.ts";
import { analyserLien } from "../../securite/liens.ts";
import { genererUlid } from "../../domaine/ulid.ts";
import type { Bibliotheque, Contribution, Couverture, Media, Provenance } from "../../domaine/modele.ts";

/** Ingestion vidéo annulée par l'utilisateur (S2.4) — état de module. */
let ingestionAnnulee = false;
/** Une écriture de média est en cours (anti double-déclenchement) — état de module. */
let ecritureMediaEnCours = false;
/** Accesseurs pour le service capture (le drapeau reste UNIQUE). */
export function ecritureMedia(): boolean { return ecritureMediaEnCours; }
export function poserEcritureMedia(v: boolean): void { ecritureMediaEnCours = v; }

/** Un lien collé devient un média : YouTube reconnu explicitement (contrat §5),
 *  tout autre lien reste un média « lien » lu en ligne. */
/** Média depuis un lien SAISI — passe par le validateur central (S1.3) :
 *  https seul, normalisation, YouTube strict. `erreur` = message actionnable,
 *  l'appelant refuse PROPREMENT (toast, rien d'écrit, la saisie reste). */
export function mediaDepuisLien(url: string): { media: Media } | { erreur: string } {
  const a = analyserLien(url);
  if (!a.ok) return { erreur: a.raison };
  return {
    media:
      a.type === "plateforme"
        ? { id: genererUlid(), type: "plateforme", service: a.service, ref: a.ref }
        : { id: genererUlid(), type: "lien", ref: a.ref },
  };
}

/** Réduit une image importée en petite vignette (côté max 480 px), encodée en
 *  JPEG data-URL (D-083) : quelques Ko qui voyagent avec le modèle, jamais
 *  l'image d'origine. Rejette si le fichier n'est pas une image décodable. */
async function reduireImageEnVignette(fichier: File): Promise<string> {
  const url = URL.createObjectURL(fichier);
  try {
    const img = await new Promise<HTMLImageElement>((resoudre, rejeter) => {
      const el = new Image();
      el.onload = () => resoudre(el);
      el.onerror = () => rejeter(new Error("image illisible"));
      el.src = url;
    });
    const MAX = 480;
    const echelle = Math.min(1, MAX / Math.max(img.naturalWidth, img.naturalHeight || 1));
    const w = Math.max(1, Math.round(img.naturalWidth * echelle));
    const h = Math.max(1, Math.round(img.naturalHeight * echelle));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("canvas indisponible");
    ctx.drawImage(img, 0, 0, w, h);
    return canvas.toDataURL("image/jpeg", 0.72);
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** Note directe dans Mon carnet — sans feuille de capture (D-024). */
export async function ajouterNote(app: MovensoApp, techniqueId: string, texte: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour écrire dans ton carnet.", () => void app.ajouterNote(techniqueId, texte))) return;
  const b = app.bibliotheque;
  const propre = texte.trim();
  if (!b || !propre) return;
  b.contributions.push({
    id: genererUlid(),
    techniqueId,
    provenance: "personnel",
    description: propre,
    pointsCles: [],
    creeLe: new Date().toISOString(),
    medias: [],
  });
  await app.persister(b);
}

/** Média (fichier/lien) et/ou TEXTE, directement sur la fiche — la
 *  technique n'est jamais redemandée (lot 3 §5, lot 4 §11). `infos` porte
 *  les seules questions utiles : qui l'a produit, attribution, libellé,
 *  texte (contribution complète : explication du club, ressource…). */
export async function ajouterMediaFiche(app: MovensoApp, techniqueId: string,
  source: { fichier?: File; lien?: string },
  infos?: { provenance?: Provenance; attribution?: string; label?: string; texte?: string },): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour ajouter ce média.", () => void app.ajouterMediaFiche(techniqueId, source, infos))) return;
  const b = app.bibliotheque;
  if (!b) return;
  // §concurrence : anti double-appui — un second geste pendant l'écriture ne
  // produit ni contribution ni fichier en double.
  if (ecritureMediaEnCours) return;
  ecritureMediaEnCours = true;
  try {
    const medias: Media[] = [];
    const fichiersEcrits: string[] = []; // seuls les fichiers NEUFS se retirent au rollback
    if (source.fichier) {
      // Ingestion unique (lot 8A §5) : validation type/taille AVANT tout,
      // puis fichier identique déjà présent → id réutilisé, nouvelle
      // référence, AUCUNE réécriture physique.
      const refus = refusFichierVideo(source.fichier);
      if (refus) {
        app.afficherToast(refus); // la feuille reste ouverte, rien n'est écrit
        return;
      }
      const resu = await ingererVideo(app, b, source.fichier, "fichier");
      if (!resu) return; // espace insuffisant — toast déjà posé, rien d'écrit
      if (resu.ecrit) fichiersEcrits.push(resu.media.id);
      medias.push(resu.media);
    }
    if (source.lien?.trim()) {
      const lien = mediaDepuisLien(source.lien.trim());
      if ("erreur" in lien) { app.afficherToast(lien.erreur); return; } // la saisie reste
      medias.push(lien.media);
    }
    if (!medias.length && !infos?.texte?.trim()) return;
    if (infos?.label && medias[0]) medias[0].label = infos.label;
    const provenance = infos?.provenance ?? "personnel";
    const contribution: Contribution = {
      id: genererUlid(),
      techniqueId,
      provenance,
      ...(infos?.texte?.trim() ? { description: infos.texte.trim() } : {}),
      ...(provenance !== "personnel" && infos?.attribution ? { attribution: infos.attribution } : {}),
      pointsCles: [],
      creeLe: new Date().toISOString(),
      medias,
    };
    b.contributions.push(contribution);
    // §14/§19 : jamais d'orphelin — sur échec, contribution ressortie et
    // fichier NEUF retiré (jamais un fichier dédupliqué), la feuille reste
    // ouverte.
    const ok = await persisterAvecMediasNeufs(app, b, fichiersEcrits, () => {
      b.contributions = b.contributions.filter((x) => x.id !== contribution.id);
    });
    if (!ok) return;
    // Le média apparaît immédiatement en tête et dans la galerie (§5) —
    // c'est le média AFFICHÉ de la session, pas le principal global.
    if (medias[0]) app.mediaAffiche = medias[0].id;
    app.ajoutMedia = null;
    app.afficherToast(provenance === "personnel" ? "Ajouté à ton carnet ✓" : medias.length ? "Média ajouté ✓" : "Contribution ajoutée ✓");
  } finally {
    ecritureMediaEnCours = false;
  }
}

/** Média de PRÉSENTATION de la composition (D-124) : une vidéo ou un lien qui
 *  montre l'ensemble (démo complète du kata, vidéo « moi ») — rangé au niveau
 *  de l'OBJET (`presentation.medias`), JAMAIS un pas de la séquence. Remplace
 *  l'ancien bloc `media` fourre-tout (les anciens blocs restent lisibles). */
export async function ajouterMediaPresentation(app: MovensoApp, compoId: string, source: { fichier?: File; lien?: string }, label?: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour ajouter ce média.", () => void app.ajouterMediaPresentation(compoId, source, label))) return;
  const b = app.bibliotheque;
  const compo = b?.compositions.find((x) => x.id === compoId);
  if (!b || !compo) return;
  if (ecritureMediaEnCours) return;
  ecritureMediaEnCours = true;
  try {
    const medias: Media[] = [];
    const fichiersEcrits: string[] = [];
    if (source.fichier) {
      const refus = refusFichierVideo(source.fichier);
      if (refus) { app.afficherToast(refus); return; }
      const resu = await ingererVideo(app, b, source.fichier, "fichier");
      if (!resu) return; // espace insuffisant — toast déjà posé, rien d'écrit
      if (resu.ecrit) fichiersEcrits.push(resu.media.id);
      medias.push(resu.media);
    }
    if (source.lien?.trim()) {
      const lien = mediaDepuisLien(source.lien.trim());
      if ("erreur" in lien) { app.afficherToast(lien.erreur); return; } // la saisie reste
      medias.push(lien.media);
    }
    if (!medias.length) return;
    if (label?.trim() && medias[0]) medias[0].label = label.trim();
    const avant = compo.presentation ? structuredClone(compo.presentation) : undefined;
    compo.presentation = { medias: [...(compo.presentation?.medias ?? []), ...medias] };
    compo.modifieLe = new Date().toISOString();
    const ok = await persisterAvecMediasNeufs(app, b, fichiersEcrits, () => {
      if (avant) compo.presentation = avant;
      else delete compo.presentation;
    });
    if (!ok) return;
    app.afficherToast("Présentation ajoutée ✓");
  } finally {
    ecritureMediaEnCours = false;
  }
}

/** Amende une contribution (arbitrage humain, tuning post-V3 — révise D-027) :
 *  TOUTE source devient éditable. Une contribution issue d'un pack garde son
 *  `origine` intacte (traçabilité, idempotence de réimport) mais reçoit une
 *  signature `modifiePar` = pseudo d'appareil (sinon « moi »), affichée
 *  « Modifié par … ». Le réimport du pack, lui, reste régi par l'idempotence
 *  clé pack+élément — cette édition locale est une surcouche, pas une
 *  réécriture de l'original du pack. */
export async function amenderContribution(app: MovensoApp, id: string, patch: { description?: string; attribution?: string; pointsCles?: string[] }): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour modifier cette contribution.", () => void app.amenderContribution(id, patch))) return;
  const b = app.bibliotheque;
  const c = b?.contributions.find((x) => x.id === id);
  if (!b || !c) return;
  // Contenu importé édité : on note l'éditeur (jamais on n'efface l'origine).
  const signature = c.origine ? { modifiePar: app.preferences.pseudo?.trim() || "moi" } : {};
  patch = { ...patch, ...signature };
  // §18 : transaction — l'original `c` n'est JAMAIS muté. On calcule une
  // contribution amendée (fonction pure), on la substitue dans la liste,
  // puis on persiste ; sur échec, on remet l'original intact (aucune valeur
  // modifiée ne réapparaît, pas même une clé effacée ou ajoutée). La
  // substitution se fait PAR ID (pas par index capturé) : robuste si une
  // opération concurrente a remplacé le tableau (`filter`) pendant l'await —
  // no-op si la contribution a entre-temps disparu (suppression concurrente).
  const amende = appliquerAmendement(c, patch);
  const remplacerParId = (cible: Contribution) => {
    const j = b.contributions.findIndex((x) => x.id === c.id);
    if (j !== -1) b.contributions[j] = cible;
  };
  remplacerParId(amende);
  try {
    await app.persister(b);
  } catch (e) {
    remplacerParId(c);
    app.afficherToast(e instanceof Error ? e.message : "Modification refusée");
  }
}

/** Renomme un média (titre de vidéo, tuning post-V3) — cherche le média par
 *  id dans les contributions, pose/efface son `label`, persiste. Aucun
 *  contenu n'est déplacé ni dupliqué : seul le libellé change. */
export async function majMediaLabel(app: MovensoApp, mediaId: string, label: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour renommer ce média.", () => void app.majMediaLabel(mediaId, label))) return;
  const b = app.bibliotheque;
  if (!b) return;
  const c = b.contributions.find((x) => x.medias.some((m) => m.id === mediaId));
  const m = c?.medias.find((x) => x.id === mediaId);
  if (!c || !m) return;
  const avant = m.label;
  const propre = label.trim();
  if (propre) m.label = propre;
  else delete m.label;
  try {
    await app.persister(b);
  } catch (e) {
    if (avant !== undefined) m.label = avant;
    else delete m.label;
    app.afficherToast(e instanceof Error ? e.message : "Renommage refusé");
  }
}

/** Modifie le LIEN d'un média en ligne (D-119) : re-analyse l'URL (YouTube →
 *  service + id de vidéo, sinon lien nu) et met à jour type/service/ref en
 *  place, sur toutes ses occurrences (même id), sans toucher l'id ni le
 *  libellé. Sans effet sur un média local (le fichier ne se réécrit pas ici). */
export async function majMediaLien(app: MovensoApp, mediaId: string, url: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour modifier ce lien.", () => void app.majMediaLien(mediaId, url))) return;
  const b = app.bibliotheque;
  if (!b) return;
  const propre = url.trim();
  if (!propre) return;
  const cibles = b.contributions.flatMap((c) => c.medias).filter((m) => m.id === mediaId && m.type !== "local");
  if (cibles.length === 0) return;
  const resultatLien = mediaDepuisLien(propre); // validateur central S1.3 — id ignoré ici
  if ("erreur" in resultatLien) {
    app.afficherToast(resultatLien.erreur); // rien n'est modifié
    return;
  }
  const analyse = resultatLien.media;
  const avant = cibles.map((m) => ({ m, type: m.type, service: m.service, ref: m.ref }));
  for (const m of cibles) {
    m.type = analyse.type;
    m.ref = analyse.ref;
    if (analyse.service) m.service = analyse.service;
    else delete m.service;
  }
  try {
    await app.persister(b);
    app.afficherToast("Lien mis à jour ✓");
  } catch (e) {
    for (const a of avant) {
      a.m.type = a.type;
      a.m.ref = a.ref;
      if (a.service) a.m.service = a.service;
      else delete a.m.service;
    }
    app.afficherToast(e instanceof Error ? e.message : "Lien refusé");
  }
}

/** Couverture (D-083) : fixe/retire la vignette personnalisée d'une technique.
 *  Passe par le modèle (data-URL pour une image importée, ou renvoi vers un
 *  média) : ça voyage avec la bibliothèque, les sauvegardes et les packs, sans
 *  toucher au stockage des vidéos. */
async function majCouverture(app: MovensoApp, techniqueId: string, couverture: Couverture | null): Promise<void> {
  const b = app.bibliotheque;
  const t = b?.techniques.find((x) => x.id === techniqueId);
  if (!b || !t) return;
  if (couverture) t.couverture = couverture;
  else delete t.couverture;
  await app.persister(b);
}

/** Importe une image et la réduit en petite vignette (max 480 px, JPEG) avant
 *  de la stocker en data-URL — jamais l'image pleine (poids maîtrisé). */
export async function definirCouvertureImage(app: MovensoApp, techniqueId: string, fichier: File): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour changer la vignette.", () => void app.definirCouvertureImage(techniqueId, fichier))) return;
  try {
    const dataUrl = await reduireImageEnVignette(fichier);
    await majCouverture(app, techniqueId, { type: "image", dataUrl });
    app.afficherToast("Vignette mise à jour ✓");
  } catch {
    app.afficherToast("Image illisible — choisis une autre photo", "alerte");
  }
}

/** Utilise la miniature d'un média déjà présent comme vignette. */
export async function definirCouvertureMedia(app: MovensoApp, techniqueId: string, mediaId: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour changer la vignette.", () => void app.definirCouvertureMedia(techniqueId, mediaId))) return;
  await majCouverture(app, techniqueId, { type: "media", mediaId });
  app.afficherToast("Vignette mise à jour ✓");
}

/** Retire la vignette personnalisée — retour à la vignette par défaut. */
export async function retirerCouverture(app: MovensoApp, techniqueId: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour changer la vignette.", () => void app.retirerCouverture(techniqueId))) return;
  await majCouverture(app, techniqueId, null);
  app.afficherToast("Vignette retirée ✓");
}

/** Retire UN média d'une technique (D-091) — retiré de sa contribution, jamais
 *  le fichier physique (lot 8A §4 : il devient orphelin, diagnostiqué et
 *  supprimable dans l'Atelier après prévisualisation). Snapshot d'abord. Les
 *  renvois vers ce média (vidéo principale, source de la vignette, média
 *  affiché) sont nettoyés ; une contribution devenue vide (ni média, ni texte)
 *  est retirée. */
export async function retirerMedia(app: MovensoApp, techniqueId: string, mediaId: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour retirer ce média.", () => void app.retirerMedia(techniqueId, mediaId))) return;
  const b = app.bibliotheque;
  const t = b?.techniques.find((x) => x.id === techniqueId);
  const c = b?.contributions.find((x) => x.techniqueId === techniqueId && x.medias.some((m) => m.id === mediaId));
  if (!b || !t || !c) return;
  await app.stockage.snapshot("avant-retrait-d-un-media");
  c.medias = c.medias.filter((m) => m.id !== mediaId);
  // Contribution devenue vide (média seul, sans texte) → on la retire.
  if (c.medias.length === 0 && !(c.description ?? "").trim() && c.pointsCles.length === 0) {
    b.contributions = b.contributions.filter((x) => x.id !== c.id);
  }
  if (t.mediaPrincipalId === mediaId) delete t.mediaPrincipalId;
  if (t.couverture?.type === "media" && t.couverture.mediaId === mediaId) delete t.couverture;
  if (app.mediaAffiche === mediaId) app.mediaAffiche = null;
  await app.persister(b);
  app.afficherToast("Média retiré — point de restauration conservé dans les sauvegardes");
}

export function annulerIngestionVideo(app: MovensoApp): void {
  ingestionAnnulee = true;
}

export async function ingererVideo(app: MovensoApp, b: Bibliotheque,
  fichier: File,
  origine: "camera" | "fichier",): Promise<{ media: Media; ecrit: boolean } | null> {
  ingestionAnnulee = false;
  const estAnnule = () => ingestionAnnulee;
  app.enregistrementMedia = { phase: "analyse", fraction: 0, octets: fichier.size, etaSec: null };
  app.requestUpdate();
  try {
    const { media, dejaPresent } = await preparerVideo(b, fichier, origine, estAnnule);
    if (dejaPresent) return { media, ecrit: false };
    if (await espaceInsuffisantPour(app, fichier)) return null;
    const debut = performance.now();
    app.enregistrementMedia = { phase: "ecriture", fraction: 0, octets: fichier.size, etaSec: null };
    app.requestUpdate();
    let dernierRendu = 0;
    await app.stockage.ecrireVideo(media.id, fichier, media.extension, (f) => {
      const maintenant = performance.now();
      if (f < 1 && maintenant - dernierRendu < 100) return; // throttle ~10 img/s
      dernierRendu = maintenant;
      const ecoule = (maintenant - debut) / 1000;
      const etaSec = f > 0.03 ? Math.max(0, Math.round(ecoule / f - ecoule)) : null;
      app.enregistrementMedia = { phase: "ecriture", fraction: f, octets: fichier.size, etaSec };
      app.requestUpdate();
    }, estAnnule);
    return { media, ecrit: true };
  } catch (e) {
    // S2.4 : l'abandon volontaire n'est pas un échec — brouillon déjà jeté
    // (ecrireVideo/empreinte), la capture ou la fiche RESTE ouverte.
    if (e instanceof Error && e.name === "AnnulationIngestion") {
      app.afficherToast("Ajout annulé — rien n'a été écrit");
      return null;
    }
    throw e;
  } finally {
    app.enregistrementMedia = null;
    app.requestUpdate();
  }
}

/** Persiste un état où des fichiers médias NEUFS viennent d'être écrits
 *  (§17, §19) — la transaction média+donnée métier est atomique côté effet
 *  observable : sur échec de persistance, on retire les fichiers NEUFS (jamais
 *  les dédupliqués, partagés avec des références existantes) ET on annule la
 *  mutation mémoire. Résultat : aucun orphelin, aucune référence fantôme.
 *  Retourne `true` si persisté, `false` si un rollback a eu lieu. */
export async function persisterAvecMediasNeufs(app: MovensoApp, b: Bibliotheque, fichiersNeufs: string[], annulerMemoire: () => void): Promise<boolean> {
  try {
    await app.persister(b);
    return true;
  } catch (e) {
    annulerMemoire();
    for (const id of fichiersNeufs) await app.stockage.supprimerVideo(id);
    app.afficherToast(e instanceof Error ? e.message : "Enregistrement refusé");
    return false;
  }
}
