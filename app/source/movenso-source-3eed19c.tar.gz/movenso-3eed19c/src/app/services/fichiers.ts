/**
 * Service FICHIERS LOCAUX / PARTAGE NATIF (S3.A1, tranche T2 — extrait de
 * racine.ts, code déménagé tel quel) : enregistrer un fichier à un endroit
 * retrouvable (D-106, Documents/Movenso sur Android via Filesystem, téléchargement
 * sur le web) et remettre un fichier à la feuille de partage native.
 */

import type { MovensoApp } from "../racine.ts";

/** Déclenche le téléchargement d'un fichier produit localement. */
/** Télécharge un fichier ADOSSÉ AU DISQUE (fichier temporaire OPFS) : l'URL
 *  objet référence le Blob sans le copier dans le tas JS (lot 8B §15). */
export function telechargerFichier(fichier: Blob, nom: string): void {
  const url = URL.createObjectURL(fichier);
  const a = document.createElement("a");
  a.href = url;
  a.download = nom;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

/** Enregistre un fichier LOCALEMENT à un endroit que l'utilisateur retrouve
 *  (D-106). Sur Android (Capacitor), un `<a download>` sur blob URL ne produit
 *  AUCUN fichier trouvable dans la WebView — on écrit donc via Filesystem dans
 *  **Documents/Movenso** (visible depuis l'app Fichiers). Sur le web, le
 *  téléchargement classique. Retourne une description de l'emplacement, pour
 *  le message de confirmation. */
export async function enregistrerFichierLocal(app: MovensoApp, fichier: File): Promise<string> {
  let estNatif = false;
  try {
    const { Capacitor } = await import("@capacitor/core");
    estNatif = !!Capacitor?.isNativePlatform?.();
    if (estNatif) {
      await ecrireFichierNatifParBlocs(fichier, "documents", `Movenso/${fichier.name}`);
      return `Documents/Movenso/${fichier.name}`;
    }
  } catch {
    // Écriture Documents impossible (Android 10 / scoped storage / OEM). Sur
    // NATIF, on route vers la feuille de partage (« Enregistrer dans
    // Fichiers ») — le `<a download>` ne produit RIEN de trouvable en WebView,
    // et prétendre un succès serait mensonger (D-110). Le web, lui, télécharge.
    if (estNatif) {
      await remettreFichierPartage(app, fichier, fichier.name, `Movenso — ${fichier.name}`);
      return "le partage — choisis « Enregistrer dans Fichiers »";
    }
  }
  telechargerFichier(fichier, fichier.name);
  return "tes téléchargements";
}

/** Remet un `.movpack` au PARTAGE, du plus intégré au plus sûr :
 *  1) sur Android (Capacitor), la vraie feuille de partage du système
 *     (WhatsApp, Drive, mail…) via le fichier écrit dans le cache ;
 *  2) sinon le partage Web natif (navigateurs récents) ;
 *  3) sinon un téléchargement, en disant OÙ trouver le fichier. */
export async function remettreFichierPartage(app: MovensoApp, fichier: File, titre: string, texte: string): Promise<void> {
  // 1) Android natif — la feuille de partage système ouvre WhatsApp/Drive/mail.
  try {
    const { Capacitor } = await import("@capacitor/core");
    if (Capacitor?.isNativePlatform?.()) {
      const { Filesystem, Directory } = await import("@capacitor/filesystem");
      const { Share } = await import("@capacitor/share");
      await ecrireFichierNatifParBlocs(fichier, "cache", fichier.name);
      const { uri } = await Filesystem.getUri({ path: fichier.name, directory: Directory.Cache });
      await Share.share({ title: titre, text: texte, url: uri });
      app.afficherToast("Partagé ✓");
      return;
    }
  } catch (e) {
    if (e instanceof Error && /cancel/i.test(e.message)) return; // annulé par l'utilisateur
    // toute autre erreur (plugin absent, WebView limitée) → replis ci-dessous
  }
  // 2) Partage Web natif (fichiers).
  const nav = navigator as Navigator & {
    canShare?: (donnees?: { files?: File[] }) => boolean;
    share?: (donnees: { files?: File[]; title?: string; text?: string }) => Promise<void>;
  };
  if (nav.share && nav.canShare?.({ files: [fichier] })) {
    try {
      await nav.share({ files: [fichier], title: titre, text: texte });
      app.afficherToast("Partagé ✓");
      return;
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return;
    }
  }
  // 3) Repli : téléchargement, avec un message qui dit où le trouver.
  telechargerFichier(fichier, fichier.name);
  app.afficherToast("Fichier .movpack enregistré dans tes téléchargements — joins-le depuis WhatsApp, Drive ou un mail.");
}

/** Encode un blob en base64 (par tranches, sans exploser la pile) — requis
 *  par Filesystem.writeFile/appendFile du natif Android. Accepte un Blob (une
 *  tranche de fichier), pour l'écriture par blocs (D-111). */
async function blobEnBase64(fichier: Blob): Promise<string> {
  const octets = new Uint8Array(await fichier.arrayBuffer());
  let binaire = "";
  const TRANCHE = 0x8000;
  for (let i = 0; i < octets.length; i += TRANCHE) binaire += String.fromCharCode(...octets.subarray(i, i + TRANCHE));
  return btoa(binaire);
}

/** Écrit un fichier sur le stockage NATIF par BLOCS (D-111) : jamais le
 *  fichier entier + son base64 en RAM d'un coup (OOM garanti sur une vidéo de
 *  plusieurs centaines de Mo). Chaque bloc fait un multiple de 3 octets → son
 *  base64 se concatène proprement via `appendFile`. */
async function ecrireFichierNatifParBlocs(fichier: Blob, dossier: "documents" | "cache", chemin: string): Promise<void> {
  const { Filesystem, Directory } = await import("@capacitor/filesystem");
  const directory = dossier === "documents" ? Directory.Documents : Directory.Cache;
  const TAILLE = 3 * 1024 * 1024; // 3 Mo, multiple de 3 (base64 concaténable)
  if (fichier.size === 0) {
    await Filesystem.writeFile({ path: chemin, data: "", directory, recursive: true });
    return;
  }
  let premier = true;
  for (let offset = 0; offset < fichier.size; offset += TAILLE) {
    const b64 = await blobEnBase64(fichier.slice(offset, offset + TAILLE));
    if (premier) {
      await Filesystem.writeFile({ path: chemin, data: b64, directory, recursive: true });
      premier = false;
    } else {
      await Filesystem.appendFile({ path: chemin, data: b64, directory });
    }
  }
}
