/**
 * Service TAXONOMIES + TYPES DE RELATION (S3.A1, tranche T6 — extrait de
 * racine.ts, code déménagé tel quel) : renommage de discipline, catégories et
 * niveaux (ajout, renommage, réordonnancement, suppression AVEC arbitrage —
 * jamais de référence invalide), types de relation en données (D-020.2).
 */

import type { MovensoApp } from "../racine.ts";
import type { Technique } from "../../domaine/modele.ts";

export async function majNomDiscipline(app: MovensoApp, id: string, nom: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour renommer cette discipline.", () => void app.majNomDiscipline(id, nom))) return;
  const b = app.bibliotheque;
  const d = b?.disciplines.find((x) => x.id === id);
  if (!b || !d || !nom.trim()) return;
  d.nom = nom.trim();
  await app.persister(b);
}

export async function ajouterTaxonomie(app: MovensoApp, disciplineId: string, quoi: "familles" | "niveaux", nom: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour modifier les taxonomies.", () => void app.ajouterTaxonomie(disciplineId, quoi, nom))) return;
  const b = app.bibliotheque;
  const d = b?.disciplines.find((x) => x.id === disciplineId);
  const propre = nom.trim();
  if (!b || !d || !propre) return;
  const base = propre.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-");
  let id = base;
  for (let n = 2; [...d.familles, ...d.niveaux].some((x) => x.id === id); n++) id = `${base}-${n}`;
  d[quoi].push({ id, nom: propre, ordre: d[quoi].length + 1 });
  await app.persister(b);
}

export async function majTaxonomie(app: MovensoApp, disciplineId: string,
  quoi: "familles" | "niveaux",
  id: string,
  patch: { nom?: string; couleur?: string; couleur2?: string },): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour modifier les taxonomies.", () => void app.majTaxonomie(disciplineId, quoi, id, patch))) return;
  const b = app.bibliotheque;
  const d = b?.disciplines.find((x) => x.id === disciplineId);
  const entree = d?.[quoi].find((x) => x.id === id);
  if (!b || !entree) return;
  if (patch.nom?.trim()) entree.nom = patch.nom.trim();
  if (quoi === "niveaux") {
    const n = entree as { couleur?: string; couleur2?: string };
    if (patch.couleur !== undefined) (patch.couleur ? (n.couleur = patch.couleur) : delete n.couleur);
    if (patch.couleur2 !== undefined) (patch.couleur2 ? (n.couleur2 = patch.couleur2) : delete n.couleur2);
  }
  await app.persister(b);
}

/** Techniques de la discipline utilisant une taxonomie (lot 6 §8). */
export function usagesTaxonomie(app: MovensoApp, disciplineId: string, quoi: "familles" | "niveaux", id: string): Technique[] {
  return (app.bibliotheque?.techniques ?? []).filter(
    (t) => t.disciplineId === disciplineId && (quoi === "familles" ? t.familleId === id : t.niveauxIds.includes(id)),
  );
}

/** Déplace une famille ou un niveau d'un cran (lot 6 §8) — le champ
 *  `ordre` suit l'ordre du tableau. */
export function reordonnerTaxonomie(app: MovensoApp, disciplineId: string, quoi: "familles" | "niveaux", id: string, delta: -1 | 1): void {
  if (!app.garde("modification", "Saisis le PIN pour modifier les taxonomies.", () => void app.reordonnerTaxonomie(disciplineId, quoi, id, delta))) return;
  const b = app.bibliotheque;
  const d = b?.disciplines.find((x) => x.id === disciplineId);
  if (!b || !d) return;
  const liste = d[quoi];
  const i = liste.findIndex((x) => x.id === id);
  const j = i + delta;
  if (i < 0 || j < 0 || j >= liste.length) return;
  const [entree] = liste.splice(i, 1);
  liste.splice(j, 0, entree as never);
  liste.forEach((x, n) => (x.ordre = n + 1));
  void app.persister(b);
}

/** Retire une famille ou un niveau avec CONTRÔLE DES USAGES (lot 6 §8) :
 *  sans `resolution`, refus actionnable si utilisée (jamais de référence
 *  invalide) ; `resolution` = id d'une autre valeur (report sur les
 *  fiches) ou null (retirer la classification). Snapshot motivé dès que
 *  des fiches changent. */
export async function supprimerTaxonomie(app: MovensoApp, disciplineId: string,
  quoi: "familles" | "niveaux",
  id: string,
  resolution?: string | null,): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour supprimer cette valeur de classification.", () => void app.supprimerTaxonomie(disciplineId, quoi, id, resolution))) return;
  const b = app.bibliotheque;
  const d = b?.disciplines.find((x) => x.id === disciplineId);
  const entree = d?.[quoi].find((x) => x.id === id);
  if (!b || !d || !entree) return;
  const usages = app.usagesTaxonomie(disciplineId, quoi, id);
  if (usages.length && resolution === undefined) {
    app.afficherToast(`Utilisé par ${usages.length} technique${usages.length > 1 ? "s" : ""} — choisis « remplacer » ou « retirer la classification »`);
    return;
  }
  const cible = resolution ? d[quoi].find((x) => x.id === resolution)?.nom : null;
  if (resolution && !cible) return; // cible inconnue : rien ne bouge
  if (usages.length) {
    await app.stockage.snapshot(`avant-suppression-taxonomie-${entree.nom}`);
    for (const t of usages) {
      if (quoi === "familles") resolution ? (t.familleId = resolution) : delete t.familleId;
      else
        t.niveauxIds = resolution
          ? [...new Set(t.niveauxIds.map((x) => (x === id ? resolution : x)))]
          : t.niveauxIds.filter((x) => x !== id);
    }
  }
  d[quoi] = d[quoi].filter((x) => x.id !== id) as never;
  await app.persister(b);
  if (usages.length) {
    app.afficherToast(cible
      ? `« ${entree.nom} » supprimée — ${usages.length} technique${usages.length > 1 ? "s" : ""} reclassée${usages.length > 1 ? "s" : ""} vers « ${cible} » (point de restauration conservé)`
      : `« ${entree.nom} » supprimée — classification retirée de ${usages.length} technique${usages.length > 1 ? "s" : ""} (point de restauration conservé)`);
  }
}

export async function ajouterTypeRelation(app: MovensoApp, libelle: string, libelleInverse: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour modifier les types de lien.", () => void app.ajouterTypeRelation(libelle, libelleInverse))) return;
  const b = app.bibliotheque;
  const propre = libelle.trim();
  if (!b || !propre) return;
  const base = propre.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-");
  if (b.typesRelation.some((t) => t.id === base)) {
    app.afficherToast(`Le type « ${propre} » existe déjà`);
    return;
  }
  const symetrique = libelleInverse.trim() === "";
  b.typesRelation.push({
    id: base,
    libelle: propre,
    ...(symetrique ? { symetrique: true } : { libelleInverse: libelleInverse.trim() }),
  });
  await app.persister(b);
  app.afficherToast(`Type de relation « ${propre} » ajouté ✓`);
}

/** Renomme un type de lien — libellés seulement, l'id (slug) ne bouge
 *  jamais : les relations existantes restent cohérentes (lot 6 §10). */
export async function majTypeRelation(app: MovensoApp, id: string, patch: { libelle?: string; libelleInverse?: string }): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour modifier les types de lien.", () => void app.majTypeRelation(id, patch))) return;
  const b = app.bibliotheque;
  const t = b?.typesRelation.find((x) => x.id === id);
  if (!b || !t) return;
  if (patch.libelle !== undefined && patch.libelle.trim()) t.libelle = patch.libelle.trim();
  if (patch.libelleInverse !== undefined && !t.symetrique) {
    const v = patch.libelleInverse.trim();
    if (!v) {
      app.afficherToast("Un lien orienté garde une lecture inverse — ou passe-le en symétrique d'abord");
      return;
    }
    t.libelleInverse = v;
  }
  await app.persister(b);
}

/** Bascule la symétrie d'un type — UNIQUEMENT s'il est inutilisé : la
 *  nature de lecture des relations existantes ne change jamais en
 *  silence (lot 6 §10). */
export async function basculerSymetrieTypeRelation(app: MovensoApp, id: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour modifier les types de lien.", () => void app.basculerSymetrieTypeRelation(id))) return;
  const b = app.bibliotheque;
  const t = b?.typesRelation.find((x) => x.id === id);
  if (!b || !t) return;
  const usages = app.usagesTypeRelation(id);
  if (usages) {
    app.afficherToast(`« ${t.libelle} » relie déjà ${usages} paire${usages > 1 ? "s" : ""} de techniques — sa nature de lecture ne peut plus changer`);
    return;
  }
  if (t.symetrique) {
    delete t.symetrique;
    t.libelleInverse = t.libelleInverse ?? `${t.libelle} (inverse)`;
  } else {
    t.symetrique = true;
    delete t.libelleInverse;
  }
  await app.persister(b);
}
