/**
 * Service FAVORIS + DOUBLONS (S3.A1, tranche T5 — extrait de racine.ts, code
 * déménagé tel quel) : marque-pages immédiats et réversibles (lot 5 §4-5) ;
 * aide non bloquante aux doublons (D-068) — scan, « ce ne sont pas des
 * doublons », résolution garder/retirer, fusion avec point de restauration et
 * impacts externes annoncés (S2.6), défusion par source, adaptation locale.
 */

import type { MovensoApp } from "../racine.ts";
import { clePaire, detecterDoublons, defusionnerDoublons, fusionnerDoublons, type ChoixFusion, type PaireDoublon } from "../../domaine/doublons.ts";
import { nomEditorialSource } from "../vues.ts";
import { genererUlid } from "../../domaine/ulid.ts";
import type { Bibliotheque, Contribution, Technique } from "../../domaine/modele.ts";

export function estFavori(app: MovensoApp, techniqueId: string): boolean {
  return app.bibliotheque?.favoris.includes(techniqueId) ?? false;
}

/** Ajout/retrait immédiat, sans confirmation (§5) — rien d'autre ne change. */
export async function basculerFavori(app: MovensoApp, techniqueId: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour modifier tes favoris.", () => void app.basculerFavori(techniqueId))) return;
  const b = app.bibliotheque;
  if (!b || !b.techniques.some((t) => t.id === techniqueId)) return;
  const retire = b.favoris.includes(techniqueId);
  b.favoris = retire ? b.favoris.filter((x) => x !== techniqueId) : [...b.favoris, techniqueId];
  await app.persister(b);
  app.afficherToast(retire ? "Retiré des favoris" : "Ajouté aux favoris");
}

/** Favoris affichables : les références orphelines (technique retirée par un
 *  réimport) sont ignorées à l'affichage — jamais d'écran cassé, jamais de
 *  technique fantôme (§6, comportement tracé). */
export function techniquesFavorites(app: MovensoApp): Technique[] {
  const b = app.bibliotheque;
  if (!b) return [];
  return b.favoris.map((id) => b.techniques.find((t) => t.id === id)).filter((t): t is Technique => t !== undefined);
}

/** Paires de fiches en forte homonymie inter-packs, hors paires « ignorées ». */
export function doublonsPotentiels(app: MovensoApp): PaireDoublon[] {
  const b = app.bibliotheque;
  if (!b) return [];
  return detecterDoublons(b, b.doublonsIgnores ?? []);
}

/** Rescan (tuning post-V3) : oublie toutes les paires écartées (« conservées »
 *  / « pas des doublons ») pour les re-proposer à l'arbitrage. Ne fusionne ni
 *  ne supprime rien — remet juste la détection à zéro côté paires ignorées. */
export async function rescannerDoublons(app: MovensoApp): Promise<void> {
  const b = app.bibliotheque;
  if (!b || !(b.doublonsIgnores ?? []).length) return;
  delete b.doublonsIgnores;
  await app.persister(b);
  app.doublonOuvert = null;
  app.requestUpdate();
  app.afficherToast("Rescan effectué — les paires écartées reviennent à l'arbitrage.");
}

/** Résout une paire SANS suppression : les deux fiches restent indépendantes,
 *  la paire cesse d'être proposée (arbitrée). Sert aussi à « ce ne sont pas
 *  des doublons ». Jamais de PIN : rien n'est détruit. */
export async function classerDoublon(app: MovensoApp, aId: string, bId: string, message: string): Promise<void> {
  const b = app.bibliotheque;
  if (!b) return;
  b.doublonsIgnores = [...new Set([...(b.doublonsIgnores ?? []), clePaire(aId, bId)])];
  await app.persister(b);
  if (app.fusionDoublon && app.fusionDoublon.aId === aId && app.fusionDoublon.bId === bId) app.fusionDoublon = null;
  app.afficherToast(message);
}

/** Conserver UNE fiche de la paire, retirer l'autre — la suppression passe par
 *  `supprimerTechnique` (PIN, snapshot = sauvegarde préalable, confirmation,
 *  reprise des notes personnelles « à rattacher »). */
export async function resoudreDoublonGarder(app: MovensoApp, gardeId: string, retireId: string): Promise<void> {
  const b = app.bibliotheque;
  if (!b || !b.techniques.some((t) => t.id === gardeId)) return;
  await app.supprimerTechnique(retireId);
}

/** Fusion sélective de deux doublons en une fiche cohérente (D-068) — PIN,
 *  snapshot préalable, jamais d'empilement ni de média dupliqué. */
export async function fusionnerDoublonAvec(app: MovensoApp, aId: string, bId: string, choix: ChoixFusion): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour fusionner ces fiches.", () => void app.fusionnerDoublonAvec(aId, bId, choix))) return;
  const b = app.bibliotheque;
  if (!b) return;
  await app.stockage.snapshot("avant-fusion-doublon");
  // Bundle pré-fusion des deux fiches (D-101, voie H) : de quoi défusionner.
  const bundle = (id: string) => {
    const technique = b.techniques.find((t) => t.id === id)!;
    return {
      technique: structuredClone(technique),
      contributions: b.contributions.filter((c) => c.techniqueId === id).map((c) => structuredClone(c)),
      etaitFavori: b.favoris.includes(id),
    };
  };
  const aAvant = bundle(aId);
  const bAvant = bundle(bId);
  let fusionnee: Bibliotheque;
  try {
    fusionnee = fusionnerDoublons(b, aId, bId, choix);
  } catch (e) {
    app.afficherToast(`Fusion impossible : ${e instanceof Error ? e.message : "état inattendu"}`, "alerte");
    return;
  }
  fusionnee.fusions = [
    ...(fusionnee.fusions ?? []),
    { fusionneeLe: new Date().toISOString(), fusionneeId: aId, a: aAvant, b: bAvant },
  ];
  app.fusionDoublon = null;
  await app.persister(fusionnee);
  app.afficherToast("Fusionnées en une seule fiche ✓ — défusionnable depuis « Doublons »");
}

/** Défusion (D-101, voie H) : rétablit les deux fiches d'origine d'une fusion. */
export async function defusionner(app: MovensoApp, fusionneeId: string): Promise<void> {
  if (!app.garde("destruction_ou_sensible", "Saisis le PIN pour défusionner ces fiches.", () => void app.defusionner(fusionneeId))) return;
  const b = app.bibliotheque;
  if (!b) return;
  await app.stockage.snapshot("avant-defusion");
  let defait: Bibliotheque;
  try {
    defait = defusionnerDoublons(b, fusionneeId);
  } catch (e) {
    app.afficherToast(`Défusion impossible : ${e instanceof Error ? e.message : "état inattendu"}`, "alerte");
    return;
  }
  await app.persister(defait);
  app.afficherToast("Fiches défusionnées ✓ — les deux fiches d'origine sont rétablies");
}

/** Adaptation locale d'une voix importée (D-027, invariants 58-61) : une
 *  NOUVELLE contribution locale, préremplie depuis la source, attribuée
 *  lisiblement, directement modifiable — l'original ne bouge jamais et une
 *  réimportation ne l'écrase pas (elle n'a pas d'`origine`). Les médias
 *  restent à la voix d'origine : l'adaptation porte le texte. */
export async function creerAdaptationLocale(app: MovensoApp, contributionId: string): Promise<void> {
  if (!app.garde("modification", "Saisis le PIN pour créer une adaptation locale.", () => void app.creerAdaptationLocale(contributionId))) return;
  const b = app.bibliotheque;
  const source = b?.contributions.find((x) => x.id === contributionId);
  if (!b || !source) return;
  const adaptation: Contribution = {
    id: genererUlid(),
    techniqueId: source.techniqueId,
    provenance: "personnel",
    ...(source.description ? { description: source.description } : {}),
    pointsCles: [...source.pointsCles],
    ...(source.variantes ? { variantes: source.variantes } : {}),
    attribution: `Adaptation locale d'après ${nomEditorialSource(source)}`,
    creeLe: new Date().toISOString(),
    medias: [],
  };
  b.contributions.push(adaptation);
  await app.persister(b);
  app.voixOuverte = adaptation.id; // l'adaptation s'ouvre, prête à travailler
  app.afficherToast("Adaptation locale créée — modifiable librement ✓");
}
