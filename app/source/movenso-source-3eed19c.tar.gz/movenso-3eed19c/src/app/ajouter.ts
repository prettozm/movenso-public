/**
 * Panneau contextuel « Ajouter » (lot 4 §2-3) — court, orienté gestes,
 * jamais de vocabulaire interne (identité, contribution, provenance, pack).
 * Racine Bibliothèque : deux gestes. Discipline ouverte : cinq gestes,
 * discipline présélectionnée. Sa fermeture ne modifie aucune donnée.
 */

import { html, nothing, type TemplateResult } from "lit";
import { doublonsPotentiels } from "../domaine/rapprochement.ts";
import type { MovensoApp } from "./racine.ts";

export interface EtatAjouter {
  /** Discipline présélectionnée quand le panneau s'ouvre depuis une discipline. */
  disciplineId?: string;
  /** Sous-étape « Une technique » : nom + discipline si nécessaire. */
  creation?: boolean;
  nomTechnique?: string;
  disciplineChoisieId?: string;
  disciplineNom?: string;
  /** Enrichissements FACULTATIFS de la création (lot 4 §4).
   *  `| undefined` explicite : ces choix se REMETTENT à zéro (changement de
   *  discipline, « Je le ferai plus tard ») — exactOptionalPropertyTypes. */
  appellation?: string;
  classer?: boolean;
  familleId?: string | undefined;
  niveauxIds?: string[];
}

export function gabaritAjouter(app: MovensoApp): TemplateResult {
  const etat = app.ajouter!;
  return html`
    <div class="voile" @click=${() => (app.ajouter = null)}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Ajouter">
      <div class="prise"></div>
      <h2>Que veux-tu ajouter ?</h2>
      ${etat.creation ? html`<div class="geste">Son nom et sa discipline suffisent.</div>` : nothing}
      ${etat.creation ? etapeCreation(app) : listeGestes(app)}
    </div>
  `;
}

function listeGestes(app: MovensoApp): TemplateResult {
  const etat = app.ajouter!;
  return html`
    <div class="gestes-ajouter">
      <button class="option-ajouter" @click=${() => (app.ajouter = { ...etat, creation: true })}>
        ＋ Créer une technique <span>nom et discipline</span>
      </button>
      <button class="option-ajouter" @click=${() => { app.ajouter = null; app.ouvrirCapture(); }}>
        🎥 Capture rapide <span>Filmer, choisir une vidéo ou enregistrer un lien pour le classer plus tard.</span>
      </button>
    </div>
    <div class="actions">
      <button class="bouton" @click=${() => (app.ajouter = null)}>Annuler</button>
    </div>
  `;
}

/** Création d'une technique (§4-5) : le minimum suffit — nom + discipline
 *  connue, choisie ou créée dans le même parcours ; appellation et
 *  classification FACULTATIVES ; les doublons potentiels se suggèrent
 *  pendant la saisie, jamais de fusion silencieuse. La fiche s'ouvre après. */
function etapeCreation(app: MovensoApp): TemplateResult {
  const etat = app.ajouter!;
  const b = app.bibliotheque!;
  const choisie = etat.disciplineChoisieId ?? etat.disciplineId ?? b.disciplines[0]?.id;
  const discipline = b.disciplines.find((d) => d.id === choisie);
  const nom = (etat.nomTechnique ?? "").trim();
  const pret = nom !== "" && (b.disciplines.length > 0 ? choisie !== undefined : (etat.disciplineNom ?? "").trim() !== "");
  // Prévention des doublons (§5) : identités existantes de la même discipline.
  const doublons = choisie && nom ? doublonsPotentiels(b, choisie, nom) : { exacte: null, proches: [] };
  const extras = () => ({
    ...(etat.appellation?.trim() ? { nomTraditionnel: etat.appellation.trim() } : {}),
    ...(etat.familleId ? { familleId: etat.familleId } : {}),
    ...(etat.niveauxIds?.length ? { niveauxIds: etat.niveauxIds } : {}),
  });
  const creerVraiment = async () => {
    let disciplineId = b.disciplines.length ? choisie : undefined;
    if (!disciplineId) disciplineId = (await app.creerDiscipline(etat.disciplineNom!.trim())) ?? undefined;
    if (!disciplineId) return;
    app.ajouter = null;
    await app.creerTechnique(disciplineId, nom, extras());
  };
  const creer = async () => {
    if (!pret) return;
    // Correspondance exacte unique : la création séparée exige une
    // confirmation explicite (§5) — jamais de doublon par inattention.
    if (doublons.exacte) {
      app.demanderConfirmation({
        titre: `« ${doublons.exacte.nom} » existe déjà dans ${discipline?.nom ?? "cette discipline"}`,
        corps: "Créer quand même une technique distincte ?",
        bouton: "Créer quand même",
        action: () => { void creerVraiment(); },
      });
      return;
    }
    await creerVraiment();
  };
  const utiliser = (techniqueId: string) => {
    app.ajouter = null;
    app.ouvrirFiche(techniqueId);
  };
  const basculerNiveau = (id: string) => {
    const actuels = etat.niveauxIds ?? [];
    app.ajouter = { ...etat, niveauxIds: actuels.includes(id) ? actuels.filter((x) => x !== id) : [...actuels, id] };
  };
  const aClasser = (discipline?.familles.length ?? 0) > 0 || (discipline?.niveaux.length ?? 0) > 0;
  return html`
    <div style="padding:2px 0">
      <input class="champ-note champ-nouveau-nom" style="min-height:0" autofocus aria-label="Nom de la technique"
             placeholder="Nom de la technique…"
             .value=${etat.nomTechnique ?? ""}
             @input=${(e: InputEvent) => (app.ajouter = { ...etat, nomTechnique: (e.target as HTMLInputElement).value })}
             @keydown=${(e: KeyboardEvent) => { if (e.key === "Enter") void creer(); }}>
    </div>
    ${doublons.exacte || doublons.proches.length
      ? html`<div class="doublons">
          ${doublons.exacte
            ? html`<div class="doublon-exacte">« ${doublons.exacte.nom} » existe déjà dans ${discipline?.nom ?? "cette discipline"}.</div>`
            : html`<div>Technique similaire déjà présente :</div>`}
          <div class="chips-filtres" style="padding:6px 0 0">
            ${[...(doublons.exacte ? [doublons.exacte] : []), ...doublons.proches].map(
              (t) => html`<button class="chip-filtre" @click=${() => utiliser(t.id)}>Utiliser « ${t.nom} »</button>`,
            )}
          </div>
        </div>`
      : nothing}
    ${etat.disciplineId === undefined && b.disciplines.length > 0
      ? html`<div class="chips-filtres" style="padding:8px 0 2px" aria-label="Dans quelle discipline ?">
          ${b.disciplines.map(
            (d) => html`<button class="chip-filtre ${choisie === d.id ? "actif" : ""}"
              @click=${() => (app.ajouter = { ...etat, disciplineChoisieId: d.id, familleId: undefined, niveauxIds: [] })}>${d.nom}</button>`,
          )}
        </div>`
      : nothing}
    ${b.disciplines.length === 0
      ? html`<div style="padding:6px 0 2px">
          <input class="champ-note champ-discipline" style="min-height:0" aria-label="Discipline"
                 placeholder="Dans quelle discipline ? (ex. Judo, Boxe…)"
                 .value=${etat.disciplineNom ?? ""}
                 @input=${(e: InputEvent) => (app.ajouter = { ...etat, disciplineNom: (e.target as HTMLInputElement).value })}>
        </div>`
      : nothing}
    ${aClasser
      ? etat.classer
        ? html`<div class="classer-maintenant">
            ${discipline!.familles.length
              ? html`<div class="section-titre" style="padding:8px 2px 2px">Famille</div>
                  <div class="chips-filtres">
                    ${discipline!.familles.map(
                      (f) => html`<button class="chip-filtre ${etat.familleId === f.id ? "actif" : ""}"
                        @click=${() => (app.ajouter = { ...etat, familleId: etat.familleId === f.id ? undefined : f.id })}>${f.nom}</button>`,
                    )}
                  </div>`
              : nothing}
            ${discipline!.niveaux.length
              ? html`<div class="section-titre" style="padding:8px 2px 2px">Niveau</div>
                  <div class="chips-filtres">
                    ${discipline!.niveaux.map(
                      (n) => html`<button class="chip-filtre ${etat.niveauxIds?.includes(n.id) ? "actif" : ""}"
                        @click=${() => basculerNiveau(n.id)}>${n.nom}</button>`,
                    )}
                  </div>`
              : nothing}
            <button class="action-douce" style="margin-top:8px"
              @click=${() => (app.ajouter = { ...etat, classer: false, familleId: undefined, niveauxIds: [] })}>
              Je le ferai plus tard <span>la technique se crée sans classement</span>
            </button>
          </div>`
        : html`<button class="action-douce" style="margin-top:8px" @click=${() => (app.ajouter = { ...etat, classer: true })}>
            Classer maintenant <span>(facultatif — famille, niveau)</span>
          </button>`
      : nothing}
    <div class="actions">
      <button class="bouton" @click=${() => (app.ajouter = { ...etat, creation: false })}>← Retour</button>
      <button class="bouton principal" ?disabled=${!pret} @click=${() => void creer()}>
        ${doublons.exacte || doublons.proches.length ? "Créer quand même" : "Créer la technique"}
      </button>
    </div>
  `;
}
