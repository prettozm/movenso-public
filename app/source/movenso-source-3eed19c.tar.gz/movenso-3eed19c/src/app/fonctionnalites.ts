/**
 * Drapeaux de fonctionnalités — activer / désactiver une capacité entière SANS
 * supprimer de code. Mettre un drapeau à `false` retire proprement ses points
 * d'entrée (onglet, boutons, écran) ; le code reste en place, réactivable d'un
 * seul changement ici.
 */

/** Vue visuelle des relations (« carte mentale ») : onglet bas « Relations » +
 *  bouton « Voir en graphe » sur la fiche. `false` = fonctionnalité invisible,
 *  l'app retombe sur la navigation à quatre onglets. */
export const RELATIONS_VISUELLES = true;
