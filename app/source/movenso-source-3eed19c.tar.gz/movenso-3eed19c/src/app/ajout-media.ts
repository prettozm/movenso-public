/**
 * Feuille « Ajouter un média » — depuis la fiche, sans la quitter et sans
 * redemander la technique (lot 3 §5) : la fiche ouverte la détermine déjà.
 * Deux moments : le contenu (filmer / fichier / lien), puis les seules
 * questions utiles (qui l'a produit, attribution, libellé facultatif).
 */

import { html, nothing, type TemplateResult } from "lit";
import type { Provenance } from "../domaine/modele.ts";
import type { MovensoApp } from "./racine.ts";

export interface EtatAjoutMedia {
  techniqueId: string;
  /** `contribution` (lot 4 §11) : texte et/ou média, distinct du carnet. */
  mode?: "media" | "contribution";
  fichier?: File;
  lien?: string;
  saisieLien?: boolean;
  provenance: Provenance;
  attribution?: string;
  label?: string;
  texte?: string;
}

export function gabaritAjoutMedia(app: MovensoApp): TemplateResult {
  const etat = app.ajoutMedia!;
  if (etat.mode === "contribution")
    return html`
      <div class="voile" @click=${() => (app.ajoutMedia = null)}></div>
      <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Ajouter du contenu">
        <div class="prise"></div>
        <h2>Ajouter du contenu</h2>
        <div class="geste">De qui vient ce contenu ? — la technique est déjà connue</div>
        ${etapeContribution(app)}
      </div>
    `;
  const contenuChoisi = etat.fichier !== undefined || etat.lien !== undefined;
  return html`
    <div class="voile" @click=${() => (app.ajoutMedia = null)}></div>
    <div class="feuille" role="dialog" aria-modal="true" tabindex="-1" aria-label="Ajouter un média">
      <div class="prise"></div>
      <h2>Ajouter un média</h2>
      <div class="geste">${contenuChoisi ? "Qui a produit ce média ?" : "Le contenu — filmer, choisir ou lier"}</div>
      ${contenuChoisi ? etapeInfos(app) : etapeContenu(app)}
    </div>
  `;
}

/** Contribution complète depuis la fiche (lot 4 §11) — trois questions au
 *  plus : de qui, quoi (texte et/ou média), attribution selon le cas.
 *  Jamais de discipline, de technique, de pack ni d'id de source. */
function etapeContribution(app: MovensoApp): TemplateResult {
  const etat = app.ajoutMedia!;
  const choisir = (p: Provenance) =>
    (app.ajoutMedia = { ...etat, provenance: p, ...(p === "personnel" ? { attribution: "" } : {}) });
  const aContenu = (etat.texte ?? "").trim() !== "" || etat.fichier !== undefined || (etat.lien ?? "").trim() !== "";
  const pret = aContenu && (etat.provenance !== "ressource" || (etat.attribution ?? "").trim() !== "");
  const joindreFichier = () => {
    const champ = document.createElement("input");
    champ.type = "file";
    champ.accept = "video/*";
    champ.onchange = () => {
      const fichier = champ.files?.[0];
      if (fichier && app.ajoutMedia) app.ajoutMedia = { ...app.ajoutMedia, fichier };
    };
    champ.click();
  };
  return html`
    <div class="chips-filtres" style="padding:4px 0 0" aria-label="De qui vient ce contenu ?">
      <button class="chip-filtre ${etat.provenance === "personnel" ? "actif" : ""}" @click=${() => choisir("personnel")}>Moi</button>
      <button class="chip-filtre ${etat.provenance === "enseignement" ? "actif" : ""}" @click=${() => choisir("enseignement")}>Mon prof / club</button>
      <button class="chip-filtre ${etat.provenance === "ressource" ? "actif" : ""}" @click=${() => choisir("ressource")}>Une ressource</button>
    </div>
    ${etat.provenance !== "personnel"
      ? html`<div style="margin-top:8px">
          <input class="champ-note" style="min-height:0" aria-label=${etat.provenance === "enseignement" ? "Qui l'enseigne ?" : "Source"}
                 placeholder=${etat.provenance === "enseignement" ? "Qui l'enseigne ? (ex. Club, Sensei Dupont)" : "Source (obligatoire — ex. chaîne, livre)"}
                 .value=${etat.attribution ?? ""}
                 @input=${(e: InputEvent) => (app.ajoutMedia = { ...app.ajoutMedia!, attribution: (e.target as HTMLInputElement).value })}>
        </div>`
      : nothing}
    <textarea class="champ-note" style="margin-top:8px; min-height:72px"
              placeholder="Texte — explication, points d'attention… (un média peut suffire)"
              .value=${etat.texte ?? ""}
              @input=${(e: InputEvent) => (app.ajoutMedia = { ...app.ajoutMedia!, texte: (e.target as HTMLTextAreaElement).value })}></textarea>
    ${etat.fichier ? html`<span class="joint" style="margin-top:6px">🎞 vidéo jointe (${(etat.fichier.size / 1e6).toFixed(1)} Mo)</span>` : nothing}
    <input class="champ-mini" style="margin-top:8px" inputmode="url" aria-label="Lien vidéo (YouTube ou autre)"
           placeholder="🔗 Coller un lien (YouTube…) — facultatif"
           .value=${etat.lien ?? ""}
           @input=${(e: InputEvent) => (app.ajoutMedia = { ...app.ajoutMedia!, lien: (e.target as HTMLInputElement).value })}>
    <div class="chips-filtres" style="padding:8px 0 0">
      <button class="chip-filtre" @click=${joindreFichier}>🎞 joindre une vidéo</button>
    </div>
    <div class="actions">
      <button class="bouton" @click=${() => (app.ajoutMedia = null)}>Annuler</button>
      <button class="bouton principal" ?disabled=${!pret}
        @click=${() => {
          const source = { ...(etat.fichier ? { fichier: etat.fichier } : {}), ...(etat.lien?.trim() ? { lien: etat.lien.trim() } : {}) };
          void app.ajouterMediaFiche(etat.techniqueId, source, {
            provenance: etat.provenance,
            ...(etat.attribution?.trim() ? { attribution: etat.attribution.trim() } : {}),
            ...(etat.texte?.trim() ? { texte: etat.texte.trim() } : {}),
          });
        }}>
        Ajouter
      </button>
    </div>
  `;
}

function choisirFichierVideo(app: MovensoApp, camera: boolean): void {
  const champ = document.createElement("input");
  champ.type = "file";
  champ.accept = "video/*";
  if (camera) champ.setAttribute("capture", "environment");
  champ.onchange = () => {
    const fichier = champ.files?.[0];
    if (fichier && app.ajoutMedia) app.ajoutMedia = { ...app.ajoutMedia, fichier };
  };
  champ.click();
}

function etapeContenu(app: MovensoApp): TemplateResult {
  const etat = app.ajoutMedia!;
  return html`
    <div class="choix-double">
      <button @click=${() => choisirFichierVideo(app, true)}>
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="14" height="12" rx="2"/><path d="m16 10 6-3v10l-6-3"/></svg>
        Filmer maintenant <span class="indice">caméra, hors ligne</span>
      </button>
      <button @click=${() => choisirFichierVideo(app, false)}>
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12"/><path d="m7 8 5-5 5 5"/><rect x="4" y="15" width="16" height="6" rx="2"/></svg>
        Une vidéo de l'appareil <span class="indice">stockée hors ligne</span>
      </button>
    </div>
    <div class="choix-secondaire">
      ${etat.saisieLien
        ? html`<div class="creation-discipline" style="margin-top:6px">
            <input placeholder="Coller un lien (YouTube ou autre)…" aria-label="Lien de la vidéo" autofocus
                   @keydown=${(e: KeyboardEvent) => {
                     if (e.key === "Enter") {
                       const v = (e.target as HTMLInputElement).value.trim();
                       if (v) app.ajoutMedia = { ...etat, lien: v };
                     }
                   }}>
            <button class="bouton principal"
              @click=${(e: Event) => {
                const v = (e.target as HTMLElement).parentElement!.querySelector("input")!.value.trim();
                if (v) app.ajoutMedia = { ...etat, lien: v };
              }}>OK</button>
          </div>`
        : html`<button class="action-douce" @click=${() => (app.ajoutMedia = { ...etat, saisieLien: true })}>
            🔗 Coller un lien <span>(YouTube ou autre — lecture en ligne)</span>
          </button>`}
    </div>
    <div class="actions">
      <button class="bouton" @click=${() => (app.ajoutMedia = null)}>Annuler</button>
    </div>
  `;
}

/** Les seules questions utiles (§5) : qui l'a produit, attribution si ce
 *  n'est pas moi, libellé facultatif. Jamais « à quelle technique ? ». */
function etapeInfos(app: MovensoApp): TemplateResult {
  const etat = app.ajoutMedia!;
  const choisir = (p: Provenance) =>
    (app.ajoutMedia = { ...etat, provenance: p, ...(p === "personnel" ? { attribution: "" } : {}) });
  const pret = etat.provenance !== "ressource" || (etat.attribution ?? "").trim() !== "";
  return html`
    ${etat.fichier
      ? html`<span class="joint">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
          vidéo jointe (${(etat.fichier.size / 1e6).toFixed(1)} Mo)
        </span><div style="height:10px"></div>`
      : nothing}
    ${etat.lien ? html`<span class="joint">🔗 ${etat.lien}</span><div style="height:10px"></div>` : nothing}
    <div class="chips-filtres" style="padding:4px 0 0" aria-label="Qui a produit ce média ?">
      <button class="chip-filtre ${etat.provenance === "personnel" ? "actif" : ""}" @click=${() => choisir("personnel")}>Moi</button>
      <button class="chip-filtre ${etat.provenance === "enseignement" ? "actif" : ""}" @click=${() => choisir("enseignement")}>Mon prof / club</button>
      <button class="chip-filtre ${etat.provenance === "ressource" ? "actif" : ""}" @click=${() => choisir("ressource")}>Une ressource</button>
    </div>
    ${etat.provenance !== "personnel"
      ? html`<div style="margin-top:8px">
          <input class="champ-note" style="min-height:0" aria-label=${etat.provenance === "enseignement" ? "Qui l'enseigne ?" : "Source"}
                 placeholder=${etat.provenance === "enseignement" ? "Qui l'enseigne ? (ex. Club, Sensei Dupont)" : "Source (obligatoire — ex. chaîne, livre)"}
                 .value=${etat.attribution ?? ""}
                 @input=${(e: InputEvent) => (app.ajoutMedia = { ...app.ajoutMedia!, attribution: (e.target as HTMLInputElement).value })}>
        </div>`
      : nothing}
    <div style="margin-top:8px">
      <input class="champ-note champ-libelle" style="min-height:0" aria-label="Libellé du média"
             placeholder="Libellé facultatif (ex. « vue de côté »)"
             .value=${etat.label ?? ""}
             @input=${(e: InputEvent) => (app.ajoutMedia = { ...app.ajoutMedia!, label: (e.target as HTMLInputElement).value })}>
    </div>
    <div class="actions">
      <button class="bouton" @click=${() => (app.ajoutMedia = null)}>Annuler</button>
      <button class="bouton principal" ?disabled=${!pret}
        @click=${() => {
          const source = { ...(etat.fichier ? { fichier: etat.fichier } : {}), ...(etat.lien ? { lien: etat.lien } : {}) };
          const infos = {
            provenance: etat.provenance,
            ...(etat.attribution?.trim() ? { attribution: etat.attribution.trim() } : {}),
            ...(etat.label?.trim() ? { label: etat.label.trim() } : {}),
          };
          void app.ajouterMediaFiche(etat.techniqueId, source, infos);
        }}>
        Ajouter
      </button>
    </div>
  `;
}
