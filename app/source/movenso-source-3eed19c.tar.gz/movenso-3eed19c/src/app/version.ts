/** Version de l'application, injectée au build par Vite (`define`
 *  `__APP_VERSION__`, dérivée de package.json). Hors build (tests unitaires,
 *  exécution directe), la constante n'est pas définie → repli sur "dev". */
declare const __APP_VERSION__: string;

export const VERSION: string =
  typeof __APP_VERSION__ !== "undefined" ? __APP_VERSION__ : "dev";

/** Commit court du build (D-212) — le « où » exact dans GitHub. On affiche le
 *  SHA et jamais une URL, précisément parce qu'il survit à un renommage de
 *  dépôt : celui-ci a eu lieu le 2026-08-09 (`movenso-v3` → `movenso`) sans
 *  rien changer ici (D-254). Hors build : "local". */
declare const __APP_COMMIT__: string;

export const COMMIT: string =
  typeof __APP_COMMIT__ !== "undefined" ? __APP_COMMIT__ : "local";
