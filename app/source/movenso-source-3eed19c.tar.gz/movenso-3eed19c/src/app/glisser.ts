/**
 * Réordonnancement — UN SEUL mécanisme : les boutons ▲/▼ (D-233).
 *
 * Le glisser-déposer tactile a été RETIRÉ partout (arbitrage porteur
 * 2026-08-07). Trois raisons : (1) WCAG 2.5.7 impose de toute façon une
 * alternative à pointeur unique, donc les flèches ne sont jamais optionnelles ;
 * (2) le glisser n'auto-défilait pas aux bords, donc il ne pouvait pas déplacer
 * un élément hors de la zone visible — il promettait plus qu'il ne tenait ;
 * (3) la poignée ⠿ mangeait la largeur de chaque ligne, précisément celle qui
 * manque à la trame des compositions.
 *
 * `boutonsMonterDescendre` fournit des boutons ▲/▼ explicites — utilisables au
 * doigt, au clavier et via un lecteur d'écran (TalkBack). Chaque déplacement
 * est annoncé dans une zone `aria-live`.
 */

import { html, nothing, type TemplateResult } from "lit";
import type { MovensoApp } from "./racine.ts";

export interface ReordreParGlisser {
  /** Réordonne EN MÉMOIRE (sans persister) : place `id` à l'emplacement de `cibleId`. */
  reordonner: (id: string, cibleId: string) => void;
  /** Persiste l'ordre courant (contrôle PIN inclus). */
  enregistrer: () => void;
  /** Ordre courant des identifiants — nécessaire aux déplacements d'un cran (S2.9). */
  ordre: () => string[];
  /** Nom lisible d'un élément — pour les libellés accessibles et les annonces (S2.9). */
  nom: (id: string) => string;
}

/* ---------- annonces pour lecteurs d'écran (S2.9) ---------- */

let zoneAnnonce: HTMLElement | null = null;

/** Annonce un texte aux lecteurs d'écran via une zone `aria-live` polie,
 *  invisible à l'écran. Le texte est vidé puis reposé pour être ré-annoncé
 *  même s'il est identique au précédent. */
function annoncer(texte: string): void {
  if (!zoneAnnonce || !zoneAnnonce.isConnected) {
    zoneAnnonce = document.createElement("div");
    zoneAnnonce.className = "annonce-lecteur";
    zoneAnnonce.setAttribute("role", "status");
    zoneAnnonce.setAttribute("aria-live", "polite");
    document.body.append(zoneAnnonce);
  }
  zoneAnnonce.textContent = "";
  requestAnimationFrame(() => { if (zoneAnnonce) zoneAnnonce.textContent = texte; });
}

/* ---------- déplacement d'un cran (S2.9 : clavier + boutons) ---------- */

/** Déplace `id` d'un cran (`delta` = −1 monter, +1 descendre), persiste
 *  aussitôt et annonce la nouvelle position. En butée : annonce seulement.
 *
 *  `reordonner(x, cible)` retire `x` puis l'insère À l'index de la cible : ça
 *  ne fait avancer que l'élément qui vient d'APRÈS (retirer `x` décale toute
 *  cible située plus bas d'un rang vers le haut — descendre serait un no-op).
 *  On échange donc toujours en faisant monter l'élément du dessous : monter
 *  `id` = le passer devant son voisin du dessus ; descendre `id` = faire
 *  passer son voisin du dessous devant lui. */
function deplacerDunCran(app: MovensoApp, id: string, delta: -1 | 1, opts: ReordreParGlisser): void {
  const ordre = opts.ordre();
  const i = ordre.indexOf(id);
  if (i < 0) return;
  const j = i + delta;
  if (j < 0 || j >= ordre.length) {
    annoncer(`${opts.nom(id)} est déjà en ${delta < 0 ? "première" : "dernière"} position.`);
    return;
  }
  if (delta < 0) opts.reordonner(id, ordre[j]!);
  else opts.reordonner(ordre[j]!, id);
  opts.enregistrer();
  annoncer(`${opts.nom(id)}, position ${j + 1} sur ${ordre.length}.`);
  app.requestUpdate();
}

/** Boutons ▲/▼ explicites (S2.9) — alternative au glisser, utilisable au
 *  doigt, au clavier et via TalkBack. Désactivés en butée. */
export function boutonsMonterDescendre(app: MovensoApp, id: string, opts: ReordreParGlisser): TemplateResult | typeof nothing {
  const ordre = opts.ordre();
  if (ordre.length < 2) return nothing;
  const i = ordre.indexOf(id);
  const nom = opts.nom(id);
  return html`<span class="boutons-reordre">
    <button type="button" class="bouton-icone" aria-label="Monter ${nom}" title="Monter"
      ?disabled=${i <= 0} @click=${() => deplacerDunCran(app, id, -1, opts)}>▲</button>
    <button type="button" class="bouton-icone" aria-label="Descendre ${nom}" title="Descendre"
      ?disabled=${i >= ordre.length - 1} @click=${() => deplacerDunCran(app, id, 1, opts)}>▼</button>
  </span>`;
}
