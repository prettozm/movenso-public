/**
 * ATELIER — COMMUN (S3.A10) : l'état léger et les aides partagées par les
 * écrans d'atelier (atelier-medias / -taxonomies / -reglages) — extrait
 * d'atelier.ts pour casser les cycles d'import (les modules d'écran importent
 * d'ici, jamais l'entrée atelier.ts). Comportement inchangé.
 */
import { html, type TemplateResult } from "lit";
import type { MovensoApp } from "./racine.ts";

/** État léger : quels petits formulaires de création sont ouverts (clé
 *  « discipline » ou « <discId>:familles » / « <discId>:niveaux »). */
export const creationOuverte = new Set<string>();

/** En-tête d'un encart : titre à gauche, bouton « ＋ » à droite qui ouvre/ferme
 *  le petit formulaire de création (tuning post-V3, cf. maquette). */
export function enteteEncart(titre: string, cle: string, app: MovensoApp): TemplateResult {
  const ouvert = creationOuverte.has(cle);
  // Le ＋ ouvre la création et se transforme en − pour la refermer.
  return html`<div class="encart-entete">
    <span class="titre-atelier">${titre}</span>
    <button class="bouton-plus ${ouvert ? "actif" : ""}" aria-label=${ouvert ? `Fermer la création dans ${titre}` : `Ajouter dans ${titre}`} aria-expanded=${ouvert}
      @click=${() => { ouvert ? creationOuverte.delete(cle) : creationOuverte.add(cle); app.requestUpdate(); }}>${ouvert ? "−" : "＋"}</button>
  </div>`;
}

/** Section encadrée d'un sous-écran de Plus (D-089) : une carte `carte-atelier`
 *  avec son titre — pour que chaque section soit nettement délimitée et titrée,
 *  de façon homogène sur toutes les pages de Plus. */
export function carteSection(titre: string, contenu: unknown): TemplateResult {
  return html`<div class="carte-atelier">
    <div class="encart-entete"><span class="titre-atelier">${titre}</span></div>
    ${contenu}
  </div>`;
}

export function tailleLisible(octets: number): string {
  if (octets >= 1_000_000) return `${(octets / 1_000_000).toFixed(1)} Mo`;
  return `${Math.max(1, Math.round(octets / 1000))} Ko`;
}

export const etatGestion: { requete: string; disciplineId: string | null } = { requete: "", disciplineId: null };
