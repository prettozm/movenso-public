/**
 * RELATIONS — COMMUN (S3.A10) : l'état de session, l'historique des centres et
 * les aides partagées par les vues Liste/Carte/Mindmap/Explorer — extrait de
 * relations-visuelle.ts pour casser les cycles d'import (les modules de vue
 * importent d'ici, jamais l'inverse). Comportement inchangé.
 */
import { html, nothing, svg, type TemplateResult } from "lit";
import type { Bibliotheque, Technique, RoleRelation } from "../domaine/modele.ts";
import type { RelationAffichee } from "../domaine/relations.ts";
import type { MovensoApp } from "./racine.ts";

// « mindmap » = la Carte actuelle (canevas HTML pan/zoom, D-140) ; « classique »
// = l'ancienne Mindmap radiale à grille fluide (D-135), remise en parallèle
// pour comparer les deux UX (retour porteur, 2026-07-29).
export type Vue = "liste" | "mindmap" | "classique" | "explorer";
export type Tri = "pertinence" | "alpha";

export type IntentId = "enchainer" | "preparer" | "comparer" | "defendre";
export type Etape = { id: string; note?: string; role?: RoleRelation };

/** État de session, léger (survit au recentrage via `relationCentre` côté app). */
export const etat: {
  recherche: string; vue: Vue; filtre: string | null; tri: Tri; plein: boolean;
  bienvenue: boolean;
  exIntent: IntentId | null; exChemin: Etape[]; exCompare: string | null; mmDeplie: Set<string>;
  mmMasque: Set<string>; mmCherche: boolean; carteDeplie: Set<string>; carteMasque: Set<string>; carteRoleDeplie: Set<RoleRelation>;
} = {
  recherche: "",
  vue: "liste",
  bienvenue: false, // écran de BIENVENUE réinvoqué depuis l'aide (D-180)
  filtre: null,
  tri: "pertinence",
  plein: false, // Carte : plein écran (D-138 R6/R8)
  exIntent: null, // Explorer : objectif choisi
  exChemin: [], // Explorer : parcours construit (1re étape = centre)
  exCompare: null, // Explorer : cible du face-à-face Comparer (O2, D-198)
  mmDeplie: new Set(), // Mindmap : (héritage) — non utilisé par le gabarit fixe
  mmMasque: new Set(), // Mindmap : slots masqués via les chips légende/filtre (D-148)
  mmCherche: false, // Mindmap : recherche compacte ouverte (icône loupe, D-148)
  carteDeplie: new Set(), // Carte : nœuds dépliés (multi-niveaux, D-158)
  carteMasque: new Set(), // Carte : libellés de familles masqués via les chips légende/filtre (D-159)
  carteRoleDeplie: new Set(), // Carte : rôles dont le « +N autres » a été déplié SUR PLACE (D-160)
};

/** Historique des centres visités DANS Relations (R4, D-137) — pile de session
 *  (état module ; le centre COURANT, lui, persiste via R3). Sert le fil
 *  d'Ariane : toucher un maillon y ramène, « Revenir » dépile — JAMAIS de
 *  retour à la Bibliothèque. */
export let historique: string[] = []; // liaison vivante — LECTURE seule hors de ce module

/** File « avant » (→) : les centres quittés en reculant — vidée par toute
 *  NOUVELLE navigation (pousser, recentrage externe). Liaison vivante,
 *  lecture seule hors de ce module. */
export let futur: string[] = [];

/** Recentre en empilant (recentrage : nœud Mindmap, ligne Liste, candidat
 *  Explorer, résultat de recherche, point de départ). Si la cible est déjà dans
 *  la pile, on y revient (troncature) plutôt que de créer un doublon. */
export function pousser(app: MovensoApp, id: string): void {
  const idx = historique.lastIndexOf(id);
  historique = idx >= 0 ? historique.slice(0, idx + 1) : [...historique, id];
  futur = []; // toute nouvelle navigation invalide le « avant »
  app.recentrerRelations(id);
}

/** ← Revenir : dépile d'un cran (jamais en deçà du premier centre) — le
 *  centre quitté passe dans `futur` pour que → puisse y revenir. */
export function reculer(app: MovensoApp): void {
  if (historique.length <= 1) return;
  futur = [historique[historique.length - 1]!, ...futur];
  historique = historique.slice(0, -1);
  app.recentrerRelations(historique[historique.length - 1]!);
}

/** → Suivant : rejoue le centre quitté par ← (vidé par toute autre navigation). */
export function avancer(app: MovensoApp): void {
  const suivant = futur[0];
  if (!suivant) return;
  futur = futur.slice(1);
  historique = [...historique, suivant];
  app.recentrerRelations(suivant);
}

/** Réconcilie la pile avec le centre résolu au rendu : gère l'entrée EXTERNE
 *  (ex. « Voir en graphe » depuis une fiche, centre mémorisé au démarrage) qui
 *  fixe le centre sans passer par `pousser`. Pur ajustement de cache module. */
export function synchroniserHistorique(centreId: string): void {
  if (historique.length === 0) { historique = [centreId]; return; }
  if (historique[historique.length - 1] === centreId) return; // ← / → passent ici sans rien changer
  const idx = historique.lastIndexOf(centreId);
  historique = idx >= 0 ? historique.slice(0, idx + 1) : [...historique, centreId];
  futur = []; // recentrage EXTERNE (fiche, démarrage) : le « avant » ne vaut plus
}

export function nomFamille(b: Bibliotheque, t: Technique): string {
  return t.familleId
    ? b.disciplines.find((d) => d.id === t.disciplineId)?.familles.find((f) => f.id === t.familleId)?.nom ?? ""
    : "";
}

/** Classe couleur d'un lien d'après son RÔLE sémantique (D-136) : le placement
 *  et la couleur suivent le rôle (avant/après/…), jamais le texte du libellé. */
export function classeRole(role: RoleRelation): string {
  return `role--${role}`;
}

/** Pastille ⚠️ si la technique porte une alerte (D-136) — visible en navigation. */
export function pastilleAlerte(app: MovensoApp, id: string): TemplateResult {
  const a = app.technique(id)?.alertes?.[0];
  return a ? html`<span class="rel-alerte" title=${a.libelle}>⚠️</span>` : (nothing as unknown as TemplateResult);
}

/** Petite icône par rôle (cohérente avec la couleur). Le fragment interne DOIT
 *  passer par le tag `svg` de Lit (D-150) : avec `html`, le <path> naissait dans
 *  le namespace HTML et ne se dessinait jamais — d'où des icônes invisibles
 *  (badges/labels/chips en « carrés vides ») depuis D-136. */
export function iconeRole(role: RoleRelation): TemplateResult {
  const s = (d: string) =>
    html`<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">${svg`<path d=${d}></path>`}</svg>`;
  switch (role) {
    case "before": return s("M20 12H6M11 6l-6 6 6 6"); // ← amène
    case "after": return s("M4 12h14M13 6l6 6-6 6"); // → suite
    case "opposition": return s("M12 3l7 3v5c0 4.2-2.9 7.7-7 8.9C7.9 18.7 5 15.2 5 11V6z"); // bouclier
    case "peer": return s("M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 17l-5.2 2.7 1-5.8L3.5 9.7l5.9-.9z"); // étoile
    case "context": return s("M4 5h11a3 3 0 013 3v11M4 5v11a3 3 0 003 3h12M4 5l4 3"); // signet
    default: return s("M4 12h14M13 6l6 6-6 6");
  }
}

/** Ordre d'affichage des rôles (ligne de temps : avant → après → opposition → pair → contexte). */
export const ORDRE_ROLE: RoleRelation[] = ["before", "after", "opposition", "peer", "context"];

/** Groupe les liaisons par libellé (= rôle affiché), triées par RÔLE puis libellé. */
export function grouper(liaisons: RelationAffichee[]): { libelle: string; role: RoleRelation; liste: RelationAffichee[] }[] {
  const parLibelle = new Map<string, RelationAffichee[]>();
  for (const l of liaisons) parLibelle.set(l.libelle, [...(parLibelle.get(l.libelle) ?? []), l]);
  return [...parLibelle.entries()]
    .map(([libelle, liste]) => ({ libelle, role: liste[0]!.role, liste }))
    .sort((a, z) => (ORDRE_ROLE.indexOf(a.role) - ORDRE_ROLE.indexOf(z.role)) || a.libelle.localeCompare(z.libelle, "fr"));
}

/** Tri interne d'un groupe : pertinence (priorité éditoriale) ou alphabétique. */
export function trier(app: MovensoApp, liste: RelationAffichee[]): RelationAffichee[] {
  const nom = (l: RelationAffichee) => app.technique(l.techniqueId)?.nom ?? "";
  return [...liste].map((l, i) => ({ l, i })).sort((a, z) => {
    if (etat.tri === "alpha") return nom(a.l).localeCompare(nom(z.l), "fr") || a.i - z.i;
    return (a.l.priorite ?? Infinity) - (z.l.priorite ?? Infinity) || a.i - z.i;
  }).map((x) => x.l);
}

/** ---- Vue CARTE (D-140, retour de la Mindmap graphique + pan/zoom) : hub AU
 *  CENTRE, cartes-vignettes posées par RÔLE autour (avant à gauche, après à
 *  droite, pair en haut, opposition en bas, contexte en bas-gauche), reliées au
 *  hub par des courbes de Bézier colorées. Le pan / zoom / pincement agit par
 *  TRANSFORM CSS sur la scène : les cartes gardent leurs vraies vignettes <img>
 *  (la version 100 % SVG de D-138 avait sacrifié cette richesse et devenait
 *  illisible par défaut). Le fit reste LISIBLE — plancher de zoom `K_FIT_MIN`,
 *  scène centrée sur le hub — ; au-delà, on déborde et on se déplace. Toucher une
 *  carte recentre (historique R4) ; le hub ouvre la fiche ; « +N » bascule dans
 *  la Liste ; double-toucher = fit ; bouton plein écran. ---- */
export function couleurRole(role: RoleRelation): string {
  switch (role) {
    case "before": return "var(--state-success)"; // amène = VERT (aligné Mindmap/proto, D-158)
    case "after": return "var(--state-info)"; // suite = BLEU
    case "opposition": return "#9B72D0";
    case "peer": return "var(--accent)";
    case "context": return "#C9971E"; // or/jaune (fondamentaux) — distinct des similarités (D-147)
    default: return "var(--sourdine)";
  }
}
