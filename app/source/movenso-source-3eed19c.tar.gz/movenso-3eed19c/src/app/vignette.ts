/**
 * Vignette d'une technique (module dédié, S3.A10 — extrait de vues.ts pour
 * casser le cycle vues ↔ relations : les vues Relations l'importent d'ici,
 * sans dépendre de vues.ts). Comportement inchangé.
 */
import { html, nothing, type TemplateResult } from "lit";
import type { Media, Technique } from "../domaine/modele.ts";
import { sourceDe } from "../domaine/modele.ts";
import { idYoutubeValide } from "../securite/liens.ts";
import type { MovensoApp } from "./racine.ts";

/** Illustration de la FAMILLE d'une technique (schéma 5) — le repli quand la
 *  technique n'a pas la sienne. Lecture seule : la famille est le seul lieu
 *  d'écriture de cette image. */
export function imageDeFamille(app: MovensoApp, t: Technique): string | null {
  if (!t.familleId) return null;
  const d = app.bibliotheque?.disciplines.find((x) => x.id === t.disciplineId);
  const c = d?.familles.find((f) => f.id === t.familleId)?.couverture;
  return c?.type === "image" ? c.dataUrl : null;
}

/** Vignette d'une technique : miniature YouTube si média plateforme, sinon
 *  initiale sur fond calme. Hors ligne, l'image échoue proprement (placeholder). */
export function vignetteTechnique(app: MovensoApp, t: Technique, sourcePreferee?: string | null): TemplateResult {
  const initiale = html`<span class="vignette-initiale">${t.nomTraditionnel?.charAt(0) ?? t.nom.charAt(0)}</span>`;
  const cacher = (e: Event) => ((e.target as HTMLElement).style.display = "none");
  // Couverture personnalisée (D-083) : une image importée l'emporte sur tout ;
  // un renvoi vers un média réutilise sa miniature (YouTube pour l'instant).
  if (t.couverture?.type === "image")
    return html`<span class="vignette">${initiale}<img loading="lazy" src=${t.couverture.dataUrl} alt="" @error=${cacher}></span>`;
  // À défaut, l'image de sa FAMILLE (schéma 5) — DÉRIVÉE, jamais recopiée sur
  // la technique. C'est le filet qui évite une fiche nue, et il porte un titre
  // générique : une carte de famille assumée, pas une photo qui prétendrait
  // être cette technique-là (D-244).
  const familleImage = imageDeFamille(app, t);
  if (familleImage)
    return html`<span class="vignette">${initiale}<img loading="lazy" src=${familleImage} alt="" @error=${cacher}></span>`;
  let forcee: Media | undefined;
  if (t.couverture?.type === "media") {
    const cibleId = t.couverture.mediaId;
    forcee = app.bibliotheque!.contributions.filter((c) => c.techniqueId === t.id).flatMap((c) => c.medias).find((m) => m.id === cibleId);
  }
  const candidats = app
    .bibliotheque!.contributions.filter((c) => c.techniqueId === t.id && c.provenance !== "personnel")
    .flatMap((c) => c.medias.map((media) => ({ media, source: sourceDe(c) })))
    .filter((x) => x.media.type === "plateforme" && x.media.service === "youtube");
  const media = forcee ?? (sourcePreferee ? candidats.find((x) => x.source === sourcePreferee)?.media : undefined) ?? candidats[0]?.media;
  return html`<span class="vignette">
    ${initiale}
    ${(app.preferences.vignettesDistantes ?? false) && media && media.type === "plateforme" && media.service === "youtube" && idYoutubeValide(media.ref)
      ? html`<img loading="lazy" src="https://img.youtube.com/vi/${media.ref}/mqdefault.jpg" alt="" @error=${cacher}>`
      : nothing}
  </span>`;
}

/** Pastille couleur d'un niveau (ceinture une ou deux couleurs). Partagée
 *  grille / favoris / fiche / Explorer (S3.D3-O5) — vit ici pour rester
 *  importable sans cycle. */
export function pastilleNiveau(n: { nom: string; couleur?: string; couleur2?: string }): TemplateResult {
  const fond = n.couleur
    ? n.couleur2
      ? `linear-gradient(90deg, ${n.couleur} 50%, ${n.couleur2} 50%)`
      : n.couleur
    : "var(--trait)";
  return html`<span class="puce-niveau" style="background:${fond}" title=${n.nom}></span>`;
}
