/** <movenso-video-locale> — lit une vidéo capturée depuis OPFS (URL objet,
 *  flux disque, jamais chargée en mémoire). Absente → message dégradé. */

import { LitElement, html, nothing } from "lit";
import type { MovensoApp } from "./racine.ts";

export class MovensoVideoLocale extends LitElement {
  static properties = { app: { attribute: false }, mediaId: { attribute: false }, url: { state: true } };

  // cf. racine.ts : initialisation dans le constructeur, jamais en champ de classe.
  declare app: MovensoApp;
  declare mediaId: string;
  declare url: string | null | undefined; // undefined = chargement, null = introuvable

  constructor() {
    super();
    this.mediaId = "";
    this.url = undefined;
  }

  override createRenderRoot() {
    return this;
  }

  override connectedCallback(): void {
    super.connectedCallback();
    void this.app.stockage.urlVideo(this.mediaId).then((u) => (this.url = u));
  }

  override disconnectedCallback(): void {
    super.disconnectedCallback();
    if (this.url) URL.revokeObjectURL(this.url);
  }

  override render() {
    if (this.url === undefined) return nothing;
    if (this.url === null)
      return html`<div class="video-absente" style="font-size:12.5px;color:var(--sourdine)">
        Vidéo introuvable sur cet appareil.
        <button class="action-douce" style="margin-top:4px" @click=${() => this.app.ouvrirPlusSection("medias")}>
          Vérifier <span>(Plus — Médias)</span>
        </button>
      </div>`;
    // Un seul lecteur actif à la fois (NR-003-002) : lancer cette vidéo met
    // en pause les autres et replie les lecteurs en ligne dépliés.
    return html`<div class="media-video"><video src=${this.url} controls playsinline preload="metadata"
      @play=${(e: Event) => {
        document.querySelectorAll("video").forEach((v) => { if (v !== e.target) v.pause(); });
        if (this.app.mediasDeplies.size) {
          this.app.mediasDeplies = new Set();
          this.app.requestUpdate();
        }
      }}></video></div>`;
  }
}

customElements.define("movenso-video-locale", MovensoVideoLocale);
