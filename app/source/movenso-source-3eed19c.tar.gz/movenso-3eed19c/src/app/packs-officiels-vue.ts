/**
 * Écran « Packs officiels » (B2, D-211) — VUE À DONNÉES CIBLÉES (règle
 * d'architecture conventions §13/D-204 : pas de MovensoApp ici) : le catalogue
 * publié sur le site, chaque pack installable via le circuit d'import normal.
 * États honnêtes : chargement, catalogue injoignable (hors ligne, dev, APK
 * avant ouverture du CSP), catalogue vide.
 */
import { html, type TemplateResult } from "lit";
import type { PackOfficiel } from "./services/packs-officiels.ts";
import { carteSection } from "./atelier-commun.ts";

export function ecranPacksOfficiels(
  catalogue: PackOfficiel[] | "chargement" | "indisponible" | null,
  agir: { installer: (p: PackOfficiel) => void; recharger: () => void },
): TemplateResult {
  if (catalogue === null || catalogue === "chargement")
    return carteSection("Packs officiels", html`<p class="fil-vide" style="padding:6px 0">Chargement du catalogue…</p>`);
  if (catalogue === "indisponible")
    return carteSection("Packs officiels", html`
      <p class="fil-vide" style="padding:6px 0 10px">
        Catalogue injoignable — il vit sur le site public de Movenso et demande
        une connexion. Tu peux aussi importer un fichier .movpack à la main
        (Plus › Importer un pack).
      </p>
      <button class="action-douce" @click=${agir.recharger}>Réessayer</button>
    `);
  if (catalogue.length === 0)
    return carteSection("Packs officiels", html`<p class="fil-vide" style="padding:6px 0">Aucun pack publié pour l'instant.</p>`);
  return carteSection("Packs officiels", html`
    <p class="details" style="padding:0 2px 8px">Chaque pack s'installe après un
      rapport d'import — rien ne s'écrit sans ton accord, et tout se retire.</p>
    ${catalogue.map((p) => html`
      <div class="pack-officiel">
        <div class="pack-officiel-entete">
          <span class="pack-officiel-nom">${p.title}</span>
          <span class="pack-officiel-version">v${p.version}</span>
        </div>
        ${p.itemCount ? html`<div class="pack-officiel-meta">${p.itemCount}</div>` : ""}
        ${p.summary ? html`<p class="pack-officiel-resume">${p.summary}</p>` : ""}
        <button class="chip-filtre pack-officiel-installer" @click=${() => agir.installer(p)}>⤓ Télécharger et importer</button>
      </div>
    `)}
  `);
}
