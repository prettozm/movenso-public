/**
 * RELATIONS — VUE CARTE (S3.A4, tranche 1 — extraite de relations-visuelle.ts,
 * code déménagé tel quel) : mindmap HTML pannable/zoomable (D-140→D-160) —
 * LAYOUT (placement par rôle, séparation sans chevauchement, boîte englobante),
 * TRANSFORM (fit lisible K_FIT, zoom autour d'un point), GESTES (pan au seuil,
 * pincement, double-toucher) et RENDU (cartes-vignettes, dépliage multi-niveaux,
 * chips légende/filtre, plein écran).
 */

import { html, nothing, svg, type TemplateResult } from "lit";
import { ref } from "lit/directives/ref.js";
import type { Bibliotheque, Technique } from "../domaine/modele.ts";
import { vignetteTechnique } from "./vignette.ts";
import { etat, pousser, nomFamille, classeRole, iconeRole, grouper, trier, couleurRole, pastilleAlerte, ORDRE_ROLE } from "./relations-commun.ts";
import { relationsPourFiche, type RelationAffichee } from "../domaine/relations.ts";
import type { RoleRelation } from "../domaine/modele.ts";

// Géométrie de la scène (pixels « scène », avant transform). Cartes assez
// grandes pour une vignette 16/10 + nom + raison ; écarts pensés pour ne pas se
// chevaucher aux tailles usuelles.
const CARW = 176, CARH = 150, HUBW = 208, HUBH = 168;

const COLX = 360, ROWY = 330, GAPV = 168, GAPH = 210; // écarts colonne / rangée

const CAP_CARTE = 4; // cartes par rôle avant regroupement « +N »
const MARGE = 48; // marge de scène autour du contenu
const K_MIN = 0.3, K_MAX = 2.4; // bornes de zoom (gestes)

/** Ancres de placement par rôle (centre = origine 0,0). */
const ANCRE_ROLE: Record<RoleRelation, { axe: "v" | "h"; ax: number; ay: number }> = {
  before: { axe: "v", ax: -COLX, ay: 0 },
  after: { axe: "v", ax: COLX, ay: 0 },
  peer: { axe: "h", ax: 0, ay: -ROWY },
  opposition: { axe: "h", ax: 0, ay: ROWY },
  context: { axe: "v", ax: -COLX, ay: ROWY },
};

// Dépliage multi-niveaux (D-158) : garde-fous anti « boule de poils ».
const EXP_ENFANTS = 4; // enfants max ajoutés par dépliage (les plus prioritaires)
const EXP_D = 265; // distance parent → enfants (dans l'axe opposé au hub)
const MAX_NOEUDS = 40; // plafond global de cartes visibles

type NoeudCarte = {
  x: number; y: number; w: number; h: number; // centre + taille, hub à l'origine
  nom: string; fam: string; role: RoleRelation | null;
  centre?: boolean; id?: string; plus?: number; absente?: boolean;
  note?: string; alerte?: string;
  /** Profondeur (D-158) : 0 = hub, 1 = relations directes, 2+ = déplié. */
  niveau?: number;
  /** Nombre de liens ENCORE INVISIBLES de ce nœud (badge « +n » de dépliage). */
  depl?: number;
  /** true : ce nœud est actuellement déplié (badge « − »). */
  deplie?: boolean;
};
import type { MovensoApp } from "./racine.ts";

const K_FIT_MIN = 0.6, K_FIT_MAX = 1; // le fit reste lisible et ne grossit jamais

/** true tant qu'un geste vient de PANORAMIQUER / zoomer (déplacement > seuil) :
 *  sert à ne pas recentrer sur le clic qui suit un glisser. */
let carteAPanne = false;

function placerNoeud(anc: { axe: "v" | "h"; ax: number; ay: number }, i: number, total: number): { x: number; y: number } {
  return anc.axe === "v"
    ? { x: anc.ax, y: anc.ay - ((total - 1) * GAPV) / 2 + i * GAPV }
    : { x: anc.ax - ((total - 1) * GAPH) / 2 + i * GAPH, y: anc.ay };
}

/** Courbe de Bézier hub↔carte ; horizontale pour avant/après (ligne de temps),
 *  verticale sinon. Coordonnées « scène » (déjà décalées, ≥ 0). */
function courbeCarte(c: NoeudCarte, n: NoeudCarte, role: RoleRelation): string {
  if (role === "before" || role === "after") {
    const x1 = c.x + (n.x < c.x ? -c.w / 2 : c.w / 2), y1 = c.y;
    const x2 = n.x + (n.x < c.x ? n.w / 2 : -n.w / 2), y2 = n.y;
    const mx = (x1 + x2) / 2;
    return `M${x1} ${y1} C ${mx} ${y1} ${mx} ${y2} ${x2} ${y2}`;
  }
  const y1 = c.y + (n.y < c.y ? -c.h / 2 : c.h / 2), x1 = c.x;
  const y2 = n.y + (n.y < c.y ? n.h / 2 : -n.h / 2), x2 = n.x;
  const my = (y1 + y2) / 2;
  return `M${x1} ${y1} C ${x1} ${my} ${x2} ${my} ${x2} ${y2}`;
}

/** Hauteur d'une carte selon sa raison (D-159/D-160) : le texte ne se tronque
 *  JAMAIS — la carte grandit autant que nécessaire (estimation prudente :
 *  ≈22 caractères par ligne à cette largeur, plafond large à 8 lignes). */
function hauteurCarte(note: string | undefined): number {
  if (!note) return CARH;
  return CARH + Math.min(8, Math.ceil(note.length / 22)) * 13;
}

/** Interdiction de chevauchement (D-159, durci D-160) : relaxation SYMÉTRIQUE —
 *  deux cartes qui se recouvrent s'écartent chacune de la moitié de la
 *  pénétration le long de l'axe de moindre recouvrement (seul le hub est fixe :
 *  l'autre carte prend alors tout l'écart). L'écartement symétrique converge là
 *  où « une seule bouge » oscillait entre deux voisins concurrents. */
function separerNoeuds(noeuds: NoeudCarte[]): void {
  const M = 16; // marge minimale entre cartes
  for (let iter = 0; iter < 120; iter++) {
    let bouge = false;
    for (let i = 0; i < noeuds.length; i++) {
      for (let j = i + 1; j < noeuds.length; j++) {
        const a = noeuds[i]!, c = noeuds[j]!;
        const dx = c.x - a.x, dy = c.y - a.y;
        const px = (a.w + c.w) / 2 + M - Math.abs(dx);
        const py = (a.h + c.h) / 2 + M - Math.abs(dy);
        if (px <= 0 || py <= 0) continue;
        const axeX = px < py;
        const signe = axeX ? Math.sign(dx || 1) : Math.sign(dy || 1);
        const pen = axeX ? px : py;
        const depA = a.centre ? 0 : c.centre ? pen : pen / 2;
        const depC = c.centre ? 0 : a.centre ? pen : pen / 2;
        if (axeX) { a.x -= signe * depA; c.x += signe * depC; }
        else { a.y -= signe * depA; c.y += signe * depC; }
        bouge = true;
      }
    }
    if (!bouge) break;
  }
}

/** Pose le graphe (hub + cartes par rôle + arêtes) en coordonnées « scène »
 *  positives, et renvoie la taille de scène + le centre du hub (pour le fit).
 *  Les nœuds DÉPLIÉS (`etat.carteDeplie`, D-158) reçoivent leurs voisins les
 *  plus prioritaires autour d'eux, dans l'axe opposé au hub ; un voisin déjà
 *  visible n'est JAMAIS dupliqué — seule l'arête est tracée vers l'existant. */
function poserCarte(app: MovensoApp, b: Bibliotheque, centre: Technique, liaisons: RelationAffichee[]): {
  noeuds: NoeudCarte[]; aretes: { d: string; role: RoleRelation }[];
  sceneW: number; sceneH: number; hubX: number; hubY: number;
} {
  const brut: NoeudCarte[] = [];
  const parId = new Map<string, NoeudCarte>();
  const C: NoeudCarte = { x: 0, y: 0, w: HUBW, h: HUBH, centre: true, role: null, niveau: 0, nom: centre.nom, fam: nomFamille(b, centre), id: centre.id };
  const alC = app.technique(centre.id)?.alertes?.[0]?.libelle;
  if (alC) C.alerte = alC;
  brut.push(C);
  parId.set(centre.id, C);

  const parRole = new Map<RoleRelation, RelationAffichee[]>();
  for (const l of liaisons) parRole.set(l.role, [...(parRole.get(l.role) ?? []), l]);

  for (const role of ORDRE_ROLE) {
    const liste0 = parRole.get(role);
    if (!liste0 || liste0.length === 0) continue;
    const liste = trier(app, liste0);
    // « +N autres » déplié (D-160) : le rôle montre TOUTES ses cartes sur place.
    const cap = etat.carteRoleDeplie.has(role) ? Infinity : CAP_CARTE;
    const trop = liste.length > cap;
    const items = trop ? liste.slice(0, cap - 1) : liste;
    const reste = liste.length - items.length;
    const total = items.length + (reste > 0 ? 1 : 0);
    const anc = ANCRE_ROLE[role];
    items.forEach((l, i) => {
      const t = app.technique(l.techniqueId);
      const p = placerNoeud(anc, i, total);
      const n: NoeudCarte = { x: p.x, y: p.y, w: CARW, h: hauteurCarte(l.note), role, niveau: 1, id: l.techniqueId, nom: t?.nom ?? "(absente)", fam: t ? nomFamille(b, t) : "", absente: !l.presente || !t };
      if (l.note !== undefined) n.note = l.note;
      const al = t?.alertes?.[0]?.libelle;
      if (al) n.alerte = al;
      brut.push(n);
      if (n.id && !n.absente && !parId.has(n.id)) parId.set(n.id, n);
    });
    if (reste > 0) {
      const p = placerNoeud(anc, items.length, total);
      brut.push({ x: p.x, y: p.y, w: CARW, h: CARH, role, plus: reste, nom: `+${reste} autres`, fam: "" });
    }
  }

  // Dépliage (D-158) : les voisins des nœuds dépliés, placés dans l'axe qui
  // s'éloigne du hub, ordonnés par priorité (D-134). Arêtes supplémentaires
  // parent→enfant, y compris vers un nœud déjà visible (jamais dupliqué).
  const extra: { de: NoeudCarte; vers: NoeudCarte; role: RoleRelation }[] = [];
  for (const idDeplie of etat.carteDeplie) {
    const parent = parId.get(idDeplie);
    if (!parent) continue;
    parent.deplie = true;
    const voisins = trier(app, relationsPourFiche(b, idDeplie).filter((l) => l.presente && !etat.carteMasque.has(l.libelle)));
    const nouveaux = voisins.filter((l) => !parId.has(l.techniqueId));
    const places = nouveaux.slice(0, Math.max(0, Math.min(EXP_ENFANTS, MAX_NOEUDS - brut.length)));
    const dist = Math.hypot(parent.x, parent.y) || 1;
    const ux = parent.x / dist, uy = parent.y / dist; // axe hub → parent
    const px = -uy, py = ux; // perpendiculaire
    const pas = Math.abs(px) * (CARW + 34) + Math.abs(py) * (CARH + 40);
    places.forEach((l, i) => {
      const t = app.technique(l.techniqueId);
      if (!t) return;
      const off = (i - (places.length - 1) / 2) * pas;
      const n: NoeudCarte = {
        x: parent.x + ux * EXP_D + px * off, y: parent.y + uy * EXP_D + py * off,
        w: CARW, h: hauteurCarte(l.note), role: l.role, niveau: (parent.niveau ?? 1) + 1,
        id: l.techniqueId, nom: t.nom, fam: nomFamille(b, t),
      };
      if (l.note !== undefined) n.note = l.note;
      const al = t.alertes?.[0]?.libelle;
      if (al) n.alerte = al;
      brut.push(n);
      parId.set(n.id!, n);
      extra.push({ de: parent, vers: n, role: l.role });
    });
    // Voisins DÉJÀ visibles : l'arête seulement (le graphe se referme).
    for (const l of voisins) {
      const existant = parId.get(l.techniqueId);
      if (existant && existant !== parent && !places.some((x) => x.techniqueId === l.techniqueId)) {
        extra.push({ de: parent, vers: existant, role: l.role });
      }
    }
  }
  // Badge « +n » : liens encore invisibles de chaque nœud visible (id réel).
  for (const n of brut) {
    if (!n.id || n.absente || n.centre) continue;
    n.depl = relationsPourFiche(b, n.id).filter((l) => l.presente && !parId.has(l.techniqueId) && !etat.carteMasque.has(l.libelle)).length;
  }

  separerNoeuds(brut); // interdiction de chevauchement (D-159)

  // Boîte de contenu → décalage pour des coordonnées « scène » positives.
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const n of brut) {
    minX = Math.min(minX, n.x - n.w / 2); maxX = Math.max(maxX, n.x + n.w / 2);
    minY = Math.min(minY, n.y - n.h / 2); maxY = Math.max(maxY, n.y + n.h / 2);
  }
  const sx = MARGE - minX, sy = MARGE - minY;
  const decale = new Map<NoeudCarte, NoeudCarte>();
  const noeuds = brut.map((n) => { const d = { ...n, x: n.x + sx, y: n.y + sy }; decale.set(n, d); return d; });
  const hub = noeuds[0]!;
  const aretes: { d: string; role: RoleRelation }[] = [];
  for (let i = 1; i < noeuds.length; i++) {
    const n = noeuds[i]!;
    if (n.role && (n.niveau ?? 1) === 1 || n.plus) aretes.push({ d: courbeCarte(hub, n, n.role ?? "peer"), role: n.role ?? "peer" });
  }
  for (const e of extra) {
    const de = decale.get(e.de)!, vers = decale.get(e.vers)!;
    aretes.push({ d: courbeCarte(de, vers, e.role), role: e.role });
  }
  return {
    noeuds, aretes,
    sceneW: maxX - minX + 2 * MARGE, sceneH: maxY - minY + 2 * MARGE,
    hubX: hub.x, hubY: hub.y,
  };
}

// Transform courant de la scène (persiste entre rendus) + technique sur
// laquelle le fit a été calculé (refit au changement de centre / plein écran).
const carteVue = { tx: 0, ty: 0, k: 1, fitId: "" };

let carteScene: HTMLElement | null = null;

let carteViewport: HTMLElement | null = null;

let carteBoite = { w: 1, h: 1, hubX: 0, hubY: 0 };

function appliquerTransforme(): void {
  if (carteScene) carteScene.style.transform = `translate(${carteVue.tx}px, ${carteVue.ty}px) scale(${carteVue.k})`;
}

/** Recadre : zoom lisible (borné) et scène centrée sur le hub. */
function fitCarte(): void {
  if (!carteViewport) return;
  const r = carteViewport.getBoundingClientRect();
  if (!r.width || !r.height) return;
  const k = Math.max(K_FIT_MIN, Math.min(K_FIT_MAX, Math.min(r.width / carteBoite.w, r.height / carteBoite.h)));
  carteVue.k = k;
  carteVue.tx = r.width / 2 - carteBoite.hubX * k;
  carteVue.ty = r.height / 2 - carteBoite.hubY * k;
  appliquerTransforme();
}

/** Zoom autour d'un point du viewport (coord écran), facteur f, k borné. */
function zoomAutour(cx: number, cy: number, f: number): void {
  if (!carteViewport) return;
  const r = carteViewport.getBoundingClientRect();
  const px = cx - r.left, py = cy - r.top;
  const nk = Math.max(K_MIN, Math.min(K_MAX, carteVue.k * f));
  const sx = (px - carteVue.tx) / carteVue.k, sy = (py - carteVue.ty) / carteVue.k;
  carteVue.k = nk;
  carteVue.tx = px - sx * nk;
  carteVue.ty = py - sy * nk;
  appliquerTransforme();
}

function zoomBouton(f: number): void {
  if (!carteViewport) return;
  const r = carteViewport.getBoundingClientRect();
  zoomAutour(r.left + r.width / 2, r.top + r.height / 2, f);
}

function distancePts(pts: Map<number, { x: number; y: number }>): number {
  const [a, z] = [...pts.values()];
  return a && z ? Math.hypot(a.x - z.x, a.y - z.y) : 0;
}

function milieuPts(pts: Map<number, { x: number; y: number }>): { x: number; y: number } {
  const [a, z] = [...pts.values()];
  return a && z ? { x: (a.x + z.x) / 2, y: (a.y + z.y) / 2 } : { x: 0, y: 0 };
}

/** Installe pan (1 doigt / souris), pincement (2 doigts), zoom molette et
 *  double-toucher = fit sur le viewport (une seule fois par élément). */
function installerGestesCarte(vue: HTMLElement): void {
  const pts = new Map<number, { x: number; y: number }>();
  let pan: { x: number; y: number } | null = null;
  let pinch: { dist: number } | null = null;
  let dernierTap = 0;

  vue.addEventListener("pointerdown", (e) => {
    carteAPanne = false;
    // PAS de capture ici (D-160) : capturer au pointerdown retargettait le
    // `click` vers le viewport — cartes, badges et « +N » ne recevaient JAMAIS
    // leur clic. La capture n'arrive qu'au franchissement du seuil de
    // glissement (dans pointermove) : avant, le clic circule normalement.
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 1) { pan = { x: e.clientX, y: e.clientY }; pinch = null; }
    else if (pts.size === 2) { pan = null; pinch = { dist: distancePts(pts) }; }
    vue.classList.add("grab");
  });
  vue.addEventListener("pointermove", (e) => {
    if (!pts.has(e.pointerId)) return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size >= 2 && pinch) {
      const d = distancePts(pts), m = milieuPts(pts);
      if (pinch.dist > 0) zoomAutour(m.x, m.y, d / pinch.dist);
      pinch.dist = d;
      carteAPanne = true;
    } else if (pan) {
      const dx = e.clientX - pan.x, dy = e.clientY - pan.y;
      if (!carteAPanne && Math.abs(dx) + Math.abs(dy) > 6) {
        carteAPanne = true; // seuil franchi : c'est un pan — on capture MAINTENANT
        try { vue.setPointerCapture(e.pointerId); } catch { /* best-effort */ }
      }
      carteVue.tx += dx; carteVue.ty += dy;
      pan = { x: e.clientX, y: e.clientY };
      appliquerTransforme();
    }
  });
  const fin = (e: PointerEvent) => {
    pts.delete(e.pointerId);
    try { vue.releasePointerCapture(e.pointerId); } catch { /* best-effort */ }
    if (pts.size === 1) { const [p] = [...pts.values()]; pan = p ? { x: p.x, y: p.y } : null; pinch = null; }
    else if (pts.size === 0) { pan = null; pinch = null; vue.classList.remove("grab"); }
  };
  vue.addEventListener("pointerup", fin);
  vue.addEventListener("pointercancel", fin);
  vue.addEventListener("wheel", (e) => { e.preventDefault(); zoomAutour(e.clientX, e.clientY, e.deltaY > 0 ? 0.9 : 1.11); }, { passive: false });
  vue.addEventListener("dblclick", () => fitCarte());
  vue.addEventListener("pointerup", (e) => {
    if (e.pointerType !== "touch") return;
    const t = Date.now();
    if (t - dernierTap < 320) fitCarte();
    dernierTap = t;
  });
}

/** Rendu HTML d'une carte-vignette de la scène (positionnée en absolu). */
function carteNoeud(app: MovensoApp, n: NoeudCarte): TemplateResult {
  const style = `left:${n.x - n.w / 2}px; top:${n.y - n.h / 2}px; width:${n.w}px; height:${n.h}px`;
  const alerte = n.alerte ? html`<span class="rel-alerte" title=${n.alerte}>⚠️</span>` : nothing;
  if (n.centre && n.id) {
    const t = app.technique(n.id);
    return html`<button class="rel-carte-carte hub" style=${style} @click=${() => { if (!carteAPanne) app.ouvrirFiche(n.id!); }} title="Ouvrir la fiche">
      <span class="rel-carte-media">${t ? vignetteTechnique(app, t) : nothing}</span>
      <span class="rel-carte-nom">${n.nom}${alerte}</span>
      <span class="rel-carte-voir">Ouvrir la fiche ›</span>
    </button>`;
  }
  if (n.plus && n.role) {
    // D-160 : « +N autres » se déplie SUR PLACE dans la Carte (fini le renvoi
    // vers la Liste) — le rôle montre alors toutes ses cartes.
    return html`<button class="rel-carte-carte plus ${classeRole(n.role)}" style=${style}
      @click=${() => { if (!carteAPanne && n.role) { etat.carteRoleDeplie.add(n.role); app.requestUpdate(); } }}>
      <span class="rel-carte-plus-txt">${n.nom}</span>
      <span class="rel-carte-plus-sous">déplier ici ›</span>
    </button>`;
  }
  const t = n.id ? app.technique(n.id) : undefined;
  if (n.absente || !t) {
    return html`<div class="rel-carte-carte absente ${n.role ? classeRole(n.role) : ""}" style=${style}>
      <span class="rel-carte-nom">${n.nom}</span>
    </div>`;
  }
  // Badge de DÉPLIAGE (D-158) : « +n » = n liens encore invisibles → les déploie
  // autour de la carte SANS recentrer ; « − » replie. Élément FRÈRE positionné
  // sur le coin (jamais un bouton dans un bouton). Aucun badge si rien à déplier.
  const basculerDepl = (ev: Event) => {
    ev.stopPropagation();
    if (carteAPanne || !n.id) return;
    if (n.deplie) etat.carteDeplie.delete(n.id); else etat.carteDeplie.add(n.id);
    app.requestUpdate();
  };
  const badgeDepl = n.deplie || (n.depl ?? 0) > 0
    ? html`<button class="rel-carte-depl ${n.deplie ? "actif" : ""}"
        style=${`left:${n.x + n.w / 2 - 16}px; top:${n.y + n.h / 2 - 13}px`}
        aria-label=${n.deplie ? "Replier les liens de ce nœud" : `Déplier ${n.depl} lien${(n.depl ?? 0) > 1 ? "s" : ""} de plus`}
        title=${n.deplie ? "Replier" : `Déplier ${n.depl} lien${(n.depl ?? 0) > 1 ? "s" : ""} de plus`}
        @click=${basculerDepl}>${n.deplie ? "−" : `+${n.depl}`}</button>`
    : nothing;
  return html`<button class="rel-carte-carte ${classeRole(n.role ?? "peer")} ${(n.niveau ?? 1) >= 2 ? "niveau2" : ""}" style=${style}
    @click=${() => { if (!carteAPanne && n.id) pousser(app, n.id); }} title=${n.note ?? nothing}>
    <span class="rel-carte-media">${vignetteTechnique(app, t)}</span>
    <span class="rel-carte-nom">${t.nom}${alerte}</span>
    ${n.note ? html`<span class="rel-carte-note">${n.note}</span>` : nothing}
  </button>${badgeDepl}`;
}

export function vueCarte(app: MovensoApp, b: Bibliotheque, centre: Technique, liaisons: RelationAffichee[]): TemplateResult {
  // Recentrage = nouvelle exploration : les dépliages de l'ancien centre tombent.
  if (carteVue.fitId !== centre.id) { etat.carteDeplie.clear(); etat.carteRoleDeplie.clear(); }
  // Chips LÉGENDE + FILTRE (D-159) : une par famille de liens (couleur + libellé
  // + compte) — toucher masque/affiche la famille dans toute la carte.
  const groupes = grouper(liaisons);
  const visibles = liaisons.filter((l) => !etat.carteMasque.has(l.libelle));
  const { noeuds, aretes, sceneW, sceneH, hubX, hubY } = poserCarte(app, b, centre, visibles);
  carteBoite = { w: sceneW, h: sceneH, hubX, hubY };
  // « Tout déplier / replier tout » (D-159) : déplie chaque carte de niveau 1
  // (dans la limite du plafond global), ou revient au premier niveau.
  const idsNiveau1 = [...new Set(visibles.filter((l) => l.presente).map((l) => l.techniqueId))];
  const basculerTout = () => {
    if (etat.carteDeplie.size > 0 || etat.carteRoleDeplie.size > 0) {
      etat.carteDeplie.clear(); etat.carteRoleDeplie.clear(); // premier niveau, replié
    } else {
      idsNiveau1.forEach((id) => etat.carteDeplie.add(id));
      for (const g of groupes) etat.carteRoleDeplie.add(g.role); // « +N » aussi
    }
    app.requestUpdate();
  };
  const installerVue = (el?: Element) => {
    if (!el) return;
    carteViewport = el as HTMLElement;
    if (!carteViewport.dataset.carteInstallee) { carteViewport.dataset.carteInstallee = "1"; installerGestesCarte(carteViewport); }
  };
  const installerScene = (el?: Element) => {
    if (!el) return;
    carteScene = el as HTMLElement;
    const refit = carteVue.fitId !== centre.id;
    carteVue.fitId = centre.id;
    requestAnimationFrame(() => { if (refit) fitCarte(); else appliquerTransforme(); });
  };
  return html`
    <div class="rel-carte-chips" role="list" aria-label="Familles de liens (légende / filtre)">
      ${groupes.map((g) => {
        const masque = etat.carteMasque.has(g.libelle);
        const coul = couleurRole(g.role);
        return html`<button role="listitem" class="rel-carte-chip ${masque ? "masque" : ""}"
          style=${`color:${coul}; background:color-mix(in srgb, ${coul} 15%, var(--carte))`}
          @click=${() => { masque ? etat.carteMasque.delete(g.libelle) : etat.carteMasque.add(g.libelle); app.requestUpdate(); }}
          title=${masque ? `Afficher « ${g.libelle} »` : `Masquer « ${g.libelle} »`}>
          ${iconeRole(g.role)}<span class="rel-carte-chip-lib">${g.libelle}</span><span class="rel-carte-chip-n">${g.liste.length}</span>
        </button>`;
      })}
    </div>
    <div class="rel-carte ${etat.plein ? "plein" : ""}">
      <div class="rel-carte-outils">
        <button class="rel-carte-bt" @click=${() => zoomBouton(1.25)} aria-label="Zoom avant" title="Zoom avant">+</button>
        <button class="rel-carte-bt" @click=${() => zoomBouton(0.8)} aria-label="Zoom arrière" title="Zoom arrière">−</button>
        <button class="rel-carte-bt" @click=${() => fitCarte()} aria-label="Réajuster la carte" title="Réajuster">⊙</button>
        <button class="rel-carte-bt ${etat.carteDeplie.size > 0 || etat.carteRoleDeplie.size > 0 ? "actif" : ""}" @click=${basculerTout}
          aria-label=${etat.carteDeplie.size > 0 || etat.carteRoleDeplie.size > 0 ? "Replier tout (premier niveau)" : "Tout déplier"}
          title=${etat.carteDeplie.size > 0 || etat.carteRoleDeplie.size > 0 ? "Replier tout (premier niveau)" : "Tout déplier"}>${etat.carteDeplie.size > 0 || etat.carteRoleDeplie.size > 0 ? "⊟" : "⊞"}</button>
        <button class="rel-carte-bt ${etat.plein ? "actif" : ""}" @click=${() => { etat.plein = !etat.plein; carteVue.fitId = ""; app.requestUpdate(); }}
          aria-label=${etat.plein ? "Quitter le plein écran" : "Plein écran"} title=${etat.plein ? "Quitter le plein écran" : "Plein écran"}>⛶</button>
      </div>
      <div class="rel-carte-aide">Glisse pour te déplacer · pince/molette pour zoomer · touche une carte pour recentrer</div>
      <div class="rel-carte-vue" ${ref(installerVue)}>
        <div class="rel-carte-scene" style=${`width:${sceneW}px; height:${sceneH}px`} ${ref(installerScene)}>
          <svg class="rel-carte-liens" viewBox=${`0 0 ${sceneW} ${sceneH}`} width=${sceneW} height=${sceneH} aria-hidden="true">
            ${aretes.map((a) => svg`<path d=${a.d} stroke-linecap="round" style=${`stroke:${couleurRole(a.role)}; fill:none; stroke-width:2.6; opacity:.7`}></path>`)}
          </svg>
          ${noeuds.map((n) => carteNoeud(app, n))}
        </div>
      </div>
    </div>
  `;
}
