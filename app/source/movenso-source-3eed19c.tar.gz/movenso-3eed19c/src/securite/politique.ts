/**
 * Politique CENTRALISÉE des actions protégées (lot 7 §17) : les
 * composants demandent une autorisation ici — aucune condition
 * `if (pinActif)` dispersée. Fonction pure, testable.
 */

/** Catégories minimales (§17). */
export type CategorieAction = "consultation" | "modification" | "destruction_ou_sensible";

/** Les deux protections indépendantes (§2) — état de préférences. */
export interface Protections {
  /** A. Protéger les modifications. */
  modifications: boolean;
  /** B. Protéger les suppressions et opérations sensibles. */
  suppressions: boolean;
}

export const PROTECTIONS_INACTIVES: Protections = { modifications: false, suppressions: false };

/**
 * Autorisation résultante : `libre`, ou `pin_requis`.
 * La consultation n'est JAMAIS bloquée (§0) ; une session déverrouillée
 * libère les deux niveaux — un seul PIN local (§9).
 */
export function autorisation(
  categorie: CategorieAction,
  protections: Protections,
  sessionDeverrouillee: boolean,
): "libre" | "pin_requis" {
  if (categorie === "consultation") return "libre";
  const protegee = categorie === "modification" ? protections.modifications : protections.suppressions;
  if (!protegee) return "libre";
  return sessionDeverrouillee ? "libre" : "pin_requis";
}

/** Durée de la session curateur (§8) — fonction pure du dernier geste
 *  autorisé : « arriere-plan » ne se verrouille que par l'arrière-plan,
 *  la fermeture ou « Verrouiller maintenant » ; sinon 5 ou 15 minutes
 *  d'inactivité. */
export function sessionActive(
  dernierGesteA: number | null,
  mode: "5min" | "15min" | "arriere-plan",
  maintenant: number,
): boolean {
  if (dernierGesteA === null) return false;
  if (mode === "arriere-plan") return true;
  return maintenant - dernierGesteA < (mode === "15min" ? 15 : 5) * 60_000;
}
