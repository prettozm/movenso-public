/**
 * Sécurité locale (lot 7) — PIN facultatif d'appareil, sans compte ni
 * serveur. Le PIN n'est JAMAIS stocké ni journalisé : seuls le sel,
 * les paramètres de dérivation et l'empreinte dérivée sont conservés
 * (§5). Web Crypto uniquement — aucune bibliothèque cryptographique.
 */

/** Itérations PBKDF2/SHA-256 — recommandation OWASP pour les cibles
 *  actuelles (Chromium/WebView) ; documentées ici, stockées avec chaque
 *  vérification pour pouvoir évoluer sans invalider l'existant. */
export const ITERATIONS_PBKDF2 = 310_000;

/** Ce qui est conservé pour vérifier le PIN — jamais le PIN lui-même. */
export interface VerificationPin {
  version: 1;
  /** Sel aléatoire propre à l'installation (hex, 16 octets). */
  sel: string;
  iterations: number;
  /** Empreinte dérivée PBKDF2/SHA-256 (hex, 32 octets). */
  empreinte: string;
}

/** Format §4 : 6 à 12 chiffres, valeurs trop évidentes refusées.
 *  Retourne un message d'erreur clair, ou null si le PIN est acceptable. */
export function validerFormatPin(pin: string): string | null {
  if (!/^\d{6,12}$/.test(pin)) return "Le PIN est une suite de 6 à 12 chiffres";
  if (/^(\d)\1+$/.test(pin)) return "Un même chiffre répété est trop évident";
  const montante = "01234567890123456789012";
  const descendante = [...montante].reverse().join("");
  if (montante.includes(pin) || descendante.includes(pin)) return "Une suite de chiffres est trop évidente";
  return null;
}

function octetsVersHex(octets: Uint8Array): string {
  return [...octets].map((x) => x.toString(16).padStart(2, "0")).join("");
}

function hexVersOctets(hex: string): Uint8Array {
  const octets = new Uint8Array(hex.length / 2);
  for (let i = 0; i < octets.length; i++) octets[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return octets;
}

async function deriver(pin: string, selHex: string, iterations: number): Promise<string> {
  const cle = await crypto.subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: hexVersOctets(selHex) as BufferSource, iterations },
    cle,
    256,
  );
  return octetsVersHex(new Uint8Array(bits));
}

/** Crée les données de vérification d'un PIN valide (jamais le PIN). */
export async function creerVerification(pin: string): Promise<VerificationPin> {
  const erreur = validerFormatPin(pin);
  if (erreur) throw new Error(erreur);
  const sel = octetsVersHex(crypto.getRandomValues(new Uint8Array(16)));
  return { version: 1, sel, iterations: ITERATIONS_PBKDF2, empreinte: await deriver(pin, sel, ITERATIONS_PBKDF2) };
}

/** Vérifie un PIN — comparaison des empreintes à temps constant,
 *  sans journalisation de la valeur saisie. */
export async function verifierPin(pin: string, v: VerificationPin): Promise<boolean> {
  const empreinte = await deriver(pin, v.sel, v.iterations);
  if (empreinte.length !== v.empreinte.length) return false;
  let difference = 0;
  for (let i = 0; i < empreinte.length; i++) difference |= empreinte.charCodeAt(i) ^ v.empreinte.charCodeAt(i);
  return difference === 0;
}

/** Temporisation progressive après échecs (§10) : immédiat jusqu'à 4
 *  erreurs, attente courte croissante ensuite, plafonnée — jamais de
 *  verrouillage définitif. En secondes. */
export function delaiApresEchecs(echecsConsecutifs: number): number {
  if (echecsConsecutifs < 5) return 0;
  return Math.min(30, 2 ** (echecsConsecutifs - 4));
}
