/**
 * Validation CENTRALE des URL externes (S1.3, audit P0.3) — décision pure et
 * testée : TOUTE chaîne destinée à un `href`, un `src` ou un embed passe par
 * ce module.
 *
 * Règles :
 * - à la SAISIE (`analyserLien`) : seuls les liens `https:` sont acceptés —
 *   `http:` est refusé avec un message actionnable, les protocoles actifs
 *   (`javascript:`, `data:`, `file:`, `blob:`, …) et inconnus toujours ;
 *   l'URL est NORMALISÉE avant stockage (`new URL().toString()`) ;
 * - YouTube est reconnu par un parseur STRICT (liste blanche d'hôtes +
 *   extraction d'identifiant vérifié) — seul cet identifiant, jamais l'URL
 *   brute, est interpolé dans les embeds et vignettes ;
 * - à l'AFFICHAGE (`urlSure`) : une URL déjà stockée (pack importé, donnée
 *   historique) n'est jamais réécrite, mais rien de non-`https:` ne devient
 *   cliquable ni chargeable.
 */

export type AnalyseLien =
  | { ok: true; type: "plateforme"; service: "youtube"; ref: string; url: string }
  | { ok: true; type: "lien"; ref: string; url: string }
  | { ok: false; raison: string };

/** Hôtes YouTube reconnus — tout autre hôte reste un lien nu (jamais d'embed). */
const HOTES_YOUTUBE = new Set([
  "youtube.com",
  "www.youtube.com",
  "m.youtube.com",
  "music.youtube.com",
  "www.youtube-nocookie.com",
  "youtu.be",
]);

/** Identifiant vidéo YouTube plausible — la SEULE forme interpolée dans une
 *  URL d'embed ou de vignette (jamais une chaîne libre). */
export function idYoutubeValide(ref: string): boolean {
  return /^[A-Za-z0-9_-]{6,20}$/.test(ref);
}

function idYoutubeDepuis(u: URL): string | null {
  let id: string | null = null;
  if (u.hostname === "youtu.be") id = u.pathname.slice(1).split("/")[0] || null;
  else if (u.pathname === "/watch") id = u.searchParams.get("v");
  else id = u.pathname.match(/^\/(?:shorts|embed|live|v)\/([^/]+)/)?.[1] ?? null;
  return id && idYoutubeValide(id) ? id : null;
}

/** Analyse une URL SAISIE (capture, source, édition de lien) : refuse tout ce
 *  qui n'est pas `https:`, normalise, et reconnaît YouTube strictement. */
export function analyserLien(brut: string): AnalyseLien {
  const propre = brut.trim();
  if (!propre) return { ok: false, raison: "Lien vide." };
  let u: URL;
  try {
    u = new URL(propre);
  } catch {
    return { ok: false, raison: "Ce n'est pas une adresse valide (attendu : https://…)." };
  }
  if (u.protocol !== "https:") {
    return {
      ok: false,
      raison:
        u.protocol === "http:"
          ? "Seuls les liens https sont acceptés — ce site existe sans doute en https."
          : `Protocole refusé (${u.protocol.replace(":", "")}) — seuls les liens https sont acceptés.`,
    };
  }
  if (HOTES_YOUTUBE.has(u.hostname.toLowerCase())) {
    const id = idYoutubeDepuis(u);
    // un lien YouTube sans vidéo identifiable (chaîne, playlist…) reste un lien nu https
    if (id) return { ok: true, type: "plateforme", service: "youtube", ref: id, url: u.toString() };
  }
  return { ok: true, type: "lien", ref: u.toString(), url: u.toString() };
}

/** Re-contrôle d'AFFICHAGE pour une URL déjà stockée : `https:` normalisée,
 *  ou `null` — l'appelant montre alors du texte, jamais un lien actif. */
export function urlSure(brut: string | undefined | null): string | null {
  if (!brut) return null;
  try {
    const u = new URL(brut.trim());
    return u.protocol === "https:" ? u.toString() : null;
  } catch {
    return null;
  }
}

/** Domaine affichable d'une URL sûre — pour SIGNALER où mène une sortie de
 *  Movenso (S2.11) : `www.` retiré, `null` si l'URL n'est pas exploitable. */
export function domaineDe(brut: string | undefined | null): string | null {
  const sure = urlSure(brut);
  if (!sure) return null;
  try {
    return new URL(sure).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}
