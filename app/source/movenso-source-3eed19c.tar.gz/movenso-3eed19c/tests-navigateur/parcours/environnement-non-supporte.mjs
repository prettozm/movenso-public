/**
 * CHAPITRE e2e (S3.A7) — S1.10 (D-167) — environnement non supporté, jamais d'écran blanc.
 * Contexte(s) Playwright propre(s) : OPFS isolé, lançable après tout chapitre.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { join } from "node:path";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== S1.10 option 1 (D-167) — environnement NON SUPPORTÉ : jamais d'écran
   blanc ni d'erreur brute. Deux simulations : OPFS absent (vieux navigateur)
   et createWritable absent (le cas Safari, qui passait l'ancienne garde). ===== */
for (const cas of [
  { nom: "sans OPFS", script: () => { delete StorageManager.prototype.getDirectory; } },
  { nom: "sans createWritable (Safari)", script: () => { delete FileSystemFileHandle.prototype.createWritable; } },
]) {
  const ctxNS = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pNS = await ctxNS.newPage();
  // pas de surveiller() : on tolère zéro erreur ici aussi, mais on l'assert localement
  const erreursNS = [];
  pNS.on("pageerror", (e) => erreursNS.push(String(e)));
  await pNS.addInitScript(cas.script);
  await pNS.goto("http://localhost:4517/");
  await pNS.waitForSelector(".erreur-demarrage", { timeout: 10000 });
  const texteNS = await pNS.locator(".erreur-demarrage").innerText();
  assert.ok(/Chrome, Edge et Firefox/.test(texteNS), `${cas.nom} : l'écran nomme les navigateurs supportés — ` + texteNS.slice(0, 120));
  assert.ok(/sauvegarde|Rien n'a été modifié/.test(texteNS), `${cas.nom} : l'échappatoire / l'innocuité sont dits`);
  assert.equal(await pNS.locator(".barre-nav").count(), 0, `${cas.nom} : jamais d'interface partiellement fonctionnelle`);
  assert.deepEqual(erreursNS, [], `${cas.nom} : zéro erreur JS brute — ` + erreursNS.join(" | "));
  await ctxNS.close();
}
}
