/**
 * CHAPITRE e2e (S3.A7) — S1.5 (D-166) — import transactionnel, zéro orphelin subi.
 * Contexte(s) Playwright propre(s) : OPFS isolé, lançable après tout chapitre.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== S1.5 (D-166, options B+C) — import TRANSACTIONNEL : un échec de
   persistance APRÈS la promotion re-déplace les médias (zéro orphelin, la
   proposition reste, le réessai gagne) ; un orphelin résiduel (crash brutal)
   est SIGNALÉ au démarrage, jamais supprimé d'office. ===== */
{
  const fichierCertifB = join(tmpdir(), "movenso-e2e-certif-complet.movpack");
  const ctxH = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pH = await ctxH.newPage();
  surveiller(pH);
  await pH.goto("http://localhost:4517/");
  await pH.waitForSelector(".action-douce");
  const [selH] = await Promise.all([pH.waitForEvent("filechooser"), pH.locator(".action-douce", { hasText: "Importer" }).click()]);
  await selH.setFiles(fichierCertifB);
  await pH.waitForSelector('.feuille[aria-label="Restauration complète"]');
  // la persistance échouera UNE fois — exactement la fenêtre du constat S1.5
  await pH.evaluate(() => {
    const app = document.querySelector("movenso-app");
    const originale = app.stockage.sauvegarder.bind(app.stockage);
    let premiere = true;
    app.stockage.sauvegarder = async (b) => {
      if (premiere) { premiere = false; throw new Error("écriture simulée refusée (coupure S1.5)"); }
      return originale(b);
    };
  });
  const compterH = (dossier) => pH.evaluate(async (d) => {
    try {
      const dir = await (await navigator.storage.getDirectory()).getDirectoryHandle(d.racine).then((x) => d.sous ? x.getDirectoryHandle(d.sous) : x);
      let n = 0;
      for await (const _ of dir.keys()) n++;
      return n;
    } catch { return 0; }
  }, dossier);
  await pH.locator(".feuille .actions .bouton.principal", { hasText: "Restaurer" }).click();
  await pH.locator(".toast", { hasText: "Restauration impossible" }).waitFor();
  // S1.12 : la CAUSE est consignée pour le diagnostic (opération + message)
  const echecConsigne = await pH.evaluate(() => document.querySelector("movenso-app").dernierEchec);
  assert.equal(echecConsigne?.code, "MOV-E04", "l'échec porte son code STABLE (D-217)");
  assert.equal(echecConsigne?.operation, "restauration complète", "l'échec est consigné avec son opération");
  assert.match(echecConsigne?.message ?? "", /écriture simulée refusée/, "et sa cause éditoriale : " + (echecConsigne?.message ?? "∅"));
  assert.equal(await compterH({ racine: "videos" }), 0, "ROLLBACK : aucun média promu ne survit à l'échec de persistance (zéro orphelin)");
  assert.ok((await compterH({ racine: "staging", sous: "import" })) >= 1, "les médias sont revenus en staging — la matière du réessai");
  assert.equal(await pH.locator('.feuille[aria-label="Restauration complète"]').count(), 1, "la proposition RESTE après l'échec — l'utilisateur décide");
  // le RÉESSAI gagne : re-promotion idempotente + persistance qui réussit
  await pH.locator(".feuille .actions .bouton.principal", { hasText: "Restaurer" }).click();
  await pH.locator(".toast", { hasText: "Bibliothèque restaurée" }).waitFor();
  assert.equal(await compterH({ racine: "videos" }), 1, "le réessai promeut et persiste — état final complet");
  // option C : un orphelin résiduel (crash brutal simulé : fichier étranger
  // dans videos/) est SIGNALÉ au prochain démarrage — jamais supprimé seul.
  await pH.evaluate(async () => {
    const videos = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos", { create: true });
    const h = await videos.getFileHandle("01ORPHELINSIMULE0000000000.webm", { create: true });
    const w = await h.createWritable();
    await w.write(new Uint8Array(64));
    await w.close();
  });
  await pH.reload();
  await pH.locator(".toast", { hasText: "orphelin" }).waitFor();
  assert.equal(await compterH({ racine: "videos" }), 2, "le signalement ne supprime RIEN — proposé, jamais subi");
  await ctxH.close();
}
}
