/**
 * CHAPITRE e2e (S3.A7) — Lot 8A boucle 8A.4 (§10) — espace insuffisant : jamais de demi-import.
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Consomme le .movpack exporté par le scénario I (chemin passé en paramètre).
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { surveiller, lent, navigateur, rendu, finit } from "../harnais.mjs";

export async function run({ fichierExport }) {
/* ===== Lot 8A boucle 8A.4 (§10) — espace insuffisant : jamais de
   bibliothèque partiellement restaurée, les deux tailles sont dites.
   Depuis S1.9 (D-163), le refus arrive dès l'IMPORT (borne basse = taille
   de l'archive, avant tout staging) ; le contrôle à la CONFIRMATION reste
   pour l'espace qui se dérobe entre la proposition et la confirmation. ===== */
const ctxD = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
const pageD = await ctxD.newPage();
surveiller(pageD);
await pageD.addInitScript(() => {
  // quota minuscule simulé : l'estimation est fiable ET insuffisante
  navigator.storage.estimate = async () => ({ usage: 0, quota: 200_000 });
});
await pageD.goto("http://localhost:4517/");
await pageD.waitForSelector(".action-douce");
const [selecteurD] = await Promise.all([
  pageD.waitForEvent("filechooser"),
  pageD.locator(".action-douce", { hasText: "Importer" }).click(),
]);
await selecteurD.setFiles(fichierExport);
// S1.9 : refus IMMÉDIAT, avant tout staging — aucune proposition ne s'ouvre
await pageD.locator(".toast", { hasText: "Espace insuffisant" }).waitFor();
assert.ok((await pageD.locator(".toast").innerText()).includes("disponibles"), "le refus dit la taille à écrire ET l'espace estimé disponible");
assert.equal(await pageD.locator('.feuille[aria-label="Restauration complète"]').count(), 0, "rien n'est proposé quand l'archive ne peut de toute façon pas être stagée (S1.9)");
assert.ok((await pageD.locator(".ecran").innerText()).includes("Importer"), "l'état existant est conservé — jamais de restauration partielle (§10)");
{
  const fichiersD = await pageD.evaluate(async () => {
    try {
      const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos");
      let n = 0;
      for await (const nom of d.keys()) n += nom ? 1 : 0;
      return n;
    } catch { return 0; }
  });
  assert.equal(fichiersD, 0, "aucun fichier vidéo écrit avant le refus");
}
await ctxD.close();
// §10 (préservé) : l'espace se dérobe ENTRE la proposition et la confirmation
// — le staging a réussi, la promotion est refusée, la proposition reste.
{
  const ctxD2 = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageD2 = await ctxD2.newPage();
  surveiller(pageD2);
  await pageD2.goto("http://localhost:4517/");
  await pageD2.waitForSelector(".action-douce");
  const [selecteurD2] = await Promise.all([
    pageD2.waitForEvent("filechooser"),
    pageD2.locator(".action-douce", { hasText: "Importer" }).click(),
  ]);
  await selecteurD2.setFiles(fichierExport);
  await pageD2.waitForSelector(".feuille[aria-label=\"Restauration complète\"]");
  await pageD2.evaluate(() => {
    // l'espace disparaît APRÈS la proposition (autre app, autre onglet…)
    const app = document.querySelector("movenso-app");
    app.stockage.estimerEspace = async () => ({ usage: 1_000_000_000, quota: 1_000_000_000 });
  });
  await pageD2.locator(".feuille .actions .bouton.principal", { hasText: "Restaurer" }).click();
  await pageD2.locator(".toast", { hasText: "Espace insuffisant" }).waitFor();
  assert.equal(await pageD2.locator('.feuille[aria-label="Restauration complète"]').count(), 1, "la proposition reste — l'utilisateur décide, rien n'est subi");
  await pageD2.locator(".feuille .actions .bouton", { hasText: "Annuler" }).click();
  await finit(async () => assert.ok((await pageD2.locator(".ecran").innerText()).includes("Importer"), "l'état existant est conservé — jamais de restauration partielle (§10)"));
  await ctxD2.close();
}
}
