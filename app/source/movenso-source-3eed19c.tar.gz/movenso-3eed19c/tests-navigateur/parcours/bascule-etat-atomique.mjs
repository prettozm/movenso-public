/**
 * CHAPITRE e2e (S3.A7) — Lot 8C boucle 8C.2 (§18) — bascule d'état atomique (jamais à moitié écrit).
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== Lot 8C boucle 8C.2 (§18, scénario E côté état) — bascule d'état
   PROTÉGÉE + reprise d'une transaction inachevée : un `bibliotheque.json.tmp`
   résiduel (commit interrompu) est écarté au démarrage, l'état COURANT valide
   survit intact ; aucune bascule vers un état à moitié écrit. ===== */
{
  const ctxT = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageT = await ctxT.newPage();
  surveiller(pageT);
  await pageT.goto("http://localhost:4517/");
  await pageT.waitForSelector(".action-douce");
  // état courant réel : une discipline créée par un vrai parcours
  await pageT.locator(".action-douce", { hasText: "Créer ta première technique" }).click();
  await pageT.waitForSelector(".champ-nouveau-nom");
  await pageT.fill(".champ-nouveau-nom", "Ikkyo");
  await pageT.fill(".champ-discipline", "Aïkido");
  await pageT.locator(".feuille .actions .bouton.principal", { hasText: "Créer la technique" }).click();
  await pageT.waitForSelector(".edition");
  await pageT.locator('.fiche-actions [aria-label="Enregistrer"]').click();
  await pageT.locator(".fiche-entete h1", { hasText: "Ikkyo" }).waitFor();
  await pageT.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // racine Bibliothèque
  await pageT.locator(".chip-discipline", { hasText: "Aïkido" }).waitFor();
  // (1) une bascule d'état RÉUSSIE (la création ci-dessus) ne laisse aucun
  //     temporaire derrière elle ; on capture l'état courant valide.
  const avant = await pageT.evaluate(async () => {
    const racine = await navigator.storage.getDirectory();
    let tmp = false;
    for await (const [n] of racine.entries()) if (n === "bibliotheque.json.tmp") tmp = true;
    const cur = await (await (await racine.getFileHandle("bibliotheque.json")).getFile()).text();
    return { tmp, cur };
  });
  assert.equal(avant.tmp, false, "une bascule d'état réussie ne laisse aucun temporaire (§18)");
  // (2) on simule un commit INTERROMPU : un .tmp à moitié écrit traîne à côté
  //     de l'état courant (jamais basculé). Le démarrage doit l'écarter.
  await pageT.evaluate(async () => {
    const racine = await navigator.storage.getDirectory();
    const h = await racine.getFileHandle("bibliotheque.json.tmp", { create: true });
    const w = await h.createWritable();
    await w.write('{"versionSchema":99,"disciplines":[{"MOITIÉ ÉCRITE'); // JSON tronqué
    await w.close();
  });
  await pageT.reload();
  await pageT.waitForSelector(".chip-discipline");
  assert.equal(await pageT.locator(".chip-discipline", { hasText: "Aïkido" }).count(), 1, "l'état COURANT valide survit à un commit interrompu (§18)");
  const apres = await pageT.evaluate(async () => {
    const racine = await navigator.storage.getDirectory();
    let tmpPresent = false;
    for await (const [n] of racine.entries()) if (n === "bibliotheque.json.tmp") tmpPresent = true;
    const cur = await (await (await racine.getFileHandle("bibliotheque.json")).getFile()).text();
    return { tmpPresent, cur };
  });
  assert.equal(apres.tmpPresent, false, "le temporaire d'un commit interrompu est nettoyé au démarrage (§19)");
  assert.equal(apres.cur, avant.cur, "le fichier d'état courant n'a jamais basculé vers le .tmp à moitié écrit");
  await ctxT.close();
}
}
