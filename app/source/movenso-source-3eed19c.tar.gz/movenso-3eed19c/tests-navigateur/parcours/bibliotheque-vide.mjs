/**
 * CHAPITRE e2e (S3.A7) — S2.15 — campagne bibliothèque vide.
 * Contexte(s) Playwright propre(s) : OPFS isolé, lançable après tout chapitre.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { join } from "node:path";
import { surveiller, lent, ouvrirPlus, navigateur, rendu } from "../harnais.mjs";

export async function run() {
/* ===== S2.15 — campagne BIBLIOTHÈQUE VIDE : aucun écran ne suppose une
   discipline, technique, composition, relation, favori, média, capture ou
   pack existants. Sur une installation VIERGE (mode avancé + relations bêta
   activés pour tout révéler), chaque onglet et chaque sous-écran de Plus se
   rend avec un contenu utile (état vide ou commandes) — la surveillance
   globale garantit en plus zéro erreur JS. ===== */
{
  const ctxV = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pV = await ctxV.newPage();
  surveiller(pV);
  await pV.goto("http://localhost:4517/");
  await pV.waitForSelector(".action-douce");
  await pV.evaluate(() => {
    const app = document.querySelector("movenso-app");
    app.basculerReglage("modeAvance");
    app.basculerReglage("vueRelationBeta");
    app.basculerReglage("compositionsBeta"); // D-223 : bêta opt-in
  });
  await rendu(pV);
  // les onglets principaux, tous, sur vide
  const nbOnglets = await pV.locator(".barre-nav .nav-onglet").count();
  assert.ok(nbOnglets >= 4, "S2.15 : la nav complète est là (relations bêta comprises) : " + nbOnglets);
  for (let i = 0; i < nbOnglets; i++) {
    const nom = (await pV.locator(".barre-nav .nav-onglet").nth(i).innerText()).trim();
    await pV.locator(".barre-nav .nav-onglet").nth(i).click();
    await rendu(pV);
    const texte = (await pV.locator("movenso-app").innerText()).trim();
    assert.ok(texte.length > 30, `S2.15 : l'onglet « ${nom} » doit se rendre utile sur bibliothèque vide`);
  }
  // chaque sous-écran de Plus (sauf « Importer un pack » : action → sélecteur de fichier)
  await pV.locator(".barre-nav .nav-onglet").last().click();
  await rendu(pV);
  const lignes = (await pV.locator(".ligne-menu-titre").allInnerTexts()).map((t) => t.trim()).filter((t) => t && t !== "Importer un pack");
  assert.ok(lignes.length >= 12, "S2.15 : mode avancé + bêta révèlent tout le menu — " + lignes.join(" | "));
  for (const titre of lignes) {
    await ouvrirPlus(pV, titre);
    await rendu(pV);
    const texte = (await pV.locator("movenso-app").innerText()).trim();
    assert.ok(texte.length > 30, `S2.15 : « ${titre} » doit offrir un état vide utile — texte : ${texte.slice(0, 60)}`);
  }
  await ctxV.close();
}
}
