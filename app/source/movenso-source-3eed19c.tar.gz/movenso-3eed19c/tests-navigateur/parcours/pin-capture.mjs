/**
 * CHAPITRE e2e (S3.A7) — Lot 8C boucle 8C.6 (audit F1) — repère filmé avec PIN.
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== Lot 8C boucle 8C.6 (audit contradictoire, F1) — repère filmé avec PIN
   demandé PENDANT l'enregistrement : aucun fichier n'est écrit tant que le PIN
   n'est pas saisi (la méthode entière est différée), puis la reprise écrit le
   fichier ET le bloc qui le référence — jamais un fichier écrit puis supprimé
   puis re-référencé (l'orphelin que §19 interdit). ===== */
{
  const ctxPin = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const p = await ctxPin.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  const compterVideos = () =>
    p.evaluate(async () => {
      try {
        const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos");
        let n = 0;
        for await (const _ of d.keys()) n++;
        return n;
      } catch {
        return 0;
      }
    });
  const compoId = await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    await app.creerDiscipline("PinDisc");
    await app.creerComposition("Compo PIN");
    const cid = app.bibliotheque.compositions.at(-1).id;
    // protection des modifications active + session verrouillée
    await app.activerProtection("modifications", { pin: "246813", confirmation: "246813" });
    app.verrouiller(true);
    return cid;
  });
  const vAvant = await compterVideos();
  // tenter d'ajouter un repère filmé pendant que la session est verrouillée
  await p.evaluate((cid) => {
    const app = document.querySelector("movenso-app");
    app.capture = { etape: "note", note: "repère protégé", demarreA: Date.now(), video: new File([new Uint8Array(6000)], "r.mp4", { type: "video/mp4" }), compositionCible: cid };
    return app.terminerCaptureRepere();
  }, compoId);
  const pendant = await p.evaluate(() => ({
    pin: document.querySelector("movenso-app").demandePin !== null,
    captureOuverte: document.querySelector("movenso-app").capture !== null,
    blocs: document.querySelector("movenso-app").bibliotheque.compositions[0].blocs.length,
  }));
  assert.ok(pendant.pin, "le PIN est demandé AVANT toute écriture (garde à l'entrée)");
  assert.ok(pendant.captureOuverte, "la capture reste ouverte tant que le PIN n'est pas saisi");
  assert.equal(pendant.blocs, 0, "aucun bloc n'est ajouté avant le PIN");
  assert.equal(await compterVideos(), vAvant, "AUCUN fichier vidéo écrit avant le PIN (pas d'orphelin possible)");
  // saisir le PIN → l'action différée (fire-and-forget) rejoue
  // terminerCaptureRepere EN ENTIER ; on attend le VRAI signal de succès
  // (capture fermée, posée seulement APRÈS la persistance) — jamais une lecture
  // anticipée sur blocs.length (poussé avant la fin du persist → course).
  await p.evaluate(() => document.querySelector("movenso-app").validerDemandePin("246813"));
  await p.waitForFunction(() => document.querySelector("movenso-app").capture === null);
  const apres = await p.evaluate(() => {
    const bloc = document.querySelector("movenso-app").bibliotheque.compositions[0].blocs[0];
    return { blocs: document.querySelector("movenso-app").bibliotheque.compositions[0].blocs.length, mediaId: bloc?.medias[0]?.id ?? null, capture: document.querySelector("movenso-app").capture };
  });
  assert.equal(apres.blocs, 1, "après le PIN, exactement un bloc repère est ajouté");
  assert.equal(await compterVideos(), vAvant + 1, "après le PIN, le fichier est écrit UNE fois");
  assert.ok(apres.mediaId, "le bloc repère référence bien un média");
  const fichierPresent = await p.evaluate(async (mid) => {
    const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos");
    for await (const [n] of d.entries()) if (n === mid || n.startsWith(mid + ".")) return true;
    return false;
  }, apres.mediaId);
  assert.ok(fichierPresent, "le fichier référencé par le bloc existe RÉELLEMENT (aucun orphelin, aucune perte de la capture)");
  assert.equal(apres.capture, null, "la capture se ferme au vrai succès");
  await ctxPin.close();
}
}
