/**
 * CHAPITRE e2e (S3.A7) — Lot 8C boucle 8C.3 (§17/§19) — atomicité média+métier sous échecs injectés.
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== Lot 8C boucle 8C.3 (§17/§19, concurrence) — atomicité média+métier :
   un échec de persistance sur CHAQUE parcours d'écriture ne laisse ni
   contribution/bloc fantôme ni fichier orphelin ; un double-appui ne duplique
   pas la contribution. Échecs injectés en remplaçant `sauvegarder`. ===== */
{
  const ctxTx = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const p = await ctxTx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  const techId = await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const did = await app.creerDiscipline("Transac");
    await app.creerTechnique(did, "Uchi mata");
    return app.bibliotheque.techniques.at(-1).id;
  });
  const compterVideos = () =>
    p.evaluate(async () => {
      try {
        const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos");
        let n = 0;
        for await (const _ of d.keys()) n++;
        return n;
      } catch {
        return 0;
      }
    });
  const nbContribs = () => p.evaluate((t) => document.querySelector("movenso-app").bibliotheque.contributions.filter((c) => c.techniqueId === t).length, techId);

  // (A) échec pendant ajouterMediaFiche → aucune contribution, aucun orphelin
  const vA = await compterVideos();
  const cA = await nbContribs();
  await p.evaluate(async (t) => {
    const app = document.querySelector("movenso-app");
    const vrai = app.stockage.sauvegarder.bind(app.stockage);
    app.stockage.sauvegarder = async () => {
      throw new Error("échec simulé");
    };
    const f = new File([new Uint8Array(4096)], "clip.mp4", { type: "video/mp4" });
    await app.ajouterMediaFiche(t, { fichier: f }, { provenance: "personnel" });
    app.stockage.sauvegarder = vrai;
  }, techId);
  assert.equal(await nbContribs(), cA, "ajouterMediaFiche : échec de persistance → aucune contribution fantôme (§19)");
  assert.equal(await compterVideos(), vA, "ajouterMediaFiche : le fichier NEUF est retiré sur échec, aucun orphelin (§19)");

  // (B) double-appui sur terminerCapture (même fichier) → UNE contribution, UN fichier
  const cB = await nbContribs();
  const vB = await compterVideos();
  await p.evaluate(async (t) => {
    const app = document.querySelector("movenso-app");
    const f = new File([new Uint8Array(8192)], "double.mp4", { type: "video/mp4" });
    app.capture = { etape: "note", note: "repère", demarreA: Date.now(), video: f };
    await Promise.all([app.terminerCapture(t), app.terminerCapture(t)]); // deux gestes concurrents
  }, techId);
  assert.equal(await nbContribs(), cB + 1, "double-appui : une SEULE contribution créée (§concurrence)");
  assert.equal(await compterVideos(), vB + 1, "double-appui : un SEUL fichier physique (déduplication + garde)");

  // (C) échec pendant terminerCaptureRepere (repère filmé) → aucun bloc, aucun orphelin
  const compoId = await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    await app.creerComposition("Enchaînement");
    return app.bibliotheque.compositions.at(-1).id;
  });
  const vC = await compterVideos();
  await p.evaluate(async (cid) => {
    const app = document.querySelector("movenso-app");
    const vrai = app.stockage.sauvegarder.bind(app.stockage);
    app.stockage.sauvegarder = async () => {
      throw new Error("échec simulé");
    };
    const f = new File([new Uint8Array(12288)], "repere.mp4", { type: "video/mp4" });
    app.capture = { etape: "note", note: "", demarreA: Date.now(), video: f, compositionCible: cid };
    await app.terminerCaptureRepere();
    app.stockage.sauvegarder = vrai;
  }, compoId);
  const blocs = await p.evaluate((cid) => document.querySelector("movenso-app").bibliotheque.compositions.find((c) => c.id === cid).blocs.length, compoId);
  assert.equal(blocs, 0, "repère : échec de persistance → aucun bloc fantôme (§19)");
  assert.equal(await compterVideos(), vC, "repère : le fichier NEUF filmé est retiré sur échec, aucun orphelin (§19 — trou 8C.3 comblé)");
  await ctxTx.close();
}
}
