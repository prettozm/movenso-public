/**
 * CHAPITRE e2e (S3.A7) — Lot 10B (A1) — publication : relation vers une cible hors pack.
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { unzipSync } from "fflate";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== Lot 10B (A1) — publication : une relation vers une cible HORS
   périmètre est exclue du fichier publié (jamais de lien pendant), la relation
   LOCALE est inchangée, et le rapport annonce l'exclusion. ===== */
{
  const ctxRel = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const p = await ctxRel.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  const { did, aId, absent } = await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const did = await app.creerDiscipline("Lutte");
    await app.creerTechnique(did, "Souplesse");
    await app.creerTechnique(did, "Passage");
    const [a, cible] = app.bibliotheque.techniques.slice(-2);
    const absent = "01HZ0000000000000000000000"; // identité hors du pack
    a.relations = [
      { type: "enchaine", cibleId: cible.id }, // interne
      { type: "contre", cibleId: absent }, // hors périmètre
    ];
    await app.stockage.sauvegarder(app.bibliotheque);
    app.bibliotheque = { ...app.bibliotheque };
    app.ecran = { type: "bibliotheques" };
    app.requestUpdate();
    return { did, aId: a.id, absent };
  });
  await p.evaluate((d) => document.querySelector("movenso-app").preparerPublication(d, { avecVideos: false, nom: "Lutte" }), did);
  const resumePub = await p.evaluate(() => document.querySelector("movenso-app").publicationPrete?.resume ?? "");
  const [dl] = await Promise.all([p.waitForEvent("download"), p.evaluate(() => document.querySelector("movenso-app").enregistrerPublicationLocale())]);
  const f = join(tmpdir(), "movenso-10b-rel.movpack");
  await dl.saveAs(f);
  const arch = unzipSync(readFileSync(f));
  const bibPack = JSON.parse(new TextDecoder().decode(arch["bibliotheque.json"]));
  const idsPack = new Set(bibPack.techniques.map((t) => t.id));
  // aucune relation pendante dans le pack
  for (const t of bibPack.techniques) for (const r of t.relations) assert.ok(idsPack.has(r.cibleId), "aucun lien pendant dans le pack publié (A1)");
  const aPack = bibPack.techniques.find((t) => t.id === aId);
  assert.ok(aPack.relations.some((r) => r.cibleId !== absent) && !aPack.relations.some((r) => r.cibleId === absent), "relation interne conservée, relation hors périmètre exclue");
  // la relation LOCALE est inchangée + le rapport (publicationPrête) annonce l'exclusion
  const nbRel = await p.evaluate((id) => document.querySelector("movenso-app").bibliotheque.techniques.find((x) => x.id === id).relations.length, aId);
  assert.equal(nbRel, 2, "la relation locale originale n'est pas modifiée par la publication");
  assert.match(resumePub, /relation.*exclue/i, "le rapport du pack préparé annonce la relation exclue");
  await ctxRel.close();
}
}
