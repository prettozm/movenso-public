/**
 * CHAPITRE e2e (S3.A7) — D-249 : la croix ✕ « Annuler l'édition » doit défaire
 * les modifications À L'ÉCRAN, pas seulement dans le modèle (D-105).
 *
 * Le défaut attrapé : le commentaire de fiche vit HORS de la bascule
 * lecture/édition, donc sa liaison Lit survit à la sortie d'édition. Lit
 * compare la valeur à sa dernière valeur COMMITÉE, jamais au DOM ; quand la
 * saisie de l'utilisateur n'a été commitée par aucun rendu intermédiaire, la
 * valeur restaurée par ✕ est ÉGALE au mémo, Lit saute l'écriture, et le texte
 * abandonné reste affiché. L'app dit « Modifications annulées » et montre le
 * contraire — et la prochaine perte de focus le ré-enregistre.
 *
 * Ce chapitre force le cas SANS dépendre de la charge machine : le `change`
 * est émis puis ✕ est actionnée dans la MÊME tâche, avant que l'écriture OPFS
 * n'ait rendu la main. Le flux principal de `parcours.mjs` couvre le même
 * comportement par le chemin nominal — mais il ne rougissait que sur machine
 * lente, ce qui est précisément ce qu'un test ne doit pas faire dépendre.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 800 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");

  // Une technique portant déjà une note : c'est elle que ✕ devra rendre.
  const idTechnique = await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const d = await app.creerDiscipline("Judo");
    await app.creerTechnique(d, "Tai-otoshi"); // ouvre la fiche ET passe en édition
    const id = app.bibliotheque.techniques.find((t) => t.nom === "Tai-otoshi").id;
    await app.ajouterNote(id, "NOTE INITIALE");
    app.validerEditionFiche(); // sortir de l'édition ouverte par la création
    app.ouvrirFiche(id);
    await app.updateComplete;
    return id;
  });
  await p.waitForSelector(".commentaire-zone");
  await rendu(p);

  const etat = () => p.evaluate(() => {
    const app = document.querySelector("movenso-app");
    const c = app.bibliotheque.contributions.find((x) => x.description);
    return { ecran: document.querySelector(".commentaire-zone").value, modele: c?.description ?? "" };
  });
  assert.deepEqual(await etat(), { ecran: "NOTE INITIALE", modele: "NOTE INITIALE" }, "témoin : la note de départ est à l'écran et au modèle");

  await p.evaluate((id) => document.querySelector("movenso-app").entrerEditionFiche(id), idTechnique); // instantané D-105
  await rendu(p);

  // Saisie PUIS ✕ dans la même tâche : aucun rendu entre les deux.
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const zone = document.querySelector(".commentaire-zone");
    zone.value = "MODIF A ANNULER";
    zone.dispatchEvent(new Event("change", { bubbles: true })); // → majContribution, écriture NON attendue
    await app.annulerEditionFiche();
    await app.updateComplete;
  });
  await rendu(p);

  await finit(async () =>
    assert.deepEqual(await etat(), { ecran: "NOTE INITIALE", modele: "NOTE INITIALE" },
      "✕ doit défaire la modification à l'écran ET au modèle (D-105/D-249)"));

  // L'AUTRE MOITIÉ DU CONTRAT (D-251) : ce champ porte une note PERSONNELLE
  // auto-enregistrée à la PERTE DE FOCUS, pas à la frappe. Entre les deux, le
  // DOM est en avance sur le modèle — et c'est normal. Un rendu ordinaire
  // (toast, écriture qui se termine, rafraîchissement) ne doit donc JAMAIS
  // réécrire ce champ, sous peine d'effacer une note en cours de frappe.
  // Première tentative de correctif de D-249 : elle faisait exactement ça.
  // On tape à la SUITE, sans vider le champ : une frappe n'émet pas de
  // `change` (il n'arrive qu'à la perte de focus), donc le modèle reste sur
  // « NOTE INITIALE » pendant tout ce temps. C'est exactement la fenêtre où
  // un rendu ne doit rien réécrire.
  await p.locator(".commentaire-zone").click();
  await p.locator(".commentaire-zone").press("End");
  await p.locator(".commentaire-zone").type(" et ma suite en cours de frappe", { delay: 5 });
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    app.afficherToast("un message quelconque"); // un rendu que l'utilisateur n'a pas demandé
    app.requestUpdate();
    await app.updateComplete;
  });
  await rendu(p);
  assert.equal(await p.locator(".commentaire-zone").inputValue(), "NOTE INITIALE et ma suite en cours de frappe",
    "un rendu ordinaire ne doit pas effacer la note en cours de frappe (D-251)");

  // Et elle s'enregistre bien à la perte de focus, comme promis.
  await p.locator(".commentaire-zone").blur();
  await finit(async () =>
    assert.equal((await etat()).modele, "NOTE INITIALE et ma suite en cours de frappe", "la note personnelle s'enregistre à la perte de focus"));

  // Et le texte abandonné ne doit pas revenir par la persistance : au
  // rechargement, c'est la note en vigueur qui est relue depuis OPFS.
  //
  // On ATTEND que l'écriture ait atterri, sans la sonder : `charger()` n'est
  // pas un lecteur passif — il REPREND une transaction inachevée, donc il
  // supprime le `bibliotheque.json.tmp` qu'il trouve. Le sonder en boucle
  // pendant une écriture, c'est effacer le temporaire entre son écriture et
  // sa relecture : la bascule échoue (« écriture d'état incohérente ») et le
  // disque garde l'ancienne valeur. Une sonde qui casse ce qu'elle observe.
  // On passe donc par la FILE d'écriture : cette sauvegarde-ci se range
  // derrière la précédente et ne rend la main qu'une fois l'autre posée.
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    await app.stockage.sauvegarder(app.bibliotheque);
  });
  await p.reload();
  await finit(async () => {
    const note = await p.evaluate(async () => {
      const app = document.querySelector("movenso-app");
      await app?.updateComplete;
      return app?.bibliotheque?.contributions.find((x) => x.description)?.description ?? null;
    });
    assert.equal(note, "NOTE INITIALE et ma suite en cours de frappe", "après rechargement, la note relue est celle réellement enregistrée");
  });

  await ctx.close();
}
