/**
 * CHAPITRE e2e (S3.A7) — Lot 8C boucle 8C.4 (§20) — sauvegarde complète honnête (vidéo manquante dite).
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== Lot 8C boucle 8C.4 (§20) — « sauvegarde complète » honnête : une vidéo
   référencée absente du stockage rend la sauvegarde PARTIELLE (jamais
   l'étiquette « complète » sur un contenu amputé). ===== */
{
  const ctxSv = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const p = await ctxSv.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const did = await app.creerDiscipline("Sauv");
    await app.creerTechnique(did, "Technique média absent");
    const t = app.bibliotheque.techniques.at(-1).id;
    // référence vers un média LOCAL dont les octets manquent au stockage (ULID
    // valides). On reste sur la racine : la vidéo absente n'est jamais rendue.
    app.bibliotheque.contributions.push({
      id: "01HZ0000000000000000000000",
      techniqueId: t,
      provenance: "personnel",
      pointsCles: [],
      creeLe: new Date().toISOString(),
      medias: [{ id: "01HZ0000000000000000000001", type: "local", ref: "01HZ0000000000000000000001" }],
    });
    app.ecran = { type: "bibliotheques" };
    app.requestUpdate();
    await app.stockage.sauvegarder(app.bibliotheque);
    app.bibliotheque = { ...app.bibliotheque };
  });
  const [dl] = await Promise.all([p.waitForEvent("download"), p.evaluate(() => document.querySelector("movenso-app").exporterTout(true))]);
  await dl.saveAs(join(tmpdir(), "movenso-8c4.movpack"));
  const df = await p.evaluate(() => document.querySelector("movenso-app").dernierFichier);
  assert.match(df.role, /PARTIELLE/, "une vidéo référencée absente rend la sauvegarde PARTIELLE, jamais « complète » (§20)");
  assert.match(df.resume, /absente/, "l'exclusion de la vidéo absente est nommée");
  assert.match(df.resume, /réglages d'appareil/, "les réglages d'appareil sont dits exclus (D-065)");
  await ctxSv.close();
}
}
