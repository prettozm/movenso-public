/**
 * CHAPITRE e2e (S3.A7) — Lot 8D boucle 8D.1 (§38) — export du diagnostic technique.
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== Lot 8D boucle 8D.1 (§38) — export du diagnostic technique : un fichier
   texte lisible (compteurs, médias, stockage, versions), SANS aucun secret. ===== */
{
  const ctxD = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const p = await ctxD.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const did = await app.creerDiscipline("DiagDisc");
    await app.creerTechnique(did, "Tech diag");
  });
  const [dl] = await Promise.all([p.waitForEvent("download"), p.evaluate(() => document.querySelector("movenso-app").exporterDiagnostic())]);
  const chemin = await dl.path();
  const contenu = readFileSync(chemin, "utf8");
  assert.match(contenu, /diagnostic technique/i, "le diagnostic est lisible");
  assert.match(contenu, /techniques : 1/, "le diagnostic rapporte les compteurs réels");
  assert.match(contenu, /plateforme : web/, "la plateforme est indiquée");
  /* ---- D-234 : encodage et contexte enrichi ---- */
  assert.ok(contenu.startsWith("\uFEFF"), "un BOM UTF-8 ouvre le fichier — sinon « â€” » chez qui l'ouvre (D-234)");
  assert.match(contenu, /Sources du contenu/, "d'où vient le contenu (pack ou local)");
  assert.match(contenu, /local : 1 technique/, "une technique créée sur l'appareil est comptée « local »");
  assert.match(contenu, /Capacités de la plateforme :/, "les capacités réelles de l'appareil sont rapportées");
  assert.match(contenu, /stockage OPFS : oui/);
  assert.match(contenu, /Réglages actifs \(hors protections\) :/, "les réglages NON sensibles sont rapportés");
  assert.match(contenu, /sauvegardes internes : /, "le nombre de sauvegardes situe l'historique");
  assert.ok(!/\bpin\b/i.test(contenu), "aucun secret : le mot « PIN » n'apparaît pas");
  assert.ok(!/pbkdf|password|mot de passe/i.test(contenu), "aucun secret dans le diagnostic");

  /* ---- S3.A14 (D-217) : version d'app, codes d'erreur stables, opération longue. ---- */
  assert.match(contenu, /version de l'application : /, "la version applicative complète est indiquée");
  assert.match(contenu, /Opération longue :\n  aucune depuis le démarrage/, "honnête sans opération longue");
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    await app.occuperPendant("Sonde e2e…", async () => {});
    app.consignerEchec("MOV-E02", new Error("panne simulée e2e"));
  });
  const [dl2] = await Promise.all([p.waitForEvent("download"), p.evaluate(() => document.querySelector("movenso-app").exporterDiagnostic())]);
  const contenu2 = readFileSync(await dl2.path(), "utf8");
  assert.ok(contenu2.includes("Sonde e2e… — terminée ("), "l'opération longue terminée est datée (début → fin)");
  assert.match(contenu2, /\[MOV-E02\] lecture d'un pack — panne simulée e2e/, "le dernier échec porte son code stable");
  await ctxD.close();
}
}
