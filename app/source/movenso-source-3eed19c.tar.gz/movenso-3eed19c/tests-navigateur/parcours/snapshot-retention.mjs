/**
 * CHAPITRE e2e (S3.A7) — Lot 8C boucle 8C.5 (§22-23) — snapshot + rétention.
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== Lot 8C boucle 8C.5 (§22-23, scénario G) — snapshot + rétention : la
   suppression d'une contribution RETIENT le fichier (le rollback a un sens) ;
   restaurer le snapshot ramène la contribution, vidéo comprise. + reprise
   d'une écriture média interrompue : un résidu de `staging/` est nettoyé au
   démarrage (jamais un fichier partiel parmi les définitifs, §17). ===== */
{
  const ctxG = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const p = await ctxG.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  const compterVideos = () =>
    p.evaluate(async () => {
      try {
        const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos");
        let n = 0;
        for await (const _ of d.keys()) n++;
        return n;
      } catch {
        return 0;
      }
    });
  const nbContribs = () => p.evaluate(() => document.querySelector("movenso-app").bibliotheque.contributions.length);
  const cid = await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const did = await app.creerDiscipline("SnapG");
    await app.creerTechnique(did, "Tech snapshot");
    const t = app.bibliotheque.techniques.at(-1).id;
    await app.ajouterMediaFiche(t, { fichier: new File([new Uint8Array(5000)], "g.mp4", { type: "video/mp4" }) }, { provenance: "personnel" });
    return app.bibliotheque.contributions.at(-1).id;
  });
  const vAvant = await compterVideos();
  const cAvant = await nbContribs();
  assert.equal(vAvant, 1, "une vidéo est présente avant la suppression");
  await p.evaluate((c) => document.querySelector("movenso-app").supprimerContribution(c), cid);
  assert.equal(await nbContribs(), cAvant - 1, "la contribution est retirée de l'état");
  assert.equal(await compterVideos(), vAvant, "rétention (§22-23) : le fichier n'est PAS supprimé physiquement — le rollback a un sens");
  // restaurer le snapshot le plus récent (pris « avant-retrait », état AVEC la contribution)
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const noms = await app.stockage.listerSauvegardes();
    await app.restaurerSauvegarde(noms[0]);
  });
  assert.equal(await nbContribs(), cAvant, "restaurer le snapshot ramène la contribution supprimée (§22)");
  assert.equal(await compterVideos(), vAvant, "la vidéo retenue est toujours là : rollback complet, vidéo comprise");

  // reprise d'une écriture média interrompue : un résidu de staging/ (fichier
  // partiel d'une capture coupée) est nettoyé au démarrage, jamais promu.
  await p.evaluate(async () => {
    const racine = await navigator.storage.getDirectory();
    const staging = await racine.getDirectoryHandle("staging", { create: true });
    const h = await staging.getFileHandle("residu-interrompu.mp4", { create: true });
    const w = await h.createWritable();
    await w.write(new Uint8Array(1234));
    await w.close();
  });
  await p.reload();
  await p.waitForSelector(".chip-discipline");
  const stagingVide = await p.evaluate(async () => {
    try {
      const s = await (await navigator.storage.getDirectory()).getDirectoryHandle("staging");
      for await (const _ of s.keys()) return false;
      return true;
    } catch {
      return true; // dossier retiré = vide
    }
  });
  assert.ok(stagingVide, "un résidu d'écriture média interrompue est nettoyé au démarrage (§17)");
  await ctxG.close();
}
}
