/**
 * CHAPITRE e2e (S3.A7) — D-243 : une nouvelle version d'un pack qui RETIRE des
 * liens ne les retire pas d'office, elle les PROPOSE.
 *
 * Le défaut d'origine était silencieux : mettre à jour un pack épuré (D-241 :
 * 315 → 67 liens) ne changeait rien chez qui l'avait déjà, et rien ne le
 * disait. On éprouve ici les deux moitiés de la réponse — le rapport d'import
 * ANNONCE le nombre, et l'écran Relations laisse trancher, à l'unité comme en
 * bloc, sans que rien n'ait bougé entre-temps.
 *
 * Tout passe par le CIRCUIT RÉEL (sélecteur de fichier, aperçu, rapport) : le
 * défaut vivait précisément dans ce circuit, une API de test l'aurait manqué.
 * Contexte Playwright propre : OPFS isolé (A7).
 */
import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

const FICHIER = join(tmpdir(), "packtest.json");

/** Un pack minimal, paramétré par ses arêtes — v1 en pose trois, v2 une seule. */
function pack(relations) {
  const id = (n) => `01KX9CT5WN7HH6JWRTX9WPDE0${n}`;
  const noms = ["Alpha", "Beta", "Gamma", "Delta"];
  return {
    versionSchema: 4,
    disciplines: [{ id: id("A"), nom: "Judo test", familles: [], niveaux: [] }],
    techniques: noms.map((nom, i) => ({
      id: id(i), nom, disciplineId: id("A"), niveauxIds: [], alertes: [],
      relations: relations.filter(([de]) => de === i).map(([, vers]) => ({
        type: "similaire", cibleId: id(vers), note: `${noms[i]} et ${noms[vers]} se ressemblent.`, priorite: 1,
      })),
    })),
    contributions: [], compositions: [], favoris: [],
    typesRelation: [{ id: "similaire", libelle: "Similaire à", symetrique: true, role: "peer" }],
  };
}

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 900 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".barre-nav");

  /** Import par le circuit réel ; rend le texte du rapport affiché. */
  async function importer(biblio, premier) {
    writeFileSync(FICHIER, JSON.stringify(biblio));
    const declencheur = premier
      ? p.locator(".action-douce", { hasText: "Importer" }).click()
      : (async () => {
          await p.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
          await rendu(p);
          await p.locator(".ligne-menu", { hasText: "Importer un pack" }).click();
        })();
    const [selecteur] = await Promise.all([p.waitForEvent("filechooser"), declencheur]);
    await selecteur.setFiles(FICHIER);
    await p.waitForSelector(".feuille .actions .bouton.principal");
    await p.locator(".feuille .actions .bouton.principal").click();
    const rapport = p.locator('.feuille[aria-label="Rapport d\'import"]');
    await rapport.waitFor();
    const texte = await rapport.innerText();
    await rapport.locator(".actions .bouton.principal").click();
    await rendu(p);
    return texte;
  }

  const liens = () => p.evaluate(() => document.querySelector("movenso-app").bibliotheque
    .techniques.reduce((n, t) => n + t.relations.length, 0));

  await importer(pack([[0, 1], [0, 2], [1, 3]]), true);
  assert.equal(await liens(), 3, "témoin : la v1 a bien posé ses trois liens");

  // v2 : deux liens retirés du pack. RIEN ne doit disparaître tout seul.
  const texte = await importer(pack([[0, 1]]), false);
  assert.equal(await liens(), 3, "une mise à jour ne retire JAMAIS un lien d'office (D-243)");
  assert.match(texte, /2 liens? que tu as/, "le rapport DIT le nombre — c'est ce silence qui faisait le défaut : " + texte);
  assert.match(texte, /rien n'a été retiré/, "le rapport dit aussi que rien n'a bougé : " + texte);

  // L'écran Relations les présente, avec le geste « garder / retirer ».
  await p.evaluate(() => document.querySelector("movenso-app").ouvrirPlusSection("relations"));
  await rendu(p);
  await p.waitForSelector(".retrait-propose");
  assert.equal(await p.locator(".retrait-propose").count(), 2, "les deux propositions sont montrées");
  assert.equal(await p.locator(".retirer-liens-lot").count(), 1,
    "l'action groupée existe — arbitrer 255 arêtes à l'unité n'a pas de sens");

  // « Garder » classe la proposition SANS toucher à l'arête.
  await p.locator(".retrait-propose .chip-filtre", { hasText: "Garder" }).first().click();
  await finit(async () => assert.equal(await p.locator(".retrait-propose").count(), 1, "la proposition gardée est classée"));
  assert.equal(await liens(), 3, "« garder » ne détruit rien");

  // « Retirer » supprime l'arête, et elle seule.
  await p.locator(".retrait-propose .chip-filtre", { hasText: "Retirer" }).first().click();
  await finit(async () => assert.equal(await liens(), 2, "« retirer » enlève l'arête proposée, et elle seule"));
  await finit(async () => assert.equal(await p.locator(".retrait-propose").count(), 0, "plus rien à trancher"));

  await ctx.close();
}
