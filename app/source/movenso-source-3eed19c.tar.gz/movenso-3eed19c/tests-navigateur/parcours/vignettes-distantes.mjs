/**
 * CHAPITRE e2e (S4.3/D-260) — « rien ne part sans geste ».
 *
 * Une fiche sans illustration locale POUVAIT afficher la miniature fournie
 * par YouTube : la requête partait toute seule, dès que la vignette entrait
 * dans le champ. Le pack Judo n'ayant aucune image locale, c'était le cas
 * COURANT et non marginal — donc une promesse produit démentie en silence.
 *
 * Ce chapitre observe le RÉSEAU, pas le DOM : c'est la seule preuve qui
 * porte. Une vignette absente à l'écran ne prouverait rien (elle pourrait
 * avoir été demandée puis masquée) ; une requête absente, si.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 800 } });
  const p = await ctx.newPage();
  surveiller(p);

  // On observe TOUTE requête sortante vers YouTube, et on la bloque : le test
  // ne doit dépendre d'aucun accès réseau réel.
  const versYoutube = [];
  await p.route("**://*.youtube.com/**", (r) => { versYoutube.push(r.request().url()); return r.abort(); });
  await p.route("**://*.ytimg.com/**", (r) => { versYoutube.push(r.request().url()); return r.abort(); });

  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");

  // Une technique sans image locale, avec une vidéo YouTube sourcée : le cas
  // exact du pack Judo.
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const d = await app.creerDiscipline("Judo");
    await app.creerTechnique(d, "O-soto-gari");
    const id = app.bibliotheque.techniques.find((t) => t.nom === "O-soto-gari").id;
    app.validerEditionFiche();
    await app.ajouterMediaFiche(id, { lien: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" },
      { provenance: "referentiel", attribution: "Kodokan" });
    app.ouvrirBibliotheque();
    await app.updateComplete;
  });
  await p.waitForSelector(".carte-technique");
  await rendu(p);

  assert.deepEqual(versYoutube, [], "réglage OFF (défaut) : aucune requête vers YouTube depuis la grille");

  // La fiche non plus ne doit rien demander tant qu'on ne lance pas la vidéo.
  await p.locator(".carte-technique").first().locator(".carte-ouvrir").click();
  await p.waitForSelector(".fiche-entete h1");
  await rendu(p);
  assert.deepEqual(versYoutube, [], "réglage OFF : ouvrir une fiche ne contacte pas YouTube non plus");

  // Le réglage existe, il est dans Réglages avancés, et il est ÉTEINT.
  const etatInitial = await p.evaluate(() => document.querySelector("movenso-app").preferences.vignettesDistantes ?? false);
  assert.equal(etatInitial, false, "le réglage est éteint par défaut");

  // Allumé, l'utilisateur RÉCUPÈRE les vignettes : la capacité n'est pas
  // supprimée, elle est rendue au choix (jamais une capacité retirée en
  // douce — contrat).
  await p.evaluate(() => document.querySelector("movenso-app").basculerReglage("vignettesDistantes"));
  await p.evaluate(() => { const a = document.querySelector("movenso-app"); a.ouvrirBibliotheque(); return a.updateComplete; });
  await rendu(p);
  await finit(async () => assert.ok(versYoutube.length > 0, "réglage ON : la vignette distante est demandée"));

  await ctx.close();
}
