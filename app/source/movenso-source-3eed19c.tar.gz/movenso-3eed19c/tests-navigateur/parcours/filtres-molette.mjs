/**
 * CHAPITRE e2e (S3.A7) — D-228 : sur PC, la MOLETTE défile une rangée de filtres
 * qui déborde. Bug remonté par le porteur : la barre de défilement est masquée
 * (conçue pour le pouce), donc à la souris la rangée était inatteignable — la
 * molette verticale faisait défiler la page.
 * Contexte Playwright propre : pointeur fin, sans tactile (le cas d'un PC).
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 800 }, hasTouch: false });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");

  // Assez de disciplines pour que la rangée de filtres déborde franchement.
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    for (const n of ["Judo", "Karaté", "Jujitsu", "Aïkido", "Boxe", "Lutte", "Taïso", "Yoga", "Kendo", "Capoeira", "Sambo", "Krav-maga"])
      await app.creerDiscipline(n);
    app.ouvrirBibliotheque();
    await app.updateComplete;
  });
  await p.waitForSelector(".chip-discipline");
  await rendu(p);

  const rangee = p.locator(".chips-filtres").first();
  const mesure = () => p.evaluate(() => {
    const r = document.querySelector(".chips-filtres");
    return { gauche: r.scrollLeft, deborde: r.scrollWidth > r.clientWidth + 1, max: r.scrollWidth - r.clientWidth };
  });
  await finit(async () => assert.ok((await mesure()).deborde, "témoin : la rangée de filtres déborde bien à cette largeur"));

  const boite = await rangee.boundingBox();
  await p.mouse.move(boite.x + boite.width / 2, boite.y + boite.height / 2);
  await p.mouse.wheel(0, 240); // molette VERTICALE, comme sur un PC
  await finit(async () =>
    assert.ok((await mesure()).gauche > 0, "la molette verticale doit défiler la rangée horizontalement (D-228)"));

  // La molette en sens inverse revient au début, et aux bornes la page reprend
  // la main (on ne piège jamais le défilement de la page).
  await p.mouse.wheel(0, -600);
  await finit(async () => assert.equal((await mesure()).gauche, 0, "en sens inverse, la rangée revient à son début"));

  // Une rangée qui NE déborde PAS ne capture pas la molette : la feuille
  // « Apparence » a des rangées qui passent à la ligne — la page doit défiler.
  await p.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
  await p.locator(".ligne-menu", { hasText: "Apparence" }).click();
  await p.waitForSelector(".chips-filtres");
  await rendu(p);
  const sansDebordement = await p.evaluate(() =>
    [...document.querySelectorAll(".chips-filtres")].every((r) => r.scrollWidth <= r.clientWidth + 1));
  assert.ok(sansDebordement, "les rangées d'Apparence passent à la ligne : rien à défiler");

  await ctx.close();
}
