/**
 * CHAPITRE e2e (S3.A7) — Lot 8B boucle 8B.1 (§14) — intégrité par fichier (SHA-256) au réimport.
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { unzipSync, zipSync } from "fflate";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== Lot 8B boucle 8B.1 (§14, scénario D) — intégrité par fichier : un
   .movpack dont un octet vidéo est altéré est REFUSÉ à l'import, la
   bibliothèque cible n'est pas mutée. Export réel via l'app, corruption au
   niveau d'une entrée du ZIP (le CRC du ZIP reste valide — c'est bien
   l'empreinte SHA-256 de l'inventaire qui refuse). ===== */
{
  const ctxE = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageE = await ctxE.newPage();
  surveiller(pageE);
  await pageE.goto("http://localhost:4517/");
  await pageE.waitForSelector(".action-douce");
  // corpus minimal AVEC une vidéo locale, puis export complet réel
  await pageE.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const dId = await app.creerDiscipline("Aikido");
    await app.creerTechnique(dId, "Ikkyo");
    const t = app.bibliotheque.techniques.find((x) => x.nom === "Ikkyo");
    await app.ajouterMediaFiche(t.id, { fichier: new File([new Uint8Array(2048).fill(3)], "v.webm", { type: "video/webm" }) });
  });
  const [dlE] = await Promise.all([
    pageE.waitForEvent("download"),
    pageE.evaluate(() => document.querySelector("movenso-app").exporterTout(true)),
  ]);
  const fSain = join(tmpdir(), "movenso-8b1.movpack");
  await dlE.saveAs(fSain);
  await ctxE.close();

  // corruption d'un octet d'une entrée vidéo (le ZIP reste structurellement valide)
  const arch = unzipSync(readFileSync(fSain));
  const cleVideo = Object.keys(arch).find((k) => k.startsWith("medias/")); // §12 : structure canonique medias/<id>.<ext>
  assert.ok(cleVideo, "l'export complet doit ranger ses médias sous medias/<id>.<ext>");
  arch[cleVideo][0] = arch[cleVideo][0] ^ 0xff;
  const fCorrompu = join(tmpdir(), "movenso-8b1-corrompu.movpack");
  writeFileSync(fCorrompu, zipSync(arch));

  // import sur une installation VIERGE : refus à l'intégrité, aucune écriture
  const ctxG = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageG = await ctxG.newPage();
  surveiller(pageG);
  await pageG.goto("http://localhost:4517/");
  await pageG.waitForSelector(".action-douce");
  const [selG] = await Promise.all([
    pageG.waitForEvent("filechooser"),
    pageG.locator(".action-douce", { hasText: "Importer" }).click(),
  ]);
  await selG.setFiles(fCorrompu);
  await pageG.locator(".toast", { hasText: "Intégrité" }).waitFor();
  assert.equal(await pageG.locator(".feuille").count(), 0, "un conteneur corrompu n'ouvre AUCUNE proposition d'écriture");
  assert.ok((await pageG.locator(".ecran").innerText()).includes("Importer"), "la bibliothèque cible reste vierge — aucune mutation (§14)");
  const restE = await pageG.evaluate(async () => {
    try {
      const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos");
      let n = 0;
      for await (const nom of d.keys()) n += nom ? 1 : 0;
      return n;
    } catch { return 0; }
  });
  assert.equal(restE, 0, "aucun média écrit lorsqu'un conteneur est refusé");
  await ctxG.close();

  // D-114 — chemin SAIN en flux : le même export complet, non corrompu, importé
  // sur une installation vierge, restaure la bibliothèque ET la vidéo (staging
  // vérifié → promu vers videos/). Prouve la lecture EN FLUX de bout en bout.
  const ctxH = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageH = await ctxH.newPage();
  surveiller(pageH);
  // estimation généreuse ET fiable : le garde-fou d'espace (marge 16 Mo) ne doit
  // pas dépendre du disque partagé du bac à sable, déjà entamé par les contextes
  // précédents — on teste ici la PROMOTION, pas le refus (couvert par le §10).
  await pageH.addInitScript(() => {
    navigator.storage.estimate = async () => ({ usage: 0, quota: 5_000_000_000 });
  });
  await pageH.goto("http://localhost:4517/");
  await pageH.waitForSelector(".action-douce");
  const [selH] = await Promise.all([
    pageH.waitForEvent("filechooser"),
    pageH.locator(".action-douce", { hasText: "Importer" }).click(),
  ]);
  await selH.setFiles(fSain);
  // conteneur « complet » sur une install vierge → proposition de restauration
  const feuilleR = pageH.locator('.feuille[aria-label="Restauration complète"]');
  await feuilleR.waitFor();
  assert.match(await feuilleR.innerText(), /1 vidéo/, "la proposition annonce la vidéo du conteneur");
  await feuilleR.locator(".bouton.principal", { hasText: "Restaurer" }).click();
  await pageH.locator(".toast", { hasText: "restaurée" }).waitFor();
  const bilanH = await pageH.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    let videos = 0;
    try {
      const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos");
      for await (const _ of d.keys()) videos++;
    } catch { /* pas de dossier */ }
    let staging = 0;
    try {
      const s = await (await navigator.storage.getDirectory()).getDirectoryHandle("staging");
      const imp = await s.getDirectoryHandle("import");
      for await (const _ of imp.keys()) staging++;
    } catch { /* import nettoyé */ }
    return { videos, staging, ikkyo: app.bibliotheque.techniques.some((t) => t.nom === "Ikkyo") };
  });
  assert.equal(bilanH.videos, 1, "la vidéo du conteneur est promue dans videos/ après restauration");
  assert.equal(bilanH.staging, 0, "la zone d'import est vidée après la promotion (aucun résidu)");
  assert.ok(bilanH.ikkyo, "la bibliothèque restaurée contient bien la technique du conteneur");
  await ctxH.close();
}
}
