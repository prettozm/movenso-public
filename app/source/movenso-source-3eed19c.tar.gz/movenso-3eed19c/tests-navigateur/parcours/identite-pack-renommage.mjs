/**
 * CHAPITRE e2e (S3.A7) — Lot 8B boucle 8B.1id — identité de pack stable au renommage.
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { unzipSync } from "fflate";
import { surveiller, navigateur } from "../harnais.mjs";

export async function run() {
/* ===== Lot 8B boucle 8B.1id — identité de pack STABLE au renommage : publier
   une discipline, la renommer, republier → MÊME manifeste.id (dérivé de
   l'ULID), nom de fichier différent (dérivé du nom éditorial). ===== */
{
  const ctxH = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageH = await ctxH.newPage();
  surveiller(pageH);
  await pageH.goto("http://localhost:4517/");
  await pageH.waitForSelector(".action-douce");
  const dId = await pageH.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const id = await app.creerDiscipline("Boxe");
    await app.creerTechnique(id, "Jab");
    return id;
  });
  const manifesteDe = (arch) => JSON.parse(new TextDecoder().decode(arch["manifeste.json"]));
  const [dl1] = await Promise.all([
    pageH.waitForEvent("download"),
    pageH.evaluate(async (id) => { const app = document.querySelector("movenso-app"); await app.preparerPublication(id, { avecVideos: false, nom: "Boxe" }); await app.enregistrerPublicationLocale(); }, dId),
  ]);
  const f1 = join(tmpdir(), "movenso-8b1id-1.movpack");
  await dl1.saveAs(f1);
  const m1 = manifesteDe(unzipSync(readFileSync(f1)));
  // renommer la discipline PUIS republier
  await pageH.evaluate((id) => document.querySelector("movenso-app").majNomDiscipline(id, "Boxe anglaise"), dId);
  const [dl2] = await Promise.all([
    pageH.waitForEvent("download"),
    pageH.evaluate(async (id) => { const app = document.querySelector("movenso-app"); await app.preparerPublication(id, { avecVideos: false, nom: "Boxe anglaise" }); await app.enregistrerPublicationLocale(); }, dId),
  ]);
  const f2 = join(tmpdir(), "movenso-8b1id-2.movpack");
  await dl2.saveAs(f2);
  const m2 = manifesteDe(unzipSync(readFileSync(f2)));
  assert.equal(m1.id, m2.id, "l'identité du pack est STABLE au renommage (dérivée de l'ULID)");
  assert.ok(m1.id.includes(dId), "l'identité du pack porte l'ULID de la discipline : " + m1.id);
  assert.equal(m2.nom, "Boxe anglaise", "le nom éditorial suit le renommage");
  assert.notEqual(m1.nom, m2.nom, "le nom éditorial du manifeste a bien changé");
  await ctxH.close();
}
}
