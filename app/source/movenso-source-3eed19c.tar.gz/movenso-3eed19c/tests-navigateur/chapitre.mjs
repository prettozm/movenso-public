/**
 * Lanceur d'UN chapitre e2e (D-237) — pour itérer en secondes plutôt qu'en
 * minutes. `parcours.mjs` reste l'AUTORITÉ : il enchaîne le flux principal à
 * état cumulatif ET les vingt chapitres, et c'est lui que `npm run verifier`
 * et la CI exécutent. Ce lanceur ne remplace rien : il sert à travailler.
 *
 *   npm run e2e:chapitre composition-a-plusieurs
 *   npm run e2e:chapitre filtres-molette export-diagnostic
 *
 * Chaque chapitre ouvre son propre contexte Playwright (OPFS isolé, A7), donc
 * il se joue seul sans dépendre de ce qui précède — c'est précisément ce qui
 * rend ce lanceur possible.
 */
import assert from "node:assert/strict";
import { readdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { serveur, navigateur, erreurs } from "./harnais.mjs";

const ICI = dirname(fileURLToPath(import.meta.url));
const demandes = process.argv.slice(2).map((n) => n.replace(/\.mjs$/, ""));
const disponibles = (await readdir(join(ICI, "parcours"))).filter((f) => f.endsWith(".mjs")).map((f) => f.slice(0, -4));

if (demandes.length === 0 || demandes.some((n) => !disponibles.includes(n))) {
  const inconnus = demandes.filter((n) => !disponibles.includes(n));
  if (inconnus.length) console.error(`chapitre inconnu : ${inconnus.join(", ")}`);
  console.error(`usage : npm run e2e:chapitre <nom…>\nchapitres :\n  ${disponibles.join("\n  ")}`);
  await navigateur.close();
  serveur.close();
  process.exit(1);
}

for (const nom of demandes) {
  const debut = Date.now();
  const { run } = await import(`./parcours/${nom}.mjs`);
  await run();
  console.log(`chapitre ${nom} : OK (${((Date.now() - debut) / 1000).toFixed(1)} s)`);
}
assert.deepEqual(erreurs, [], "erreurs JS : " + erreurs.join(" | "));
console.log(`${demandes.length} chapitre(s) : OK, zéro erreur JS`);
await navigateur.close();
serveur.close();
