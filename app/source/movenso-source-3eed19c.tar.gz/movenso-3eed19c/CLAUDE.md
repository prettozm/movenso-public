# Movenso V3 — Instructions permanentes

## Au début de chaque session

1. Vérifier la branche, le commit et l’état Git.
2. Lire `docs/execution/MASTER.md`.
3. Lire `docs/execution/STATE.md`.
4. Lire `docs/execution/DECISIONS.md`.
5. Lire uniquement le lot courant indiqué dans `STATE.md`.
6. Lire les sections concernées de `docs/execution/QUALITY.md`.
7. Exécuter la vérification rapide disponible.

La mémoire opérationnelle est dans le dépôt. Ne pas se fier à une mémoire conversationnelle qui contredit ces fichiers.

## Mode de travail

Travailler en autonomie par boucles verticales courtes. Une boucle traite un seul comportement utilisateur, le vérifie, le documente, puis se termine par un commit vert et une mise à jour de `STATE.md`.

Enchaîner les boucles et les lots tant qu’aucune condition d’arrêt de `MASTER.md` n’est rencontrée.

## Deux dépôts, deux régimes (D-267)

`movenso` est un lieu de **travail** : l'historique, les lots et les décisions y
ont une valeur. `movenso-public` est une **destination** : on n'y développe pas,
on y dépose un build déjà vérifié. Appliquer la même règle aux deux revient soit
à interdire de publier, soit à laisser passer du travail sans revue.

**`movenso`** — toujours une branche, **jamais `main`**, **jamais de fusion**.

**`movenso-public`** — publication **directe sur `main`** autorisée, à quatre
conditions cumulatives :

1. le commit correspondant de `movenso` est **poussé** ;
2. `npm run verifier` est **vert** sur ce commit ;
3. `node verifier-catalogues.mjs` est vert **après** dépôt ;
4. application, packs et source partent **dans le même commit** — jamais un
   sous-ensemble (la garde le refuse désormais, via `app/build.json`).

**Exception — reste en branche + PR** : tout ce qui est **rédigé et engageant**
(mentions, confidentialité, sécurité, licences) et tout ce qui touche la
**posture de sécurité** (CSP, workflows, gardes). La ligne de partage : *ce qui
est produit et gardé va direct ; ce qui est écrit et engageant passe par le
porteur.* Un build se vérifie par des gardes ; une phrase juridique, non.

**APK et releases** suivent la même règle, et ne se génèrent que sur **demande
explicite**.

Si une consigne de démarrage de session contredit cette règle — par exemple en
nommant la même branche pour les deux dépôts — le **signaler** au lieu d'en
appliquer la lettre en silence.

## Interdictions

- Ne jamais travailler sur `main` **dans `movenso`** (voir « Deux dépôts, deux régimes »).
- Ne jamais fusionner, force-push ou réécrire l’historique.
- Ne jamais modifier Movenso V2.
- Ne jamais commencer deux lots en parallèle.
- Ne jamais ajouter une fonction hors du lot courant.
- Ne jamais supprimer une capacité sans décision explicite.
- Ne jamais committer un secret, un PIN ou un keystore.
- Ne jamais déclarer démontré ce qui ne l’est que partiellement.

## Avant de corriger : qualifier l’objet (D-251)

Ne jamais corriger un champ, un écran ou un comportement sans avoir écrit son
**cycle** — sinon on corrige le mauvais objet, et le correctif est plus
dangereux que le défaut.

Quatre questions, dont la réponse se **vérifie dans le code**, jamais de
mémoire :

1. **Qui l’écrit, et quand ?** (une saisie validée ? un auto-enregistrement à
   la perte de focus ? un import ?)
2. **À qui appartient la donnée ?** (contenu d’un pack, ou contenu personnel ?)
3. **Où vit-elle, et jusqu’où voyage-t-elle ?** (mémoire, disque, export,
   sauvegarde — un contenu personnel ne s’exporte pas)
4. **Qu’est-ce qui a le droit de l’écraser, et à quel geste précis ?**

Deux champs qui se ressemblent à l’écran peuvent n’avoir aucun rapport : le
titre d’une fiche est une donnée validée en édition, le commentaire est une
note **personnelle auto-enregistrée hors édition**. Les traiter pareil a
produit une perte de saisie silencieuse (D-251).

## Un correctif n’est vert que démontré dans les DEUX sens

- Un test doit **rougir sans le correctif** et **passer avec** — les deux
  mesurés, pas supposés. Un test qui n’a jamais échoué ne prouve rien.
- Le **comportement voisin du même objet** doit être testé dans le même
  chapitre : ici, l’annulation ET la frappe en cours. Corriger l’un en cassant
  l’autre est le mode d’échec normal, pas un accident rare.
- Un test ne doit **jamais fabriquer un événement que le produit n’émet pas**
  (leçon D-231/D-251) : une preuve obtenue sur un chemin inventé ne prouve
  rien du chemin de l’utilisateur.
- Un test **instable n’est pas à stabiliser mais à instruire** : sur machine
  lente, c’est souvent une course réelle qu’on n’a pas encore lue (D-249).

## Une information, un lieu (D-253)

Le piège répété de ce projet n’est pas d’écrire une mauvaise valeur, c’est
d’en écrire une **bonne à un second endroit** : la copie survit à l’original
et rien ne le signale (D-250 — trois états contradictoires du même numéro).

- Une valeur a **un seul lieu d’écriture**. Toute autre mention la **dérive**
  ou n’existe pas.
- Ne jamais créer une seconde liste « pour l’affichage » : deux listes de la
  même chose finissent toujours par diverger (D-252).
- Une duplication qu’on ne peut pas supprimer se **rattache par une garde
  exécutable**, jamais par une consigne — une garde que rien n’exécute est une
  consigne de plus.
- `npm run verifier:references` tient cette règle pour les versions ; y
  **ajouter un cas** dès qu’une information se met à vivre à deux endroits.

## En cas de doute, demander

Demander **avant d’écrire**, et non après avoir livré, quand : la nature ou le
cycle d’un objet n’est pas certain ; un correctif dépasse le défaut constaté ;
un choix engage le contenu, le format public ou ce que l’utilisateur voit ;
ou quand un rollback est une option défendable. Livrer sous hypothèse tacite
est ce qui coûte le plus cher ici.

## Fin d’une boucle

Une boucle est terminée seulement si :

- le comportement fonctionne de bout en bout ;
- le test ciblé est vert ;
- les non-régressions voisines sont vérifiées ;
- la **doc est amendée au fil de l’eau, dans le même commit** (règle
  `docs/conventions.md` §12) : `docs/systeme.md` si l’architecture ou un
  comportement change, `docs/workflows.md` si un parcours change,
  `docs/execution/QUALITY.md` pour la recette et les capacités ;
- `docs/execution/STATE.md` est à jour (le **présent** ne vit que là) ;
- la décision éventuelle est inscrite au journal (`docs/execution/DECISIONS.md`) ;
- un commit local vert existe.

Ne jamais laisser la doc « propre » (architecture, parcours) prendre du retard
sur le code : une boucle qui change le produit sans mettre à jour la doc qui
fait autorité sur ce sujet n’est pas verte.

## Fin d’un lot

Un lot est terminé seulement si ses critères obligatoires sont couverts, `npm run verifier` est vert, **les documents décrivent le réel** (aucun écart connu entre `docs/systeme.md`/`docs/workflows.md` et le code) et un checkpoint de lot est inscrit dans `STATE.md`.
