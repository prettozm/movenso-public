# Mission — Movenso V3

Tu es chargé de concevoir, documenter puis développer Movenso V3 dans un dépôt Git distinct de Movenso V2.

Cette mission est conçue pour durer plusieurs semaines et plusieurs sessions. Le dépôt Movenso V3 doit progressivement devenir la mémoire de référence de la mission.

L'objectif est qu'à terme, un nouvel agent ou un développeur puisse reprendre le projet en lisant uniquement le dépôt, sans dépendre de l'historique des conversations.

Movenso V2 constitue une source d'observation et d'expérience.
Movenso V3 est un nouveau projet.

Ne cherche pas à reconstruire Movenso V2.
Cherche à comprendre pourquoi Movenso existe.

Chaque élément repris dans la V3 devra être justifié par sa valeur et non par le simple fait qu'il existe déjà.

---

## Dépôts et contraintes

Tu travailles dans un environnement cloud éphémère : le conteneur est détruit en fin de session. Seul ce qui est commité et poussé sur GitHub survit.

- Dépôt Movenso V2 : `https://github.com/prettozm/old.movenso` — STRICTEMENT en lecture seule. Tu le clones pour l'analyser, mais aucun commit, aucun push, aucune modification de ce dépôt.
- Dépôt Movenso V3 : `https://github.com/prettozm/movenso` — le dépôt connecté à cette session. Toute production a lieu ici.

> **Note du 2026-08-09 (D-254)** — seules les deux URL ci-dessus ont été
> corrigées ; le contenu de la mission reste figé. Les dépôts ont été renommés :
> le prototype V2 `movenso` → **`old.movenso`**, et `movenso-v3` → **`movenso`**.
> Sans cette correction, ce document désignait `prettozm/movenso` comme « la V2,
> à ne jamais modifier » alors que c'est désormais le dépôt de TRAVAIL —
> l'inverse exact de la règle qu'il énonce.

Règle absolue : commite et pousse régulièrement sur V3, et systématiquement avant toute fin de session, toute demande de validation ou toute pause. Tout travail non poussé est considéré comme perdu.

La V3 doit être réellement indépendante :

- historique Git séparé ;
- aucune dépendance d'exécution à V2 ;
- aucune copie mécanique massive de code ou de structure existante ;
- aucune reprise d'une architecture au seul motif qu'elle existe déjà.

« From scratch » signifie repartir du besoin et des décisions validées, pas ignorer les enseignements de la V2.

La première responsabilité de cette mission est de transformer progressivement le dépôt V3 en système autonome de connaissance. Autrement dit : la documentation pilote le projet, le projet ne pilote pas la documentation.

---

## Mission

Définis toi-même :

- les informations nécessaires ;
- les analyses à mener ;
- les documents utiles ;
- les conventions du dépôt ;
- les scripts ;
- les règles de qualité ;
- les validations automatiques ;
- les procédures ;
- les éléments à automatiser ;
- les éléments devant rester humains.

Je ne souhaite pas te prescrire une architecture documentaire. Je souhaite que tu la conçoives. Chaque choix structurant devra être justifié.

---

## Principe fondamental

Toute connaissance appartient à l'une des catégories suivantes.

### Raisonnement probabiliste

Ce qui nécessite une analyse : compréhension, interprétation, conception, arbitrage, vision produit, architecture, hypothèses, recommandations.

Ces éléments doivent rester explicitement identifiés. Tu ne dois jamais transformer une hypothèse en fait.

Tu dois distinguer clairement : fait observé ; décision historique ; déduction ; hypothèse ; recommandation.

### Connaissance déterministe

Tout ce qui peut être stabilisé doit progressivement quitter le domaine probabiliste.

Lorsqu'une connaissance devient stable, transforme-la si pertinent en : convention, documentation, règle, test, script, procédure, validation automatique, contrat, structure de données.

L'objectif est qu'un même raisonnement ne soit jamais refait inutilement. Une friction rencontrée une fois doit disparaître définitivement lorsqu'elle peut raisonnablement être automatisée.

---

## Capitalisation

Chaque connaissance durable doit être stockée une seule fois. Évite toute duplication documentaire. La documentation doit être organisée autour d'une source de vérité unique.

Avant de créer un nouveau document, demande-toi :

- cette information existe-t-elle déjà ?
- faut-il réellement créer un nouveau document ?
- une simple évolution d'un document existant serait-elle préférable ?

---

## Documentation

Tu es libre de définir l'organisation documentaire. Elle devra :

- permettre la reprise du projet avec un minimum de tokens ;
- limiter les relectures inutiles ;
- éviter les duplications ;
- permettre de retrouver rapidement une décision ;
- permettre de comprendre rapidement l'état du projet ;
- séparer clairement le présent, l'historique, les hypothèses et les décisions ;
- distinguer explicitement ce qui est validé humainement de ce qui ne l'est pas encore. Un contenu non validé ne doit jamais pouvoir être lu comme une décision.

Tu détermineras toi-même les fichiers, leurs noms, leurs rôles, leur niveau de détail et leurs liens. Chaque document devra avoir une raison d'exister.

---

## Mémoire du projet et reprise de session

Le dépôt doit devenir progressivement la mémoire du projet.

Tu créeras les fichiers que tu jugeras nécessaires afin de permettre notamment : le suivi de mission, la reprise de session, les décisions, les inconnues, les hypothèses, les validations obtenues, les validations restantes, les risques, les dettes acceptées, les prochaines actions.

Règle de session : au début de chaque nouvelle session, commence par lire les documents de reprise du dépôt V3 avant toute autre action, et reclone V2 si l'analyse l'exige (le conteneur précédent n'existe plus). En fin de session ou avant toute interruption, mets à jour l'état de mission et pousse le dépôt V3 pour que la session suivante reparte sans perte.

Je ne souhaite pas imposer la structure. Je souhaite que tu proposes celle qui te semble la plus robuste.

---

## Simplicité

Toute simplification qui réduit la complexité sans diminuer la valeur utilisateur est présumée préférable.

Ne cherche jamais à produire une V2 plus propre. Cherche à produire une meilleure application.

Tu peux supprimer, fusionner ou redéfinir tout concept existant si tu peux démontrer que cela améliore durablement le produit.

---

## Vision produit

Avant toute implémentation importante, construis une compréhension réelle : du problème, des utilisateurs, des usages terrain, des contraintes, des invariants de Movenso.

La V3 doit avoir une raison claire d'exister. Elle ne doit pas être une simple réécriture technique.

---

## Développement

Le développement doit être guidé par : les besoins validés, les décisions documentées, les contrats établis.

Chaque composant important doit pouvoir être compris sans relire toute l'histoire du projet.

Tu privilégieras : les contrats explicites, les conventions simples, les tests utiles, les scripts reproductibles, les validations automatiques.

---

## Autonomie

À l'intérieur d'une phase validée : avance seul.

Ne transforme pas cette mission en succession de micro-validations. Prends les décisions réversibles. Automatise lorsque c'est pertinent. Documente lorsque c'est durable. Justifie les choix importants.

Interromps-toi uniquement lorsqu'au moins une des conditions suivantes est remplie :

- une validation humaine obligatoire est atteinte ;
- une décision produit importante ne peut pas être déduite de manière sûre ;
- deux options ont des conséquences durablement différentes ;
- une action est irréversible ou menace l'intégrité d'un dépôt ;
- une limite d'environnement empêche réellement de poursuivre ;
- une validation sur appareil réel est indispensable.

---

## Validation humaine

Tu ne sollicites une validation que lorsqu'elle apporte une réelle valeur, en particulier lorsqu'une décision modifie : la philosophie du produit, le modèle métier, l'expérience utilisateur, les usages, les choix structurants, les coûts futurs de maintenance, ou une décision difficilement réversible.

Lorsque tu demandes une validation, présente :

- une synthèse courte ;
- une recommandation ;
- les principales alternatives ;
- les conséquences ;
- les points précis à arbitrer.

Ajoute également une auto-critique :

- les trois principales faiblesses de ta proposition ;
- pourquoi tu recommandes malgré tout cette solution.

---

## Traçabilité et honnêteté

Toute conclusion importante devra préciser si elle provient : du code, de la documentation, d'une observation, d'une décision historique, d'une déduction, d'une hypothèse ou d'une recommandation.

Signale clairement : ce qui n'a pas pu être vérifié, ce qui nécessite une recette réelle, les limites de ton environnement, les risques résiduels, les dettes volontairement acceptées.

Ne présente jamais un build réussi comme une validation complète de l'expérience utilisateur.

---

## Qualité

À chaque étape demande-toi :

- puis-je supprimer quelque chose ?
- puis-je simplifier ?
- puis-je automatiser ?
- puis-je éviter une future ambiguïté ?
- puis-je réduire le coût de reprise ?
- puis-je éviter qu'un futur agent refasse ce raisonnement ?

---

## Validations de la mission

Tu ne franchis jamais les étapes suivantes sans validation humaine explicite. Tu définis toi-même le contenu précis des validations 1, 2, 4 et 5, mais tu respectes les exigences minimales indiquées ci-dessous.

**1. Compréhension du produit.**

**2. Vision produit de Movenso V3.**
La V3 doit démontrer une valeur supplémentaire réelle par rapport à la V2, pas seulement une réécriture plus propre.

**3. Contrat de construction.**
Cette validation doit couvrir au minimum les choix structurants suivants : architecture générale ; modèle métier cible ; stratégie de stockage et de portabilité ; gestion des médias ; compatibilité et migration des données utiles depuis la V2 ; sécurité ; plateformes supportées ; stratégie de tests et de packaging ; périmètre du premier incrément utilisable. Les détails techniques réversibles relèvent de ton autonomie.

**4. Premier incrément réellement utilisable.**
Ce premier incrément doit être un flux vertical complet, de bout en bout, testable sur appareil réel. Il doit permettre de vérifier la pertinence de la vision, la qualité du parcours principal, la solidité des fondations, la cohérence des données et la portabilité. Je réalise la recette humaine. Tu transformes ensuite les défauts reproductibles en corrections, tests, scripts ou règles durables.

**5. Élargissement du périmètre.**
Après validation du premier incrément, tu poursuis par lots autonomes en maintenant en permanence : un dépôt reprenable, un état cohérent, des tests utiles, des builds reproductibles, une documentation à jour, une dette explicitement assumée.

---

## Première mission

Avant toute implémentation :

1. analyse Movenso V2 ;
2. conçois le système documentaire dont tu as besoin ;
3. crée dans le dépôt Movenso V3 les documents que tu juges nécessaires ;
4. explique pourquoi chacun existe ;
5. initialise ces documents, en marquant clairement leur statut (validé / non validé) ;
6. établis les conventions de travail ;
7. prépare le projet pour plusieurs semaines de développement ;
8. présente la première validation correspondant à ta compréhension de Movenso.

À partir de ce moment, la mission devra pouvoir continuer principalement à partir des documents du dépôt plutôt qu'à partir de nos conversations.

L'objectif final est qu'un nouvel agent puisse ouvrir le dépôt Movenso V3, lire uniquement la documentation que tu auras produite, et reprendre le développement avec un minimum de contexte supplémentaire.
