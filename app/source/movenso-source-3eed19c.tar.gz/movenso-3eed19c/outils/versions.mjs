/**
 * Lit les versions courantes DEPUIS LEURS SOURCES (D-253) — aucun numéro
 * n'est recopié dans la documentation, donc il faut un moyen de les voir.
 *
 *   npm run versions
 *
 * Le catalogue des packs vit dans l'autre dépôt (`movenso-public`) : s'il est
 * cloné à côté, ses versions s'affichent ; sinon on le dit, on ne devine pas.
 */
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const RACINE = join(dirname(fileURLToPath(import.meta.url)), "..");
const lire = (p) => readFile(p, "utf8");

const pkg = JSON.parse(await lire(join(RACINE, "package.json")));
console.log(`\napplication            ${pkg.version}   (package.json)`);

const constante = async (fichier, nom) => {
  const m = (await lire(join(RACINE, fichier))).match(new RegExp(`${nom}\\s*=\\s*(\\d+)`));
  return m ? m[1] : "?";
};
console.log(`schéma de données      ${await constante("src/domaine/modele.ts", "VERSION_SCHEMA")}       (src/domaine/modele.ts)`);
console.log(`conteneur .movpack     ${await constante("src/echange/movpack.ts", "VERSION_MOVPACK")}       (src/echange/movpack.ts)`);

const CANDIDATS = [
  join(RACINE, "..", "movenso-public", "packs", "index.json"),
  "/workspace/movenso-public/packs/index.json",
];
let catalogue = null;
let source = null;
for (const c of CANDIDATS) {
  try { catalogue = JSON.parse(await lire(c)); source = c; break; } catch { /* suivant */ }
}

if (!catalogue) {
  console.log("\npacks                  catalogue introuvable — cloner movenso-public à côté pour les lire");
  console.log("                       (source unique : movenso-public/packs/index.json)\n");
} else {
  console.log(`\npacks publiés          (${source})`);
  for (const p of catalogue) console.log(`  ${String(p.title).padEnd(22)}${p.version}`);
  console.log("");
}
