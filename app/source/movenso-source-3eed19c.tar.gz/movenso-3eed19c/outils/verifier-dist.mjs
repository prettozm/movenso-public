// Vérification du contenu du build (S1.2, D-162) — le dossier dist/ publié
// ne doit contenir QUE l'app compilée : ni source, ni sourcemap, ni secret,
// ni donnée locale. Échoue (exit 1) à la moindre anomalie ; la CI et
// `npm run verifier` l'exécutent après chaque build.
import { readdir, readFile, stat } from "node:fs/promises";
import { join, extname, relative } from "node:path";

const RACINE = new URL("../dist", import.meta.url).pathname;

// Liste blanche : tout fichier hors de ces extensions est un intrus.
const EXTENSIONS_PERMISES = new Set([".html", ".js", ".css", ".svg", ".png", ".ico", ".woff2"]);
// Interdits explicites, quel que soit le contexte.
const EXTENSIONS_INTERDITES = new Set([".map", ".ts", ".tsx", ".json", ".env", ".md", ".sh", ".zip", ".movpack"]);
// Motifs de secrets/chemins locaux dans les fichiers texte.
const MOTIFS_SUSPECTS = [
  { motif: /-----BEGIN [A-Z ]*PRIVATE KEY-----/, nom: "clé privée PEM" },
  { motif: /AKIA[0-9A-Z]{16}/, nom: "clé AWS" },
  { motif: /gh[pousr]_[A-Za-z0-9]{20,}/, nom: "jeton GitHub" },
  { motif: /\/home\/[a-z0-9_-]+\//i, nom: "chemin local absolu" },
  { motif: /node_modules\//, nom: "référence node_modules" },
];

async function lister(dossier) {
  const resultat = [];
  for (const entree of await readdir(dossier, { withFileTypes: true })) {
    const chemin = join(dossier, entree.name);
    if (entree.isDirectory()) resultat.push(...(await lister(chemin)));
    else resultat.push(chemin);
  }
  return resultat;
}

const erreurs = [];
let fichiers;
try {
  fichiers = await lister(RACINE);
} catch {
  console.error("verifier-dist : dist/ absent — lancer `npm run build` d'abord.");
  process.exit(1);
}

if (!fichiers.some((f) => relative(RACINE, f) === "index.html"))
  erreurs.push("index.html absent de dist/");

for (const chemin of fichiers) {
  const rel = relative(RACINE, chemin);
  const ext = extname(rel).toLowerCase();
  const nom = rel.split("/").pop();

  // 1) Emplacement : uniquement la racine et assets/ (pas d'arborescence surprise).
  const dossier = rel.includes("/") ? rel.slice(0, rel.lastIndexOf("/")) : "";
  if (dossier !== "" && dossier !== "assets") erreurs.push(`emplacement inattendu : ${rel}`);

  // 2) Extension : liste blanche stricte + interdits nommés.
  if (nom.startsWith(".")) erreurs.push(`fichier caché : ${rel}`);
  else if (EXTENSIONS_INTERDITES.has(ext)) erreurs.push(`extension interdite (${ext}) : ${rel}`);
  else if (!EXTENSIONS_PERMISES.has(ext)) erreurs.push(`extension hors liste blanche (${ext}) : ${rel}`);

  // 3) Contenu des fichiers texte : aucun secret, aucun chemin local.
  if ([".html", ".js", ".css", ".svg"].includes(ext)) {
    const texte = await readFile(chemin, "utf8");
    for (const { motif, nom: quoi } of MOTIFS_SUSPECTS)
      if (motif.test(texte)) erreurs.push(`${quoi} détecté dans ${rel}`);
    if (ext === ".html" && /src=["'][^"']*\/src\//.test(texte))
      erreurs.push(`index.html référence les sources (src/) : ${rel}`);
  }

  // 4) Aucun fichier vide (build tronqué).
  if ((await stat(chemin)).size === 0) erreurs.push(`fichier vide : ${rel}`);
}

// 5) BUDGET du bundle (S3.A10, D-198) : le poids total de dist/ reste sous un
// plafond calibré (~685 Ko mesurés au moment du calibrage + ~30 % de marge).
// Empêche l'inflation silencieuse (dépendance lourde, asset oublié) — se
// recalibre par DÉCISION si une évolution légitime le franchit.
const BUDGET_DIST_OCTETS = 900_000;
let totalOctets = 0;
for (const chemin of fichiers) totalOctets += (await stat(chemin)).size;
if (totalOctets > BUDGET_DIST_OCTETS)
  erreurs.push(`poids total de dist/ : ${totalOctets} octets > budget ${BUDGET_DIST_OCTETS} (S3.A10 — recalibrer par décision ou dégraisser)`);

if (erreurs.length) {
  console.error(`verifier-dist : ${erreurs.length} anomalie(s) dans dist/ :`);
  for (const e of erreurs) console.error("  - " + e);
  process.exit(1);
}
console.log(`verifier-dist : dist/ propre (${fichiers.length} fichiers, extensions et contenus contrôlés, ${Math.round(totalOctets / 1000)} Ko ≤ budget ${BUDGET_DIST_OCTETS / 1000} Ko).`);
