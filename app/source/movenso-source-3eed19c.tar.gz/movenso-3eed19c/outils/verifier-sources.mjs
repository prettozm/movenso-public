// Garde-fou statique des sources — quatre contrôles :
// (1) injection HTML (S1.11, D-166) : aucun nouveau vecteur ne doit entrer
//     dans src/ — innerHTML/outerHTML en écriture, insertAdjacentHTML,
//     document.write, eval. La liste des exceptions JUSTIFIÉES est vide
//     depuis la conversion de la Mindmap en éléments SVG typés.
// (2) ordre des COUCHES (S3.A6, D-176) : le domaine est PUR — il n'importe
//     jamais app/echange/stockage/securite ; echange/stockage/securite
//     n'importent jamais app. Sens autorisé : app → (echange|stockage|
//     securite) → domaine.
// (3) CYCLES d'import (S3.A10, D-198) : aucun cycle d'import RUNTIME entre
//     modules de src/ — `import type` (liaison effacée à la compilation) est
//     ignoré, `export … from` compte comme une arête. Les cycles hérités des
//     découpages A3/A4 ont été cassés par les modules *-commun.
// (4) BUDGET de taille (S3.A10, D-198 — l'esprit d'A11) : aucun fichier de
//     src/ ne dépasse 2 000 lignes — empêche la dette des fichiers-monde
//     (racine.ts, 4 018 l. avant A1) de se reformer.
import { readdir, readFile } from "node:fs/promises";
import { join, relative, dirname, normalize } from "node:path";

const LIGNES_MAX = 2000;

const RACINE = new URL("../src", import.meta.url).pathname;
const MOTIFS = [
  { motif: /\.innerHTML\s*=|\.outerHTML\s*=/, nom: "affectation innerHTML/outerHTML" },
  { motif: /insertAdjacentHTML\s*\(/, nom: "insertAdjacentHTML" },
  { motif: /document\.write\s*\(/, nom: "document.write" },
  { motif: /\beval\s*\(|new Function\s*\(/, nom: "eval / new Function" },
];
/** Exceptions justifiées : chemin relatif → motif toléré. VIDE aujourd'hui. */
const EXCEPTIONS = new Map();

async function lister(dossier) {
  const resultat = [];
  for (const e of await readdir(dossier, { withFileTypes: true })) {
    const chemin = join(dossier, e.name);
    if (e.isDirectory()) resultat.push(...(await lister(chemin)));
    else if (/\.(ts|tsx|js|mjs)$/.test(e.name)) resultat.push(chemin);
  }
  return resultat;
}

/** Couches interdites par dossier source (S3.A6/D-176) : depuis la clé, on
 *  n'importe JAMAIS un des dossiers listés. */
const COUCHES_INTERDITES = new Map([
  ["domaine", ["app", "echange", "stockage", "securite"]],
  ["echange", ["app"]],
  ["stockage", ["app"]],
  ["securite", ["app"]],
]);

function coucheDe(rel) {
  const m = rel.match(/^src\/([^/]+)\//);
  return m ? m[1] : null;
}

/** Arêtes d'import RUNTIME d'un fichier : `import ... from "./x.ts"` et
 *  `export ... from "./x.ts"`, en ignorant les liaisons type-only
 *  (`import type`, `export type { } from`). Cibles relatives seulement. */
function aretesRuntime(chemin, texte) {
  const aretes = [];
  for (const ligne of texte.split("\n")) {
    const m = ligne.match(/^\s*(import|export)\s+(type\s+)?[^"']*from\s+["'](\.[^"']+)["']/);
    if (!m || m[2]) continue;
    aretes.push(normalize(join(dirname(chemin), m[3])));
  }
  return aretes;
}

const erreurs = [];
const graphe = new Map();
for (const chemin of await lister(RACINE)) {
  const rel = "src/" + relative(RACINE, chemin);
  const texte = await readFile(chemin, "utf8");
  for (const { motif, nom } of MOTIFS) {
    if (motif.test(texte) && EXCEPTIONS.get(rel) !== nom)
      erreurs.push(`${rel} : ${nom} — interdit sans justification (S1.11)`);
  }
  const interdits = COUCHES_INTERDITES.get(coucheDe(rel)) ?? [];
  for (const cible of interdits) {
    const motifImport = new RegExp(`from\\s+["'](?:\\.\\./)+${cible}/`);
    if (motifImport.test(texte))
      erreurs.push(`${rel} : import depuis src/${cible}/ — sens de couche interdit (S3.A6 : app → echange|stockage|securite → domaine)`);
  }
  // UN SEUL ÉCRIVAIN de la bibliothèque (S4.4/D-258) : `sauvegarder` porte la
  // bascule protégée (temporaire → relecture → revalidation) ET la file de
  // sérialisation. Toute autre écriture directe du fichier courant contourne
  // les deux — c'est ce que faisait la restauration, seul chemin d'écriture
  // sans protection, et il s'exerce quand l'utilisateur récupère d'un
  // problème. Une garde vaut mieux qu'une relecture : la prochaine écriture
  // directe se signalera d'elle-même.
  for (const [i, ligne] of texte.split("\n").entries()) {
    if (/\becrireTexte\s*\(\s*FICHIER_BIBLIOTHEQUE\b(?!_TMP)/.test(ligne) && !/dans `sauvegarder`/.test(ligne))
      erreurs.push(
        `${rel}:${i + 1} : écriture DIRECTE de bibliotheque.json — seule « sauvegarder » écrit l'état courant`
        + ` (bascule protégée + file, S4.4/D-258)`,
      );
  }

  const lignes = texte.split("\n").length;
  if (lignes > LIGNES_MAX)
    erreurs.push(`${rel} : ${lignes} lignes > budget ${LIGNES_MAX} (S3.A10 — découper avant que la dette ne se reforme)`);
  graphe.set(chemin, aretesRuntime(chemin, texte));
}

// Détection de cycles (DFS sur pile) — chaque cycle rapporté une seule fois.
{
  const vus = new Set();
  const cyclesVus = new Set();
  const dfs = (n, pile) => {
    vus.add(n);
    pile.push(n);
    for (const d of graphe.get(n) ?? []) {
      const i = pile.indexOf(d);
      if (i >= 0) {
        const cycle = pile.slice(i);
        const cle = [...cycle].sort().join("|");
        if (!cyclesVus.has(cle)) {
          cyclesVus.add(cle);
          const noms = [...cycle, d].map((x) => "src/" + relative(RACINE, x));
          erreurs.push(`cycle d'import runtime : ${noms.join(" → ")} (S3.A10 — extraire le partagé vers un module commun)`);
        }
      } else if (!vus.has(d)) dfs(d, pile);
    }
    pile.pop();
  };
  for (const n of graphe.keys()) if (!vus.has(n)) dfs(n, []);
}

// --- Noms de classe CSS partagés entre feuilles thématiques (D-232) ---
// Un nom de classe est une ressource GLOBALE : réemployer `.carte-technique`
// (grille de la bibliothèque) pour une carte de composition a rétréci toutes
// les vignettes de l'app. Les partages ci-dessous sont VOULUS (composants
// communs) ; tout partage NOUVEAU doit être un choix, pas un accident.
const PARTAGES_ATTENDUS = new Set([
  "action-douce", "actions", "bouton", "bouton-icone", "bouton-video", "champ-mini",
  "chip-filtre", "chips-filtres", "creation-discipline", "details", "ecran", "fil", "jp",
  "liaisons", "ligne-atelier", "media-legende", "media-principal", "media-video",
  "pastille", "points", "recherche", "resultat", "resultats", "titre-atelier",
  "vignette", "vignette-initiale", "voix-corps",
]);
{
  const dossier = join(RACINE, "styles");
  const parClasse = new Map();
  for (const nom of await readdir(dossier)) {
    if (!nom.endsWith(".css") || nom === "app.css") continue;
    const texte = (await readFile(join(dossier, nom), "utf8")).replace(/\/\*[\s\S]*?\*\//g, "");
    for (const m of texte.matchAll(/(^|[\s,>+~])\.([A-Za-z_][\w-]*)/g)) {
      const cle = m[2];
      if (!parClasse.has(cle)) parClasse.set(cle, new Set());
      parClasse.get(cle).add(nom);
    }
  }
  for (const [classe, feuilles] of parClasse)
    if (feuilles.size > 1 && !PARTAGES_ATTENDUS.has(classe))
      erreurs.push(
        `classe CSS « .${classe} » définie dans ${[...feuilles].sort().join(" et ")} — ` +
        `collision probable (D-232) : préfixer, ou l'ajouter à PARTAGES_ATTENDUS si le partage est voulu`,
      );
}

if (erreurs.length) {
  console.error(`verifier-sources : ${erreurs.length} problème(s) dans src/ :`);
  for (const e of erreurs) console.error("  - " + e);
  process.exit(1);
}
console.log(`verifier-sources : aucun vecteur d'injection HTML ; couches respectées (domaine pur) ; zéro cycle d'import runtime (${graphe.size} fichiers) ; tous les fichiers ≤ ${LIGNES_MAX} lignes ; aucune collision de classe CSS entre feuilles.`);
