/**
 * Assemble les packs convertis (comme le fait l'application au premier
 * lancement) et imprime le rapport de rapprochement : rejointes, créées,
 * suggestions à arbitrer. Sert à produire le lot compact d'arbitrage (D-015)
 * et à vérifier la table de règles avant embarquement.
 *
 *   node --experimental-strip-types tools/rapport-rapprochement.ts
 */

import { readFileSync } from "node:fs";
import { bibliothequeVide } from "../src/domaine/modele.ts";
import { migrerBibliotheque } from "../src/domaine/migrations.ts";
import { importerDansBibliotheque, type RegleRapprochement } from "../src/domaine/rapprochement.ts";

const PACKS = [
  { fichier: "donnees/kodokan.json", packId: "kodokan" },
  { fichier: "donnees/club-judo.json", packId: "club-judo" },
];

const table = JSON.parse(readFileSync("donnees/rapprochements-judo.json", "utf8")) as {
  regles: RegleRapprochement[];
};

let b = bibliothequeVide();
for (const { fichier, packId } of PACKS) {
  const pack = migrerBibliotheque(JSON.parse(readFileSync(fichier, "utf8")));
  const resultat = importerDansBibliotheque(b, pack, { packId, regles: table.regles });
  b = resultat.bibliotheque;
  const r = resultat.rapport;
  console.log(`\n=== ${packId} → discipline « ${r.discipline} »`);
  console.log(`rejointes : ${r.rejointes.length} · créées : ${r.creees.length} · retirées : ${r.retirees.length}`);
  if (r.suggestions.length) {
    console.log(`suggestions à arbitrer (${r.suggestions.length}) :`);
    for (const s of r.suggestions) console.log(`  - « ${s.nom} » ~ ${s.candidats.join(" / ")} (${s.motif})`);
  }
}
console.log(
  `\nBibliothèque assemblée : ${b.disciplines.length} discipline(s), ${b.techniques.length} identités, ${b.contributions.length} contributions`,
);
const multiVoix = b.techniques.filter(
  (t) => new Set(b.contributions.filter((c) => c.techniqueId === t.id).map((c) => c.origine?.pack)).size > 1,
);
console.log(`identités à plusieurs voix : ${multiVoix.length}`);
