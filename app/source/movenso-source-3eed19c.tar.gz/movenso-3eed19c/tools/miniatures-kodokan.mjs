#!/usr/bin/env node
/**
 * Récupère les miniatures des vidéos du pack Kodokan (D-088, point de départ des
 * illustrations par technique). Deux étapes :
 *   1. construit un MANIFESTE (une entrée par technique : slug, nom, id vidéo,
 *      URL de miniature) — déterministe, sans réseau ;
 *   2. télécharge chaque miniature dans `img/kodokan/<slug>.jpg` (maxres puis
 *      repli hqdefault).
 *
 * NB : l'egress de l'environnement Claude bloque YouTube (403 policy). Lancer ce
 * script depuis une machine à réseau ouvert : `node tools/miniatures-kodokan.mjs`.
 * Le manifeste, lui, est écrit même sans réseau.
 */
import fs from "node:fs";
import path from "node:path";

const RACINE = new URL("..", import.meta.url).pathname;
const PACK = path.join(RACINE, "donnees/kodokan.json");
const DOSSIER = path.join(RACINE, "img/kodokan");

function slug(nom) {
  return nom
    .normalize("NFD").replace(/[̀-ͯ]/g, "") // accents
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "technique";
}

const b = JSON.parse(fs.readFileSync(PACK, "utf8"));
const nomParId = new Map(b.techniques.map((t) => [t.id, t.nom]));
const principalParId = new Map(b.techniques.map((t) => [t.id, t.mediaPrincipalId]));

// Une illustration PAR TECHNIQUE : la vidéo mise en avant si définie, sinon la
// première vidéo YouTube rencontrée.
const parTechnique = new Map();
for (const c of b.contributions) {
  if (!c.techniqueId) continue;
  for (const m of c.medias) {
    if (m.type !== "plateforme" || m.service !== "youtube") continue;
    const prioritaire = principalParId.get(c.techniqueId) === m.id;
    const actuel = parTechnique.get(c.techniqueId);
    if (!actuel || prioritaire) parTechnique.set(c.techniqueId, m.ref);
  }
}

const vus = new Set();
const manifeste = [];
for (const [techniqueId, videoId] of parTechnique) {
  const nom = nomParId.get(techniqueId) ?? techniqueId;
  let s = slug(nom);
  let n = 2;
  while (vus.has(s)) s = `${slug(nom)}-${n++}`;
  vus.add(s);
  manifeste.push({
    slug: s,
    nom,
    techniqueId,
    videoId,
    fichier: `${s}.jpg`,
    urls: [
      `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`,
      `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    ],
  });
}

fs.mkdirSync(DOSSIER, { recursive: true });
fs.writeFileSync(path.join(DOSSIER, "manifest.json"), JSON.stringify(manifeste, null, 2));
console.log(`Manifeste écrit : ${manifeste.length} techniques → img/kodokan/manifest.json`);

// Étape 2 : téléchargement (ignorée proprement si le réseau bloque YouTube).
let ok = 0;
let echecs = 0;
for (const e of manifeste) {
  const cible = path.join(DOSSIER, e.fichier);
  let telecharge = false;
  for (const url of e.urls) {
    try {
      const r = await fetch(url);
      if (!r.ok) continue;
      const buf = Buffer.from(await r.arrayBuffer());
      if (buf.length < 2000) continue; // miniature « absente » (placeholder gris)
      fs.writeFileSync(cible, buf);
      telecharge = true;
      break;
    } catch {
      /* réseau indisponible → repli/échec géré ci-dessous */
    }
  }
  if (telecharge) ok++;
  else echecs++;
}
console.log(`Téléchargées : ${ok} · échecs : ${echecs}`);
if (echecs) console.log("→ Réseau YouTube bloqué ici ? Relance ce script sur une machine à réseau ouvert.");
