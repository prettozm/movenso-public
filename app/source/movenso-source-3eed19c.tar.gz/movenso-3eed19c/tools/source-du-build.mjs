/**
 * SOURCE CORRESPONDANTE du build publié (S4.7/D-265).
 *
 *   node tools/source-du-build.mjs [--vers <dossier-site>]
 *
 * La GPLv3 n'oblige pas à ouvrir le dépôt de travail : elle oblige à fournir,
 * à qui reçoit le binaire, **la source qui correspond à CE binaire**. Le site
 * déclare l'application sous GPL v3 et distribue une version web plus une APK ;
 * la source doit donc voyager avec elles.
 *
 * D'où le nom du fichier : il porte le **SHA du commit**, celui-là même que
 * l'application affiche dans Plus › À propos. On peut ainsi vérifier de
 * l'extérieur que la source proposée est bien celle du binaire servi — une
 * archive « dernière version » ne le permettrait pas.
 *
 * Contenu : tout ce que git suit, SAUF `donnees/images/` — ce sont les
 * illustrations des packs, des données de contenu qui n'entrent pas dans la
 * construction de l'application (le `dist/` n'en contient rien). Les exclure
 * fait passer l'archive de ~10 Mo à quelques centaines de Ko sans retirer une
 * ligne de ce qui est nécessaire pour rebâtir le binaire.
 */
import { execFileSync } from "node:child_process";
import { mkdirSync, writeFileSync, readFileSync } from "node:fs";
import { join } from "node:path";

const git = (...args) => execFileSync("git", args, { encoding: "utf8", maxBuffer: 1 << 28 }).trim();
const cible = process.argv.includes("--vers") ? process.argv[process.argv.indexOf("--vers") + 1] : null;

const RACINE = git("rev-parse", "--show-toplevel");
const sha = git("rev-parse", "--short", "HEAD");
const propre = git("status", "--porcelain") === "";
if (!propre) {
  console.error("source-du-build : le dépôt n'est pas propre — une source qui ne correspond à AUCUN commit");
  console.error("n'est pas une source correspondante. Committer d'abord.");
  process.exit(1);
}

// `git archive` produit l'arbre EXACT du commit : pas de fichier oublié, pas
// de fichier local en trop. Les images de packs sont écartées par attribut.
const fichiers = git("ls-files").split("\n").filter((f) => f && !f.startsWith("donnees/images/"));
const tar = execFileSync("tar", ["-czf", "-", "--transform", `s|^|movenso-${sha}/|`, "--", ...fichiers],
  { maxBuffer: 1 << 28 });

mkdirSync("dist-publication/source", { recursive: true });
const nom = `movenso-source-${sha}.tar.gz`;
writeFileSync(`dist-publication/source/${nom}`, tar);
console.log(`dist-publication/source/${nom} — ${(tar.length / 1024).toFixed(0)} Ko, ${fichiers.length} fichiers, commit ${sha}`);

if (cible) {
  mkdirSync(join(cible, "app", "source"), { recursive: true });
  writeFileSync(join(cible, "app", "source", nom), tar);

  // CARTE D'IDENTITÉ DU DÉPLOIEMENT (D-267) — ce que la garde du site lit pour
  // refuser une publication incohérente. Elle remplace l'ancien fichier
  // `COMMIT`, qui ne disait qu'une chose : un seul fichier, pas deux.
  //
  // Le SCHÉMA est ce qui compte le plus ici. Publier des packs en schéma N+1
  // devant une app restée en schéma N rend le catalogue INUTILISABLE — l'app
  // refuse les packs qu'on lui propose. La règle « app et packs partent
  // ensemble » cesse d'être une discipline et devient un refus mesurable.
  const modele = readFileSync(join(RACINE, "src/domaine/modele.ts"), "utf8");
  const movpack = readFileSync(join(RACINE, "src/echange/movpack.ts"), "utf8");
  const constante = (src, nom) => Number(src.match(new RegExp(`${nom}\\s*=\\s*(\\d+)`))?.[1]);
  const build = {
    version: JSON.parse(readFileSync(join(RACINE, "package.json"), "utf8")).version,
    commit: sha,
    versionSchema: constante(modele, "VERSION_SCHEMA"),
    versionMovpack: constante(movpack, "VERSION_MOVPACK"),
    source: `source/${nom}`,
  };
  writeFileSync(join(cible, "app", "build.json"), JSON.stringify(build, null, 1) + "\n");
  console.log(`déposé dans ${cible}/app/ — build.json : ${JSON.stringify(build)}`);
}
