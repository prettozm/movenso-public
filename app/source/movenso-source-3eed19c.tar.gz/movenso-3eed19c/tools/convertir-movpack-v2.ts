/**
 * Conversion d'un `.movpack` v2 (format V2) en bibliothèque V3 (JSON).
 * La compatibilité V2 est payée UNE FOIS ici, jamais dans l'application
 * (contrat §6). Usage :
 *
 *   node --experimental-strip-types tools/convertir-movpack-v2.ts \
 *     <entrée.movpack> <sortie.json> [--provenance referentiel|enseignement] [--attribution "Kodokan"]
 *
 * Sans vidéos locales : ce convertisseur traite les packs « métadonnées »
 * (vidéos en ligne référencées). Un pack V2 contenant des vidéos locales
 * sera refusé explicitement (à outiller le jour où le besoin existe).
 */

import { readFileSync, writeFileSync } from "node:fs";
import { unzipSync, strFromU8 } from "fflate";
import type { Bibliotheque, Contribution, Media, Relation, Technique } from "../src/domaine/modele.ts";
import { TYPES_RELATION_DEFAUT, VERSION_SCHEMA } from "../src/domaine/modele.ts";
import { genererUlid } from "../src/domaine/ulid.ts";
import { validerBibliotheque } from "../src/domaine/validation.ts";

/* ---------- formes V2 (le strict nécessaire, pas le format complet) ---------- */
interface V2VideoRef {
  file: string;
  label?: string;
  online?: boolean;
  url?: string;
  youtubeId?: string;
}
interface V2Technique {
  id: number | string;
  titre: string;
  nom_traditionnel?: string;
  famille: string;
  niveaux: string[];
  source?: string;
  videos: V2VideoRef[];
  desc?: string;
  points?: string[];
  variantes?: string;
  relations?: Partial<Record<"prepare_par" | "continue_vers" | "contre_par" | "similaire_a", (number | string)[]>>;
}
interface V2Pack {
  schemaVersion: number;
  discipline: { id: string; label: string };
  familles: { id: string; label: string; ordre?: number }[];
  niveaux: { id: string; label: string; ordre?: number; couleur?: string; couleur2?: string }[];
  sources?: { id: string; label: string }[];
  techniques: V2Technique[];
}

/* ---------- conversion ---------- */
function convertirMedia(v: V2VideoRef): Media {
  const base = { id: genererUlid(), ...(v.label !== undefined ? { label: v.label } : {}) };
  if (v.youtubeId) return { ...base, type: "plateforme", service: "youtube", ref: v.youtubeId };
  if (v.online && v.url) return { ...base, type: "lien", ref: v.url };
  throw new Error(
    `Vidéo locale « ${v.file} » : ce convertisseur ne traite que les packs à vidéos en ligne (à outiller si besoin réel)`,
  );
}

export function convertirPackV2(
  pack: V2Pack,
  options: {
    provenance: "referentiel" | "enseignement";
    attribution: string;
    creeLe: string;
    /** Identifiant stable du pack (clé de traçabilité/idempotence, D-015). */
    packId: string;
    /** Nom de la discipline cible (la pratique, D-013) — ex. « Judo ». */
    discipline?: string;
  },
): Bibliotheque {
  const disciplineId = genererUlid();
  // Ids V2 (numériques ou slugs) → ULID, mapping conservé pour les relations.
  const idV3 = new Map<string, string>();
  for (const t of pack.techniques) idV3.set(String(t.id), genererUlid());

  const avertissements: string[] = [];
  const techniques: Technique[] = [];
  const contributions: Contribution[] = [];

  for (const t of pack.techniques) {
    const id = idV3.get(String(t.id))!;
    // Relations V2 → V3 : V3 stocke « source → type → cible » ; les formes
    // inverses de V2 (prepare_par, contre_par) se posent donc sur l'autre technique.
    const relations: Relation[] = [];
    const poserSur = (proprietaireV2: number | string, type: Relation["type"], cibleV2: number | string) => {
      const proprietaire = idV3.get(String(proprietaireV2));
      const cible = idV3.get(String(cibleV2));
      if (!proprietaire || !cible) {
        avertissements.push(`relation ${String(proprietaireV2)} ${type} ${String(cibleV2)} : cible hors du pack, ignorée`);
        return;
      }
      if (proprietaire === id) relations.push({ type, cibleId: cible });
      else {
        const autre = techniques.find((x) => x.id === proprietaire);
        autre?.relations.push({ type, cibleId: cible });
      }
    };
    for (const cible of t.relations?.continue_vers ?? []) poserSur(t.id, "enchaine", cible);
    for (const cible of t.relations?.similaire_a ?? []) poserSur(t.id, "similaire", cible);
    for (const source of t.relations?.prepare_par ?? []) poserSur(source, "prepare", t.id);
    for (const source of t.relations?.contre_par ?? []) poserSur(source, "contre", t.id);

    techniques.push({
      id,
      disciplineId,
      nom: t.titre,
      ...(t.nom_traditionnel ? { nomTraditionnel: t.nom_traditionnel } : {}),
      familleId: t.famille,
      niveauxIds: t.niveaux ?? [],
      relations,
      origine: { pack: options.packId, element: String(t.id) },
    });

    const sourceLabel = pack.sources?.find((s) => s.id === t.source)?.label;
    contributions.push({
      id: genererUlid(),
      techniqueId: id,
      provenance: options.provenance,
      ...(t.desc ? { description: t.desc } : {}),
      pointsCles: t.points ?? [],
      ...(t.variantes ? { variantes: t.variantes } : {}),
      attribution: sourceLabel ?? options.attribution,
      creeLe: options.creeLe,
      medias: t.videos.map(convertirMedia),
      origine: { pack: options.packId, element: String(t.id) },
    });
  }

  const bibliotheque: Bibliotheque = {
    versionSchema: VERSION_SCHEMA,
    typesRelation: TYPES_RELATION_DEFAUT.map((t) => ({ ...t })),
    compositions: [],
    disciplines: [
      {
        id: disciplineId,
        nom: options.discipline ?? pack.discipline.label,
        familles: pack.familles.map((f) => ({ id: f.id, nom: f.label, ...(f.ordre !== undefined ? { ordre: f.ordre } : {}) })),
        niveaux: pack.niveaux.map((n) => ({
          id: n.id,
          nom: n.label,
          ...(n.ordre !== undefined ? { ordre: n.ordre } : {}),
          ...(n.couleur ? { couleur: n.couleur } : {}),
          ...(n.couleur2 ? { couleur2: n.couleur2 } : {}),
        })),
      },
    ],
    techniques,
    contributions,
  };
  validerBibliotheque(bibliotheque);
  if (avertissements.length) console.warn("Avertissements :\n - " + avertissements.join("\n - "));
  return bibliotheque;
}

/* ---------- lecture du conteneur .movpack v2 ---------- */
export function lireMovpackV2(octets: Uint8Array): V2Pack[] {
  const fichiers = unzipSync(octets);
  const manifest = fichiers["manifest.json"];
  if (!manifest) throw new Error("manifest.json absent : pas un .movpack");
  const m = JSON.parse(strFromU8(manifest)) as { format?: string; version?: number; containsVideos?: boolean };
  if (m.format !== "movenso-pack" || m.version !== 2) {
    throw new Error(`Format non géré (format=${m.format}, version=${m.version}) : seul le .movpack v2 est converti`);
  }
  if (m.containsVideos) throw new Error("Pack avec vidéos locales : non géré par ce convertisseur (cf. en-tête)");
  return Object.entries(fichiers)
    .filter(([nom]) => nom.startsWith("packs/") && nom.endsWith(".json"))
    .map(([, contenu]) => JSON.parse(strFromU8(contenu)) as V2Pack);
}

/* ---------- ligne de commande ---------- */
if (process.argv[1]?.endsWith("convertir-movpack-v2.ts")) {
  const [entree, sortie] = process.argv.slice(2);
  if (!entree || !sortie) {
    console.error("Usage : convertir-movpack-v2.ts <entrée.movpack> <sortie.json> [--provenance …] [--attribution …]");
    process.exit(1);
  }
  const lireOption = (nom: string, defaut: string) => {
    const i = process.argv.indexOf(`--${nom}`);
    return i > -1 ? process.argv[i + 1] ?? defaut : defaut;
  };
  const provenance = lireOption("provenance", "referentiel") as "referentiel" | "enseignement";
  const attribution = lireOption("attribution", "Source du pack V2");
  const packId = lireOption("pack", "");
  const discipline = lireOption("discipline", "");
  if (!packId) throw new Error("--pack <id stable> est requis (traçabilité D-015)");
  const packs = lireMovpackV2(readFileSync(entree));
  if (packs.length !== 1) throw new Error(`${packs.length} packs dans le conteneur : gérer un par un`);
  const b = convertirPackV2(packs[0]!, {
    provenance,
    attribution,
    creeLe: new Date().toISOString(),
    packId,
    ...(discipline ? { discipline } : {}),
  });
  writeFileSync(sortie, JSON.stringify(b, null, 1) + "\n");
  console.log(
    `Écrit ${sortie} : ${b.techniques.length} techniques, ${b.contributions.length} contributions (${provenance}, « ${attribution} »)`,
  );
}
