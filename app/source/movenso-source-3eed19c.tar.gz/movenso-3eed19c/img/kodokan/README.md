# Miniatures Kodokan — référence de travail (D-088)

Ces images sont les **miniatures des vidéos YouTube** référencées par le pack
`donnees/kodokan.json` (une par technique, cf. `manifest.json`).

**Comment les obtenir** (les `.jpg` ne sont PAS versionnés ici) :
- **En local** (réseau ouvert, ex. WSL) : `node tools/miniatures-kodokan.mjs`
  → remplit ce dossier ; l'egress de la session Claude bloque YouTube, donc ça
  ne peut pas se faire depuis l'agent.
- **Par la CI** : le workflow `miniatures.yml` (une fois la branche dans `main`)
  publie un artefact `miniatures-kodokan`.
Seuls `manifest.json` (la liste) et ce README sont versionnés.

⚠️ **Statut juridique — à lire avant toute diffusion.**
Ces vignettes sont la **propriété de leurs auteurs / du Kodokan** (droit
d'auteur). Elles sont conservées ici uniquement comme **référence de travail
privée** — pour concevoir des illustrations. Elles **ne doivent pas** être
publiées telles quelles, ni « dérivées » (retouchées) dans une app distribuée,
sans autorisation. La voie sûre : des **illustrations originales** (créées, pas
tracées à partir de ces images) + des **liens d'intégration** (embed) vers les
vidéos officielles. Voir la discussion réglementation.
