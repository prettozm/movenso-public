/**
 * Garde « une information, un lieu » (D-253).
 *
 * Le piège récurrent de ce projet n'est pas d'écrire un mauvais numéro, c'est
 * d'en écrire un BON à un second endroit : la copie survit à l'original et
 * personne ne le voit. D-250 en est l'exemple complet — cinq packs publiés,
 * un catalogue web resté en arrière, un registre encore à `0.1.0`, trois
 * états contradictoires et aucun signal.
 *
 * Cette garde refuse la recopie là où elle s'est déjà produite :
 *
 *  1. `docs/versions.md` est une CARTE des références, pas un registre de
 *     valeurs : aucun numéro de version ne doit y figurer.
 *  2. La version de l'app n'est écrite que dans `package.json` — aucun autre
 *     fichier suivi ne doit la porter en dur.
 *  3. L'adresse du dépôt est la BONNE : `movenso-v3` n'existe plus (D-254).
 *  4. Les versions de FORMAT ne sont écrites que dans leur constante de code.
 *
 * Ajouter un cas ici quand une information se met à vivre à deux endroits :
 * c'est le seul endroit où l'on peut le dire une fois pour toutes.
 */
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { execFileSync } from "node:child_process";

const RACINE = join(dirname(fileURLToPath(import.meta.url)), "..");
const problemes = [];
const lire = (p) => readFile(join(RACINE, p), "utf8");
/** Un fichier SUIVI par git peut avoir été supprimé du disque sans que la
 *  suppression soit encore indexée — c'est un état normal en cours de travail,
 *  pas un défaut. La garde l'ignore au lieu de s'interrompre : une garde qui
 *  plante ne garde rien. */
const lireSiPresent = async (p) => { try { return await lire(p); } catch { return null; } };

/* ---------- 1. versions.md ne porte aucune valeur ---------- */

const versionsMd = await lire("docs/versions.md");
// On ignore le bloc de citation d'en-tête, qui EXPLIQUE la règle en citant
// l'incident (« encore à 0.1.0 ») — l'exemple n'est pas une déclaration.
const corps = versionsMd
  .split("\n")
  .filter((l) => !l.startsWith(">"))
  .join("\n");
const litteraux = [...corps.matchAll(/(?<![\w.-])\d+\.\d+\.\d+(?:-[\w.]+)?(?![\w.-])/g)].map((m) => m[0]);
// `0.1.0` est cité comme CONVENTION de démarrage, pas comme état d'un pack.
const interdits = litteraux.filter((v) => v !== "0.1.0");
if (interdits.length)
  problemes.push(
    `docs/versions.md porte ${interdits.length} numéro(s) de version : ${[...new Set(interdits)].join(", ")}.\n`
    + `    Ce fichier dit OÙ vivent les versions, il ne les recopie pas (D-253).\n`
    + `    La valeur courante se lit avec « npm run versions ».`,
  );

/* ---------- 2. la version de l'app n'est écrite qu'une fois ---------- */

const versionApp = JSON.parse(await lire("package.json")).version;
// Fichiers suivis par git, hors verrou npm (généré) et hors cet outil.
const suivis = execFileSync("git", ["ls-files"], { cwd: RACINE, encoding: "utf8" })
  .split("\n")
  .filter(Boolean)
  .filter((f) => !["package.json", "package-lock.json", "outils/verifier-references.mjs"].includes(f))
  .filter((f) => /\.(ts|mjs|js|json|md|html|ya?ml)$/.test(f))
  // Le journal des décisions et le présent RACONTENT l'histoire : « app 0.9.0-rc.1 »
  // y est un fait daté, pas une référence que l'on met à jour.
  .filter((f) => !["docs/execution/DECISIONS.md", "docs/execution/STATE.md"].includes(f))
  .filter((f) => !f.startsWith("docs/archives/"));

for (const f of suivis) {
  const contenu = await lireSiPresent(f);
  if (contenu?.includes(versionApp))
    problemes.push(`${f} porte la version de l'app en dur (« ${versionApp} ») — elle ne s'écrit que dans package.json.`);
}

/* ---------- 3. l'adresse du dépôt : une seule, la bonne (D-254) ---------- */

// Le dépôt de l'app a été renommé `movenso-v3` → `movenso` le 2026-08-09, et
// le prototype V2 `movenso` → `old.movenso`. GitHub redirige l'ancienne
// adresse, donc un lien périmé « marche » — c'est précisément ce qui le rend
// durable et faux. Pire : `prettozm/movenso` DÉSIGNAIT la V2 en lecture seule
// et désigne maintenant le dépôt de travail ; un document resté à l'ancienne
// lecture dit l'exact inverse de la règle qu'il énonce.
for (const f of suivis) {
  const contenu = await lireSiPresent(f);
  if (contenu?.includes("github.com/prettozm/movenso-v3"))
    problemes.push(`${f} pointe encore sur github.com/prettozm/movenso-v3 — le dépôt s'appelle « movenso » depuis le 2026-08-09 (D-254).`);
}

/* ---------- 4. les Actions sont épinglées par SHA (S4.13/D-265) ---------- */

// Un tag comme `@v4` est MUTABLE : qui contrôle le dépôt de l'action — ou qui
// en compromet le compte — peut le faire pointer vers du code différent, qui
// s'exécutera ensuite dans notre CI avec le jeton du dépôt. Un SHA complet est
// immuable. Le coût assumé : les mises à jour deviennent manuelles, et c'est
// justement ce qu'on veut d'une dépendance qui s'exécute chez nous.
for (const f of suivis.filter((f) => f.startsWith(".github/workflows/"))) {
  const contenu = (await lireSiPresent(f)) ?? "";
  for (const [i, ligne] of contenu.split("\n").entries()) {
    const m = ligne.match(/uses:\s*([^\s#]+)/);
    if (!m) continue;
    const ref = m[1];
    if (ref.startsWith("./")) continue; // action locale : pas de tiers, rien à épingler
    if (!/@[0-9a-f]{40}$/.test(ref))
      problemes.push(`${f}:${i + 1} : action « ${ref} » non épinglée — un tag est mutable, exiger un SHA complet (S4.13)`);
  }
}

/* ---------- 5. les versions de format ne vivent qu'en constante ---------- */

const formats = [
  { nom: "VERSION_SCHEMA", fichier: "src/domaine/modele.ts" },
  { nom: "VERSION_MOVPACK", fichier: "src/echange/movpack.ts" },
];
for (const { nom, fichier } of formats) {
  const src = await lire(fichier);
  const m = src.match(new RegExp(`${nom}\\s*=\\s*(\\d+)`));
  if (!m) problemes.push(`${fichier} : constante ${nom} introuvable — la garde ne peut plus vérifier son unicité.`);
}

/* ---------- 6. la CI joue TOUTE la chaîne de vérification ---------- */

// `npm run verifier` et le workflow `ci.yml` décrivent la même chose à deux
// endroits : ce que le projet considère comme vérifié. Ils ont divergé en
// silence — `verifier:references` n'a jamais tourné en CI (D-270). Une
// duplication qu'on ne peut pas supprimer (le workflow intercale des étapes
// d'artefact entre les vérifications) se rattache par une garde, jamais par
// une consigne.
{
  const pkg = JSON.parse(await lire("package.json"));
  const ci = (await lireSiPresent(".github/workflows/ci.yml")) ?? "";
  // Les commandes sont comparées TELLES QU'ÉCRITES (`npm test` et
  // `npm run build` cohabitent dans la chaîne) : normaliser inventerait une
  // forme que ni l'un ni l'autre n'emploie.
  const etapes = (pkg.scripts?.verifier ?? "").split("&&").map((c) => c.trim()).filter(Boolean);
  for (const etape of etapes) {
    if (!new RegExp(`${etape.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(\\s|$)`, "m").test(ci))
      problemes.push(`.github/workflows/ci.yml : « ${etape} » fait partie de \`npm run verifier\` mais la CI ne le joue pas — vérifié en local, pas à la poussée.`);
  }
}

/* ---------- verdict ---------- */

if (problemes.length) {
  console.error(`verifier-references : ${problemes.length} information(s) recopiée(s)\n`);
  for (const p of problemes) console.error(`  ✕ ${p}`);
  console.error("\nUne information a UN lieu. Supprimer la copie, ou la dériver de sa source.");
  process.exit(1);
}

console.log("verifier-references : aucune information recopiée (versions.md est une carte, version d'app en un lieu, adresse de dépôt à jour, formats en constantes, CI = chaîne complète).");
