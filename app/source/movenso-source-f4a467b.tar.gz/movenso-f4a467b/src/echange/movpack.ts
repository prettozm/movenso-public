/**
 * Conteneur `.movpack` v3 (contrat §6, exigences D-018.1) — le véhicule de la
 * souveraineté : identité du pack, auteur, portée, version, INTÉGRITÉ
 * vérifiée, conditions d'utilisation, réimport idempotent (les ids voyagent).
 *
 * ZIP (fflate) : manifeste.json + bibliotheque.json + videos/<ULID>.
 * Aucune E/S ici : octets → structures et retour. Détection par contenu,
 * jamais par extension.
 */

import { unzipSync, zipSync, Zip, ZipDeflate, ZipPassThrough, Unzip, UnzipInflate, type Zippable } from "fflate";
import { sourceDe, type Bibliotheque } from "../domaine/modele.ts";
import { migrerAvecImages, type ImageDetachee } from "../domaine/migrations.ts";
import { validerBibliotheque } from "../domaine/validation.ts";
import { registreMedias, type EntreeRegistre } from "../domaine/medias.ts";
import { normaliserPourRecherche } from "../domaine/recherche.ts";
import { Sha256, sha256Hex } from "../domaine/sha256.ts";

/** Version du CONTENEUR (indépendante du schéma de la bibliothèque).
 *  v5 (D-269) : les IMAGES de couverture sont des fichiers `images/<sha256>`,
 *  inscrits à l'inventaire d'intégrité comme les médias — elles ne voyagent
 *  plus en base64 dans `bibliotheque.json`.
 *  v4 (lot 8B) : inventaire d'intégrité PAR FICHIER (bibliotheque.json ET
 *  chaque média), version éditoriale, options d'inclusion explicites.
 *  v3 (empreinte globale de bibliotheque.json seule) reste lisible.
 *  Les v4 et v3 restent LISIBLES : leurs images en base64 sont détachées à la
 *  lecture par la migration de schéma, et l'appelant les reçoit exactement
 *  comme celles d'un v5 — un seul chemin d'écriture en aval. */
export const VERSION_MOVPACK = 5;

/** Une entrée de l'inventaire d'intégrité (lot 8B §14) : un fichier du
 *  conteneur, son chemin canonique, sa taille en octets, son empreinte. */
interface FichierManifeste {
  chemin: string;
  taille: number;
  sha256: string;
}

export interface ManifesteMovpack {
  format: "movpack";
  version: number;
  /** Identité stable du pack — clé d'idempotence au réimport (D-015). */
  id: string;
  nom: string;
  /** `complet` = export intégral restaurable (type d'objet : sauvegarde) ;
   *  `discipline` = pack publiable ; `composition` = une composition et les
   *  identités qu'elle référence. La portée EST le type d'objet (§13). */
  portee: "complet" | "discipline" | "composition";
  auteur?: string;
  conditions?: string;
  creeLe: string;
  versionSchema: number;
  /** SHA-256 (hex) de bibliotheque.json — l'intégrité se vérifie, ne se
   *  suppose pas. Conservé en v4 (repli et inspecteurs externes) ; en v4
   *  l'autorité est l'inventaire `fichiers`. */
  empreinte: string;
  videos: string[];
  /** v4 — version ÉDITORIALE du pack (défaut 1) : distincte des versions du
   *  conteneur, du schéma et de l'application (§28). */
  versionEditoriale?: number;
  /** v4 — algorithme des empreintes de l'inventaire. */
  algorithme?: string;
  /** v4 — ce que le conteneur inclut réellement, DIT (§13) : médias,
   *  contenu personnel (carnet, favoris). */
  inclusions?: { medias: boolean; contenuPersonnel: boolean };
  /** v4 — inventaire d'intégrité par fichier (bibliotheque.json + médias). */
  fichiers?: FichierManifeste[];
}

export class ErreurMovpack extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ErreurMovpack";
  }
}

/** Détection par contenu : un ZIP commence par « PK ». */
export function estZip(octets: Uint8Array): boolean {
  return octets.length > 3 && octets[0] === 0x50 && octets[1] === 0x4b;
}

/** Dossiers de médias reconnus dans un conteneur : `medias/` (canonique,
 *  lot 8B §12) et `videos/` (v3 et historiques, restés importables). */
function estCheminMedia(chemin: string): boolean {
  return (chemin.startsWith("medias/") || chemin.startsWith("videos/")) && chemin.length > 7;
}

/** Chemin d'une IMAGE de couverture (v5, D-269) : `images/<sha256 hex>`. Le
 *  nom EST l'empreinte — un lecteur peut donc vérifier l'intégrité d'une image
 *  sans consulter le manifeste, et deux packs qui partagent une illustration
 *  la nomment pareil. */
function estCheminImage(chemin: string): boolean {
  return /^images\/[0-9a-f]{64}$/.test(chemin);
}

/** Les octets des images d'une bibliothèque, par empreinte. */
export type OctetsImages = Map<string, Uint8Array>;

/** Refuse d'écrire un conteneur dont les images manquent : l'inventaire les
 *  déclare, le ZIP ne les porte pas — les fiches arriveraient nues chez qui
 *  l'importe, sans que rien ne le signale. Mieux vaut ne pas produire le
 *  conteneur que d'en produire un vide de ses illustrations. */
function exigerImages(b: Bibliotheque, images: OctetsImages): void {
  const manquantes = (b.images ?? []).filter((i) => !images.has(i.id));
  if (manquantes.length)
    throw new ErreurMovpack(
      `Conteneur incomplet : ${manquantes.length} image(s) déclarée(s) dont les octets n'ont pas été fournis`
      + ` (première : ${manquantes[0]!.id.slice(0, 12)}…)`,
    );
}

/** Id LOGIQUE d'un média depuis son chemin : `medias/<id>.<ext>` ou
 *  `videos/<id>` → `<id>` (un ULID ne contient jamais de point). */
function idMediaDepuisChemin(chemin: string): string {
  const apresDossier = chemin.slice(chemin.indexOf("/") + 1);
  const point = apresDossier.indexOf(".");
  return point === -1 ? apresDossier : apresDossier.slice(0, point);
}

export interface MetaExport {
  id: string;
  nom: string;
  portee: ManifesteMovpack["portee"];
  auteur?: string;
  conditions?: string;
  /** Version éditoriale du pack (défaut 1). */
  versionEditoriale?: number;
}

/** Chemin canonique d'un média (§12) : `medias/<mediaId>.<extension>`,
 *  l'extension venant du registre (8A) ; `medias/<id>` nu si inconnue. */
function cheminMedia(registre: Map<string, EntreeRegistre>, id: string): string {
  const ext = registre.get(id)?.media.extension;
  return ext ? `medias/${id}.${ext}` : `medias/${id}`;
}

/** Assemble le manifeste v4 à partir d'un inventaire déjà calculé. */
function construireManifeste(
  b: Bibliotheque,
  meta: MetaExport,
  ids: string[],
  inventaire: FichierManifeste[],
  empreinteBib: string,
  aDesMedias: boolean,
  creeLe: string,
): ManifesteMovpack {
  return {
    format: "movpack",
    version: VERSION_MOVPACK,
    id: meta.id,
    nom: meta.nom,
    portee: meta.portee,
    ...(meta.auteur ? { auteur: meta.auteur } : {}),
    ...(meta.conditions ? { conditions: meta.conditions } : {}),
    creeLe,
    versionSchema: b.versionSchema,
    empreinte: empreinteBib,
    videos: ids,
    versionEditoriale: meta.versionEditoriale ?? 1,
    algorithme: "SHA-256",
    // Options d'inclusion DITES, jamais devinées : les médias présents dans
    // le conteneur ; le contenu personnel n'accompagne que l'export complet.
    inclusions: { medias: aDesMedias, contenuPersonnel: meta.portee === "complet" },
    fichiers: inventaire,
  };
}

/**
 * Export EN MÉMOIRE (petits paquets, fixtures de test) — construit tout
 * l'archive d'un coup. Pour l'app et les gros médias, utiliser
 * `exporterMovpackFlux` (mémoire bornée par blocs, lot 8B §15).
 */
export async function exporterMovpack(
  b: Bibliotheque,
  meta: MetaExport,
  videos: Map<string, Uint8Array>,
  images: OctetsImages = new Map(),
): Promise<Uint8Array> {
  validerBibliotheque(b); // jamais un conteneur invalide en circulation
  exigerImages(b, images);
  const json = new TextEncoder().encode(JSON.stringify(b));
  const empreinteBib = sha256Hex(json);
  const registre = registreMedias(b);
  const inventaire: FichierManifeste[] = [
    { chemin: "bibliotheque.json", taille: json.length, sha256: empreinteBib },
  ];
  for (const [id, contenu] of videos)
    inventaire.push({ chemin: cheminMedia(registre, id), taille: contenu.length, sha256: sha256Hex(contenu) });
  // Les images sont nommées par leur empreinte : l'inventaire la répète, ce
  // qui n'est pas une duplication mais le format commun à tous les fichiers.
  for (const i of b.images ?? [])
    inventaire.push({ chemin: `images/${i.id}`, taille: i.taille, sha256: i.id });
  const manifeste = construireManifeste(b, meta, [...videos.keys()], inventaire, empreinteBib, videos.size > 0, new Date().toISOString());
  const fichiers: Zippable = {
    "manifeste.json": new TextEncoder().encode(JSON.stringify(manifeste, null, 2)),
    "bibliotheque.json": json,
  };
  for (const [id, contenu] of videos) {
    fichiers[cheminMedia(registre, id)] = [contenu, { level: 0 }]; // déjà compressé (vidéo)
  }
  for (const i of b.images ?? []) {
    fichiers[`images/${i.id}`] = [images.get(i.id)!, { level: 0 }]; // JPEG/PNG/WebP : déjà compressés
  }
  return zipSync(fichiers, { level: 6 });
}

/** Rôle du flux d'écriture d'un export à mémoire bornée (§15). */
export interface SortieFlux {
  /** Écrit un chunk du conteneur (progressivement, vers un fichier temporaire). */
  ecrire(chunk: Uint8Array): Promise<void>;
}

/**
 * Export à MÉMOIRE BORNÉE PAR BLOCS (lot 8B §15) — le chemin réel de l'app.
 *
 * De bout en bout : chaque média est lu par blocs de taille fixe
 * (`lireBlocs`, jamais `arrayBuffer()` intégral), haché en SHA-256
 * INCRÉMENTAL, poussé progressivement dans son entrée ZIP (stockée sans
 * compression), et les chunks du conteneur sont écrits au fil de l'eau via
 * `sortie` (vers un fichier temporaire OPFS). Ni le média entier, ni
 * l'archive entière ne résident jamais en mémoire : le pic est borné à
 * quelques blocs (celui lu + celui en attente d'écriture) + les petits JSON.
 *
 * Le manifeste et `bibliotheque.json` (petits) restent en mémoire (autorisé).
 * `estAnnule()` est consulté entre les blocs : une annulation lève
 * `ErreurMovpack` — l'appelant nettoie le fichier temporaire.
 */
export async function exporterMovpackFlux(
  b: Bibliotheque,
  meta: MetaExport,
  ids: string[],
  lireBlocs: (id: string) => AsyncIterable<Uint8Array>,
  sortie: SortieFlux,
  opts: {
    creeLe: string;
    estAnnule?: () => boolean;
    surProgression?: (fait: number, total: number) => void;
    /** Octets des images de couverture (D-269). Petits et en nombre borné —
     *  ils tiennent en mémoire, contrairement aux vidéos qui passent par
     *  `lireBlocs`. Absents alors que l'inventaire en déclare : refus. */
    images?: OctetsImages;
  },
): Promise<ManifesteMovpack> {
  validerBibliotheque(b);
  const images = opts.images ?? new Map();
  exigerImages(b, images);
  const registre = registreMedias(b);
  const json = new TextEncoder().encode(JSON.stringify(b));
  const inventaire: FichierManifeste[] = [
    { chemin: "bibliotheque.json", taille: json.length, sha256: sha256Hex(json) },
  ];

  // File d'attente des chunks émis par fflate (drainée après chaque poussée :
  // ne dépasse jamais la sortie d'un bloc).
  let file: Uint8Array[] = [];
  let erreurZip: Error | null = null;
  const zip = new Zip((err, chunk) => {
    if (err) erreurZip = err;
    else if (chunk && chunk.length) file.push(chunk);
  });
  const drainer = async (): Promise<void> => {
    if (erreurZip) throw new ErreurMovpack(`Compression du conteneur échouée : ${erreurZip.message}`);
    const lot = file;
    file = [];
    for (const c of lot) await sortie.ecrire(c);
  };
  const verifierAnnulation = (): void => {
    if (opts.estAnnule?.()) throw new ErreurMovpack("Export annulé");
  };

  // 1) bibliotheque.json (petit, compressé)
  const eBib = new ZipDeflate("bibliotheque.json", { level: 6 });
  zip.add(eBib);
  eBib.push(json, true);
  await drainer();

  // 2) chaque média, par blocs — lecture, hachage incrémental, poussée ZIP
  for (const id of ids) {
    verifierAnnulation();
    const chemin = cheminMedia(registre, id);
    const entree = new ZipPassThrough(chemin); // vidéo : stockée sans compression
    zip.add(entree);
    const hacheur = new Sha256();
    let taille = 0;
    let enAttente: Uint8Array | null = null; // un bloc d'avance → marquer le dernier
    for await (const bloc of lireBlocs(id)) {
      if (enAttente) {
        entree.push(enAttente, false);
        hacheur.update(enAttente);
        taille += enAttente.length;
        await drainer();
        verifierAnnulation();
      }
      enAttente = bloc;
    }
    if (enAttente) {
      entree.push(enAttente, true);
      hacheur.update(enAttente);
      taille += enAttente.length;
    } else {
      entree.push(new Uint8Array(0), true); // média vide : entrée valide, empreinte du vide
    }
    await drainer();
    inventaire.push({ chemin, taille, sha256: hacheur.digestHex() });
    opts.surProgression?.(inventaire.length - 1, ids.length);
  }

  // 3) les images de couverture — petites, stockées telles quelles (déjà
  //    compressées), et nommées par leur empreinte : l'inventaire la reprend.
  for (const i of b.images ?? []) {
    verifierAnnulation();
    const chemin = `images/${i.id}`;
    const entree = new ZipPassThrough(chemin);
    zip.add(entree);
    entree.push(images.get(i.id)!, true);
    await drainer();
    inventaire.push({ chemin, taille: i.taille, sha256: i.id });
  }

  // 4) manifeste.json en DERNIER (il porte l'inventaire complet)
  const manifeste = construireManifeste(b, meta, ids, inventaire, inventaire[0]!.sha256, ids.length > 0, opts.creeLe);
  const eMan = new ZipDeflate("manifeste.json", { level: 6 });
  zip.add(eMan);
  eMan.push(new TextEncoder().encode(JSON.stringify(manifeste, null, 2)), true);
  await drainer();

  zip.end();
  await drainer();
  return manifeste;
}

/** CONTRAT D'INTÉGRITÉ d'un conteneur (S4.2/D-263).
 *
 *  Le repli « empreinte globale » appartient à v3. Il était choisi sur le seul
 *  fait que `fichiers` soit absent ou vide — **sans regarder la version
 *  déclarée**. Un conteneur annonçant `version: 4` pouvait donc omettre son
 *  inventaire et retomber en silence sur le contrôle le plus faible : le
 *  `bibliotheque.json` restait couvert par l'empreinte globale, mais **les
 *  médias voyageaient sans aucune empreinte**, et aucun avertissement ne le
 *  disait. Un conteneur choisissait lui-même la rigueur qu'on lui appliquait.
 *
 *  Désormais : v4 EXIGE son inventaire, et le repli est réservé à v3.
 */
function contratIntegrite(manifeste: ManifesteMovpack): FichierManifeste[] | null {
  const aInventaire = Array.isArray(manifeste.fichiers) && manifeste.fichiers.length > 0;

  if (manifeste.version >= 4) {
    if (!aInventaire)
      throw new ErreurMovpack(
        "Conteneur v4 incomplet : l'inventaire d'intégrité « fichiers » est obligatoire à partir de la version 4"
        + " — un conteneur ne choisit pas la rigueur qu'on lui applique",
      );
    // L'algorithme est DIT : on refuse de vérifier avec autre chose que ce que
    // le conteneur annonce, plutôt que de supposer qu'il pensait SHA-256.
    if (manifeste.algorithme !== undefined && manifeste.algorithme !== "SHA-256")
      throw new ErreurMovpack(`Algorithme d'intégrité « ${manifeste.algorithme} » non supporté (SHA-256 attendu)`);
    for (const [i, f] of manifeste.fichiers!.entries()) {
      const ou = `Inventaire, entrée ${i + 1}`;
      if (!f || typeof f !== "object") throw new ErreurMovpack(`${ou} : objet attendu`);
      if (typeof f.chemin !== "string" || f.chemin.trim() === "") throw new ErreurMovpack(`${ou} : chemin manquant`);
      if (!Number.isInteger(f.taille) || f.taille < 0) throw new ErreurMovpack(`${ou} (${f.chemin}) : taille invalide`);
      if (typeof f.sha256 !== "string" || !/^[0-9a-f]{64}$/.test(f.sha256))
        throw new ErreurMovpack(`${ou} (${f.chemin}) : empreinte SHA-256 mal formée`);
    }
    return manifeste.fichiers!;
  }

  // v3 et antérieurs : l'inventaire n'existait pas. S'il est là malgré tout,
  // on l'honore (un conteneur qui en dit PLUS ne doit pas être puni) ; sinon
  // c'est l'empreinte globale, qui doit alors être présente et bien formée.
  if (aInventaire) return manifeste.fichiers!;
  if (typeof manifeste.empreinte !== "string" || !/^[0-9a-f]{64}$/.test(manifeste.empreinte))
    throw new ErreurMovpack("Manifeste incomplet : empreinte de bibliotheque.json manquante ou mal formée");
  return null;
}

/**
 * Réunit les images d'un conteneur, quelle que soit leur provenance.
 *
 * Un v5 les porte en fichiers ; un v4 les portait en base64, et la migration
 * de schéma vient de les détacher. Les deux aboutissent au MÊME objet, avec la
 * même identité (l'empreinte), donc l'appelant n'a qu'un cas à traiter.
 *
 * L'inventaire de la bibliothèque fait autorité : une image du ZIP que
 * personne ne déclare est ignorée (elle serait un fichier orphelin dès
 * l'écriture), et une image déclarée mais absente n'est pas fabriquée — la
 * vignette se dégradera, ce qui est visible, plutôt que d'échouer à l'import
 * d'un pack par ailleurs valide.
 */
function reunirImages(
  b: Bibliotheque,
  detachees: ImageDetachee[],
  duConteneur: Map<string, Uint8Array>,
): ImageDetachee[] {
  const parId = new Map(detachees.map((i) => [i.id, i]));
  for (const declaree of b.images ?? []) {
    if (parId.has(declaree.id)) continue;
    const octets = duConteneur.get(declaree.id);
    if (octets) parId.set(declaree.id, { ...declaree, octets });
  }
  return [...parId.values()];
}

export interface ContenuMovpack {
  manifeste: ManifesteMovpack;
  bibliotheque: Bibliotheque;
  videos: Map<string, Uint8Array>;
  /** Images de couverture, octets compris (D-269). L'appelant les écrit en
   *  fichiers ; il n'a PAS à savoir d'où elles viennent — d'un `images/` du
   *  conteneur (v5) ou du base64 détaché par la migration de schéma (v4 et
   *  antérieurs). Un seul chemin d'écriture en aval, donc un seul à prouver. */
  images: ImageDetachee[];
  /** Fichiers présents dans l'archive mais absents de l'inventaire :
   *  ignorés, jamais exécutés, mais SIGNALÉS (§14). */
  avertissements: string[];
}

export async function lireMovpack(octets: Uint8Array): Promise<ContenuMovpack> {
  let fichiers: Record<string, Uint8Array>;
  try {
    fichiers = unzipSync(octets);
  } catch {
    throw new ErreurMovpack("Fichier illisible : pas une archive .movpack valide");
  }
  const brutManifeste = fichiers["manifeste.json"];
  const brutBibliotheque = fichiers["bibliotheque.json"];
  if (!brutManifeste || !brutBibliotheque) {
    throw new ErreurMovpack("Archive incomplète : manifeste.json et bibliotheque.json attendus");
  }
  const manifeste = JSON.parse(new TextDecoder().decode(brutManifeste)) as ManifesteMovpack;
  if (manifeste.format !== "movpack") throw new ErreurMovpack("Manifeste inconnu : pas un .movpack");
  if (manifeste.version > VERSION_MOVPACK) {
    throw new ErreurMovpack(
      `Conteneur .movpack v${manifeste.version}, plus récent que l'application (v${VERSION_MOVPACK}) — mettre à jour l'application`,
    );
  }

  // Intégrité (§14) : TOUT est vérifié AVANT de construire ou de retourner
  // quoi que ce soit — un conteneur douteux est refusé avant toute mutation.
  const avertissements: string[] = [];
  const videos = new Map<string, Uint8Array>();
  const imagesDuConteneur = new Map<string, Uint8Array>(); // v5 : `images/<empreinte>`
  const inventaire = contratIntegrite(manifeste);
  if (inventaire) {
    // v4 : inventaire par fichier — liste, puis tailles, puis empreintes.
    const declares = new Set<string>(["manifeste.json"]);
    let bibliothequeDeclaree = false;
    for (const f of inventaire) {
      declares.add(f.chemin);
      const contenu = fichiers[f.chemin];
      if (!contenu) throw new ErreurMovpack(`Fichier manquant : ${f.chemin} est déclaré mais absent de l'archive`);
      if (contenu.length !== f.taille)
        throw new ErreurMovpack(`Taille inattendue : ${f.chemin} (${contenu.length} octets, ${f.taille} attendus)`);
      if (sha256Hex(contenu) !== f.sha256)
        throw new ErreurMovpack(`Intégrité en échec : ${f.chemin} ne correspond pas à son empreinte`);
      if (f.chemin === "bibliotheque.json") bibliothequeDeclaree = true;
      else if (estCheminImage(f.chemin)) imagesDuConteneur.set(f.chemin.slice(7), contenu);
      else if (estCheminMedia(f.chemin)) videos.set(idMediaDepuisChemin(f.chemin), contenu);
    }
    if (!bibliothequeDeclaree)
      throw new ErreurMovpack("Manifeste incomplet : bibliotheque.json absent de l'inventaire d'intégrité");
    for (const chemin of Object.keys(fichiers))
      if (!declares.has(chemin)) avertissements.push(`Fichier inattendu ignoré : ${chemin}`);
  } else {
    // v3 (repli) : empreinte globale de bibliotheque.json seule.
    if (sha256Hex(brutBibliotheque) !== manifeste.empreinte)
      throw new ErreurMovpack("Intégrité en échec : le contenu ne correspond pas à l'empreinte du manifeste");
    for (const [chemin, contenu] of Object.entries(fichiers))
      if (estCheminMedia(chemin)) videos.set(idMediaDepuisChemin(chemin), contenu);
  }

  const { bibliotheque, imagesDetachees } = migrerAvecImages(JSON.parse(new TextDecoder().decode(brutBibliotheque)));
  validerBibliotheque(bibliotheque);
  return {
    manifeste,
    bibliotheque,
    videos,
    images: reunirImages(bibliotheque, imagesDetachees, imagesDuConteneur),
    avertissements,
  };
}

/**
 * Puits d'écriture des médias d'un conteneur lu EN FLUX (bêta, D-114) : l'app
 * le branche sur le staging OPFS, les tests sur une collecte mémoire. AUCUN
 * octet de média ne transite jamais par le tas de `lireMovpackFlux` — ils
 * partent au fil de l'eau vers ce puits.
 */
export interface PuitsMediaFlux {
  /** Ouvre l'écriture d'un média (nom physique `<id>.<ext>`). */
  ouvrir(nomPhysique: string): Promise<void>;
  /** Ajoute un bloc au média courant. */
  ecrire(bloc: Uint8Array): Promise<void>;
  /** Clôt le média courant, complet. */
  fermer(): Promise<void>;
  /** Abandonne et nettoie tout ce qui a été mis en attente (échec/annulation). */
  abandonner(): Promise<void>;
}

/** Limites de dépouillement d'une archive (S1.4, D-165) — LARGES pour tout
 *  usage légitime, fatales pour une archive hostile. Surchargées en test. */
export const LIMITES_MOVPACK = {
  /** `manifeste.json` / `bibliotheque.json` : accumulés en mémoire — bornés
   *  (une « zip bomb » vise précisément cette accumulation). */
  octetsPetitFichier: 64_000_000,
  /** Nombre d'entrées du ZIP (médias compris). */
  entreesMax: 4_096,
  /** Volume total DÉCOMPRESSÉ toléré, tous fichiers confondus. */
  octetsTotal: 8_000_000_000,
} as const;

/** Extensions de média acceptées dans une archive — la vidéo est le seul
 *  média-fichier du modèle ; « sans extension » = historique, accepté. */
const EXTENSIONS_MEDIA_ARCHIVE = new Set(["webm", "mp4", "mov", "mkv", "3gp", "ogv", "avi"]);

/** Signatures d'EXÉCUTABLES — refusées quel que soit le nom du fichier
 *  (contrôle du type réel : une extension ne blanchit jamais le contenu). */
function signatureExecutable(bloc: Uint8Array): string | null {
  if (bloc.length >= 2 && bloc[0] === 0x4d && bloc[1] === 0x5a) return "exécutable Windows (MZ)";
  if (bloc.length >= 4 && bloc[0] === 0x7f && bloc[1] === 0x45 && bloc[2] === 0x4c && bloc[3] === 0x46) return "exécutable ELF";
  if (bloc.length >= 2 && bloc[0] === 0x23 && bloc[1] === 0x21) return "script exécutable (#!)";
  return null;
}

/** Chemin d'entrée SÛR : relatif, segments non vides, sans `..`, sans
 *  antislash, sans caractère de contrôle, sans lecteur Windows. */
function cheminEntreeSur(nom: string): boolean {
  if (!nom || nom.length > 512) return false;
  if (/[\u0000-\u001f\\]/.test(nom)) return false; // contrôle + antislash (chemin Windows)
  if (nom.startsWith("/") || /^[a-z]:/i.test(nom)) return false; // absolu / lecteur Windows
  return nom.split("/").every((s) => s.length > 0 && s !== "." && s !== "..");
}

/** Un média VÉRIFIÉ, déjà écrit dans le puits — jamais ses octets en mémoire. */
export interface MediaStreame {
  id: string;
  nomPhysique: string;
  taille: number;
  sha256: string;
}

export interface ContenuMovpackFlux {
  manifeste: ManifesteMovpack;
  bibliotheque: Bibliotheque;
  /** Médias vérifiés, stockés par le puits — prêts à être promus. */
  medias: MediaStreame[];
  /** Images de couverture, octets compris (D-269) — mêmes que `ContenuMovpack`,
   *  et de la même façon quelle que soit la version du conteneur. */
  images: ImageDetachee[];
  avertissements: string[];
}

type EvenementFlux =
  | { t: "debut"; nom: string }
  | { t: "donnee"; nom: string; bloc: Uint8Array; final: boolean };

function concatener(morceaux: Uint8Array[]): Uint8Array {
  if (morceaux.length === 1) return morceaux[0]!;
  let total = 0;
  for (const m of morceaux) total += m.length;
  const out = new Uint8Array(total);
  let pos = 0;
  for (const m of morceaux) {
    out.set(m, pos);
    pos += m.length;
  }
  return out;
}

/**
 * Lecture EN FLUX d'un `.movpack` (D-114) — la variante à MÉMOIRE BORNÉE de
 * `lireMovpack`, pour l'import/restauration de conteneurs volumineux (la vidéo
 * locale de la bêta). Les petits JSON (manifeste, bibliotheque) sont accumulés
 * en mémoire (autorisé) ; CHAQUE média est décompressé par blocs et poussé
 * aussitôt dans `puits` (staging), haché en SHA-256 INCRÉMENTAL — ni le média
 * entier ni l'archive entière ne résident jamais dans le tas. L'ordre des
 * entrées n'importe pas (le manifeste est vérifié une fois le flux consommé).
 *
 * L'INTÉGRITÉ garde la règle de `lireMovpack` (§14) : tout est vérifié AVANT
 * de rien retourner. Un conteneur douteux `abandonner()` le puits (staging
 * nettoyé) et lève `ErreurMovpack` — les médias ne sont promus qu'à la
 * confirmation, donc l'appelant n'a alors rien de définitif à défaire.
 */
export async function lireMovpackFlux(
  source: ReadableStream<Uint8Array>,
  puits: PuitsMediaFlux,
  opts: { estAnnule?: () => boolean; limites?: Partial<typeof LIMITES_MOVPACK> } = {},
): Promise<ContenuMovpackFlux> {
  // S1.4 (D-165) : bornes de dépouillement — une archive qui les dépasse est
  // HOSTILE ou corrompue, l'import s'arrête proprement (staging nettoyé).
  const lim = { ...LIMITES_MOVPACK, ...opts.limites };
  let entrees = 0;
  let totalDecompresse = 0;
  let brutManifeste: Uint8Array | null = null;
  let brutBibliotheque: Uint8Array | null = null;
  const mediasParChemin = new Map<string, MediaStreame>();
  const imagesDuConteneur = new Map<string, Uint8Array>(); // v5 : `images/<empreinte>`
  const tousLesNoms = new Set<string>();

  // File d'événements émis SYNCHRONEMENT par fflate pendant `push` ; drainée
  // (asynchrone : écritures OPFS) après chaque push — jamais plus d'un bloc
  // d'entrée en attente.
  const evenements: EvenementFlux[] = [];
  let erreurZip: Error | null = null;
  const uz = new Unzip();
  uz.register(UnzipInflate); // gère « stored » (0) ET « deflate » (8)
  uz.onfile = (fichier) => {
    evenements.push({ t: "debut", nom: fichier.name });
    fichier.ondata = (err, bloc, final) => {
      if (err) erreurZip = err;
      else evenements.push({ t: "donnee", nom: fichier.name, bloc, final });
    };
    fichier.start();
  };

  // Un seul média en écriture à la fois (le ZIP est séquentiel).
  let media: { chemin: string; id: string; nomPhysique: string; hacheur: Sha256; taille: number } | null = null;
  // Petit fichier en cours : JSON connu (accumulé) ou inattendu (drainé sans le garder).
  let petit: { nom: string; garder: boolean; morceaux: Uint8Array[]; taille: number } | null = null;

  const drainer = async (): Promise<void> => {
    while (evenements.length) {
      const e = evenements.shift()!;
      if (e.t === "debut") {
        // S1.4 : chaque entrée est contrôlée AVANT d'être traitée — nombre,
        // chemin sûr, unicité, extension de média attendue.
        if (++entrees > lim.entreesMax)
          throw new ErreurMovpack(`Archive refusée : plus de ${lim.entreesMax} entrées`);
        if (!cheminEntreeSur(e.nom))
          throw new ErreurMovpack(`Archive refusée : chemin dangereux (${e.nom})`);
        if (tousLesNoms.has(e.nom))
          throw new ErreurMovpack(`Archive refusée : chemin en double (${e.nom})`);
        tousLesNoms.add(e.nom);
        if (estCheminMedia(e.nom)) {
          const nomPhysique = e.nom.slice(e.nom.indexOf("/") + 1);
          const ext = nomPhysique.match(/\.([a-z0-9]{1,5})$/i)?.[1]?.toLowerCase();
          if (ext !== undefined && !EXTENSIONS_MEDIA_ARCHIVE.has(ext))
            throw new ErreurMovpack(`Archive refusée : type de média inattendu (${e.nom})`);
          media = { chemin: e.nom, id: idMediaDepuisChemin(e.nom), nomPhysique, hacheur: new Sha256(), taille: 0 };
          await puits.ouvrir(nomPhysique);
        } else {
          // Les IMAGES de couverture (v5) passent par le chemin des petits
          // fichiers : quelques dizaines de Ko chacune, donc l'accumulation
          // reste bornée — inutile de leur ouvrir le puits des médias, qui
          // écrit dans le staging vidéo et promeut vers `videos/`.
          petit = {
            nom: e.nom,
            garder: e.nom === "manifeste.json" || e.nom === "bibliotheque.json" || estCheminImage(e.nom),
            morceaux: [],
            taille: 0,
          };
        }
      } else if (media && e.nom === media.chemin) {
        if (e.bloc.length) {
          // S1.4 : le TYPE RÉEL prime sur l'extension — un exécutable déguisé
          // en vidéo est refusé sur ses premiers octets, borne totale tenue.
          if (media.taille === 0) {
            const s = signatureExecutable(e.bloc);
            if (s) throw new ErreurMovpack(`Archive refusée : ${media.chemin} est un ${s}, pas une vidéo`);
          }
          totalDecompresse += e.bloc.length;
          if (totalDecompresse > lim.octetsTotal)
            throw new ErreurMovpack(`Archive refusée : volume décompressé au-delà de ${Math.round(lim.octetsTotal / 1_000_000)} Mo`);
          media.hacheur.update(e.bloc);
          media.taille += e.bloc.length;
          await puits.ecrire(e.bloc);
        }
        if (e.final) {
          await puits.fermer();
          mediasParChemin.set(media.chemin, { id: media.id, nomPhysique: media.nomPhysique, taille: media.taille, sha256: media.hacheur.digestHex() });
          media = null;
        }
      } else if (petit && e.nom === petit.nom) {
        if (e.bloc.length) {
          // S1.4 : l'accumulation en mémoire des petits fichiers est BORNÉE —
          // c'est la cible exacte d'une « zip bomb » (JSON ultra-compressé).
          totalDecompresse += e.bloc.length;
          petit.taille += e.bloc.length;
          if (totalDecompresse > lim.octetsTotal)
            throw new ErreurMovpack(`Archive refusée : volume décompressé au-delà de ${Math.round(lim.octetsTotal / 1_000_000)} Mo`);
          if (petit.taille > lim.octetsPetitFichier)
            throw new ErreurMovpack(`Archive refusée : ${petit.nom} dépasse ${Math.round(lim.octetsPetitFichier / 1_000_000)} Mo`);
          if (petit.garder) petit.morceaux.push(e.bloc.slice()); // copie : le tampon fflate est réutilisé au push suivant
        }
        if (e.final) {
          if (petit.garder) {
            const total = concatener(petit.morceaux);
            if (petit.nom === "manifeste.json") brutManifeste = total;
            else if (petit.nom === "bibliotheque.json") brutBibliotheque = total;
            else imagesDuConteneur.set(petit.nom.slice(7), total);
          }
          petit = null;
        }
      }
    }
  };

  const illisible = () => new ErreurMovpack("Fichier illisible : pas une archive .movpack valide");

  try {
    const lecteur = source.getReader();
    for (;;) {
      if (opts.estAnnule?.()) throw new ErreurMovpack("Import annulé");
      const { done, value } = await lecteur.read();
      try {
        uz.push(value ?? new Uint8Array(0), done);
      } catch {
        throw illisible();
      }
      if (erreurZip) throw illisible();
      await drainer();
      if (done) break;
    }

    // Intégrité — TOUT est vérifié avant de rien retourner (§14). (Capture en
    // const : ces `let` sont assignés dans une closure, le CFA de TS ne les
    // affine pas sinon.)
    const octetsManifeste = brutManifeste as Uint8Array | null;
    const octetsBibliotheque = brutBibliotheque as Uint8Array | null;
    if (!octetsManifeste || !octetsBibliotheque)
      throw new ErreurMovpack("Archive incomplète : manifeste.json et bibliotheque.json attendus");
    const manifeste = JSON.parse(new TextDecoder().decode(octetsManifeste)) as ManifesteMovpack;
    if (manifeste.format !== "movpack") throw new ErreurMovpack("Manifeste inconnu : pas un .movpack");
    if (manifeste.version > VERSION_MOVPACK)
      throw new ErreurMovpack(
        `Conteneur .movpack v${manifeste.version}, plus récent que l'application (v${VERSION_MOVPACK}) — mettre à jour l'application`,
      );

    const avertissements: string[] = [];
    let medias: MediaStreame[];
    const inventaire = contratIntegrite(manifeste);
    if (inventaire) {
      // v4 : inventaire par fichier — chaque déclaration confrontée à ce qui a
      // réellement transité (taille + empreinte), rien de promu sans preuve.
      const declares = new Set<string>(["manifeste.json"]);
      let bibliothequeDeclaree = false;
      medias = [];
      for (const f of inventaire) {
        declares.add(f.chemin);
        if (f.chemin === "bibliotheque.json") {
          if (octetsBibliotheque.length !== f.taille)
            throw new ErreurMovpack(`Taille inattendue : bibliotheque.json (${octetsBibliotheque.length} octets, ${f.taille} attendus)`);
          if (sha256Hex(octetsBibliotheque) !== f.sha256)
            throw new ErreurMovpack("Intégrité en échec : bibliotheque.json ne correspond pas à son empreinte");
          bibliothequeDeclaree = true;
        } else if (estCheminImage(f.chemin)) {
          const octets = imagesDuConteneur.get(f.chemin.slice(7));
          if (!octets) throw new ErreurMovpack(`Fichier manquant : ${f.chemin} est déclaré mais absent de l'archive`);
          if (octets.length !== f.taille)
            throw new ErreurMovpack(`Taille inattendue : ${f.chemin} (${octets.length} octets, ${f.taille} attendus)`);
          if (sha256Hex(octets) !== f.sha256)
            throw new ErreurMovpack(`Intégrité en échec : ${f.chemin} ne correspond pas à son empreinte`);
        } else {
          const m = mediasParChemin.get(f.chemin);
          if (!m) throw new ErreurMovpack(`Fichier manquant : ${f.chemin} est déclaré mais absent de l'archive`);
          if (m.taille !== f.taille)
            throw new ErreurMovpack(`Taille inattendue : ${f.chemin} (${m.taille} octets, ${f.taille} attendus)`);
          if (m.sha256 !== f.sha256)
            throw new ErreurMovpack(`Intégrité en échec : ${f.chemin} ne correspond pas à son empreinte`);
          medias.push(m);
        }
      }
      if (!bibliothequeDeclaree)
        throw new ErreurMovpack("Manifeste incomplet : bibliotheque.json absent de l'inventaire d'intégrité");
      for (const nom of tousLesNoms) if (!declares.has(nom)) avertissements.push(`Fichier inattendu ignoré : ${nom}`);
    } else {
      // v3 (repli) : empreinte globale de bibliotheque.json seule.
      if (sha256Hex(octetsBibliotheque) !== manifeste.empreinte)
        throw new ErreurMovpack("Intégrité en échec : le contenu ne correspond pas à l'empreinte du manifeste");
      medias = [...mediasParChemin.values()];
    }

    const { bibliotheque, imagesDetachees } = migrerAvecImages(JSON.parse(new TextDecoder().decode(octetsBibliotheque)));
    validerBibliotheque(bibliotheque);
    return {
      manifeste,
      bibliotheque,
      medias,
      images: reunirImages(bibliotheque, imagesDetachees, imagesDuConteneur),
      avertissements,
    };
  } catch (e) {
    await puits.abandonner();
    throw e instanceof ErreurMovpack ? e : illisible();
  }
}

/** Source d'un élément : le pack d'origine, ou « local » (créé sur cet appareil). */
/**
 * Extrait un pack publiable d'une discipline, borné à un PÉRIMÈTRE DE SOURCES
 * (D-023, fermeture 2) : une publication n'emporte jamais par défaut les
 * contributions d'une source que l'auteur ne maîtrise pas — le contenu local
 * seul par défaut, chaque source importée en opt-in explicite. Le carnet
 * personnel ne se publie jamais. Fonction pure.
 */
/** Une relation exclue de la publication car sa cible est hors périmètre
 *  (lot 10B, A1) — pour l'annonce d'aperçu et le rapport final. */
interface RelationExclue {
  techniqueId: string;
  techniqueNom: string;
  type: string;
  cibleId: string;
}

export interface ExtractionPack {
  extrait: Bibliotheque;
  /** Relations retirées du FICHIER publié (jamais de la bibliothèque locale)
   *  parce que leur identité cible n'appartient pas au périmètre du pack. */
  relationsExclues: RelationExclue[];
}

export function extrairePackDiscipline(
  b: Bibliotheque,
  disciplineId: string,
  sources: ReadonlySet<string> = new Set(["local"]),
  techniquesChoisies?: ReadonlySet<string>,
  opts: { compositionsPersonnelles?: boolean } = {},
): ExtractionPack {
  const discipline = b.disciplines.find((d) => d.id === disciplineId);
  if (!discipline) throw new ErreurMovpack("Discipline introuvable");
  // Sous-ensemble explicite de techniques (tuning post-V3 : « choix de
  // techniques ») — restreint le périmètre en plus des sources.
  const choisie = (id: string) => !techniquesChoisies || techniquesChoisies.has(id);
  const contributions = b.contributions.filter(
    (c) => c.provenance !== "personnel" && c.techniqueId !== null && choisie(c.techniqueId) && sources.has(sourceDe(c)),
  );
  const idsContribues = new Set(contributions.map((c) => c.techniqueId!));
  // Identités : celles du périmètre de sources, plus celles que les
  // contributions incluses éclairent (une contribution voyage avec son identité).
  const techniques = b.techniques.filter(
    (t) => t.disciplineId === disciplineId && choisie(t.id) && (sources.has(sourceDe(t)) || idsContribues.has(t.id)),
  );
  const ids = new Set(techniques.map((t) => t.id));
  // Règle (lot 10B, A1) : une relation n'est exportée que si sa SOURCE et sa
  // CIBLE sont toutes deux dans le périmètre. Une cible hors périmètre → la
  // relation est EXCLUE du fichier publié (jamais de relation pendante créée en
  // silence), la relation LOCALE n'est jamais modifiée, la cible n'est JAMAIS
  // ajoutée implicitement. Les exclusions sont comptées et détaillées.
  const relationsExclues: RelationExclue[] = [];
  const techniquesPubliees = techniques.map((t) => {
    const clone = structuredClone(t);
    clone.relations = t.relations.filter((r) => {
      if (ids.has(r.cibleId)) return true;
      relationsExclues.push({ techniqueId: t.id, techniqueNom: t.nom, type: r.type, cibleId: r.cibleId });
      return false;
    });
    return clone;
  });
  const extrait: Bibliotheque = {
    versionSchema: b.versionSchema,
    typesRelation: structuredClone(b.typesRelation),
    ...(b.typesAlerte ? { typesAlerte: structuredClone(b.typesAlerte) } : {}), // D-136 : types d'alerte voyagent
    disciplines: [structuredClone(discipline)],
    techniques: techniquesPubliees,
    contributions: structuredClone(contributions.filter((c) => ids.has(c.techniqueId!))),
    // Compositions embarquées AVEC la discipline (D-127) : une séance/kata
    // « voyage » avec le pack de sa discipline pour rester JOUABLE à l'import,
    // même sur un appareil qui n'a pas encore le pack. On retient, en plus de
    // celles issues des sources de la discipline, toute composition non
    // personnelle dont TOUS les pas techniques pointent des techniques du
    // périmètre exporté (`ids`) — donc sans référence pendante à l'arrivée.
    compositions: structuredClone(
      b.compositions.filter((c) => {
        const pasTech = c.blocs.filter((x) => x.type === "technique" && x.techniqueId);
        const jouableIci = pasTech.length > 0 && pasTech.every((x) => ids.has(x.techniqueId!));
        // Composition PERSONNELLE : publiée seulement sur OPT-IN explicite
        // (D-127) et seulement si elle est jouable dans ce périmètre (jamais de
        // référence pendante). Sinon, le carnet reste privé (lot 5 §4).
        if (c.provenance === "personnel") return (opts.compositionsPersonnelles ?? false) && jouableIci;
        return jouableIci || sources.has(sourceDe(c));
      }),
    ),
    favoris: [], // marque-pages personnels : exclus de toute publication (lot 5 §4)
  };
  validerBibliotheque(extrait);
  return { extrait, relationsExclues };
}

/**
 * Extrait un pack pour UNE seule technique (partage individuel — D-067). Le
 * pack porte la discipline de la fiche, la fiche elle-même et SES contributions
 * sourcées (jamais le carnet personnel, §31). Les relations vers d'autres
 * identités sont exclues du fichier (cible hors périmètre, D-066) : un pack
 * d'une technique ne contient jamais de lien pendant. Fonction pure.
 */
export function extrairePackTechnique(b: Bibliotheque, techniqueId: string): ExtractionPack {
  const t = b.techniques.find((x) => x.id === techniqueId);
  if (!t) throw new ErreurMovpack("Technique introuvable");
  const discipline = b.disciplines.find((d) => d.id === t.disciplineId);
  if (!discipline) throw new ErreurMovpack("Discipline introuvable");
  const contributions = b.contributions.filter((c) => c.techniqueId === t.id && c.provenance !== "personnel");
  const relationsExclues: RelationExclue[] = [];
  const clone = structuredClone(t);
  clone.relations = t.relations.filter((r) => {
    if (r.cibleId === t.id) return true; // (auto-référence improbable) tolérée
    relationsExclues.push({ techniqueId: t.id, techniqueNom: t.nom, type: r.type, cibleId: r.cibleId });
    return false;
  });
  const extrait: Bibliotheque = {
    versionSchema: b.versionSchema,
    typesRelation: structuredClone(b.typesRelation),
    ...(b.typesAlerte ? { typesAlerte: structuredClone(b.typesAlerte) } : {}), // D-136 : types d'alerte voyagent
    disciplines: [structuredClone(discipline)],
    techniques: [clone],
    contributions: structuredClone(contributions),
    compositions: [],
    favoris: [],
  };
  validerBibliotheque(extrait);
  return { extrait, relationsExclues };
}

/**
 * Extrait le pack d'UNE composition (D-020.1, verrouillé D-127) : la composition
 * PLUS les IDENTITÉS de technique qu'elle enchaîne (jamais leur carnet personnel)
 * et les disciplines de ces identités. L'export ET le partage d'une composition
 * passent par ici : une composition partagée reste JOUABLE à l'import même sur un
 * appareil qui n'a pas le pack d'origine. Fonction pure.
 */
export function extrairePackComposition(b: Bibliotheque, compositionId: string): Bibliotheque {
  const compo = b.compositions.find((c) => c.id === compositionId);
  if (!compo) throw new ErreurMovpack("Composition introuvable");
  const idsTechniques = new Set(
    compo.blocs.filter((x) => x.type === "technique" && x.techniqueId).map((x) => x.techniqueId!),
  );
  const techniques = b.techniques.filter((t) => idsTechniques.has(t.id));
  const idsDisciplines = new Set(techniques.map((t) => t.disciplineId));
  const extrait: Bibliotheque = {
    versionSchema: b.versionSchema,
    typesRelation: structuredClone(b.typesRelation),
    disciplines: structuredClone(b.disciplines.filter((d) => idsDisciplines.has(d.id))),
    techniques: structuredClone(techniques),
    contributions: [], // un pack de composition ne transporte pas de carnet
    compositions: [structuredClone(compo)],
    favoris: [],
  };
  validerBibliotheque(extrait);
  return extrait;
}

/** Nom de FICHIER lisible d'un pack — dérivé du nom éditorial (peut changer
 *  avec lui). Ce n'est PAS l'identité technique du pack (voir idPackStable). */
export function idDePack(nom: string): string {
  return `pack-${normaliserPourRecherche(nom)}`;
}

/** Identité TECHNIQUE stable d'un pack (lot 8B) — clé d'idempotence au
 *  réimport (D-013/D-015). Dérivée de l'ULID de l'entité publiée (discipline
 *  ou composition), donc INVARIANTE au renommage : republier après un
 *  renommage produit le même id → réimport = mise à jour, pas doublon. */
export function idPackStable(entiteId: string): string {
  return `pack-${entiteId}`;
}
