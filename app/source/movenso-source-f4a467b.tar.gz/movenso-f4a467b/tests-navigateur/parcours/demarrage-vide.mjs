/**
 * CHAPITRE e2e (S3.A7) — Scénario A — vide mais jamais bloqué (D-017).
 * Contexte(s) Playwright propre(s) : OPFS isolé, lançable après tout chapitre.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { surveiller, lent, ouvrirPlus, revelerCreation, ouvrirSection, ouvrirCreationSection, ouvrirDisc, gesteCapture, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
/* ===== Scénario A — vide mais jamais bloqué (D-017) : créer sa discipline,
   capturer, sans aucun contenu installé. Contexte isolé (OPFS propre). ===== */
const ctxA = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
{
  const page = await ctxA.newPage();
  surveiller(page);
  await page.goto("http://localhost:4517/");
  await page.waitForSelector(".action-douce");
  assert.equal(await page.locator(".chip-discipline").count(), 0, "aucun contenu ne doit être embarqué");
  assert.ok((await page.locator(".ecran").innerText()).includes("Elle démarre vide, par choix"), "état vide inexplicite");
  // D-084/D-223 : TROIS destinations par défaut — « Relations » ET « Compositions »
  // sont des options bêta (Plus › Réglages avancés, section propre depuis D-234).
  assert.equal(await page.locator(".barre-nav .nav-onglet").count(), 3, "exactement trois onglets attendus par défaut");
  assert.deepEqual(await page.locator(".barre-nav .nav-onglet span").allInnerTexts(), ["Bibliothèque", "Favoris", "Plus"], "ordre des onglets");
  // D-223 : l'interrupteur révèle l'onglet Compositions, et le masque à nouveau.
  await page.evaluate(() => document.querySelector("movenso-app").basculerReglage("compositionsBeta"));
  await rendu(page);
  assert.deepEqual(await page.locator(".barre-nav .nav-onglet span").allInnerTexts(), ["Bibliothèque", "Favoris", "Compositions", "Plus"], "l'opt-in révèle l'onglet Compositions (D-223)");
  await page.evaluate(() => document.querySelector("movenso-app").basculerReglage("compositionsBeta"));
  await rendu(page);
  assert.equal(await page.locator(".barre-nav .nav-onglet").count(), 3, "l'opt-out masque l'onglet à nouveau (D-223)");
  // D-084 : par défaut, les outils de curation sont MASQUÉS (mode avancé off)
  await page.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
  await page.waitForSelector(".ecran.plus");
  for (const cache of ["Médias", "Doublons potentiels", "Relations entre techniques", "Diagnostic et maintenance"])
    assert.equal(await page.locator(".ligne-menu-titre", { hasText: new RegExp(`^${cache}$`) }).count(), 0, `« ${cache} » doit être masqué hors mode avancé`);
  // D-234 : « Réglages avancés » est une SECTION à part entière, toujours
  // visible (c'est elle qui allume le reste) — et elle dit ce qui est actif.
  assert.equal(await page.locator(".ligne-menu-titre", { hasText: /^Réglages avancés$/ }).count(), 1,
    "« Réglages avancés » a sa propre entrée dans Plus (D-234)");
  await page.locator(".ligne-menu", { hasText: "Réglages avancés" }).click();
  await page.waitForSelector(".interrupteur");
  assert.equal(await page.locator(".interrupteur").count(), 4,
    "mode avancé + vignettes distantes (S4.3) + les deux bêtas, hors d'Apparence");
  // Le réglage réseau est ÉTEINT à l'arrivée : c'est la promesse « rien ne
  // part sans geste » (D-260), et elle se vérifie ici, sur une installation
  // neuve, pas seulement dans son chapitre dédié.
  assert.equal(
    await page.locator('.interrupteur[aria-checked="true"]').count(), 0,
    "sur une installation neuve, aucun interrupteur avancé n'est actif");
  await page.locator(".interrupteur", { hasText: "Mode avancé" }).click();
  await rendu(page);
  await page.locator('.barre .bouton-icone[aria-label="Retour"]').click();
  await finit(async () => assert.equal(
    await page.locator(".ligne-menu-titre", { hasText: /^Diagnostic et maintenance$/ }).count(), 1,
    "le mode avancé révèle les outils de curation depuis sa nouvelle section"));
  await page.locator(".ligne-menu", { hasText: "Réglages avancés" }).click();
  await page.waitForSelector(".interrupteur");
  await page.locator(".interrupteur", { hasText: "Mode avancé" }).click();
  await rendu(page);
  await page.locator('.barre .bouton-icone[aria-label="Retour"]').click();
  await rendu(page);
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await rendu(page);
  // plus de bouton global Capturer (lot 1 §7) ; la racine porte l'action
  // contextuelle « Ajouter » (lot 4 §2) — panneau court, fermeture sans effet
  assert.equal(await page.locator(".fab", { hasText: "Ajouter" }).count(), 1, "action contextuelle « Ajouter » attendue sur la racine (lot 4 §2)");
  await page.locator(".fab", { hasText: "Ajouter" }).click();
  await page.waitForSelector(".gestes-ajouter");
  assert.equal(await page.locator(".option-ajouter").count(), 2, "le panneau racine offre deux gestes");
  const textePanneauRacine = (await page.locator(".feuille").innerText()).toLowerCase();
  for (const interdit of ["identité", "contribution", "provenance", "pack", "manifeste"])
    assert.ok(!textePanneauRacine.includes(interdit), `vocabulaire interne « ${interdit} » dans le panneau Ajouter`);
  await page.locator(".voile").click(); // fermeture sans effet (lot 4 §3)
  await finit(async () => assert.equal(await page.locator(".feuille").count(), 0, "le panneau doit se fermer par le voile"));
  // état vide (tuning post-V3) : deux actions — « Importer un pack » et
  // « Créer ta première technique » (l'ancien flux « Créer une discipline » a
  // disparu ; créer une technique crée la discipline à la volée, D-017).
  assert.equal(await page.locator(".action-douce", { hasText: "Créer ta première technique" }).count(), 1, "action « Créer ta première technique » attendue sur l'état vide");
  await page.locator(".action-douce", { hasText: "Créer ta première technique" }).click();
  await page.waitForSelector(".champ-nouveau-nom");
  await page.fill(".champ-nouveau-nom", "Crochet gauche");
  await page.fill(".champ-discipline", "Boxe"); // aucune discipline encore : créée à la volée
  await page.locator(".feuille .actions .bouton.principal", { hasText: "Créer la technique" }).click();
  await page.waitForSelector(".edition"); // la fiche s'ouvre prête à compléter
  // lot 3 §3 : sans média, un fallback actionnable — jamais un rectangle vide (D-091 : en édition, dans la zone Médias)
  assert.equal(await page.locator(".edition-medias .action-douce", { hasText: "Ajouter un média" }).count(), 1, "fallback média sans action");
  await page.locator('.fiche-actions [aria-label="Enregistrer"]').click();
  await page.locator(".fiche-entete h1", { hasText: "Crochet gauche" }).waitFor();
  // une note personnelle se pose directement sur la fiche (commentaire toujours visible)
  await page.fill(".commentaire-zone", "Crochet du gauche, coude bas.");
  await page.locator(".commentaire-zone").blur();
  await rendu(page);
  // l'onglet Bibliothèque mène à la racine ; la puce discipline FILTRE la grille (tuning post-V3)
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await page.waitForSelector(".chip-discipline");
  await page.locator(".chip-discipline", { hasText: "Boxe" }).click();
  assert.equal(await page.locator(".chip-discipline.actif", { hasText: "Boxe" }).count(), 1, "la puce discipline doit devenir un filtre actif (tuning post-V3)");
  assert.ok((await page.locator(".carte-nom").allInnerTexts()).some((t) => t.includes("Crochet gauche")), "la grille filtrée doit montrer la technique de la discipline");
  // D-071 : « Plus » remplace l'Atelier — un MENU (sections + lignes), jamais
  // d'accordéons ni de tableau de bord. Le menu rend ses trois sections et ses
  // lignes ; la création de discipline vit dans « Discipline ».
  await page.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
  await page.waitForSelector(".ecran.plus");
  assert.deepEqual(
    (await page.locator(".menu-section-titre").allInnerTexts()).map((t) => t.trim().toLowerCase()),
    ["ma bibliothèque", "importer, exporter et sauvegarder", "préférences"],
    "les trois sections du menu Plus, dans l'ordre",
  );
  assert.equal(await page.locator(".ligne-menu", { hasText: "Discipline" }).count(), 1, "la ligne « Discipline » doit exister");
  await page.locator(".ligne-menu", { hasText: "Discipline" }).click();
  await page.waitForSelector(".barre .contexte");
  assert.ok((await page.locator(".barre .contexte").innerText()).includes("Discipline"), "sous-écran « Discipline » attendu");
  // post-V3 : la création est derrière le ＋ de l'encart « Disciplines »
  await revelerCreation(page, "Ajouter dans Disciplines", ".creation-discipline input");
  await page.fill(".creation-discipline input", "Aïkido");
  await page.locator(".creation-discipline .bouton", { hasText: "Créer" }).click();
  await finit(async () => assert.ok((await page.locator(".ecran").innerText()).includes("Aïkido"), "la discipline créée doit apparaître dans « Discipline »"));
  // mémoire d'onglet (lot 1 §8) : le retour à la Bibliothèque conserve le
  // filtre discipline actif (tuning post-V3 : la puce est un filtre, pas une page)
  await page.locator(".barre-nav .nav-onglet", { hasText: "Bibliothèque" }).click();
  await page.waitForSelector(".chip-discipline");
  assert.equal(await page.locator(".chip-discipline.actif", { hasText: "Boxe" }).count(), 1, "mémoire d'onglet : filtre discipline perdu au retour de Plus");
  // Plus conserve son sous-écran ouvert pendant la session (mémoire d'onglet)
  await page.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
  await page.waitForSelector(".barre .contexte");
  assert.ok(
    (await page.locator(".barre .contexte").innerText()).includes("Discipline"),
    "Plus doit conserver son sous-écran pendant la session",
  );
  await page.locator(".barre-nav .nav-onglet", { hasText: "Bibliothèque" }).click(); // retour → grille filtrée Boxe (mémoire)
  await page.waitForSelector(".chip-discipline");
  await page.locator(".barre-nav .nav-onglet", { hasText: "Bibliothèque" }).click(); // second appui : racine
  await page.waitForSelector(".chip-discipline");
  assert.equal(await page.locator(".chip-discipline").count(), 2, "deux disciplines créées de zéro");
  // fermeture 1 (D-023) + lot 2 §11 : discipline vide = état spécifique, deux actions, aucune impasse
  await ouvrirDisc(page, "Aïkido");
  await page.waitForSelector(".discipline-vide");
  assert.ok((await page.locator(".discipline-vide").innerText()).includes("ne contient encore aucune technique"), "état vide de discipline inexplicite");
  assert.equal(await page.locator(".discipline-vide .action-douce", { hasText: "Importer" }).count(), 1, "action Importer absente de la discipline vide");
  await page.locator(".discipline-vide .bouton.principal", { hasText: "Créer la première technique" }).click();
  await page.fill(".actions-bibliotheque .creation-discipline input", "Ikkyo");
  await page.click(".actions-bibliotheque .creation-discipline .bouton");
  await page.waitForSelector(".edition"); // la fiche s'ouvre prête à compléter
  await page.locator('.fiche-actions [aria-label="Enregistrer"]').click(); // plus de « Terminer » (lot 3 §16)
  await page.locator(".fiche-entete h1", { hasText: "Ikkyo" }).waitFor();
  await page.locator('.barre [aria-label="Fermer"]').click(); // retour (pile) → explorateur Aïkido
  await page.locator(".carte-nom", { hasText: "Ikkyo" }).waitFor();

  // lot 4 §7.A (boucle 4.3) : la recherche de rattachement est CADRÉE à la
  // discipline présélectionnée, et s'élargit sur demande explicite
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // → racine Bibliothèque
  await page.waitForSelector(".chip-discipline");
  await ouvrirDisc(page, "Boxe"); // écran discipline : la capture y est cadrée sur Boxe
  await page.locator(".fab", { hasText: "Ajouter" }).click();
  await gesteCapture(page, "note");
  await page.fill(".champ-note", "Vu au stage — à ranger côté aïkido.");
  await page.click(".feuille .actions .bouton.principal");
  await page.fill(".feuille .recherche input", "ikkyo");
  await finit(async () => assert.equal(await page.locator(".feuille .resultat:not(.creer)").count(), 0, "la recherche doit d'abord rester cadrée à Boxe"));
  assert.ok((await page.locator(".feuille .fil-vide").innerText()).includes("dans Boxe"), "le cadre de la recherche doit être nommé");
  await page.locator(".feuille .action-douce", { hasText: "toutes les disciplines" }).click();
  await rendu(page);
  await page.locator(".feuille .resultat", { hasText: "Ikkyo" }).first().click();
  await page.locator(".fiche-entete h1", { hasText: "Ikkyo" }).waitFor();

  // lot 4 §6.B (boucle 4.3) : une vidéo choisie passe par l'APERÇU —
  // Utiliser / Choisir un autre fichier / Abandonner ; rien d'écrit avant la fin
  const miniVideo = join(tmpdir(), "movenso-mini-video.webm");
  writeFileSync(miniVideo, Buffer.alloc(2048, 7));
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // racine
  await page.waitForSelector(".chip-discipline");
  await ouvrirDisc(page, "Boxe"); // écran discipline : contexte de création présélectionné
  await page.locator(".fab", { hasText: "Ajouter" }).click();
  await page.locator(".option-ajouter", { hasText: "Capture rapide" }).click();
  await page.waitForSelector(".choix-double");
  const [choixVideo] = await Promise.all([
    page.waitForEvent("filechooser"),
    page.locator(".choix-secondaire .action-douce", { hasText: "Ajouter une vidéo existante" }).click(),
  ]);
  await choixVideo.setFiles(miniVideo);
  await page.waitForSelector(".feuille .media-video video");
  assert.ok((await page.locator(".apercu-infos").innerText()).includes("rien n'est encore enregistré"), "l'aperçu doit dire que rien n'est enregistré");
  assert.ok((await page.locator(".feuille .actions").innerText()).includes("Choisir un autre fichier"), "l'alternative au fichier choisi doit exister");
  await page.locator(".feuille .actions .bouton.principal", { hasText: "Utiliser" }).click();
  await finit(async () => assert.ok((await page.locator(".feuille").innerText()).includes("vidéo jointe"), "après Utiliser, la note doit porter la vidéo"));
  await page.locator(".feuille .actions .bouton", { hasText: "Annuler" }).click(); // rien n'est écrit
  await finit(async () => assert.equal(await page.locator(".feuille").count(), 0, "annuler ferme la capture sans rien créer"));

  // scénario D du lot 4 : créer une technique DEPUIS une capture vidéo —
  // parcours atomique : capture → nouvelle technique → rattachement → fiche
  await page.locator(".fab", { hasText: "Ajouter" }).click();
  await page.locator(".option-ajouter", { hasText: "Capture rapide" }).click();
  await page.waitForSelector(".choix-double");
  const [choixVideo2] = await Promise.all([
    page.waitForEvent("filechooser"),
    page.locator(".choix-secondaire .action-douce", { hasText: "Ajouter une vidéo existante" }).click(),
  ]);
  await choixVideo2.setFiles(miniVideo);
  await page.waitForSelector(".feuille .media-video video");
  await page.locator(".feuille .actions .bouton.principal", { hasText: "Utiliser" }).click();
  await page.fill(".champ-note", "Technique inconnue vue en sparring.");
  await page.click(".feuille .actions .bouton.principal"); // → sais-tu où le ranger ?
  await page.fill(".feuille .champ-nouveau-nom", "Uppercut");
  await rendu(page);
  await page.locator(".resultat.creer").click();
  await page.locator(".fiche-entete h1", { hasText: "Uppercut" }).waitFor();
  assert.ok((await page.locator("movenso-video-locale").count()) >= 1, "la vidéo capturée doit vivre sur la fiche créée");
  await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → explorateur Boxe
  await page.locator(".carte-nom", { hasText: "Uppercut" }).waitFor(); // visible dans la grille

  // lot 6 §5-7 (boucle 6.2, scénario B) : gestion des disciplines dans Plus
  await ouvrirPlus(page, "Disciplines et classement");
  // créer Karaté (nom seul) — création derrière le ＋ de l'encart Disciplines
  await revelerCreation(page, "Ajouter dans Disciplines", ".creation-discipline input");
  await page.fill(".creation-discipline input", "Karaté");
  await page.click(".creation-discipline .bouton");
  await rendu(page);
  // V2 (D-072) : on CHOISIT la discipline dans la rangée de puces → sa seule
  // fiche de gestion s'affiche (jamais dix cartes empilées).
  const selGestion = async (nom) => { await page.locator(".chip-gestion", { hasText: nom }).first().click(); await rendu(page); };
  await selGestion("Karaté");
  // tuning post-V3 : les compteurs vivent sur la ligne « N techniques · N catégories · N niveaux »
  // (sous la rangée de puces), plus dans la carte ; la notion de « sources » a quitté cet écran.
  assert.ok((await page.locator(".ecran").innerText()).includes("0 technique"), "compteurs de discipline attendus");
  // renommer → Karaté Shotokan : édition EN PLACE (post-V3 : plus de crayon).
  // Le nom est un champ éditable dans la carte de la discipline SÉLECTIONNÉE ;
  // on écrit et on valide par blur (déclenche le @change → majNomDiscipline).
  const champNomDiscipline = page.locator(".carte-discipline .titre-discipline-champ");
  await champNomDiscipline.fill("Karaté Shotokan");
  await champNomDiscipline.blur();
  await rendu(page);
  // le nom vit dans la VALEUR de l'input et dans la puce de gestion (pas dans le texte de la carte)
  assert.equal(await page.locator(".chip-gestion", { hasText: "Karaté Shotokan" }).count(), 1, "le renommage doit s'appliquer");
  // (post-V3 : « Ouvrir dans la Bibliothèque » a quitté cette carte)
  await selGestion("Karaté Shotokan");
  // D-233 : le glisser-déposer a été RETIRÉ — les flèches ▲/▼ sont le seul
  // mécanisme de réordonnancement, ici comme partout.
  assert.equal(await page.locator(".poignee-glisser").count(), 0, "plus aucune poignée de glisser (D-233)");
  await page.locator('[aria-label="Monter Karaté Shotokan"]').click();
  await finit(async () => assert.deepEqual(await page.locator(".chip-gestion").allInnerTexts(), ["Boxe", "Karaté Shotokan", "Aïkido"], "le bouton ▲ doit monter la discipline d'un cran (S2.9)"));
  await page.locator('[aria-label="Monter Karaté Shotokan"]').click();
  await finit(async () => assert.deepEqual(await page.locator(".chip-gestion").allInnerTexts(), ["Karaté Shotokan", "Boxe", "Aïkido"], "…et encore d'un cran, jusqu'en tête"));
  await finit(async () => assert.ok(
    ((await page.locator(".annonce-lecteur[role=status]").textContent()) ?? "").includes("position 1 sur 3"),
    "le déplacement doit être annoncé aux lecteurs d'écran (aria-live) (S2.9)",
  ));
  // …et retour d'un cran par ▼ (ce sont des boutons : doigt, clavier, TalkBack)
  await page.locator('[aria-label="Descendre Karaté Shotokan"]').click();
  await finit(async () => assert.deepEqual(await page.locator(".chip-gestion").allInnerTexts(), ["Boxe", "Karaté Shotokan", "Aïkido"], "le bouton ▼ doit redescendre d'un cran (S2.9)"));
  // en butée : pas de déplacement, annonce honnête
  await page.locator('[aria-label="Monter Boxe"]').isDisabled().then((d) => assert.ok(d, "▲ doit être désactivé en première position (S2.9)"));
  // retirer la discipline vide : 🗑️ déclenche directement un confirm() (post-V3)
  await selGestion("Karaté Shotokan");
  await page.locator('.carte-discipline [aria-label="Supprimer la discipline"]').click();
  await page.waitForSelector(".feuille-confirmation"); // C2 : feuille nommée
  await page.locator(".feuille-confirmation .bouton.danger").click();
  await finit(async () => assert.equal(await page.locator(".chip-gestion").filter({ hasText: "Karaté Shotokan" }).count(), 0, "la discipline vide doit se retirer"));
  // discipline NON vide : jamais un clic — 🗑️ ouvre directement le récap guardé
  // (post-V3 : plus d'étape « Préparer la suppression », plus de confirm simple)
  await selGestion("Boxe");
  // seule la carte de la discipline SÉLECTIONNÉE est rendue (post-V3) → une seule .carte-discipline
  const carteBoxe = () => page.locator(".carte-discipline").first();
  await carteBoxe().locator('[aria-label="Supprimer la discipline"]').click();
  await page.waitForSelector(".suppression-discipline");
  const recap = await page.locator(".suppression-discipline").innerText();
  assert.ok(recap.includes("2 techniques"), "le récap doit compter les techniques : " + recap);
  assert.ok(/point de restauration/i.test(recap), "le récap doit nommer le point de restauration (D-099 : plus de « snapshot »)");
  assert.ok(recap.includes("à rattacher"), "le récap doit dire que les notes personnelles survivent");
  // annuler : rien ne change
  await page.locator(".suppression-discipline .chip-filtre", { hasText: "Annuler" }).click();
  await finit(async () => assert.equal(await page.locator(".suppression-discipline").count(), 0, "annuler referme la préparation"));
  assert.ok((await page.locator(".ecran").innerText()).includes("Boxe"), "annuler ne supprime rien");
  // suppression réelle avec confirmation renforcée : les notes personnelles
  // reviennent « à rattacher », l'autre discipline ne bouge pas
  await carteBoxe().locator('[aria-label="Supprimer la discipline"]').click();
  await page.waitForSelector(".suppression-discipline");
  await page.locator(".suppression-discipline .action-danger", { hasText: "Supprimer la discipline" }).click();
  await page.waitForSelector(".feuille-confirmation");
  await page.locator(".feuille-confirmation .bouton.danger").click();
  await page.waitForTimeout(lent(300));
  assert.equal(await page.locator(".chip-gestion").filter({ hasText: "Boxe" }).count(), 0, "la discipline supprimée doit disparaître de Plus");
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // second appui : racine
  await page.waitForSelector(".chip-discipline");
  assert.equal(await page.locator(".chip-discipline").count(), 1, "seule Aïkido doit rester");
  // D-071 : les notes personnelles de Boxe reviennent « à rattacher » — désormais
  // dans Plus › Médias, en kpi « Captures à rattacher »
  await ouvrirPlus(page, "À traiter");
  {
    const kpi = page.locator(".kpi").filter({ has: page.locator(".kpi-libelle", { hasText: "Captures à rattacher" }) });
    assert.ok(Number(await kpi.locator(".kpi-nombre").innerText()) >= 2, "les notes personnelles de Boxe doivent revenir « à rattacher »");
  }

  // lot 6 §8 (boucle 6.3, scénario C) : taxonomies — créer, ordonner,
  // utiliser, puis supprimer AVEC arbitrage (usages visibles, remplacer /
  // retirer la classification / annuler — jamais de référence invalide)
  await ouvrirPlus(page, "Disciplines et classement");
  const carteAikido = () => page.locator(".carte-discipline").filter({ hasText: "Aïkido" }).first();
  // tuning post-V3 : Catégories et Niveaux sont des sections DÉDIÉES, visibles
  // seulement après avoir choisi une discipline (« Toutes » les masque). « Familles »
  // est devenu « Catégories » (plus de <details> à déplier).
  await selGestion("Aïkido");
  const lignesFamilles = () => page.locator('input[aria-label="Nom de la catégorie"]');
  // création derrière le ＋ de l'encart Catégories (post-V3). Créer AUTO-FERME
  // le petit formulaire : on ré-ouvre le ＋ avant chaque ajout.
  for (const nom of ["Immobilisations", "Projections"]) {
    await ouvrirCreationSection(page, "Catégories", "Ajouter une catégorie", 'input[placeholder="Nom de la catégorie"]');
    await page.locator('input[placeholder="Nom de la catégorie"]').fill(nom);
    await page.locator('input[placeholder="Nom de la catégorie"]').press("Enter");
    await rendu(page);
  }
  // D-233 : réordonnancement des catégories par les seules flèches (aller-retour)
  const carteCategories = () => page.locator(".carte-atelier").filter({ has: page.locator(".titre-atelier", { hasText: "Catégories" }) });
  await carteCategories().locator('[aria-label="Monter Projections"]').click();
  await finit(async () => assert.deepEqual(
    await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)),
    ["Projections", "Immobilisations"],
    "le bouton ▲ doit monter la catégorie d'un cran (S2.9)",
  ));
  await carteCategories().locator('[aria-label="Descendre Projections"]').click();
  await finit(async () => assert.deepEqual(
    await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)),
    ["Immobilisations", "Projections"],
    "le bouton ▼ doit descendre la catégorie d'un cran (S2.9)",
  ));
  await carteCategories().locator('[aria-label="Monter Projections"]').click();
  await finit(async () => assert.deepEqual(
    await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)),
    ["Projections", "Immobilisations"],
    "et retour à l'ordre de départ",
  ));
  // création d'un niveau derrière le ＋ de l'encart Niveaux (post-V3)
  await ouvrirCreationSection(page, "Niveaux", "Ajouter un niveau", 'input[placeholder="Nom du niveau"]');
  await page.locator('input[placeholder="Nom du niveau"]').fill("5e kyu");
  await page.locator('input[placeholder="Nom du niveau"]').press("Enter");
  await rendu(page);
  // classer Ikkyo avec la famille et le niveau
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await page.locator(".chip-discipline", { hasText: "Aïkido" }).click();
  await page.locator(".carte-technique", { hasText: "Ikkyo" }).first().click();
  await page.waitForSelector(".fiche-entete h1");
  await page.locator('.barre [aria-label="Modifier"]').click();
  await page.waitForSelector(".edition");
  await page.selectOption("#champ-categorie", { label: "Projections" }); // catégorie = menu déroulant
  await page.locator(".niveau-coche", { hasText: "5e kyu" }).locator("input").check(); // niveaux = cases à cocher
  await rendu(page);
  await page.locator('.fiche-actions [aria-label="Enregistrer"]').click();
  await finit(async () => assert.ok((await page.locator(".fiche-famille").innerText()).toLowerCase().includes("projections"), "la famille doit se voir sur la fiche"));
  // suppression d'une famille UTILISÉE : arbitrage, jamais un simple confirm
  await ouvrirPlus(page, "Disciplines et classement");
  await selGestion("Aïkido");
  await ouvrirSection(page, "Catégories");
  await page.locator('[aria-label="Retirer la catégorie"]').first().click(); // Projections (1re)
  await page.waitForSelector(".suppression-taxonomie");
  const arbitrage = await page.locator(".suppression-taxonomie").innerText();
  assert.ok(arbitrage.includes("1 technique") && arbitrage.includes("Ikkyo"), "l'arbitrage doit montrer les usages : " + arbitrage);
  await page.locator(".suppression-taxonomie .chip-filtre", { hasText: "Annuler" }).click();
  await finit(async () => assert.equal(await page.locator(".suppression-taxonomie").count(), 0, "annuler referme l'arbitrage"));
  assert.deepEqual(await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)), ["Projections", "Immobilisations"], "annuler ne supprime rien");
  // remplacer : les fiches sont reclassées, la valeur disparaît
  await page.locator('[aria-label="Retirer la catégorie"]').first().click();
  await page.locator(".suppression-taxonomie .chip-filtre", { hasText: "Remplacer par « Immobilisations »" }).click();
  await finit(async () =>
    assert.deepEqual(await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)), ["Immobilisations"], "la famille remplacée doit disparaître"));
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // mémoire : fiche Ikkyo
  await page.waitForSelector(".fiche-famille");
  assert.ok((await page.locator(".fiche-famille").innerText()).toLowerCase().includes("immobilisations"), "la fiche doit être reclassée vers la valeur de remplacement");
  // niveau utilisé : « retirer la classification » — la fiche reste intègre
  await ouvrirPlus(page, "Disciplines et classement");
  await selGestion("Aïkido");
  await ouvrirSection(page, "Niveaux");
  await page.locator('[aria-label="Retirer le niveau"]').first().click();
  await page.waitForSelector(".suppression-taxonomie");
  await page.locator(".suppression-taxonomie .action-danger", { hasText: "Retirer la classification" }).click();
  await rendu(page);
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // fiche Ikkyo
  await page.waitForSelector(".fiche-entete h1");
  const ficheApres = await page.locator(".ecran").innerText();
  assert.ok(!ficheApres.includes("5e kyu"), "le niveau supprimé ne doit plus apparaître sur la fiche");
  assert.ok(ficheApres.toLowerCase().includes("immobilisations"), "la famille de remplacement doit rester");

  /* ---- D-224 : fiche SANS vidéo mais AVEC illustration — la couverture prend
     la place du média, l'invitation à ajouter reste (compacte et honnête). ---- */
  assert.equal(await page.locator(".media-absent").count(), 1, "témoin : sans couverture, le bloc « aucun média » est là");
  // La couverture se pose par le GESTE du produit (D-269 : elle devient un
  // fichier, et l'inventaire la déclare) — jamais en écrivant le champ à la
  // main, ce qui prouverait un chemin que personne n'emprunte.
  await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const t = app.bibliotheque.techniques.find((x) => x.nom === "Ikkyo");
    const gif = "R0lGODlhAQABAIAAAP7urwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==";
    const octets = Uint8Array.from(atob(gif), (c) => c.charCodeAt(0));
    await app.definirCouvertureImage(t.id, new File([octets], "vignette.gif", { type: "image/gif" }));
  });
  await rendu(page);
  assert.equal(await page.locator(".couverture-fiche").count(), 1, "l'illustration s'affiche en tête de fiche (D-224)");
  assert.equal(await page.locator(".media-absent").count(), 0, "le bloc « aucun média » s'efface devant l'illustration");
  assert.ok((await page.locator(".couverture-fiche-pied").innerText()).includes("aucune vidéo"), "l'honnêteté reste dite : « aucune vidéo pour l'instant »");
  await page.locator(".couverture-fiche-pied .chip-filtre", { hasText: "Ajouter un média" }).click();
  await page.waitForSelector(".feuille");
  assert.ok((await page.locator(".feuille").innerText()).toLowerCase().includes("média"), "le CTA compact ouvre bien l'ajout de média");
}
await ctxA.close();
}
