/**
 * CHAPITRE e2e (S3.A7) — D-114 régression — réimporter deux fois le même pack avec vidéo ;
 * + D-222 : la MISE À JOUR d'un pack applique sous-titre et couverture fournis.
 * Contexte(s) Playwright propre(s) : OPFS isolé.
 */
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { unzipSync, zipSync, strToU8, strFromU8 } from "fflate";
import { surveiller, lent, navigateur, rendu } from "../harnais.mjs";

export async function run() {
/* ===== D-114 régression — RÉIMPORTER DEUX FOIS LE MÊME PACK de discipline AVEC
   VIDÉO ne casse rien : promotion IDEMPOTENTE (une seule vidéo physique), la 2ᵉ
   passe reconnaît le déjà-installé, aucune erreur (signalé en recette appareil). ===== */
{
  // 1) fabriquer un vrai pack de discipline AVEC une vidéo (média d'enseignement,
  //    donc publiable — le personnel ne l'est pas), via le flux d'export de l'app.
  const ctxK = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageK = await ctxK.newPage();
  surveiller(pageK);
  await pageK.goto("http://localhost:4517/");
  await pageK.waitForSelector(".action-douce");
  await pageK.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const dId = await app.creerDiscipline("Boxe");
    await app.creerTechnique(dId, "Direct");
    const t = app.bibliotheque.techniques.find((x) => x.nom === "Direct");
    await app.ajouterMediaFiche(
      t.id,
      { fichier: new File([new Uint8Array(3072).fill(5)], "direct.webm", { type: "video/webm" }) },
      { provenance: "enseignement", attribution: "Coach" }, // non-personnel → voyage dans le pack
    );
    window.__dId = dId;
  });
  const packAvecVideo = join(tmpdir(), "movenso-e2e-pack-boxe.movpack");
  const [dlPack] = await Promise.all([
    pageK.waitForEvent("download"),
    pageK.evaluate(async () => {
      const app = document.querySelector("movenso-app");
      await app.preparerPublication(window.__dId, { avecVideos: true, auteur: "Coach" });
      await app.enregistrerPublicationLocale();
    }),
  ]);
  await dlPack.saveAs(packAvecVideo);
  await ctxK.close();

  // 2) importer CE pack deux fois de suite sur une installation neuve.
  const ctxJ = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
  const pageJ = await ctxJ.newPage();
  surveiller(pageJ);
  await pageJ.addInitScript(() => {
    navigator.storage.estimate = async () => ({ usage: 0, quota: 5_000_000_000 });
  });
  await pageJ.goto("http://localhost:4517/");
  await pageJ.waitForSelector(".action-douce");
  const importerPackJ = async (depuisVide, chemin = packAvecVideo) => {
    if (depuisVide) {
      const [sel] = await Promise.all([
        pageJ.waitForEvent("filechooser"),
        pageJ.locator(".action-douce", { hasText: "Importer" }).click(),
      ]);
      await sel.setFiles(chemin);
    } else {
      await pageJ.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
      await pageJ.waitForSelector(".ecran.plus");
      const [sel] = await Promise.all([
        pageJ.waitForEvent("filechooser"),
        pageJ.locator(".ligne-menu", { hasText: "Importer un pack" }).click(),
      ]);
      await sel.setFiles(chemin);
    }
    await pageJ.locator(".feuille .actions .bouton.principal").click(); // « Installer » ou « Mettre à jour »
    const rapport = pageJ.locator('.feuille[aria-label="Rapport d\'import"]');
    await rapport.waitFor();
    await rapport.locator(".actions .bouton.principal", { hasText: "Fermer" }).click();
    await rendu(pageJ);
  };
  await importerPackJ(true); // 1er import, depuis l'état vide
  // 2ᵉ import du MÊME pack (déjà installé) : la feuille propose « Mettre à jour »
  await importerPackJ(false);
  const bilanJ = await pageJ.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    let videos = 0;
    try {
      const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos");
      for await (const _ of d.keys()) videos++;
    } catch { /* aucun */ }
    return { videos, techniques: app.bibliotheque.techniques.length, toast: app.toast || "" };
  });
  assert.equal(bilanJ.videos, 1, "réimporter le même pack ne duplique pas la vidéo physique (promotion idempotente D-114)");
  assert.equal(bilanJ.techniques, 1, "réimporter le même pack ne duplique pas la technique (idempotence D-067)");
  assert.doesNotMatch(bilanJ.toast, /impossible|erreur/i, "aucune erreur au réimport du même pack : " + bilanJ.toast);

  /* ---- D-222 : la MISE À JOUR du pack applique le sous-titre et la couverture
     fournis par le pack propriétaire (régression : pack Yoga 0.1.0 → 0.2.0,
     mise à jour sans image). On fabrique une v2 RÉELLE du même conteneur
     (mêmes éléments, champs enrichis, intégrité recalculée) et on la
     réimporte par le circuit normal. ---- */
  const archive = unzipSync(new Uint8Array(readFileSync(packAvecVideo)));
  const bibV2 = JSON.parse(strFromU8(archive["bibliotheque.json"]));
  const directV2 = bibV2.techniques.find((t) => t.nom === "Direct");
  directV2.nomTraditionnel = "Jab";
  // La couverture fournie par un pack est une IMAGE en fichier (D-269) : on
  // fabrique le pack comme la chaîne de publication le ferait — octets dans
  // `images/<empreinte>`, entrée d'inventaire dans la bibliothèque, et ligne
  // dans l'inventaire d'intégrité du manifeste. Un pack bâti autrement serait
  // refusé, et le test prouverait un chemin que personne n'emprunte.
  const octetsImage = new Uint8Array([0xff, 0xd8, 0xff, 0xdb, 0x00, 0x43, 0x00, 0x08, 0xff, 0xd9]);
  const empreinteImage = createHash("sha256").update(octetsImage).digest("hex");
  directV2.couverture = { type: "fichier", imageId: empreinteImage };
  bibV2.images = [{ id: empreinteImage, mime: "image/jpeg", taille: octetsImage.length }];
  archive[`images/${empreinteImage}`] = octetsImage;
  const manifesteV2 = JSON.parse(strFromU8(archive["manifeste.json"]));
  manifesteV2.fichiers.push({ chemin: `images/${empreinteImage}`, taille: octetsImage.length, sha256: empreinteImage });
  const octetsBib = strToU8(JSON.stringify(bibV2));
  const shaBib = createHash("sha256").update(octetsBib).digest("hex");
  manifesteV2.empreinte = shaBib;
  manifesteV2.versionEditoriale = (manifesteV2.versionEditoriale ?? 1) + 1;
  for (const f of manifesteV2.fichiers) if (f.chemin === "bibliotheque.json") { f.sha256 = shaBib; f.taille = octetsBib.length; }
  archive["bibliotheque.json"] = octetsBib;
  archive["manifeste.json"] = strToU8(JSON.stringify(manifesteV2));
  const packV2 = join(tmpdir(), "movenso-e2e-pack-boxe-v2.movpack");
  writeFileSync(packV2, Buffer.from(zipSync(archive)));
  await importerPackJ(false, packV2); // « Mettre à jour » via Plus › Importer
  const apresMaj = await pageJ.evaluate(() => {
    const t = document.querySelector("movenso-app").bibliotheque.techniques.find((x) => x.nom === "Direct");
    const app = document.querySelector("movenso-app");
    return {
      trad: t.nomTraditionnel ?? "",
      couv: t.couverture?.imageId ?? "",
      declaree: (app.bibliotheque.images ?? []).some((i) => i.id === t.couverture?.imageId),
      total: app.bibliotheque.techniques.length,
    };
  });
  assert.equal(apresMaj.total, 1, "la mise à jour ne duplique rien");
  assert.equal(apresMaj.trad, "Jab", "la mise à jour applique le sous-titre fourni par le pack (D-222)");
  assert.equal(apresMaj.couv, empreinteImage, "la mise à jour applique la couverture fournie par le pack (D-222)");
  assert.ok(apresMaj.declaree, "et l'image du pack a rejoint notre inventaire (D-269)");
  // S1.9 (D-163) : refus AVANT d'écrire quand l'espace fiable manque — export
  // ET staging d'import (borne basse = taille de l'archive). On simule un
  // stockage plein, rien ne doit s'écrire, le message dit les deux tailles.
  const refusEspace = await pageJ.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const originale = app.stockage.estimerEspace.bind(app.stockage);
    app.stockage.estimerEspace = async () => ({ usage: 1_000_000_000, quota: 1_000_000_000 });
    app.toast = "";
    await app.exporterTout(true); // 1 vidéo présente → refus avant le temporaire
    const toastExport = app.toast;
    app.toast = "";
    await app.importerPack(new File([new Uint8Array([0x50, 0x4b, 0x03, 0x04, 0, 0, 0, 0])], "plein.movpack"));
    const toastImport = app.toast;
    const proposition = app.importEnAttente;
    app.stockage.estimerEspace = originale; // on rend l'estimation réelle
    return { toastExport, toastImport, proposition };
  });
  assert.match(refusEspace.toastExport, /Espace insuffisant/, "l'export est refusé AVANT d'ouvrir le temporaire : " + refusEspace.toastExport);
  assert.match(refusEspace.toastImport, /Espace insuffisant/, "l'import est refusé AVANT tout staging (borne basse) : " + refusEspace.toastImport);
  assert.equal(refusEspace.proposition, null, "aucune proposition d'import n'est créée quand l'espace manque");
  await ctxJ.close();
}
}
