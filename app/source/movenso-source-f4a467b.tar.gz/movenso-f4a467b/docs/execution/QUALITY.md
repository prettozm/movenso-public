# QUALITY — Recette, non-régression et capacités

## 1. Modèle de fiche recette

### REC-XXX-000 — Titre

**Objectif**

Comportement utilisateur démontré.

**Préconditions**

- État initial :
- Données :
- Plateforme :

**Étapes**

1. ...
2. ...
3. ...

**Résultat attendu**

- ...

**Risques de régression**

- ...

**Preuves**

- Test automatique :
- Vérification manuelle :
- Android réel :
- Capture ou artefact :

**Statut**

`NON EXÉCUTÉ` / `AUTOMATISÉ` / `DÉMONTRÉ MANUELLEMENT` / `PARTIEL` / `ÉCHEC`

---

## 2. Modèle de non-régression

### NR-XXX-000 — Titre

**Invariant**

Ce qui doit toujours rester vrai.

**Origine**

- Lot :
- Boucle :
- Commit :

**Couverture**

- Test :
- Recette :
- Plateformes :

**Dépendances**

- Workflows voisins :

**Statut**

`ACTIF` / `PARTIEL` / `À RENFORCER`

---

## Recettes du lot 01

### REC-001-001 — Racine Bibliothèque : liste, recherche globale, état vide

**Objectif** : l'onglet Bibliothèque mène toujours à la liste des
disciplines ; elle porte la recherche globale ; vide, elle propose
exactement Importer un pack et Créer une discipline.

**Préconditions** : (a) installation vierge ; (b) installation avec ≥ 1 discipline.

**Étapes**

1. Ouvrir l'onglet Bibliothèque.
2. (a) Vérifier la phrase d'état vide + les deux actions ; créer une discipline.
3. (b) Vérifier une carte par discipline ; chercher une technique via la
   recherche globale ; ouvrir un résultat ; revenir.

**Résultat attendu** : liste toujours affichée, recherche globale
fonctionnelle, état vide actionnable sans onboarding.

**Risques de régression** : e2e supposant le direct-vers-discipline ;
création de discipline en double.

**Preuves** : e2e `parcours.mjs` (scénarios A/B adaptés) · capture manuelle à la fin du lot.

**Statut** : `AUTOMATISÉ`

### REC-001-002 — Racine Pratique : trois usages, jamais un historique

**Objectif** : Pratique donne accès à Favoris (état vide honnête, pas de
faux comportement) et Compositions (sous-destination) ; « À reprendre »
n'apparaît que s'il existe une action réellement inachevée.

**Étapes** : ouvrir l'onglet Pratique sans capture inachevée (pas de
section À reprendre) ; ouvrir Compositions ; revenir (retour → Pratique) ;
créer une capture non rattachée puis vérifier son apparition dans À reprendre.

**Résultat attendu** : trois sections max, pas de texte « ton carnet est
vide », pas d'historique de consultation.

**Preuves** : e2e `parcours.mjs` (scénario F, bloc Pratique) ; l'apparition
d'une capture inachevée est couverte en 1.3+ quand la capture « plus tard »
redirigera vers Pratique.

**Statut** : `AUTOMATISÉ` (y compris l'apparition d'une capture « plus tard » dans À reprendre — boucle 1.3)

### REC-001-003 — L'Accueil n'existe plus ; démarrage sur la Bibliothèque

**Objectif** : au lancement (premier, après fermeture, après mise à jour),
l'application ouvre la Bibliothèque ; trois onglets exactement ; une
ancienne préférence de démarrage « accueil » est migrée automatiquement ;
une capture « garder pour plus tard » atterrit dans Pratique › À reprendre.

**Étapes** : lancer à vide (état vide, 2 actions) ; lancer avec données
(liste des disciplines) ; recharger (retour à la Bibliothèque) ; capturer
« plus tard » (arrivée sur Pratique).

**Résultat attendu** : aucun écran ni route Accueil ; migration silencieuse
et persistée de la préférence ; aucune donnée perdue.

**Preuves** : e2e `parcours.mjs` (scénarios A/B) · unit
`tests/preferences.test.ts` (migration pure : accueil → bibliotheque,
préférences conservées, contenus illisibles → défauts).

**Statut** : `AUTOMATISÉ` (Android réel : à vérifier au checkpoint du lot)

### REC-001-004 — Actions contextuelles, jamais de Capturer global

**Objectif** : aucun bouton flottant global ; « Ajouter » n'apparaît que
sur une discipline (et ouvre le flux existant, discipline présélectionnée) ;
la fiche garde ses actions locales ; l'édition de composition porte le
point d'entrée « capturer un repère » ; la barre basse disparaît sous les
feuilles (capture, import).

**Preuves** : e2e — `.fab` absent sur racine/fiche/Pratique/Atelier,
présent sur discipline ; capture → création à la volée présélectionnée ;
note directe au carnet depuis la fiche.

**Statut** : `AUTOMATISÉ`

### NR-001-002 — Aucune action globale ambiguë

**Invariant** : `.fab` n'existe que sur l'écran discipline, libellé
« Ajouter » ; jamais « Capturer » comme bouton universel.

**Origine** : lot 01, boucle 1.4. **Couverture** : e2e (asserts count 0
sur racine, fiche, Pratique, Atelier). **Statut** : `ACTIF`

### REC-001-005 — Conservation d'état et retour déterministe

**Objectif** : le retour d'une fiche restaure filtres et position de
l'explorateur ; changer d'onglet puis revenir restaure l'écran, la pile
et le défilement de l'onglet ; un second appui sur l'onglet actif revient
à sa racine ; le bouton retour Android suit l'ordre du lot 1 §9.

**Préconditions** : bibliothèque peuplée (Judo réuni).

**Étapes** : filtrer « gari » → ouvrir une fiche → retour (filtre et
résultats intacts) → aller sur Pratique → revenir (même écran filtré) →
second appui (racine). Android réel : retour depuis fiche/édition/feuille/
racines selon §9.

**Preuves** : e2e `parcours.mjs` (bloc « conservation d'état ») ; retour
Android : à vérifier sur appareil (l'e2e navigateur ne déclenche pas le
backButton Capacitor).

**Statut** : `AUTOMATISÉ` (web) · `DÉMONTRÉ MANUELLEMENT` (Android réel — recette humaine 2026-07-12 : les 6 points du retour §9 confirmés)

### NR-001-003 — Le retour ne perd jamais le contexte

**Invariant** : retour de fiche → même liste, mêmes filtres, même
position ; bascule d'onglet sans réinitialisation pendant la session.

**Origine** : lot 01, boucle 1.5. **Couverture** : e2e. **Statut** : `ACTIF`

### NR-001-001 — Trois destinations exactement

**Invariant** : la barre basse contient exactement Bibliothèque, Pratique,
Atelier, dans cet ordre ; aucun onglet Accueil ou Capturer.

**Origine** : lot 01, boucle 1.3. **Couverture** : e2e scénario A
(count === 3 + ordre des libellés). **Statut** : `ACTIF`

## Recettes du lot 02

### REC-002-000 — Raccord après lot 1

**Objectif** : la racine Bibliothèque peuplée ne porte plus l'action
Importer (état vide et Atelier seulement) ; placeholder de recherche
lisible sur téléphone ; le FAB ne masque jamais la dernière rangée à plein
défilement ; indicateur d'onglet actif = barrette courte (jamais un trait
pleine largeur) ; état vide des Favoris neutre.

**Preuves** : e2e (absence d'Importer sur racine peuplée, import via
Atelier, texte Favoris sans « version ») · mesure programmatique du
chevauchement FAB (610 < 726 px) · captures regardées (D-026).

**Statut** : `AUTOMATISÉ` (+ vérification visuelle)

### REC-002-001 — Cartes de disciplines : compter le visible, pas les packs

**Objectif** : une carte affiche le nombre d'identités uniques (jamais
l'addition brute des contributions), le nombre de sources (> 1), le nombre
d'identités à plusieurs voix ; une discipline vide affiche « 0 technique ·
prête à être complétée » ; aucun identifiant de pack.

**Preuves** : unit `tests/resume-discipline.test.ts` (fixtures Judo
réelles : identités < 160, 2 sources, 24+règles plurivoix ; vide = zéros) ·
e2e (regex sur la carte Judo + absence de « club-judo »).

**Statut** : `AUTOMATISÉ`

### REC-002-002 — Recherche globale : contexte et conservation

**Objectif** : chaque résultat porte vignette (ou fallback), nom,
appellation, discipline et « N voix » quand il y en a plusieurs ; une
identité n'apparaît qu'une fois ; ouvrir un résultat puis revenir restaure
la requête et les résultats.

**Preuves** : e2e (un seul Harai-goshi ; `.fam` contient « Judo » ; retour →
input et résultats intacts).

**Statut** : `AUTOMATISÉ`

### REC-002-003 — Filtres cumulables : visibles, réinitialisables, jamais ambigus

**Objectif** : les filtres actifs restent visibles ; « Réinitialiser les
filtres » apparaît seulement si ≥ 1 filtre actif ; zéro résultat filtré
affiche « Aucune technique ne correspond à ces filtres » — jamais l'état
d'une discipline vide.

**Preuves** : e2e (Jaune + texte introuvable → message dédié →
réinitialisation → grille complète, recherche vidée, chip disparue).

**Statut** : `AUTOMATISÉ`

### REC-002-004 — Discipline vide sans impasse

**Objectif** : ouvrir une discipline vide affiche « X ne contient encore
aucune technique » + action principale « Créer la première technique »
(workflow existant, discipline présélectionnée) + action secondaire
« Importer un pack » ; création → fiche → retour → la technique est dans
la grille.

**Preuves** : e2e scénario A (Aïkido vide → Ikkyo) ; le texte périmé
« + Capturer » (bouton disparu au lot 1) est retiré.

**Statut** : `AUTOMATISÉ`

### REC-002-005 — Les filtres appartiennent à leur discipline

**Objectif** : recherche, source, famille, niveau sont conservés par
discipline pendant la session ; rouvrir une discipline restaure son
dernier état ; ouvrir une autre discipline ne contamine pas la première.

**Preuves** : e2e (« gari » restauré au retour racine → Judo).

**Statut** : `AUTOMATISÉ`

### REC-002-006 — Une identité, plusieurs voix : vue par source sans duplication

**Objectif** : sous filtre de source, chaque identité reste unique et son
aperçu privilégie un média de cette source (le média principal global ne
change pas) ; en vue « toutes sources », les identités réunies portent un
badge discret « N voix » ; les chips de source affichent des libellés
éditoriaux, jamais un slug.

**Preuves** : e2e (Harai-goshi unique sous Kodokan puis sous Club judo ;
badge présent ; « club-judo » absent des chips ; repère personnel retrouvé
par la recherche globale — scénario E).

**Statut** : `AUTOMATISÉ`

### NR-002-002 — Une identité n'est jamais comptée deux fois

**Invariant** : les compteurs de la racine portent sur les identités de la
discipline, pas sur les contributions des packs.

**Origine** : lot 02, boucle 2.1. **Couverture** : unit + e2e. **Statut** : `ACTIF`

### NR-002-001 — L'import ne vit jamais sur la racine peuplée

**Invariant** : « Importer un pack » n'apparaît que sur l'état vide de la
Bibliothèque et dans l'Atelier (Protéger).

**Origine** : lot 02, boucle 2.0 (recette humaine du lot 1).
**Couverture** : e2e. **Statut** : `ACTIF`

## Recettes du lot 03

### REC-003-001 — En-tête de fiche compact

**Objectif** : l'en-tête porte retour, nom/appellation (corps de fiche),
et un menu ⋮ (Modifier les informations générales · Retirer cette
technique de la bibliothèque) ; aucun bouton permanent Retirer/Terminer/
Capturer ; l'édition est sauvegardée au fil de l'eau et se ferme par
« Fermer » ou le retour Android (qui ferme d'abord le menu ouvert).

**Preuves** : e2e (absence de « Terminer » sur la fiche ; menu ⋮ portant
les deux actions ; fermeture d'édition via `.fermer` au scénario A).

**Statut** : `AUTOMATISÉ`

### REC-003-002 — Média principal : légende, galerie, fallback

**Objectif** : le média principal s'affiche avec une légende éditoriale
« auteur · provenance » (« Moi » pour un contenu personnel, jamais un
slug de pack) ; s'il existe d'autres médias, une galerie compacte permet
d'en afficher un autre en tête — c'est un choix de session qui ne change
jamais le média principal global ; sans aucun média, un état propre
« Aucun média pour l'instant » propose « Ajouter un média ».

**Preuves** : e2e (`.media-absent` + action-douce sur une technique sans
média ; légende avec « · » ne contenant aucun slug ; clic sur la galerie
→ un seul `.galerie-item.actif`, le média affiché ne se répète pas dans
les voix).

**Statut** : `AUTOMATISÉ`

### REC-003-003 — Ajouter un média depuis la fiche

**Objectif** : une action « Ajouter un média » est accessible depuis la
fiche (menu ⋮, galerie, état « Aucun média ») sans quitter la fiche ni
passer par le flux générique Capturer ; elle propose Filmer maintenant /
vidéo de l'appareil / coller un lien ; elle ne redemande JAMAIS la
technique ; elle ne pose que les questions utiles (qui l'a produit,
attribution si ce n'est pas moi, libellé facultatif) ; après ajout le
média apparaît immédiatement (galerie + légende avec auteur et
provenance) et le retour reste sur la fiche ; le média affiché peut être
choisi comme aperçu principal par l'action explicite « Utiliser comme
aperçu principal de cette technique » (§4).

**Preuves** : e2e (menu ⋮ → feuille sans champ « À quelle technique ? » ;
lien collé + « Une ressource » + attribution → galerie enrichie, légende
« [attribution] · Ressource », écran resté fiche ; action « aperçu
principal » visible quand le média affiché n'est pas le principal, et
disparue une fois le choix appliqué ; « Ajouter » désactivé pour une
ressource sans attribution — même règle que la validation domaine).

**Statut** : `AUTOMATISÉ`

### REC-003-004 — Voix importée intacte, adaptation locale (D-027)

**Objectif** : une voix importée n'est jamais éditable directement ; elle
affiche « Ce contenu vient de [source]. L'original reste intact. Tu peux
ajouter ta note ou créer une adaptation locale. » ; « Créer une adaptation
locale » produit une nouvelle contribution locale préremplie, attribuée
« Adaptation locale d'après [source] », affichée séparément de l'original
et directement modifiable ; une contribution créée localement reste
directement modifiable.

**Étapes** : ouvrir une voix Kodokan → constater l'absence d'édition
inline + l'explication → créer l'adaptation → la modifier → vérifier que
l'original est intact → réimporter le pack → vérifier que l'adaptation
n'est pas écrasée.

**Résultat attendu** : invariants 57-64 respectés ; aucun champ grisé sans
explication.

**Preuves** : e2e (une seule voix ouverte à la fois — accordéon vérifié ;
titres éditoriaux sans slug ; deux voix importées protégées avec
l'explication ; aucune zone d'édition inline sur une voix importée alors
que la locale en a une ; adaptation créée ouverte, modifiée, original
octet pour octet identique avant/après ; réimport Kodokan → adaptation
conservée, voix importée strictement identique) + unit
(`rapprochement.test.ts` : « D-027 — une réimportation restaure l'original
et n'écrase jamais l'adaptation locale »).

**Représentation retenue (D-062, §21)** : l'adaptation est une contribution
`personnel` AVEC attribution (« Adaptation locale d'après [source] »),
sans `origine` — le carnet ne garde que le personnel sans attribution.
Faiblesse de modèle documentée : pas de marqueur explicite d'adaptation ;
le lot 6 devra en tenir compte pour l'exclusion de publication (D-063).

**Statut** : `AUTOMATISÉ`

### REC-003-005 — Relations dans la fiche (refondu D-138 R5/R19)

**Objectif** : la section « Relations · N » de la fiche présente un aperçu
**compact groupé par rôle** (≈2 liens/rôle, avec la raison de chaque lien
et la couleur/icône du rôle ; « Présente dans » à part) ; toucher une
ligne ouvre la fiche cible et le retour revient à la fiche précédente sans
perdre le contexte (§19) ; l'**icône réseau** de la barre du haut ouvre la
**Carte** centrée, le lien **« Voir toutes les relations »** ouvre l'écran
Relations en **Liste** centré sur la technique ; « Utilisée dans · N » reste
un accès compact (§12). **Changement D-138** : le dépliage « sur place » du
lot 3 est supprimé (remplacé par l'ouverture de l'écran Relations).

**Preuves** : e2e sur Juji Gatame (>3 relations) : en-tête « Relations · N »,
aperçu capé (`.rel-ligne` ≤ N), « Voir toutes les relations » → écran
Relations en vue Liste ; navigation par `button.rel-ligne` puis retour rouvre
la fiche d'origine (Juji Gatame et O-soto-gari du Club). La source par
relation n'existe pas dans le modèle (`Relation` = type + cibleId).

**Statut** : `AUTOMATISÉ`

### REC-138-001 — Carte des relations robuste (R6/R7/R8, refondue D-140)

**Objectif** : la vue **Carte** est une **mindmap HTML pannable/zoomable**
(refonte D-140 de la version 100 % SVG, jugée illisible par défaut et sans
vignettes) : hub au centre + **cartes-vignettes** (vraie `<img>`, liseré
coloré par rôle, nom + raison) placées par rôle (avant gauche, après droite,
opposition bas, pair haut, contexte bas-gauche), reliées par des **courbes de
Bézier** colorées (couche `<svg>` de fond) ; **glisser = pan**, **molette =
zoom**, **deux doigts = pincement** via `transform` CSS ; **fit lisible par
défaut** (plancher `K_FIT_MIN`, ne grossit jamais au-delà de 1, scène centrée
sur le hub ; au-delà on déborde et on se déplace ; le transform persiste entre
rendus et se recadre au changement de centre / plein écran) ; **⊙ / double-
toucher = fit** ; **toucher une carte recentre** (l'historique n'alimente plus
que le fil d'Ariane d'Explorer — retiré de l'en-tête de la Carte, D-160) ; le
**hub ouvre la fiche** ; pastille ⚠️ ; **bouton plein écran ⛶** masque tout le
chrome (re-appui pour sortir). **Exploration multi-niveaux (D-158→D-160)** :
badge « +n » par nœud déplie ses voisins **sur place** (niveau 2 atténué,
jamais de doublon de nœud, « − » replie) ; la carte « +N autres » d'une
famille capée **déplie la famille sur place** (plus de renvoi vers la Liste,
D-160) ; **chips légende + filtre** par famille de liens ; **⊞/⊟** tout
déplier / replier tout ; **texte de raison jamais tronqué** (la carte grandit,
~22 car./ligne, 8 lignes max) ; **aucun chevauchement de tuiles** (séparation
symétrique convergente, seul le hub est fixe) ; le pointeur n'est capturé
qu'au **seuil de glissement** (les taps sur cartes/badges restent des clics).

**Preuves** : e2e (vue Carte rendue : `.rel-carte-scene` présente,
`.rel-carte-liens` avec `viewBox`, ≥2 `.rel-carte-carte`, transform `scale`
appliqué par le fit, bascule plein écran `.rel-carte.plein` puis sortie,
dépliage `.rel-carte-depl` → cartes `.niveau2` sans doublon puis repli — le
harnais échoue sur toute erreur JS) ; contrôle programmatique D-160
(O-soto-gari 390×730 : « +N autres » 15 → 22 cartes sur place, tout déplier →
40 cartes avec **0 chevauchement** et **0 note tronquée**, pan intact, 0 fil
d'Ariane dans la Carte) ; confirmé visuellement (hub centré lisible, rôles
colorés — vert avant / bleu après / violet contre —, vignettes + raisons).

**Statut** : `AUTOMATISÉ` (rendu + transform + plein écran + dépliage) ;
gestes pan/zoom/pincement/double-toucher confirmés visuellement (non
simulables en e2e).

### REC-138-002 — Point de départ + polish Liste (R2/R14)

**Objectif** : sans centre, l'onglet affiche « Choisis un point de départ »
(recherche + « Récemment consultées » + Favoris en chips + « Explorer au
hasard ») — jamais de redirection vers la Bibliothèque. Dans la Liste : la
carte centrale est **collante** et se **réduit en bandeau compact** au
défilement ; les chips de filtre défilent sans barre grise permanente, le
filtre actif est ramené dans la vue.

**Preuves** : e2e (chips de filtre présents ; carte centrale `position:
sticky`) ; confirmé visuellement (bandeau « O-soto-gari · 16 techniques
reliées » compacté au scroll ; Favoris en chips sur le point de départ).

**Statut** : `AUTOMATISÉ` (chips + sticky) ; compaction au scroll et retour
auto sur le filtre actif confirmés visuellement.

### REC-140-001 — Rôles rétro-appliqués + remise en ordre de l'écran Relations

**Objectif** : sur une bibliothèque persistée **avant D-136** (types de
relation par défaut sans `role`), l'écran Relations doit retrouver toutes ses
capacités : (a) **Explorer** propose les 4 intentions dès que les arêtes
existent (Construire un enchaînement = `after`, Trouver une préparation =
`before`, Comparer = `peer`, Voir les contres = `opposition`) — plus jamais
réduit au seul « comparer » ; (b) la **Liste** peuple le groupe **« Enchaîné
depuis »** (inverse dérivé d'`enchaine` = rôle `before`) ; (c) la **Carte**
place les cartes par rôle. La cause racine était le repli sur `peer`
(`roleAffiche`) faute de rôle sur les types persistés. Correctif = **migration
de schéma 3 → 4** (`retroRolesDefaut`) qui réinjecte `role`/`ordre` sur les
types par défaut par id stable, **sans écraser un rôle éditorial explicite**.
Corollaire UX : le **fil d'Ariane est masqué dans la Liste** (doublon perçu
avec « Enchaîné depuis ») — conservé sur Carte et Explorer.

**Preuves** : unitaires — `tests/composition.test.ts` (migration 1→…→4 :
rôles présents ; migration 3→4 ciblée : défauts rétro-appliqués
`prepare→before`/`enchaine→after`/`contre→opposition`/`similaire→peer`, choix
éditorial `context` préservé) ; confirmé visuellement sur O-soto-gari
(Explorer : 4 intentions ; Liste : « Enchaîné depuis » = 11 techniques ;
Carte : rôles colorés).

**Statut** : `AUTOMATISÉ` (migration + rôles) ; effet écran confirmé
visuellement.

### REC-148-001 — Mindmap : mapping déterministe par type métier + gabarit spatial (recette O-soto-gari)

**Objectif** : chaque relation est placée d'après son **type métier réel**
(rôle brut du type), dans une **zone nommée** fixe — jamais par l'ordre / le
nombre / la place restante, et **jamais par repli vers Similaire**. Cas de
recette **O-soto-gari** : Similaires en haut ; Enchaînée depuis à gauche (2 +
« +9 ») ; Enchaîne vers à droite (2 + « +2 ») ; **Fondamentaux requis** sous le
centre = **Kihon-dosa + Ukemi** ; **Contre** = O-soto-gaeshi **centré** sous les
fondamentaux (pas rejeté à droite). Un type sans rôle mais « fondamental »
(id/libellé) → Fondamentaux ; sinon → « Autres liens ». Aucun titre de famille
tronqué ; pas de moitié inférieure vide ; hub ≈ 38 % centré, visible sans
défiler ; chips légende/filtre ; recherche par icône ; Fondamentaux en **or**.

**Preuves** : e2e (O-soto-gari : famille zone `bottom` contient Kihon-dosa ;
la zone `top`/Similaires ne contient **jamais** Kihon-dosa/Ukemi ; hub entre
en-tête et nav sans défiler) ; unit `donnees-kodokan.test.ts` (type
`fondamentaux` rôle `context`, O-soto-gari porte 2 « Fondamentaux requis ») ;
confirmé visuellement 390×844 sombre.

**Statut** : `AUTOMATISÉ` (mapping + placement + hub visible).

### REC-141-002 — Mindmap : carte synthétique à hauteur fixe (D-147)

**Objectif (recette mobile ~390×844 portrait)** : la Mindmap est une **zone-carte
à hauteur fixe**, pas une liste verticale. Critères : la **technique centrale est
entièrement visible sans défiler la page** (jamais sous la nav) ; le **titre + le
compteur** de chaque famille non vide sont visibles ; **≥ 1 carte** de chaque
famille non vide est perceptible ; la **nav basse ne recouvre aucun contenu** ; la
**direction** des relations se comprend par la position (Similaires haut ·
Précurseurs gauche · Suites droite · Fondamentaux bas · Contres bas-droite) + les
connecteurs colorés ; une famille de **11 relations ne transforme pas la carte en
colonne** (2 cartes + « +N ») ; **aucun défilement** nécessaire pour comprendre la
carte initiale.

**Preuves** : e2e (onglet Mindmap : `.rel-mm-radial`, `.rel-mm-hub` unique, ≥2
`.rel-mm-branche`, ≥1 flèche `<path>`, 0 numéro) ; contrôle programmatique 390×844
(`.rel-mm-hub` à y≈400–540, nav à y≈790 → hub visible sans scroll) + confirmé
visuellement en thème sombre (O-soto-gari : hub « 19 relations » centré, Similaires
2+« +1 », Enchaîné-depuis 2+« +9 », Enchaîne-vers 2+« +2 », Contre, flèches).

**Statut** : `AUTOMATISÉ` (structure + hub visible sans scroll) ; rendu confirmé
visuellement.

### REC-141-001 — Mindmap « radiale » en parallèle de la Carte (comparaison UX)

**Objectif** : l'écran Relations offre **4 onglets — Liste · Carte ·
Mindmap · Explorer**. « Mindmap » (id de vue `classique`) est une **mindmap
radiale** (D-143, alignée au prototype porteur) : la technique **au centre**,
une **branche par rôle** disposée autour — variantes en haut, précurseurs
(`before`) à gauche, suites (`after`) à droite, fondamentaux/kata (`context`)
et contres (`opposition`) sous le centre — reliée au hub par une **flèche de
Bézier colorée par rôle** (mesurée sur le DOM, best-effort). **Grandes cartes
VERTICALES** (vignette 16/10 + badge de rôle + nom + famille) et **libellés
flottants colorés** au-dessus de chaque groupe (D-144) ; hub central avec badge
« N relations ». **Sans numérotation** ; libellé → Liste filtrée ; « + N
autre » déplie sur place ; Tout déplier / Réduire / Centrer. Grille **fluide**
→ pas de scroll horizontal, ni rail latéral.
Historique des refontes : radiale D-135 → SVG pan/zoom D-138 (→ devenue la
Carte D-140) → timeline verticale D-142 (numéros + rail : **rejetée par le
porteur**) → **retour au radial du prototype D-143**. Coexistence
**temporaire** avec la Carte (D-140) jusqu'à l'arbitrage.

**Preuves** : e2e (onglet « Mindmap » : `.rel-mm-radial` + un `.rel-mm-hub`,
≥2 `.rel-mm-branche`, **0** `.rel-mm-rang` — numérotation retirée —, ≥1
`<path>` tracé dans `.rel-mm-liens` après mesure DOM) ; confirmé visuellement
(O-soto-gari : hub centré, branches Enchaîné-depuis 11 (gauche) · Enchaîne-vers
4 (droite) · Similaire/À-ne-pas-confondre (haut) · Contre (bas-droite), flèches
colorées, tout à l'écran).

**Statut** : `AUTOMATISÉ` (structure + absence de numéros + liens tracés) ;
comparaison des deux UX = décision porteur en attente.

### REC-156-001 — Éditeur de relations : feuille « Lien »

**Objectif** : le graphe s'ÉCRIT depuis l'app. Une feuille unique « Lien » :
Depuis (source) → Type (chips des types de relation) → Vers (recherche) →
Raison (texte libre) → Priorité (1-5 / aucune) ; en édition, champs pré-remplis
+ « Retirer ce lien ». L'inverse n'est jamais saisi (dérivé) ; éditer une ligne
au sens dérivé édite l'arête stockée chez l'autre technique. Refus
actionnables : auto-lien, cible absente, doublon (type + cible). Portes
d'entrée : fiche (« ＋ Ajouter un lien », aussi sans lien existant ; ✎ par
ligne), Relations › Liste (« ＋ lien » + ✎), état vide de l'onglet, Plus ›
Relations entre techniques (« ＋ Ajouter un lien de ce type » + ✎ par
instance). PIN de modification.

**Preuves** : e2e (Liste : créer Similaire à → De-ashi-harai avec raison +
priorité 2 → la ligne apparaît avec sa raison ; ✎ → raison éditée visible ;
« Retirer ce lien » (confirm) → disparue).

**Statut** : `AUTOMATISÉ`.

### REC-003-007 — Contexte de fiche et libellés éditoriaux (boucle 3.7)

**Objectif** : l'en-tête fixe de la fiche identifie la technique ouverte
(« Harai-goshi »), pas seulement la discipline, avec retour et menu ⋮
inchangés ; le nom de source affiché est le nom éditorial le plus précis
disponible (« Club judo » plutôt que « Club » ; jamais un slug, un UUID ou
un id de pack), identique dans le titre de la voix et dans « Ce contenu
vient de … ».

**Preuves** : e2e (barre de fiche = « Harai-goshi » ; aucun titre de voix
se terminant par « · Club » ; « Club judo » présent dans un titre ET dans
l'explication d'origine) + unit (`source-editoriale.test.ts`, 6 cas :
attribution vague ⊂ nom de pack → nom de pack ; attribution plus précise
conservée ; jamais le slug brut ; « Moi » en repli personnel ; adaptation).

**Statut** : `AUTOMATISÉ`

### NR-003-002 — Un seul lecteur média actif sur la fiche

**Invariant** : déplier un média replie tout autre média déplié et met en
pause toute vidéo locale en cours ; lancer une vidéo locale met en pause
les autres et replie les lecteurs en ligne — jamais deux lectures
simultanées, média principal et média de voix compris. Le média affiché en
tête ne se rend jamais une seconde fois dans sa voix (déjà couvert).

**Origine** : lot 03, boucle 3.7 (recette Android 2026-07-13).
**Couverture** : e2e (média principal déplié → 1 iframe ; média de voix
déplié ensuite → toujours 1 iframe, lecteur principal replié) ; pauses
croisées confirmées sur Android réel (recette finale 2026-07-13 :
« un seul lecteur média actif à la fois »). **Statut** : `ACTIF`

### NR-003-001 — L'original importé ne bouge jamais

**Invariant** : aucune action de la fiche ne modifie une contribution
portant une origine de pack ; une réimportation ne touche pas les
adaptations locales ; l'adaptation est une contribution locale distincte.

**Origine** : lot 03, boucle 3.4 — décision humaine D-027 (remplace
D-024). **Couverture** : e2e (édition inline absente, texte identique
après adaptation et après réimport) + unit rapprochement (réimport
restaure l'original, adaptation intacte) + garde applicative
(`amenderContribution` refuse toute contribution portant une `origine`).
**Statut** : `ACTIF`

---

## Recettes du lot 04

### REC-004-001 — Panneau contextuel « Ajouter »

**Objectif** : la racine Bibliothèque porte une action contextuelle
« Ajouter » ouvrant un panneau court à deux gestes (Une technique /
Filmer ou garder quelque chose — la capture sans discipline redevient
possible) ; une discipline ouverte porte le même « Ajouter » avec cinq
gestes (Une technique / Filmer maintenant / Une vidéo ou un fichier /
Un lien / Un mot ou commentaire), discipline présélectionnée ; aucun
vocabulaire interne (identité, contribution, provenance, pack) dans ce
premier panneau ; la fermeture ne modifie aucune donnée ; le retour
Android ferme le panneau en premier ; « Une technique » crée avec le
minimum (nom, discipline choisie ou créée dans le parcours) et ouvre la
fiche.

**Preuves** : e2e (panneau racine à 2 options, panneau discipline à
5 options sans mots internes ; fermeture par le voile sans effet ;
création minimale depuis la racine → fiche ; « Un mot ou commentaire »
débouche sur l'étape note de la capture — les trois parcours existants
passés par le FAB re-testés à travers le panneau).

**Statut** : `AUTOMATISÉ` (filmer/fichier : sélecteur natif, recette
Android du lot)

### REC-004-002 — Création enrichie et prévention des doublons

**Objectif** : la création accepte le minimum (nom) et propose sans
imposer : appellation traditionnelle facultative, section « Classer
maintenant » (famille/niveaux de la discipline choisie, masquée si la
discipline n'en a pas) avec « Je le ferai plus tard » explicite ; pendant
la saisie du nom, les identités proches de la MÊME discipline se
suggèrent (« Utiliser « X » » ouvre sa fiche) ; une correspondance exacte
unique se recommande et la création séparée exige une confirmation
explicite ; jamais de fusion automatique ; le moteur de rapprochement
n'est pas modifié (fonction pure `doublonsPotentiels` ajoutée à côté).

**Preuves** : e2e (« De Ashi Barai » suggère « De-ashi-harai », bouton
« Créer quand même », « Utiliser » ouvre la fiche sans créer ; doublon
exact refusé à la confirmation → rien de créé ; création avec appellation
+ famille + niveau → pastilles sur la fiche) + unit
(`rapprochement.test.ts` : quasi-correspondance, inclusion, exacte,
saisie courte silencieuse, jamais inter-disciplines, ambigu sans
décision).

**Statut** : `AUTOMATISÉ`

### REC-004-003 — Capture par le contenu, aperçu, « Sais-tu où le ranger ? »

**Objectif** : le contenu se capture AVANT toute métadonnée ; une vidéo
(filmée ou choisie) passe par un aperçu — Utiliser / Refilmer ou Choisir
un autre fichier / Abandonner — et RIEN ne s'écrit avant la toute fin ;
un lien collé montre son service ou domaine (URL conservée telle quelle)
avec Utiliser / Modifier (préremplie) / Abandonner ; le rattachement pose
« Sais-tu où le ranger ? » avec trois chemins (existante — recherche
cadrée à la discipline présélectionnée, élargie sur demande, résultats
avec vignette et discipline — / nouvelle / « Garder pour plus tard ») ;
la conservation affiche « Conservé dans Pratique > À reprendre » (§21,
jamais de « Terminer »). Le libellé court facultatif (§7.C) EST la note
du geste 2 (« un mot suffit »). Un seul chemin vidéo : le panneau
« Ajouter » passe par le même aperçu (défaut d'intégration attrapé par
l'e2e et corrigé dans cette boucle).

**Preuves** : e2e (vidéo réelle via sélecteur → aperçu « rien n'est
encore enregistré » + « Choisir un autre fichier » → Utiliser → « vidéo
jointe » → Annuler sans trace ; lien → « YouTube » détecté → Abandonner
vide → repris → rattaché à une technique existante, note sur la fiche ;
recherche cadrée : « ikkyo » introuvable « dans Boxe » → « Chercher dans
toutes les disciplines » → rattaché à Ikkyo ; question « sais-tu où le
ranger ? » et « Garder pour plus tard » présents).

**Statut** : `AUTOMATISÉ` (caméra réelle et permissions : recette Android)

### REC-004-004 — Personnel par défaut, capture non rattachée complète

**Objectif** : une capture est « Moi · Personnel » par défaut sans aucune
question ; « Ce contenu vient de quelqu'un d'autre » (action secondaire)
ouvre prof/club/ressource avec la seule attribution nécessaire — jamais
le nom d'un pack par défaut, pas de rôle « référentiel » offert (aucune
curation représentable) ; un enseignement attribué devient une voix
Enseignement, pas une note de carnet ; une capture NON personnelle se
garde aussi pour plus tard (provenance conservée, invariant de validation
d'increment-1 §2 remplacé — tracé dans la matrice de conservation) ; en
reprise, la capture se consulte (texte, vidéo locale, lien), son texte se
modifie, elle se supprime avec confirmation (snapshot préalable) — jamais
de fausse technique vide.

**Preuves** : e2e (étape note sans aucune chip par défaut ; enseignement
« Sensei Dupont » → voix « Enseignement · Sensei Dupont » sur la fiche ;
ressource « Chaîne BJJ » gardée pour plus tard → carte « À reprendre »
portant l'attribution → reprise : texte consulté et modifié, provenance
affichée, suppression confirmée → file vide) + unit (validation : toute
provenance « à rattacher », attribution exigée pour le sourcé).

**Statut** : `AUTOMATISÉ`

### REC-004-005 — Contribution depuis la fiche, retour par étapes, médias sûrs

**Objectif** : « Ajouter une contribution » (menu ⋮ de la fiche, distinct
du carnet) pose au plus trois questions — de qui (Moi / prof ou club /
ressource), quoi (texte et/ou média joint), attribution selon le cas —
jamais la discipline, la technique, un pack ou un id de source ; le
retour Android DANS la capture recule étape par étape (clavier système →
saisie de lien → étape précédente) et, si un contenu existe, pose « Que
faire de cette capture ? » (Garder pour plus tard / Continuer /
Abandonner) — sans contenu, il sort sans confirmation inutile ; les
écritures sont sûres (§14) : anti double-geste sur la terminaison,
rollback si la persistance échoue (contribution ressortie, fichier
supprimé, feuille/capture conservée) ; tous les parcours locaux marchent
hors ligne, un lien s'enregistre sans réseau (aperçu = domaine calculé
localement, jamais de requête).

**Preuves** : e2e (contribution « Club de Castres » + texte → nouvelle
voix Enseignement portant le texte, sans re-demande de technique ;
`reculerCapture()` piloté : note vide → sortie directe ; note remplie →
question → Continuer (contenu intact) → question → Garder pour plus tard
→ À reprendre → supprimée). **Couverture partielle assumée** : le
rollback d'échec de persistance (§14) est posé dans le code
(`terminerCapture`, `ajouterMediaFiche`) mais son chemin d'erreur n'est
PAS couvert par un test automatisé (il faudrait simuler un échec OPFS) —
revu à la main, tracé ici ; l'ordre clavier→feuille du retour reste à la
recette Android.

**Statut** : `AUTOMATISÉ` (sauf réserve ci-dessus, documentée)

## Recettes du lot 05

### REC-005-001 — Favoris : marque-page pur, immédiat, réversible

**Objectif** : une étoile sur la fiche ajoute/retire la technique des
favoris — immédiat, réversible, sans confirmation, état lisible par la
forme (☆/★) et non la couleur seule ; les favoris apparaissent dans
Pratique en liste compacte (vignette, nom, appellation, discipline —
toucher ouvre la fiche, retrait secondaire) ; un favori ne crée ni ne
copie RIEN ; le champ `favoris` (schéma v3, migration 2→3) voyage dans la
sauvegarde intégrale et JAMAIS dans une publication (pack de discipline
ou export de composition) ; une référence orpheline (technique retirée
par un réimport) est ignorée à l'affichage et nettoyée au retrait local —
jamais d'écran cassé ni de technique fantôme (comportement tracé ici) ;
état vide compact « Ajoute une technique à tes favoris depuis sa fiche ».

**Preuves** : e2e (étoile → Pratique → fiche → retour → retrait immédiat
→ état vide → technique intacte ; favori présent APRÈS restauration
intégrale sur contexte vierge et pointant la bonne technique) + unit
(migration 1→2→3 avec favoris vides et données conservées ; validation
ULID ; publication de pack sans favoris).

**Statut** : `AUTOMATISÉ`

### REC-005-002 — Racine Pratique compacte

**Objectif** : la racine de Pratique reste courte — À reprendre (masquée
si vide) en aperçu de 3 avec « Voir tout (N) », Favoris en aperçu de 4
avec « Voir tout (N) », Compositions en carte unique dont l'état vide dit
« crée ton premier enchaînement, cours ou parcours personnel » ; chaque
carte d'À reprendre montre le texte OU (vidéo), un indicateur 🎞 si un
média accompagne le texte, la date et l'auteur/attribution, et son état
(« à rattacher ») ; jamais une longue succession de grands blocs.
Limite tracée : la « discipline présélectionnée éventuelle » (§3) n'est
pas représentable — la contribution n'a pas de champ discipline (hors
périmètre modèle, voir Hors périmètre observé).

**Preuves** : e2e (4 captures gardées → aperçu à 3, « Voir tout (4) » →
liste complète, action disparue ; états vides compacts déjà couverts par
REC-005-001 ; les 4 captures voyagent dans l'export intégral et restent
accessibles après restauration).

**Statut** : `AUTOMATISÉ`

### REC-005-003 — Éditeur de composition : deux gestes, menu de bloc

**Objectif** : l'ajout expose exactement DEUX choix (Ajouter une
technique / Ajouter du texte) — jamais les huit types internes ; un
nouveau texte libre prend le type le plus générique (`etape`), les
anciens types restent lisibles (libellés) et intacts en données ; la
création demande le titre seul, la description reste facultative
(affichée en lecture) ; le sélecteur de technique donne accès aux favoris
(chips ★ quand la recherche est vide) et nomme la discipline des
résultats ; chaque technique ajoutée emporte un libellé de secours
(`bloc.texte` = nom) — l'identité reste la référence ; un bloc technique
en édition ouvre un menu (Voir la fiche / Remplacer la technique —
libellé de secours mis à jour — / Ajouter du texte après — insertion à la
bonne position — / Retirer de la composition) ; un bloc texte se modifie
directement en édition ; on reste dans l'éditeur après chaque ajout.

**Preuves** : e2e (favori ajouté par chip ★ puis retiré par le menu sans
toucher la bibliothèque ; les 4 actions du menu présentes ; « Ajouter du
texte après » insère en position 2 ; texte modifié en place et lu après
fermeture ; description affichée en lecture ; type `etape` vérifié par la
classe du bloc réordonné).

**Statut** : `AUTOMATISÉ` (Remplacer : e2e complet en 5.5 avec §17)

### REC-005-004 — Mode entraînement

**Objectif** : depuis une composition, « ▶ Mode entraînement » ouvre un
pas-à-pas plein écran : titre + progression « 3 / 8 », bloc courant en
grand (technique : vignette, nom, appellation, « Voir la fiche » ; texte :
en grand sans métadonnée), aperçu « Ensuite : … », grandes actions
Précédent / Quitter / Suivant (désactivées aux bornes), barre basse
masquée ; ouvrir une fiche puis revenir retrouve LE MÊME bloc (l'index
vit dans l'écran, la pile le restaure) ; Quitter revient à la
composition ; ni chronomètre, ni lecture automatique, ni maintien
d'écran (règles système).

**Preuves** : e2e (barre absente, 1/4 → fiche → retour 1/4, blocs texte
en grand, Suivant désactivé à 4/4, Quitter → composition, barre revenue)
+ captures regardées (D-026).

**Statut** : `AUTOMATISÉ` (tactile/tablette : recette Android)

### REC-005-005 — Liste, duplication, indisponible, export honnête

**Objectif** : chaque carte de la liste porte titre, nombre de blocs (ou
« brouillon »), date de dernière modification, miniature de la première
technique et ▶ (mode entraînement direct) ; recherche par titre + tri
A→Z quand plusieurs compositions existent ; « Dupliquer » crée une
nouvelle composition avec de NOUVEAUX blocs référençant les MÊMES
identités (l'originale intacte, aucune technique ni média copié, l'
`origine` de pack ne suit pas) ; suppression avec confirmation ; une
technique retirée de la Bibliothèque laisse ses blocs avec leur libellé
de secours « X — indisponible » (jamais de suppression silencieuse, la
confirmation de retrait NOMME les compositions), et le bloc se répare
par « Remplacer la technique » ; l'export d'une composition affiche un
rapport AVANT (blocs, techniques référencées — identités seules, sans
contributions —, vidéos incluses ou non, carnet jamais inclus) —
granularité réellement implémentée documentée, pas d'option fictive.

**Preuves** : e2e (scénario H complet : duplication, copie renommée,
originale à 4 blocs, suppression confirmée ; scénario G complet :
« Jetable » créée → ajoutée → retirée de la Bibliothèque avec dialogue
nommant « Ma spéciale » → bloc « Jetable — à retrouver » → Remplacer →
résolu) + §22 après restauration (ordre/textes intacts, mode
entraînement fonctionnel). Import d'une composition : couvert par les
tests de rapprochement existants (blocs réécrits vers les identités
réunies, réimport idempotent) et la tolérance de validation (référence
absente affichée, jamais bloquante).

**Statut** : `AUTOMATISÉ`

### REC-005-006 — Notifications transitoires et éditeur épuré (boucle 5.7)

**Objectif** : une notification temporaire (toast) disparaît d'elle-même
après une durée courte (~3,4 s), est remplacée par toute notification plus
récente, est effacée par un changement d'écran (elle ne suit jamais
l'utilisateur) et ne se rend JAMAIS sur l'écran d'entraînement ; elle ne
masque donc durablement ni action ni contenu. L'éditeur de composition
expose exactement DEUX constructions — « Ajouter une technique » et
« Ajouter du texte » — sans action « Filmer ou noter un repère » (les
blocs repère existants restent lisibles, le workflow de capture du lot 4
est intact). Aucun libellé interne de type de bloc n'est visible : un bloc
de texte montre uniquement son texte (le type reste conservé en données).
La suppression d'une composition passe par « Supprimer la composition »
(jamais un « Retirer » ambigu), avec une confirmation qui NOMME la
composition, et un traitement dangereux visuellement distinct
d'« Exporter » et « Fermer ».

**Preuves** : e2e (toast posé puis navigation → disparu ; écran
d'entraînement sans `.toast` ; deux étiquettes de construction exactement
et absence du bouton repère ; bloc `etape` sans libellé de type en édition
ET en lecture ; bouton « Supprimer la composition » distinct, dialogue de
confirmation portant le nom, suppression effective ; disparition
AUTOMATIQUE du toast sans navigation — attente réelle > durée). La garde
d'expiration au rendu (minuteur gelé par la plateforme) est structurelle :
sa preuve sur appareil appartient à la recette Android dédiée.

**Statut** : `DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ` — recette Android
finale 5.7 (2026-07-13, APK du run 29236712324, commit 3d6b008) : les
10 points validés, dont la disparition automatique réelle, l'effacement
au changement d'écran, l'entraînement sans toast hérité et l'absence de
doublon au double-appui.

### NR-005-001 — Une notification transitoire ne survit ni au temps ni à l'écran

**Invariant** : tout toast disparaît automatiquement après sa durée
courte ; un nouveau toast remplace l'ancien ; TOUT changement d'écran
(navigation empilée, retour, bascule d'onglet, retour Android) efface le
toast courant ; l'écran d'entraînement ne rend jamais de toast, même si
un minuteur a été gelé par la plateforme (garde d'expiration au rendu).

**Origine** : lot 05, boucle 5.7 (recette Android 2026-07-13 : toast
d'import persistant des dizaines de secondes jusque dans l'entraînement).
**Couverture** : e2e (toast puis navigation → `.toast` absent ; mode
entraînement ouvert après une action à toast → aucun `.toast`) ;
confirmé sur Android réel (recette 5.7, 2026-07-13). **Statut** : `ACTIF`

### NR-005-002 — L'éditeur n'expose ni type interne ni action ambiguë

**Invariant** : l'éditeur de composition propose exactement deux
constructions visibles (technique / texte) ; aucun libellé de type interne
de bloc (`ÉTAPE`, `TRANSITION`…) n'apparaît à l'utilisateur ; la
suppression d'une composition n'est jamais offerte sous un libellé ambigu
(« Retirer » seul) — uniquement « Supprimer la composition » avec
confirmation nommant la composition.

**Origine** : lot 05, boucle 5.7 (recette Android 2026-07-13).
**Couverture** : e2e (étiquettes de construction comptées, bouton repère
absent, `.bloc-nature` muette sur les blocs de texte, libellé et dialogue
de suppression vérifiés) ; confirmé sur Android réel (recette 5.7,
2026-07-13 : anciens repères lisibles, aucun type interne, aucun libellé
ambigu). **Statut** : `ACTIF`

## Recettes du lot 06

### REC-006-001 — Racine de l'Atelier : quatre intentions et synthèse actionnable

**Objectif** : la racine de l'Atelier contient exactement QUATRE intentions,
dans cet ordre : Construire · Médias et qualité · Échanger et protéger ·
Réglages et sécurité — repliées par défaut, une seule ouverte à la fois
(ouvrir l'une referme la précédente), jamais les quatre développées en mur
de texte. L'intention ouverte est conservée pendant la session : changer
d'onglet puis revenir retrouve la même section (le défilement suit la
mémoire d'onglet du lot 1). En tête, une synthèse UNIQUEMENT actionnable :
chaque élément (captures à rattacher, vidéos introuvables, relations à
réparer) est cliquable et ouvre directement le workflow ou la section
concernée ; sans problème, une seule mention compacte « Aucun problème
détecté » — jamais de KPI décoratif ni de tableau de bord vide. L'onglet
inférieur reste l'UNIQUE entrée globale (aucune autre navigation vers
l'Atelier général ; les anciennes routes Admin n'existent pas en V3 —
rien à rediriger, documenté).

**Preuves** : e2e (quatre summaries exactement, dans l'ordre ; « Aucun
problème détecté » sur corpus sain ; accordéon — une seule `[open]` après
ouverture d'une seconde intention ; intention conservée après bascule
d'onglet aller-retour ; synthèse « à rattacher » cliquable ouvrant le
rattachement sans mutation à la fermeture).

**Statut** : `AUTOMATISÉ` (accordéons au doigt : recette Android du lot)

### REC-006-002 — Construire > Disciplines : gestion complète et suppression sécurisée

**Objectif** : chaque carte de discipline porte nom, nombre de techniques,
taxonomies (familles · niveaux) et nombre de SOURCES présentes, plus un
indicateur cliquable « N à vérifier » quand des problèmes actionnables la
concernent (→ Médias et qualité). Actions : créer (nom seul — jamais de
pack, provenance ou taxonomie obligatoire), renommer (aucune identité ni
référence ne bouge — les ids sont des ULID stables), réordonner
(Monter/Descendre, l'ordre suit sur la racine Bibliothèque), « Ouvrir
dans la Bibliothèque », retirer une discipline VIDE (confirmation
simple). Une discipline NON vide ne se supprime JAMAIS en un clic :
« Préparer la suppression… » présente le contenu réel (techniques,
contributions, vidéos locales, compositions concernées NOMMÉES, sort des
notes personnelles) et trois options réelles — Annuler (rien ne change),
Exporter tout d'abord (.movpack complet), Supprimer la discipline et son
contenu (confirmation renforcée nommant la discipline ; snapshot motivé
créé d'abord ; les notes personnelles reviennent « à rattacher », le
savoir sourcé part avec ses identités, les blocs de composition restent
lisibles « à retrouver »).

**Preuves** : e2e (scénario B complet : créer Karaté → compteurs avec
sources → renommer en Karaté Shotokan → Ouvrir dans la Bibliothèque →
réordonner (ordre vérifié) → retirer la vide → non-vide : pas de retrait
simple, récap comptant 2 techniques + contributions + snapshot + « à
rattacher », Annuler sans effet, suppression renforcée → seule l'autre
discipline reste, les notes personnelles réapparaissent dans Pratique >
À reprendre).

**Statut** : `AUTOMATISÉ`

### REC-006-003 — Construire > Taxonomies : ordonner et supprimer sans référence invalide

**Objectif** : les familles et niveaux d'une discipline se créent
(nom seul), se renomment, s'ORDONNENT (Monter/Descendre — le champ
`ordre` suit), gardent leurs couleurs de ceinture (niveaux) ; rien n'est
présupposé (ni ceintures, ni nomenclature japonaise). Supprimer une
valeur INUTILISÉE demande une confirmation simple. Supprimer une valeur
UTILISÉE ouvre un arbitrage — jamais un simple confirm : le nombre
d'utilisations et les techniques concernées (cliquables → fiche)
s'affichent, avec trois issues réelles : « Remplacer par « X » » (les
fiches sont reclassées), « Retirer la classification » (les fiches
perdent cette valeur, proprement), « Annuler » (rien ne bouge). Toute
issue qui modifie des fiches crée un snapshot motivé et se conclut par
une notification nommant le résultat. Aucune référence invalide n'est
jamais créée.

**Preuves** : e2e (scénario C complet sur Aïkido/Ikkyo : deux familles
créées puis ordonnées — ordre vérifié par les valeurs —, niveau créé,
technique classée par la fiche, suppression d'une famille utilisée →
arbitrage montrant « 1 technique » et « Ikkyo », Annuler sans effet,
Remplacer → famille disparue et fiche reclassée, niveau retiré par
« Retirer la classification » → fiche intègre sans le niveau).

**Statut** : `AUTOMATISÉ`

### REC-006-004 — Types de relation, liste de gestion, sources

**Objectif** : les types de relation s'administrent sans exposer le schéma
brut — chaque ligne montre libellé, lecture inverse (ou ⇄ symétrique),
compteur d'usages et « importé » quand une origine existe, JAMAIS l'id
interne. Créer ✓, renommer (les libellés seuls — l'id slug ne bouge
jamais, les relations restent cohérentes), modifier la lecture inverse,
basculer la symétrie UNIQUEMENT si le type est inutilisé (refus expliqué
sinon), supprimer UNIQUEMENT s'il est inutilisé (remplace la rupture
consentie — refus actionnable : « retire-les d'abord des fiches ») ; les
quatre types historiques restent disponibles. « Techniques — gestion » :
recherche + filtres (Toutes / À compléter / Problèmes), chaque ligne porte
nom, discipline et étiquettes d'état (sans classification / sans contenu /
sans média / relation à réparer / vidéo manquante), toucher ouvre la
fiche ; 15 lignes max + invite à affiner — jamais une seconde
Bibliothèque, aucune action de masse factice. « Sources et auteurs » :
consultation éditoriale par source (nom éditorial — jamais un slug —,
compteurs, disciplines) + « Mon contenu (local) » ; le manifeste d'un pack
tiers ne se modifie jamais.

**Preuves** : e2e (quatre types migrés visibles ; type symétrique créé
avec ⇄ ; renommé ; suppression d'un type utilisé refusée sans rien
changer ; type inutilisé supprimé ; recherche de gestion → discipline +
étiquette d'état → fiche ouverte ; sources avec nom éditorial « Club
judo », « Mon contenu (local) », aucun slug).

**Limites tracées** : « désactiver pour de nouvelles relations » non
retenu — le modèle n'a pas de champ, et AUCUNE UI ne crée de relation
(elles viennent des packs) : capacité de création de relation absente de
V3, tracée dans STATE ; version/conditions d'un pack non conservées par
le modèle (lot 8B).

**Statut** : `AUTOMATISÉ`

### REC-006-005 — Médias et qualité : intégrité distinguée du « à compléter », orphelins sûrs

**Objectif** : la section répond pour chaque anomalie à « quel problème ?
quels contenus ? que faire ? » et SÉPARE deux natures : « Problèmes à
traiter — intégrité » (vidéos locales manquantes avec fiches concernées,
relations vers des identités absentes, fichiers vidéo sans référence) et
« À compléter — pas des erreurs » (captures à rattacher → workflow direct,
techniques sans contenu, sans niveau — dit explicitement : une technique
sans vidéo n'est PAS une erreur). Un fichier orphelin se traite UN PAR UN :
la prévisualisation est OBLIGATOIRE avant que la suppression n'apparaisse,
la confirmation nomme la taille, la référence est revérifiée à l'instant
de la suppression (un fichier référencé n'est jamais supprimé), aucune
suppression en masse n'existe. La médiathèque liste les fichiers présents
(type, taille, références cliquables vers les fiches, état) et ne propose
JAMAIS de supprimer un média référencé. Le lien « Vérifier dans
l'Atelier » d'une vidéo absente ouvre directement cette section.

**Preuves** : e2e (fichier orphelin déposé en OPFS → synthèse « 1 fichier
sans référence » → médiathèque le montre avec son état → AUCUN bouton de
suppression avant « Vérifier » (prévisualisation) → suppression confirmée
→ diagnostic redevenu « Aucun problème détecté » — les compteurs suivent).

**Statut** : `AUTOMATISÉ` (lien « Vérifier dans l'Atelier » : revue de
code + recette Android du lot — le déclenchement exige une vidéo
réellement absente de l'appareil)

### REC-006-006 — Échanger et protéger : quatre gestes distincts, orchestrés et honnêtes

**Objectif** : Importer / Publier / Sauvegarder / Restaurer sont QUATRE
gestes présentés distinctement, jamais des synonymes. IMPORT (§17-18) :
l'aperçu avant confirmation annonce le contenu et le volume du fichier
(+ nom, auteur, portée, conditions du manifeste pour un vrai .movpack) ;
après import, un RAPPORT compact (nouvelles, réunies, vidéos, à
rapprocher) avec « Ouvrir la discipline » et « Fermer » — jamais un simple
« Import réussi », jamais de renvoi forcé. PUBLICATION (§19-20) : sources
au nom ÉDITORIAL (jamais de slug), opt-in par source, formulaire nom
éditorial + auteur + conditions + inclusion des vidéos, PRÉVISUALISATION
EXACTE (identités, contributions, sources, taille vidéos, EXCLUS : carnet,
favoris, captures, sources non cochées), sortie donnant nom réel du
fichier, taille, résumé — le fichier va au téléchargement de l'appareil
(mécanisme réellement fonctionnel ; pas de fausse promesse de partage).
SAUVEGARDE (§21) : « Sauvegarde complète de cette installation » (avec
vidéos) distincte de la « légère » qui DIT ne pas être complète ; la
sortie décrit contenu et taille. RESTAURATION (§23.A) : le contenu
s'affiche AVANT toute écriture (date, disciplines, compteurs, vidéos),
annulable sans changement, uniquement sur installation vierge (refus
explicite sinon — existant). ROLLBACK (§22/§24) : snapshots motivés
lisibles ; la confirmation explique ce qui sera remplacé, dit que les
vidéos ne sont PAS incluses dans les snapshots, et que l'état courant est
lui-même snapshoté (retour annulable).

**Preuves** : e2e (aperçu d'import avec contenu/volume ; rapport après
import avec « Ouvrir la discipline » suivi jusqu'à la discipline ;
scénario H — source « Club judo » éditoriale sans slug, formulaire,
prévisualisation avec exclus, génération, nom de fichier suivant le nom
éditorial, sortie honnête ; sauvegarde complète avec sortie nom/taille/
médias ; restauration ctxC — aperçu, ANNULER sans écriture, restauration
réelle, données vérifiées).

**Limites tracées** : partage système Android non implémenté (le fichier
va aux Téléchargements — dit à l'utilisateur ; Web Share API avec fichiers
non fiable en WebView : lot 8D) ; version éditoriale de pack absente du
manifeste (8B) ; taille des snapshots non affichée (noms/motifs seuls —
mineur) ; snapshots sans octets vidéo (dit à l'utilisateur, refactor 8C).

**Statut** : `AUTOMATISÉ`

### REC-006-007 — Réglages et sécurité : démarrage avec repli discret, aucun contrôle factice

**Objectif** : la section porte le thème (auto/jour/nuit), la tonalité
(6 accents existants), l'écran de démarrage (Bibliothèque par défaut ·
dernière discipline consultée · discipline choisie — jamais d'Accueil ni
de route supprimée) et l'ÉTAT RÉEL des protections : « Aucune protection
active — la modification est libre », les protections facultatives
annoncées pour le lot Sécurité SANS aucun contrôle factice. Si la
discipline choisie au démarrage a disparu : l'application s'ouvre sur la
Bibliothèque, l'utilisateur est informé DISCRÈTEMENT (toast), le
lancement n'est jamais bloqué.

**Preuves** : e2e (scénario L complet sur le contexte restauré :
démarrage réglé sur Judo → relance → Judo ; suppression sécurisée de
Judo → relance → racine Bibliothèque + toast « n'existe plus » ; état des
protections affiché sans aucun bouton ni champ).

**Statut** : `AUTOMATISÉ`

### Audit des scénarios du lot 06 (§32)

A (navigation) ✓ e2e · B (discipline) ✓ e2e · C (taxonomies) ✓ e2e ·
D (types de relation) e2e SAUF « l'utiliser » — aucune UI ne crée de
relation (tracé, décision humaine) · E (média manquant) : détection e2e
indirecte, traitement manuel (exige un fichier réellement absent —
recette Android) · F (orphelin) ✓ e2e · G (import) ✓ e2e (annulation d'un
pack : unit à blanc + annulation de restauration e2e) · H (publication)
✓ e2e + unit · I (sauvegarde) ✓ e2e · J (restauration) ✓ e2e ·
K (rollback) : mécanisme unit stockage, parcours recette Android ·
L (démarrage) ✓ e2e · M (téléphone) : accordéon e2e + recette Android.

## Recettes du lot 07

### REC-007-001 — Cœur du PIN et politique centralisée des actions

**Objectif** : le secret n'existe JAMAIS en clair — création d'une
vérification = sel aléatoire propre à l'installation (16 octets) +
dérivation PBKDF2/SHA-256 (Web Crypto, 310 000 itérations, documentées) ;
seuls {version, sel, itérations, empreinte dérivée} sont conservés ; la
vérification compare les empreintes à temps constant, sans journaliser le
PIN. Format §4 : 6 à 12 chiffres uniquement, valeurs évidentes refusées
(chiffre répété, suites ascendantes/descendantes — dont 000000 et
123456) avec un message clair. La politique des actions est CENTRALISÉE :
`autorisation(catégorie, protections, session)` répond libre /
pin_requis — consultation toujours libre ; modification et
destruction_ou_sensible suivent chacune LEUR réglage ; une session
déverrouillée libère les deux niveaux (un seul PIN, §9). La temporisation
des échecs est une fonction pure : immédiat jusqu'à 4 erreurs, attente
courte croissante ensuite, plafonnée — jamais de verrouillage définitif.

**Preuves** : unit (format : longueurs, lettres, 000000/123456/répétitions/
suites refusées ; création : sels distincts, itérations documentées, le
PIN n'apparaît NULLE PART dans la structure sérialisée ; vérification :
bon PIN accepté, mauvais refusé, empreinte altérée refusée ; politique :
les 8 combinaisons catégorie×protection×session ; temporisation :
progression et plafond).

**Statut** : `AUTOMATISÉ`

### REC-007-002 — Activation, désactivation et préréglage des protections

**Objectif** : aucun PIN n'est demandé tant qu'aucune protection n'est
activée (§3). Deux réglages INDÉPENDANTS dans Atelier > Réglages et
sécurité. Première activation : explication brève de ce qui sera protégé
→ création du PIN (clavier numérique, chiffres masqués avec révélation
possible) → confirmation — si elle diffère : rien n'est activé, l'écran
reste, l'erreur est claire ; jamais de PIN incomplet enregistré. Activer
la seconde protection avec un PIN existant n'en redemande pas un nouveau.
Désactiver exige le PIN actuel ; quand plus AUCUNE protection n'est
active, les données de vérification sont supprimées (dit à
l'utilisateur) et aucun PIN n'est demandé ensuite. Préréglage « Tablette
partagée » : les deux protections + délai de session court + démarrage
sur la Bibliothèque — les deux protections restent configurables
séparément ensuite. Le délai de session (5 min / 15 min / jusqu'à
l'arrière-plan) se règle par chips quand une protection est active.
« Changer le PIN » : vérifier l'actuel → nouveau + confirmation →
nouvelles données avec NOUVEAU sel (échec après vérification = l'ancien
PIN reste valable, jamais d'installation sans vérification).

**Preuves** : e2e (contexte C : activation avec confirmation différente →
erreur sans activation ; activation réussie ; seconde protection sans
nouveau PIN ; désactivation refusée avec mauvais PIN ; désactivation des
deux → « Aucune protection active » et secret supprimé ; préréglage
partagé → deux protections actives) + unit 7.1 (format, création,
vérification).

**Statut** : `AUTOMATISÉ` (clavier numérique réel : recette Android)

### REC-007-003 — Déverrouillage au point d'action et session curateur

**Objectif** : jamais de PIN au démarrage (§7). Une action protégée
déclenchée ouvre un panneau contextuel qui DIT pourquoi le PIN est
demandé, conserve le contexte, et REPREND automatiquement l'action après
un déverrouillage réussi. Annuler revient exactement au contexte
précédent sans rien modifier ni perdre. Un mauvais PIN affiche une erreur
sans révéler la longueur ni la proximité ; la temporisation progressive
s'applique à partir de la 5e erreur consécutive et le compteur se remet à
zéro au succès. Une saisie correcte ouvre la SESSION curateur : les
actions couvertes ne redemandent pas le PIN, un indicateur discret
(🔓 + « Verrouiller ») le montre — jamais un gros mode Admin ; le
verrouillage arrive par inactivité (5/15 min selon le réglage), par
« Verrouiller maintenant », par l'arrière-plan (mode « jusqu'à
l'arrière-plan » : immédiat ; sinon le seuil d'inactivité s'applique au
retour), par la fermeture — la session n'est JAMAIS persistée ni
sauvegardée. Le retour Android ferme le panneau PIN sans exécuter
l'action. Un seul PIN libère les deux niveaux (§9).

**Preuves** : unit (sessionActive : bornes 5/15 min, mode arrière-plan,
jamais active sans geste ; temporisation) + e2e (action protégée → panneau
avec raison ; Annuler → rien ne change ; mauvais PIN → erreur, l'action
n'est pas exécutée ; bon PIN → l'action REPREND seule ; seconde action
sans nouvelle demande ; indicateur visible ; « Verrouiller maintenant » →
le PIN est redemandé). Arrière-plan, clavier numérique, orientation :
recette Android.

**Statut** : `AUTOMATISÉ` (expiration réelle et arrière-plan : recette
Android — la logique temporelle est prouvée en unit)

### REC-007-004 — La matrice branchée sur les workflows

**Objectif** : TOUTES les actions passent par la politique centralisée —
36 gardes de méthode (`#autorise`, arguments capturés dans la fermeture :
rien n'est perdu, l'action reprend après déverrouillage, §19) + gardes
d'interface là où l'ordre compte. MODIFICATION : créer/renommer/réordonner
disciplines et taxonomies, types de lien, créer une technique, capture
(FAB « Ajouter » — l'action reste visible, le PIN arrive à l'usage §16),
reprise d'une capture, médias et contributions de fiche, carnet, favoris,
compositions (créer/modifier/dupliquer), import. DESTRUCTION_OU_SENSIBLE :
retraits (technique, discipline, taxonomie, type, contribution,
composition, fichier orphelin), restauration, rollback, publication,
sauvegarde complète, export de composition, protections elles-mêmes
(désactivation au PIN, 7.2). Sur les suppressions à confirmation, le PIN
arrive AVANT la confirmation destructive, qui reste due (scénario D — le
PIN ne la remplace jamais) ; consultation, lecture des médias, recherche,
compositions en lecture et mode entraînement ne passent par AUCUNE garde.

**Preuves** : e2e (scénario D complet sur le contexte protégé : seules
les suppressions protégées → note de carnet enregistrée SANS PIN ;
retrait de technique → panneau PIN AVANT toute confirmation → PIN → la
confirmation destructive s'affiche ENSUITE → annuler → la technique
existe toujours) + tout le parcours ctxA/ctxB inchangé (sans protection,
36 gardes traversées librement — aucun PIN nulle part, scénario A).

**Statut** : `AUTOMATISÉ`

### REC-007-005 — Secrets hors exports, réinitialisation, journal minimal

**Objectif** : AUCUN réglage de sécurité ne voyage — les protections
vivent dans les préférences d'appareil, qui ne sont incluses dans aucun
`.movpack` (pack, composition, sauvegarde complète) : décision §21
documentée = restaurer sur un autre appareil demande une reconfiguration
des protections, le PIN ne se transporte jamais. La RÉINITIALISATION
complète (§22) est une opération sensible : PIN si protégé, explication
de ce qui sera supprimé (bibliothèque, vidéos, snapshots, préférences ET
protections), sauvegarde proposée, confirmation renforcée — puis retour à
la Bibliothèque vide sans AUCUN hash ni session résiduels (l'action ne
s'appelle jamais « Déconnexion »). « PIN oublié » : explication honnête
(réinstaller + restaurer une sauvegarde, ou réinitialiser) — ni question
secrète, ni PIN maître, ni porte dérobée. Journal minimal (§23) : en
mémoire de session seulement — dernier déverrouillage, échecs agrégés,
verrouillages — sans valeur secrète, jamais persisté ni exporté.

**Preuves** : unit (un export complet ne contient ni « protections », ni
« empreinte », ni sel — le PIN n'existe pas dans la bibliothèque) + e2e
(réinitialisation : PIN → explication → Annuler sans effet → confirmation
renforcée → bibliothèque vide, « Aucune protection active », création
libre ensuite sans aucun PIN).

**Statut** : `AUTOMATISÉ`

### Audit des scénarios du lot 07 (§27)

A (appareil personnel — jamais de PIN) ✓ e2e (tout le parcours sans
protection) · B (première activation, annulation sans changement) ✓ e2e ·
C (session curateur) e2e (2 modifications sans redemande, verrouillage
manuel) — l'EXPIRATION réelle : unit `sessionActive` + recette Android ·
D (protections distinctes, PIN puis confirmation) ✓ e2e · E (tablette
partagée) e2e partiel (préréglage, consultation libre, action protégée) +
recette Android (relance, tablette réelle) · F (mauvais PIN) e2e (1
erreur, sans fuite) — temporisation progressive : unit + recette ·
G (changement de PIN, ancien refusé) ✓ e2e · H (désactivation partielle
puis totale) ✓ e2e · I (arrière-plan) : code revu (`visibilitychange`) +
recette Android · J (formulaire en cours) : par construction (arguments
dans la fermeture de reprise) + recette · K (sauvegarde sans secret,
restauration) ✓ unit + e2e · L (réinitialisation) ✓ e2e.

## Recettes du sous-lot 8A

### REC-008A-001 — Modèle logique du média et registre dérivé

**Objectif** : un média local porte des métadonnées OPTIONNELLES (MIME
réel, extension canonique, nom original, taille en octets, date d'ajout,
origine caméra/fichier/import) — rien d'obligatoire qu'on ne sait pas
obtenir de façon fiable, et un média lien/plateforme ne porte JAMAIS de
fausse taille locale (il garde URL, service, référence distante). Le
registre central est une FONCTION PURE `registreMedias(b)` : pour chaque
média, ses métadonnées et TOUTES ses références (contributions, blocs de
composition, média principal d'une technique) — jamais un compteur
maintenu à la main qui pourrait dériver (§3) ; les couches applicatives
(références de vidéos locales, diagnostics) RÉUTILISENT ce calcul au lieu
de le dupliquer.

**Preuves** : unit (même média dans deux contributions → une entrée, deux
références ; bloc de composition et mediaPrincipalId comptés comme
références ; un lien n'a ni taille ni extension locale ; bibliothèque
vide → registre vide) ; la duplication `#referencesVideos` de racine.ts
remplacée par la fonction du domaine (revue).

**Statut** : `AUTOMATISÉ`

### REC-008A-002 — Ingestion unique et déduplication

**Objectif** : tout média local entrant (capture caméra, choix de fichier,
ajout depuis la fiche) passe par UN SEUL pipeline (§5) : lecture des
métadonnées réelles (MIME, nom d'origine, taille), calcul de l'empreinte
SHA-256 (Web Crypto, un fichier à la fois), recherche d'un média identique
par TAILLE + EMPREINTE — jamais le nom d'origine seul, et jamais un média
historique sans empreinte (aucune fausse déduplication). Doublon exact →
l'identifiant existant est réutilisé, une nouvelle référence métier est
créée, le fichier physique n'est PAS dupliqué et ses métadonnées d'origine
sont conservées. En cas d'échec de persistance, seuls les fichiers NEUFS
sont retirés au rollback — jamais un fichier dédupliqué, qui appartient
aussi aux références existantes ; aucune référence vers un fichier
inexistant n'est créée. Validation d'entrée (étape 4 du §5, complétée
en 8A.5) : fichier vide ou type déclaré non-vidéo → refus AVANT toute
écriture, la feuille/capture reste ouverte ; un type ABSENT est toléré
(des caméras Android n'en déclarent pas) — l'extension reste alors
indéterminée. La zone temporaire de réception et le quota relèvent de
la boucle 8A.4 (REC-008A-004).

**Preuves** : unit (extension canonique dérivée du MIME avec repli nommé ;
vecteur SHA-256 connu ; identique par taille+empreinte, jamais nom seul ni
historique sans empreinte ; doublon renommé → id réutilisé et métadonnées
d'origine ; même taille contenu différent → média distinct ; refus du
vide et du non-vidéo, tolérance du type absent) ; e2e scénario
B du lot (même fichier ajouté deux fois — renommé, MIME différent — → UN
fichier physique dans OPFS, DEUX références partageant id et empreinte ;
contenu différent de même taille → second fichier ; trois références
visibles sur la fiche) ; rollback dédupliqué : revue de code (les deux
sites conservent `fichiersEcrits`).

**Statut** : `AUTOMATISÉ`

### REC-008A-003 — Références multiples sûres

**Objectif** : un média peut être référencé par plusieurs contributions,
des blocs de composition, un média principal, une capture à reprendre —
et retirer UNE référence ne supprime jamais le fichier physique tant
qu'une autre existe (§4). La propriété du fichier ne se déduit JAMAIS de
la première contribution qui l'a créé. Retirer la DERNIÈRE référence ne
supprime pas non plus le fichier : il devient orphelin, diagnostiqué
dans l'Atelier (flux 6.5), et la suppression physique n'arrive qu'après
prévisualisation obligatoire + confirmation, un fichier à la fois — les
snapshots « avant-retrait » restent ainsi restaurables, vidéo comprise.
Audit des flux de suppression : `supprimerContribution` corrigé (seul
site qui supprimait physiquement sans recalcul) ; `supprimerTechnique`,
`supprimerDisciplineEtContenu`, `supprimerComposition` ne touchent pas
les fichiers (orphelins diagnostiqués) ; `supprimerVideoOrpheline`
revérifie les références à l'instant de la suppression ; les rollbacks
de capture/ajout ne retirent que les fichiers NEUFS (REC-008A-002) ;
`reinitialiserTout` est une politique explicite confirmée.

**Preuves** : e2e scénario A complet du lot (média partagé par deux
contributions → retrait d'une : fichier conservé et lisible dans
l'autre ; retrait de la dernière : fichier conservé, devenu orphelin,
diagnostiqué dans la synthèse de l'Atelier ; suppression physique
seulement après Vérifier + confirmation, sans toucher l'autre fichier ;
la contribution restante survit intacte) ; unit (une capture à
rattacher — techniqueId null — est une référence qui protège le
fichier) ; audit des sites de suppression : revue de code ci-dessus.

**Statut** : `AUTOMATISÉ`

### REC-008A-004 — Nommage physique, staging et espace disponible

**Objectif** : les NOUVEAUX fichiers vidéo se nomment
`<mediaId>.<extension-canonique>` (§6) — jamais d'après le nom d'origine,
la technique ou le pack ; les fichiers historiques sans extension restent
lisibles par résolution compatible (id nu puis `<id>.<ext>`), sans aucun
renommage en masse. Les écritures passent par la zone temporaire
`staging/` (§7) : un fichier n'apparaît dans `videos/` qu'une fois
complet (déplacement, repli copie), et le staging est vidé au démarrage —
une interruption ne laisse jamais un fichier partiel parmi les
définitifs. Avant une écriture volumineuse (restauration, import),
l'espace est estimé (§10) : estimation fiable et insuffisante → refus
AVANT toute mutation avec les deux tailles dites, l'état existant
conservé et la proposition toujours ouverte ; estimation indisponible →
on procède honnêtement, sans inventer ni refus ni garantie. Miniatures
(§9) : AUCUNE n'est générée — vignettes et aperçus sont des rendus à la
volée, rien à sauvegarder ni régénérer (documenté). Emplacements réels
par cible (§8) : documentés dans `systeme.md` §5bis (Android privé /
navigateur / PWA non livrée), avec `persist()` demandé au démarrage.

**Preuves** : unit (verdict d'espace : refus fiable, acceptation avec
marge 10 %/plancher 16 Mo, honnêteté sans estimation, disponible jamais
négatif ; nommage physique) ; e2e (les fichiers du scénario B portent
`.webm` et jamais le nom d'origine ; l'ancien fichier nu du flux
orphelin reste prévisualisable et supprimable — résolution compatible ;
contexte vierge à quota simulé : restauration refusée avant mutation,
tailles dites, proposition conservée, zéro fichier écrit) ; staging :
sonde OPFS (move inter-dossiers disponible) + revue de code du repli.

**Statut** : `AUTOMATISÉ`

## Recettes du sous-lot 8B

### REC-008B-001 — Manifeste complet et intégrité par fichier

**Objectif** : un `.movpack` produit par la V3 est un conteneur v4 dont
le manifeste porte, en plus de son identité (id, nom, portée, auteur,
conditions, date, version du schéma, version éditoriale) et de ses
options d'inclusion DITES (médias oui/non, contenu personnel oui/non —
jamais devinées), un INVENTAIRE par fichier : pour bibliotheque.json ET
pour chaque média, {chemin canonique, taille en octets, empreinte
SHA-256} avec l'algorithme nommé. À la lecture (§14), l'intégrité se
vérifie fichier par fichier — liste, puis tailles, puis empreintes — et
tout écart (fichier déclaré manquant, taille différente, empreinte
différente) fait REFUSER le conteneur AVANT toute mutation de la
bibliothèque active (D-043) ; la vérification ne se limite jamais à
bibliotheque.json. Un fichier présent dans l'archive mais absent de
l'inventaire est IGNORÉ avec avertissement (politique documentée), jamais
accepté en silence ni exécuté. Les conteneurs v3 déjà produits (empreinte
globale de bibliotheque.json seule, pas d'inventaire) restent lisibles
par repli explicite — jamais cassés sans migration.

**Preuves** : unit (`tests/movpack.test.ts`) — ronde-trip v4 (manifeste
inventaire complet, tailles et empreintes exactes, aucune perte de
données/vidéos) ; média dont un octet est altéré → refus avec le chemin
fautif ; média déclaré mais absent de l'archive → refus ; taille d'un
fichier modifiée → refus ; bibliotheque.json falsifié → refus ; fichier
supplémentaire inattendu → import possible + avertissement listé ;
conteneur v3 (sans `fichiers`) relu par repli sur l'empreinte globale.
E2e (`parcours.mjs`) — un `.movpack` exporté puis altéré (un octet vidéo)
est refusé à l'import, la bibliothèque active reste inchangée.

**Statut** : `AUTOMATISÉ`

### REC-008B-001id — Identité de pack stable au renommage

**Objectif** : l'identité technique d'un pack publié (le `id` du manifeste,
clé d'idempotence au réimport, D-013/D-015) ne dépend PLUS du nom éditorial.
Elle se dérive de l'ULID STABLE de l'entité publiée (discipline ou
composition), invariant au renommage : renommer une discipline puis
republier produit un pack de MÊME identité — réimporté ailleurs, il MET À
JOUR le pack existant au lieu de créer une source distincte (règle le point
« idDePack au renommage » tracé au lot 6). Le nom éditorial ne sert plus
qu'au NOM DE FICHIER lisible (`idDePack(nom)`), qui peut donc changer avec le
nom sans affecter l'identité. Aucun changement de modèle ni migration :
l'ULID existant suffit.

**Preuves** : unit (`idPackStable(id)` dérive `pack-<id>` de l'entité, jamais
du nom) ; e2e — publier une discipline (fichier 1), la renommer via
`majNomDiscipline`, republier (fichier 2) : les deux manifestes portent le
MÊME `id`, les noms de fichier diffèrent.

**Statut** : `AUTOMATISÉ`

### REC-008B-002 — Structure canonique et nature du conteneur

**Objectif** : un `.movpack` produit par la V3 range ses médias sous la
structure canonique `medias/<mediaId>.<extension>` (§12), l'extension venant
du registre 8A (`medias/<id>` nu si inconnue) ; le chemin de l'inventaire
d'intégrité coïncide exactement avec l'entrée d'archive. Les conteneurs
antérieurs (médias sous `videos/<ULID>`, v3 et historiques) restent
importables — la lecture retrouve l'id logique quel que soit le dossier et
l'extension. La nature du conteneur (§11) est documentée : ZIP versionné,
extension `.movpack`, MIME `application/vnd.movenso.movpack+zip` (replis
documentés) ; la détection reste par CONTENU (signature ZIP + manifeste +
format + version), jamais par la seule extension.

**Preuves** : unit (`movpack.test.ts`) — un média avec extension est écrit et
inventorié sous `medias/<id>.<ext>` ; ronde-trip retrouvant l'id ; un vrai
conteneur v3 (médias sous `videos/<id>`, manifeste sans inventaire) reste
lisible. E2e — l'export complet range ses médias sous `medias/<id>.<ext>`
(le scénario d'intégrité 8B.1 y localise le média).

**Statut** : `AUTOMATISÉ`

### REC-008B-003 — Export à mémoire bornée par blocs

**Objectif** : l'export réel de l'application (`exporterTout`, `publierPack`,
`exporterComposition`) suit un pipeline BORNÉ PAR BLOCS de bout en bout
(§15) : source média → lecture par blocs de taille fixe (1 Mio,
`lireMediaParBlocs` sur `Blob.slice(...).arrayBuffer()`) → SHA-256
INCRÉMENTAL (`Sha256`, WebCrypto étant one-shot) → poussée progressive de
l'entrée ZIP (vidéo stockée sans compression, `ZipPassThrough` en flux) →
écriture au fil de l'eau dans un fichier temporaire OPFS. Interdits
respectés : aucun `Blob.arrayBuffer()` intégral sur un média ; aucune
accumulation de tous les fichiers dans la bibliothèque ZIP ; aucune
reconstruction finale de l'archive en mémoire ; le téléchargement se fait
depuis le fichier OPFS adossé au disque, sans copie intégrale dans le tas.
Cycle de vie du temporaire : écrit dans `staging/` (OPFS n'expose le
fichier qu'au `close()` — aucun fichier final visible avant finalisation,
aucun `.movpack` partiel présenté comme valide) ; balayé avant chaque
nouvel export et au démarrage (`nettoyerArchivesTemp` / `nettoyerStaging`) ;
supprimé à l'annulation/échec. Annulation (`estAnnule`, consultée entre
blocs) et échec → temporaire abandonné, rien de téléchargé. OPFS
indisponible → refus borné explicite (jamais de repli qui chargerait tout
en mémoire). Les hashes du manifeste sont calculés sur les octets
réellement archivés (mêmes blocs) → cohérence par construction, vérifiée
en relisant le conteneur.

**Preuves** — trois niveaux distincts (règle de preuve §4) :
- **Démontré structurellement** (unit `movpack.test.ts`, `sha256.test.ts`) :
  SHA-256 incrémental conforme à WebCrypto sur toutes les bornes de bloc ;
  export en flux → ronde-trip identique, média remis en blocs ≤ 1 bloc
  (journal des tailles), octets conservés (empreinte == SHA-256 indépendant),
  deux exports successifs stables, annulation à mi-parcours → aucune
  finalisation ; les trois exports de l'app passent par le flux (revue) ;
  e2e : export complet → restauration VIDÉOS COMPRISES (scénario I),
  corruption refusée, renommage stable — tous via le flux.
- **Mesuré dans le harnais** : le pic réel de blocs détenus et la mémoire
  sur gros médias (≥150 Mo, ≥500 Mo cumulés) → **boucle 8B.4** (à suivre).
- **À vérifier physiquement sur Android** : export d'un gros corpus réel sur
  l'appareil (mémoire, pas de crash, fichier restaurable) → **recette
  Android ciblée 8B**.

**Statut** : `AUTOMATISÉ` (structure) — mesure gros médias en 8B.4, Android en recette.

### REC-008B-004 — Tailles de référence et preuve de mémoire

**Objectif** : PROUVER, à l'échelle des tailles de référence (§16), que
l'export à mémoire bornée tient ses promesses — par un harnais outillé
reproductible, `npm run epreuve:export` (`tests/epreuve-export-8b.ts`),
HORS du verifier rapide (volumes lourds).

**Preuves — deux parties (règle §4)** :
- **A · Correction à échelle modérée** (sortie accumulée, ZIP relu, CHAQUE
  empreinte vérifiée) : 202 médias dont 200 petits + 2 moyens non alignés au
  bloc → relecture complète, 203 empreintes conformes aux octets réels ;
  deux exports successifs → empreintes identiques ; annulation à mi-export →
  rejet sans finalisation ; erreur de lecture à mi-export → propagée, aucune
  finalisation.
- **B · Mémoire à grande échelle** (sortie JETÉE et comptée, blocs générés
  paresseusement — le média n'existe jamais en entier) — mesures réelles
  (Node, ce dépôt, 2026-07-13) :

  | Scénario | Volume | Pic blocs générés | Buffer max | RSS max |
  |---|---|---|---|---|
  | Un gros média | 200 Mo | 1 | 1,05 Mo (= 1 bloc) | +61 Mo |
  | Plusieurs gros (dont un de 200) | 700 Mo | 1 | 1,05 Mo | +1 Mo |
  | Nombreux petits (2000 × 4 Ko) | 8 Mo | 1 | ~4 Ko | +4 Mo |

  DÉMONTRÉ STRUCTURELLEMENT (déterministe) : buffer max ≤ 1 bloc (aucun
  chemin intégral `arrayBuffer` ne subsiste) ; pic de blocs générés
  simultanément = 1, INDÉPENDANT du volume ; toute la sortie écrite au fil de
  l'eau. MESURÉ (corroboration) : la RSS ne suit JAMAIS le volume — 700 Mo
  exportés pour +1 Mo de RSS. Le pipeline retient en plus un bloc d'avance
  côté flux (`enAttente`) : pic réel ≈ 2-3 blocs, jamais le média ni
  l'archive.
- **À vérifier physiquement sur Android** : export d'un gros corpus réel sur
  l'appareil (pas de crash mémoire, fichier restaurable) → recette ciblée 8B.

**Limites réelles observées / honnêtes** : le SHA-256 (WebCrypto one-shot)
imposait de tout charger ; le module incrémental le lève. La borne n'est PAS
une promesse de taille illimitée : elle est ~quelques blocs + petits JSON,
plus le comportement disque d'OPFS/WebView (à confirmer sur Android). Aucune
compression en flux des vidéos (stockées telles quelles) — voulu (§15).

**Statut** : `AUTOMATISÉ` (structure + harnais) — Android en recette.

### REC-008B-005 — Pack publié, export de composition, JSON historiques (§24-26)

**Objectif** : un pack publié n'emporte jamais le carnet personnel ni les
favoris (§24, exclusions maîtrisées) ; une composition exportée se réimporte
sans dupliquer les identités (§25, idempotence par origine) ; un JSON nu est
traité comme un format HISTORIQUE explicitement dit, jamais présenté comme un
`.movpack` (§26).

**Preuves** : unit — exclusions carnet/favoris à la publication
(`movpack.test.ts`) ; réimport d'une composition (double import) → une seule
composition, aucun doublon (`composition.test.ts`). App — l'aperçu d'import
d'un JSON nu affiche « Fichier JSON historique : ni manifeste ni intégrité de
conteneur » (même canal d'avertissement que les fichiers inattendus, rendu en
e2e).

**Réserve (P2, §24)** : une technique publiée peut porter une relation vers
une identité HORS périmètre — aujourd'hui copiée telle quelle (cible absente
TOLÉRÉE par le modèle, jamais bloquante), mais NI ajoutée, NI signalée comme
dépendance, NI exclue avec avertissement. Refinement de qualité éditoriale,
sans risque de données — tracé pour une boucle dédiée / lot 9.

**Statut** : `AUTOMATISÉ` (réserve §24 tracée)

### REC-008C-001 — Amendement transactionnel d'une contribution (§18)

**Objectif** : modifier une contribution locale est une transaction — sur
échec de persistance, l'état revient EXACTEMENT à l'original (aucune valeur
modifiée ne réapparaît, pas même une clé ajoutée ou effacée).

**Preuves** : unit `contribution.test.ts` — `appliquerAmendement` retourne une
NOUVELLE contribution sans jamais muter l'original (description posée/rognée,
description vide → clé absente, attribution posée/ignorée si vide) ; un original
non muté sert de point de rollback fidèle (`deepEqual` avant/après). Service
(`racine.ts amenderContribution`) : substitue l'amendé dans la liste, persiste,
et sur exception remet l'exemplaire d'origine à son index.

**Correctif** : le rollback précédent capturait `structuredClone(c)` APRÈS la
mutation en place — un no-op (il restaurait la version déjà modifiée) qui, en
plus, ne réeffaçait pas une clé ajoutée. Corrigé par la fonction pure.

**Statut** : `AUTOMATISÉ`

### REC-008C-002 — Bascule d'état protégée + reprise au démarrage (§18)

**Objectif** : l'état métier ne s'écrase jamais en place sans vérification ; un
commit interrompu ne bascule jamais vers un état à moitié écrit ; au démarrage,
un résidu d'écriture est nettoyé et le dernier état valide est conservé
(scénario E côté état).

**Preuves** : e2e `parcours.mjs` (bloc 8C.2) — une bascule réussie ne laisse
aucun `bibliotheque.json.tmp` ; un `.tmp` tronqué injecté à côté d'un état
courant valide est ÉCARTÉ au reload (la discipline « Aïkido » survit, le
`.tmp` a disparu, le fichier courant n'a jamais changé). Mécanisme
(`StockageOpfs.sauvegarder`) : écriture du temporaire → relecture → revalidation
(`migrerBibliotheque`+`validerBibliotheque`) → bascule vers le fichier courant
(swap OPFS au `close()`) → suppression du temporaire ;
`reprendreTransactionInachevee()` appelée par `charger()` au démarrage.

**Limite honnête (§17)** : atomicité NON parfaite revendiquée — OPFS ne fournit
pas de rename transactionnel garanti ; la stratégie est « écrire-valider-
basculer + écarter un résidu au prochain lancement », jamais « atomique ».

**Statut** : `AUTOMATISÉ` (à confirmer sur Android par recette : fermeture
forcée pendant une écriture)

### REC-008C-003 — Atomicité média+métier sur tous les parcours + concurrence (§17, §19)

**Objectif** : un échec de persistance sur n'importe quel parcours d'écriture
(ajout de média sur fiche, capture rattachée, repère filmé de composition) ne
laisse jamais de contribution/bloc fantôme ni de fichier orphelin ; un
double-appui ne duplique ni la contribution ni le fichier.

**Preuves** : e2e `parcours.mjs` (bloc 8C.3) — `sauvegarder` remplacé pour
échouer : (A) `ajouterMediaFiche` → aucune contribution, fichier neuf retiré ;
(B) deux `terminerCapture` concurrents du même fichier → UNE contribution, UN
fichier (garde `#ecritureMediaEnCours` + déduplication d'empreinte) ; (C)
`terminerCaptureRepere` → aucun bloc, fichier filmé retiré (comble le trou : la
vidéo du repère restait orpheline si la persistance échouait).

**Mécanisme** : helper unique `#persisterAvecMediasNeufs(b, fichiersNeufs,
annulerMemoire)` — persiste et, sur échec, retire les fichiers NEUFS (jamais un
dédupliqué, partagé) puis annule la mutation mémoire ; `modifierComposition`
retourne désormais le succès pour que `terminerCaptureRepere` ne ferme la
capture qu'au vrai succès ; garde anti-double-appui posée synchronement à
l'entrée de tous les parcours d'écriture média.

**Statut** : `AUTOMATISÉ`

### REC-008C-004 — Sauvegarde complète honnête + rétention snapshot (§20-23)

**Objectif** : « sauvegarde complète » n'est jamais une étiquette mensongère ;
les réglages d'appareil sont dits exclus (D-065) ; un snapshot (état seul)
annonce sa limite média et la rétention physique donne un sens au rollback.

**Preuves** : unit `sauvegarde.test.ts` — `decrireSauvegarde` : complète
seulement si vidéos incluses ET aucune manquante, sinon PARTIELLE avec
exclusions nommées ; réglages d'appareil toujours exclus. e2e `parcours.mjs`
(bloc 8C.4) — une vidéo référencée absente du stockage rend la sauvegarde
PARTIELLE (`dernierFichier.role` = « PARTIELLE », résumé nommant la vidéo
absente et l'exclusion des réglages d'appareil). Restauration :
`confirmerRestauration` annonce « réglages d'appareil à reconfigurer ».

**Rétention (§22-23)** : les snapshots sont l'état métier SEUL (stratégie B,
limite déjà dite dans la confirmation de rollback) ; la suppression physique
d'un média n'arrive jamais immédiatement après une action métier — seulement à
l'orphelin CONFIRMÉ à l'Atelier (rétention de fait). Le rollback d'un snapshot
retrouve donc les octets tant que l'orphelin n'a pas été purgé — corbeille
dédiée jugée hors périmètre (§23 : « ne pas implémenter une corbeille complexe
si elle dépasse le lot »).

**Statut** : `AUTOMATISÉ`

### REC-008C-005 — Snapshot, rétention et reprise média (§22-23, scénario G)

**Objectif** : un snapshot rend le rollback utile (la rétention physique
conserve les octets), et une écriture média interrompue ne laisse jamais de
fichier partiel parmi les définitifs.

**Preuves** : e2e `parcours.mjs` (bloc 8C.5) — supprimer une contribution
RETIENT son fichier (compteur vidéos inchangé) ; restaurer le snapshot le plus
récent ramène la contribution ET sa vidéo ; un résidu injecté dans `staging/`
est nettoyé au démarrage (jamais promu). Scénario E côté média couvert par le
nettoyage de `staging/` au démarrage.

**Statut** : `AUTOMATISÉ` (interruption réelle pendant écriture = recette Android)

### REC-008C-006 — Corrections issues de l'audit contradictoire (F1, F2)

**F1 (orphelin sur PIN pendant l'enregistrement d'un repère)** :
`terminerCaptureRepere` gardait le PIN via `modifierComposition` APRÈS avoir
écrit le fichier ; sur session verrouillée, `#autorise` différait l'action et le
fichier neuf était supprimé, puis l'action différée rejouait la mutation en
référençant un fichier disparu → orphelin + perte de la capture. **Corrigé** :
garde PIN à l'ENTRÉE (comme les jumelles), transaction propre via
`#persisterAvecMediasNeufs` — sur PIN différé, RIEN n'est écrit et la méthode
entière est rejouée. **Preuve** : e2e `parcours.mjs` (bloc 8C.6) — protection
active + session verrouillée → aucun fichier avant le PIN, capture ouverte,
0 bloc ; après le PIN → 1 fichier, 1 bloc référençant un fichier réellement
présent, capture fermée.

**F2 (rollback par index fragile)** : `amenderContribution` restaurait par index
capturé, invalidé si une opération concurrente réassignait `b.contributions`.
**Corrigé** : substitution PAR ID (`findIndex(x.id === c.id)`), robuste à un
`filter` concurrent, no-op si la contribution a disparu.

**Statut** : `AUTOMATISÉ` (F1) / `CORRIGÉ, robustesse` (F2)

### REC-008D-001 — Diagnostic technique exportable (§38)

**Objectif** : une opération de stockage/export/import est diagnosticable sans
exposer de secret ; l'Atelier offre « Exporter le diagnostic ».

**Preuves** : unit `diagnostic.test.ts` — `construireDiagnostic` rapporte
plateforme, versions (dont la version APPLICATIVE complète `x.y.z+sha`,
D-217), compteurs, santé médias et espace (ou « indisponible » honnête),
codes d'erreur STABLES (`CODES_ECHEC`, format `MOV-Enn`), opération longue
(absente / terminée datée / « ENCORE EN COURS » = blocage dit tel quel) ;
aucun secret (ni PIN, ni empreinte, ni mot de passe). e2e chapitre
`export-diagnostic` — l'action Atelier produit un fichier texte lisible avec
les compteurs réels, sans le mot « PIN » ni terme de secret ; un échec
consigné ressort avec son code (`[MOV-E02] lecture d'un pack — …`) et une
opération passée par le voile ressort « terminée (début → fin) ».

**Statut** : `AUTOMATISÉ`

### REC-008-CONSOLIDÉE — Recette Android du lot 8 (8A → 8D)

À exécuter sur l'APK debug de clôture (artefact `movenso-apk` du run de CI le
plus récent). Chaque point est déjà démontré en automatisé/harnais ; la recette
Android confirme le comportement APPAREIL (OPFS/WebView réels), seul juge des
points marqués « appareil ».

**8A — médias et registre**
1. Ajouter la MÊME vidéo à deux contributions → un seul fichier, deux
   références ; retirer une contribution → la vidéo reste lisible dans l'autre ;
   retirer la dernière → orpheline, jamais supprimée en silence ; suppression
   physique seulement après prévisualisation + confirmation (Atelier).
2. Importer deux fois le même fichier → une seule empreinte, un seul fichier
   physique, références distinctes.

**8B — `.movpack`, intégrité, mémoire bornée**
3. Sauvegarde volumineuse (~500 Mo cumulés, une vidéo ≥150 Mo) → **pas de crash
   mémoire**, progression visible, `.movpack` produit.
4. `.movpack` altéré (un octet) → **refusé** à l'import, rien n'est écrit
   (message « Intégrité »).
5. Publier une discipline → fichier importable ailleurs ; renommer la discipline
   puis republier → à l'import, **mise à jour** du même pack (pas de doublon).
6. Import d'un JSON nu → l'aperçu dit « ni manifeste ni intégrité de conteneur ».

**8C — transactions, sauvegarde, restauration**
7. Couper l'app pendant un gros export → au redémarrage, **aucun `.movpack`
   partiel** présenté, staging nettoyé.
8. Couper l'app pendant une écriture/restauration → au redémarrage, **état
   précédent valide** retrouvé, aucune bibliothèque à moitié écrite.
9. Restaurer une **sauvegarde complète** sur une installation vierge → savoir et
   **vidéos** intégralement restaurés ; le rapport dit « réglages d'appareil à
   reconfigurer ».
10. Une sauvegarde alors qu'une vidéo manque → annoncée **PARTIELLE**, exclusion
    nommée (jamais « complète »).
11. Snapshot puis suppression d'une contribution → restaurer le snapshot ramène
    la contribution ET sa vidéo (rétention) ; la limite « octets non inclus dans
    un snapshot » est dite AVANT un rollback qui toucherait un média purgé.
12. Double-appui sur « enregistrer » une capture → une seule contribution, un
    seul fichier.

**8D — Android et plateformes**
13. Construire l'APK depuis la CI (ou machine neuve) → installer → filmer →
    exporter → le fichier arrive aux **Téléchargements** (accessible depuis
    Files/Drive), la sortie DIT son nom/taille/contenu.
14. Mettre à jour l'APK → **données et vidéos conservées**, aucune réimportation
    demandée ; désinstaller → réinstaller → **vide**, puis restaurer une
    sauvegarde → tout revient.
15. Atelier → Réglages → « Exporter le diagnostic » → fichier texte lisible,
    **aucun secret**.
16. Couper le réseau → consulter, sauvegarder, restaurer, lire les médias
    locaux → aucun besoin d'un service distant.

**Réserves connues à re-vérifier en recette** : borne mémoire sur gros fichiers
(8B) ; interruption réelle pendant écriture (8C) ; le **partage système natif**
n'est PAS livré (téléchargement WebView à la place — attendu).

**Statut** : `VALIDÉE` — recette Android consolidée confirmée par l'humain
(Yahya, 2026-07-13, 21 points ; APK 29272039028 / CI 29272785511). R1
(mémoire/interruption) levée sur appareil ; R2 (partage natif différé), R3
(relations hors périmètre P2), R4 (`majContribution`), R5 (PWA/Windows/Electron),
R6 (V2 outillée) acceptées comme réserves annoncées, aucune sur les données.
**Lot 08 : ACCEPTABLE.**

### REC-009-001 — Fondations visuelles + coque/contenu (§2-8, boucle 9.1)

**Objectif** : établir une base visuelle centralisée (tokens, coque sombre /
contenu clair, sémantique de couleur) sans changer aucune règle fonctionnelle,
appliquée à un échantillon d'écrans, pour valider la DIRECTION avant propagation.

**Preuves** : `npm run verifier` vert (130 unit + e2e — aucun sélecteur cassé
par les changements de coque) ; captures avant/après (téléphone + tablette) des
5 écrans échantillons (Bibliothèque, discipline, fiche, Pratique+composition,
Atelier+section, import). Tokens ajoutés dans `app.css` (anciens noms en alias).
Accent vermillon par défaut conservé + 6 tonalités ; couleurs sémantiques
(danger/attention/succès/info) FIXES, indépendantes de la tonalité ; accent
éclairci (`--accent-sur-shell`) pour lecture sur la coque.

**Findings documentés (hors 9.1)** : voyant rouge sur « techniques sans niveau »
(catégorie « à compléter — pas des erreurs ») → §28, à corriger en 9.6 ;
Pratique sans en-tête de coque → 9.2.

**Statut** : `VALIDÉ` — direction (coque sombre / contenu clair / vermillon)
confirmée par l'humain (2026-07-13) ; propagée en 9.2→9.8.

### REC-009-002 — Propagation et consolidation visuelle (§9-38, boucles 9.2→9.8)

**Objectif** : propager la direction validée à toute l'app en intégrant les 10
contraintes humaines, sans changer de logique métier ni retirer de capacité.

**Incohérences corrigées** :
- 9.2 contraste des textes de coque relevé (marque, titres, nav) ; en-tête
  **Pratique** ajouté (cohérent avec Bibliothèque/Atelier).
- 9.3 **audit des bleus** : initiales de repli neutralisées (bleu réservé à la
  provenance) ; étiquettes **sans capitales** (§6).
- 9.4 en-tête de voix **source-first** (« Kodokan · Référentiel », §17) ; couleur
  sémantique confinée au petit tag.
- 9.5 blocs de composition distingués par la **forme** (bleu retiré).
- 9.6 voyant « à compléter » **neutre** au lieu de rouge (§28, contrainte 6).
- 9.7 thème sombre + **6 tonalités jour/nuit** vérifiés ; largeur de lecture
  tablette maîtrisée (sans sur-colonnage).

**Preuves** : `npm run verifier` vert (130 unit + e2e — aucun sélecteur cassé) ;
captures de référence jour + nuit, téléphone + tablette (Bibliothèque,
discipline, fiche, Pratique/composition, Atelier/section, import).

**Limites visuelles restantes** (documentées, non bloquantes) : (a) famille
d'icônes SVG unique (§9) — quelques emojis subsistent dans les menus/flux de
capture ; (b) vue tablette côte à côte (§31) non implémentée (contenu centré
une colonne) ; (c) marque typographique conservée (pas de nouveau logo, §33).

**Statut** : `AUTOMATISÉ` (recette Android consolidée du lot 9 à valider)

### REC-009-CONSOLIDÉE — Recette Android du lot 9 (identité graphique)

À exécuter sur l'APK de recette du lot 9 (artefact `movenso-apk` du commit de
clôture). Aucune fonction ne change : la recette juge le VISUEL et l'ergonomie.

1. **Identité globale** : coque sombre cohérente (en-tête + nav basse) encadrant
   un contenu clair ; vermillon reconnaissable (onglet actif, logo, FAB) ; aucun
   écran sombre uniforme sans hiérarchie.
2. **Lisibilité de coque** : titres d'écran et signature de marque clairement
   lisibles sur la coque, tout en restant secondaires.
3. **Bibliothèque** : grille média-first lisible, filtres compacts, pas de bleu
   décoratif concurrent ; défilement fluide sur une discipline riche.
4. **Fiche** : média-first ; source prioritaire (« Kodokan · Référentiel »),
   provenance secondaire ; pas de cartes imbriquées.
5. **Pratique** : en-tête cohérent ; À reprendre/Favoris/Compositions distincts.
6. **Atelier** : « à compléter » en voyant NEUTRE (jamais rouge) ; rouge réservé
   à l'intégrité/suppression ; libellés calmes (sans mur de capitales).
7. **Thème sombre** : hiérarchie conservée, surfaces distinctes, pas de mur de
   gris ; bascule jour/nuit propre.
8. **6 tonalités** en jour ET nuit : accent, sélection, onglet actif et liens
   lisibles ; couleurs sémantiques (danger/succès/attention) INCHANGÉES.
9. **Petits téléphones / paysage / clavier ouvert** : barres basses, zones sûres,
   panneaux et actions finales sans chevauchement ni troncature.
10. **Tablette** : densité supérieure, largeur de lecture confortable, média non
    étiré ; actions tactiles suffisantes ; pas de composant téléphone étiré.
11. **Accessibilité** : focus visible, texte agrandi utilisable, états non
    portés par la seule couleur, animations réduites si le système le demande.

**Réserves attendues (non bloquantes)** : icônes emojis résiduelles dans
quelques menus (§9) ; pas de vue tablette côte à côte (§31) ; marque
typographique (pas de nouveau logo, §33).

**Statut** : `VALIDÉE` — recette Android réelle confirmée par l'humain (Yahya,
2026-07-13, 12 points ; APK 29279256488 / CI 29279256402 / commit 8d26c299).
Consignes de clôture intégrées : filet bleu de la carte discipline CONSERVÉ
(sémantique « discipline ») ; « filtres ceinture » → « filtres de niveau ».
**Lot 09 : ACCEPTABLE.**

## 3. Matrice des capacités

Statuts : `NON COMMENCÉ`, `EN COURS`, `AUTOMATISÉ`, `DÉMONTRÉ MANUELLEMENT`, `PARTIEL`, `BLOQUÉ`, `ÉCHEC`.

| Lot | Capacité | Statut | Test | Recette | Plateforme | Réserve |
|---|---|---|---|---|---|---|
| 1 | Démarrage sur Bibliothèque | AUTOMATISÉ | e2e A/B + unit migration | REC-001-003 | web + Android réel (recette humaine) | — |
| 1 | Trois onglets | AUTOMATISÉ | e2e (count + ordre) | NR-001-001 | web | — |
| 1 | Retour Android | DÉMONTRÉ MANUELLEMENT | pile/état : e2e ; ordre §9 : recette humaine 2026-07-12 | REC-001-005 | web + Android réel | — |
| 1 | Conservation d'état par onglet | AUTOMATISÉ | e2e (mémoire, second appui, filtre au retour) | REC-001-005, NR-001-003 | web | défilement : vérif visuelle manuelle |
| 1 | Actions contextuelles (pas de Capturer global) | AUTOMATISÉ | e2e (fab par écran) | REC-001-004, NR-001-002 | web | — |
| 1 | Racine Pratique (À reprendre/Favoris/Compositions) | AUTOMATISÉ | e2e | REC-001-002 | web | favoris : destination seule (lot 5) |
| 2 | Recherche multisource sans doublon | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette humaine Android 2026-07-12 (14 points) | REC-002-002/006 | web + Android réel | — |
| 2 | Filtres cumulables | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette humaine Android | REC-002-003 | web + Android réel | — |
| 2 | Discipline vide sans impasse | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette humaine Android | REC-002-004 | web + Android réel | — |
| 2 | Compteurs racine (identités/sources/voix) | AUTOMATISÉ | unit `resume-discipline` + e2e | REC-002-001, NR-002-002 | web | — |
| 2 | Filtres conservés par discipline | AUTOMATISÉ | e2e | REC-002-005 | web | — |
| 2 | Vue par source (aperçu + badge voix, libellés éditoriaux) | AUTOMATISÉ | e2e scénario C | REC-002-006 | web | — |
| 3 | Fiche média-first (légende, galerie, fallback, ajout, aperçu principal) | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette Android finale 2026-07-13 (APK run 29217733902 : ajout sans élément fantôme après annulation, un seul lecteur actif) | REC-003-002/003 | web + Android réel | — |
| 3 | Plusieurs voix distinctes (accordéon, D-027 : original intact + adaptation) | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + unit rapprochement + recette Android (adaptation distincte, original inaltéré) | REC-003-004, NR-003-001 | web + Android réel | — |
| 3 | Carnet éditable directement | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette Android (clavier et retour corrects) | REC-002-002 (recherche), scénario C | web + Android réel | — |
| 3 | En-tête compact, menu ⋮, retrait informé (plus de « Terminer ») | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette Android (menu/clavier/navigation liés gérés par Retour) | REC-003-001 | web + Android réel | — |
| 3 | Relations dans la fiche (groupées par rôle, D-138 R5/R19 ; icône réseau → Carte, « Voir toutes » → Liste) | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e (aperçu capé, navigation par ligne + retour, « Voir toutes » → écran Relations) + recette | REC-003-005 | web + Android réel | dépliage sur place §19 retiré (décision D-138) |
| bêta | Écran Relations — Carte SVG pan/zoom/plein écran + point de départ + polish Liste (D-138) | DÉMONTRÉ (auto rendu + visuel gestes) | e2e (Carte rendue + plein écran ; chips + carte collante) + captures | REC-138-001/002 | web | gestes pan/zoom/double-toucher confirmés visuellement (non simulés en e2e monolithe) |
| 3 | Contexte de fiche + libellés éditoriaux + lecteur unique (boucle 3.7) | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + unit + recette Android (en-tête = technique, « Club judo » cohérent, un seul lecteur, aucun id visible) | REC-003-007, NR-003-002 | web + Android réel | — |
| 4 | Panneau « Ajouter » contextuel (racine + discipline) | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette Android 2026-07-13 (panneaux corrects, fermeture sans mutation) | REC-004-001 | web + Android réel | — |
| 4 | Création minimale + doublons | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + unit + recette Android (suggestion, confirmation, aucun doublon) | REC-004-002 | web + Android réel | — |
| 4 | Capture par le contenu (aperçu, « où le ranger ? », plus tard) | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette Android (caméra refusée PUIS acceptée, enregistrement/aperçu/reprise, vidéo vide non validable, sélecteur avec erreur contrôlée, hors ligne) | REC-004-003 | web + Android réel | — |
| 4 | Personnel par défaut + capture non rattachée complète | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + unit + recette Android (attribution correcte, survie à la fermeture, reprise/suppression) | REC-004-004 | web + Android réel | — |
| 4 | Contribution depuis la fiche + retour par étapes + écritures sûres | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette Android (arrière-plan sans perte, retour par étapes, aucun média fantôme, aucun double ajout) | REC-004-005 | web + Android réel | le rollback d'échec de persistance reste non simulé en test automatisé (comportements observables validés sur Android) |
| 5 | Favoris | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + unit (migration, publication) + recette Android 2026-07-13 (immédiats, réversibles, persistants, sans doublons) | REC-005-001/002 | web + Android réel | — |
| 5 | Compositions Technique + Texte | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + unit (anciens types intacts) + recettes Android 2026-07-13 (15 points, puis recette finale 5.7 : 10 points — APK 29236712324) | REC-005-003/005/006, NR-005-001/002 | web + Android réel | — |
| 5 | Mode entraînement | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette Android (téléphone, paysage, tablette, retour au même bloc) | REC-005-004, NR-005-001 | web + Android réel | — |
| 6 | Atelier en quatre intentions | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette Android 2026-07-13 (16 points : accordéon unique, synthèse mise à jour, suppression sécurisée, arbitrages, orphelins individuels, tablette) | REC-006-001→005/007 | web + Android réel | — |
| 6 | Import, publication et sauvegarde séparés | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + unit + recette Android (import avec aperçu/annulation/rapport, fichier invalide refusé, publication conforme aux exclusions, restauration complète VIDÉOS COMPRISES sur installation vierge, rollback avec limite annoncée) | REC-006-006 | web + Android réel | partage système Android : lot 8D |
| 7 | Modification libre par défaut | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | e2e + recette Android 2026-07-13 (appareil personnel sans PIN, consultation toujours libre) | REC-007-004, scénario A | web + Android réel | — |
| 7 | Protections facultatives | DÉMONTRÉ MANUELLEMENT + AUTOMATISÉ | unit + e2e + recette Android (20 points : clavier numérique, point d'action, reprise, expiration réelle/arrière-plan/fermeture forcée, aucune apparition furtive, temporisation, tablette partagée, réinitialisation) | REC-007-001→005 | web + Android réel | — |
| 8A | Médias partagés et registre sûr | **ACCEPTABLE** (recette Android consolidée validée 2026-07-13) | unit (registre, ingestion, dédup, espace, nommage, validation) + e2e scénarios A et B + quota simulé | REC-008A-001→004 | web + Android réel | — |
| 8B | `.movpack` et intégrité | **ACCEPTABLE** (recette Android consolidée validée 2026-07-13) | unit (inventaire v4, corruption/manquant/taille refusés, inattendu signalé, rétrocompat v3, identité stable, structure medias/<id>.<ext>, SHA-256 incrémental, export en flux) + e2e (corruption refusée sans mutation ; renommage → même identité ; export→restauration via flux) + harnais `epreuve:export` (202 médias vérifiés ; 700 Mo → RSS +1 Mo, pic blocs=1) | REC-008B-001/001id/002/003/004 | web + harnais Node + Android réel | R3 (P2) relations hors périmètre à la publication |
| 9 | Identité graphique et consolidation UX | **ACCEPTABLE** (recette Android réelle validée 2026-07-13, 12 points ; APK 29279256488) | verifier vert (aucun sélecteur cassé) + captures de référence jour/nuit tel+tab ; direction validée humain | REC-009-001/002/CONSOLIDÉE | web + Android réel | icônes SVG unifiées (§9), tablette côte à côte (§31), logo (§33) = limites tracées, non bloquantes |
| 8D | Android et matrice des plateformes | **ACCEPTABLE** (recette Android consolidée validée 2026-07-13) | unit (`construireDiagnostic` sans secret) + e2e (export diagnostic) + inspecteur `.movpack` exécuté ; stratégie Android B prouvée par CI apk | REC-008D-001 | web + APK CI ; matrice systeme.md §5quater | share-sheet natif DIFFÉRÉ (raison : vérif appareil + mémoire bornée 8B) ; PWA différée ; Windows/Electron absents (déclarés) |
| 8C | Transactions, sauvegarde et restauration | **ACCEPTABLE** (recette Android consolidée validée 2026-07-13) | unit (`appliquerAmendement`, `decrireSauvegarde`) + e2e (bascule d'état protégée + reprise d'un commit interrompu ; échec de persistance sur chaque parcours média→aucun orphelin ; double-appui→1 contribution ; sauvegarde PARTIELLE si vidéo absente ; snapshot+rétention→rollback vidéo comprise ; staging nettoyé au démarrage) | REC-008C-001→005 | web | atomicité non parfaite (dite) ; interruption réelle pendant écriture = recette Android |
| 8D | Android reproductible | NON COMMENCÉ |  |  |  |  |
| 9 | Identité visuelle consolidée | NON COMMENCÉ |  |  |  |  |
| 10 | Recette finale et décision | NON COMMENCÉ |  |  |  |  |

## 4. Règles de preuve

- Un test unitaire ne démontre pas à lui seul un workflow.
- Un E2E navigateur ne démontre pas Android réel.
- Un build réussi ne démontre pas l’installation.
- Des compteurs égaux ne démontrent pas une restauration complète.
- Une fonction sans chemin utilisateur reste partielle.
- Aucun statut n’est amélioré parce que le code semble correct.

## 4. Audit 10A — recette finale (2026-07-13)

**Statut : RAPPORT 10A RENDU — arrêt au verrou §25 (validation humaine du plan
P0/P1 fermé requise avant 10B).** Aucune correction fonctionnelle effectuée.

### État initial
- Branche `claude/movenso-v2-mission-ynb4ig`, commit `b19179e`, Git PROPRE (0 non-commité).
- Version app `3.0.0-dev` ; schéma modèle **v3** ; conteneur `.movpack` **v4**.
- Node 22.22.2, npm 10.9.7, Capacitor 8.4.x, appId `fr.prettozm.movenso.v3`.
- OS build Linux ; Java 21 (Temurin, CI apk). Commandes : dev, build, test, test:e2e, typecheck, verifier, epreuve:export.

### Résultats des commandes (aucun code modifié pour masquer un échec)
| Commande | Résultat |
|---|---|
| `npm run typecheck` | ✓ vert |
| `npm test` (unitaires) | ✓ **130 pass / 0 fail** |
| `npm run test:e2e` (Chromium, OPFS réel) | ✓ « zéro erreur JS » (scénarios A,B,C,D,E,G,H,I,M + 8A/8B/8C/8D/9) |
| `npm run build` (web Vite) | ✓ vert |
| build Android | ✓ CI `apk` vert (dernier : run APK du commit de code du lot 9) |
| `npm run epreuve:export` (mémoire bornée 8B) | ✓ 700 Mo → RSS +1 Mo, pic blocs=1 |
| packs de démonstration | ✓ kodokan.movpack + club-judo.movpack |
| inspection `.movpack` | ✓ INTÈGRE |

### Matrice des capacités
Voir §3 ci-dessus (à jour) : lots 1-9 tous **ACCEPTABLE** (recettes humaines
Android consignées). Aucune capacité au statut Échec / Non démontré.

### Classement des anomalies (§4)
- **P0 (bloquant absolu) : AUCUN.**
- **P1 (majeur) : AUCUN.** Tous les workflows essentiels validés en recette
  humaine (lots 1-9) ; sauvegarde/restauration/intégrité/transactions démontrées
  (lot 8) ; sécurité (lot 7) ; navigation/retour Android (lots 1,9).
- **P2 (modéré, réserves documentées)** :
  - `A1` (lot 8 §24) relations vers identités hors périmètre à la publication :
    copiées telles quelles, ni signalées ni exclues avec avertissement (cible
    absente tolérée par le modèle, sans risque données).
  - `A2` (lot 9 §31) vue tablette côte à côte (fiche média-gauche/voix-droite)
    non implémentée : contenu centré une colonne large (contournement : lisible,
    largeur maîtrisée).
  - `A3` (lot 8 §27) import de format V2 : migration OUTILLÉE (`tools/`,
    packs-demo dérivés) mais pas de parcours d'import V2 in-app de premier rang.
- **P3 (mineur, backlog)** :
  - `A4` (lot 9 §9) famille d'icônes SVG unique : emojis résiduels dans quelques
    menus/flux de capture (🎞🎥🔗🔒🔓) ; glyphes monochromes cohérents.
  - `A5` (lot 9 §33) marque : pas de nouveau logo (marque typographique).
  - `A6` (lot 8) `majContribution` : mutation en place (sans média ; robustesse
    mineure — les autres parcours d'écriture sont transactionnels depuis 8C).
- **Statuts DÉCLARÉS (non-anomalies, plateformes)** : partage-sheet natif Android
  différé (téléchargement WebView livré et dit) ; PWA différée ; Windows/Electron
  absents (analyse de perte V2 faite).

### Plan de correction FERMÉ (P0/P1)
**AUCUN P0 ni P1 → aucune correction obligatoire en 10B.** Les P2 (A1-A3) sont
des réserves documentées sans risque de données/sécurité/restauration ; A1 est
un P2 potentiellement corrigeable de façon courte et sans risque en 10B (signaler
les relations hors périmètre à la publication) — À DÉCIDER PAR L'HUMAIN. Les P3
(A4-A6) restent au backlog post-V3 (§37), non corrigés dans ce lot.

### 10B — Stabilisation (correction A1, D-066)

**Objectif** : à la publication, une relation n'est exportée que si sa source ET
sa cible sont dans le périmètre ; une cible hors périmètre → relation exclue du
FICHIER (jamais du local), cible jamais ajoutée, exclusions annoncées et
rapportées, aucun lien pendant publié.

**Preuves** : unit `movpack.test.ts` (7 assertions : relation interne conservée,
hors périmètre exclue, local inchangé, cible non ajoutée, compte exact, réimport
sans référence invalide, zéro exclusion si tout est présent) ; e2e `parcours.mjs`
(publier → `.movpack` sans relation pendante, relations locales inchangées,
`dernierFichier.resume` annonce l'exclusion). `extrairePackDiscipline` retourne
`{extrait, relationsExclues}` ; aperçu Atelier + rapport final câblés. Aucun A2-A6
traité. `npm run verifier` vert (132 unit + e2e).

### Arrêt (§25)
Le rapport 10A est rendu. **La suite (10B) ne commence qu'après validation
humaine** : (1) confirmer qu'aucun P0/P1 n'est requis ; (2) trancher si le P2
`A1` (relations hors périmètre à la publication) est corrigé en 10B ou reste
réserve. Aucune modification de code effectuée pendant l'audit.

---

## Phase STABILISATION V1 (D-161/D-162)

### REC-S1-002 — Contenu du build contrôlé (S1.2, P0.2 de l'audit)

**Objectif** : le dossier `dist/` publié ne contient QUE l'app compilée —
jamais de source (`.ts`), de sourcemap (`.map`), de donnée locale (`.json`,
`.movpack`), de fichier caché, de secret (clé privée, jeton, clé cloud) ni de
chemin local absolu. Tout écart fait échouer la vérification.

**Dispositif** : `outils/verifier-dist.mjs` — liste blanche d'extensions
(html/js/css/svg/png/ico/woff2), interdits nommés, emplacement borné (racine +
`assets/`), scan de motifs suspects dans les fichiers texte, refus des
fichiers vides et d'un `index.html` référençant `src/`. Branché dans
`npm run verifier` (après build) et dans la CI (`ci.yml`, étape dédiée).

**Preuves** : exécution verte sur le build courant (14 fichiers) ; test
négatif démontré (un `donnees.json` injecté dans `dist/` → sortie 1 avec
anomalie nommée, retiré ensuite). La CI rejoue le contrôle à chaque poussée.

**Statut** : `AUTOMATISÉ`

### REC-S1-001 — Build reproductible et artefact CI (S1.1, P0.1 de l'audit)

**Objectif** : un tiers clone le dépôt, exécute la procédure documentée
(README §37 : `.nvmrc` Node 22, `npm ci`, `npm run verifier`) et obtient le
build publiable ; l'artefact officiel est produit par la CI, jamais un build
local.

**Dispositif** : `engines` (`node >=22.6 <23`, `npm >=10`) + `.nvmrc` ;
la CI publie l'artefact `movenso-web-<sha>` = `dist/` (contrôlé par
`verifier:dist`) + `SHA256SUMS` (empreinte de chaque fichier), rétention 7 j ;
règle de publication écrite dans `docs/versions.md` §4 (RC/release = artefact
CI exclusivement ; tolérance bêta : build local d'un commit poussé et vert).

**Preuves** : CI verte sur le commit (clone propre → `npm ci` → chaîne
complète → artefact) — le passage même de la CI démontre qu'aucun fichier non
versionné n'est requis ; étape SHA-256 répétée localement à l'identique.

**Statut** : `AUTOMATISÉ` (chaîne CI) ; procédure machine vierge documentée.

### REC-S1-009 — Persistance du stockage lue et affichée (S1.9 boucle 1, P0.9)

**Objectif** : l'utilisateur sait si son stockage local peut être purgé par le
navigateur. `persist()` était déjà demandé au démarrage (contrat §4) mais en
aveugle — désormais son résultat est LU et affiché ; on peut redemander.

**Dispositif** : `StockageOpfs.persistanceStockage(demander?)` (persisted() →
persist(), `null` honnête si API absente) ; état `persistanceStockage` évalué
au démarrage (`native` sur Capacitor — bac à sable applicatif) ; ligne
`.persistance-stockage` dans la carte « Espace de stockage » (Plus ›
Apparence) : accordée ✓ / non garantie ⚠ + bouton « Demander la persistance »
(toast honnête : le navigateur décide) / natif / inconnue.

**Preuves** : e2e (ligne présente dans Apparence, texte ∈ {4 états honnêtes},
clic sur « Demander la persistance » → toast, jamais bloquant) ; typecheck +
167 unit + build + e2e complet verts.

**Reste (S1.9 boucle 2)** : instruire le garde-fou d'espace existant
(D-096/D-097) — couvre-t-il import et sauvegarde AVANT de commencer ? —
compléter + tests quota.

**Statut** : `AUTOMATISÉ`

### REC-S1-009b — Garde d'espace AVANT toute grosse écriture (S1.9 boucle 2)

**Objectif** : Movenso ne commence pas une opération qu'il sait ne pas pouvoir
terminer. Instruction préalable : la capture (D-096) et la confirmation
d'import/restauration (§10) étaient couvertes ; l'EXPORT/sauvegarde ne
vérifiait rien avant d'écrire son archive temporaire, et le staging d'import
ne refusait qu'en échouant à l'écriture.

**Dispositif** :
- **Export/sauvegarde** (`#exporterEnFlux`) : la taille à écrire est connue
  d'avance (somme des médias présents) → refus avant d'ouvrir le temporaire.
  Mesuré au quota SYSTÈME réel, jamais à la limite volontaire D-097 (sinon
  l'export deviendrait impossible dès la limite atteinte — l'inverse du but).
- **Import/restauration** (`importerPack`) : borne basse fiable = taille de
  l'archive, refusée AVANT tout staging ; le contrôle fin reste à l'écriture
  (échec propre D-114) puis à la confirmation (§10, limite D-097 comprise).
- **Évolution assumée du 8A.4** : le refus d'une archive trop grosse arrive
  désormais dès l'import (aucune proposition fantôme) ; la démonstration §10
  « refus à la confirmation » est PRÉSERVÉE via un scénario où l'espace se
  dérobe entre la proposition et la confirmation (staging réussi, promotion
  refusée, la proposition reste, Annuler conserve l'état).

**Preuves** : e2e — (1) stockage plein simulé : export refusé avant le
temporaire ET import refusé avant staging, message « Espace insuffisant »
avec les deux tailles, aucune proposition créée ; (2) 8A.4 réécrit : archive
trop grosse → refus immédiat, 0 fichier écrit ; espace disparu après
proposition → refus à la confirmation, proposition conservée. 167 unit +
build + e2e complet verts.

**Statut** : `AUTOMATISÉ`

### REC-S1-003 — URL externes validées partout (S1.3, P0.3 de l'audit)

**Objectif** : aucune chaîne utilisateur ou importée n'atteint un `href`, un
`src` ou un embed sans validation. À la saisie : https seul, normalisé,
YouTube strict. Au rendu : re-contrôle des données stockées (packs) — texte
inerte plutôt que lien actif quand ce n'est pas sûr.

**Dispositif** : `src/securite/liens.ts` (`analyserLien`/`urlSure`/
`idYoutubeValide`) ; entrées via `mediaDepuisLien` + `majMediaLien` (refus
propre : toast, rien d'écrit, la saisie reste) ; puits gardés : lien
médiathèque (+`noreferrer`), embed + vignette YouTube (id vérifié seulement),
`<video src>`, référence d'alerte réglementaire.

**Preuves** : 15 unit (chaque protocole refusé a son test ; 8 formes d'URL
YouTube → même id ; hôte non listé jamais en embed ; id hostile — traversée,
injection de paramètre — rejeté) ; e2e (`javascript:` et `http:` refusés avec
message, média jamais muté ; zéro erreur JS sur tout le parcours). 182 unit +
build + e2e complet verts.

**Statut** : `AUTOMATISÉ`

### REC-S1-004 — Imports .movpack durcis (S1.4, P0.4 de l'audit)

**Objectif** : une archive hostile ne sort pas de la zone prévue et ne sature
ni la mémoire ni le stockage en silence ; tout refus est PROPRE (message
clair, staging nettoyé, rien de définitif).

**Dispositif** (`lireMovpackFlux`, D-165) : bornes `LIMITES_MOVPACK` (64 Mo /
petit fichier accumulé, 4 096 entrées, 8 Go décompressés) ; chemins contrôlés
explicitement (relatifs, sans `..`/antislash/contrôle/lecteur, doublons
refusés) ; extensions de média en liste blanche + signatures d'exécutables
(MZ/ELF/`#!`) refusées sur les premiers octets ; borne basse d'espace AVANT
staging (REC-S1-009b) en amont.

**Preuves** : corpus hostile `tests/movpack-hostile.test.ts` (11 tests — zip
bomb ciblée/globale, traversée, absolu/Windows, doublons, exécutables
déguisés, extensions interdites, JSON profond, archive tronquée, manifeste
mensonger ; chaque refus vérifie `puits.abandonner`) ; NR : les archives
légitimes passent inchangées (193 unit + e2e complet verts, imports kodokan/
club-judo/export-réimport intacts).

**Statut** : `AUTOMATISÉ`

### REC-S1-006 — Sauvegarde/restauration CERTIFIÉES sur corpus de référence (S1.6, P0.6)

**Objectif** : une sauvegarde complète restaure exactement ce qui est promis,
et uniquement cela — démontré sur une bibliothèque de référence riche, pas
sur un cas jouet.

**Corpus de référence** (construit par l'e2e, contexte isolé) : 2 disciplines
Unicode (« Aïkido 合気道 », « Judo-Éprouvette »), techniques accentuées + nom
traditionnel kanji, **relation avec raison et priorité**, **favori**,
contribution personnelle ET enseignement attribué, **composition** à
consignes, **vidéo locale** (4 096 octets déterministes), média en ligne
YouTube, capture **« à traiter »** (techniqueId null).

**Ce qui est restauré** (démontré) : la bibliothèque INTÉGRALE à l'identique
objet par objet (`deepEqual` avant/après : ids, relations note+priorité,
favoris, compositions, à-traiter, Unicode intact) + chaque vidéo à
l'**empreinte SHA-256 près**. **Ce qui n'est PAS restauré** (structurel,
jamais une perte silencieuse) : les **préférences d'appareil** (thème,
densité, limite d'espace, réglages de démarrage — `preferences.json` n'est
jamais exporté) et le **PIN** (jamais dans un export) — à reconfigurer ;
la **sauvegarde légère** restaure toutes les données mais AUCUNE vidéo
physique (les références restent, les fichiers sont dits absents).

**Cas d'erreur** : archive tronquée → refus propre au niveau UI (toast,
aucune proposition) ; octet altéré → refus d'intégrité (8B.1, NR) ; espace
insuffisant → refus avant staging (REC-S1-009b) ; interruption pendant la
restauration → transaction 8C.2 + proposition conservée (8A.4). Le cas
« média manquant à l'export » est couvert par la sémantique §20 (l'export
devient « partiel » et le DIT — jamais une entrée vide).

**Statut** : `AUTOMATISÉ` (bloc e2e dédié, contextes isolés)

### REC-S1-007 — Non-divulgation par FORMAT d'export (S1.7, P0.7 de l'audit)

**Objectif** : chaque format exporté a son test de non-divulgation — on OUVRE
l'archive réellement produite (unzip) et on y cherche des SENTINELLES
plantées dans chaque donnée privée ; une sentinelle retrouvée = une fuite.

**Dispositif** : `tests/non-divulgation.test.ts` (7 tests) sur bibliothèque
SENSIBLE (sentinelles uniques : carnet, contribution hors choix, composition
personnelle, capture à rattacher) :
- pack de discipline : carnet/à-rattacher/compo perso absents, `favoris: []`,
  le manifeste DIT `contenuPersonnel: false` — le publiable voyage ;
- opt-in compositions perso (D-127) : la compo voyage, le carnet JAMAIS ;
- pack partiel (choix de techniques) : les notes des techniques écartées ne
  fuient pas ; technique seule : une identité, rien d'autre ; composition :
  jamais de carnet ni favoris ;
- sauvegarde complète : contenu personnel inclus VOULU et DIT
  (`contenuPersonnel: true`) ; aucune trace de protection/PIN ;
- diagnostic : compteurs seuls — structurellement incapable de porter un
  secret (type `EntreeDiagnostic`).
E2e (bloc certification S1.6 étendu) : pseudo d'appareil planté avant
l'export réel → chaque entrée JSON de l'archive téléchargée est dézippée et
scannée (sentinelle absente, `preferences.json` jamais une entrée, aucune
trace pbkdf2/protections).

**Statut** : `AUTOMATISÉ` (200 unit + e2e complet verts)

### REC-S1-008 — Promesse « hors ligne » réduite et exacte (S1.8, option B, D-163)

**Formulation de référence** : « Les données et vidéos restent sur l'appareil.
Une connexion peut être nécessaire pour charger ou mettre à jour l'application
web et consulter les ressources externes. »

**Aligné** : Plus › À propos (app), description `package.json`, kicker de
l'accueil movenso-public (« Hors ligne » → « Sur ton appareil »),
`docs/systeme.md` §1. La page Confidentialité du site était déjà exacte.
Les mentions « hors ligne » restantes dans l'app parlent des DONNÉES
(vidéo stockée localement, capture sans réseau) — exactes, conservées.
PWA (démarrage en mode avion, installation, mises à jour contrôlées) notée
chantier post-v1 (D-163).

**Statut** : `FAIT` (revue exhaustive par grep app + site ; aucune promesse
d'app-shell hors ligne ne subsiste)

### REC-S1-005 — Import/restauration transactionnels : rollback + signalement (S1.5, B+C)

**Objectif** : après n'importe quelle interruption, ancien état complet OU
nouvel état complet — jamais un mélange silencieux.

**Dispositif (D-166)** : promotion → persistance INVERSÉE en cas d'échec
(les fichiers réellement déplacés sont re-déplacés vers le staging, la
proposition reste, le réessai re-promeut idempotent) ; au démarrage, les
orphelins résiduels (crash brutal) sont comptés et SIGNALÉS (toast → Plus ›
Médias), jamais supprimés d'office.

**Preuves (e2e)** : coupure simulée à la persistance (sauvegarder jette une
fois) → « Restauration impossible », videos/ = 0 (rollback), staging ≥ 1,
proposition intacte ; réessai → « Bibliothèque restaurée ✓ », videos/ = 1 ;
fichier étranger planté dans videos/ + rechargement → toast « orphelin »,
rien de supprimé (videos/ = 2). Import et restauration partagent le même
chemin patché. 200 unit + build + e2e complet verts.

**Statut** : `AUTOMATISÉ`

### REC-S1-011 — Zéro innerHTML + garde statique anti-injection (S1.11)

**Objectif** : aucun contenu injecté par concaténation HTML dans l'app, et un
garde-fou automatisé qui empêche durablement tout retour.

**Dispositif (D-166)** : l'unique occurrence (connecteurs SVG de la Mindmap,
`tracerLiensMindmap`) est convertie en **éléments SVG typés**
(`createElementNS` + `replaceChildren`) à attributs identiques — rendu
inchangé, Mindmap gelée respectée (e2e structure : hub, branches, ≥1 path,
recette O-soto-gari intacte). `outils/verifier-sources.mjs` interdit dans
`src/` : affectation `innerHTML`/`outerHTML`, `insertAdjacentHTML`,
`document.write`, `eval`/`new Function` — liste d'exceptions justifiées
VIDE ; branché dans `npm run verifier` et en étape CI dédiée.

**Preuves** : garde vert sur l'arbre courant ; test négatif démontré (fichier
avec `innerHTML =` injecté → sortie 1 nommant fichier et motif) ; 200 unit +
build + e2e complet verts après conversion.

**Statut** : `AUTOMATISÉ`

### REC-S1-012 — Chemins d'erreur des opérations critiques (S1.12, P0.12)

**Objectif** : toute erreur critique a un message compréhensible, un chemin de
récupération, et sa CAUSE conservée dans le diagnostic — jamais de stack
brute, jamais d'état mélangé.

**Inventaire vérifié (déjà couvert avant cette boucle)** : messages éditoriaux
+ état conservé + proposition qui reste (imports/restaurations, S1.5-B),
temporaires nettoyés (export : archive partielle supprimée ; staging balayé
au démarrage 8A §7), voile « … en cours » (D-131), garde de démarrage D-110
(WebView sans OPFS → message clair, jamais d'écran blanc), transaction 8C.2.
Les catch silencieux restants ont tous un repli légitime (best-effort
documenté : mesure DOM, partage natif → feuille de partage, vignette →
« choisis une autre photo »).

**Complété (D-166)** : `dernierEchec` — les catch des opérations critiques
(lecture d'un pack, installation, restauration complète, restauration de
sauvegarde interne, export .movpack, téléchargement de pack officiel — hors
annulation volontaire) consignent opération + message éditorial tronqué
(200 c.) ; les erreurs NON GÉRÉES (window error / unhandledrejection) sont
consignées SANS être avalées ; le diagnostic exporté porte une section
« Dernier échec » (ou « aucun depuis le démarrage »).

**Complété (D-217, S3.A14)** : chaque consignation porte un code STABLE
(`CODES_ECHEC` dans `domaine/diagnostic.ts` : `MOV-E01` export → `MOV-E06`
pack officiel, `MOV-E98/E99` non gérées — un code publié ne se recycle
jamais) ; le diagnostic rapporte aussi l'OPÉRATION LONGUE de la session
(voile `occuperPendant` et export en flux : libellé + début + fin, « ENCORE
EN COURS » si elle court toujours) et la version applicative complète.

**Preuves** : unit diagnostic (section présente, code + cause lisibles,
jamais de stack ; 3 états de l'opération longue) ; e2e (coupure S1.5 →
`dernierEchec = { code: "MOV-E04", operation: "restauration complète",
message: "écriture simulée refusée" }` ; chapitre export-diagnostic : code
et opération terminée dans le fichier produit). Verifier complet vert.

**Statut** : `AUTOMATISÉ`

### REC-S1-010 — Environnements non compatibles (S1.10 option 1, P0.10)

**Objectif** : aucun écran blanc ni erreur technique brute sur un
environnement non supporté ; jamais d'interface partiellement fonctionnelle.

**Dispositif (D-167)** : garde de démarrage testant `getDirectory` ET
`createWritable` (le cas Safari) ; message par plateforme ; écran
`.erreur-demarrage` nommant les navigateurs supportés (Chrome, Edge,
Firefox récents), disant l'échappatoire (sauvegarde .movpack importable sur
un navigateur supporté) et l'innocuité (« rien n'a été modifié »).

**Preuves** : e2e — deux contextes simulés (StorageManager sans
getDirectory ; FileSystemFileHandle sans createWritable) → écran propre,
navigateurs nommés, 0 `.barre-nav`, 0 erreur JS. Quota faible couvert par
REC-S1-009b ; mode privé Chrome = OPFS fonctionnel (couvert par tout l'e2e).

**Statut** : `AUTOMATISÉ` (simulations) ; recette humaine Safari/Firefox
réels notée pour la matrice v1 (S3).

### REC-S2-008 — Promesses de sauvegarde exactes (S2.8, P1.8 de l'audit)

**Objectif** : plus aucun « restaurable à l'identique » — la formulation dit
ce qui revient (savoir, compositions, favoris, vidéos) et ce qui se
reconfigure (réglages d'appareil, PIN), en cohérence avec la certification
REC-S1-006 et le toast de restauration (déjà exact).

**Corrigé** : feuille Plus › Sauvegardes (bouton « Sauvegarde complète »),
aide À propos (§ Sauvegarde et restauration), `docs/recette-beta.md`. Gardé
sciemment : la ligne corbeille (« Restaurer une fiche la remet à
l'identique ») — elle parle d'une FICHE restaurée depuis la corbeille, ce
qui est exact. Le site public était déjà correct (page Confidentialité).

**Preuves** : grep sans reste côté UI/site/docs utilisateur (seuls des
commentaires de code internes subsistent) ; 201 unit + build + e2e verts.

**Statut** : `FAIT` (revue exhaustive)

### REC-S2-009 — Alternatives au glisser-déposer (S2.9, P1.9 de l'audit)

**Objectif** : le glisser-déposer n'est jamais le seul chemin pour réordonner
— déplacement possible au doigt sans geste fin, au clavier, et via un lecteur
d'écran, avec annonce du résultat.

**Livré (D-168)** : sur les QUATRE sites de réordonnancement (disciplines,
catégories, niveaux, blocs de composition) — (1) la poignée ⠿ devient un
**bouton focalisable** : flèches haut/bas (ou gauche/droite) = déplacer d'un
cran ; (2) boutons **▲/▼ explicites** (« Monter X » / « Descendre X »,
désactivés en butée) à côté de chaque élément ; (3) chaque déplacement
persiste aussitôt (même garde PIN que le glisser) et est **annoncé** dans une
zone `aria-live="polite"` (« X, position 2 sur 3 » ; en butée : « X est déjà
en première position »). Cœur commun `deplacerDunCran` (`glisser.ts`),
consommé par les quatre sites.

**Bug débusqué en route** : la primitive `reordonner(x, cible)` (retirer puis
insérer à l'index de la cible) est un **no-op pour descendre d'un cran** — le
retrait décale la cible d'un rang vers le haut. Le glisser masquait le défaut
(on survole l'élément d'après) ; « descendre » se fait donc en faisant monter
le voisin du dessous.

**Preuves** : e2e — disciplines (▲ puis ↓ clavier, annonce vérifiée, ▲
désactivé en butée), catégories (▼ puis ↑ clavier, aller-retour), blocs de
composition (▼ puis ↑ clavier, annonce) ; 203 unit + build + e2e verts.

**Reste (honnête)** : TalkBack réel non essayé — les boutons ▲/▼ nommés et
l'`aria-live` sont le chemin prévu ; à confirmer lors d'une recette appareil
(peut s'adosser à la recette S2.3 ou à S2.10 accessibilité).

**Statut** : `FAIT` (`AUTOMATISÉ` ; TalkBack appareil en attente de recette)

### REC-S2-010 — Accessibilité des parcours essentiels (S2.10, P1.10) — EN COURS

**Inventaire (revue du code, 2026-08-02)** : socle déjà correct — `lang`,
`aria-current` (nav), `role=tab`/`aria-selected` (Relations),
`aria-pressed` (favoris), `role="status"` (toast = erreurs annoncées),
`:focus-visible` global, boutons-icônes tous nommés, titres par écran,
réordonnancement clavier (S2.9). Écarts : champs au placeholder seul,
modales non modales (ni Escape, ni `aria-modal`, ni retour de focus),
cibles/contraste/zoom à vérifier, TalkBack/clavier = recette appareil.

**Tranche 1 livrée — noms accessibles** : 16 inputs + 2 textareas gagnent
un `aria-label` (recherches, liens, attributions, noms, discipline,
libellé média, description, points clés) ; les champs à `<label for>`
existants comptent. **Garde e2e `champsTousNommes`** : aucun champ
visible sans nom accessible, balayé aux points denses (entonnoir de
composition ; fiche en édition + feuille média) — un futur champ anonyme
casse le test.

**Tranche 2 livrée — modales réellement modales** : les 15 feuilles
`role="dialog"` portent `aria-modal="true"` + `tabindex="-1"` ; **Échap
ferme la modale du dessus** (listener central : il clique le dernier
`.voile` — même chemin de fermeture que le toucher hors feuille ; le voile
OCCUPÉ n'est pas concerné, une opération ne s'abandonne que par son bouton
Annuler) ; **gestion centrale du focus** (`updated()`) : à l'ouverture le
focus entre dans la feuille (champ `autofocus` s'il existe, sinon la
feuille elle-même — pas de clavier virtuel surprise), à la fermeture il
REVIENT à l'élément ouvreur. Preuve e2e : aria-modal présent, focus dans
la feuille à l'ouverture, Échap ferme, focus rendu à l'ouvreur — et tout
le parcours existant (PIN, imports, funnels) passe inchangé.

**Tranche 3 livrée — cibles, contraste, zoom** : (1) **contraste vérifié
par calcul** (luminance WCAG) : encre/sourdine/accent sur carte/papier et
sur-accent sur accent ≥ 4,5:1 (AA) sur les DEUX thèmes ET les 5 tonalités
d'accent — aucun correctif nécessaire (min observé 4,70, ocre) ; (2)
**cibles ≥ 24 px** (WCAG 2.2) : les deux seuls contrôles sous la barre
(boutons ▲/▼ du réordonnancement ~18 px, poignée ⠿ ~20 px) remontés par
le padding ; le reste (chips 26+, cœur 34, boutons, kpi) était déjà bon ;
(3) **zoom 200 %** : e2e à viewport 320 px (proxy d'une fenêtre 640 px
zoomée ×2) — accueil, menu Plus, À propos sans défilement horizontal.

**Tranche 4 (D-172, porteur 2026-08-02)** : la traversée TalkBack
exhaustive est ABANDONNÉE (trop coûteuse à exécuter) — le socle technique
est en place et vérifié par e2e, **les remontées utilisateur feront foi**
pour les défauts TalkBack résiduels. **Fluidité au doigt confirmée**
(Samsung A36) : Mindmap/Carte fluides (pan, zoom, pincement), Explorer
instantané.

**Statut** : `CLOS` (tranches 1-3 `AUTOMATISÉ` ; TalkBack = remontées
utilisateur, D-172)

### REC-S2-011 — Sortie de Movenso signalée (S2.11, P1.11 de l'audit)

**Objectif** : aucun départ silencieux vers l'extérieur — l'utilisateur voit
OÙ il va avant de cliquer.

**Constat vérifié** : DEUX sorties externes dans toute l'app (revue
`target="_blank"`) — le lien de la médiathèque et la référence d'alerte
réglementaire ; les cartes entières n'ouvrent jamais de lien externe ; le
HTTP n'est jamais cliquable (S1.3), l'avertissement HTTP est donc sans objet.

**Livré (D-168)** : `domaineDe()` (helper central, www retiré, null si non
sûr — testé) ; médiathèque : « ▶ Ouvrir le lien · youtube.com ↗ » + infobulle
« Quitte Movenso » ; alerte : ↗ existant + infobulle « Quitte Movenso —
<domaine> ». `rel="noopener noreferrer"` partout (S1.3).

**Preuves** : 5 assertions unit (`domaineDe`) ; revue exhaustive des sorties ;
202 unit + build + e2e verts. E2e dédié non ajouté (le `<a>` médiathèque
n'apparaît que pour un média sans fiche — cas rare, gabarit revu).

**Statut** : `FAIT` (helper `AUTOMATISÉ`)

### REC-S2-014 — Première ouverture claire (S2.14, P1.14 de l'audit)

**Objectif** : à la première ouverture, l'utilisateur sait ce qu'est Movenso,
que le vide est un choix, que ses données restent locales et où vit la
sauvegarde — sans tutoriel imposé, sans PIN demandé.

**Livré (D-168)** : l'état vide de la Bibliothèque dit — accroche (« Movenso
est ta mémoire du mouvement : tes techniques, tes repères et tes séances,
dans une bibliothèque à toi »), « Elle démarre vide, par choix », les deux
actions (Importer un pack / Créer ta première technique, inchangées), et le
filet (« Tes données et vidéos restent sur cet appareil — pense à créer une
sauvegarde de temps en temps (Plus › Sauvegardes) »). Le starter pack est
une décision à étudier avec le porteur (hors de cette boucle, D-168).

**Preuves** : e2e à la première ouverture (accroche, vide-par-choix,
localité, chemin de sauvegarde) + assertions historiques réalignées.
202 unit + build + e2e complet verts.

**Statut** : `AUTOMATISÉ`

### REC-S2-015 — Campagne bibliothèque vide (S2.15, P1.15 de l'audit)

**Objectif** : aucun écran ne suppose une discipline, technique,
composition, relation, favori, média, capture ou pack existants.

**Livré (D-168)** : campagne e2e systématique sur installation VIERGE,
mode avancé + relations bêta activés pour tout révéler — chaque onglet de
la nav (Bibliothèque, Favoris, Relations, Compositions, Plus) et chacun
des 13 sous-écrans de Plus (Disciplines et classement, Gestion des
techniques, À traiter, Corbeille, Doublons, Médias, Relations entre
techniques, Créer ou exporter un pack, Sauvegardes, Sécurité, Apparence,
Diagnostic, À propos) se rend avec un contenu utile (état vide nommé ou
commandes), zéro erreur JS (surveillance globale). « Importer un pack »
exclu du balayage (action → sélecteur de fichier), couvert par les tests
d'import existants.

**Couverture par les tests préexistants** (les WORKFLOWS sur vide, en plus
des écrans) : premier lancement + création depuis rien (S2.14, scénario
A), création de discipline/technique/composition depuis le vide, recherche
sans résultat, publication refusée sans contenu, restauration sur
installation vierge (contexte C), états vides Favoris/Relations (« Choisis
un point de départ » sans redirection, D-137).

**Statut** : `AUTOMATISÉ`

### REC-S3-D1/D2 — Relations : en-tête uniforme, hasard sur place (D-179)

**Objectif (verdicts porteur)** : D1 — uniformiser les quatre vues (« la
loupe en haut est mieux que la barre ») ; D2 — le dé centre aléatoirement
SUR PLACE dans la vue courante, « exit la page principale ».

**Livré** : en-tête identique sur Liste · Carte · Mindmap · Explorer —
loupe (panneau « Centrer sur… » PARTAGÉ, `panneauCentrer`), **🎲 « Centrer
au hasard »** (technique reliée tirée au sort, jamais le centre courant,
aucun écran intermédiaire), ⌖ revenir au départ (si historique). Supprimés :
la barre inline `selecteurCentre` (Liste/Carte/Explorer), le doublon du
panneau interne à la Mindmap, le bouton « Changer de point de départ »
(v1 D-175). L'écran « Choisis un point de départ » ne sert plus que la
toute première visite (contrat D-137 intact).

**Preuves (e2e)** : loupe présente dans l'en-tête Mindmap ET Liste ;
l'ancienne barre absente ; 🎲 recentre sans passer par l'écran d'entrée et
reste dans la vue courante ; la loupe recentre depuis la Liste (panneau +
chips). 203 unit + build + e2e complet verts.

**Statut** : `AUTOMATISÉ`

### REC-S2-016 — Campagne grosse bibliothèque (S2.16, P1.16 de l'audit)

**Objectif** : les workflows tiennent sur un corpus massif ; mesures.

**Livré** : `npm run campagne:charge` (`tests-navigateur/campagne-charge.mjs`,
hors du parcours e2e — à la demande) : génère le jeu P1.16 — 10 disciplines
(2 catégories + 3 niveaux chacune), **2 000 techniques, 10 000 relations**
(5/technique, types par défaut, notes + priorités), **500 contributions,
100 compositions** de 10 pas, 50 favoris — persiste (validation complète),
recharge à froid et mesure. Zéro erreur JS sur toute la campagne.

**Mesures (conteneur CI, Chromium headless, 2026-08-02)** :
| Mesure | Résultat |
|---|---|
| génération + validation + persistance | ~380 ms |
| **démarrage à froid** (reload → premier écran) | **~1 000 ms** |
| recherche (frappe → résultat) | ~120 ms |
| ouverture de fiche | ~25 ms |
| explorateur d'une discipline (200 cartes) | ~80 ms |
| Mindmap (ouverture) | ~25 ms |
| Carte / Explorer (bascule de vue) | ~3 ms |
| persistance complète (2e écriture) | ~230 ms |
| mémoire JS (usedJSHeapSize) | ~34 Mo |

Aucun goulot : tout est sous la seconde, la recherche et les vues Relations
restent instantanées à 10 000 arêtes.

**Restes (honnêtes)** : médias multi-Go non simulés (allocation disque du
conteneur — le flux d'import est déjà borné et streamé S1.4, l'espace gardé
S1.9) ; temps d'import d'un gros pack non mesuré isolément (le rapprochement
sur 2 000 identités est le point à surveiller — à mesurer si un cas réel
apparaît) ; fluidité AU DOIGT (fps Mindmap/Explorer) = appréciation
appareil, à coupler à la recette porteur. Piège d'outillage consigné : la
recherche de l'écran racine PERSISTE dans les filtres — l'explorateur
filtré par une recherche précédente peut légitimement afficher « aucune
technique ne correspond » (comportement voulu, pas un bug de charge).

**Statut** : `AUTOMATISÉ` (campagne à la demande) + fluidité au doigt
`VALIDÉE` sur appareil (porteur, Samsung A36, 2026-08-02 : Mindmap/Carte
fluides — pan, zoom, pincement —, Explorer instantané)

### REC-S2-007 — Vocabulaire suppression / corbeille / restauration (S2.7)

**Inventaire (revue exhaustive des libellés)** : le schéma existant est
COHÉRENT et conservé — « Mettre à la corbeille » (réversible, dit où
restaurer), « Supprimer définitivement » (depuis la corbeille, irréversible
dit), « Vider la corbeille » (irréversible + point de restauration conservé),
« Retirer » réservé aux RÉFÉRENCES (favori, média d'une fiche, vignette, pas
de composition, lien de relation — pas d'objet détruit). Le vocabulaire
D-099 (« point de restauration », jamais « snapshot ») était appliqué
partout sauf un oubli.

**Trois écarts corrigés (D-168)** : (1) suppression de composition — dernier
« snapshot » utilisateur → « point de restauration » ; (2) discipline vide —
confirm « Retirer » désaligné de l'aria-label « Supprimer » → verbe unifié +
point de restauration dit ; (3) la DURÉE de conservation de la corbeille
n'était dite nulle part → l'écran Corbeille dit désormais « sans limite de
durée — rien n'expire tout seul » (notre modèle : jamais d'expiration
silencieuse, mieux que la durée chiffrée que l'audit imaginait).

**Tests existants vérifiés (rien à ajouter)** : suppression discipline non
vide (REC-006-002 : préparation, contenu réel présenté, export d'abord),
technique reliée (liens entrants nettoyés au vidage D-081), technique dans
une composition (annoncée dans les dépendances au moment de la mise à la
corbeille), corbeille e2e (restaurer / supprimer définitivement / vider).

**Statut** : `FAIT` (202 unit + build + e2e complet verts)

### REC-S2-004 — Annulation des opérations longues (S2.4, P1.4 de l'audit)

**Instruction** : l'annulation d'export EXISTAIT (annulerExport — temporaire
supprimé, toast, 8B.3) mais AUCUN bouton ne l'appelait ; l'`estAnnule` de la
lecture de pack n'était pas branché ; les transactions courtes (installation,
restauration après confirmation) restent NON annulables par principe — la
cohérence passe avant le confort (documenté).

**Livré (D-168)** : le voile « … en cours » porte un bouton d'annulation
quand l'opération le permet (`annulationOccupe`) — export/sauvegarde
(→ annulerExport existant) et lecture d'un pack (→ estAnnule branché,
abandon du puits = staging nettoyé, toast « Import annulé — rien n'a été
écrit », jamais consigné comme échec). Reste (boucle suivante) : annulation
de l'INGESTION vidéo (jeton dans ecrireVideo + bouton sur la feuille de
progression).

**Preuves** : unit (lecture annulée → ErreurMovpack « annulé » + puits
abandonné ; export déjà couvert 8B.3) ; e2e (le voile affiche le bouton et
l'annulation répond). 203 unit + build + e2e complet verts.

**Boucle 2 — ingestion VIDÉO annulable (S2.4 complet)** : jeton `estAnnule`
vérifié entre les blocs de l'ANALYSE (empreinte SHA-256, `AnnulationIngestion`
dédiée) et de l'ÉCRITURE (`ecrireVideo` : abort du writable + brouillon de
staging jeté) ; bouton « Annuler » sur la feuille de progression (deux
phases) ; l'abandon est un CHOIX — toast « Ajout annulé — rien n'a été
écrit », jamais consigné en échec, la capture/fiche reste ouverte. E2e :
fichier de 24 Mo + abandon → bibliothèque inchangée, zéro brouillon vidéo en
staging, feuille refermée. Les transactions courtes restent non annulables
(principe documenté).

**Statut** : `AUTOMATISÉ` (S2.4 COMPLET)

### REC-S2-002 — Terminer proprement les séances (S2.2, P1.2 de l'audit)

**Objectif** : plus d'impasse au dernier pas — une fin nette, dite, résumée.

**Livré (D-169)** : « Terminer » remplace le « Suivant » grisé au dernier
pas ; l'appui coupe chrono/voix/bips et bascule sur un résumé minimal (nom,
N pas parcourus, durée RÉALISÉE — horloge murale, remise à zéro à chaque
démarrage de revue) avec un unique « Fermer » ; le dernier pas MINUTÉ
conclut seul la séance (auto-avance → résumé + « Séance terminée » vocal +
bip final) ; Quitter en cours reste sans résumé (fin réelle seulement).

**Preuves (e2e)** : dernier pas manuel → plus de Suivant, Terminer → résumé
(« 2 pas parcourus · durée réalisée »), annonce vocale journalisée, Fermer
sort net ; composition à un seul pas minuté d'1 s → le résumé apparaît SEUL.
NR : sortie par retour Android toujours sans résumé ni chrono résiduel
(D-126 réaffirmé). 203 unit + build + e2e complet verts.

**Statut** : `AUTOMATISÉ`

### REC-S2-001 — Création de techniques : un seul écrivain, garde par chemin (S2.1, option V)

**Objectif (D-169)** : plus jamais deux logiques de création divergentes —
et jamais de doublon par inattention, SANS casser le moment chaud de la
capture.

**Livré** :
- **un seul écrivain** : `#pousserNouvelleTechnique` (trim, discipline
  vérifiée, forme canonique) — `creerTechnique` (persiste + ouvre la fiche)
  et `terminerCapture` (sa propre transaction, n'ouvre rien) l'utilisent
  tous deux ; l'écart réel (la capture poussait la technique à la main,
  sans trim ni validations) est fermé ;
- **explorateur discipline** : la même garde de doublon EXACT que la
  feuille Ajouter (« existe déjà… créer quand même une technique
  distincte ? ») sur le champ ET le bouton Créer ;
- **capture** : JAMAIS de question de doublon (moment chaud, choix
  documenté) — le rapprochement/Doublons potentiels rattrape après coup.

**Preuves (e2e)** : doublon exact dans l'explorateur → confirmation nommée ;
refusée = zéro création ; acceptée = identité distincte ; capture au nom
existant → création SANS dialogue (un dialog ferait échouer le test).
203 unit + build + e2e complet verts. Note : les identifiants sont des
ULID — la crainte « slug vide » de l'audit était sans objet.

**Statut** : `AUTOMATISÉ`

### REC-S2-006 — Fusion/défusion clarifiées (S2.6, P1.6 de l'audit)

**Instruction** : l'essentiel existait — point de restauration AVANT fusion
(`avant-fusion-doublon`) ET avant défusion, bundle pré-fusion (D-101 voie H),
défusion annonçant déjà sa limite (« les liens entrants restent sur la fiche
fusionnée »), test des relations ENTRANTES déjà présent
(tests/doublons.test.ts : favoris, relations entrantes, compositions réécrits
de B vers A). Manquait UNIQUEMENT l'aperçu des impacts externes.

**Livré (D-168)** : le panneau de fusion dit désormais, AVANT le geste, ce
qui pointait « B » et suivra la fiche fusionnée (liens entrants redirigés,
pas de composition redirigés, favori qui suit) + « un point de restauration
est créé avant la fusion — défusionnable depuis Doublons ».

**Preuves** : e2e (le panneau annonce point de restauration + défusion) ;
NR fusion/défusion existantes intactes. 203 unit + build + e2e verts.

**Statut** : `AUTOMATISÉ`

### REC-S2-003 — Chrono & audio : recette appareil réel (S2.3) — EN COURS

**Appareil** : Samsung Galaxy A36, Chrome Android (app web déployée).

**Phase A — comportements de base : 6/6 OK (porteur, 2026-08-02)**
- A1 ✓ déroulé complet : prépa 3-2-1 vocale, « Préparez-vous, <nom> 1 min »,
  annonce mi-temps, bips finaux, bip de fin, passage auto ;
- A2 ✓ pause 10 s → reprise exactement où c'était ;
- A3/A4 ✓ Suivant/Précédent : son coupé net, pas suivant annoncé, avec et
  sans son ;
- A5 ✓ « bips seuls » OK, « muet » = zéro son ;
- A6 ✓ Terminer → résumé, durée RÉELLE confirmée par le porteur ;
- observation notable : le décompte CONTINUE en arrière-plan (app quittée
  pour écrire) — comportement Chrome/A36 constaté, à recouper en B2/C2.

**Phases B (interruptions) et C (dérive) : retour porteur (2026-08-02)**
- constat : **le chrono dérive selon les cas** en arrière-plan / écran
  verrouillé (Chrome bride les minuteurs d'un onglet caché — la dérive
  dépend de la charge, de l'économie d'énergie, du chemin d'interruption) ;
- **décision porteur (D-170, GO explicite)** : l'arrière-plan SUSPEND la
  séance ; en complément, verrou d'écran pendant l'entraînement (D-93 levé).

**Livré (D-170)** : `visibilitychange` → hidden pendant l'entraînement =
`suspendreSeance` (même pause que le bouton, voix coupée net, bandeau
« Séance mise en pause — l'app est passée en arrière-plan », reprise d'un
GESTE, jamais automatique) ; **Screen Wake Lock** posé sur l'écran
d'entraînement (`maintenirEcranSeance`), relâché à toute sortie, redemandé
au retour au premier plan (le navigateur le relâche seul en cachant l'app) ;
silencieux si l'API manque. Promesse documentée (systeme.md §4bis,
workflows.md §6) : séance = écran allumé, app au premier plan ; caché ou
verrouillé = pause, reprise où on était.

**Preuves** : e2e — wake lock demandé à l'entrée et relâché à la sortie
(API simulée), hidden → chrono en pause + bandeau + décompte figé 1,6 s,
retour → toujours en pause, ▶ Reprendre relance ; 203 unit + build + e2e.

**Contre-recette appareil (porteur, Samsung A36/Chrome, 2026-08-02) : 4/4 OK**
- CR1 ✓ l'écran ne s'éteint plus tout seul pendant une séance (verrou actif) ;
- CR2 ✓ verrouillage volontaire → son coupé net, au retour chrono figé +
  bandeau + ▶ Reprendre reprend au même point ;
- CR3 ✓ changement d'app → même comportement (pause + bandeau + reprise) ;
- CR4 ✓ la pause manuelle inchangée, sans bandeau.

**Statut** : `VALIDÉ` (D-170 démontré sur appareil — S2.3 CLOS)

### REC-S2-012 — Médias orphelins : total, rattachement (S2.12)

**Instruction** : la distinction orphelin ≠ référence cassée EXISTAIT déjà
(deux listes séparées : « Vidéos manquantes » avec accès fiche, « Fichiers
inutilisés » avec taille par fichier), la suppression individuelle avec
prévisualisation OBLIGATOIRE aussi (D-107), le signalement au démarrage
depuis S1.5-C. La « suppression groupée » demandée par l'audit CONTREDIT la
décision D-107 (« jamais en masse ») — question posée au porteur, non
implémentée en attendant.

**Livré (D-168)** : (1) TOTAL de la section affiché (« total : X Mo ») ;
(2) **rattachement d'un média retrouvé** : dans la ligne orpheline vérifiée,
une recherche courte (5 résultats) rattache le fichier à une technique via
une contribution personnelle — le fichier ne bouge pas, il redevient
référencé ; empreinte recalculée (déduplication future) ; échec de
persistance → contribution retirée, rien de mutant.

**Preuves (e2e)** : orphelin planté → À traiter → Vérifier → recherche →
chip → toast « rattaché », la ligne disparaît, la contribution porte le
média. 203 unit + build + e2e complet verts.

**Suppression groupée (D-171, arbitrage porteur 2026-08-02)** : « un plus
dans ce cas » — actée comme PRÉCISION de D-107 (la masse reste interdite
pour les références et les fiches ; des fichiers sans aucune référence,
chacun prévisualisé, peuvent partir ensemble). Livré : bouton « Supprimer
les N fichiers vérifiés — X Mo » dès 2 vérifiés (confirmation nommée),
chaque fichier RE-vérifié orphelin à l'instant de supprimer (un fichier
redevenu référencé est conservé et compté à part dans le toast) ;
l'individuel reste le chemin premier. Preuve e2e : 3 orphelins plantés,
1 vérifié = pas de bouton, 2 vérifiés = bouton avec compte + taille,
suppression → seuls les vérifiés partent, le troisième reste.

**Statut** : `AUTOMATISÉ` (complet — rattachement + groupé D-171)

### REC-229-001 — Composition à rôles : déclaration, lien, lecture en trame

> **Révisée D-231** (le chemin réel de l'entonnoir, après six captures du
> porteur), puis **réécrite D-239** : la version précédente décrivait encore
> quatre valeurs de lien (« ⇉ En même temps », « → En réaction », « ↓ Puis »),
> des glyphes sur les cartes et une poignée de glisser-déposer — tout cela a
> été RETIRÉ depuis (D-233, D-235). Une recette qui décrit un produit disparu
> ne prouve rien.

**Objectif**

Monter une séquence à plusieurs (attaque, esquive simultanée, contre) et la
relire en trame — sans jamais perdre un pas, ni une possibilité d'édition, ni
le regroupement temporel après un remaniement.

**Préconditions**

- État initial : bêta « Compositions » activée (D-223), aucune composition.
- Données : quelques techniques de la même discipline.
- Plateforme : web et Android (aucun chemin natif spécifique).

**Étapes**

1. Compositions → **Créer** → nommer → **Suivant**.
2. Étape « Qui pratique ? » : toucher **À plusieurs** (deux champs vides
   apparaissent), tenter **Suivant** sans rien saisir, puis **＋ Ajouter un
   rôle** deux fois pour arriver à quatre.
3. Nommer les quatre rôles, **Suivant**.
4. Ajouter les pas en choisissant à chaque fois le rôle, et en cochant
   **« Rejoint le temps précédent »** pour ceux qui se jouent en même temps :
   un pas seul, deux pas de rôles différents dans un même temps, **deux pas du
   MÊME rôle dans un même temps**, un pas neutre (aucun rôle), un dernier pas
   seul.
5. Lire la composition **sur téléphone** (écran étroit), puis **sur tablette en
   paysage ou sur PC**.
6. Toucher **✎** dans la barre haute : l'écran entier passe en édition.
7. Sur un pas : changer son rôle, basculer son lien, le monter avec **▲**,
   le retirer avec **✕**. Retirer en particulier **le premier pas d'un temps
   qui en contient plusieurs**, puis **le tout premier pas de la composition**.
8. Ressortir de l'édition (**✎** de nouveau) et relire.
9. ⋮ → Rôles → ajouter un rôle sans le nommer, puis en le nommant, puis en
   retirer un et confirmer.

**Résultat attendu**

- L'étape « Qui pratique ? » vient **avant** les pas ; **Seul** est le défaut
  et se passe d'un geste. **Aucun nom n'est proposé** — ni paire toute faite,
  ni « Rôle 3 » ; **Suivant** reste inactif tant qu'un champ est vide.
- Chaque pas porte son rôle **dès sa création**, et son lien est un **unique
  interrupteur** : « Rejoint le temps précédent ». Il n'existe aucune autre
  relation dans le produit.
- L'axe gauche numérote les **temps** : une **rangée = un temps**. Les pas
  liés partagent la rangée ; un pas non lié en ouvre une.
- Deux pas du **même rôle dans un même temps** s'**empilent** dans la même
  cellule — c'est le seul moyen de dire « vraiment simultané pour une même
  personne », et il fonctionne.
- **Aucun glyphe, aucun mot de liaison** sur les cartes : la simultanéité est
  le sens de partager une rangée, portée par la mise en page seule.
- **Sur écran étroit** : une colonne, le nom du rôle **visible** sur chaque
  carte, les temps intacts. **Sur écran large** : une **voie par rôle**, le nom
  **une seule fois** en tête de voie. Un pas **neutre traverse toute la
  largeur** (correctif D-238).
- Chaque rôle a sa **couleur**, distincte jusqu'à six, qui encadre ses cartes —
  toujours **en plus** du nom, jamais à sa place.
- **En lecture, les cartes ne portent AUCUN outil** (D-233). Tout l'outillage
  n'apparaît qu'après **✎**, qui force aussi la **colonne unique**.
- Le regroupement **survit aux remaniements** (garde-fou porteur, D-235) :
  retirer le premier pas d'un temps ne fusionne pas les autres dans le temps
  précédent — le temps survit, amputé ; retirer le tout premier pas de la
  composition ne rend jamais la bibliothèque invalide ; **▲/▼** à l'intérieur
  d'un temps ne le scinde pas, et franchir sa frontière change bien de temps.
- Dans le ⋮, un rôle n'est créé **que** s'il est nommé ; en retirer un ne
  supprime **aucun** pas — ses pas redeviennent neutres.

**Risques de régression**

- Composition **solo sans lien** : lecture en liste strictement inchangée.
- Composition **solo AVEC un lien** : passe en trame par temps (voulu, D-231).
- Sept rôles et plus : colonne unique quelle que soit la largeur.
- Requêtes de conteneur absentes (vieux moteur) : colonne unique — jamais une
  grille cassée.
- Composition **importée d'avant D-235** (valeurs `simultane` / `reaction` /
  `puis`) : se lit sans erreur, et la première écriture la normalise.
- Grille de la **bibliothèque** : vignettes à leur taille normale — la trame ne
  partage plus aucune classe avec elle (D-232, garde automatique).
- Séance minutée : durée, chrono et résumé inchangés.

**Preuves**

- Test automatique : unit `tests/composition.test.ts` — découpage en temps,
  répartition en voies, trame déclenchée par un lien seul, tolérance aux
  valeurs héritées, et **les quatre gestes du garde-fou** (suppression d'un
  ouvreur, suppression du premier pas, déplacement intra-temps, déplacement
  franchissant un temps).
- e2e chapitre `composition-a-plusieurs.mjs` — **quatre rôles déclarés par
  l'entonnoir**, lecture vérifiée à **400 px** (repli, noms de rôle visibles,
  teintes distinctes) **et à 900 px** (voies déployées, en-tête de colonnes).
- Contenu réel : le **Nage-no-kata (26 pas)** et le **Goshin-jutsu (36 pas)**
  des packs officiels sont lisibles de bout en bout — c'est ce corpus qui a
  révélé le pas neutre épinglé à la première colonne (D-238).

**Statut**

`AUTOMATISÉ` (recette appareil à faire au gel RC — voir REC-B4-001)

### REC-B4-001 — Recette RC sur appareil (B4, gel des fonctions)

**Statut** : `EN ATTENTE DU PORTEUR` — rédigée le 2026-08-08 (D-240).

**Ce qui est gelé.** À partir du 2026-08-08, plus aucune fonction nouvelle
n'entre dans la v1 (D-240). Ne restent recevables que : les correctifs issus
de cette recette, et le **contenu** (versions détaillées des deux katas, que
le porteur prépare — une composition de plus dans un pack n'est pas une
fonction de plus).

**Contexte à connaître avant de commencer**

- Version : celle de `package.json` (`npm run versions`). L'app affiche sa
  version complète et son commit de build dans
  **Plus › À propos** — le vérifier avant de recetter, pour ne pas juger un
  build périmé (leçon de la publication du 2026-08-08).
- **Web** : le site sert le dernier build publié. **APK** : à lancer à la
  demande (Actions → `apk` → *Run workflow*, D-197).
- **La signature de l'APK est ÉPHÉMÈRE** (D-113, le secret stable est repoussé
  de deux semaines, D-239) : chaque build est signé d'une clé différente, donc
  une **réinstallation par-dessus la précédente échouera**. Désinstaller
  d'abord. **Conséquence à ne pas subir : désinstaller EFFACE les données de
  l'app.** Faire une **sauvegarde** (Plus › Stockage et sauvegardes) avant
  toute réinstallation, et la restaurer après.

**R1 — Composition à plusieurs, par l'entonnoir réel.** Dérouler REC-229-001
en entier, sur téléphone **et** sur écran large. Motif : c'est la fonction qui
a le plus bougé (D-227 → D-238) et la seule dont une recette porteur a déjà
démenti une livraison.

**R2 — Contenu réel des packs.** Installer les cinq packs officiels — **Judo
0.7.1, Jujitsu 0.3.1, Karaté 0.3.0, JJB 0.2.0, Taïso 0.2.0** — et, sur chacun,
**compter les techniques après mise à jour** : elles ne doivent pas doubler
(D-247). Puis : ouvrir le **Nage-no-kata** et le **Goshin-jutsu** et les faire
défiler en entier dans les deux orientations (sections lisibles en pleine
largeur, aucun pas tronqué, projections référencées ouvrant leur fiche) ;
vérifier qu'une fiche de **Taïso** et une de **Karaté** portent bien leur
illustration SPÉCIFIQUE, et qu'une fiche de **Jujitsu** ou de **JJB** porte la
carte de sa FAMILLE, titre générique visible. Le **Judo n'a aucune image** :
ses fiches s'appuient sur les vidéos Kodokan, c'est voulu.

**R2bis — Une séance au chrono, sur du contenu réel.** Le Taïso est le seul
pack dont les seize séances sont **intégralement minutées** (20 à 46 min,
D-248) : y dérouler une séance complète vaut mieux que la fixture fabriquée
qu'utilisait REC-S2-003.

**R3 — Packs officiels depuis l'APK** (D-219). Depuis l'**APK** et non le web :
le catalogue se charge, un pack s'installe par le circuit normal, la mise à
jour d'un pack déjà installé applique bien sous-titre et couverture (D-222).

**R4 — Passe visuelle des thèmes** (C3, seul reliquat de ce chantier). Clair,
sombre, et « suivre le système » en basculant le réglage Android en cours de
route. Regarder en particulier : les **six teintes de rôle** (distinctes et
lisibles dans les deux thèmes), les toasts et les confirmations nommées (C2),
la trame de composition, la grille de la bibliothèque.

**R5 — Stockage et sauvegardes** (D-236). L'entrée de « Plus » annonce
l'espace utilisé et la date de la dernière sauvegarde ; la carte d'espace est
bien **là** et non dans Apparence ; la ligne de persistance et son bouton
fonctionnent ; sauvegarder puis restaurer rend une bibliothèque identique.

**R6 — Réglages avancés et diagnostic** (D-234). La section existe pour
elle-même dans « Plus » ; le diagnostic exporté s'ouvre **sans mojibake** sur
le téléphone (c'est le défaut qui avait échappé au porteur lui-même), et son
contexte dit les sources, les sauvegardes, le maillage et les capacités.

**R6bis — Liens retirés par un pack** (D-243, nouveau). Dérouler REC-243-001
sur le pack Judo 0.6.1 → 0.7.0 : le rapport annonce les retraits, rien ne
disparaît tout seul, l'écran Relations laisse trancher, « Tout retirer » ramène
au maillage d'une installation neuve.

**R7 — Non-régressions du socle.** Une séance minutée complète (le chrono et
l'arrière-plan sont déjà validés en REC-S2-003 — vérifier seulement que rien
n'a bougé), une recherche, une création de technique, un export et un
réimport. **Ajout D-249** : dérouler REC-249-001 (annuler une édition de
fiche) — sur appareil, où l'écriture est la plus lente, c'est là que le défaut
corrigé se manifestait.

**Comment rendre le résultat** : point par point, `OK` ou ce qui a été vu.
Une capture vaut mieux qu'une description pour tout ce qui est visuel — c'est
ainsi qu'a été trouvé le défaut de D-231.

### REC-243-001 — Un pack qui retire des liens : proposé, jamais subi

**Objectif**

Mettre à jour un pack dont une nouvelle version a RETIRÉ des liens, et pouvoir
aligner sa bibliothèque sans perdre son propre travail.

**Préconditions**

- Le pack Judo **0.6.1** installé (315 liens), la version **0.7.0** disponible
  (67 liens) — ou tout pack dont deux versions diffèrent par leurs arêtes.

**Étapes**

1. Installer la version ancienne, vérifier le nombre de liens sur une fiche.
2. Tracer **soi-même** un lien entre deux techniques du pack, et un autre vers
   une technique personnelle.
3. Importer la nouvelle version, **lire le rapport d'import**.
4. Aller dans **Plus › Relations**, section « Liens que le pack ne déclare plus ».
5. Sur une entrée : **Garder**. Sur une autre : **Retirer**.
6. **Tout retirer** sur le reste du lot, puis lire la confirmation avant de valider.
7. Vérifier le maillage obtenu, puis restaurer le point de sauvegarde.

**Résultat attendu**

- Le rapport dit : « **N liens** que tu as ne sont plus déclarés par ce pack —
  **rien n'a été retiré** ». C'est la phrase qui manquait : le silence était le
  défaut (« j'ai mis à jour et rien n'a changé »).
- **Aucun lien n'a disparu** à ce stade. Le maillage est intact.
- La section liste les propositions, groupées par pack, avec le compte.
- **Garder** classe la proposition et ne touche pas à l'arête. **Retirer**
  supprime cette arête, et elle seule.
- Le lien tracé vers une technique **personnelle** n'apparaît JAMAIS dans la
  liste. Celui tracé entre deux techniques **du pack** y apparaît — c'est
  inévitable (une arête ne porte pas d'origine) et la confirmation le dit.
- « Tout retirer » prend un **point de restauration** avant d'agir, et le dit.
- Après retrait complet, le maillage est **identique à une installation neuve**
  de la nouvelle version.

**Risques de régression**

- Les désaccords de **raison** (D-157) restent arbitrés séparément, avec leurs
  trois choix — un retrait n'est pas un désaccord de contenu.
- Réimporter deux fois la même version ne duplique aucune proposition.
- Une proposition dont le pack redéclare l'arête disparaît d'elle-même.
- Un pack qui n'a jamais eu de liens (Jujitsu avant 0.2.0) n'en propose aucun.

**Preuves**

- Unit `tests/rapprochement.test.ts` — proposition détectée sans rien retirer,
  idempotence, proposition caduque nettoyée, lien vers ses propres techniques
  épargné, arbitrage « garder » / « retirer ».
- e2e `tests-navigateur/parcours/retraits-liens.mjs` — **par le circuit réel**
  (sélecteur de fichier, aperçu, rapport) : le rapport annonce le nombre, rien
  n'a bougé, l'écran laisse trancher à l'unité.
- Mesure sur le cas réel : Judo 0.6.1 → 0.7.0 = **255 retraits proposés**,
  0 retiré ; après « Tout retirer », **67 liens** — exactement l'installation
  neuve. Restent 30 désaccords de RAISON (le porteur a réécrit 30 notes sur des
  arêtes conservées), à arbitrer séparément : c'est le comportement D-157.

**Statut**

`AUTOMATISÉ` — recette appareil à faire au gel RC (ajoutée à REC-B4-001).

### REC-249-001 — Annuler une édition de fiche : l'écran dit la vérité

**Objectif**

Vérifier que la croix ✕ « Annuler l'édition » défait les modifications
**à l'écran** autant que dans les données (promesse D-105), y compris quand
l'appareil est lent.

**Préconditions**

- Une technique portant déjà un commentaire (« NOTE INITIALE » suffit).

**Étapes**

1. Ouvrir la fiche, lire le commentaire.
2. Passer en édition (✎ de la barre haute).
3. Modifier le commentaire, puis **quitter le champ** (le texte s'auto-enregistre).
4. Actionner **✕** sans attendre.
5. Lire le commentaire affiché.
6. Fermer l'app et la rouvrir, relire le commentaire.

**Résultat attendu**

- Après ✕, le champ affiche **la note d'origine** — jamais le texte abandonné.
- Le toast « Modifications annulées » et ce qui est affiché **disent la même
  chose** : c'est exactement ce qui divergeait (D-249).
- Après réouverture, la note persistée est celle d'avant l'édition.
- Le favori activé pendant l'édition est lui aussi défait (D-110).

**Ce qu'est ce champ (à savoir avant de le toucher, D-251)**

Ce n'est **pas** un champ de fiche comme le titre. C'est une **note
personnelle libre**, propre à l'utilisateur (`provenance: "personnel"`),
**auto-enregistrée à la perte de focus** — pas à la frappe — et **non
exportée** : elle ne quitte l'appareil que dans une sauvegarde complète
(`inclusions.contenuPersonnel` n'est vrai que pour `portee === "complet"` ;
`tests/non-divulgation.test.ts` épingle son absence des packs). Entre la
frappe et le blur, l'écran est donc **légitimement en avance** sur le
modèle, et aucun rendu ne doit reprendre la main sur ce champ — sauf la
croix ✕, qui est le seul geste demandant explicitement le contraire.

**Risques de régression**

- **Taper une note et laisser un rendu survenir** (un toast, une écriture qui
  se termine) : la frappe en cours doit rester intacte, curseur compris.
  C'est ce qu'un premier correctif de D-249 cassait.
- Le titre et le sous-titre de fiche : ils vivent dans la bascule
  lecture/édition, donc leur champ est recréé à chaque entrée — vérifier
  simplement qu'une annulation les rend intacts.
- Taper une note sur une fiche **sans** entrer en édition (note rapide, D-044)
  doit continuer de s'enregistrer normalement.

**Preuves**

- e2e `tests-navigateur/parcours/annulation-edition.mjs` — force le cas sans
  dépendre de la charge machine (le `change` puis ✕ dans la même tâche),
  vérifie l'écran, le modèle, l'écriture réellement posée sur le disque et
  l'état relu après rechargement. **Il couvre les deux moitiés du contrat** et
  rougit dans les deux sens (mesuré) : sans le `keyed`, l'annulation ne se
  voit pas à l'écran ; avec un `live()`, la note en cours de frappe est
  effacée par le premier rendu venu.
- Flux principal `parcours.mjs` — le même comportement par le chemin nominal
  (saisie réelle, blur, clic sur ✕).

**Statut**

`AUTOMATISÉ` — à repasser à la main dans REC-B4-001 (R7), sur appareil réel :
c'est là que la lenteur d'écriture est la plus probable.

### REC-255-001 — Un pack au champ facultatif mal formé est refusé, pas installé

**Objectif**

Vérifier qu'un `.movpack` dont un champ optionnel est mal formé est **refusé
à l'import avec un message**, au lieu d'être installé puis de casser
l'affichage d'une fiche.

**Préconditions**

- Un `.movpack` fabriqué à la main (l'outil d'emballage ne produit jamais
  ça) portant, sur une technique, `alertes: {}` ou `couverture: 42`.

**Étapes**

1. Importer le pack : lire le message de refus.
2. Vérifier qu'**aucune discipline n'a été créée** et qu'aucune technique
   n'est apparue.
3. Importer ensuite un pack officiel : il s'installe normalement.

**Résultat attendu**

- Le refus **nomme le champ fautif** (« alertes : un tableau est attendu »,
  « couverture : type inconnu »), jamais un message de moteur JS.
- **Rien n'a été écrit** : le refus intervient avant toute mutation.
- Les **six packs officiels restent installables** — c'est la contrepartie qui
  compte autant que le refus : un validateur qui refuse trop rendrait un pack
  publié impossible à installer.

**Risques de régression**

- Un pack légitime portant une alerte IJF complète, une couverture image ou
  une origine bien formée doit continuer de passer.
- Le pack **Yoga** est en schéma 3 : il doit être migré PUIS validé, dans cet
  ordre (c'est le lecteur qui s'en charge).

**Preuves**

- Unit `tests/validation-hostile.test.ts` — 6 cas : alertes, couverture,
  **inventaire des images** (D-269), origine, champs parcourus, et
  non-régression nominale. Chaque cas épingle aussi sa contrepartie légitime.
- Mesure sur le réel : les **six packs publiés** repassés par `lireMovpack`
  (migration comprise) → tous valides.
- Mesuré avant correctif, sur la même base : les six formes mal formées
  étaient **acceptées**, et `alertes.map` levait bien `is not a function`.

**Statut**

`AUTOMATISÉ` — à repasser à la main dans REC-B4-001 (R7) sur appareil.


## S4.2bis boucle B — les images sont des fichiers (schéma 6, D-269)

**Ce qui est couvert**

- Une bibliothèque en **schéma 5** (images en base64) migre à l'ouverture : les
  octets deviennent `images/<empreinte>`, l'état maigrit, et la **vignette
  reste affichée**. Une seconde ouverture ne rejoue rien.
- Une couverture posée par le **geste du produit** (`definirCouvertureImage`)
  écrit un fichier et inscrit l'image à l'inventaire dans la même persistance.
- Un **pack** apporte ses images en fichiers `images/<empreinte>` ; son
  inventaire rejoint le nôtre à l'import, par empreinte.
- Un conteneur **v4** (base64) reste importable : ses images sont détachées à
  la lecture et suivent exactement le même chemin d'écriture qu'un v5.
- La validation **refuse** une couverture qui désigne une image non déclarée —
  l'incohérence est arrêtée à l'écriture, pas découverte en vignette vide.

**Risques de régression**

- **Perdre une image encore utilisée** : le balayage des fichiers est séparé de
  l'épuration de l'inventaire, et la recherche des références est un parcours
  GÉNÉRIQUE — la corbeille (D-081) et les fusions réversibles (D-101) gardent
  des copies de couvertures, les oublier effacerait l'illustration d'une fiche
  encore restaurable.
- **Un export sans ses images** : les écrivains REFUSENT un conteneur dont
  l'inventaire déclare des images dont les octets n'ont pas été fournis.
- **Un rendu synchrone** : Lit ne peut pas attendre une lecture de fichier ;
  les URL d'affichage sont préparées avant que la bibliothèque soit publiée
  (`preparerImages`), au chargement comme après chaque persistance.

**Preuves**

- e2e `tests-navigateur/parcours/images-en-fichiers.mjs` — migration d'un état
  schéma 5 écrit à la main dans OPFS, sur le vrai chemin de chargement.
  **Mesuré dans les deux sens** : contre le build précédent, le chapitre échoue
  (`5 !== 6`).
- e2e `reimport-meme-pack` — un pack v2 fabriqué comme la chaîne de publication
  le fait (octets + inventaire + ligne au manifeste) met à jour la couverture,
  et son image rejoint l'inventaire local.
- Unit : `tests/validation-hostile.test.ts` (inventaire et renvois),
  `tests/migration-images-famille.test.ts` (la marche 4 → 5 testée seule).
- Mesure sur le réel : les **six packs publiés** migrés en schéma 6, réécrits
  en movpack v5, relus par `lireMovpack`, octets comparés un à un — identiques,
  aucune couverture orpheline. `bibliotheque.json` du karaté : 5025 → 153 Ko.
- `npm run campagne:charge` chiffre le coût qui motivait le chantier : 419 ms
  de sauvegarde sans images, 3802 ms avec 12 Mo.
