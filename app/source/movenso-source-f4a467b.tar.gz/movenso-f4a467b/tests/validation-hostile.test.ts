/**
 * D-255 — un pack tiers peut porter n'importe quoi dans un champ FACULTATIF.
 *
 * Ces champs n'étaient pas validés : `alertes: {}` passait `validerBibliotheque`
 * puis cassait l'affichage de la fiche sur `alertes.map`. Un état invalide
 * franchissait donc l'import pour planter plus tard, loin de sa cause.
 *
 * Chaque cas ci-dessous est ACCEPTÉ par le validateur d'avant le correctif.
 * La contrepartie est testée juste après : ce qui est légitime reste accepté —
 * une validation qui refuse trop est aussi grave qu'une validation qui laisse
 * passer, elle rendrait des packs publiés impossibles à installer.
 */

import test from "node:test";
import assert from "node:assert/strict";
import { validerBibliotheque, ErreurValidation } from "../src/domaine/validation.ts";
import { bibliotheque, disciplineJudo, technique, contribution } from "./aide.ts";
import { genererUlid } from "../src/domaine/ulid.ts";

/** Construit une bibliothèque d'une technique portant `patch`. */
function avecTechnique(patch: Record<string, unknown>) {
  const judo = disciplineJudo();
  const t = technique(judo.id, patch as never);
  return bibliotheque({ disciplines: [judo], techniques: [t], contributions: [] });
}

const refuse = (b: Parameters<typeof validerBibliotheque>[0], quoi: string) =>
  assert.throws(() => validerBibliotheque(b), ErreurValidation, `${quoi} doit être REFUSÉ`);

test("alertes : seul un tableau d'alertes complètes est accepté", () => {
  refuse(avecTechnique({ alertes: {} }), "alertes en objet");
  refuse(avecTechnique({ alertes: "interdit en compétition" }), "alertes en chaîne");
  refuse(avecTechnique({ alertes: [{}] }), "alerte sans type ni libellé");
  refuse(avecTechnique({ alertes: [{ type: "ijf", libelle: "Interdite" }] }), "alerte sans niveau");
  refuse(avecTechnique({ alertes: [{ type: "ijf", libelle: "Interdite", niveau: "critique" }] }), "niveau inconnu");
  refuse(avecTechnique({ alertes: [{ type: "ijf", libelle: "X", niveau: "danger", bloquante: "oui" }] }), "bloquante non booléenne");
  refuse(avecTechnique({ alertes: [{ type: "ijf", libelle: "X", niveau: "danger", reference: "IJF" }] }), "référence non objet");

  // Légitime : l'alerte complète des packs publiés.
  validerBibliotheque(avecTechnique({
    alertes: [{ type: "ijf", niveau: "danger", libelle: "Interdite en compétition IJF", detail: "Depuis 2010", bloquante: true, reference: { organisation: "IJF" } }],
  }));
});

test("couverture : image DÉCLARÉE à l'inventaire, ou média désigné par un ULID", () => {
  const EMPREINTE = "a".repeat(64);
  refuse(avecTechnique({ couverture: { type: "inconnu" } }), "type de couverture inconnu");
  refuse(avecTechnique({ couverture: 42 }), "couverture numérique");
  refuse(avecTechnique({ couverture: { type: "fichier" } }), "renvoi sans imageId");
  refuse(avecTechnique({ couverture: { type: "fichier", imageId: "pas-une-empreinte" } }), "imageId hors format");
  refuse(avecTechnique({ couverture: { type: "image", dataUrl: "data:image/jpeg;base64,/9j/" } }), "base64 inline : la forme du schéma 5 n'est plus acceptée");
  refuse(avecTechnique({ couverture: { type: "media", mediaId: "pas-un-ulid" } }), "média mal formé");

  // Le piège que la validation doit tenir (D-269) : une couverture qui désigne
  // une image que RIEN ne déclare. Elle ne s'affichera jamais, et personne ne
  // saurait dire pourquoi — on la refuse à l'écriture.
  refuse(avecTechnique({ couverture: { type: "fichier", imageId: EMPREINTE } }), "image non déclarée à l'inventaire");

  const declaree = avecTechnique({ couverture: { type: "fichier", imageId: EMPREINTE } });
  declaree.images = [{ id: EMPREINTE, mime: "image/jpeg", taille: 128 }];
  validerBibliotheque(declaree);
  validerBibliotheque(avecTechnique({ couverture: { type: "media", mediaId: genererUlid() } }));
});

test("inventaire des images : empreintes uniques, MIME d'image, taille réelle", () => {
  const EMPREINTE = "b".repeat(64);
  const avecInventaire = (images: unknown) => {
    const b = avecTechnique({});
    (b as { images?: unknown }).images = images;
    return b;
  };
  refuse(avecInventaire("pas un tableau"), "inventaire non tableau");
  refuse(avecInventaire([{ id: "court", mime: "image/jpeg", taille: 1 }]), "identité hors format");
  refuse(avecInventaire([{ id: EMPREINTE, mime: "video/webm", taille: 1 }]), "MIME qui n'est pas une image");
  refuse(avecInventaire([{ id: EMPREINTE, mime: "image/jpeg", taille: 0 }]), "taille nulle");
  refuse(
    avecInventaire([{ id: EMPREINTE, mime: "image/jpeg", taille: 1 }, { id: EMPREINTE, mime: "image/png", taille: 2 }]),
    "deux déclarations contradictoires des mêmes octets",
  );
  validerBibliotheque(avecInventaire([{ id: EMPREINTE, mime: "image/jpeg", taille: 4096 }]));
});

test("origine : un pack et un élément, sinon la source affichée est fausse", () => {
  refuse(avecTechnique({ origine: "pack-judo" }), "origine en chaîne");
  refuse(avecTechnique({ origine: {} }), "origine vide");
  refuse(avecTechnique({ origine: { pack: "pack-judo" } }), "origine sans element");
  refuse(avecTechnique({ origine: { pack: "", element: "x" } }), "pack vide");

  validerBibliotheque(avecTechnique({ origine: { pack: "pack-judo", element: "o-soto-gari" } }));
});

test("un champ qu'on parcourt est refusé proprement, jamais par une erreur technique", () => {
  // Avant D-255 : « t.relations is not iterable » — un message de moteur JS,
  // pas un refus. Le message doit désormais dire ce qui ne va pas.
  const b = avecTechnique({ relations: {} });
  assert.throws(() => validerBibliotheque(b), (e: Error) => {
    assert.ok(e instanceof ErreurValidation, "un refus, pas un TypeError");
    assert.match(e.message, /relations.*tableau/i, "le message nomme le champ fautif");
    return true;
  });

  refuse(avecTechnique({ niveauxIds: "gokyo-1" }), "niveaux en chaîne");
  const judo = disciplineJudo();
  const t = technique(judo.id);
  refuse(bibliotheque({ disciplines: [judo], techniques: [t], contributions: [contribution(t.id, { pointsCles: {} as never })] }), "points clés en objet");
  refuse(bibliotheque({ disciplines: [judo], techniques: {} as never, contributions: [] }), "collection de techniques en objet");
});

test("non-régression : une bibliothèque nominale reste valide", () => {
  validerBibliotheque(bibliotheque());
});
