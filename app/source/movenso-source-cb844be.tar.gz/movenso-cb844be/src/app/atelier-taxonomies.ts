/**
 * ATELIER — DISCIPLINES, TAXONOMIES, TYPES DE RELATION, TECHNIQUES, SOURCES
 * (S3.A3, tranche 2 — écrans extraits d'atelier.ts, code déménagé tel quel) :
 * carte de la discipline sélectionnée (renommage, suppression sécurisée avec
 * récap), catégories et niveaux (création, couleurs, suppression arbitrée),
 * types de relation (usages, symétrie), gestion des techniques, sources.
 */

import { html, nothing, type TemplateResult } from "lit";
import type { Discipline, Technique } from "../domaine/modele.ts";
import { boutonsMonterDescendre, type ReordreParGlisser } from "./glisser.ts";
import { vignetteTechnique } from "./vues.ts";
import { creationOuverte, etatGestion, tailleLisible } from "./atelier-commun.ts";
import { compositionsUtilisant } from "../domaine/composition.ts";
import { nomEditorialSource } from "./vues.ts";
import type { MovensoApp } from "./racine.ts";

/** Taxonomie dont la suppression attend un arbitrage (clé `dId:quoi:id`). */
let taxonomieASupprimer: string | null = null;

/** Type de relation dont on a déplié la liste des instances (D-080). */
let typeDeplie: string | null = null;

/** Une INSTANCE d'un type de lien : source → cible, résolue dans la
 *  bibliothèque vivante. Les cibles absentes (fiche en corbeille ou disparue)
 *  ne sont pas listées — le lien reste stocké mais masqué (D-081). */
interface InstanceRelation {
  sourceId: string;
  sourceNom: string;
  cibleId: string;
  cibleNom: string;
}

/** Créer une discipline — la construction vit à l'Atelier (D-024), l'accueil
 *  ne la propose qu'à la toute première installation (D-017).
 *  Le champ se VIDE après création (constat terrain : doublon au double-appui). */
export function sectionCreerDiscipline(app: MovensoApp): TemplateResult {
  // Créer referme le petit formulaire (tuning post-V3) et sélectionne la
  // nouvelle discipline.
  const creer = async (champ: HTMLInputElement) => {
    const nom = champ.value;
    champ.value = "";
    const id = await app.creerDiscipline(nom);
    creationOuverte.delete("discipline");
    if (id) app.disciplineGestion = id;
    app.requestUpdate();
  };
  return html`
    <div class="creation-discipline" style="margin:6px 0 2px">
      <input placeholder="Nom de la discipline…" autofocus aria-label="Nom de la discipline"
             @keydown=${(e: KeyboardEvent) => { if (e.key === "Enter") void creer(e.target as HTMLInputElement); }}>
      <button class="bouton principal"
        @click=${(e: Event) => void creer((e.target as HTMLElement).parentElement!.querySelector("input")!)}>Créer</button>
    </div>
  `;
}

/** Disciplines dont la suppression sécurisée est en préparation (§7). */
const suppressionsEnPreparation = new Set<string>();

/** Le ＋ rouge des volets Catégories/Niveaux (uniformité D-308) — même geste
 *  que celui des Disciplines : ouvre le volet ET le petit formulaire de
 *  création, sans laisser le <summary> avaler le clic. */
function boutonPlusVolet(app: MovensoApp, cle: string, quoi: string): TemplateResult {
  const ouvert = creationOuverte.has(cle);
  return html`<button class="bouton-plus ${ouvert ? "actif" : ""}" aria-label=${ouvert ? `Fermer — ${quoi}` : quoi} aria-expanded=${ouvert}
    @click=${(e: Event) => {
      e.preventDefault();
      e.stopPropagation();
      const volet = (e.target as HTMLElement).closest("details");
      if (volet && !ouvert) volet.open = true;
      ouvert ? creationOuverte.delete(cle) : creationOuverte.add(cle);
      app.requestUpdate();
    }}>${ouvert ? "−" : "＋"}</button>`;
}

/** Suppression d'une discipline via la ✕ de sa ligne (uniformité D-308) : le
 *  récapitulatif — techniques, vidéos, notes, compositions — s'affiche avant
 *  tout geste destructif ; une discipline vide passe par la confirmation. */
export function demanderSuppressionDiscipline(app: MovensoApp, d: Discipline): void {
  const nb = app.bibliotheque!.techniques.filter((t) => t.disciplineId === d.id).length;
  if (nb === 0) {
    app.autoriser("destruction_ou_sensible", `Saisis le PIN pour retirer « ${d.nom} ».`, () => {
      app.demanderConfirmation({
        titre: `Supprimer la discipline vide « ${d.nom} » ?`,
        corps: "Un point de restauration sera conservé.",
        bouton: "Supprimer la discipline",
        action: () => { void app.supprimerDiscipline(d.id); },
      });
    });
  } else {
    app.disciplineGestion = d.id; // le récapitulatif s'affiche sous SA carte
    suppressionsEnPreparation.add(d.id);
    app.requestUpdate();
  }
}

/** Récapitulatif de suppression d'une discipline, s'il est en préparation
 *  (D-309) — rendu sous la ligne de la discipline, l'encart dédié a disparu :
 *  le nom s'édite EN LIGNE comme celui d'une catégorie ou d'un niveau. */
export function panneauSuppressionDiscipline(app: MovensoApp, d: Discipline): TemplateResult | typeof nothing {
  if (!suppressionsEnPreparation.has(d.id)) return nothing;
  const techniques = app.bibliotheque!.techniques.filter((t) => t.disciplineId === d.id);
  return recapSuppression(app, d, techniques, new Set(techniques.map((t) => t.id)));
}

/** Section Catégories (familles) de la discipline sélectionnée — encart à titre,
 *  bouton ＋ pour créer, réordonnancement au glisser. */
export function sectionCategories(app: MovensoApp, d: Discipline): TemplateResult {
  const cle = `${d.id}:familles`;
  const opts: ReordreParGlisser = {
    reordonner: (id, cible) => app.deplacerTaxonomieVers(d.id, "familles", id, cible),
    enregistrer: () => void app.enregistrerReordre(),
    ordre: () => d.familles.map((x) => x.id),
    nom: (id) => d.familles.find((x) => x.id === id)?.nom ?? "la catégorie",
  };
  const creer = (champ: HTMLInputElement) => { void app.ajouterTaxonomie(d.id, "familles", champ.value); champ.value = ""; creationOuverte.delete(cle); app.requestUpdate(); };
  return html`
    <details class="carte-atelier sous-volet">
      <summary class="encart-entete"><span class="titre-atelier">Catégories <span class="carnet-compte">${d.familles.length}</span></span>
        ${boutonPlusVolet(app, cle, "Ajouter une catégorie")}</summary>
      <div style="padding-top:8px">
      ${creationOuverte.has(cle)
        ? html`<div class="ligne-atelier">
            <input class="champ-mini" placeholder="Nom de la catégorie" autofocus aria-label="Nouvelle catégorie"
                   @keydown=${(e: KeyboardEvent) => { if (e.key === "Enter") creer(e.target as HTMLInputElement); }}>
            <button class="bouton" style="flex:none"
              @click=${(e: Event) => creer((e.target as HTMLElement).parentElement!.querySelector("input")!)}>Ajouter</button>
          </div>`
        : nothing}
      ${d.familles.map((f) => html`
        <div class="ligne-atelier">
          ${boutonsMonterDescendre(app, f.id, opts)}
          <input class="champ-mini" .value=${f.nom} aria-label="Nom de la catégorie"
                 @change=${(e: Event) => void app.majTaxonomie(d.id, "familles", f.id, { nom: (e.target as HTMLInputElement).value })}>
          ${outilsTaxonomie(app, d, "familles", f.id, f.nom, "la catégorie")}
        </div>
        ${panneauSuppressionTaxonomie(app, d, "familles", f.id, f.nom)}`)}
      ${d.familles.length === 0 && !creationOuverte.has(cle) ? html`<p class="fil-vide" style="padding:6px 2px 0">Aucune catégorie — touche ＋.</p>` : nothing}
      </div>
    </details>
  `;
}

/** Section Niveaux — encart à titre, ＋ pour créer, glisser pour réordonner.
 *  La couleur se choisit sur un aperçu splitté (deux teintes), la seconde
 *  couleur s'active à la sélection. */
export function sectionNiveaux(app: MovensoApp, d: Discipline): TemplateResult {
  const cle = `${d.id}:niveaux`;
  const opts: ReordreParGlisser = {
    reordonner: (id, cible) => app.deplacerTaxonomieVers(d.id, "niveaux", id, cible),
    enregistrer: () => void app.enregistrerReordre(),
    ordre: () => d.niveaux.map((x) => x.id),
    nom: (id) => d.niveaux.find((x) => x.id === id)?.nom ?? "le niveau",
  };
  const creer = (champ: HTMLInputElement) => { void app.ajouterTaxonomie(d.id, "niveaux", champ.value); champ.value = ""; creationOuverte.delete(cle); app.requestUpdate(); };
  return html`
    <details class="carte-atelier sous-volet">
      <summary class="encart-entete"><span class="titre-atelier">Niveaux <span class="carnet-compte">${d.niveaux.length}</span></span>
        ${boutonPlusVolet(app, cle, "Ajouter un niveau")}</summary>
      <div style="padding-top:8px">
      ${creationOuverte.has(cle)
        ? html`<div class="ligne-atelier">
            <input class="champ-mini" placeholder="Nom du niveau" autofocus aria-label="Nouveau niveau"
                   @keydown=${(e: KeyboardEvent) => { if (e.key === "Enter") creer(e.target as HTMLInputElement); }}>
            <button class="bouton" style="flex:none"
              @click=${(e: Event) => creer((e.target as HTMLElement).parentElement!.querySelector("input")!)}>Ajouter</button>
          </div>`
        : nothing}
      ${d.niveaux.length ? html`<p class="fil-vide" style="padding:0 2px 4px">Un niveau porte une ou deux couleurs (ceintures bicolores) — le carré ＋ ajoute la seconde.</p>` : nothing}
      ${d.niveaux.map((n) => html`
        <div class="ligne-atelier">
          ${boutonsMonterDescendre(app, n.id, opts)}
          <input class="champ-mini" .value=${n.nom} aria-label="Nom du niveau"
                 @change=${(e: Event) => void app.majTaxonomie(d.id, "niveaux", n.id, { nom: (e.target as HTMLInputElement).value })}>
          ${couleurNiveau(app, d, n)}
          ${outilsTaxonomie(app, d, "niveaux", n.id, n.nom, "le niveau")}
        </div>
        ${panneauSuppressionTaxonomie(app, d, "niveaux", n.id, n.nom)}`)}
      ${d.niveaux.length === 0 && !creationOuverte.has(cle) ? html`<p class="fil-vide" style="padding:6px 2px 0">Aucun niveau — touche ＋.</p>` : nothing}
      </div>
    </details>
  `;
}

/** Niveaux dont la seconde couleur est en cours d'édition (révélée sur sélection). */
const secondeCouleurOuverte = new Set<string>();

/** Éditeur de couleur d'un niveau (D-309) : deux emplacements de MÊME forme —
 *  la couleur, et la seconde (ceinture bicolore) qui naît d'un carré ＋ en
 *  pointillé. L'ancien aperçu splitté faisait un troisième carré d'une autre
 *  tête, et rien ne disait qu'une seconde couleur existait. */
function couleurNiveau(app: MovensoApp, d: Discipline, n: { id: string; couleur?: string; couleur2?: string }): TemplateResult {
  const bicolore = secondeCouleurOuverte.has(n.id) || n.couleur2 !== undefined;
  return html`<span class="couleur-niveau">
    <input type="color" class="pastille-couleur" .value=${n.couleur ?? "#cccccc"} title="Couleur du niveau"
           @change=${(e: Event) => void app.majTaxonomie(d.id, "niveaux", n.id, { couleur: (e.target as HTMLInputElement).value })}>
    ${bicolore
      ? html`<input type="color" class="pastille-couleur" .value=${n.couleur2 ?? n.couleur ?? "#cccccc"} title="Seconde couleur (ceinture bicolore)"
               @change=${(e: Event) => void app.majTaxonomie(d.id, "niveaux", n.id, { couleur2: (e.target as HTMLInputElement).value })}>`
      : html`<button class="pastille-couleur pastille-ajout" aria-label="Ajouter une seconde couleur (ceinture bicolore)" title="Ajouter une seconde couleur (ceinture bicolore)"
               @click=${() => { secondeCouleurOuverte.add(n.id); app.requestUpdate(); }}>＋</button>`}
  </span>`;
}

/** Suppression sécurisée d'une discipline NON vide (§7) : jamais en un clic —
 *  le contenu concerné est présenté, la sauvegarde préalable proposée, et la
 *  confirmation renforcée nomme ce qui part. */
function recapSuppression(app: MovensoApp, d: Discipline, techniques: { id: string }[], idsD: Set<string>): TemplateResult {
  const b = app.bibliotheque!;
  const contribs = b.contributions.filter((c) => c.techniqueId && idsD.has(c.techniqueId));
  const perso = contribs.filter((c) => c.provenance === "personnel").length;
  const videos = contribs.flatMap((c) => c.medias).filter((m) => m.type === "local").length;
  const compos = b.compositions.filter((c) => c.blocs.some((x) => x.type === "technique" && x.techniqueId && idsD.has(x.techniqueId)));
  const fermer = () => {
    suppressionsEnPreparation.delete(d.id);
    app.requestUpdate();
  };
  return html`<div class="suppression-discipline">
    <p class="details" style="line-height:1.5">
      Supprimer « ${d.nom} » retirera <b>${techniques.length} technique${techniques.length > 1 ? "s" : ""}</b>
      (${videos ? `${videos} vidéo${videos > 1 ? "s" : ""} locale${videos > 1 ? "s" : ""}` : "aucune vidéo locale"}).
      ${perso
        ? html`${perso > 1 ? `Tes ${perso} notes personnelles reviendront` : "Ta note personnelle reviendra"}
            « à rattacher » — rien de personnel n'est perdu.`
        : nothing}
      ${compos.length
        ? `Compositions concernées : ${compos.map((c) => c.nom).join(", ")} — leurs blocs resteront lisibles « à retrouver ».`
        : "Aucune composition concernée."}
      Un point de restauration est créé d'abord.
    </p>
    <div class="chips-filtres" style="flex-wrap:wrap; padding:4px 0 0">
      <button class="chip-filtre" @click=${fermer}>Annuler</button>
      <button class="chip-filtre" title="Sauvegarde complète avant de supprimer"
        @click=${() => void app.exporterTout(true)}>Exporter tout d'abord (.movpack)</button>
      <button class="action-danger" style="padding:6px 10px; font-size:12px"
        @click=${() =>
          app.autoriser("destruction_ou_sensible", `Saisis le PIN pour supprimer « ${d.nom} » et son contenu.`, () => {
            app.demanderConfirmation({
              titre: `Supprimer définitivement « ${d.nom} » et ses ${techniques.length} technique${techniques.length > 1 ? "s" : ""} ?`,
              corps: "Un point de restauration sera créé juste avant.",
              bouton: "Supprimer la discipline et son contenu",
              action: () => { fermer(); void app.supprimerDisciplineEtContenu(d.id); },
            });
          })}>Supprimer la discipline et son contenu</button>
    </div>
  </div>`;
}

/** Bouton ✕ d'une ligne de taxonomie (lot 6 §8) : la suppression d'une valeur
 *  UTILISÉE ouvre l'arbitrage au lieu d'un simple confirm. Le réordonnancement
 *  se fait désormais au glisser (poignée), plus par des flèches. */
function outilsTaxonomie(
  app: MovensoApp,
  d: Discipline,
  quoi: "familles" | "niveaux",
  id: string,
  nom: string,
  quoiLisible: string,
): TemplateResult {
  return html`
    <button class="bouton-icone" aria-label="Retirer ${quoiLisible}"
      @click=${() => {
        if (app.usagesTaxonomie(d.id, quoi, id).length) {
          taxonomieASupprimer = `${d.id}:${quoi}:${id}`;
          app.requestUpdate();
        } else {
          app.demanderConfirmation({
            titre: `Retirer ${quoiLisible} « ${nom} » ?`,
            corps: `Inutilisé${quoi === "familles" ? "e" : ""} — aucune fiche n'y fait référence.`,
            bouton: "Retirer",
            action: () => { void app.supprimerTaxonomie(d.id, quoi, id); },
          });
        }
      }}>✕</button>
  `;
}

/** Arbitrage avant suppression d'une taxonomie utilisée (§8) : usages
 *  visibles, puis remplacer par une autre valeur / retirer la
 *  classification / annuler — jamais de référence invalide. */
function panneauSuppressionTaxonomie(
  app: MovensoApp,
  d: Discipline,
  quoi: "familles" | "niveaux",
  id: string,
  nom: string,
): TemplateResult {
  if (taxonomieASupprimer !== `${d.id}:${quoi}:${id}`) return html``;
  const usages = app.usagesTaxonomie(d.id, quoi, id);
  const autres = d[quoi].filter((x) => x.id !== id);
  const fermer = () => {
    taxonomieASupprimer = null;
    app.requestUpdate();
  };
  return html`<div class="suppression-discipline suppression-taxonomie">
    <p class="details" style="line-height:1.5">
      « ${nom} » est utilisée par <b>${usages.length} technique${usages.length > 1 ? "s" : ""}</b> :
    </p>
    <div class="chips-filtres" style="flex-wrap:wrap; padding:2px 0 0">
      ${usages.slice(0, 8).map((t) => html`<button class="chip-filtre" @click=${() => app.ouvrirFiche(t.id)}>${t.nom}</button>`)}
      ${usages.length > 8 ? html`<span class="chip-filtre" style="cursor:default">… ${usages.length - 8} de plus</span>` : nothing}
    </div>
    <div class="chips-filtres" style="flex-wrap:wrap; padding:6px 0 0">
      <button class="chip-filtre" @click=${fermer}>Annuler</button>
      ${autres.map(
        (x) => html`<button class="chip-filtre" @click=${() => { fermer(); void app.supprimerTaxonomie(d.id, quoi, id, x.id); }}>
          Remplacer par « ${x.nom} »</button>`,
      )}
      <button class="action-danger" style="padding:6px 10px; font-size:12px"
        @click=${() => { fermer(); void app.supprimerTaxonomie(d.id, quoi, id, null); }}>
        Retirer la classification</button>
    </div>
  </div>`;
}

export function sectionTypesRelation(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  return html`
    <div class="carte-atelier">
      <div class="ligne-atelier"><span class="titre-atelier" style="font-size:14px">Liens entre techniques</span></div>
      <details class="sous-volet">
        <summary class="details" style="cursor:pointer">Comment ça marche ?</summary>
        <p class="fil-vide" style="padding:6px 0 0">
          Un lien se lit dans les deux sens : « Ko-uchi-gari <b>prépare</b>
          O-soto-gari » s'affiche aussi « O-soto-gari <b>préparée par</b>
          Ko-uchi-gari ». C'est ce libellé inverse qu'on te demande — laisse-le
          vide si le lien se lit pareil des deux côtés (« similaire à »).
        </p>
      </details>
      ${b.typesRelation.map((t) => (typeEnEdition === t.id ? ligneEditionTypeRelation(app, t) : ligneTypeRelation(app, t)))}
      <div class="ligne-atelier">
        <input class="champ-mini" placeholder="Nouveau lien…" aria-label="Libellé du type">
        <input class="champ-mini" placeholder="Lecture inverse…" aria-label="Libellé inverse">
        <button class="bouton principal" style="flex:none"
          @click=${(e: Event) => {
            const champs = (e.target as HTMLElement).parentElement!.querySelectorAll("input");
            void app.ajouterTypeRelation(champs[0]!.value, champs[1]!.value);
            champs.forEach((c) => (c.value = ""));
          }}>Ajouter</button>
      </div>
    </div>
  `;
}

/** Type de relation en cours d'édition (lot 6 §10). */
let typeEnEdition: string | null = null;

function instancesDuType(app: MovensoApp, typeId: string, symetrique: boolean): InstanceRelation[] {
  const b = app.bibliotheque!;
  const noms = new Map(b.techniques.map((t) => [t.id, t.nom]));
  const out: InstanceRelation[] = [];
  const vues = new Set<string>();
  for (const t of b.techniques)
    for (const r of t.relations) {
      if (r.type !== typeId) continue;
      const cibleNom = noms.get(r.cibleId);
      if (cibleNom === undefined) continue; // cible absente : masquée, jamais listée
      // Symétrique : dédoublonne la paire non ordonnée (A⇄B == B⇄A).
      const cle = symetrique ? [t.id, r.cibleId].sort().join("|") : `${t.id}|${r.cibleId}`;
      if (vues.has(cle)) continue;
      vues.add(cle);
      out.push({ sourceId: t.id, sourceNom: noms.get(t.id) ?? "?", cibleId: r.cibleId, cibleNom });
    }
  return out.sort((a, z) => a.sourceNom.localeCompare(z.sourceNom));
}

/** Liste dépliée des instances d'un type — chaque lien cliquable (ouvre la
 *  fiche source), ✎ pour éditer raison/priorité (feuille « Lien », D-156) et
 *  ✕ pour retirer CE lien précis (D-080). « ＋ Ajouter un lien de ce type »
 *  ouvre la feuille en création, type présélectionné, source à choisir. */
function listeInstancesType(app: MovensoApp, t: { id: string; libelle: string; symetrique?: boolean }): TemplateResult {
  const instances = instancesDuType(app, t.id, t.symetrique ?? false);
  const fleche = t.symetrique ? "⇄" : "→";
  const ajouter = html`<button class="chip-filtre" style="margin:4px 12px 8px"
    @click=${() => app.ouvrirEditionLien(null, undefined, undefined, t.id)}>＋ Ajouter un lien de ce type</button>`;
  if (instances.length === 0)
    return html`<p class="fil-vide" style="padding:4px 12px 2px">Aucun lien de ce type pour l'instant.</p>${ajouter}`;
  return html`<div class="instances-relation">
    ${instances.map(
      (i) => html`<div class="ligne-instance">
        <button class="lien-instance" @click=${() => app.ouvrirFiche(i.sourceId)}
          title="Ouvrir « ${i.sourceNom} »">${i.sourceNom} <span class="fleche-instance">${fleche}</span> ${i.cibleNom}</button>
        <button class="bouton-icone" aria-label=${`Modifier le lien ${i.sourceNom} ${fleche} ${i.cibleNom}`} title="Raison, priorité…"
          @click=${() => app.ouvrirEditionLien(i.sourceId, i.cibleId, t.id)}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
        </button>
        <button class="bouton-icone danger" aria-label=${`Retirer le lien ${i.sourceNom} ${fleche} ${i.cibleNom}`} title="Retirer ce lien"
          @click=${() => app.demanderConfirmation({
            titre: `Retirer le lien « ${i.sourceNom} ${fleche} ${i.cibleNom} » ?`,
            bouton: "Retirer le lien",
            action: () => { void app.retirerRelation(i.sourceId, i.cibleId, t.id); },
          })}>✕</button>
      </div>`,
    )}
  </div>${ajouter}`;
}

/** Une ligne de type : libellés, symétrie, usages, origine — jamais l'id interne
 *  (§10). Cliquable : déplie la liste de ses instances éditables (D-080). */
function ligneTypeRelation(app: MovensoApp, t: { id: string; libelle: string; libelleInverse?: string; symetrique?: boolean; origine?: { pack: string } }): TemplateResult {
  const usages = app.usagesTypeRelation(t.id);
  const ouvert = typeDeplie === t.id;
  // D-388/§18 : « Fourni par un pack » (générique) — un pack s'identifie par un ULID (D-320), un type n'a pas d'attribution lisible d'où tirer un nom.
  const dePack = t.origine ? " Ce type provient d'un pack partagé." : "";
  return html`<div class="type-relation-bloc">
    <div class="ligne-atelier">
      <button class="details lien-type" style="flex:1;text-align:left" aria-expanded=${ouvert}
        @click=${() => { typeDeplie = ouvert ? null : t.id; app.requestUpdate(); }}>
        <span class="chevron-type" aria-hidden="true">${ouvert ? "▾" : "▸"}</span>
        ${t.libelle}${t.symetrique ? " ⇄" : ` → ${t.libelleInverse}`}
        ${usages ? html`<span class="kpi-nombre" style="font-size:10px">${usages}</span>` : nothing}
        ${t.origine ? html`<span style="opacity:.7"> · Fourni par un pack</span>` : nothing}
      </button>
      <button class="bouton-icone" aria-label="Modifier ce lien" title="Renommer / lecture inverse"
        @click=${() => { typeEnEdition = t.id; app.requestUpdate(); }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
      </button>
      <button class="bouton-icone" aria-label="Supprimer ce lien"
        @click=${() => {
          // D-388/§17 : jamais de suppression SILENCIEUSE. Un type UTILISÉ ne se
          // retire pas — DIALOGUE nommant le nombre (danger:false, pas un toast), PACK rappelé.
          if (usages) app.demanderConfirmation({ titre: `« ${t.libelle} » est utilisé`, bouton: "Compris", danger: false, action: () => {},
            corps: `${usages} relation${usages > 1 ? "s" : ""} l'utilise${usages > 1 ? "nt" : ""} — enlève d'abord ces liens des fiches concernées.${dePack}` });
          else app.demanderConfirmation({ titre: `Retirer le lien « ${t.libelle} » ?`, bouton: "Retirer le type",
            corps: `Inutilisé — aucune relation ne s'en sert.${dePack}`, action: () => { void app.supprimerTypeRelation(t.id); } });
        }}>✕</button>
    </div>
    ${ouvert ? listeInstancesType(app, t) : nothing}
  </div>`;
}

function ligneEditionTypeRelation(app: MovensoApp, t: { id: string; libelle: string; libelleInverse?: string; symetrique?: boolean }): TemplateResult {
  const usages = app.usagesTypeRelation(t.id);
  return html`<div class="ligne-atelier edition-type-relation" style="flex-wrap:wrap">
    <input class="champ-mini" .value=${t.libelle} aria-label="Libellé du lien">
    ${t.symetrique
      ? html`<span class="details">⇄ se lit pareil des deux sens</span>`
      : html`<input class="champ-mini" .value=${t.libelleInverse ?? ""} aria-label="Lecture inverse">`}
    <button class="chip-filtre" title=${usages ? "des relations utilisent déjà cette lecture" : "basculer la nature de lecture"}
      @click=${() => void app.basculerSymetrieTypeRelation(t.id)}>${t.symetrique ? "Rendre orienté" : "Rendre symétrique ⇄"}</button>
    <button class="bouton principal" style="flex:none; padding:7px 12px; font-size:12.5px"
      @click=${(e: Event) => {
        const champs = (e.target as HTMLElement).parentElement!.querySelectorAll("input");
        typeEnEdition = null;
        void app.majTypeRelation(t.id, {
          libelle: champs[0]!.value,
          ...(t.symetrique ? {} : { libelleInverse: champs[1]?.value ?? "" }),
        });
      }}>OK</button>
  </div>`;
}

/** Retrait d'une technique (tuning post-V3 : déplacé de la fiche vers Plus) —
 *  PIN d'abord, mise en CORBEILLE réversible ENSUITE (D-081). Rien n'est détruit :
 *  la fiche, ses notes et ses liens sont restaurables tant que la corbeille n'est
 *  pas vidée. */
function retirerTechnique(app: MovensoApp, t: Technique): void {
  app.autoriser("destruction_ou_sensible", `Saisis le PIN pour retirer « ${t.nom} ».`, () => {
    const utilisatrices = compositionsUtilisant(app.bibliotheque!, t.id);
    const dependances = utilisatrices.length
      ? `\nUtilisée dans ${utilisatrices.length} composition${utilisatrices.length > 1 ? "s" : ""} (${utilisatrices.map((c) => c.nom).join(", ")}).`
      : "";
    app.demanderConfirmation({
      titre: `Mettre « ${t.nom} » à la corbeille ?`,
      corps: `${dependances ? dependances.trim() + "\n" : ""}Geste réversible : tu pourras la restaurer depuis Plus › Corbeille.`,
      bouton: "Mettre à la corbeille",
      action: () => { void app.supprimerTechnique(t.id); },
    });
  });
}

/** Section Techniques (tuning post-V3 : entrée de menu à part entière) : filtre
 *  par discipline, recherche, filtres À compléter / Problèmes, liste navigable ;
 *  ouvre la fiche ou retire une technique. */
export function sectionTechniques(app: MovensoApp, disciplineId: string | null): TemplateResult {
  const b = app.bibliotheque!;
  if (disciplineId && !b.disciplines.some((d) => d.id === disciplineId)) disciplineId = null;
  const idsTous = new Set(b.techniques.map((t) => t.id));
  const contribuees = new Set(b.contributions.filter((c) => c.techniqueId).map((c) => c.techniqueId!));
  const avecMedia = new Set(b.contributions.filter((c) => c.techniqueId && c.medias.length).map((c) => c.techniqueId!));
  const videoManquante = new Set(app.mediasManquants.filter((m) => m.techniqueId).map((m) => m.techniqueId!));
  const nomDiscipline = (id: string) => b.disciplines.find((d) => d.id === id)?.nom ?? "";
  const nomFamille = (t: (typeof b.techniques)[number]) =>
    t.familleId ? b.disciplines.find((d) => d.id === t.disciplineId)?.familles.find((f) => f.id === t.familleId)?.nom ?? "" : "";
  const etiquettes = (t: (typeof b.techniques)[number]): string[] => {
    const e: string[] = [];
    if (!t.familleId && t.niveauxIds.length === 0) e.push("sans classification");
    if (!contribuees.has(t.id)) e.push("sans contenu");
    else if (!avecMedia.has(t.id)) e.push("sans média");
    if (t.relations.some((r) => !idsTous.has(r.cibleId))) e.push("relation à réparer");
    if (videoManquante.has(t.id)) e.push("vidéo manquante");
    return e;
  };
  const requete = etatGestion.requete.trim().toLowerCase();
  const correspond = (t: (typeof b.techniques)[number]) => {
    if (disciplineId && t.disciplineId !== disciplineId) return false;
    if (requete && !`${t.nom} ${t.nomTraditionnel ?? ""}`.toLowerCase().includes(requete)) return false;
    return true;
  };
  const resultats = b.techniques
    .filter(correspond)
    .sort((a, z) => a.nom.localeCompare(z.nom, "fr", { sensitivity: "base" }));
  return html`
    <div class="carte-atelier" style="margin-top:10px">
      ${b.disciplines.length > 1
        ? html`<div class="chips-filtres" style="padding:0 0 4px" aria-label="Filtrer par discipline">
            <button class="chip-filtre ${!disciplineId ? "actif" : ""}"
              @click=${() => { etatGestion.disciplineId = null; app.requestUpdate(); }}>Toutes</button>
            ${b.disciplines.map(
              (d) => html`<button class="chip-filtre ${disciplineId === d.id ? "actif" : ""}"
                @click=${() => { etatGestion.disciplineId = d.id; app.requestUpdate(); }}>${d.nom}</button>`,
            )}
          </div>`
        : nothing}
      <div class="recherche" style="margin:0">
        <input placeholder="Chercher une technique…" aria-label="Chercher une technique" .value=${etatGestion.requete}
               @input=${(e: InputEvent) => { etatGestion.requete = (e.target as HTMLInputElement).value; app.requestUpdate(); }}>
      </div>
      ${resultats.map((t) => {
        const fam = nomFamille(t);
        return html`<div class="ligne-gestion ligne-gestion-double">
          <button class="ligne-gestion-ouvrir" @click=${() => app.ouvrirFiche(t.id)}>
            <span class="ligne-gestion-nom">${t.nom}</span>
            <span class="details">${nomDiscipline(t.disciplineId)}${fam ? ` · ${fam}` : ""}</span>
            ${etiquettes(t).length
              ? html`<span class="etiquettes-gestion">${etiquettes(t).map((e) => html`<span class="etiquette-gestion">${e}</span>`)}</span>`
              : nothing}
          </button>
          <button class="bouton-icone danger supprimer-technique" aria-label=${`Retirer ${t.nom}`} title="Retirer cette technique"
            @click=${() => retirerTechnique(app, t)}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/></svg>
          </button>
        </div>`;
      })}
      ${resultats.length === 0 ? html`<p class="fil-vide" style="padding:8px 0 0">Rien ne correspond.</p>` : nothing}
    </div>
  `;
}

function sectionSources(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const packs = new Map<string, { techniques: number; exemple?: (typeof b.contributions)[number] }>();
  const entree = (pack: string) => {
    let e = packs.get(pack);
    if (!e) packs.set(pack, (e = { techniques: 0 }));
    return e;
  };
  let localTechniques = 0;
  for (const t of b.techniques) t.origine ? entree(t.origine.pack).techniques++ : localTechniques++;
  for (const c of b.contributions) if (c.origine) { const e = entree(c.origine.pack); if (!e.exemple) e.exemple = c; }
  const pseudo = (app.preferences.pseudo ?? "").trim();
  return html`
    <div class="carte-atelier">
      <details class="sous-volet">
        <summary class="details" style="cursor:pointer">Sources (${packs.size + 1})</summary>
        ${[...packs.entries()].map(([pack, e]) => {
          const nom = e.exemple ? nomEditorialSource(e.exemple) : pack;
          return html`<div class="ligne-atelier">
            <span class="details" style="flex:1"><b style="color:var(--encre)">${nom}</b> · ${e.techniques} technique${e.techniques > 1 ? "s" : ""}</span>
          </div>`;
        })}
        <div class="ligne-atelier">
          <span class="details" style="flex:1"><b style="color:var(--encre)">${pseudo || "Mon contenu"}</b> · ${localTechniques} technique${localTechniques > 1 ? "s" : ""}</span>
        </div>
        <div class="etiquette" style="padding:10px 2px 2px">Ton pseudo</div>
        <div class="aide">Il signe ce que tu crées sur cet appareil — affiché sur tes fiches à la place de « Mon contenu ». Il reste local, jamais partagé.</div>
        <div class="ligne-atelier" style="margin-top:4px">
          <input class="champ-mini" placeholder="Ex. Yahya, Sensei Dupont…" .value=${pseudo}
                 aria-label="Ton pseudo"
                 @change=${(e: Event) => app.changerPseudo((e.target as HTMLInputElement).value)}>
        </div>
      </details>
    </div>
  `;
}
