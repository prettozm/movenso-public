/**
 * FEUILLE DES FILTRES de la Bibliothèque (extraite de vues.ts, D-380). Les
 * rangées de puces (catégories, niveaux) qui encombraient l'écran, allées
 * chercher dans une feuille qui se ferme sur « Voir N techniques », jamais un
 * « OK » muet.
 *
 * D-380 : quand « Toutes » les disciplines sont montrées, les taxonomies se
 * GROUPENT par discipline (constat porteur) — sinon les vocabulaires de trois
 * disciplines se mélangent dans un même sac, et ça empire à chaque discipline
 * ajoutée. Une seule discipline en vue = liste à plat, sans sous-titre inutile.
 */
import { html, nothing, type TemplateResult } from "lit";
import type { Famille, Niveau } from "../domaine/modele.ts";
import type { MovensoApp } from "./racine.ts";
import { pastilleNiveau } from "./vignette.ts";

/** Clé de regroupement d'un niveau par NOM (D-127) : « 1 dan » venu de packs
 *  différents (donc des id distincts) = UN seul filtre, pas trois. */
export function cleNiveau(n: { nom: string }): string {
  return n.nom.trim().toLowerCase().replace(/\s+/g, " ");
}

export const panneauFiltres = { ouvert: false };

type OptsFiltres = {
  familles: Famille[]; niveaux: Niveau[];
  groupes: { nom: string; familles: Famille[]; niveaux: Niveau[] }[];
  f: MovensoApp["filtres"]; nomNiveauSel: string | null;
  basculer: (cle: "familleId" | "source", valeur: string) => void;
  basculerNiveau: (n: Niveau) => void; reinitialiser: () => void; nombre: number;
};

export function feuilleFiltres(app: MovensoApp, o: OptsFiltres): TemplateResult {
  const fermer = () => { panneauFiltres.ouvert = false; app.requestUpdate(); };
  const puceFamille = (fa: Famille) => html`<button class="chip-filtre ${o.f.familleId === fa.id ? "actif" : ""}"
    @click=${() => o.basculer("familleId", fa.id)}>${fa.nom}</button>`;
  const puceNiveau = (n: Niveau) => html`<button class="chip-filtre ${o.nomNiveauSel === cleNiveau(n) ? "actif" : ""}"
    @click=${() => o.basculerNiveau(n)}>${pastilleNiveau(n)}${n.nom}</button>`;
  const grouper = o.groupes.length > 1;
  const sectionFamilles = grouper
    ? html`${o.groupes.filter((g) => g.familles.length).map((g) => html`<div class="feuille-sous-groupe">${g.nom}</div>
        <div class="chips-filtres libre">${g.familles.map(puceFamille)}</div>`)}`
    : (o.familles.length > 1 ? html`<div class="chips-filtres libre" aria-label="Catégories">${o.familles.map(puceFamille)}</div>` : nothing);
  const sectionNiveaux = grouper
    ? html`${o.groupes.filter((g) => g.niveaux.length).map((g) => html`<div class="feuille-sous-groupe">${g.nom}</div>
        <div class="chips-filtres libre">${g.niveaux.map(puceNiveau)}</div>`)}`
    : (o.niveaux.length ? html`<div class="chips-filtres libre" aria-label="Niveaux">${o.niveaux.map(puceNiveau)}</div>` : nothing);
  const aFamilles = grouper ? o.groupes.some((g) => g.familles.length) : o.familles.length > 1;
  const aNiveaux = grouper ? o.groupes.some((g) => g.niveaux.length) : o.niveaux.length > 0;
  return html`
    <div class="voile" @click=${fermer}></div>
    <div class="feuille feuille-filtres" role="dialog" aria-label="Filtres">
      <div class="feuille-poignee" aria-hidden="true"></div>
      <div class="feuille-titre">Filtres</div>
      ${aFamilles ? html`<div class="feuille-groupe">Catégories</div>${sectionFamilles}` : nothing}
      ${aNiveaux ? html`<div class="feuille-groupe">Niveaux</div>${sectionNiveaux}` : nothing}
      <div class="feuille-filtres-actions">
        <button class="bouton" @click=${() => { o.reinitialiser(); }}>Réinitialiser les filtres</button>
        <button class="bouton principal" @click=${fermer}>Voir ${o.nombre} technique${o.nombre > 1 ? "s" : ""}</button>
      </div>
    </div>`;
}
