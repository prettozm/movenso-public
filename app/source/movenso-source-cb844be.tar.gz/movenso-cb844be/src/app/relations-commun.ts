/**
 * RELATIONS — COMMUN (S3.A10) : l'état de session, l'historique des centres et
 * les aides partagées par les deux vues Liste / Graphe — extrait de
 * relations-visuelle.ts pour casser les cycles d'import (les modules de vue
 * importent d'ici, jamais l'inverse).
 */
import { html, nothing, svg, type TemplateResult } from "lit";
import type { Bibliotheque, Technique, RoleRelation, TypeRelationDef } from "../domaine/modele.ts";
import type { RelationAffichee } from "../domaine/relations.ts";
import type { MovensoApp } from "./racine.ts";

// D-383 : TROIS onglets d'un même graphe — Liste · Graphe (id interne `mindmap`)
// · Parcours (`explorer`). L'onglet Graphe porte DEUX dispositions du même
// réseau (`Disposition`) : « structure » = radial lisible (ex-Mind map
// `classique`, D-376), « reseau » = pan/zoom exploratoire (ex-Carte, D-140).
// Fusionner leur RÔLE dans la navigation, pas leur rendu (demande porteur).
export type Vue = "liste" | "mindmap" | "explorer";
export type Disposition = "structure" | "reseau";
export type Tri = "pertinence" | "alpha";

export type IntentId = "enchainer" | "preparer" | "comparer" | "defendre";
export type Etape = { id: string; note?: string; role?: RoleRelation };

/** État de session, léger (survit au recentrage via `relationCentre` côté app). */
export const etat: {
  recherche: string; vue: Vue; disposition: Disposition; filtre: string | null; tri: Tri; plein: boolean;
  bienvenue: boolean;
  exIntent: IntentId | null; exChemin: Etape[]; exCompare: string | null;
  mmCherche: boolean; carteDeplie: Set<string>; carteMasque: Set<string>; carteRoleDeplie: Set<RoleRelation>;
  mmDeplie: Set<string>; mmMasque: Set<string>;
} = {
  recherche: "",
  vue: "liste",
  disposition: "structure", // Graphe : disposition courante (hydratée au 1er rendu, D-383)
  bienvenue: false, // écran de BIENVENUE réinvoqué depuis l'aide (D-180)
  filtre: null,
  tri: "pertinence",
  plein: false, // Graphe : plein écran (D-138 R6/R8)
  exIntent: null, // Parcours : objectif choisi
  exChemin: [], // Parcours : parcours construit (1re étape = centre)
  exCompare: null, // Parcours : cible du face-à-face Comparer (O2, D-198)
  mmCherche: false, // recherche compacte (loupe de l'en-tête) — PARTAGÉE par les vues
  carteDeplie: new Set(), // Graphe : nœuds dépliés (multi-niveaux, D-158)
  carteMasque: new Set(), // Graphe : libellés de familles masqués via les chips légende/filtre (D-159)
  carteRoleDeplie: new Set(), // Graphe : rôles dont le « +N autres » a été déplié SUR PLACE (D-160)
  mmDeplie: new Set(), // Mind map radiale : slots dont le « +N » est déplié sur place (D-152)
  mmMasque: new Set(), // Mind map radiale : slots masqués via les chips légende/filtre
};

/** Historique des centres visités DANS Relations (R4, D-137) — pile de session
 *  (état module ; le centre COURANT, lui, persiste via R3). Sert le fil
 *  d'Ariane : toucher un maillon y ramène, « Revenir » dépile — JAMAIS de
 *  retour à la Bibliothèque. */
export let historique: string[] = []; // liaison vivante — LECTURE seule hors de ce module

/** Recentre en empilant (recentrage : nœud, ligne Liste, candidat Parcours,
 *  résultat de recherche, point de départ). Si la cible est déjà dans la pile,
 *  on y revient (troncature) plutôt que de créer un doublon. */
export function pousser(app: MovensoApp, id: string): void {
  const idx = historique.lastIndexOf(id);
  historique = idx >= 0 ? historique.slice(0, idx + 1) : [...historique, id];
  app.recentrerRelations(id);
}

/** ← Revenir : dépile d'un cran (jamais en deçà du premier centre). D-384 :
 *  l'avance (→) est retirée avec les flèches permanentes de l'en-tête — le
 *  retour reste, CONTEXTUEL (chip « ← <précédent> » quand la pile a un cran). */
export function reculer(app: MovensoApp): void {
  if (historique.length <= 1) return;
  historique = historique.slice(0, -1);
  app.recentrerRelations(historique[historique.length - 1]!);
}

/** Réconcilie la pile avec le centre résolu au rendu : gère l'entrée EXTERNE
 *  (ex. « Voir en graphe » depuis une fiche, centre mémorisé au démarrage) qui
 *  fixe le centre sans passer par `pousser`. Pur ajustement de cache module. */
export function synchroniserHistorique(centreId: string): void {
  if (historique.length === 0) { historique = [centreId]; return; }
  if (historique[historique.length - 1] === centreId) return;
  const idx = historique.lastIndexOf(centreId);
  historique = idx >= 0 ? historique.slice(0, idx + 1) : [...historique, centreId];
}

/** Techniques qui participent au graphe (au moins un lien, entrant ou sortant). */
export function techniquesReliees(b: Bibliotheque): Technique[] {
  return b.techniques.filter(
    (t) => t.relations.length > 0 || b.techniques.some((z) => z.relations.some((r) => r.cibleId === t.id)),
  );
}

/** 🎲 : centre AU HASARD sur une AUTRE technique reliée, sur place (D-179).
 *  Vit ici (et non dans relations-visuelle) pour que Parcours l'appelle sans
 *  créer de cycle d'import (D-384 : le dé déménage dans Parcours). */
export function hasardSurPlace(app: MovensoApp): void {
  const b = app.bibliotheque;
  if (!b) return;
  const centreId = app.techniqueCentreRelations();
  const candidates = techniquesReliees(b).filter((t) => t.id !== centreId);
  if (candidates.length === 0) return;
  pousser(app, candidates[Math.floor(Math.random() * candidates.length)]!.id);
}

export function nomFamille(b: Bibliotheque, t: Technique): string {
  return t.familleId
    ? b.disciplines.find((d) => d.id === t.disciplineId)?.familles.find((f) => f.id === t.familleId)?.nom ?? ""
    : "";
}

/** Classe couleur d'un lien d'après son RÔLE sémantique (D-136) : le placement
 *  et la couleur suivent le rôle (avant/après/…), jamais le texte du libellé. */
export function classeRole(role: RoleRelation): string {
  return `role--${role}`;
}

/** Pastille ⚠️ si la technique porte une alerte (D-136) — visible en navigation. */
export function pastilleAlerte(app: MovensoApp, id: string): TemplateResult {
  const a = app.technique(id)?.alertes?.[0];
  return a ? html`<span class="rel-alerte" title=${a.libelle}>⚠️</span>` : (nothing as unknown as TemplateResult);
}

/** Petite icône par rôle (cohérente avec la couleur). Le fragment interne DOIT
 *  passer par le tag `svg` de Lit (D-150) : avec `html`, le <path> naissait dans
 *  le namespace HTML et ne se dessinait jamais — d'où des icônes invisibles
 *  (badges/labels/chips en « carrés vides ») depuis D-136. */
export function iconeRole(role: RoleRelation): TemplateResult {
  const s = (d: string) =>
    html`<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">${svg`<path d=${d}></path>`}</svg>`;
  switch (role) {
    case "before": return s("M20 12H6M11 6l-6 6 6 6"); // ← amène
    case "after": return s("M4 12h14M13 6l6 6-6 6"); // → suite
    case "opposition": return s("M12 3l7 3v5c0 4.2-2.9 7.7-7 8.9C7.9 18.7 5 15.2 5 11V6z"); // bouclier
    case "peer": return s("M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 17l-5.2 2.7 1-5.8L3.5 9.7l5.9-.9z"); // étoile = voisins
    case "context": return s("M4 5h11a3 3 0 013 3v11M4 5v11a3 3 0 003 3h12M4 5l4 3"); // signet
    default: return s("M4 12h14M13 6l6 6-6 6");
  }
}

/** Ordre d'affichage des rôles (ligne de temps : avant → après → opposition → pair → contexte). */
export const ORDRE_ROLE: RoleRelation[] = ["before", "after", "opposition", "peer", "context"];

/** Définition COURTE d'un type de lien, dérivée de son RÔLE (D-385/§19) — montrée
 *  au choix du type pour éviter les liens mal catégorisés. Clé sur le rôle (le
 *  seul sémantique universel : les types sont créables), pas sur le libellé. */
function definitionRole(role: RoleRelation): string {
  switch (role) {
    case "before": return "Une base utile AVANT cette technique.";
    case "after": return "Les deux techniques peuvent réellement se succéder.";
    case "opposition": return "Ce qui répond à la technique — contre, réaction.";
    case "peer": return "Une proximité : à rapprocher, ou à ne pas confondre.";
    case "context": return "Appartenance à un ensemble (kata, forme).";
  }
}

/** Ligne montrée sous les chips de type à l'ajout d'un lien (D-385/§19) : la
 *  lecture inverse CONCRÈTE + la définition du rôle — éviter les liens mal
 *  catégorisés, sans page d'aide à part. */
export function defTypeLien(t: TypeRelationDef | undefined): TemplateResult | typeof nothing {
  if (!t) return nothing;
  const lec = t.symetrique ? "Se lit pareil dans les deux sens" : t.libelleInverse ? `« ${t.libelle} » → « ${t.libelleInverse} »` : `« ${t.libelle} »`;
  return html`<p class="lien-def"><span class="lien-def-lecture">${lec}</span> · ${definitionRole(t.role ?? "peer")}</p>`;
}

/** Groupe les liaisons par libellé (= rôle affiché), triées par RÔLE puis libellé. */
export function grouper(liaisons: RelationAffichee[]): { libelle: string; role: RoleRelation; liste: RelationAffichee[] }[] {
  const parLibelle = new Map<string, RelationAffichee[]>();
  for (const l of liaisons) parLibelle.set(l.libelle, [...(parLibelle.get(l.libelle) ?? []), l]);
  return [...parLibelle.entries()]
    .map(([libelle, liste]) => ({ libelle, role: liste[0]!.role, liste }))
    .sort((a, z) => (ORDRE_ROLE.indexOf(a.role) - ORDRE_ROLE.indexOf(z.role)) || a.libelle.localeCompare(z.libelle, "fr"));
}

/** Tri interne d'un groupe : pertinence (priorité éditoriale) ou alphabétique. */
export function trier(app: MovensoApp, liste: RelationAffichee[]): RelationAffichee[] {
  const nom = (l: RelationAffichee) => app.technique(l.techniqueId)?.nom ?? "";
  return [...liste].map((l, i) => ({ l, i })).sort((a, z) => {
    if (etat.tri === "alpha") return nom(a.l).localeCompare(nom(z.l), "fr") || a.i - z.i;
    return (a.l.priorite ?? Infinity) - (z.l.priorite ?? Infinity) || a.i - z.i;
  }).map((x) => x.l);
}

/** Bascule de DISPOSITION du Graphe (D-383) : UN bouton, pas un second jeu
 *  d'onglets — même réseau, deux placements. « Structuré » = radial lisible,
 *  « Réseau » = pan/zoom. Le bouton dit la disposition COURANTE, le ⇄ signale
 *  qu'il alterne ; le choix est mémorisé sur l'appareil. */
export function barreDisposition(app: MovensoApp): TemplateResult {
  const struct = etat.disposition === "structure";
  const autre: Disposition = struct ? "reseau" : "structure";
  const nomAutre = struct ? "Réseau" : "Structuré";
  const basculer = () => { etat.disposition = autre; etat.plein = false; app.enregistrerRelationsUi({ relationsDisposition: autre }); app.requestUpdate(); };
  return html`<div class="rel-dispo-barre">
    <button class="rel-dispo" @click=${basculer} aria-label=${`Basculer en disposition ${nomAutre}`} title=${`Basculer en disposition ${nomAutre}`}>
      <span class="rel-dispo-glyphe" aria-hidden="true">${struct ? "▦" : "⧉"}</span>
      <span class="rel-dispo-nom">${struct ? "Structuré" : "Réseau"}</span>
      <span class="rel-dispo-swap" aria-hidden="true">⇄</span>
    </button>
  </div>`;
}

/** ---- Vue CARTE (D-140, retour de la Mindmap graphique + pan/zoom) : hub AU
 *  CENTRE, cartes-vignettes posées par RÔLE autour (avant à gauche, après à
 *  droite, pair en haut, opposition en bas, contexte en bas-gauche), reliées au
 *  hub par des courbes de Bézier colorées. Le pan / zoom / pincement agit par
 *  TRANSFORM CSS sur la scène : les cartes gardent leurs vraies vignettes <img>
 *  (la version 100 % SVG de D-138 avait sacrifié cette richesse et devenait
 *  illisible par défaut). Le fit reste LISIBLE — plancher de zoom `K_FIT_MIN`,
 *  scène centrée sur le hub — ; au-delà, on déborde et on se déplace. Toucher une
 *  carte recentre (historique R4) ; le hub ouvre la fiche ; « +N » bascule dans
 *  la Liste ; double-toucher = fit ; bouton plein écran. ---- */
export function couleurRole(role: RoleRelation): string {
  switch (role) {
    // Les VALEURS vivent dans `base.css` (`--role-*`) : elles étaient recopiées
    // en dur ici, et `peer` empruntait `--accent` — donc changeait avec la
    // tonalité, jusqu'à se confondre avec `before` ou `after` (D-349).
    case "before": return "var(--role-before)"; // amène = VERT (aligné Mindmap/proto, D-158)
    case "after": return "var(--role-after)"; // suite = BLEU
    case "opposition": return "var(--role-opposition)";
    case "peer": return "var(--role-peer)"; // voisins (similaire / variante) = CORAIL
    case "context": return "var(--role-context)"; // or (fondamentaux) — distinct des similarités (D-147)
    default: return "var(--sourdine)";
  }
}
