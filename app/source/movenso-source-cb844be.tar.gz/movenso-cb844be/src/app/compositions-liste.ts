/**
 * LISTE des compositions (UI-1, D-320) — deux publics, deux grammaires.
 *
 * L'écran mélangeait « mes séquences » et « celles de mes packs » dans une
 * liste unique : seize séances de taïso noyaient les trois enchaînements de
 * l'utilisateur, et rien ne disait laquelle lui appartenait. La bascule
 * **Mes compositions | Packs** (sur `provenance`) sépare ce qui s'édite de ce
 * qui se duplique, et chaque côté prend la densité de son usage (R2, D-318) :
 *  - **Mes** sert à AGIR → cartes compactes, la densité d'aujourd'hui ;
 *  - **Packs** sert à DÉCOUVRIR → groupes par discipline, de l'air, un aperçu.
 *
 * Trois choix qui viennent d'une mesure, pas d'un goût :
 *  - la **vignette reste petite** (R1) : dérivée de la première technique, elle
 *    se répète — taïso a 16 séances pour 2 vignettes distinctes ; en héros elle
 *    se lirait comme un défaut d'affichage. C'est le NOM qui discrimine ;
 *  - le **liseré = discipline dominante** (arbitrage porteur), teinte prise sur
 *    la palette de six déjà utilisée par les rôles — aucune couleur nouvelle,
 *    et `Discipline` ne gagne aucun champ ;
 *  - une composition **sans dominante** ne reçoit PAS une couleur au hasard
 *    (R5) : liseré neutre et chip « Mixte · judo + JJB », qui dit le vrai.
 *
 * Ce que la carte de pack NE porte PAS : le nom du pack. Mesuré sur les six
 * packs officiels — aucun n'attribue ses compositions, et leur `origine.pack`
 * est un ULID depuis D-247 : la chip aurait affiché « 01KY8F8AV3R8BW… ».
 * L'onglet, le groupe de discipline et le pied explicatif disent déjà d'où
 * elles viennent ; un identifiant n'aurait rien ajouté qu'une inquiétude.
 *
 * Ce que la liste NE fait pas : la section « Continuer ». Elle exige la
 * dernière position de lecture, qui n'est pas persistée (UI-6).
 */

import { html, nothing, type TemplateResult } from "lit";
import type { Composition } from "../domaine/modele.ts";
import { dureeTotale, formaterDuree, nombreDePas } from "../domaine/composition.ts";
import { vignetteTechnique } from "./vues.ts";
import type { MovensoApp } from "./racine.ts";

/** Combien de compositions un groupe de pack montre avant « Voir les N ». */
const APERCU_GROUPE = 3;

/** Onglets, tri et groupes dépliés — état de SESSION : un geste en cours, pas
 *  une préférence d'appareil (rien à persister, rien à migrer). */
const etatListe: { onglet: "mes" | "packs" | null; tri: "recent" | "nom" | "duree"; deplies: Set<string> } = {
  onglet: null, tri: "recent", deplies: new Set(),
};

/** Bascule la liste sur l'onglet « Packs » (UI-4, D-322) : l'entonnoir de
 *  création y renvoie pour « partir d'une composition existante » — le geste
 *  est la duplication, qui existe déjà sur la carte. Rien de neuf, un chemin
 *  nommé. */
export function ouvrirOngletPacks(): void {
  etatListe.onglet = "packs";
}

/** Une composition m'appartient-elle ? `provenance` répond, et c'est le seul
 *  critère : un savoir venu d'un pack porte `referentiel`/`ressource`. */
function estAMoi(c: Composition): boolean {
  return c.provenance === "personnel";
}

/** Teinte d'une discipline (D-320) : son RANG dans la bibliothèque, projeté sur
 *  les six teintes des rôles (D-227). Un seul lieu de calcul (D-253) — liseré,
 *  pastille de groupe et chip s'y réfèrent tous.
 *
 *  Pourquoi le rang et non une empreinte du nom : avec six teintes, une
 *  empreinte ferait collisionner deux disciplines sur les six packs officiels —
 *  « judo et yoga en terre cuite » se lit comme un défaut. Le rang les garde
 *  distinctes tant qu'il y en a six ou moins ; la contrepartie assumée est que
 *  réordonner ses disciplines change les teintes, ce qui reste cohérent partout
 *  au même instant. */
function rangDiscipline(app: MovensoApp, nom: string): number {
  const i = app.bibliotheque!.disciplines.findIndex((d) => d.nom === nom);
  return i < 0 ? 0 : (i % 6) + 1;
}

/** Disciplines présentes dans une composition, avec leur POIDS (nombre de pas
 *  qui les citent) — c'est le poids qui désigne la dominante. */
export function disciplinesPesees(app: MovensoApp, c: Composition): { nom: string; poids: number }[] {
  const poids = new Map<string, number>();
  for (const bloc of c.blocs) {
    if (bloc.type !== "technique" || !bloc.techniqueId) continue;
    const t = app.technique(bloc.techniqueId);
    const d = t && app.bibliotheque!.disciplines.find((x) => x.id === t.disciplineId);
    if (d) poids.set(d.nom, (poids.get(d.nom) ?? 0) + 1);
  }
  return [...poids].map(([nom, p]) => ({ nom, poids: p })).sort((a, z) => z.poids - a.poids);
}

/** La discipline DOMINANTE, ou `null` s'il y a égalité entre les deux
 *  premières (une égalité n'a pas de dominante — R5 : on ne tranche pas au
 *  hasard, on affiche « Mixte »). */
function disciplineDominante(app: MovensoApp, c: Composition): string | null {
  const pesees = disciplinesPesees(app, c);
  if (pesees.length === 0) return null;
  if (pesees.length > 1 && pesees[1]!.poids === pesees[0]!.poids) return null;
  return pesees[0]!.nom;
}

/* ---------- pictogrammes de la ligne de méta ---------- */

const IC_ETAPES = html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/></svg>`;
const IC_DUREE = html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>`;
const IC_SEUL = html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="8" r="3.6"/><path d="M5.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/></svg>`;
const IC_PLUSIEURS = html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="9" cy="8" r="3.4"/><path d="M2.5 20c0-3.5 2.9-5.8 6.5-5.8S15.5 16.5 15.5 20"/><circle cx="17.5" cy="8.5" r="2.8"/><path d="M16 14.4c3 .3 5.5 2.4 5.5 5.6"/></svg>`;

/** Ligne de méta à ICÔNES : étapes, durée si elle existe, mode. Elle se compose
 *  DE CE QUI EST PRÉSENT (D-315) — aucun pack ne réunit rôles et durées, donc
 *  aucune case vide, aucun « 0 min ». */
function ligneMeta(c: Composition): TemplateResult {
  const pas = nombreDePas(c);
  const total = dureeTotale(c);
  const roles = c.acteurs ?? [];
  return html`
    <span class="meta-ligne">
      <span><span class="meta-ic">${IC_ETAPES}</span>${pas === 0 ? "à construire" : `${pas} étape${pas > 1 ? "s" : ""}`}</span>
      ${total > 0 ? html`<span><span class="meta-ic">${IC_DUREE}</span>${formaterDuree(total)}</span>` : nothing}
      ${roles.length >= 2
        ? html`<span><span class="meta-ic">${IC_PLUSIEURS}</span>${roles.length === 2 ? "À deux" : `${roles.length} rôles`}</span>`
        : html`<span><span class="meta-ic">${IC_SEUL}</span>Seul</span>`}
    </span>`;
}

/** Pastilles sous la méta : les rôles NOMMÉS à partir de deux (R6 — en dessous,
 *  il n'y a rien à distinguer), sinon « Mixte · a + b » quand aucune discipline
 *  ne domine. */
function badgesCarte(app: MovensoApp, c: Composition): TemplateResult | typeof nothing {
  const roles = c.acteurs ?? [];
  if (roles.length >= 2)
    return html`<span class="carte-badges">${roles.map(
      (a, i) => html`<em class="badge-role" data-acteur-rang=${i + 1}>${a.nom}</em>`,
    )}</span>`;
  const pesees = disciplinesPesees(app, c);
  if (disciplineDominante(app, c) === null && pesees.length > 1)
    return html`<span class="carte-badges"><em class="badge-mixte">Mixte · ${pesees.map((p) => p.nom).join(" + ")}</em></span>`;
  return nothing;
}

/** Vignette d'une composition : celle de sa première technique, petite (R1). */
function vignetteDe(app: MovensoApp, c: Composition): TemplateResult | typeof nothing {
  const premier = c.blocs.find((x) => x.type === "technique" && x.techniqueId);
  const t = premier?.techniqueId ? app.technique(premier.techniqueId) : undefined;
  return t ? vignetteTechnique(app, t) : nothing;
}

/** Une carte. Le second rond change de geste selon le côté : ⋮ sur les miennes
 *  (renommer, décrire, supprimer), **Dupliquer** sur celles d'un pack — c'est
 *  le geste attendu là, et le ⋮ reste accessible depuis la fiche : aucune
 *  capacité perdue, seulement rangée où elle sert. */
function carte(app: MovensoApp, c: Composition): TemplateResult {
  const dom = disciplineDominante(app, c);
  const rang = dom ? rangDiscipline(app, dom) : 0;
  return html`
    <article class="carte-liste composition-carte" data-acteur-rang=${rang}>
      <button class="composition-ouvrir" @click=${() => app.ouvrirComposition(c.id)}>
        <span class="carte-liste-vignette">${vignetteDe(app, c)}</span>
        <span class="carte-liste-corps">
          <span class="carte-liste-titre">${c.nom}</span>
          ${ligneMeta(c)}
          ${badgesCarte(app, c)}
        </span>
      </button>
      ${c.blocs.length
        ? html`<button class="rond-action plein composition-play" aria-label="Démarrer « ${c.nom} »" title="Passer en revue"
            @click=${() => app.demarrerEntrainement(c.id)}>
            <svg width="19" height="19" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13l11-6.5z"/></svg>
          </button>`
        : nothing}
      <!-- D-392/§2 : le SECOND rond est TOUJOURS ⋮ (mes compos comme celles de pack)
           — la copie n'est plus un bouton nu sur la liste (copies involontaires),
           elle vit dans le menu, où le pack n'offre que dupliquer/partager (D-392). -->
      <button class="rond-action fantome composition-options" aria-label="Options de « ${c.nom} »" title="Autres actions"
        @click=${() => { app.menuComposition = c.id; app.requestUpdate(); }}>
        <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="5.5" r="1.7"/><circle cx="12" cy="12" r="1.7"/><circle cx="12" cy="18.5" r="1.7"/></svg>
      </button>
    </article>`;
}

/** Le tri, dans l'ordre où on le veut : récent d'abord (ce qu'on vient de
 *  toucher), puis nom, puis durée. `modifieLe` à défaut de `creeLe`. */
function trier(liste: Composition[], tri: typeof etatListe.tri): Composition[] {
  const copie = [...liste];
  if (tri === "nom") return copie.sort((a, z) => a.nom.localeCompare(z.nom, "fr"));
  if (tri === "duree") return copie.sort((a, z) => dureeTotale(z) - dureeTotale(a));
  return copie.sort((a, z) => (z.modifieLe ?? z.creeLe).localeCompare(a.modifieLe ?? a.creeLe));
}

/** Bascule segmentée Mes | Packs — deux onglets exclusifs, jamais un filtre
 *  caché dans un menu. Les compteurs sont dits : un onglet vide se voit avant
 *  d'être touché. */
function segments(app: MovensoApp, nMes: number, nPacks: number, onglet: "mes" | "packs"): TemplateResult {
  const bouton = (cle: "mes" | "packs", libelle: string, n: number) => html`
    <button class="segment ${onglet === cle ? "actif" : ""}" aria-pressed=${onglet === cle}
      @click=${() => { etatListe.onglet = cle; app.requestUpdate(); }}>
      ${libelle}<span class="segment-compte">${n}</span>
    </button>`;
  return html`<div class="segments" role="group" aria-label="Quelles compositions afficher">
    ${bouton("mes", "Mes compositions", nMes)}${bouton("packs", "Packs", nPacks)}
  </div>`;
}

/** Sélecteur de tri : un `<select>` natif plutôt qu'un menu maison — il défile
 *  sur mobile, il est lu par les lecteurs d'écran, et il ne coûte aucune
 *  feuille de plus (D-126 : moins de surfaces, pas plus). */
function selecteurTri(app: MovensoApp): TemplateResult {
  return html`<label class="tri-compos">Trier par
    <select aria-label="Trier les compositions" .value=${etatListe.tri}
      @change=${(e: Event) => { etatListe.tri = (e.target as HTMLSelectElement).value as typeof etatListe.tri; app.requestUpdate(); }}>
      <option value="recent">Récent</option>
      <option value="nom">Nom</option>
      <option value="duree">Durée</option>
    </select>
  </label>`;
}

/** Côté PACKS : un groupe par discipline dominante, l'aperçu à trois, le reste
 *  derrière « Voir les N ». Les compositions sans dominante finissent dans un
 *  groupe « Mixtes » — nommé, pas caché. */
function groupesPacks(app: MovensoApp, visibles: Composition[]): TemplateResult {
  const groupes = new Map<string, Composition[]>();
  for (const c of visibles) {
    const cle = disciplineDominante(app, c) ?? "Mixtes";
    const dans = groupes.get(cle);
    if (dans) dans.push(c);
    else groupes.set(cle, [c]);
  }
  const ordre = [...groupes.keys()].sort((a, z) => (groupes.get(z)!.length - groupes.get(a)!.length) || a.localeCompare(z, "fr"));
  return html`${ordre.map((nom) => {
    const dans = trier(groupes.get(nom)!, etatListe.tri);
    const deplie = etatListe.deplies.has(nom);
    const montres = deplie ? dans : dans.slice(0, APERCU_GROUPE);
    return html`<section class="groupe-pack" aria-label=${nom}>
      <header class="groupe-tete">
        <span class="pastille-disc" data-acteur-rang=${nom === "Mixtes" ? 0 : rangDiscipline(app, nom)} aria-hidden="true"></span>
        <h3>${nom}</h3><span class="groupe-compte">${dans.length}</span>
      </header>
      ${montres.map((c) => carte(app, c))}
      ${dans.length > APERCU_GROUPE
        ? html`<button class="voir-plus" @click=${() => {
            deplie ? etatListe.deplies.delete(nom) : etatListe.deplies.add(nom);
            app.requestUpdate();
          }}>${deplie ? "Replier" : `Voir les ${dans.length}`}</button>`
        : nothing}
    </section>`;
  })}`;
}

/** Carte « Continuer » (UI-6, D-324) : la reprise de la dernière séance
 *  interrompue. **UNE seule entrée** (arbitrage porteur) — pas d'historique.
 *
 *  Elle vit AU-DESSUS de la bascule, et non dans « Mes compositions » comme le
 *  montraient les planches : ce qu'on reprend peut très bien être une séance de
 *  pack, et la ranger d'un côté l'aurait fait disparaître de l'autre. « Où j'en
 *  étais » n'est pas une question d'appartenance.
 *
 *  Une référence ORPHELINE (composition supprimée, bibliothèque restaurée)
 *  n'affiche rien et ne se nettoie pas : effacer sans geste serait une écriture
 *  de plus — même règle qu'un favori orphelin (D-127).
 *
 *  La position se dit « 2 / 4 », comme le LECTEUR qu'elle ouvre — et non
 *  « Étape 2 sur 4 » (D-326). L'index est une place dans le déroulé, que le
 *  lecteur traverse jalons compris ; le mot « étape » compte les gestes
 *  (`nombreDePas`, qui les exclut). Deux notions différentes ne partagent pas
 *  un mot, sinon la carte et l'écran qu'elle ouvre se contredisent. */
function carteReprise(app: MovensoApp, toutes: Composition[]): TemplateResult | typeof nothing {
  const d = app.preferences.derniereLecture;
  const compo = d && toutes.find((c) => c.id === d.compositionId);
  if (!d || !compo || d.index >= compo.blocs.length) return nothing;
  const bloc = compo.blocs[d.index]!;
  const nomPas = bloc.techniqueId
    ? app.technique(bloc.techniqueId)?.nom ?? bloc.texte ?? "étape"
    : (bloc.texte ?? "").trim() || "étape";
  return html`
    <section class="reprise" aria-label="Reprendre où tu t'es arrêté">
      <div class="reprise-tete"><span class="reprise-libelle">Continuer</span></div>
      <article class="carte-liste reprise-carte" data-acteur-rang=${(() => {
        const dom = disciplineDominante(app, compo);
        return dom ? rangDiscipline(app, dom) : 0;
      })()}>
        <button class="composition-ouvrir reprise-ouvrir" @click=${() => app.ouvrirComposition(compo.id)}>
          <span class="carte-liste-vignette">${vignetteDe(app, compo)}</span>
          <span class="carte-liste-corps">
            <span class="carte-liste-titre">${compo.nom}</span>
            <span class="reprise-position">${d.index + 1} / ${compo.blocs.length} · ${nomPas}</span>
            <!-- D-396/§1 : une barre de progression dit « reprise », pas « dernière ouverte ». -->
            <span class="reprise-barre" aria-hidden="true"><span class="reprise-jauge" style=${`width:${Math.round(((d.index + 1) / compo.blocs.length) * 100)}%`}></span></span>
          </span>
        </button>
        <button class="rond-action plein reprise-reprendre" aria-label="Reprendre « ${compo.nom} » à l'étape ${d.index + 1}"
          title="Reprendre où tu t'es arrêté" @click=${() => app.demarrerEntrainement(compo.id, d.index)}>
          <svg width="19" height="19" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13l11-6.5z"/></svg>
        </button>
      </article>
    </section>`;
}

/** L'écran. `filtrer` reçoit la recherche et les chips de discipline, qui
 *  restent au-dessus de la bascule : ils portent sur les deux côtés. */
export function listeCompositions(
  app: MovensoApp,
  toutes: Composition[],
  visibles: Composition[],
  entete: TemplateResult,
  vide: TemplateResult,
): TemplateResult {
  const mesToutes = toutes.filter(estAMoi);
  const packsToutes = toutes.filter((c) => !estAMoi(c));
  // Entrée naturelle : mes compositions si j'en ai, sinon celles de mes packs —
  // un onglet vide d'accueil ferait croire à une bibliothèque vide.
  const naturel = mesToutes.length > 0 || packsToutes.length === 0 ? "mes" : "packs";
  // Un onglet CHOISI qui s'est vidé (restauration, suppression) revient au
  // côté qui a du contenu : mieux vaut montrer ce qui existe que défendre un
  // geste passé.
  const choisi = etatListe.onglet;
  const compte = (o: "mes" | "packs") => (o === "mes" ? mesToutes.length : packsToutes.length);
  const onglet = choisi && compte(choisi) > 0 ? choisi : naturel;
  const dedans = visibles.filter((c) => (onglet === "mes" ? estAMoi(c) : !estAMoi(c)));
  return html`
    <header class="marque"><div style="flex:1"><div class="nom">Compositions</div>
      ${toutes.length <= 3
        ? html`<div class="devise">Assemble tes techniques en enchaînements et en séances.</div>`
        : nothing}</div></header>
    ${entete}
    ${carteReprise(app, toutes)}
    ${segments(app, mesToutes.length, packsToutes.length, onglet)}
    <!-- D-392/§1 : l'explication des Packs vit SOUS le sélecteur (et non tout en bas
         d'une longue liste), légère — elle dit d'où viennent ces compositions
         avant qu'on les parcoure. -->
    ${onglet === "packs" && dedans.length > 0
      ? html`<p class="compo-packs-intro">Compositions fournies par tes packs — duplique-en une pour la personnaliser.</p>`
      : nothing}
    ${dedans.length === 0
      ? vide
      : onglet === "packs"
        ? html`<div class="fil fil-packs">${groupesPacks(app, dedans)}</div>`
        : html`<div class="sect-liste"><h3>Mes compositions</h3>${selecteurTri(app)}</div>
            <div class="fil">${trier(dedans, etatListe.tri).map((c) => carte(app, c))}</div>`}
  `;
}
