/**
 * CHAPITRE e2e (S3.A7) — D-227/D-229/D-231 : composition à PLUSIEURS.
 * On prend le chemin du PORTEUR, pas celui du concepteur : on déclare les rôles
 * DANS L'ENTONNOIR (« Qui pratique ? »), on en met QUATRE, et on lit le résultat
 * sur un écran étroit — là où mes premières preuves se limitaient à deux rôles
 * déclarés après coup, ce qui masquait le défaut (retour porteur 2026-08-07).
 * Contexte Playwright propre : OPFS isolé — le flux principal garde son état
 * cumulatif intact.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

/** Décor minimal commun : la bêta ouverte, une discipline, des techniques. */
async function decor(p) {
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".barre-nav");
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    app.basculerReglage("compositionsBeta"); // D-223 : l'onglet est en bêta opt-in
    const d = await app.creerDiscipline("Judo");
    for (const n of ["O-soto-gari", "Tai-sabaki", "O-goshi", "Ura-nage"]) await app.creerTechnique(d, n);
    app.ouvrirCompositions();
    await app.updateComplete;
  });
}

/** Ajoute un pas depuis la feuille ouverte (entonnoir ou lecture). */
async function ajouterPas(p, libelle, opts = {}) {
  await p.locator(".toggle-quoi .chip-choix", { hasText: opts.libre ? "Texte / repère" : "Une technique" }).click();
  // UI-4 (D-322) : le CONTENU d'abord — « qui agit » et « même temps »
  // n'apparaissent qu'ensuite. C'est l'ordre de la planche, et celui du geste.
  if (opts.libre) await p.fill('input[aria-label="Texte ou repère"]', libelle);
  else {
    await p.fill('input[aria-label="Chercher une technique"]', libelle);
    await rendu(p);
    await p.locator(".resultat", { hasText: libelle }).first().click();
  }
  await rendu(p);
  if (opts.role) await p.locator(".choix-acteur .chip-filtre", { hasText: opts.role }).click();
  if (opts.lien) await p.locator(".choix-lien").click(); // « rejoint le temps précédent » (D-235)
  await p.locator(".ajout-valider").click();
  await rendu(p);
}

export async function run() {
  /* ---- 1) Créer une composition à QUATRE rôles, entièrement par l'entonnoir ---- */
  const etroit = await navigateur.newContext({ viewport: { width: 400, height: 900 } });
  const p = await etroit.newPage();
  surveiller(p);
  await decor(p);

  await p.locator(".fab").click();
  await p.waitForSelector('input[aria-label="Nom de la composition"]');
  await p.fill('input[aria-label="Nom de la composition"]', "Randori codifié");
  await p.locator(".feuille .bouton.principal", { hasText: "Suivant" }).click();

  // L'étape « Qui pratique ? » existe AVANT les pas (D-231) — et l'app ne
  // propose AUCUN nom : ni paire toute faite, ni « Rôle 3 » automatique.
  await p.waitForSelector(".choix-nombre-roles");
  assert.equal(await p.locator(".acteurs-propositions").count(), 0, "aucune paire de rôles n'est proposée (D-231)");
  assert.equal(await p.locator(".choix-nombre-roles .chip-choix").count(), 2, "deux choix seulement : Seul / À plusieurs (D-232)");
  await p.locator(".choix-nombre-roles .chip-choix", { hasText: "À plusieurs" }).click();
  await finit(async () => assert.equal(await p.locator(".nom-role").count(), 2, "« à plusieurs » commence à DEUX"));
  assert.deepEqual(await p.locator(".nom-role").evaluateAll((n) => n.map((x) => x.value)), ["", ""],
    "les champs sont VIDES : le nommage vient de l'utilisateur, jamais de l'app");
  assert.equal(await p.locator(".valider-roles").isDisabled(), true, "on ne passe pas avec des rôles sans nom");
  await p.locator(".acteur-ajouter", { hasText: "Ajouter un rôle" }).click();
  await p.locator(".acteur-ajouter", { hasText: "Ajouter un rôle" }).click();
  await finit(async () => assert.equal(await p.locator(".nom-role").count(), 4, "on monte à quatre en ajoutant"));
  for (const [i, nom] of ["Tori", "Uke", "Arbitre", "Partenaire"].entries())
    await p.locator(".nom-role").nth(i).fill(nom);
  await rendu(p);
  await finit(async () => assert.equal(await p.locator(".valider-roles").isDisabled(), false, "quatre rôles nommés : on passe"));
  await p.locator(".valider-roles").click();

  /* ---- 2) Les pas se posent avec leur rôle ET leur lien, DÈS la création ---- */
  // Les réglages n'existent qu'après le contenu (UI-4, D-322) : on attend donc
  // la feuille d'ajout, pas les chips de rôle.
  await p.waitForSelector(".toggle-quoi");
  assert.equal(await p.locator(".choix-acteur").count(), 0,
    "« qui agit » n'apparaît pas avant que le contenu du pas soit choisi (UI-4)");
  await ajouterPas(p, "O-soto-gari", { role: "Tori" });
  await ajouterPas(p, "Tai-sabaki", { role: "Uke", lien: true }); // rejoint le temps 1
  await ajouterPas(p, "O-goshi", { role: "Uke" });                // ouvre le temps 2
  await ajouterPas(p, "Annonce", { role: "Arbitre", lien: true, libre: true });
  await ajouterPas(p, "Ura-nage", { role: "Tori" });              // ouvre le temps 3
  await p.locator(".feuille .bouton.principal", { hasText: "Terminer" }).click();

  /* ---- 3) Écran étroit + quatre rôles : UNE colonne, mais les temps restent ---- */
  await p.waitForSelector(".dialogue");
  await finit(async () => assert.equal(await p.locator(".temps").count(), 3, "cinq pas, trois temps (D-235)"));
  assert.equal(await p.locator(".dialogue").getAttribute("data-roles"), "4");
  const visible = (sel) => p.locator(sel).first().evaluate((n) => getComputedStyle(n).display !== "none");
  assert.equal(await visible(".dialogue-entete"), false, "à 400 px, quatre voies ne tiennent pas : pas d'en-tête de colonnes");
  await finit(async () =>
    assert.deepEqual(await p.locator(".carte-role").allTextContents(), ["Tori", "Uke", "Uke", "Arbitre", "Tori"],
      "repliée, chaque carte redit QUI agit — la couleur ne porte jamais seule (D-231)"));
  // D-235 : AUCUN glyphe, AUCUN mot de liaison — la rangée dit le temps.
  assert.equal(await p.locator(".carte-lien").count(), 0, "plus de vocabulaire de liaison sur les cartes (D-235)");

  /* ---- 4) Quatre rôles = quatre teintes DISTINCTES (bug porteur : 3 et 4 gris) ---- */
  const teintes = await p.locator(".carte-dialogue[data-acteur-rang]").evaluateAll((n) =>
    n.map((x) => getComputedStyle(x).getPropertyValue("--acteur-teinte").trim()));
  assert.equal(new Set(teintes).size, 3, "les trois rôles qui agissent ont trois teintes différentes");

  /* ---- 4bis) UI-5 (D-323) : le lecteur dit QUI fait le pas suivant ---- */
  // À deux, l'information la plus utile de l'écran n'est pas le nom du pas
  // suivant : c'est de savoir si c'est à soi ou à l'autre. La donnée existait
  // depuis D-227 ; « Ensuite » n'en montrait rien.
  await p.locator(".passer-en-revue").click();
  await p.waitForSelector(".ecran.entrainement");
  await rendu(p);
  {
    const suite = p.locator(".entrainement-suite");
    assert.match(await suite.locator(".suite-nom").innerText(), /Tai-sabaki/, "« Ensuite » nomme le pas suivant");
    assert.deepEqual(await suite.locator(".suite-passation .badge-role").allTextContents(), ["Tori", "Uke"],
      "le rôle CHANGE : la passation se lit littéralement Tori → Uke (UI-5)");
  }
  await p.locator(".entrainement-actions .bouton", { hasText: "Quitter" }).click();
  await p.waitForSelector(".dialogue");

  /* ---- 5) Rattrapage par le ⋮ : un rôle n'existe QUE nommé ---- */
  await p.locator(".menu-composition").click();
  await p.waitForSelector(".acteur-nouveau");
  assert.equal(await p.locator(".acteur-nouveau .acteur-ajouter").isDisabled(), true, "sans nom, pas de rôle");
  await p.locator(".acteur-nouveau .nom-role").fill("Juge");
  await rendu(p);
  await p.locator(".acteur-nouveau .acteur-ajouter").click();
  await finit(async () => assert.equal(await p.locator(".acteur-ligne .champ-mini").count(), 6, "cinq rôles + la ligne de saisie"));
  await p.locator(".feuille .bouton.principal", { hasText: "Terminer" }).click();
  await rendu(p);
  await etroit.close();

  /* ---- 6) Le même contenu sur un écran LARGE : les voies se déploient ---- */
  const large = await navigateur.newContext({ viewport: { width: 900, height: 900 } });
  const q = await large.newPage();
  surveiller(q);
  await decor(q);
  await q.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    await app.creerComposition("À deux");
    const co = app.bibliotheque.compositions.at(-1);
    const tech = app.bibliotheque.techniques;
    await app.modifierComposition(co.id, (c) => {
      c.acteurs = [{ id: "r1", nom: "Tori" }, { id: "r2", nom: "Uke" }];
      c.blocs = [
        { id: "01JAAAAAAAAAAAAAAAAAAAAAA1", type: "technique", techniqueId: tech[0].id, acteurId: "r1", medias: [] },
        { id: "01JAAAAAAAAAAAAAAAAAAAAAA2", type: "technique", techniqueId: tech[1].id, acteurId: "r2", lien: true, medias: [] },
      ];
    });
    app.ouvrirComposition(co.id);
    await app.updateComplete;
  });
  await q.waitForSelector(".dialogue");
  await rendu(q);
  await finit(async () => {
    const entete = await q.locator(".dialogue-entete").first().evaluate((n) => getComputedStyle(n).display);
    assert.equal(entete, "grid", "à 900 px, deux voies tiennent : les rôles se nomment en tête de colonne");
  });
  assert.deepEqual(await q.locator(".dialogue-role").allTextContents(), ["Tori", "Uke"]);
  // UI-3 (D-321) : un SEUL bandeau porte ce que la composition pèse. Avant, un
  // résumé « N temps · Tori · Uke » vivait juste au-dessus d'un bandeau disant
  // « N étapes · Tori · Uke » — deux lieux, deux chiffres qui se contredisaient
  // à l'œil (un jalon fait un temps, pas une étape). D-253.
  assert.equal(await q.locator(".dialogue-resume").count(), 0, "plus de second résumé au-dessus du bandeau (D-321)");
  {
    const stats = await q.locator(".fiche-compo-stats").innerText();
    assert.match(stats, /étape/, "le bandeau dit les étapes : " + stats);
    assert.match(stats, /temps/, "…et les temps, dans le MÊME bandeau, pour qu'on puisse les comparer : " + stats);
    assert.match(stats, /Tori[\s\S]*Uke/, "…et les rôles, une seule fois : " + stats);
  }
  const roleVisible = await q.locator(".carte-role").first().evaluate((n) => getComputedStyle(n).position);
  assert.equal(roleVisible, "absolute", "la voie disant déjà le rôle, la carte ne le répète plus à l'œil (il reste lu)");
  await large.close();
}
