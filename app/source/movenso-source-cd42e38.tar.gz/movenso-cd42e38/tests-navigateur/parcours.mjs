/**
 * Parcours de l'incrément 1 dans un vrai Chromium (OPFS réel) — contrat §9.2.3.
 * Prérequis : `npm run build` (sert dist/). Échoue au premier écart.
 * Le harnais (serveur, navigateur, calibration D-103, aides de navigation)
 * vit dans harnais.mjs (S3.A7) — son import démarre serveur et navigateur.
 */
import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { unzipSync, zipSync } from "fflate";
import {
  serveur, navigateur, erreurs, surveiller, lent, traiterRattacher,
  allerMenuPlus, champsTousNommes, ouvrirPlus, glisser, revelerCreation,
  ouvrirSection, ouvrirCreationSection, allerBiblio, ouvrirDisc, gesteCapture, rendu, finit } from "./harnais.mjs";
import { run as chapitreDemarrageVide } from "./parcours/demarrage-vide.mjs";
import { run as chapitreCertificationSauvegarde } from "./parcours/certification-sauvegarde.mjs";
import { run as chapitreImportTransactionnel } from "./parcours/import-transactionnel.mjs";
import { run as chapitreEnvironnementNonSupporte } from "./parcours/environnement-non-supporte.mjs";
import { run as chapitreBibliothequeVide } from "./parcours/bibliotheque-vide.mjs";
import { run as chapitreZoom200 } from "./parcours/zoom-200.mjs";
import { run as chapitreEspaceInsuffisant } from "./parcours/espace-insuffisant.mjs";
import { run as chapitreIntegritePack } from "./parcours/integrite-pack.mjs";
import { run as chapitreReimportMemePack } from "./parcours/reimport-meme-pack.mjs";
import { run as chapitreIdentitePackRenommage } from "./parcours/identite-pack-renommage.mjs";
import { run as chapitreBasculeEtatAtomique } from "./parcours/bascule-etat-atomique.mjs";
import { run as chapitreAtomiciteMediaMetier } from "./parcours/atomicite-media-metier.mjs";
import { run as chapitreSauvegardeHonnete } from "./parcours/sauvegarde-honnete.mjs";
import { run as chapitreSnapshotRetention } from "./parcours/snapshot-retention.mjs";
import { run as chapitreExportDiagnostic } from "./parcours/export-diagnostic.mjs";
import { run as chapitrePinCapture } from "./parcours/pin-capture.mjs";
import { run as chapitrePublicationCibleExterne } from "./parcours/publication-cible-externe.mjs";
import { run as chapitreDefusionDoublons } from "./parcours/defusion-doublons.mjs";
import { run as chapitreCompositionAPlusieurs } from "./parcours/composition-a-plusieurs.mjs";
import { run as chapitreFiltresMolette } from "./parcours/filtres-molette.mjs";
import { run as chapitreRetraitsLiens } from "./parcours/retraits-liens.mjs";
import { run as chapitreAnnulationEdition } from "./parcours/annulation-edition.mjs";
import { run as chapitreVignettesDistantes } from "./parcours/vignettes-distantes.mjs";
import { run as chapitreImagesEnFichiers } from "./parcours/images-en-fichiers.mjs";

await chapitreDemarrageVide();

/* ===== Scénario B — import volontaire des packs (fixtures exigeantes) ===== */
const ctxB = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
const page = await ctxB.newPage();
surveiller(page);
const t0 = Date.now();
await page.goto("http://localhost:4517/");
await page.waitForSelector(".action-douce");
// D-223 : les Compositions sont en bêta OPT-IN (masquées par défaut) — le
// flux principal les active d'entrée, comme un utilisateur qui s'en sert.
await page.evaluate(() => document.querySelector("movenso-app").basculerReglage("compositionsBeta"));
await rendu(page);
// S2.14 (D-168) : la première ouverture DIT ce qu'est Movenso, que les
// données restent locales, et où se trouve la sauvegarde — sans tutoriel.
{
  const texteVide = await page.locator(".ecran").innerText();
  assert.ok(/mémoire du mouvement/i.test(texteVide), "l'accroche dit ce qu'est Movenso");
  assert.ok(/dans ta propre bibliothèque/i.test(texteVide), "l'accroche dit à qui est la bibliothèque");
  assert.ok(/démarre vide, choisis comment commencer/i.test(texteVide), "l'intro enchaîne sur le choix (D-327)");
  assert.ok(/restent sur cet appareil/.test(texteVide), "la localité des données est dite");
  assert.ok(/sauvegarde/i.test(texteVide) && /Plus › Sauvegardes/.test(texteVide), "le chemin de la sauvegarde est indiqué");
}
console.log(`démarrage à vide : ${Date.now() - t0} ms`);

async function importer(fichier, viaAtelier = false) {
  // D-071 : l'import vit dans l'état vide ET dans Plus › « Importer un pack »
  // (une ACTION, pas un sous-écran : la ligne déclenche le sélecteur de fichier).
  if (viaAtelier) {
    await allerMenuPlus(page);
    const [selecteur] = await Promise.all([
      page.waitForEvent("filechooser"),
      page.locator(".ligne-menu", { hasText: "Importer un pack" }).click(),
    ]);
    await selecteur.setFiles(new URL(`../donnees/${fichier}`, import.meta.url).pathname);
  } else {
    const [selecteur] = await Promise.all([
      page.waitForEvent("filechooser"),
      page.locator(".action-douce", { hasText: "Importer" }).click(),
    ]);
    await selecteur.setFiles(new URL(`../donnees/${fichier}`, import.meta.url).pathname);
  }
  // fusion PROPOSÉE, jamais subie (D-023) : le rapport s'affiche, on confirme.
  // Lot 6 §17 : l'aperçu annonce le contenu et le volume avant confirmation.
  // D-307 (MAJ-1) : sur un réimport STRICTEMENT identique, l'aperçu honnête
  // est « À jour — cette version ne change rien » — plus un compte d'ajouts.
  await page.waitForSelector(".feuille .actions .bouton.principal");
  const apercu = await page.locator(".feuille .points").innerText();
  assert.ok(
    ["ajout", "À jour", "diffère", "mise", "ne contient plus"].some((mot) => apercu.includes(mot)),
    "l'aperçu d'import doit annoncer le contenu du fichier",
  );
  await page.locator(".feuille .actions .bouton.principal").click();
  // lot 6 §18 : un RAPPORT après import remplace le simple toast
  const rapport = page.locator(".feuille[aria-label=\"Rapport d'import\"]");
  await rapport.waitFor();
  assert.ok((await rapport.innerText()).includes("installé ✓"), "le rapport d'import doit dire ce qui a changé");
  if (viaAtelier) {
    // §18 / D-292 : « Ouvrir la discipline » mène à la Bibliothèque FILTRÉE
    // sur le corpus importé — plus jamais vers l'écran que la navigation
    // courante ne dessert pas (R7-1, REC-B4-001).
    await rapport.locator(".bouton", { hasText: "Ouvrir la discipline" }).click();
    await page.waitForSelector(".chips-filtres .chip-discipline.actif");
    await allerBiblio(page); // les asserts suivants attendent la racine Bibliothèque
  } else {
    await rapport.locator(".actions .bouton.principal").click(); // Fermer — jamais de renvoi forcé
    await rendu(page);
  }
}
await importer("kodokan.json");
// 5.7 / NR-005-001 : une notification transitoire disparaît d'ELLE-MÊME
// après une durée courte — jamais des dizaines de secondes
await page.evaluate(() => document.querySelector("movenso-app").afficherToast("notification transitoire de test"));
await page.waitForSelector(".toast");
await page.waitForTimeout(lent(3600));
assert.equal(await page.locator(".toast").count(), 0, "le toast doit disparaître seul après ~3,4 s");
await importer("club-judo.json", true);
// boucle 2.0 : plus d'action Importer sur la racine peuplée
assert.equal(await page.locator(".ecran .action-douce", { hasText: "Importer" }).count(), 0, "Importer ne doit plus vivre sur la racine peuplée");
// D-067 : les deux packs judo rejoignent UNE discipline (les disciplines
// fusionnent par nom), mais les identités techniques ne fusionnent PAS.
{
  const chips = await page.locator(".chip-discipline").allInnerTexts();
  assert.equal(chips.filter((c) => c.includes("Judo")).length, 1, "les deux packs judo doivent rejoindre UNE discipline Judo : " + chips.join(" | "));
  assert.ok(!chips.some((c) => c.includes("club-judo")), "identifiant technique de pack visible sur une puce discipline");
  // l'en-tête de la discipline annonce un compte de techniques
  await ouvrirDisc(page, "Judo");
  await page.waitForSelector(".carte-technique");
  assert.match(await page.locator(".barre .contexte").innerText(), /Judo · \d+ technique/, "l'en-tête de discipline doit annoncer un compte de techniques");
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // retour racine
  await page.waitForSelector(".marque");
}

// lot 4 §2-4 (boucle 4.1) : panneau « Ajouter » sur la racine → création
// minimale d'une technique (nom + discipline), fiche ouverte ensuite
// (placé APRÈS l'assert des compteurs : la technique locale ajoute une source)
await page.locator(".fab", { hasText: "Ajouter" }).click();
await page.locator(".option-ajouter", { hasText: "Créer une technique" }).click();
await page.fill(".feuille .champ-nouveau-nom", "Essai du panneau");
await page.locator(".feuille .actions .bouton.principal", { hasText: "Créer la technique" }).click();
await page.waitForSelector(".edition"); // la fiche s'ouvre prête à compléter
await page.locator('.fiche-actions [aria-label="Enregistrer"]').click();
await page.locator(".fiche-entete h1", { hasText: "Essai du panneau" }).waitFor();
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → racine
await page.waitForSelector(".marque");

// lot 4 §5 (boucle 4.2) : doublons suggérés pendant la saisie — « Utiliser »
await page.locator(".fab", { hasText: "Ajouter" }).click();
await page.locator(".option-ajouter", { hasText: "Créer une technique" }).click();
await page.fill(".feuille .champ-nouveau-nom", "De Ashi Barai");
await finit(async () => assert.ok((await page.locator(".doublons").innerText()).includes("De-ashi-harai"), "la quasi-correspondance doit être suggérée pendant la saisie"));
assert.ok((await page.locator(".feuille .actions .bouton.principal").innerText()).includes("quand même"), "le bouton doit devenir « Créer quand même »");
await page.locator(".doublons .chip-filtre", { hasText: "De-ashi-harai" }).click(); // Utiliser cette technique
await page.locator(".fiche-entete h1", { hasText: "De-ashi-harai" }).waitFor();
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]");
await page.waitForSelector(".marque");
// correspondance exacte : la création séparée exige une confirmation explicite
await page.locator(".fab", { hasText: "Ajouter" }).click();
await page.locator(".option-ajouter", { hasText: "Créer une technique" }).click();
await page.fill(".feuille .champ-nouveau-nom", "Essai du panneau");
await finit(async () => assert.equal(await page.locator(".doublon-exacte").count(), 1, "correspondance exacte non signalée"));
await page.locator(".feuille .actions .bouton.principal").click();
// C2 : la garde de doublon exact passe par la feuille de confirmation nommée
await page.waitForSelector(".feuille-confirmation");
assert.ok((await page.locator(".feuille-confirmation h2").innerText()).includes("existe déjà"), "créer un doublon exact doit exiger une confirmation explicite");
await page.locator(".voile").last().click(); // refus
await finit(async () => {
  assert.equal(await page.locator(".feuille-confirmation").count(), 0, "le voile referme la garde");
  assert.equal(await page.locator(".feuille").count(), 1, "refus de confirmation → rien de créé, la saisie reste");
});
// lot 4 §4 : « Classer maintenant » facultatif (l'appellation traditionnelle a
// été retirée du formulaire d'ajout rapide, D-109)
await page.fill(".feuille .champ-nouveau-nom", "Essai classé");
await page.locator(".feuille .action-douce", { hasText: "Classer maintenant" }).click();
await page.locator(".classer-maintenant .chip-filtre", { hasText: "Koshi-waza" }).click();
await page.locator(".classer-maintenant .chip-filtre", { hasText: "Jaune" }).click();
await page.locator(".feuille .actions .bouton.principal").click();
await page.waitForSelector(".edition");
await page.locator('.fiche-actions [aria-label="Enregistrer"]').click();
await page.locator(".fiche-entete h1", { hasText: "Essai classé" }).waitFor();
const familleFiche = (await page.locator(".fiche-famille").innerText()).toLowerCase();
const pastilles = await page.locator(".pastilles").innerText();
assert.ok(familleFiche.includes("koshi-waza") && pastilles.includes("Jaune"), "classement facultatif absent de la fiche : " + familleFiche + " / " + pastilles);
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]");
await page.waitForSelector(".marque");

// lot 4 §6-7 (boucle 4.3) : capture par le contenu — l'aperçu du lien détecte
// le service, Abandonner vide sans rien enregistrer, « Sais-tu où le ranger ? »
await page.locator(".chip-discipline", { hasText: "Judo" }).click();
await page.waitForSelector(".carte-technique");
await page.locator(".fab", { hasText: "Ajouter" }).click();
await gesteCapture(page, "lien");
await page.waitForSelector(".feuille .creation-discipline input");
await page.fill(".feuille .creation-discipline input", "https://youtu.be/abc12345def");
await page.locator(".feuille .creation-discipline .bouton.principal").click();
await page.waitForSelector(".apercu-lien");
assert.ok((await page.locator(".apercu-infos").innerText()).includes("YouTube"), "le service du lien doit être détecté à l'aperçu");
await page.locator(".feuille .actions .bouton", { hasText: "Abandonner" }).click();
await finit(async () => assert.equal(await page.locator(".apercu-lien").count(), 0, "Abandonner doit vider le contenu sans rien enregistrer"));
await page.fill(".feuille .creation-discipline input", "https://youtu.be/abc12345def");
await page.locator(".feuille .creation-discipline .bouton.principal").click();
await page.waitForSelector(".apercu-lien");
await page.locator(".feuille .actions .bouton.principal", { hasText: "Utiliser" }).click();
await page.fill(".champ-note", "verrouiller le poignet");
await page.click(".feuille .actions .bouton.principal"); // Rattacher →
assert.ok((await page.locator(".feuille .geste").innerText()).toLowerCase().includes("sais-tu où le ranger"), "la question du rattachement doit être posée");
assert.ok((await page.locator(".feuille .actions").innerText()).includes("Garder pour plus tard"), "« Garder pour plus tard » attendu");
await page.fill(".feuille .recherche input", "essai du panneau");
await rendu(page);
await page.locator(".feuille .resultat", { hasText: "Essai du panneau" }).first().click();
await page.locator(".fiche-entete h1", { hasText: "Essai du panneau" }).waitFor();
// carnet→commentaire : le texte d'une capture personnelle rattachée vit dans la zone Commentaire
assert.ok((await page.locator(".commentaire-zone").inputValue()).includes("verrouiller le poignet"), "la capture rattachée doit vivre sur la fiche (commentaire)");
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → explorateur Judo
await page.waitForSelector(".carte-technique");
// S1.3 (D-164) : le validateur CENTRAL refuse tout lien non https — un
// javascript:/http: passé à l'édition de lien ne mute RIEN et dit pourquoi.
{
  const refusLien = await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const media = app.bibliotheque.contributions.flatMap((c) => c.medias).find((m) => m.type === "plateforme");
    const refAvant = media.ref;
    app.toast = "";
    await app.majMediaLien(media.id, "javascript:alert(1)");
    const toastJs = app.toast;
    app.toast = "";
    await app.majMediaLien(media.id, "http://exemple.org/v");
    const toastHttp = app.toast;
    const refApres = app.bibliotheque.contributions.flatMap((c) => c.medias).find((m) => m.id === media.id).ref;
    return { toastJs, toastHttp, refAvant, refApres };
  });
  assert.match(refusLien.toastJs, /refusé|https/i, "javascript: est refusé avec un message clair : " + refusLien.toastJs);
  assert.match(refusLien.toastHttp, /https/, "http: est refusé en disant que https est attendu : " + refusLien.toastHttp);
  assert.equal(refusLien.refApres, refusLien.refAvant, "un lien refusé ne mute jamais le média");
}

// lot 4 §8 (boucle 4.4) : personnel par défaut — la provenance vit derrière
// « Ce contenu vient de quelqu'un d'autre » ; un enseignement attribué
// devient une voix Enseignement, jamais du carnet personnel
await page.locator(".fab", { hasText: "Ajouter" }).click();
await gesteCapture(page, "note");
assert.equal(await page.locator(".feuille .chip-filtre").count(), 0, "aucun choix de provenance ne doit s'imposer par défaut (§8)");
await page.fill(".champ-note", "Kumi-kata : coude fermé, main haute.");
await page.locator(".feuille .autre-provenance").click();
await page.locator(".feuille .chip-filtre", { hasText: "Mon prof / club" }).click();
await page.fill('.feuille input[placeholder^="Qui l' + "'" + 'enseigne"]', "Sensei Dupont");
await page.click(".feuille .actions .bouton.principal"); // Rattacher →
await page.fill(".feuille .recherche input", "essai du panneau");
await rendu(page);
await page.locator(".feuille .resultat", { hasText: "Essai du panneau" }).first().click();
await page.locator(".fiche-entete h1", { hasText: "Essai du panneau" }).waitFor();
// D-067 : la fiche mono-pack montre UNE présentation ; un enseignement attribué
// reste une contribution « enseignement » (distincte du carnet personnel) —
// vérifié par les données et par la présentation lue.
const infoEns = await page.evaluate(() => {
  const app = document.querySelector("movenso-app");
  const t = app.bibliotheque.techniques.find((x) => x.nom === "Essai du panneau");
  const c = app.bibliotheque.contributions.find((x) => x.techniqueId === t.id && x.attribution === "Sensei Dupont");
  return { provenance: c?.provenance ?? null };
});
assert.equal(infoEns.provenance, "enseignement", "l'enseignement attribué doit devenir une contribution « enseignement », pas une note de carnet");
assert.ok((await page.locator(".bloc-lecture:not(.commentaire)").first().innerText()).includes("Kumi-kata"), "le texte de l'enseignement doit apparaître dans la présentation de la fiche");
assert.ok(!(await page.locator(".commentaire-zone").inputValue()).includes("Kumi-kata"), "l'enseignement ne doit pas tomber dans le commentaire personnel");
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → explorateur Judo
await page.waitForSelector(".carte-technique");

// lot 4 §9 (boucle 4.4) : une capture NON personnelle se garde pour plus tard,
// sa provenance est conservée ; en reprise elle se lit, se modifie, se supprime
await page.locator(".fab", { hasText: "Ajouter" }).click();
await gesteCapture(page, "note");
await page.fill(".champ-note", "Passage vu en vidéo, à retrouver.");
await page.locator(".feuille .autre-provenance").click();
await page.locator(".feuille .chip-filtre", { hasText: "Une ressource" }).click();
await page.fill('.feuille input[placeholder^="Source"]', "Chaîne BJJ");
await page.click(".feuille .actions .bouton.principal");
await page.locator(".feuille .actions .bouton", { hasText: "Garder pour plus tard" }).click();
// D-107 : « à rattacher » vit désormais dans Plus › « À traiter »
await ouvrirPlus(page, "À traiter");
const kpiRattacher = () => page.locator(".kpi").filter({ has: page.locator(".kpi-libelle", { hasText: "Captures à rattacher" }) });
assert.equal(Number(await kpiRattacher().locator(".kpi-nombre").innerText()), 1, "la capture de ressource doit apparaître « à rattacher » avec sa provenance");
await traiterRattacher(page);
await page.waitForSelector(".reprise-contenu");
assert.ok((await page.locator(".reprise-contenu textarea").inputValue()).includes("Passage vu"), "le contenu de la capture doit se consulter en reprise");
assert.ok((await page.locator(".reprise-contenu .apercu-infos").innerText()).includes("Ressource · Chaîne BJJ"), "la provenance conservée doit être visible");
await page.fill(".reprise-contenu textarea", "Passage vu en vidéo — demi-garde.");
await page.locator(".reprise-contenu .action-douce", { hasText: "Supprimer cette capture" }).click();
await page.waitForSelector(".feuille-confirmation"); // C2 : feuille nommée
await page.locator(".feuille-confirmation .bouton.danger").click();
await finit(async () => assert.equal(Number(await kpiRattacher().locator(".kpi-nombre").innerText()), 0, "la capture supprimée doit disparaître d'« à rattacher »"));
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // Bibliothèque (mémoire : explorateur)
await page.waitForSelector(".carte-technique");

// lot 4 §11 (boucle 4.5) : ajouter un contenu DEPUIS la fiche sans redemander
// la technique. La fiche mono-pack (D-067) porte le carnet personnel : on y
// ajoute une note directement (les contributions sourcées viennent des packs).
await page.fill(".ecran .recherche input", "essai classé");
await rendu(page);
await page.locator(".carte-technique").first().locator(".carte-ouvrir").click();
await page.waitForSelector(".fiche-entete h1");
await page.fill(".commentaire-zone", "Entrée en tai-otoshi d'abord, saisie haute."); // la zone Commentaire est toujours visible
await page.locator(".commentaire-zone").blur(); // blur → change → enregistrement
await finit(async () => assert.ok((await page.locator(".commentaire-zone").inputValue()).includes("tai-otoshi"), "la note ajoutée depuis la fiche doit vivre dans le commentaire, sans redemander la technique"));
// D-105 / D-110 : la croix ✕ (« Annuler l'édition ») DÉFAIT les modifications
// auto-enregistrées — le TEXTE et le FAVORI (bugs silencieux, gardés ici).
await page.locator('.barre [aria-label="Modifier"]').click();
await page.waitForSelector(".edition");
await page.locator(".etoile-favori").click(); // activer le favori PENDANT l'édition
await finit(async () =>
  assert.equal(await page.locator(".etoile-favori.actif").count(), 1, "le favori s'active en édition"));
await page.fill(".commentaire-zone", "MODIF A ANNULER");
await page.locator(".commentaire-zone").blur();
await rendu(page);
await page.locator(`.barre [aria-label="Annuler l'édition"]`).click();
await finit(async () => {
  assert.equal(await page.locator(".etoile-favori.actif").count(), 0, "✕ doit défaire le favori activé en édition (D-110)");
  const commentaire = await page.locator(".commentaire-zone").inputValue();
  assert.ok(commentaire.includes("tai-otoshi") && !commentaire.includes("MODIF A ANNULER"), "✕ doit défaire les modifications de texte (D-105) : " + commentaire);
});
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → explorateur
await page.waitForSelector(".carte-technique");
await page.fill(".ecran .recherche input", ""); // repartir propre
await rendu(page);

// lot 4 §16 (boucle 4.5) : retour Android par étapes — sans contenu on sort,
// avec contenu la question « Que faire de cette capture ? » protège
await page.locator(".fab", { hasText: "Ajouter" }).click();
await gesteCapture(page, "note");
await page.evaluate(() => document.querySelector("movenso-app").reculerCapture()); // note vide → contenu
await page.evaluate(() => document.querySelector("movenso-app").reculerCapture()); // contenu vide → fermé
await finit(async () => assert.equal(await page.locator(".feuille").count(), 0, "sans contenu, le retour sort sans confirmation inutile"));
await page.locator(".fab", { hasText: "Ajouter" }).click();
await gesteCapture(page, "note");
await page.fill(".champ-note", "test retour par étapes");
await page.evaluate(() => document.querySelector("movenso-app").reculerCapture());
await finit(async () => assert.ok((await page.locator(".feuille .geste").innerText()).includes("Que faire de cette capture"), "un contenu existant doit poser la question avant de sortir"));
await page.locator(".option-ajouter", { hasText: "Continuer" }).click();
await finit(async () => assert.equal(await page.locator(".champ-note").inputValue(), "test retour par étapes", "Continuer doit revenir où on en était, contenu intact"));
await page.evaluate(() => document.querySelector("movenso-app").reculerCapture());
await page.locator(".option-ajouter", { hasText: "Garder pour plus tard" }).click();
await ouvrirPlus(page, "À traiter"); // D-107 : « à rattacher » vit dans « À traiter »
assert.equal(Number(await kpiRattacher().locator(".kpi-nombre").innerText()), 1, "la capture gardée depuis la question doit rejoindre « à rattacher »");
await traiterRattacher(page);
await page.waitForSelector(".reprise-contenu");
await page.locator(".reprise-contenu .action-douce", { hasText: "Supprimer cette capture" }).click();
await page.waitForSelector(".feuille-confirmation"); // C2 : feuille nommée
await page.locator(".feuille-confirmation .bouton.danger").click();
await rendu(page);
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // Bibliothèque (mémoire : explorateur)
await page.waitForSelector(".carte-technique");
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // second appui : racine
await page.waitForSelector(".marque");

// lot 5 §4-6 (boucle 5.1) : favoris — marque-page immédiat, réversible,
// visible dans l'onglet Favoris, la technique reste intacte dans la Bibliothèque
await page.fill(".recherche input", "essai du panneau");
await rendu(page);
await page.locator(".carte-technique", { hasText: "Essai du panneau" }).first().locator(".carte-ouvrir").click();
await page.waitForSelector(".fiche-entete h1");
assert.equal(await page.locator(".etoile-favori.actif").count(), 0, "pas favorite au départ");
await page.locator(".etoile-favori").click();
await finit(async () => assert.equal(await page.locator(".etoile-favori.actif").count(), 1, "l'étoile doit refléter l'état favori (forme, pas couleur seule)"));
await page.locator(".barre-nav .nav-onglet", { hasText: "Favoris" }).click(); // onglet Favoris (D-071)
await page.waitForSelector(".carte-technique");
const favori = page.locator(".carte-technique", { hasText: "Essai du panneau" });
assert.equal(await favori.count(), 1, "la favorite doit apparaître dans l'onglet Favoris");
await favori.locator(".carte-ouvrir").click(); // toucher → fiche
await page.locator(".fiche-entete h1", { hasText: "Essai du panneau" }).waitFor();
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → Favoris
await page.waitForSelector(".marque");
await favori.locator(".coeur.actif").click(); // retrait immédiat depuis la carte, SANS confirmation
await finit(async () => assert.equal(await page.locator(".carte-technique").count(), 0, "le retrait doit être immédiat"));
assert.ok((await page.locator(".fil-vide").innerText()).includes("Ajoute-en depuis la Bibliothèque"), "état vide des Favoris attendu");
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // Bibliothèque (mémoire : la fiche)
await page.locator(".fiche-entete h1", { hasText: "Essai du panneau" }).waitFor(); // la technique est intacte
await page.locator(".etoile-favori").click(); // re-favorite : doit voyager dans la sauvegarde intégrale (scénario J)
await rendu(page);
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → racine
await page.waitForSelector(".marque");
await page.fill(".recherche input", "");

// D-067 (dé-fusion) : deux packs judo partageant un nom produisent DEUX fiches
// distinctes, départagées par leur source — jamais une fiche composite.
await page.fill(".recherche input", "harai goshi");
await rendu(page);
const cartesHarai = page.locator(".carte-technique").filter({ has: page.locator(".carte-nom", { hasText: /Harai.?[Gg]oshi/ }) });
assert.ok((await cartesHarai.count()) >= 2, "les deux Harai-goshi (Kodokan et Club) doivent coexister");
// tuning post-V3 : le badge de source a disparu des cartes ; les deux fiches
// homonymes restent DISTINCTES, départagées par leur nom exact (Kodokan
// « Harai-goshi », Club « Harai Goshi ») et par des identités séparées.
const nomsHarai = (await cartesHarai.locator(".carte-nom").allInnerTexts()).map((s) => s.trim());
assert.ok(new Set(nomsHarai).size >= 2, "deux fiches homonymes distinctes attendues : " + nomsHarai.join(" | "));
// ouvrir la fiche Kodokan — elle ne porte QUE le contenu de son pack
const carteKodokan = page.locator(".carte-technique").filter({ has: page.locator(".carte-nom", { hasText: /^Harai-goshi$/ }) }).first();
await carteKodokan.locator(".carte-ouvrir").click();
await page.waitForSelector(".fiche-entete h1");
// lot 3 boucle 3.7 : l'en-tête fixe identifie la technique ouverte
assert.match(await page.locator(".barre .contexte").innerText(), /Harai/i, "l'en-tête fixe doit porter la technique");
assert.ok((await page.locator(".bloc-lecture:not(.commentaire)").count()) >= 1, "la fiche doit montrer une présentation (mono-pack)");
assert.ok(!(await page.locator(".ecran").innerText()).includes("Terminer"), "« Terminer » ne doit plus exister sur la fiche");
const texteKodokan = await page.locator(".bloc-lecture").first().innerText();
// lot 3 §5 : ajouter un média depuis la fiche sans la quitter ni redemander la
// technique — l'entrée passe par l'édition (« Ajouter un média »).
await page.locator('.barre [aria-label="Modifier"]').click();
await page.waitForSelector(".edition-medias");
await page.locator(".edition-medias .action-douce", { hasText: "Ajouter un média" }).click();
await page.waitForSelector(".feuille[aria-label=\"Ajouter un média\"]");
assert.ok(!(await page.locator(".feuille").innerText()).includes("À quelle technique"), "la feuille média ne doit jamais redemander la technique");
await champsTousNommes(page, "fiche en édition + feuille Ajouter un média");
// S2.10 (tranche 2) : la feuille est une VRAIE modale — aria-modal, focus
// dedans à l'ouverture, Échap ferme, focus RENDU à l'ouvreur.
assert.equal(await page.locator('.feuille[aria-modal="true"]').count(), 1, "la feuille porte aria-modal (S2.10)");
assert.ok(
  await page.evaluate(() => document.querySelector(".feuille")?.contains(document.activeElement)),
  "à l'ouverture, le focus est DANS la feuille (S2.10)",
);
await page.keyboard.press("Escape");
await finit(async () => assert.equal(await page.locator(".feuille").count(), 0, "Échap ferme la feuille (S2.10)"));
assert.ok(
  await page.evaluate(() => document.activeElement?.classList?.contains("action-douce")),
  "le focus revient à l'ouvreur après la fermeture (S2.10)",
);
await page.locator(".edition-medias .action-douce", { hasText: "Ajouter un média" }).click();
await page.waitForSelector('.feuille[aria-label="Ajouter un média"]');
await page.locator(".feuille .action-douce", { hasText: "Coller un lien" }).click();
await page.fill(".feuille .creation-discipline input", "https://www.youtube.com/watch?v=abcdef00042");
await page.locator(".feuille .creation-discipline .bouton.principal").click();
await page.locator(".feuille .chip-filtre", { hasText: "Une ressource" }).click();
assert.ok(await page.locator(".feuille .actions .bouton.principal").isDisabled(), "une ressource sans attribution ne doit pas être ajoutable");
await page.fill('.feuille input[placeholder^="Source"]', "Chaîne Kodokan TV");
await page.fill(".feuille .champ-libelle", "vue de côté");
await page.locator(".feuille .actions .bouton.principal").click();
await page.waitForSelector(".toast");
await finit(async () => assert.equal(await page.locator(".feuille").count(), 0, "la feuille média doit se fermer après l'ajout"));
// D-091 : on reste en édition ; le média ajouté est un bloc portant son titre
await page.waitForSelector(".edition-medias");
const titresEdit = await page.locator('.bloc-media-edition input[aria-label="Titre de la vidéo"]').evaluateAll((els) => els.map((e) => e.value));
assert.ok(titresEdit.includes("vue de côté"), "le média ajouté doit apparaître comme un bloc, avec son libellé");
// une seule vidéo principale (badge) ; « ★ Définir comme principale » sur les autres
assert.equal(await page.locator(".bloc-media-edition .badge-principal").count(), 1, "une seule vidéo principale à la fois (badge)");
await page.locator(".bloc-media-edition button", { hasText: "Définir comme principale" }).first().click();
await finit(async () => {
  const titrePrincipal = await page.evaluate(() => {
    const bloc = [...document.querySelectorAll(".bloc-media-edition")].find((b) => b.querySelector(".badge-principal"));
    return bloc ? bloc.querySelector('input[aria-label="Titre de la vidéo"]').value : null;
  });
  assert.equal(titrePrincipal, "vue de côté", "« Définir comme principale » applique le choix au bon média");
});
await page.locator('.fiche-actions [aria-label="Enregistrer"]').click().catch(() => {});
await rendu(page);
// NR-003-002 : un seul lecteur média actif — déplier le média affiché
if ((await page.locator(".media-principal .bouton-video").count()) >= 1) {
  await page.locator(".media-principal .bouton-video").first().click();
  await finit(async () => assert.equal(await page.locator(".media-video iframe").count(), 1, "un seul lecteur média actif à la fois (NR-003-002)"));
}
// réimport idempotent (D-067 propriété 4) : réimporter kodokan ne casse rien,
// et le média local ajouté à la fiche survit (contribution locale préservée).
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour racine
await page.waitForSelector(".marque");
await importer("kodokan.json", true);
await page.fill(".recherche input", "harai goshi");
await rendu(page);
const carteKodokan2 = page.locator(".carte-technique")
  .filter({ has: page.locator(".carte-nom", { hasText: /^Harai-goshi$/ }) })
  .first();
await carteKodokan2.locator(".carte-ouvrir").click();
await page.waitForSelector(".fiche-entete h1");
assert.ok((await page.locator(".media-choix .chip-filtre", { hasText: "vue de côté" }).count()) >= 1, "le média local ajouté doit survivre au réimport (idempotence)");
assert.equal((await page.locator(".bloc-lecture").first().innerText()).trim(), texteKodokan.trim(), "la présentation du pack doit revenir identique après réimport");
// D-157 : conflit de liaison à l'import — une raison ÉDITÉE localement (D-156)
// diverge du pack au réimport → détectée (jamais écrasée ni ignorée en
// silence), annoncée dans le rapport, arbitrée dans Plus › Relations.
await page.evaluate(async () => {
  const app = document.querySelector("movenso-app");
  const src = app.bibliotheque.techniques.find((t) => t.relations.some((r) => r.type === "enchaine" && typeof r.note === "string"));
  const r = src.relations.find((x) => x.type === "enchaine" && typeof x.note === "string");
  await app.modifierRelation(src.id, r.cibleId, "enchaine", { note: "raison éditée localement e2e" });
});
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]");
await page.waitForSelector(".marque");
await importer("kodokan.json", true);
await allerMenuPlus(page);
await page.locator(".ligne-menu", { hasText: "Relations entre techniques" }).click();
await page.waitForSelector(".conflit-liaison");
assert.equal(await page.locator(".conflit-liaison").count(), 1, "UN conflit de liaison à arbitrer après réimport");
assert.ok((await page.locator(".conflit-liaison").innerText()).includes("raison éditée localement e2e"), "la version locale est montrée");
// Arbitrage « Celle du pack » : la raison du pack remplace la locale, l'entrée disparaît.
await page.locator(".conflit-liaison .chip-filtre", { hasText: "Celle du pack" }).click();
await finit(async () => assert.equal(await page.locator(".conflit-liaison").count(), 0, "le conflit arbitré disparaît"));
const noteApres = await page.evaluate(() => {
  const app = document.querySelector("movenso-app");
  return app.bibliotheque.techniques.flatMap((t) => t.relations).some((r) => r.note === "raison éditée localement e2e");
});
assert.equal(noteApres, false, "« Celle du pack » remplace la raison locale");
await allerBiblio(page);
await page.fill(".recherche input", "harai goshi");
await rendu(page);
await page.locator(".carte-technique").filter({ has: page.locator(".carte-nom", { hasText: /^Harai-goshi$/ }) }).first().locator(".carte-ouvrir").click();
await page.waitForSelector(".fiche-entete h1");
// D-091 : retrait d'un média depuis l'édition — le bloc disparaît (snapshot conservé)
await page.locator('.barre [aria-label="Modifier"]').click();
await page.waitForSelector(".edition-medias");
const nbBlocsAvant = await page.locator(".bloc-media-edition").count();
await page.evaluate(() => {
  const bloc = [...document.querySelectorAll(".bloc-media-edition")].find(
    (b) => b.querySelector('input[aria-label="Titre de la vidéo"]').value === "vue de côté",
  );
  bloc?.querySelector(".bouton-retrait-media")?.click();
});
await finit(async () => {
  const titresApresRetrait = await page.locator('.bloc-media-edition input[aria-label="Titre de la vidéo"]').evaluateAll((els) => els.map((e) => e.value));
  assert.ok(!titresApresRetrait.includes("vue de côté"), "le média retiré doit disparaître de l'édition (D-091)");
  assert.equal(await page.locator(".bloc-media-edition").count(), nbBlocsAvant - 1, "le retrait enlève exactement un bloc média");
});
await page.locator('.fiche-actions [aria-label="Enregistrer"]').click().catch(() => {});
await rendu(page);
// D-096 : garde-fou d'espace à l'ajout d'un média — refus AVANT écriture quand
// l'estimation est fiable et insuffisante (comme à l'import).
{
  const nbAvant = await page.evaluate(() => document.querySelector("movenso-app").bibliotheque.contributions.length);
  const toastRefus = await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const t = app.bibliotheque.techniques[0];
    const orig = navigator.storage.estimate.bind(navigator.storage);
    navigator.storage.estimate = async () => ({ usage: 0, quota: 1000 }); // ~1 Ko « disponible »
    await app.ajouterMediaFiche(t.id, { fichier: new File([new Uint8Array(50000)], "grosse.webm", { type: "video/webm" }) });
    navigator.storage.estimate = orig;
    return app.toast || "";
  });
  assert.match(toastRefus, /espace insuffisant/i, "un média trop gros pour l'espace doit être refusé AVANT écriture");
  assert.equal(
    await page.evaluate(() => document.querySelector("movenso-app").bibliotheque.contributions.length),
    nbAvant,
    "aucune contribution ne doit être ajoutée quand l'espace manque",
  );
  // D-097 : une limite volontaire borne le garde-fou même si le système a de la place.
  const toastLimite = await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const t = app.bibliotheque.techniques[0];
    await app.changerLimiteEspace(200); // plafond 200 Mo
    const orig = navigator.storage.estimate.bind(navigator.storage);
    navigator.storage.estimate = async () => ({ usage: 190_000_000, quota: 100_000_000_000 }); // système large, mais près du plafond
    await app.ajouterMediaFiche(t.id, { fichier: new File([new Uint8Array(5_000_000)], "clip.webm", { type: "video/webm" }) });
    const toast = app.toast || "";
    navigator.storage.estimate = orig;
    await app.changerLimiteEspace(5000); // remettre le défaut 5 Go
    return toast;
  });
  assert.match(toastLimite, /espace insuffisant/i, "la limite volontaire doit borner l'espace même quand le système en a");
}
// D-098 : panneau de progression à l'écriture (état forcé — rendu déterministe).
await page.evaluate(() => {
  const app = document.querySelector("movenso-app");
  app.enregistrementMedia = { phase: "ecriture", fraction: 0.42, octets: 8_000_000, etaSec: 3 };
  app.requestUpdate();
});
await page.waitForSelector(".feuille-progression");
assert.match(await page.locator(".feuille-progression").innerText(), /42\s?%/, "le panneau affiche le pourcentage réel");
assert.equal(await page.locator(".feuille-progression .barre-progression-jauge").count(), 1, "le panneau porte une jauge de progression");
await page.evaluate(() => { const app = document.querySelector("movenso-app"); app.enregistrementMedia = null; app.requestUpdate(); });
await finit(async () => assert.equal(await page.locator(".feuille-progression").count(), 0, "le panneau disparaît à la fin de l'écriture"));
// lot 2 §4 : retour depuis le résultat → requête, résultats et contexte restaurés
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]");
await page.waitForSelector(".marque");
assert.equal(await page.locator(".recherche input").inputValue(), "harai goshi", "requête globale perdue au retour");
assert.ok((await page.locator(".carte-technique").count()) >= 1, "résultats globaux perdus au retour");
assert.ok((await page.locator(".carte-technique .carte-nom").count()) >= 1, "le résultat doit porter son identité");
await page.fill(".recherche input", ""); // repartir propre

// exploration (qualité V2 — D-012) : racine Bibliothèque → une seule carte
// Judo (les deux packs ont rejoint UNE discipline) — grille, filtres cumulables
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
await page.waitForSelector(".chip-discipline");
assert.equal(await page.locator(".chip-discipline").count(), 1, "les deux packs doivent rejoindre UNE discipline Judo");
await ouvrirDisc(page, "Judo");
await page.waitForSelector(".carte-technique");
assert.ok((await page.locator(".barre .contexte").innerText()).includes("Judo"), "explorateur Judo attendu");
const total = await page.locator(".carte-technique").count();
assert.ok(total >= 130, "grille incomplète (bibliothèque réunie attendue)");
await page.locator(".chip-filtre", { hasText: "Jaune" }).click(); // filtre ceinture (du club, sur la discipline réunie)
const filtreCeinture = await page.locator(".carte-technique").count();
assert.ok(filtreCeinture > 0 && filtreCeinture < total, "filtre ceinture inopérant");
await page.locator(".chip-filtre", { hasText: "Jaune" }).click(); // dé-filtre
await rendu(page);
// lot 2 §9 : filtres cumulés sans résultat → message dédié + réinitialisation
await page.locator(".chip-filtre", { hasText: "Jaune" }).click();
await page.fill(".ecran .recherche input", "zzzz-introuvable");
await finit(async () => assert.ok((await page.locator(".sans-resultat").innerText()).includes("Aucune technique ne correspond"), "état « aucun résultat » indistinct"));
await page.locator(".chip-filtre.reinitialiser").click();
await finit(async () => assert.equal(await page.locator(".carte-technique").count(), total, "la réinitialisation doit rendre la grille complète"));
assert.equal(await page.locator(".ecran .recherche input").inputValue(), "", "la réinitialisation doit vider la recherche locale");
assert.equal(await page.locator(".chip-filtre.reinitialiser").count(), 0, "Réinitialiser ne s'affiche que si un filtre est actif");
// lot 2 §6-8 (scénario C) : le FILTRE par source a été retiré de la grille
// (tuning post-V3, comme le badge de source sur les cartes). On vérifie
// autrement l'invariant D-067 : jamais de slug de pack dans les puces, et
// deux identités « Harai-goshi » distinctes, chacune rattachée à sa source
// éditoriale (« Kodokan » / « Club judo », jamais un slug).
{
  const chips = await page.locator(".chips-filtres .chip-filtre").allInnerTexts();
  assert.ok(!chips.some((c) => c.includes("club-judo")), "identifiant technique de pack dans les chips : " + chips.join(", "));
}
{
  const infoDefusion = await page.evaluate(() => {
    const app = document.querySelector("movenso-app");
    const harai = app.bibliotheque.techniques.filter((t) => /harai.?goshi/i.test(t.nom));
    const libelle = (src) => (src === "local" ? "Mon contenu" : src.replace(/^pack-/, "").replaceAll("-", " ").replace(/^./, (c) => c.toUpperCase()));
    return {
      noms: harai.map((t) => t.nom),
      packs: harai.map((t) => t.origine?.pack ?? "local"),
      libelles: harai.map((t) => libelle(t.origine?.pack ?? "local")),
    };
  });
  assert.ok(new Set(infoDefusion.noms).size >= 2, "deux identités Harai-goshi distinctes : " + infoDefusion.noms.join(" | "));
  assert.ok(new Set(infoDefusion.packs).size >= 2, "les deux fiches viennent de sources distinctes : " + infoDefusion.packs.join(" | "));
  assert.ok(infoDefusion.libelles.some((l) => l === "Kodokan") && infoDefusion.libelles.some((l) => l === "Club judo"), "libellés éditoriaux des sources attendus : " + infoDefusion.libelles.join(" | "));
  assert.ok(!infoDefusion.libelles.some((l) => l.includes("club-judo")), "jamais de slug de pack dans le libellé de source");
}
// D-138 R5/R19 : relations DANS la fiche — « Relations · N », aperçu compact
// groupé par rôle (≤2 liens/rôle) ; une ligne ouvre la fiche cible ; « Voir
// toutes les relations » ouvre l'écran Relations en vue Liste centré sur la
// technique. (Juji Gatame porte >3 relations : l'aperçu est GARANTI capé.)
await page.fill(".ecran .recherche input", "juji gatame");
await rendu(page);
await page.locator(".carte-technique").first().click();
await page.waitForSelector(".liaisons.relations");
const etiquetteRel = await page.locator(".liaisons.relations .section-titre").innerText();
const nbRelations = Number(etiquetteRel.match(/relations · (\d+)/i)?.[1]);
assert.ok(Number.isInteger(nbRelations) && nbRelations > 3, "fiche à plus de 3 relations attendue : " + etiquetteRel);
const apercuFiche = await page.locator(".liaisons.relations .rel-ligne").count();
assert.ok(apercuFiche >= 1 && apercuFiche <= nbRelations, "aperçu compact des relations attendu (" + apercuFiche + " / " + nbRelations + ")");
assert.equal(await page.locator(".liaisons.relations .rel-fiche-toutes").count(), 1, "un accès « Voir toutes les relations » est présent");
// §19 : naviguer par une ligne de relation puis revenir rouvre la fiche d'origine
await page.locator(".liaisons.relations button.rel-ligne").first().click();
await page.waitForSelector(".fiche-entete h1");
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour à la fiche d'origine
await page.waitForSelector(".liaisons.relations");
assert.match(await page.locator(".barre .contexte").innerText(), /juji.?gatame/i, "le retour doit rouvrir la fiche d'origine (§19)");
// « Voir toutes les relations » → écran Relations en vue Liste
await page.locator(".liaisons.relations .rel-fiche-toutes").click();
await page.waitForSelector(".ecran-relations");
assert.equal((await page.locator(".rel-vue-onglet.actif").innerText()).trim(), "Liste", "« Voir toutes » ouvre l'écran Relations en vue Liste");
await page.waitForSelector(".rel-listes");
// R14 : chips de filtre par rôle (défilables) + carte centrale collante
assert.ok((await page.locator(".rel-filtres .rel-chip").count()) >= 2, "chips de filtre par rôle présents dans la Liste");
assert.equal(await page.evaluate(() => getComputedStyle(document.querySelector(".rel-centre")).position), "sticky", "la carte centrale de la Liste est collante (R14)");
// D-140 : la vue « Carte » se rend en mindmap HTML pannable/zoomable (hub +
// cartes-vignettes reliées, transform CSS). On exerce le rendu (le harnais
// échoue sur toute erreur JS) et la bascule plein écran.
await page.locator(".rel-vue-onglet", { hasText: "Carte" }).click();
await page.waitForSelector(".rel-carte-scene");
assert.ok(await page.locator(".rel-carte-liens").getAttribute("viewBox"), "la Carte doit poser le viewBox de ses liens");
assert.ok((await page.locator(".rel-carte-carte").count()) >= 2, "la Carte affiche le hub + des cartes-vignettes");
// Le fit initial (rAF) pose un transform « translate(...) scale(...) » sur la scène.
await page.waitForFunction(() => (document.querySelector(".rel-carte-scene")?.style.transform || "").includes("scale"), undefined, { timeout: 2000 });
await page.locator('.rel-carte-outils [aria-label="Plein écran"]').click();
await page.waitForSelector(".rel-carte.plein");
await page.locator('.rel-carte-outils [aria-label="Quitter le plein écran"]').click();
await finit(async () => assert.equal(await page.locator(".rel-carte.plein").count(), 0, "re-appui sur ⛶ quitte le plein écran"));
// D-158 : dépliage multi-niveaux — « +n » déploie les voisins d'un nœud SANS
// recentrer (niveau 2 relié au parent), « − » replie. Jamais de doublon de nœud.
assert.ok((await page.locator(".rel-carte-depl").count()) >= 1, "au moins un nœud a des liens à déplier (+n)");
const nbAvantDepl = await page.locator(".rel-carte-carte").count();
await page.locator(".rel-carte-depl").first().click();
await finit(async () => {
  const nbApresDepl = await page.locator(".rel-carte-carte").count();
  assert.ok(nbApresDepl > nbAvantDepl, "le dépliage ajoute des cartes de niveau 2");
  assert.ok((await page.locator(".rel-carte-carte.niveau2").count()) >= 1, "les cartes dépliées portent le niveau 2 (atténuées)");
});
const ids = await page.evaluate(() => {
  const noms = [...document.querySelectorAll(".rel-carte-carte:not(.plus):not(.absente) .rel-carte-nom")].map((n) => n.textContent.trim());
  return { total: noms.length, uniques: new Set(noms).size };
});
assert.equal(ids.total, ids.uniques, "un voisin déjà visible n'est jamais dupliqué");
await page.locator(".rel-carte-depl.actif").first().click(); // « − » replie
await finit(async () => assert.equal(await page.locator(".rel-carte-carte").count(), nbAvantDepl, "replier revient à l'état initial"));
// Mindmap « carte synthétique » (D-148, gabarit spatial FIXE + mapping déterministe) :
// hub central + familles ancrées par zone, reliées par des flèches SVG colorées.
await page.locator(".rel-vue-onglet", { hasText: "Mindmap" }).click();
await page.waitForSelector(".rel-mm-radial");
assert.equal(await page.locator(".rel-mm-hub").count(), 1, "la Mindmap a un hub central unique");
assert.ok((await page.locator(".rel-mm-branche").count()) >= 2, "des familles entourent le hub");
assert.equal(await page.locator(".rel-mm-rang").count(), 0, "aucune numérotation de rang sur les nœuds");
// Les liens (flèches) sont tracés dans la couche SVG après mesure du DOM.
await page.waitForFunction(() => (document.querySelector(".rel-mm-liens")?.querySelectorAll("path").length ?? 0) >= 1, undefined, { timeout: 2000 });
// Recette mapping (D-148, recentrée D-241) : le placement suit le RÔLE du type
// de lien, pas son libellé. Centre choisi : Tomoe-nage, qui porte un lien de
// rôle « context » (kata → zone BAS) ET un « à ne pas confondre » (rôle peer →
// zone HAUT). L'épuration D-241 a retiré le type « fondamentaux » et vidé
// O-soto-gari de tout lien de contexte : l'ancien centre ne démontrait plus
// rien. Tomoe-nage prouve la même règle sur du contenu vivant — et ses deux
// voisins mènent eux-mêmes ailleurs, ce dont Explorer a besoin juste après.
await page.evaluate(() => {
  const a = document.querySelector("movenso-app");
  const t = a.bibliotheque.techniques.find((x) => x.nom.toLowerCase() === "tomoe-nage");
  a.ouvrirRelationsVisuelle(t.id, "classique");
});
await page.waitForSelector(".rel-mm-branche");
const familles = await page.evaluate(() => {
  const out = {};
  document.querySelectorAll(".rel-mm-branche").forEach((br) => {
    const slot = getComputedStyle(br).gridArea.split("/")[0].trim();
    out[slot] = [...br.querySelectorAll(".rel-mm-carte-nom")].map((n) => n.textContent.trim());
  });
  return out;
});
assert.ok((familles.bottom ?? []).some((n) => /kata/i.test(n)), "un lien de rôle « context » (kata) va en zone BAS : " + JSON.stringify(familles));
assert.ok(!(familles.top ?? []).some((n) => /kata/i.test(n)), "un lien de contexte ne tombe JAMAIS dans Similaires (top)");
assert.ok((familles.top ?? []).some((n) => /sumi-gaeshi/i.test(n)), "un lien de rôle « peer » occupe la zone HAUT : " + JSON.stringify(familles));
const hubVisible = await page.evaluate(() => {
  const h = document.querySelector(".rel-mm-hub").getBoundingClientRect();
  const nav = document.querySelector(".barre-nav").getBoundingClientRect();
  return h.top >= 0 && h.bottom <= nav.top;
});
assert.ok(hubVisible, "le hub central doit être entièrement visible entre l'en-tête et la nav basse (sans défiler)");
// S3.D1/D2 (D-179) : en-tête UNIFORME sur les quatre vues — loupe « centrer
// sur… » + 🎲 « centrer au hasard » SUR PLACE (plus d'écran intermédiaire,
// réservé à la première visite).
assert.equal(await page.locator('.rel-tete-actions [aria-label="Rechercher une technique à centrer"]').count(), 1, "la loupe vit dans l'en-tête (Mindmap)");
// D-313 : le nom du centre se compare EXACTEMENT, jamais par sous-chaîne —
// « Ko-soto-gari » contient « o-soto-gari », donc l'ancienne épingle rougissait
// quand le dé tombait juste, et seulement là (une CI rouge sur cinquante).
const centreAvantHasard = (await page.locator(".rel-mm-hub").innerText()).split("\n")[1]?.trim();
await page.locator('.rel-tete-actions [aria-label="Centrer au hasard"]').click();
await finit(async () => assert.equal(await page.locator(".rel-depart").count(), 0, "🎲 ne passe JAMAIS par l'écran d'entrée (D-179)"));
assert.equal(await page.locator(".rel-mm-hub").count(), 1, "🎲 reste dans la vue courante (Mindmap)");
{
  const centreApresHasard = (await page.locator(".rel-mm-hub").innerText()).split("\n")[1]?.trim();
  assert.notEqual(centreApresHasard, centreAvantHasard, `🎲 doit recentrer sur une AUTRE technique (avant et après : ${centreAvantHasard})`);
}
// uniformisation : la même loupe fonctionne en vue LISTE
await page.locator(".rel-vue-onglet", { hasText: "Liste" }).click();
await page.waitForSelector(".rel-listes");
assert.equal(await page.locator('.rel-tete-actions [aria-label="Rechercher une technique à centrer"]').count(), 1, "la loupe vit aussi dans l'en-tête de la Liste (D-179)");
assert.equal(await page.locator(".recherche input").count(), 0, "l'ancienne barre inline a disparu (uniformisation D-179)");
await page.locator('.rel-tete-actions [aria-label="Rechercher une technique à centrer"]').click();
await page.waitForSelector(".rel-mm-cherche input");
await page.fill(".rel-mm-cherche input", "o-soto");
await rendu(page);
// D-325 : la cible se LIT dans les résultats, elle ne se devine pas. Le produit
// exclut le centre courant de la loupe (`t.id !== centre.id`) — donc si le 🎲
// juste avant est tombé sur « O-soto-gari », cette puce ne PEUT pas exister.
// Épingler un nom fixe ici, c'était parier sur le dé (même famille que D-313).
assert.ok((await page.locator(".rel-mm-res .chip-filtre").count()) >= 1,
  "la loupe doit proposer au moins une cible pour « o-soto » (le centre courant excepté)");
const cible = (await page.locator(".rel-mm-res .chip-filtre").first().innerText()).trim();
await page.locator(".rel-mm-res .chip-filtre").first().click();
await finit(async () => assert.ok((await page.locator(".rel-centre").innerText()).includes(cible), `la loupe recentre depuis la Liste sur ${cible} (D-179)`));
// ← / → (retour porteur 2026-08-03) : les flèches d'en-tête rejouent
// l'historique de session — le ⌖ et le fil d'Ariane d'Explorer ont disparu.
await page.locator('[aria-label="Technique précédente"]').click();
await finit(async () => assert.ok(!(await page.locator(".rel-centre-nom").innerText()).includes(cible), "← revient au centre précédent"));
await page.locator('[aria-label="Technique suivante"]').click();
await finit(async () => assert.ok((await page.locator(".rel-centre-nom").innerText()).includes(cible), "→ rejoue le centre quitté"));
assert.equal(await page.locator('[aria-label="Revenir à la technique de départ"]').count(), 0, "le ⌖ a disparu (remplacé par ← / →)");
// retour en Mindmap centrée O-soto-gari : la suite (éditeur de lien) en dépend
await page.evaluate(() => {
  const a = document.querySelector("movenso-app");
  const t = a.bibliotheque.techniques.find((x) => x.nom.toLowerCase() === "o-soto-gari");
  a.ouvrirRelationsVisuelle(t.id, "classique");
});
await rendu(page);
// D-180 : l'écran d'entrée devient une BIENVENUE explicative (règles du jeu,
// rôle de chaque vue), réinvocable depuis Plus › Aide (scission D-308).
// S3.B11 (D-218/D-220) : l'À propos nomme les licences — code GPLv3, packs CC BY-NC-SA,
// vidéos propriété de leurs auteurs (liens seulement). Depuis la scission
// D-308, l'Aide (prise en main, Découvrir Relations) est une section à part.
await ouvrirPlus(page, "À propos");
{
  const licences = await page.locator(".apropos-licences").innerText();
  assert.ok(licences.includes("GNU GPL v3"), "l'À propos nomme la licence du code");
  assert.ok(licences.includes("CC BY-NC-SA 4.0"), "l'À propos nomme la licence des packs (NC : pas d'usage commercial, D-220)");
  assert.ok(licences.includes("propriété de leurs auteurs"), "l'À propos dit que les vidéos restent à leurs auteurs");
}
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]");
await ouvrirPlus(page, "Aide");
// D-310 : l'Aide est faite de volets repliés (maquette porteur) — on ouvre
// celui qui porte le raccourci avant de le toucher.
await ouvrirSection(page, "Compositions et relations");
await page.locator(".chip-filtre", { hasText: "Découvrir Relations" }).click();
await page.waitForSelector(".rel-depart");
assert.ok((await page.locator(".rel-depart-titre").innerText()).includes("Bienvenue"), "la bienvenue Relations s'ouvre depuis l'aide (D-180)");
assert.equal(await page.locator(".rel-regles .rel-regle").count(), 6, "les règles du jeu expliquent le centre, les 4 vues et les outils d'en-tête");
assert.ok((await page.locator(".rel-bienvenue-reprendre").innerText()).includes("O-soto-gari"), "« Reprendre » nomme le centre courant");
await page.locator(".rel-bienvenue-reprendre").click();
await page.waitForSelector(".rel-mm-hub");
assert.ok((await page.locator(".rel-mm-hub").innerText()).includes("O-soto-gari"), "« Reprendre » restaure la vue et le centre tels quels (D-180)");
// Explorer passe sur la variante CLUB « Ko Uchi Gari ». Choix DÉLIBÉRÉ depuis
// l'épuration D-241 : ce bloc démontre un parcours de DEUX étapes PUIS un
// changement d'objectif, ce qui exige que le pas suivant offre encore des
// objectifs. Dans le pack Judo épuré c'est devenu impossible — les cinq arêtes
// « enchaîne » restantes mènent toutes à une technique sans aucun autre lien.
// Le pack club garde cette profondeur. Centre distinct de « O Soto Gari » à
// dessein : la recette O5 juste en dessous a besoin d'un vrai changement de
// centre pour repartir d'un explorateur vierge.
await page.evaluate(() => {
  const a = document.querySelector("movenso-app");
  const t = a.bibliotheque.techniques.find((x) => x.nom === "Ko Uchi Gari");
  a.ouvrirRelationsVisuelle(t.id, "classique");
});
await rendu(page);
// S3.D3-O1 (D-198) : Explorer — badge du rôle emprunté sur chaque étape, et le
// mélange d'objectifs ASSUMÉ : « Changer d'objectif » garde le chemin, le
// montre pendant le choix, et le dit.
await page.locator(".rel-vue-onglet", { hasText: "Explorer" }).click();
await page.waitForSelector(".rel-ex");
assert.ok((await page.locator(".rel-ex-intent").count()) >= 1, "Explorer propose des objectifs sur Ko Uchi Gari");
assert.equal(await page.locator(".rel-ex-continue").count(), 0, "pas de bandeau « parcours continue » sans chemin entamé");
await page.locator(".rel-ex-intent").first().click();
await page.waitForSelector(".rel-ex-cand");
await page.locator(".rel-ex-cand").first().click();
await finit(async () => assert.ok((await page.locator(".rel-ex-etape .rel-ex-badge").count()) >= 1, "l'étape atteinte porte le badge du rôle emprunté (O1)"));
await page.locator(".rel-ex-changer").click();
await finit(async () => {
  assert.ok((await page.locator(".rel-ex-chemin .rel-ex-etape").count()) >= 2, "le chemin reste visible pendant le choix d'objectif (O1)");
  assert.equal(await page.locator(".rel-ex-continue").count(), 1, "le mélange d'objectifs est dit pendant le choix (O1)");
});
// choisir un NOUVEL objectif ne jette pas le parcours (mélange réel, O1)
await page.locator(".rel-ex-intent").first().click();
await finit(async () => assert.ok((await page.locator(".rel-ex-chemin .rel-ex-etape").count()) >= 2, "le nouvel objectif GARDE le parcours construit (O1)"));
// S3.D3-O5 : signal de NIVEAU sur les candidats — la variante CLUB d'O Soto
// Gari (niveaux en données, identité distincte D-067) enchaîne vers Tai Otoshi
// (jaune/1dan/2dan) : les pastilles de niveau apparaissent sur le candidat.
await page.evaluate(() => {
  const a = document.querySelector("movenso-app");
  const t = a.bibliotheque.techniques.find((x) => x.nom === "O Soto Gari");
  a.ouvrirRelationsVisuelle(t.id, "explorer");
});
await page.waitForSelector(".rel-ex-intent");
await page.locator(".rel-ex-intent", { hasText: "Construire un enchaînement" }).click();
await page.waitForSelector(".rel-ex-cand");
assert.ok((await page.locator(".rel-ex-cand .rel-ex-cand-niv .carte-niveau").count()) >= 1, "un candidat nivelé montre ses niveaux AVANT le choix (O5)");
// S3.D3-O2 : « Comparer » devient un FACE-À-FACE — sur O-soto-gari (kodokan),
// choisir O-soto-otoshi ouvre deux colonnes + la note « à ne pas confondre »
// (données D-136) ; « Continuer sur » avance ensuite le parcours, pas avant.
await page.evaluate(() => {
  const a = document.querySelector("movenso-app");
  const t = a.bibliotheque.techniques.find((x) => x.nom.toLowerCase() === "o-soto-gari");
  a.ouvrirRelationsVisuelle(t.id, "explorer");
});
await page.waitForSelector(".rel-ex-intent");
await page.locator(".rel-ex-intent", { hasText: "Comparer" }).click();
await page.waitForSelector(".rel-ex-cand");
await page.locator(".rel-ex-cand", { hasText: "O-soto-otoshi" }).click();
await page.waitForSelector(".rel-ex-face");
assert.equal(await page.locator(".rel-ex-face-col").count(), 2, "le face-à-face montre DEUX colonnes (O2)");
assert.ok((await page.locator(".rel-ex-face").innerText()).includes("O-soto-otoshi"), "la correspondance choisie est en colonne (O2)");
assert.ok((await page.locator(".rel-ex-face-note").innerText()).includes("fauche"), "la note de distinction est en vedette (O2, données D-136)");
assert.equal(await page.locator(".rel-ex-chemin").count(), 0, "comparer n'a PAS avancé le parcours (O2)");
await page.locator(".rel-ex-ctrl", { hasText: "Continuer sur" }).click();
await finit(async () => assert.ok((await page.locator(".rel-ex-chemin .rel-ex-etape").count()) >= 2, "« Continuer sur » avance le parcours explicitement (O2)"));
// retour à l'état attendu par la suite (éditeur de lien depuis O-soto-gari)
await page.evaluate(() => {
  const a = document.querySelector("movenso-app");
  const t = a.bibliotheque.techniques.find((x) => x.nom.toLowerCase() === "o-soto-gari");
  a.ouvrirRelationsVisuelle(t.id, "classique");
});
await rendu(page);
// D-156 : éditeur de relations — créer un lien (type + cible + raison + priorité)
// depuis la Liste, l'éditer, puis le retirer. La feuille « Lien » est LA porte
// d'écriture du graphe (fiche, Liste, Plus partagent le même composant).
await page.locator(".rel-vue-onglet", { hasText: "Liste" }).click();
await page.waitForSelector(".rel-listes");
await page.locator(".rel-tri-ajouter").click(); // ＋ lien (depuis O-soto-gari)
await page.waitForSelector('.feuille[aria-label="Nouveau lien"]');
await page.locator('.feuille[aria-label="Nouveau lien"] .chip-filtre', { hasText: /^Similaire à/ }).click();
await page.locator('.feuille input[aria-label="Chercher la technique liée"]').fill("de-ashi");
await page.locator('.feuille .chip-filtre', { hasText: "De-ashi-harai" }).first().click();
await page.locator('.feuille textarea[aria-label="Raison du lien"]').fill("Lien de test e2e");
await page.locator('.feuille[aria-label="Nouveau lien"] .chip-filtre', { hasText: /^2$/ }).click();
await page.locator('.feuille .bouton.principal', { hasText: "Ajouter" }).click();
await page.waitForSelector('.feuille[aria-label="Nouveau lien"]', { state: "detached" });
const ligneTest = () => page.locator(".rel-ligne-conteneur").filter({ hasText: "Lien de test e2e" });
await ligneTest().first().waitFor();
// Édition : le ✎ rouvre la feuille pré-remplie ; on change la raison.
await ligneTest().first().locator(".rel-ligne-editer").click();
await page.waitForSelector('.feuille[aria-label="Modifier le lien"]');
await page.locator('.feuille textarea[aria-label="Raison du lien"]').fill("Raison éditée e2e");
await page.locator('.feuille .bouton.principal', { hasText: "Enregistrer" }).click();
await page.waitForSelector('.feuille[aria-label="Modifier le lien"]', { state: "detached" });
await page.locator(".rel-ligne-conteneur").filter({ hasText: "Raison éditée e2e" }).first().waitFor();
// Retrait : « Retirer ce lien » (confirm accepté) — les deux lectures disparaissent.
await page.locator(".rel-ligne-conteneur").filter({ hasText: "Raison éditée e2e" }).first().locator(".rel-ligne-editer").click();
await page.waitForSelector('.feuille[aria-label="Modifier le lien"]');
await page.locator(".feuille .bouton.danger-lien", { hasText: "Retirer ce lien" }).click();
// C2 tranche b (D-204) : plus de confirm() natif — une feuille NOMMÉE confirme
await page.waitForSelector(".feuille-confirmation");
assert.ok((await page.locator(".feuille-confirmation h2").innerText()).includes("Retirer ce lien"), "la confirmation est une feuille nommée (C2)");
await page.locator(".feuille-confirmation .bouton.danger", { hasText: "Retirer le lien" }).click();
await page.waitForSelector('.feuille[aria-label="Modifier le lien"]', { state: "detached" });
await finit(async () => assert.equal(await page.locator(".rel-ligne-conteneur").filter({ hasText: "Raison éditée e2e" }).count(), 0, "le lien retiré doit disparaître de la Liste"));
// Régression nav (correctif D-138) : un SEUL appui sur l'onglet Relations depuis
// un AUTRE onglet ouvre bien Relations (et ne « rebondit » plus vers la
// Bibliothèque — `#allerRacine` oubliait le cas `relations`).
const ongletBiblio = page.locator(".barre-nav .nav-onglet", { hasText: "Bibliothèque" });
await ongletBiblio.click();
await rendu(page);
await page.locator(".barre-nav .nav-onglet", { hasText: "Relations" }).click();
await page.waitForSelector(".ecran-relations");
assert.equal(await page.evaluate(() => document.querySelector("movenso-app").zoneCourante()), "relations", "un appui sur l'onglet Relations ouvre Relations, pas la Bibliothèque");
// Retour à la RACINE Bibliothèque : la mémoire d'onglet restaure l'écran quitté
// (ici une fiche) ; un SECOND appui revient à la racine (comportement documenté).
await ongletBiblio.click();
await rendu(page);
await ongletBiblio.click();
await page.waitForSelector(".marque");
await page.fill(".ecran .recherche input", "o soto gari");
await rendu(page);
// la fiche du Club porte des relations (le pack club les définit)
await page
  .locator(".carte-technique")
  .filter({ has: page.locator(".carte-nom", { hasText: /^O Soto Gari$/ }) }) // la copie du club (nom à espaces)
  .first()
  .locator(".carte-ouvrir")
  .click();
await page.waitForSelector(".liaisons.relations");
assert.ok((await page.locator(".liaisons.relations button.rel-ligne").count()) >= 1, "la fiche O Soto Gari (Club) doit porter ses relations");
// §19 : naviguer par une ligne puis revenir rouvre la fiche d'origine
await page.locator(".liaisons.relations button.rel-ligne").first().click();
await page.waitForSelector(".fiche-entete h1");
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour à la fiche d'origine
await page.waitForSelector(".liaisons.relations");
assert.match(await page.locator(".barre .contexte").innerText(), /O.?soto.?gari/i, "le retour doit rouvrir la fiche d'origine (§19)");
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // racine Bibliothèque
await page.waitForSelector(".marque");

// D-090 : la densité de la grille se règle dans Plus › Apparence (curseur, Auto
// par défaut) ; l'ancien contrôle −/+ et le cœur-filtre ont quitté la barre.
assert.equal(await page.locator(".recherche-ligne .densite").count(), 0, "l'ancien contrôle de densité a quitté la barre");
assert.equal(await page.locator(".recherche-ligne .coeur-filtre").count(), 0, "le cœur-filtre a quitté la barre de recherche");
await ouvrirPlus(page, "Apparence");
const curseurDensite = page.locator('input[aria-label="Nombre de colonnes de la bibliothèque"]');
assert.equal(await curseurDensite.count(), 1, "le curseur de densité doit être présent dans Apparence");
// D-236 : la carte « Espace de stockage » a QUITTÉ Apparence (ce que l'app
// occupe n'est pas une question de présentation) pour rejoindre les sauvegardes.
assert.equal(await page.locator(".carte-atelier .titre-atelier", { hasText: "Espace" }).count(), 0,
  "l'espace de stockage n'est plus dans Apparence (D-236)");
await page.locator('.barre .bouton-icone[aria-label="Retour"]').click();
// D-308 : Stockage et Sauvegardes sont désormais DEUX sections — la carte
// Espace vit dans « Stockage », les gestes de mise à l'abri dans « Sauvegardes ».
await ouvrirPlus(page, "Stockage");
assert.ok((await page.locator(".carte-atelier .titre-atelier", { hasText: "Espace" }).count()) >= 1,
  "elle se lit désormais dans Stockage (D-236, scindé D-308)");
assert.equal(await page.locator('input[aria-label="Limite d\'espace pour les vidéos"]').count(), 1, "le curseur de limite d'espace doit être présent");
// S1.9 (D-163) : l'état de PERSISTANCE du stockage est affiché honnêtement —
// accordée / non garantie (+ bouton redemander) / natif / inconnue. persist()
// était déjà demandé au démarrage ; désormais son résultat est LU et montré.
assert.equal(await page.locator(".persistance-stockage").count(), 1, "la ligne de persistance du stockage doit être dans la carte Espace");
const textePersistance = await page.locator(".persistance-stockage").innerText();
assert.match(textePersistance, /Persistance accordée|Persistance non garantie|Stockage applicatif natif|ne sait pas répondre/, "l'état de persistance affiché est l'un des quatre états honnêtes : " + textePersistance);
if (/non garantie/.test(textePersistance)) {
  // le bouton de redemande existe et répond par un toast honnête (jamais bloquant)
  await page.locator(".persistance-stockage .lien-texte").click();
  await page.waitForSelector(".toast");
}
// retour dans Apparence pour la densité (D-236 : les deux écrans sont distincts)
await page.locator('.barre .bouton-icone[aria-label="Retour"]').click();
await ouvrirPlus(page, "Apparence");
await curseurDensite.evaluate((el) => { el.value = "3"; el.dispatchEvent(new Event("input", { bubbles: true })); });
await finit(async () => assert.equal(await page.evaluate(() => document.querySelector("movenso-app").preferences.densiteBibliotheque), 3, "le curseur doit fixer la densité à 3 colonnes"));
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // retour Bibliothèque
await page.waitForSelector(".marque");
assert.ok(((await page.locator(".grille").first().getAttribute("style")) || "").includes("repeat(3"), "la grille doit refléter la densité choisie");
// retour à « Auto » pour ne pas polluer la suite du parcours
await ouvrirPlus(page, "Apparence");
await page.locator('input[aria-label="Nombre de colonnes de la bibliothèque"]')
  .evaluate((el) => { el.value = "0"; el.dispatchEvent(new Event("input", { bubbles: true })); });
await finit(async () => assert.equal(await page.evaluate(() => document.querySelector("movenso-app").preferences.densiteBibliotheque ?? null), null, "« Auto » doit retirer la densité forcée"));
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // retour Bibliothèque
await page.waitForSelector(".marque");

// lot 1 §8-9 : conservation d'état — filtre conservé au retour de fiche,
// mémoire d'onglet au changement de destination, second appui = racine
await ouvrirDisc(page, "Judo");
await page.fill(".ecran .recherche input", "gari");
await rendu(page);
const nbFiltre = await page.locator(".carte-technique").count();
await page.locator(".carte-technique").first().click();
await page.waitForSelector(".fiche-entete h1");
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → explorateur
await page.waitForSelector(".carte-technique");
assert.equal(await page.locator(".ecran .recherche input").inputValue(), "gari", "filtre perdu au retour de fiche");
assert.equal(await page.locator(".carte-technique").count(), nbFiltre, "résultats perdus au retour de fiche");
await page.locator(".barre-nav .nav-onglet", { hasText: "Favoris" }).click(); // partir sur un autre onglet…
await page.waitForSelector(".marque");
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // …revenir : même écran, même filtre
await page.waitForSelector(".carte-technique");
assert.equal(await page.locator(".ecran .recherche input").inputValue(), "gari", "état d'onglet perdu au changement de destination");
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // second appui : racine de l'onglet
await page.waitForSelector(".marque");
// lot 2 §13 : rouvrir la discipline restaure ses filtres (mémoire par discipline)
await ouvrirDisc(page, "Judo");
await page.waitForSelector(".carte-technique");
assert.equal(await page.locator(".ecran .recherche input").inputValue(), "gari", "filtres non conservés par discipline");
await page.locator(".chip-filtre.reinitialiser").click();
await rendu(page);
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour racine, filtres propres
await page.waitForSelector(".marque");

// consultation : recherche tolérante → fiche mono-pack
await page.fill(".recherche input", "o soto");
await finit(async () => assert.ok((await page.locator(".carte-technique").count()) >= 3, "recherche « o soto » sans résultats"));
await page.locator(".carte-technique").first().locator(".carte-ouvrir").click();
await page.waitForSelector(".fiche-entete h1");
assert.ok((await page.locator(".bloc-lecture:not(.commentaire)").count()) >= 1, "présentation référentielle absente");
assert.ok((await page.locator(".bouton-video").count()) >= 1, "vidéo opt-in absente");
assert.equal(await page.locator("iframe").count(), 0, "aucun embed réseau sans geste explicite");

// M2 — note directe dans Mon carnet : action locale à la fiche (lot 1 §7)
assert.equal(await page.locator(".fab").count(), 0, "aucune action globale sur une fiche");
await page.fill(".commentaire-zone", "Test : kuzushi plus tôt.");
await page.locator(".commentaire-zone").blur();
await finit(async () => assert.ok((await page.locator(".commentaire-zone").inputValue()).includes("kuzushi"), "note absente du commentaire"));

// lot 2 §4 (scénario E) : un repère personnel se retrouve par la recherche globale
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
await page.waitForSelector(".marque");
await page.fill(".recherche input", "kuzushi");
await finit(async () => assert.ok((await page.locator(".carte-technique").count()) >= 1, "le mot personnel doit se retrouver dans la recherche globale"));
await page.fill(".recherche input", "");

// capture « plus tard » → à rattacher — depuis la discipline (« Ajouter »)
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
await page.locator(".chip-discipline", { hasText: "Judo" }).click();
await page.locator(".fab", { hasText: "Ajouter" }).click();
await gesteCapture(page, "note");
await page.fill(".champ-note", "Balayage vu en randori, nom inconnu.");
await page.click(".feuille .actions .bouton.principal");
await page.click(".feuille .actions .bouton:nth-child(2)");
// « plus tard » → Plus › « À traiter », kpi « Captures à rattacher » (D-107)
await ouvrirPlus(page, "À traiter");
assert.equal(Number(await kpiRattacher().locator(".kpi-nombre").innerText()), 1, "capture inachevée absente d'« à rattacher »");

// persistance OPFS après rechargement complet — démarrage sur la Bibliothèque (lot 1 §3)
await page.reload();
await page.waitForSelector(".chip-discipline");
await ouvrirPlus(page, "À traiter");
assert.equal(Number(await kpiRattacher().locator(".kpi-nombre").innerText()), 1, "persistance en échec");

// D-071 : la kpi « Captures à rattacher » de Plus › Médias ouvre le rattachement ;
// fermer (reculer) ne mute rien
await traiterRattacher(page);
await page.waitForSelector(".feuille");
await page.evaluate(() => document.querySelector("movenso-app").reculerCapture());
await finit(async () => assert.equal(await page.locator(".feuille").count(), 0, "la feuille de rattachement doit se refermer sans agir"));
assert.equal(Number(await kpiRattacher().locator(".kpi-nombre").innerText()), 1, "rien ne doit être muté par la fermeture");

// rattachement différé
await traiterRattacher(page);
await page.fill(".feuille .recherche input", "sasae");
await rendu(page);
await page.locator(".feuille .resultat").first().click();
await page.waitForSelector(".fiche-entete h1");
assert.ok((await page.locator(".commentaire-zone").inputValue()).includes("Balayage vu en randori"), "note rattachée absente de la fiche");

// création à la volée (cas « carnet seul », M1 §1.1) — depuis la discipline
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
await page.locator(".chip-discipline", { hasText: "Judo" }).click();
await page.locator(".fab", { hasText: "Ajouter" }).click();
await gesteCapture(page, "note");
await page.fill(".champ-note", "Variante du club.");
await page.click(".feuille .actions .bouton.principal");
await page.fill(".feuille .recherche input", "Balayage du randori");
await rendu(page);
await page.locator(".resultat.creer").click();
await page.locator(".fiche-entete h1", { hasText: "Balayage du randori" }).waitFor();

// lot 6 §9-11 (boucle 6.4) : types de relation (Plus › Relations entre
// techniques), liste de gestion et sources (Plus › Discipline)
await ouvrirPlus(page, "Relations entre techniques");
const carteLiens = () => page.locator(".carte-atelier").filter({ hasText: "Liens entre techniques" });
{
  // scénario D : les quatre types migrés, libellés lisibles (jamais un id)
  const texteLiens = await carteLiens().innerText();
  for (const l of ["Prépare", "Enchaîne vers", "Contre", "Similaire à"])
    assert.ok(texteLiens.includes(l), `type migré « ${l} » absent`);
  // créer un type symétrique (lecture inverse vide)
  await carteLiens().locator('input[aria-label="Libellé du type"]').fill("Complémentaire");
  await carteLiens().locator(".bouton.principal", { hasText: "Ajouter" }).click();
  await finit(async () => assert.ok((await carteLiens().innerText()).includes("Complémentaire ⇄"), "le type symétrique créé doit s'afficher avec sa nature"));
  // renommer (l'id ne bouge jamais, seul le libellé change)
  await carteLiens().locator(".ligne-atelier").filter({ hasText: "Complémentaire" }).locator('[aria-label="Modifier ce lien"]').click();
  await page.locator(".edition-type-relation input").first().fill("Complément de");
  await page.locator(".edition-type-relation .bouton.principal").click();
  await finit(async () => assert.ok((await carteLiens().innerText()).includes("Complément de ⇄"), "le renommage du type doit s'appliquer"));
  // un type UTILISÉ ne se supprime pas (§10 — refus actionnable, rien ne bouge)
  const nbLignes = await carteLiens().locator(".ligne-atelier").count();
  await carteLiens().locator(".ligne-atelier").filter({ has: page.locator(".kpi-nombre") }).first()
    .locator('[aria-label="Supprimer ce lien"]').click();
  await finit(async () => assert.ok((await page.locator(".toast").innerText()).includes("retire-les d'abord"), "la suppression d'un type utilisé doit être refusée avec explication"));
  // C2 (D-204) : un REFUS est un toast de niveau « alerte » (couleur de statut,
  // role=alert assertif) — un succès reste neutre (role=status).
  assert.equal(await page.locator(".toast.alerte[role=alert]").count(), 1, "le refus porte le niveau alerte (C2)");
  assert.equal(await carteLiens().locator(".ligne-atelier").count(), nbLignes, "le refus ne doit rien supprimer");
  // le type inutilisé se supprime après confirmation (feuille nommée, C2)
  await carteLiens().locator(".ligne-atelier").filter({ hasText: "Complément de" }).locator('[aria-label="Supprimer ce lien"]').click();
  await page.waitForSelector(".feuille-confirmation");
  await page.locator(".feuille-confirmation .bouton.danger").click();
  await finit(async () => assert.ok(!(await carteLiens().innerText()).includes("Complément de"), "le type inutilisé doit se supprimer"));
  // D-080 : un type se déplie sur ses instances, éditables directement
  const typeUtilise = carteLiens().locator(".type-relation-bloc").filter({ has: page.locator(".kpi-nombre") }).first();
  await typeUtilise.locator(".lien-type").click();
  await finit(async () => assert.ok(await typeUtilise.locator(".ligne-instance").count() >= 1, "un type déplié doit lister ses liens (D-080)"));
  assert.equal(await typeUtilise.locator(".ligne-instance").first().locator('[aria-label^="Retirer le lien"]').count(), 1, "chaque lien doit offrir un retrait direct");
  await typeUtilise.locator(".lien-type").click(); // replier
}
// §9 : liste de gestion — repérer l'incomplet, ouvrir la fiche (jamais une seconde Bibliothèque)
// tuning post-V3 : « Techniques » est désormais une ENTRÉE de menu à part entière
// (hors de « Discipline ») — la liste de gestion (recherche, filtres, lignes) y vit
await ouvrirPlus(page, "Gestion des techniques");
await page.fill(".recherche input", "essai classé");
await rendu(page);
{
  const ligne = page.locator(".ligne-gestion").first();
  assert.ok((await ligne.innerText()).includes("Judo"), "la ligne de gestion doit nommer la discipline");
  assert.ok((await ligne.innerText()).includes("sans média"), "l'état incomplet doit être visible : " + (await ligne.innerText()));
  await ligne.click();
  await page.locator(".fiche-entete h1", { hasText: "Essai classé" }).waitFor();
  await ouvrirPlus(page, "Gestion des techniques"); // retour dans Plus
}
// §11 (D-072) : le pseudo qui signe le contenu local a migré de l'ancienne
// section « Sources » vers Plus › Apparence (« Ton pseudo »). La section Sources
// a quitté l'écran Discipline (tuning post-V3).
{
  await ouvrirPlus(page, "Apparence");
  await page.fill('input[aria-label="Ton pseudo"]', "Yahya");
  await page.locator('input[aria-label="Ton pseudo"]').blur();
  await rendu(page);
  assert.equal(
    await page.evaluate(() => document.querySelector("movenso-app").preferences.pseudo),
    "Yahya",
    "le pseudo saisi dans Apparence doit signer le contenu local",
  );
}

// lot 6 §12-14 (boucle 6.5) : un fichier sans référence est détecté,
// prévisualisé OBLIGATOIREMENT, puis supprimé — un par un, jamais en masse
await page.evaluate(async () => {
  await document.querySelector("movenso-app").stockage.ecrireVideo("fichier-orphelin-e2e", new Blob([new Uint8Array(2048)]));
});
const kpiOrphelins = () => page.locator(".kpi").filter({ has: page.locator(".kpi-libelle", { hasText: "Fichiers inutilisés" }) });
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // quitter Plus (mémoire : fiche)…
await rendu(page);
// D-107 : le fichier orphelin se diagnostique dans « À traiter » (le parc est dans « Médias »)
await ouvrirPlus(page, "À traiter");
await page.waitForTimeout(lent(400)); // rafraîchissement asynchrone (tailles OPFS)
assert.equal(Number(await kpiOrphelins().locator(".kpi-nombre").innerText()), 1, "« À traiter » doit annoncer le fichier orphelin");
// D-107 : le parc de médias (médiathèque) vit dans « Médias », séparé des diagnostics
await ouvrirPlus(page, "Médias");
assert.ok(
  (await page.locator(".carte-atelier").filter({ hasText: "Médiathèque" }).count()) >= 1,
  "la médiathèque doit être visible en tête de Médias",
);
// D-082 : le KPI « Vidéos locales » fait office de filtre — la liste détaillée
// n'apparaît qu'à son clic (jamais tout le parc d'un coup), et se replie.
assert.equal(await page.locator(".mediatheque-liste").count(), 0, "la liste des médias reste masquée tant qu'on ne clique pas le KPI");
await page.locator(".kpi-filtre", { hasText: "Vidéos locales" }).click();
await finit(async () => assert.equal(await page.locator(".mediatheque-liste").count(), 1, "cliquer le KPI « Vidéos locales » déplie sa liste"));
await page.locator(".kpi-filtre", { hasText: "Vidéos locales" }).click(); // replier
await finit(async () => assert.equal(await page.locator(".mediatheque-liste").count(), 0, "recliquer le KPI replie la liste"));
// D-107 : les fichiers inutilisés se traitent dans « À traiter » (KPI dépliable)
await ouvrirPlus(page, "À traiter");
await rendu(page);
await page.locator(".kpi-filtre").filter({ has: page.locator(".kpi-libelle", { hasText: "Fichiers inutilisés" }) }).click();
await finit(async () => assert.equal(await page.locator(".ligne-orpheline .action-danger").count(), 0, "AUCUNE suppression sans prévisualisation (§13)"));
await page.locator(".ligne-orpheline .chip-filtre", { hasText: "Vérifier" }).click();
await page.waitForSelector(".ligne-orpheline movenso-video-locale");
await page.locator(".ligne-orpheline .action-danger").click();
await page.waitForSelector(".feuille-confirmation");
await page.locator(".feuille-confirmation .bouton.danger").click();
await page.waitForTimeout(lent(400));
assert.equal(await page.locator(".ligne-orpheline").count(), 0, "le fichier orphelin supprimé doit disparaître du diagnostic");
assert.equal(Number(await kpiOrphelins().locator(".kpi-nombre").innerText()), 0, "le problème résolu doit disparaître d'« À traiter »");

/* ===== Scénario F — composition verticale (D-020.1), édition INLINE (D-126) :
   créer (entonnoir) → ajouter (techniques + saisie libre + pause) → réordonner
   → éditer un pas (✎) → consulter → naviguer → pas-à-pas → ⋮ (renommer /
   dupliquer / supprimer) → technique indisponible → remplacer ===== */
await page.locator(".barre-nav .nav-onglet", { hasText: "Compositions" }).click(); // onglet Compositions (D-071)
await page.waitForSelector(".marque");
// D-126 : « Créer » ouvre l'ENTONNOIR (nom → ajout d'éléments), pas le grand
// tableau. Step 2 = choix « une technique / une saisie libre » + durée façon
// chrono (molettes min : s). On ajoute 2 techniques + une saisie libre.
await page.locator(".fab", { hasText: "Créer" }).click();
await page.waitForSelector('.feuille[aria-label="Créer une composition"]');
// UI-4 (D-322) : l'autre départ est NOMMÉ ici — partir d'une composition de pack
// et la dupliquer. Le geste existait (D-320) ; il n'était trouvable que si l'on
// savait déjà aller sur l'onglet Packs.
assert.equal(await page.locator(".depart-pack").count(), 1,
  "l'entonnoir nomme le départ « depuis une séance de tes packs » (UI-4)");
await page.fill('.feuille[aria-label="Créer une composition"] .creation-discipline input', "Ma spéciale");
await page.locator('.feuille[aria-label="Créer une composition"] .bouton.principal', { hasText: "Suivant" }).click();
// D-231 : « Qui pratique ? » s'intercale ici. « Seul » est le défaut et se passe
// d'un geste — le flux principal reste une composition à un seul exécutant.
await page.waitForSelector(".choix-nombre-roles");
assert.equal(await page.locator(".nom-role").count(), 0, "« Seul » par défaut : aucun rôle à nommer (D-231)");
await page.locator(".valider-roles").click();
await page.waitForSelector('.feuille[aria-label="Créer une composition"] .toggle-quoi:not(.choix-nombre-roles)');
assert.equal(await page.locator('.feuille[aria-label="Créer une composition"] .toggle-quoi:not(.choix-nombre-roles) .chip-choix').count(), 2, "step 2 : une technique / une saisie libre (D-126)");
// UI-4 (D-322) : la feuille demande QUOI d'abord. Tant qu'aucune technique n'est
// choisie, les réglages n'existent pas — elle s'ouvrait sur deux molettes de
// durée avant qu'on ait rien décidé.
assert.equal(await page.locator('.feuille[aria-label="Créer une composition"] .duree-roues select').count(), 0,
  "aucun réglage de durée avant d'avoir choisi le contenu (UI-4)");
// …et la recherche n'est pas un cul-de-sac : les techniques déjà sous la main
// s'affichent sans rien taper (une seule discipline installée ici).
assert.ok((await page.locator('.feuille[aria-label="Créer une composition"] .resultat').count()) >= 1,
  "la recherche propose les techniques à portée sans qu'on tape (UI-4)");
await champsTousNommes(page, "entonnoir de création de composition");
async function funnelAjouterTechnique(nom) {
  await page.locator('.feuille[aria-label="Créer une composition"] .chip-choix', { hasText: "Une technique" }).click();
  await page.fill('.feuille[aria-label="Créer une composition"] .recherche input', nom);
  await rendu(page);
  await page.locator('.feuille[aria-label="Créer une composition"] .resultat').first().click();
  await rendu(page);
  await page.locator('.feuille[aria-label="Créer une composition"] .ajout-valider', { hasText: "Ajouter" }).click();
  await rendu(page);
}
{
  // Le contenu choisi, les réglages apparaissent — la durée façon chrono de
  // D-126 (molettes min + s) est toujours le seul sélecteur.
  await page.locator('.feuille[aria-label="Créer une composition"] .chip-choix', { hasText: "Une technique" }).click();
  await page.fill('.feuille[aria-label="Créer une composition"] .recherche input', "o soto gari");
  await rendu(page);
  await page.locator('.feuille[aria-label="Créer une composition"] .resultat').first().click();
  await rendu(page);
  assert.equal(await page.locator('.feuille[aria-label="Créer une composition"] .duree-roues select').count(), 2,
    "durée façon chrono : molettes min + s (D-126), une fois le contenu posé");
  await page.locator('.feuille[aria-label="Créer une composition"] .ajout-valider', { hasText: "Ajouter" }).click();
  await rendu(page);
}
await funnelAjouterTechnique("harai goshi");
// une saisie libre (segment texte)
await page.locator('.feuille[aria-label="Créer une composition"] .chip-choix', { hasText: "Une saisie libre" }).click();
await page.fill('.feuille[aria-label="Créer une composition"] [aria-label="Saisie libre"]', "transition au sol");
await page.locator('.feuille[aria-label="Créer une composition"] .ajout-valider', { hasText: "Ajouter" }).click();
await finit(async () => assert.equal(await page.locator('.feuille[aria-label="Créer une composition"] .funnel-pas li').count(), 3, "3 éléments ajoutés dans l'entonnoir (D-126)"));
await page.locator('.feuille[aria-label="Créer une composition"] .actions .bouton', { hasText: "Terminer" }).click();
// UI-2 (D-319) : la composition s'ouvre en FICHE — identité, statistiques
// dérivées, aperçu des étapes, et une action forte. L'éditeur est derrière le ✎.
await page.waitForSelector(".fiche-compo-tete");
{
  const stats = await page.locator(".fiche-compo-stats").innerText();
  assert.match(stats, /3 étapes/, "la fiche compte les étapes, jalons exclus : " + stats);
  assert.equal(await page.locator(".fiche-compo-actions .action-forte", { hasText: "Démarrer" }).count(), 1,
    "une seule action forte sur la fiche (R9)");
  assert.equal(await page.locator(".fiche-compo-actions .action-seconde[disabled]").count(), 1,
    "« Planifier » est présent mais désactivé tant que l'Agenda n'existe pas (AG-1)");
  assert.equal(await page.locator(".apercu-etapes .apercu-etape").count(), 3, "l'aperçu montre les trois étapes");
  assert.equal(await page.locator(".bloc:not(.menu-bloc)").count(), 0,
    "la fiche n'est PAS l'éditeur : aucun bloc éditable en consultation (UI-2)");
}
await page.locator(".basculer-edition").click(); // ✎ : passer à l'éditeur
await page.waitForSelector(".composition-titre-lecture");
assert.equal(await page.locator(".bloc:not(.menu-bloc)").count(), 3, "3 blocs attendus (2 techniques + 1 saisie libre)");
// UI-3 (D-321) : l'éditeur porte le MÊME bandeau dérivé que la fiche — avant, il
// n'affichait qu'un « ⏱ Séance · N » quand une durée existait, donc RIEN ici, et
// ne disait ni le nombre de pas ni qui agit.
{
  const stats = await page.locator(".fiche-compo-stats").innerText();
  assert.match(stats, /3 étapes/, "le bandeau de l'éditeur compte les pas : " + stats);
  assert.match(stats, /Seul/, "…et dit qu'on est seul plutôt que de laisser un trou : " + stats);
}
// La suite des pas se lit comme une suite : rail vertical + rang sur le rail.
assert.equal(await page.locator("ol.blocs.blocs-timeline").count(), 1, "les pas forment une timeline (D-321)");
assert.match((await page.locator(".bloc.etape .bloc-nature").first().innerText()).trim(), /^\d+\.$/,
  "le rang reste dans .bloc-nature — le rail est décoratif, l'information ne déménage pas");
// 5.7 / NR-005-002 : aucun type interne visible ; D-124 boucle 3 : numérotation
// CONTINUE — chaque pas porte son rang « N. », jamais le mot du type interne.
assert.match((await page.locator(".bloc.etape .bloc-nature").first().innerText()).trim(), /^\d+\.$/, "un segment porte son rang continu, pas le libellé de type");
assert.ok(!/étape/i.test(await page.locator(".blocs").innerText()), "le mot ÉTAPE ne doit apparaître sur aucun bloc");
{
  const rangs = (await page.locator(".bloc:not(.menu-bloc) .bloc-nature").allInnerTexts()).map((t) => t.trim()).filter(Boolean);
  assert.deepEqual(rangs, rangs.map((_, k) => `${k + 1}.`), "les rangs doivent être continus : " + rangs.join(" "));
}
// D-233 : le glisser-déposer n'existe nulle part ; et le ✎ ouvre l'édition de
// TOUS les pas d'un coup (les outils ne vivent qu'ici, jamais en consultation).
assert.equal(await page.locator(".poignee-glisser").count(), 0, "le glisser-déposer a été retiré partout (D-233)");
await finit(async () =>
  assert.ok((await page.locator(".pas-reglages").count()) >= 3, "le ✎ de la barre haute ouvre l'édition de TOUS les pas (D-233)"));
// Réordonnancement : les flèches sont le SEUL mécanisme (D-233, WCAG 2.5.7).
// La saisie libre (3e) remonte d'un cran, puis redescend.
await page.locator('.bloc.etape .boutons-reordre button[title="Monter"]').click();
await finit(async () => {
  const ordre = await page.locator(".bloc:not(.menu-bloc)").evaluateAll((els) => els.map((e) => e.className));
  assert.ok(ordre[1].includes("etape"), "le bouton ▲ remonte le pas d'un cran (S2.9)");
});
await page.locator('.bloc.etape .boutons-reordre button[title="Descendre"]').click();
await finit(async () => {
  const apres = await page.locator(".bloc:not(.menu-bloc)").evaluateAll((els) => els.map((e) => e.className));
  assert.ok(apres[2].includes("etape"), "le bouton ▼ doit descendre le pas d'un cran (S2.9)");
  assert.ok(
    ((await page.locator(".annonce-lecteur[role=status]").textContent()) ?? "").includes("position 3 sur 3"),
    "le déplacement d'un pas doit être annoncé (aria-live) (S2.9)",
  );
});
// Le rôle et le lien se règlent SUR PLACE, sans ouvrir de feuille — c'est
// l'édition « globale » demandée par le porteur.
assert.ok((await page.locator(".pas-reglages .reglage-lien").count()) > 0, "chaque pas sauf le premier porte sa bascule « même temps » (D-235)");
await page.locator('.bloc.etape .boutons-reordre button[title="Monter"]').click();
await rendu(page);
// D-126 : ajouter une PAUSE via la feuille légère « ＋ » (saisie libre + durée,
// sans texte → pause), puis la retirer via ✕ pour retrouver l'état de référence.
await page.locator(".ajouter-pas-inline").click();
await page.waitForSelector('.feuille[aria-label="Ajouter un élément"]');
await page.locator('.feuille[aria-label="Ajouter un élément"] .chip-choix', { hasText: "Une saisie libre" }).click();
await page.selectOption('.feuille[aria-label="Ajouter un élément"] [aria-label="Secondes"]', "30");
await page.locator('.feuille[aria-label="Ajouter un élément"] .ajout-valider', { hasText: "Ajouter" }).click();
await rendu(page);
await page.locator('.feuille[aria-label="Ajouter un élément"] .actions .bouton', { hasText: "Terminer" }).click();
await finit(async () => assert.equal(await page.locator(".bloc.pause").count(), 1, "une pause s'ajoute (saisie libre + durée, sans texte) (D-126)"));
assert.ok((await page.locator(".bloc.pause .bloc-duree").innerText()).includes("30 s"), "la pause porte sa durée en secondes (D-126)");
await page.locator('.bloc.pause [aria-label="Retirer ce pas"]').click();
await finit(async () => assert.equal(await page.locator(".bloc.pause").count(), 0, "la pause se retire via ✕ (D-126)"));
// D-126 : éditer un pas via ✎ (mini-feuille limitée au type) — la saisie libre.
await page.locator('.bloc.etape [aria-label="Détails de ce pas"]').click();
await page.waitForSelector('.feuille[aria-label="Modifier le pas"]');
await page.fill('.feuille[aria-label="Modifier le pas"] [aria-label="Texte du pas"]', "transition au sol — rouler");
await page.locator('.feuille[aria-label="Modifier le pas"] [aria-label="Texte du pas"]').press("Tab");
await page.locator('.feuille[aria-label="Modifier le pas"] .actions .bouton.principal', { hasText: "Terminer" }).click();
await finit(async () => assert.ok((await page.locator(".ecran").innerText()).includes("transition au sol — rouler"), "le texte modifié via ✎ doit être enregistré"));
assert.ok(!/étape/i.test(await page.locator(".blocs").innerText()), "aucun type interne en LECTURE non plus");
// D-126 : la description passe par le menu ⋮ (hors-séquence).
await page.locator('.barre .bouton-icone[aria-label="Options"]').click();
await page.waitForSelector('.feuille[aria-label="Options de la composition"]');
await page.fill('.feuille[aria-label="Options de la composition"] [aria-label="Description"]', "Objectif : liaison debout-sol");
await page.locator('.feuille[aria-label="Options de la composition"] [aria-label="Description"]').press("Tab");
await rendu(page);
await page.locator('.feuille[aria-label="Options de la composition"] .bouton.principal', { hasText: "Terminer" }).click();
await finit(async () => assert.ok((await page.locator(".fiche-entete").innerText()).includes("liaison debout-sol"), "la description doit s'afficher en lecture"));
// navigation : une vignette technique ouvre sa fiche, qui référence la compo
await page.locator(".bloc.technique .bloc-technique-lecture").first().click();
await page.locator(".fiche-entete h1").first().waitFor();
assert.ok(
  (await page.locator(".ecran").innerText()).toLowerCase().includes("utilisée dans"),
  "« Utilisée dans » absent de la fiche",
);
await page.locator(".liaisons .puce-liaison", { hasText: "Ma spéciale" }).click(); // fiche technique → fiche de composition
await page.waitForSelector(".fiche-compo-tete");

// D-093 : mode pas-à-pas — ▶ « Passer en revue » lance le déroulé plein écran.
await page.locator('.barre .bouton-icone[aria-label="Passer en revue"]').click();
await page.waitForSelector(".ecran.entrainement");
assert.match(await page.locator(".entrainement-progression").innerText(), /^1 \//, "le déroulé démarre au premier bloc");
await page.locator(".entrainement-actions .bouton.principal", { hasText: "Suivant" }).click();
await finit(async () => assert.match(await page.locator(".entrainement-progression").innerText(), /^2 \//, "« Suivant » avance dans le déroulé"));
await page.locator(".entrainement-actions .bouton", { hasText: "Quitter" }).click();
await page.waitForSelector(".fiche-compo-tete");
assert.equal(await page.locator(".ecran.entrainement").count(), 0, "« Quitter » revient à la composition");

// UI-6 (D-324) : « Quitter » GARDE la position — c'est précisément le cas à
// reprendre. La carte « Continuer » apparaît en tête de la liste, au-dessus de
// la bascule (ce qu'on reprend peut être une séance de pack), et son ▶ relance
// AU BON PAS, pas au premier.
await page.locator(".barre-nav .nav-onglet", { hasText: "Compositions" }).click();
await page.waitForSelector(".marque");
await page.waitForSelector(".reprise-carte");
// D-326 : la carte reprend la NOTATION du lecteur (« 2 / 3 »), pas le mot
// « étape » — l'index est une position dans le déroulé, pas un compte de gestes.
assert.match(await page.locator(".reprise-position").innerText(), /^2 \/ 3 · /,
  "la reprise dit la position comme le lecteur : " + (await page.locator(".reprise-position").innerText()));
assert.ok((await page.locator(".reprise-carte .carte-liste-titre").innerText()).includes("Ma spéciale"),
  "…et la composition concernée");
await page.locator(".reprise-reprendre").click();
await page.waitForSelector(".ecran.entrainement");
await finit(async () => assert.match(await page.locator(".entrainement-progression").innerText(), /^2 \//,
  "« Continuer » relance au pas noté, jamais au premier (UI-6)"));
// « Terminer » efface la reprise : une séance finie n'a rien à continuer.
await page.locator(".entrainement-actions .bouton.principal", { hasText: "Suivant" }).click();
await rendu(page);
await page.locator(".entrainement-actions .bouton.principal", { hasText: "Terminer" }).click();
await page.waitForSelector(".entrainement-resume");
await page.locator(".entrainement-actions .bouton", { hasText: "Fermer" }).click();
await page.locator(".barre-nav .nav-onglet", { hasText: "Compositions" }).click();
await page.waitForSelector(".marque");
await finit(async () => assert.equal(await page.locator(".reprise-carte").count(), 0,
  "une séance TERMINÉE n'a rien à continuer : la carte disparaît (UI-6)"));
await page.locator(".composition-carte .composition-ouvrir", { hasText: "Ma spéciale" }).click();
await page.waitForSelector(".fiche-compo-tete");

// lot 5 §18 (scénario H) : duplication via ⋮ — nouvelles références, jamais de copie
await page.locator('.barre .bouton-icone[aria-label="Options"]').click();
await page.waitForSelector('.feuille[aria-label="Options de la composition"]');
await page.locator('.feuille[aria-label="Options de la composition"] .actions .bouton', { hasText: "Dupliquer" }).click();
await page.locator(".fiche-compo-identite h1", { hasText: "Ma spéciale (copie)" }).waitFor();
// 5.7 : un toast posé AVEC une navigation programmée accompagne l'arrivée
assert.ok((await page.locator(".toast").innerText()).includes("créée"), "le toast de duplication doit accompagner l'arrivée sur la copie");
// renommer la copie via ⋮
await page.locator('.barre .bouton-icone[aria-label="Options"]').click();
await page.waitForSelector('.feuille[aria-label="Options de la composition"]');
await page.fill('.feuille[aria-label="Options de la composition"] .composition-titre', "Copie de travail");
await page.locator('.feuille[aria-label="Options de la composition"] .composition-titre').press("Tab");
await rendu(page);
await page.locator('.feuille[aria-label="Options de la composition"] .bouton.principal', { hasText: "Terminer" }).click();
await page.locator(".fiche-compo-identite h1", { hasText: "Copie de travail" }).waitFor();
await page.locator('.barre [aria-label="Retour"]').click(); // retour → l'originale, inchangée
await page.locator(".fiche-compo-identite h1", { hasText: "Ma spéciale" }).waitFor();
// L'originale se lit dans sa FICHE : ses trois étapes sont dans l'aperçu (UI-2).
assert.equal(await page.locator(".apercu-etapes .apercu-etape").count(), 3,
  "l'originale ne doit pas bouger après duplication et renommage de la copie");
// liste : originale + copie
await page.locator(".barre-nav .nav-onglet", { hasText: "Compositions" }).click();
await page.waitForSelector(".composition-carte");
// D-238/D-241 : le pack judo importé au scénario B apporte SES compositions —
// une composition non personnelle voyage avec son pack pour rester jouable
// (D-127). Depuis l'épuration porteur, le Nage-no-kata est découpé en SIX
// entrées : une synthèse et les cinq séries. La liste porte donc l'originale,
// la copie, et ces six-là.
// UI-1 (D-320) : la bascule sépare ce qui est à MOI de ce que mes PACKS
// fournissent. Côté « Mes compositions » : l'originale et la copie, rien de plus.
assert.equal(await page.locator(".composition-carte").count(), 2,
  "côté « Mes compositions » : l'originale et la copie seulement (UI-1)");
assert.equal(await page.locator(".segments .segment").count(), 2, "deux onglets exclusifs : Mes | Packs");
assert.match(await page.locator(".segments").innerText(), /2[\s\S]*6/,
  "les compteurs des deux onglets sont dits AVANT de les toucher : " + (await page.locator(".segments").innerText()));
// Côté « Packs » : les six entrées du kata, groupées par discipline, avec
// « Dupliquer » sur la carte plutôt que le ⋮ — le geste attendu là.
await page.locator(".segments .segment", { hasText: "Packs" }).click();
await page.waitForSelector(".groupe-pack");
assert.equal(await page.locator(".composition-dupliquer").count(), await page.locator(".composition-carte").count(),
  "chaque carte de pack porte « Dupliquer » (UI-1)");
assert.equal(await page.locator(".composition-options").count(), 0, "le ⋮ ne s'affiche pas sur une carte de pack");
await page.locator(".groupe-pack .voir-plus").first().click(); // aperçu à trois → tout voir
await rendu(page);
assert.equal(await page.locator(".composition-carte", { hasText: "Nage-no-kata" }).count(), 6,
  "les six compositions du kata arrivent avec le pack (D-241)");
assert.ok((await page.locator(".pied-explicatif").innerText()).includes("Duplique"),
  "le pied explique pourquoi l'édition directe n'est pas le geste par défaut");
// D-326 (verdict checker) : la carte et la fiche comptent les pas AU MÊME
// ENDROIT. Sur un kata à jalons (« — Te-waza — »), la liste annonçait 26 étapes
// là où la fiche en disait 21 : la définition de « pas » vivait deux fois.
// Le kata publié est le cas réel — pas une fixture fabriquée pour l'occasion.
{
  const carte = page.locator(".composition-carte", { hasText: "Nage-no-kata — Te-waza" });
  const surLaCarte = (await carte.locator(".meta-ligne").innerText()).match(/(\d+)\s*étape/)?.[1];
  await carte.locator(".composition-ouvrir").click();
  await page.waitForSelector(".fiche-compo-stats");
  const surLaFiche = (await page.locator(".fiche-compo-stats").innerText()).match(/(\d+)\s*étape/)?.[1];
  assert.equal(surLaCarte, surLaFiche,
    `carte et fiche doivent annoncer le MÊME nombre d'étapes (carte ${surLaCarte}, fiche ${surLaFiche})`);
  assert.equal(surLaFiche, "3", "trois gestes dans Te-waza — le jalon n'en est pas un");
  await page.locator('.barre [aria-label="Retour"]').click();
  await page.waitForSelector(".composition-carte");
  await page.locator(".segments .segment", { hasText: "Packs" }).click();
  await page.waitForSelector(".groupe-pack");
  await page.locator(".groupe-pack .voir-plus").first().click();
  await rendu(page);
}
// D-326 : l'éditeur ne numérote pas un jalon — troisième compteur du même objet.
// Les dix compositions à jalons PUBLIÉES sont toutes à deux rôles (donc lues en
// grille de temps) : le cas timeline se prouve sur un jalon SAISI par
// l'utilisateur, par le chemin du produit — « ＋ Ajouter un élément », saisie
// libre, un texte encadré de tirets. Retiré ensuite : la suite du parcours
// compte les blocs de « Ma spéciale ».
await page.locator(".segments .segment", { hasText: "Mes compositions" }).click();
await page.waitForSelector(".composition-carte");
await page.locator(".composition-carte .composition-ouvrir", { hasText: "Ma spéciale" }).click();
await page.waitForSelector(".fiche-compo-tete");
await page.locator(".basculer-edition").click();
await page.waitForSelector(".blocs-timeline");
{
  const avant = (await page.locator(".fiche-compo-stats").innerText()).match(/(\d+)\s*étape/)?.[1];
  await page.locator(".ajouter-pas-inline").click();
  await page.waitForSelector(".feuille .toggle-quoi");
  await page.locator(".feuille .chip-choix", { hasText: "Une saisie libre" }).click();
  await page.fill('.feuille [aria-label="Saisie libre"]', "— Te-waza —");
  await page.locator(".feuille .ajout-valider").click();
  await rendu(page);
  // La feuille reste ouverte — on ajoute plusieurs éléments d'affilée. On la
  // referme avant de toucher aux pas derrière elle.
  await page.locator(".feuille .bouton", { hasText: "Terminer" }).click();
  await finit(async () => assert.equal(await page.locator('.feuille[aria-label="Ajouter un élément"]').count(), 0, "la feuille d'ajout se referme"));
  const rangs = (await page.locator(".bloc:not(.menu-bloc) .bloc-nature").allInnerTexts()).map((t) => t.trim()).filter(Boolean);
  assert.deepEqual(rangs, ["1.", "2.", "3."], "un jalon saisi ne consomme aucun rang : " + rangs.join(" "));
  assert.equal((await page.locator(".fiche-compo-stats").innerText()).match(/(\d+)\s*étape/)?.[1], avant,
    "…et il ne change pas le nombre d'étapes annoncé");
  await page.locator(".bloc.etape", { hasText: "Te-waza" }).locator('[aria-label="Retirer ce pas"]').click();
  await finit(async () => assert.equal(await page.locator(".bloc:not(.menu-bloc)").count(), 3, "le jalon d'essai est retiré"));
}
await page.locator(".basculer-edition").click(); // ✓ : refermer l'édition
await page.waitForSelector(".apercu-etapes");
// retour côté Packs, où la suite du parcours travaille
await page.locator('.barre [aria-label="Retour"]').click();
await page.waitForSelector(".composition-carte");
await page.locator(".segments .segment", { hasText: "Packs" }).click();
await page.waitForSelector(".groupe-pack");
await page.locator(".groupe-pack .voir-plus").first().click();
await rendu(page);
// Le liseré prend la teinte de la discipline DOMINANTE (arbitrage porteur) :
// dérivé, jamais saisi — une carte de judo ne peut pas être neutre.
assert.notEqual(await page.locator(".composition-carte").first().getAttribute("data-acteur-rang"), "0",
  "le liseré porte le rang de la discipline dominante (UI-1)");
// D-320 : « Duplique-les pour les personnaliser » doit être VRAI — la copie
// d'une composition de pack m'appartient : elle change de côté, perd son badge
// de provenance, et son ⋮ revient. Le code ne retirait que `origine` ; la copie
// restait « enseignement », donc rangée du côté des packs.
await page.locator(".composition-carte", { hasText: "Nage-no-kata — vue d’ensemble" }).locator(".composition-dupliquer").click();
await page.waitForSelector(".fiche-compo-tete");
assert.equal(await page.locator(".fiche-compo-tete .badge-source").count(), 0,
  "la copie n'est plus « d'un pack » : aucun badge de provenance sur sa fiche (D-320)");
assert.ok(!(await page.locator(".barre .contexte").innerText()).includes("Pack"),
  "…et la barre ne la présente plus comme venant d'un pack");
await page.locator('.barre [aria-label="Retour"]').click();
await page.waitForSelector(".composition-carte"); // retour côté Packs, où l'on était
await page.locator(".segments .segment", { hasText: "Mes compositions" }).click();
await rendu(page);
assert.equal(await page.locator(".composition-carte").count(), 3,
  "la copie d'une composition de pack rejoint « Mes compositions » (D-320)");
// nettoyage : la copie repart, par le ⋮ de sa carte (celui qui n'existe QUE côté « Mes »)
await page.locator(".composition-carte", { hasText: "(copie)" }).locator(".composition-options").click();
await page.waitForSelector('.feuille[aria-label="Options de la composition"]');
await page.locator(".supprimer-composition").click();
await page.waitForSelector(".feuille-confirmation");
await page.locator(".feuille-confirmation .bouton.danger").click();
await rendu(page);
await finit(async () => assert.equal(await page.locator(".composition-carte").count(), 2, "la copie retirée, il reste l'originale et « Copie de travail »"));
await page.locator(".segments .segment", { hasText: "Mes compositions" }).click();
await page.waitForSelector(".composition-carte");
assert.ok((await page.locator(".composition-carte").first().innerText()).match(/étape/i), "la carte annonce ses étapes (ligne de méta à icônes, UI-1)");
// D-125 : ▶ joue la composition directement depuis la liste
assert.ok((await page.locator(".composition-play").count()) >= 1, "un bouton ▶ jouer est présent sur les cartes");
await page.locator(".composition-play").first().click();
await page.waitForSelector(".ecran.entrainement");
await page.locator(".entrainement-actions .bouton", { hasText: "Quitter" }).click();
await page.waitForSelector(".composition-carte");
// suppression confirmée de la copie via ⋮ (nettoyage)
await page.locator(".composition-carte .composition-ouvrir", { hasText: "Copie de travail" }).click();
await page.waitForSelector(".fiche-compo-tete");
await page.locator('.barre .bouton-icone[aria-label="Options"]').click();
await page.waitForSelector('.feuille[aria-label="Options de la composition"]');
assert.equal((await page.locator(".supprimer-composition").innerText()).trim(), "Supprimer", "libellé explicite de suppression attendu");
await page.locator(".supprimer-composition").click();
// C2 tranche b (D-204) : feuille de confirmation nommée à la place du confirm()
await page.waitForSelector(".feuille-confirmation");
assert.ok((await page.locator(".feuille-confirmation h2").innerText()).includes("Copie de travail"), "la confirmation doit NOMMER la composition");
// le voile referme SANS effet, puis on confirme vraiment
await page.locator(".voile").last().click();
await finit(async () => assert.equal(await page.locator(".feuille-confirmation").count(), 0, "le voile annule la confirmation (C2)"));
// le menu ⋮ s'est refermé en ouvrant la confirmation : le rouvrir depuis l'écran
await page.locator('.barre .bouton-icone[aria-label="Options"]').click();
await page.waitForSelector('.feuille[aria-label="Options de la composition"]');
await page.locator(".supprimer-composition").click();
await page.waitForSelector(".feuille-confirmation");
await page.locator(".feuille-confirmation .bouton.danger").click();
await rendu(page);
await page.waitForSelector(".composition-carte");
await finit(async () => assert.ok((await page.locator(".toast").innerText()).includes("supprimée"), "la suppression doit être confirmée par une notification nommée"));
assert.equal(await page.locator(".toast.alerte").count(), 0, "une confirmation reste un toast NEUTRE (C2)");
assert.equal(await page.locator(".composition-carte").count(), 1,
  "la copie supprimée disparaît ; côté « Mes compositions » il ne reste que l'originale (UI-1)");
// D-215 : LOUPE de la liste des compositions — nom OU technique contenue ;
// zéro résultat = état honnête avec « tout réafficher » ; chips de discipline
// seulement quand elles départagent (une seule discipline ici → pas de chips).
await page.fill('input[aria-label="Rechercher une composition ou une technique qu\'elle contient"]', "spéciale");
await finit(async () => assert.equal(await page.locator(".composition-carte").count(), 1, "la loupe trouve par nom de composition (D-215)"));
await page.fill('input[aria-label="Rechercher une composition ou une technique qu\'elle contient"]', "zzzz-introuvable");
await finit(async () => assert.equal(await page.locator(".composition-carte").count(), 0, "zéro correspondance = liste vide honnête"));
await page.locator(".lien-nu", { hasText: "tout réafficher" }).click();
await finit(async () => assert.equal(await page.locator(".composition-carte").count(), 1, "« tout réafficher » réinitialise loupe et filtre"));
assert.equal(await page.locator(".compositions-chips").count(), 0, "une seule discipline : pas de chips inutiles (D-215)");


// lot 5 §17 (scénario G) : technique indisponible — libellé de secours, jamais
// de suppression silencieuse, Remplacer depuis la mini-feuille du pas (✎).
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // racine
await page.waitForSelector(".marque");
await page.locator(".chip-discipline", { hasText: "Judo" }).click();
await page.locator(".fab", { hasText: "Ajouter" }).click();
await page.locator(".option-ajouter", { hasText: "Créer une technique" }).click();
await page.fill(".feuille .champ-nouveau-nom", "Jetable");
await page.locator(".feuille .actions .bouton.principal").click();
await page.waitForSelector(".edition");
await page.locator('.fiche-actions [aria-label="Enregistrer"]').click();
await page.locator(".fiche-entete h1", { hasText: "Jetable" }).waitFor();
// l'ajouter à Ma spéciale via la feuille « ＋ »
await page.locator(".barre-nav .nav-onglet", { hasText: "Compositions" }).click();
await page.waitForSelector(".composition-carte");
await page.locator(".composition-carte .composition-ouvrir", { hasText: "Ma spéciale" }).click();
await page.waitForSelector(".fiche-compo-tete");
await page.locator(".basculer-edition").click(); // ＋ Ajouter vit dans l'éditeur (UI-2)
await page.waitForSelector(".blocs");
await page.locator(".ajouter-pas-inline").click();
await page.waitForSelector('.feuille[aria-label="Ajouter un élément"]');
await page.locator('.feuille[aria-label="Ajouter un élément"] .chip-choix', { hasText: "Une technique" }).click();
await page.fill('.feuille[aria-label="Ajouter un élément"] .recherche input', "jetable");
await rendu(page);
await page.locator('.feuille[aria-label="Ajouter un élément"] .resultat', { hasText: "Jetable" }).first().click();
await rendu(page);
await page.locator('.feuille[aria-label="Ajouter un élément"] .ajout-valider', { hasText: "Ajouter" }).click();
await rendu(page);
await page.locator('.feuille[aria-label="Ajouter un élément"] .actions .bouton', { hasText: "Terminer" }).click();
await finit(async () => assert.equal(await page.locator(".bloc:not(.menu-bloc)").count(), 4, "Jetable ajoutée en 4e pas"));
// retirer « Jetable » de la bibliothèque : la confirmation NOMME la composition
await ouvrirPlus(page, "Gestion des techniques");
await page.fill(".recherche input", "jetable");
await rendu(page);
await page.locator('.supprimer-technique[aria-label="Retirer Jetable"]').click();
await page.waitForSelector(".feuille-confirmation");
assert.ok((await page.locator(".feuille-confirmation h2").innerText()).includes("Jetable"), "la confirmation NOMME la technique (C2)");
assert.ok((await page.locator(".confirmation-corps").innerText()).includes("Ma spéciale"), "le retrait doit nommer les compositions dépendantes");
await page.locator(".feuille-confirmation .bouton.danger").click();
await rendu(page);
// D-081 : le retrait est une MISE EN CORBEILLE réversible — « Jetable » y figure
await ouvrirPlus(page, "Corbeille");
assert.ok(
  (await page.locator(".ligne-corbeille").filter({ hasText: "Jetable" }).count()) >= 1,
  "une fiche retirée doit apparaître dans la Corbeille (D-081)",
);
assert.ok(
  (await page.locator(".ligne-corbeille").filter({ hasText: "Jetable" }).locator(".chip-filtre", { hasText: "Restaurer" }).count()) >= 1,
  "la Corbeille doit proposer de restaurer la fiche",
);
// le bloc survit avec son libellé de secours, et se remplace via ✎
await page.locator(".barre-nav .nav-onglet", { hasText: "Compositions" }).click(); // mémoire d'onglet : la composition, dans l'état quitté
// La mémoire d'onglet restaure l'écran TEL QU'IL ÉTAIT : il peut donc déjà être
// dans l'éditeur. Le ✎ étant une bascule, on ne clique que s'il faut y entrer.
if ((await page.locator(".fiche-compo-tete").count()) > 0) await page.locator(".basculer-edition").click();
await page.waitForSelector(".blocs");
assert.ok((await page.locator(".puce-liaison.absente").innerText()).includes("Jetable"), "le libellé de secours doit s'afficher quand l'identité manque (§17)");
await page.locator('.bloc:has(.puce-liaison.absente) [aria-label="Détails de ce pas"]').click(); // ⋯ sur le pas à retrouver
await page.waitForSelector('.feuille[aria-label="Modifier le pas"]');
await page.fill('.feuille[aria-label="Modifier le pas"] [placeholder="Chercher une technique…"]', "o goshi");
await rendu(page);
await page.locator('.feuille[aria-label="Modifier le pas"] .resultat', { hasText: "O-goshi" }).first().click();
await finit(async () => assert.equal(await page.locator(".puce-liaison.absente").count(), 0, "le remplacement doit résoudre la référence"));
// nettoyage : retirer ce pas pour retrouver l'état de référence (3 pas)
await page.locator('.feuille[aria-label="Modifier le pas"] .action-danger', { hasText: "Retirer ce pas" }).click();
await finit(async () => assert.equal(await page.locator(".bloc:not(.menu-bloc)").count(), 3, "retour à l'état de référence"));

// persistance de la composition après rechargement complet — démarrage Bibliothèque
await page.reload();
await page.waitForSelector(".chip-discipline");
// D-071 : « à rattacher » vide (tout est rattaché) — Plus › Médias
await ouvrirPlus(page, "À traiter");
assert.equal(Number(await kpiRattacher().locator(".kpi-nombre").innerText()), 0, "« à rattacher » ne doit lister que l'inachevé");
// onglet Favoris : état honnête, aucune action globale
await page.locator(".barre-nav .nav-onglet", { hasText: "Favoris" }).click();
await page.waitForSelector(".marque");
assert.equal(await page.locator(".fab").count(), 0, "aucune action globale sur Favoris");
assert.ok((await page.locator(".ecran").innerText()).toLowerCase().includes("favoris"), "l'onglet Favoris doit être nommé");
// onglet Compositions : la composition persistée est présente
await page.locator(".barre-nav .nav-onglet", { hasText: "Compositions" }).click();
await page.waitForSelector(".marque");
// UI-1 (D-320) : la preuve de persistance se lit des DEUX côtés de la bascule —
// la mienne d'un côté, les six du kata de l'autre. Un seul côté prouverait la
// moitié du sujet.
assert.equal(await page.locator(".composition-carte").count(), 1, "composition non persistée (côté « Mes compositions »)");
await page.locator(".segments .segment", { hasText: "Packs" }).click();
await page.waitForSelector(".groupe-pack");
await page.locator(".groupe-pack .voir-plus").first().click();
await rendu(page);
assert.equal(await page.locator(".composition-carte").count(), 6, "les six compositions du kata ont été persistées (D-241)");
await page.locator(".segments .segment", { hasText: "Mes compositions" }).click();
await page.waitForSelector(".composition-carte");
await page.locator(".composition-carte .composition-ouvrir", { hasText: "Ma spéciale" }).click();
await page.waitForSelector(".fiche-compo-tete");
await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → liste des compositions
await page.waitForSelector(".composition-carte");

// lot 5 §2 (boucle 5.2) : quatre captures « à rattacher » (elles voyageront
// dans l'export §22) — comptées dans Plus › Médias
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // second appui : racine
await page.waitForSelector(".marque");
await page.locator(".chip-discipline", { hasText: "Judo" }).click();
await page.waitForSelector(".carte-technique");
for (const mot of ["reprise un", "reprise deux", "reprise trois", "reprise quatre"]) {
  await page.locator(".fab", { hasText: "Ajouter" }).click();
  await gesteCapture(page, "note");
  await page.fill(".champ-note", mot);
  await page.click(".feuille .actions .bouton.principal");
  await page.locator(".feuille .actions .bouton", { hasText: "Garder pour plus tard" }).click();
  await page.waitForSelector(".barre .contexte"); // Plus › Médias
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // retour explorateur Judo (mémoire)
  await page.waitForSelector(".carte-technique");
}
await ouvrirPlus(page, "À traiter");
assert.equal(Number(await kpiRattacher().locator(".kpi-nombre").innerText()), 4, "les 4 captures doivent être « à rattacher »");

/* ===== Scénario I — export complet → restauration sur installation VIERGE (R8, D-018.2) ===== */
// D-071 : la publication vit dans Plus › « Créer ou exporter un pack »
await ouvrirPlus(page, "Créer ou exporter un pack");
assert.equal(await page.locator(".fab").count(), 0, "aucune action globale sur Plus");

// lot 6 §19-20 (boucle 6.6, scénario H) : publication ORCHESTRÉE — tuning
// post-V3 : un FORMULAIRE unique (discipline · contenu · vidéos · métadonnées),
// puis « Valider » PRÉPARE le pack et affiche une carte « Pack prêt » ; le
// téléchargement n'a lieu qu'au clic « Enregistrer localement ».
{
  const carteForm = page.locator(".carte-atelier").filter({ has: page.locator(".etiquette-champ", { hasText: "Discipline" }) }).first();
  // choisir la discipline Judo (les fixtures kodokan / club-judo l'alimentent)
  await carteForm.locator(".chip-filtre", { hasText: /^Judo$/ }).first().click();
  await rendu(page);
  // métadonnées facultatives
  await page.fill('[aria-label="Auteur du pack"]', "Club de Castres");
  await page.fill('[aria-label="Note de diffusion"]', "Diffusion interne au club");
  // D-095 : le choix vidéos est explicite (« vidéos locales »), précise que les
  // liens restent inclus, et le récap estime le poids des vidéos embarquées.
  assert.ok((await carteForm.innerText()).includes("Avec les vidéos locales"), "le choix vidéos doit dire « vidéos locales »");
  assert.ok((await carteForm.innerText()).includes("Les liens"), "l'export doit préciser que les liens restent inclus");
  assert.match(await carteForm.innerText(), /aucune vidéo locale|~\s?\d+[\d.,]*\s?(Ko|Mo) de vidéos|sans les vidéos/, "le récap doit annoncer le poids/absence des vidéos locales");
  // Valider : prépare le pack sans rien télécharger (actif car des techniques sont choisies)
  const valider = page.locator(".carte-atelier button.bouton.principal").filter({ hasText: "Valider" });
  assert.ok(!(await valider.isDisabled()), "Valider doit être actif quand au moins une technique est choisie");
  await valider.click();
  // étape 2 : un pack est prêt — taille réelle + choix Enregistrer local / Partager
  const cartePrete = page.locator(".carte-atelier").filter({ has: page.locator(".titre-atelier", { hasText: "Pack prêt" }) });
  await cartePrete.waitFor();
  const detailsPrete = await cartePrete.locator(".details").innerText();
  assert.ok(/\d+\s?(Ko|Mo)/.test(detailsPrete), "la sortie du pack doit annoncer sa taille réelle : " + detailsPrete);
  assert.equal(await cartePrete.locator("button.bouton", { hasText: "Enregistrer localement" }).count(), 1, "le pack prêt doit offrir « Enregistrer localement »");
  assert.equal(await cartePrete.locator("button.bouton", { hasText: "Partager" }).count(), 1, "le pack prêt doit offrir « Partager »");
  assert.equal(await cartePrete.locator(".action-douce", { hasText: "Préparer un autre pack" }).count(), 1, "le pack prêt doit permettre de préparer un autre pack");
  // le TÉLÉCHARGEMENT du .movpack n'a lieu qu'à « Enregistrer localement » (post-V3)
  const [telechargementPack] = await Promise.all([
    page.waitForEvent("download"),
    cartePrete.locator("button.bouton", { hasText: "Enregistrer localement" }).click(),
  ]);
  assert.ok(/judo/i.test(telechargementPack.suggestedFilename()) && telechargementPack.suggestedFilename().endsWith(".movpack"), "le nom du fichier suit le nom éditorial : " + telechargementPack.suggestedFilename());
  await rendu(page);
}

// D-071/D-236 (scission D-308) : la sauvegarde complète vit dans Plus › « Sauvegardes »
await ouvrirPlus(page, "Sauvegardes");
const [telechargement] = await Promise.all([
  page.waitForEvent("download"),
  page.locator(".action-douce", { hasText: "fichier avec les vidéos" }).click(),
]);
const fichierExport = join(tmpdir(), "movenso-e2e-export.movpack");
await telechargement.saveAs(fichierExport);
// lot 6 §21 : la sortie dit le nom réel, la taille et le contenu du fichier
await rendu(page);
{
  const produit = await page.locator(".fichier-produit").innerText();
  assert.ok(produit.includes("Sauvegarde complète de cette installation"), "le rôle du fichier doit être nommé");
  assert.ok(/\.movpack/.test(produit) && /(Ko|Mo)/.test(produit), "nom réel et taille attendus : " + produit);
  assert.ok(produit.includes("vidéo"), "la présence des médias doit être dite");
}

const ctxC = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
const pageC = await ctxC.newPage();
surveiller(pageC);
await pageC.goto("http://localhost:4517/");
await pageC.waitForSelector(".action-douce");
await pageC.evaluate(() => document.querySelector("movenso-app").basculerReglage("compositionsBeta")); // D-223
await rendu(pageC);
const [selecteurC] = await Promise.all([
  pageC.waitForEvent("filechooser"),
  pageC.locator(".action-douce", { hasText: "Importer" }).click(),
]);
await selecteurC.setFiles(fichierExport);
// lot 6 §23.A : le CONTENU s'affiche avant toute écriture ; annuler ne change rien
await pageC.waitForSelector(".feuille[aria-label=\"Restauration complète\"]");
{
  const apercu = await pageC.locator(".feuille .geste").innerText();
  assert.ok(apercu.includes("techniques") && apercu.includes("vidéo"), "l'aperçu de restauration doit décrire le contenu : " + apercu);
}
await pageC.locator(".feuille .actions .bouton", { hasText: "Annuler" }).click();
await finit(async () => assert.equal(await pageC.locator(".feuille").count(), 0, "annuler referme la proposition"));
assert.ok((await pageC.locator(".ecran").innerText()).includes("Importer"), "annuler ne doit rien écrire — l'installation reste vierge");
// recommencer, puis restaurer pour de bon
const [selecteurC2] = await Promise.all([
  pageC.waitForEvent("filechooser"),
  pageC.locator(".action-douce", { hasText: "Importer" }).click(),
]);
await selecteurC2.setFiles(fichierExport);
await pageC.waitForSelector(".feuille[aria-label=\"Restauration complète\"]");
await pageC.locator(".feuille .actions .bouton.principal", { hasText: "Restaurer" }).click();
await pageC.locator(".toast", { hasText: "restaurée" }).waitFor(); // le toast d'annulation peut encore s'éteindre
await rendu(pageC);
await pageC.locator(".barre-nav .nav-onglet", { hasText: "Compositions" }).click();
await pageC.waitForSelector(".marque");
assert.equal(await pageC.locator(".composition-carte").count(), 1, "composition perdue à la restauration (côté « Mes compositions »)");
await pageC.locator(".segments .segment", { hasText: "Packs" }).click();
await pageC.waitForSelector(".groupe-pack");
await pageC.locator(".groupe-pack .voir-plus").first().click();
await rendu(pageC);
assert.equal(await pageC.locator(".composition-carte").count(), 6, "les six compositions du kata perdues à la restauration (D-241)");
await pageC.locator(".segments .segment", { hasText: "Mes compositions" }).click();
await pageC.waitForSelector(".composition-carte");
// lot 5 §4/§22 : les favoris voyagent dans la sauvegarde intégrale et
// pointent vers les bonnes techniques après restauration → onglet Favoris
await pageC.locator(".barre-nav .nav-onglet", { hasText: "Favoris" }).click();
await pageC.waitForSelector(".carte-technique");
assert.ok((await pageC.locator(".carte-technique").count()) >= 1, "les favoris doivent survivre à la restauration intégrale");
assert.ok((await pageC.locator(".carte-technique").innerText()).includes("Essai du panneau"), "le favori restauré doit pointer la bonne technique");
// les captures « à rattacher » survivent → Plus › Médias
await ouvrirPlus(pageC, "À traiter");
assert.ok(
  Number(await pageC.locator(".kpi").filter({ has: pageC.locator(".kpi-libelle", { hasText: "Captures à rattacher" }) }).locator(".kpi-nombre").innerText()) >= 1,
  "les captures à reprendre doivent rester accessibles après restauration (§22)",
);
// lot 5 §22 : la composition restaurée garde ordre et textes (le mode entraînement a été retiré)
await pageC.locator(".barre-nav .nav-onglet", { hasText: "Compositions" }).click();
await pageC.waitForSelector(".composition-carte");
await pageC.locator(".composition-carte .composition-ouvrir", { hasText: "Ma spéciale" }).click();
await pageC.waitForSelector(".fiche-compo-tete"); // ouvrir = consulter (UI-2)
await pageC.locator(".basculer-edition").click(); // ✎ : la liste des blocs vit dans l'éditeur
await pageC.waitForSelector(".blocs");
const blocsRestaure = await pageC.locator(".bloc:not(.menu-bloc)").allInnerTexts();
assert.ok(blocsRestaure[1].includes("transition au sol — rouler"), "l'ordre et les textes doivent survivre à la restauration : " + blocsRestaure.join(" | "));
await pageC.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → liste
await pageC.waitForSelector(".composition-carte");
await pageC.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // Bibliothèque
await ouvrirDisc(pageC, "Judo");
await pageC.waitForSelector(".carte-technique");
assert.ok((await pageC.locator(".barre .contexte").innerText()).includes("Judo"), "discipline perdue à la restauration");
assert.ok((await pageC.locator(".carte-technique").count()) >= 130, "identités perdues à la restauration");
// les notes personnelles ont voyagé : la fiche rattachée porte toujours son carnet
await pageC.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → racine Bibliothèque
await pageC.fill(".recherche input", "sasae");
await rendu(pageC);
await pageC.locator(".carte-technique").first().locator(".carte-ouvrir").click();
await pageC.waitForSelector(".fiche-entete h1");
assert.ok((await pageC.locator(".commentaire-zone").inputValue()).includes("Balayage vu en randori"), "note personnelle perdue à la restauration");

// lot 6 §25-26 (boucle 6.7, scénario L) : réglage de démarrage sur une
// discipline choisie, fallback DISCRET quand elle disparaît ; protections
// sans aucun contrôle factice
await ouvrirPlus(pageC, "Sécurité");
{
  // lot 7 §15 : l'appareil personnel est le DÉFAUT — aucun PIN nulle part
  const reglages = await pageC.locator(".ecran").innerText();
  assert.ok(reglages.includes("Aucune protection active"), "l'état RÉEL des protections doit être dit");
  assert.ok(reglages.toLowerCase().includes("libre"), "le fonctionnement personnel par défaut doit être nommé");
}
await ouvrirPlus(pageC, "Apparence");
await pageC.locator(".ecran .chip-filtre", { hasText: /^Judo$/ }).click(); // démarrage : discipline choisie
await rendu(pageC);
await pageC.reload();
await pageC.waitForSelector(".barre .contexte");
assert.ok((await pageC.locator(".barre .contexte").innerText()).includes("Judo"), "le démarrage doit ouvrir la discipline choisie");
// la discipline choisie disparaît → Bibliothèque + information discrète
await ouvrirPlus(pageC, "Disciplines et classement");
// D-308 : la ✕ de la ligne de discipline ouvre directement le récap guardé
// (non vide) — l'ancienne 🗑️ de la carte a disparu au profit de la ✕ uniforme.
await pageC.locator('[aria-label="Supprimer « Judo »"]').click();
await pageC.waitForSelector(".suppression-discipline");
await pageC.locator(".suppression-discipline .action-danger", { hasText: "Supprimer la discipline" }).click();
await pageC.waitForSelector(".feuille-confirmation");
await pageC.locator(".feuille-confirmation .bouton.danger").click();
await pageC.waitForTimeout(lent(400));
await pageC.reload();
await pageC.waitForSelector(".marque"); // racine Bibliothèque — jamais de blocage
assert.ok((await pageC.locator(".toast").innerText()).includes("n'existe plus"), "l'utilisateur doit être informé discrètement du repli");

// petit corpus pour les scénarios sécurité — créé AVANT les protections
// (dès 7.4, la création est elle-même une action protégée)
// D-328 : supprimer sa dernière discipline ne rend PAS la bibliothèque vierge
// — il reste une corbeille, des favoris, des compositions et la trace des
// packs installés. L'écran de première ouverture ne revient donc pas (il
// mentirait), et c'est la Bibliothèque ordinaire qui se rend : son message
// d'absence de technique, et l'action flottante « ＋ Ajouter ».
assert.equal(await pageC.locator(".ecran-vierge").count(), 0, "une bibliothèque vidée n'est pas VIERGE (D-327)");
assert.ok((await pageC.locator(".sans-resultat").innerText()).includes("Aucune technique pour l'instant"), "la Bibliothèque vidée dit son absence de technique");
await pageC.locator(".fab", { hasText: "Ajouter" }).click();
await pageC.waitForSelector(".gestes-ajouter");
await pageC.locator(".option-ajouter", { hasText: "Créer une technique" }).click();
await pageC.waitForSelector(".champ-nouveau-nom");
await pageC.fill(".champ-nouveau-nom", "Jab");
await pageC.fill(".champ-discipline", "Boxe");
await pageC.locator(".feuille .actions .bouton.principal", { hasText: "Créer la technique" }).click();
await pageC.waitForSelector(".edition");
await pageC.locator('.fiche-actions [aria-label="Enregistrer"]').click();
await pageC.locator(".fiche-entete h1", { hasText: "Jab" }).waitFor();

// lot 7 §3/§12/§14 (boucle 7.2, scénarios B et H partiels) : activation,
// seconde protection sans nouveau PIN, désactivation, préréglage partagé
await ouvrirPlus(pageC, "Sécurité");
const ligneModifs = () => pageC.locator(".ligne-atelier").filter({ hasText: "Modifications" }).first();
const ligneSuppr = () => pageC.locator(".ligne-atelier").filter({ hasText: "Suppressions" }).first();
await ligneModifs().locator(".chip-filtre", { hasText: "Protéger" }).click();
await pageC.waitForSelector(".formulaire-pin");
assert.ok((await pageC.locator(".formulaire-pin").innerText()).includes("consultation reste toujours libre"), "l'activation doit expliquer ce qui sera protégé");
// confirmation différente : RIEN n'est activé, l'écran reste, erreur claire
await pageC.fill('.formulaire-pin input[aria-label="Nouveau PIN"]', "731905");
await pageC.fill('.formulaire-pin input[aria-label="Confirmation du PIN"]', "731906");
await pageC.locator(".formulaire-pin .bouton.principal").click();
await pageC.waitForSelector(".erreur-pin");
assert.ok((await pageC.locator(".erreur-pin").innerText()).includes("ne correspondent pas"), "l'erreur de confirmation doit être claire");
assert.ok((await ligneModifs().innerText()).includes("libre"), "rien ne doit s'activer sur une confirmation différente");
// bonne confirmation → activée
await pageC.fill('.formulaire-pin input[aria-label="Nouveau PIN"]', "731905");
await pageC.fill('.formulaire-pin input[aria-label="Confirmation du PIN"]', "731905");
await pageC.locator(".formulaire-pin .bouton.principal").click();
await pageC.locator(".toast", { hasText: "activée" }).waitFor();
assert.ok((await ligneModifs().innerText()).includes("protégée par le PIN"), "l'activation doit se voir");
// seconde protection : le PIN existant sert — aucun nouveau PIN demandé (§3)
await ligneSuppr().locator(".chip-filtre", { hasText: "Protéger" }).click();
await pageC.locator(".toast", { hasText: "opérations sensibles activée" }).waitFor();
assert.equal(await pageC.locator(".formulaire-pin").count(), 0, "un PIN existant sert aux deux protections");
assert.ok((await pageC.locator(".ecran").innerText()).includes("session déverrouillée"), "le délai de session doit se régler");
// scénario G : changer le PIN — l'ancien est ensuite refusé, le nouveau accepté
await pageC.locator(".chip-filtre", { hasText: "Changer le PIN" }).click();
await pageC.fill('.formulaire-pin input[aria-label="PIN actuel"]', "731905");
await pageC.fill('.formulaire-pin input[aria-label="Nouveau PIN"]', "824613");
await pageC.fill('.formulaire-pin input[aria-label="Confirmation du nouveau PIN"]', "824613");
await pageC.locator(".formulaire-pin .bouton.principal", { hasText: "Changer le PIN" }).click();
await pageC.locator(".toast", { hasText: "PIN changé" }).waitFor();
// désactivation : l'ANCIEN PIN est refusé, rien ne change
await ligneModifs().locator(".chip-filtre", { hasText: "Désactiver" }).click();
await pageC.fill('.formulaire-pin input[aria-label="PIN actuel"]', "731905");
await pageC.locator(".formulaire-pin .action-danger").click();
await pageC.waitForSelector(".erreur-pin");
assert.ok((await pageC.locator(".erreur-pin").innerText()).includes("incorrect"), "l'ancien PIN doit être refusé après changement");
assert.ok((await ligneModifs().innerText()).includes("protégée"), "un mauvais PIN ne désactive rien");
// le NOUVEAU PIN est accepté → désactivée, l'AUTRE reste (indépendantes)
await pageC.fill('.formulaire-pin input[aria-label="PIN actuel"]', "824613");
await pageC.locator(".formulaire-pin .action-danger").click();
await pageC.locator(".toast", { hasText: "l'autre reste active" }).waitFor();
assert.ok((await ligneModifs().innerText()).includes("libre"), "la protection désactivée doit se voir");
assert.ok((await ligneSuppr().innerText()).includes("protégée"), "les protections sont indépendantes");
// désactiver la dernière → le secret est SUPPRIMÉ, plus rien n'est demandé
await ligneSuppr().locator(".chip-filtre", { hasText: "Désactiver" }).click();
await pageC.fill('.formulaire-pin input[aria-label="PIN actuel"]', "824613");
await pageC.locator(".formulaire-pin .action-danger").click();
await pageC.locator(".toast", { hasText: "supprimées" }).waitFor();
assert.ok((await pageC.locator(".ecran").innerText()).includes("Aucune protection active"), "sans protection, le secret ne survit pas par inertie");
// réactivation manuelle des DEUX protections (le préréglage a été retiré, D-102) :
// création du PIN sur « Modifications », puis « Suppressions » réutilise ce PIN
await ligneModifs().locator(".chip-filtre", { hasText: "Protéger" }).click();
await pageC.waitForSelector(".formulaire-pin");
await pageC.fill('.formulaire-pin input[aria-label="Nouveau PIN"]', "731905");
await pageC.fill('.formulaire-pin input[aria-label="Confirmation du PIN"]', "731905");
await pageC.locator(".formulaire-pin .bouton.principal").click();
await pageC.locator(".toast", { hasText: "activée" }).waitFor();
await ligneSuppr().locator(".chip-filtre", { hasText: "Protéger" }).click();
await pageC.locator(".toast", { hasText: "opérations sensibles activée" }).waitFor();
{
  const apres = await pageC.locator(".ecran").innerText();
  assert.equal((apres.match(/protégée par le PIN/g) ?? []).length, 2, "les deux protections doivent être actives pour la suite");
}

// lot 7 §7-9 (boucle 7.3, scénarios B5-8 et C partiels) : déverrouillage au
// point d'action, reprise automatique, session curateur, verrouillage manuel
await pageC.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // mémoire : fiche Jab
await pageC.locator(".fiche-entete h1", { hasText: "Jab" }).waitFor();
// l'action protégée ouvre le panneau contextuel — la RAISON est dite
await pageC.locator('.barre [aria-label="Modifier"]').click();
await pageC.waitForSelector('.feuille[aria-label="Action protégée"]');
assert.ok((await pageC.locator(".feuille .geste").innerText()).includes("Jab"), "le panneau doit dire POURQUOI le PIN est demandé");
assert.equal(await pageC.locator(".edition").count(), 0, "rien ne s'exécute avant le PIN");
// annuler = retour exact au contexte, rien n'a changé
await pageC.locator(".feuille .actions .bouton", { hasText: "Annuler" }).click();
await finit(async () => assert.equal(await pageC.locator(".edition").count(), 0, "annuler n'exécute pas l'action protégée"));
await pageC.locator(".fiche-entete h1", { hasText: "Jab" }).waitFor();
// mauvais PIN : erreur sobre, l'action reste en attente
await pageC.locator('.barre [aria-label="Modifier"]').click();
await pageC.waitForSelector('.feuille[aria-label="Action protégée"]');
await pageC.fill(".feuille .champ-pin", "999999");
await pageC.locator(".feuille .bouton.principal", { hasText: "Déverrouiller" }).click();
await pageC.waitForSelector(".feuille .erreur-pin");
assert.ok((await pageC.locator(".feuille .erreur-pin").innerText()).includes("incorrect"), "l'erreur ne révèle rien d'autre");
assert.equal(await pageC.locator(".edition").count(), 0, "un mauvais PIN n'exécute rien");
// bon PIN : l'édition s'ouvre D'ELLE-MÊME (reprise automatique de l'action)
await pageC.fill(".feuille .champ-pin", "731905");
await pageC.locator(".feuille .bouton.principal", { hasText: "Déverrouiller" }).click();
await pageC.waitForSelector(".edition");
await pageC.locator('.fiche-actions [aria-label="Enregistrer"]').click();
await rendu(pageC);
// session curateur : la seconde modification ne redemande pas le PIN
await pageC.locator('.barre [aria-label="Modifier"]').click();
await pageC.waitForSelector(".edition");
assert.equal(await pageC.locator('.feuille[aria-label="Action protégée"]').count(), 0, "la session curateur ne redemande pas le PIN immédiatement");
await pageC.locator('.fiche-actions [aria-label="Enregistrer"]').click();
// indicateur discret, puis « Verrouiller maintenant » → le PIN revient
await pageC.waitForSelector(".session-curateur");
await pageC.locator(".session-curateur").click();
await pageC.locator(".toast", { hasText: "Verrouillé" }).waitFor();
assert.equal(await pageC.locator(".session-curateur").count(), 0, "l'indicateur disparaît une fois verrouillé");
await pageC.locator('.barre [aria-label="Modifier"]').click();
await pageC.waitForSelector('.feuille[aria-label="Action protégée"]');
await pageC.locator(".feuille .actions .bouton", { hasText: "Annuler" }).click();
await rendu(pageC);

// lot 7 §2/§9 (boucle 7.4, scénario D) : protections DISTINCTES — modifier
// librement quand seules les suppressions sont protégées ; le PIN d'une
// suppression arrive AVANT la confirmation destructive, qui reste due
await ouvrirPlus(pageC, "Sécurité");
await pageC.locator(".ligne-atelier").filter({ hasText: "Modifications" }).first()
  .locator(".chip-filtre", { hasText: "Désactiver" }).click();
await pageC.fill('.formulaire-pin input[aria-label="PIN actuel"]', "731905");
await pageC.locator(".formulaire-pin .action-danger").click();
await pageC.locator(".toast", { hasText: "l'autre reste active" }).waitFor();
// modifier une fiche SANS PIN (seules les suppressions sont protégées)
await pageC.locator(".barre-nav .nav-onglet:nth-child(1)").click();
await pageC.locator(".fiche-entete h1", { hasText: "Jab" }).waitFor();
await pageC.locator('.barre [aria-label="Modifier"]').click();
await pageC.waitForSelector(".edition");
assert.equal(await pageC.locator('.feuille[aria-label="Action protégée"]').count(), 0, "modifier reste libre quand seules les suppressions sont protégées");
await pageC.fill("#champ-sous-titre", "direct du bras avant");
await pageC.locator('.fiche-actions [aria-label="Enregistrer"]').click();
await finit(async () => assert.ok((await pageC.locator(".fiche-entete .jp").innerText()).includes("direct du bras avant"), "la modification s'enregistre sans PIN"));
// D-115 : dès qu'un PIN protège l'appareil, le commentaire de fiche passe en
// LECTURE SEULE — la consultation reste une pure consultation (aucune écriture
// furtive), même si les modifications ne sont pas protégées.
assert.equal(await pageC.locator("textarea.commentaire-zone").count(), 0, "commentaire non éditable dès qu'un PIN existe (D-115)");
assert.ok((await pageC.locator(".bloc-lecture.commentaire").innerText()).includes("Lecture seule"), "le commentaire dit pourquoi il est verrouillé");
// supprimer : PIN d'abord, PUIS la confirmation destructive — annuler = rien.
// La suppression vit dans Plus › « Techniques » (entrée de menu à part, post-V3).
await ouvrirPlus(pageC, "Gestion des techniques");
await pageC.fill(".recherche input", "jab");
await rendu(pageC);
await pageC.locator('.supprimer-technique[aria-label="Retirer Jab"]').click();
await pageC.waitForSelector('.feuille[aria-label="Action protégée"]');
assert.equal(await pageC.locator(".feuille-confirmation").count(), 0, "le PIN arrive AVANT la confirmation destructive");
await pageC.fill(".feuille .champ-pin", "731905");
await pageC.locator(".feuille .bouton.principal", { hasText: "Déverrouiller" }).click();
// C2 : le PIN ne remplace JAMAIS la confirmation — la feuille nommée suit
await pageC.waitForSelector(".feuille-confirmation");
assert.ok((await pageC.locator(".feuille-confirmation h2").innerText()).includes("Jab"), "la confirmation nomme la technique après le PIN");
await pageC.locator(".voile").last().click(); // annuler sans effet
await finit(async () => assert.equal(await pageC.locator(".feuille-confirmation").count(), 0, "le voile annule la confirmation"));
assert.ok((await pageC.locator(".ecran").innerText()).includes("Jab"), "annuler la confirmation ne supprime rien");

// lot 7 §22 (boucle 7.5, scénario L du lot) : réinitialisation complète —
// PIN (suppressions protégées), explication, annulation, confirmation
await pageC.locator(".session-curateur").click(); // verrouiller la session ouverte
await pageC.locator(".toast", { hasText: "Verrouillé" }).waitFor();
await ouvrirPlus(pageC, "Diagnostic et maintenance");
await pageC.locator(".action-danger.reinitialiser").click();
await pageC.waitForSelector('.feuille[aria-label="Action protégée"]'); // opération sensible → PIN
await pageC.fill(".feuille .champ-pin", "731905");
await pageC.locator(".feuille .bouton.principal", { hasText: "Déverrouiller" }).click();
await pageC.waitForSelector(".suppression-discipline");
assert.ok((await pageC.locator(".suppression-discipline").innerText()).includes("PIN compris"), "la réinitialisation explique TOUT ce qui sera supprimé");
await pageC.locator(".suppression-discipline .chip-filtre", { hasText: "Annuler" }).click();
await finit(async () => assert.equal(await pageC.locator(".suppression-discipline").count(), 0, "annuler referme la réinitialisation"));
assert.ok(await pageC.evaluate(() => document.querySelector("movenso-app").preferences.protections?.suppressions ?? false), "annuler ne supprime rien — la protection reste active");
// confirmation renforcée → bibliothèque vide, plus aucune protection ni PIN
await pageC.locator(".action-danger.reinitialiser").click(); // session encore ouverte
await pageC.waitForSelector(".suppression-discipline");
await pageC.locator(".suppression-discipline .action-danger", { hasText: "Tout supprimer" }).click();
await pageC.waitForSelector(".feuille-confirmation");
await pageC.locator(".feuille-confirmation .bouton.danger").click();
await pageC.locator(".toast", { hasText: "réinitialisé" }).waitFor();
await pageC.waitForSelector(".action-douce");
assert.ok((await pageC.locator(".ecran").innerText()).includes("Elle démarre vide, choisis comment commencer"), "retour à la Bibliothèque vide");
// D-328 : une réinitialisation COMPLÈTE, elle, rend bien la bibliothèque
// VIERGE — c'est le seul geste qui ramène l'écran de première ouverture.
assert.equal(await pageC.locator(".ecran-vierge").count(), 1, "la réinitialisation complète rend la bibliothèque VIERGE (D-327)");
assert.equal(await pageC.locator(".fab").count(), 0, "et l'action flottante disparaît à nouveau (D-327)");
// tuning post-V3 : après réinitialisation, l'état vide crée la première
// technique (discipline à la volée) — action UI, protégée si un PIN existait.
await pageC.locator(".action-douce", { hasText: "Créer ta première technique" }).click();
await pageC.waitForSelector(".champ-nouveau-nom");

/* ===== Lot 8A boucle 8A.2 (§5, scénario B) — ingestion unique + déduplication :
   le MÊME fichier ajouté deux fois (même renommé) → UN SEUL fichier physique,
   DEUX références ; un contenu différent → un second fichier. ===== */
await pageC.fill(".champ-nouveau-nom", "Mawashi-geri");
await pageC.fill(".champ-discipline", "Karaté");
await pageC.locator(".feuille .actions .bouton.principal", { hasText: "Créer la technique" }).click();
await pageC.waitForSelector(".edition");
assert.equal(await pageC.locator('.feuille[aria-label="Action protégée"]').count(), 0, "après réinitialisation : plus aucun PIN nulle part");
await pageC.locator('.fiche-actions [aria-label="Enregistrer"]').click();
await pageC.locator(".fiche-entete h1", { hasText: "Mawashi-geri" }).waitFor();
{
  const dedup = await pageC.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const compterFichiers = async () => {
      const racine = await navigator.storage.getDirectory();
      let dossier;
      try { dossier = await racine.getDirectoryHandle("videos"); } catch { return 0; }
      let n = 0;
      for await (const nom of dossier.keys()) n += nom ? 1 : 0;
      return n;
    };
    const t = app.bibliotheque.techniques.find((x) => x.nom === "Mawashi-geri");
    const octets = new Uint8Array(64 * 1024).fill(7);
    await app.ajouterMediaFiche(t.id, { fichier: new File([octets], "kata original.webm", { type: "video/webm" }) });
    const apresPremier = await compterFichiers();
    // le MÊME contenu, renommé et sous un autre MIME déclaré : doublon exact
    await app.ajouterMediaFiche(t.id, { fichier: new File([octets], "copie (1).mp4", { type: "video/mp4" }) });
    const apresDoublon = await compterFichiers();
    // un contenu DIFFÉRENT de même taille : jamais dédupliqué
    await app.ajouterMediaFiche(t.id, { fichier: new File([new Uint8Array(64 * 1024).fill(8)], "autre.webm", { type: "video/webm" }) });
    const apresDistinct = await compterFichiers();
    const locaux = app.bibliotheque.contributions
      .filter((c) => c.techniqueId === t.id)
      .flatMap((c) => c.medias)
      .filter((m) => m.type === "local");
    const noms = [];
    for await (const n of (await (await navigator.storage.getDirectory()).getDirectoryHandle("videos")).keys()) noms.push(n);
    return {
      apresPremier,
      apresDoublon,
      apresDistinct,
      noms,
      ids: locaux.map((m) => m.id),
      empreintes: locaux.map((m) => m.sha256),
      metas: locaux.map((m) => ({ nom: m.nomOriginal, ext: m.extension, taille: m.taille, origine: m.origineMedia })),
    };
  });
  assert.equal(dedup.apresPremier, 1, "le premier ajout écrit UN fichier");
  assert.equal(dedup.apresDoublon, 1, "le doublon exact n'écrit RIEN : id réutilisé, une seule copie physique");
  assert.equal(dedup.apresDistinct, 2, "un contenu différent (même taille) écrit son propre fichier");
  assert.equal(dedup.ids.length, 3, "trois références métier existent bien");
  assert.equal(dedup.ids[0], dedup.ids[1], "les deux références du doublon partagent le MÊME id de média");
  assert.notEqual(dedup.ids[2], dedup.ids[0], "le contenu différent a son propre média");
  assert.equal(dedup.empreintes[0], dedup.empreintes[1], "l'empreinte SHA-256 est identique sur les deux références");
  assert.ok(dedup.empreintes.every((e) => /^[0-9a-f]{64}$/.test(e)), "chaque média local ingéré porte son empreinte");
  assert.equal(dedup.metas[1].nom, "kata original.webm", "le doublon conserve les métadonnées d'ORIGINE, pas celles de la copie");
  assert.deepEqual(
    { ext: dedup.metas[0].ext, taille: dedup.metas[0].taille, origine: dedup.metas[0].origine },
    { ext: "webm", taille: 64 * 1024, origine: "fichier" },
    "métadonnées réelles : extension canonique, taille en octets, origine",
  );
  // lot 8A §6 (boucle 8A.4) : le nom PHYSIQUE est `<mediaId>.<extension
  // canonique>` — jamais le nom humain, qui vit dans les métadonnées
  assert.ok(dedup.noms.every((n) => n.endsWith(".webm")), "les nouveaux fichiers portent l'extension canonique : " + dedup.noms.join(", "));
  assert.ok(dedup.noms.every((n) => !n.toLowerCase().includes("kata") && !n.includes(" ")), "le nom physique ne dépend jamais du nom d'origine");
  // §5 étape 4 : non-vidéo et fichier vide REFUSÉS avant toute écriture
  const refuses = await pageC.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const t = app.bibliotheque.techniques.find((x) => x.nom === "Mawashi-geri");
    const avant = app.bibliotheque.contributions.length;
    await app.ajouterMediaFiche(t.id, { fichier: new File([new Uint8Array(4)], "notes.pdf", { type: "application/pdf" }) });
    await app.ajouterMediaFiche(t.id, { fichier: new File([], "vide.webm", { type: "video/webm" }) });
    return app.bibliotheque.contributions.length - avant;
  });
  assert.equal(refuses, 0, "non-vidéo et fichier vide sont refusés AVANT toute écriture (§5)");
  // la fiche montre les TROIS références (sélecteur de médias horizontal)
  await pageC.waitForSelector(".media-choix");
  assert.ok(
    (await pageC.locator('.media-choix .chip-filtre:not([aria-label="Ajouter un média"])').count()) >= 3,
    "trois médias visibles sur la fiche",
  );
}

/* ===== Lot 8A boucle 8A.3 (§4, scénario A) — média partagé : retirer une
   référence ne supprime JAMAIS le fichier tant qu'une autre existe ; la
   dernière référence retirée → le fichier devient ORPHELIN (jamais supprimé
   en silence) ; suppression physique UNIQUEMENT après prévisualisation +
   confirmation (flux 6.5). ===== */
{
  const compterVideosC = () => pageC.evaluate(async () => {
    const racine = await navigator.storage.getDirectory();
    let dossier;
    try { dossier = await racine.getDirectoryHandle("videos"); } catch { return 0; }
    let n = 0;
    for await (const nom of dossier.keys()) n += nom ? 1 : 0;
    return n;
  });
  // état hérité du scénario B : 2 fichiers physiques, le premier partagé
  // par deux contributions (id commun), le second référencé une fois
  const etape1 = await pageC.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const t = app.bibliotheque.techniques.find((x) => x.nom === "Mawashi-geri");
    const locales = app.bibliotheque.contributions.filter((c) => c.techniqueId === t.id && c.medias[0]?.type === "local");
    const parId = new Map();
    for (const c of locales) parId.set(c.medias[0].id, [...(parId.get(c.medias[0].id) ?? []), c]);
    const [partageId, [, doublon]] = [...parId.entries()].find(([, cs]) => cs.length === 2);
    await app.supprimerContribution(doublon.id);
    const octets = await app.stockage.lireVideo(partageId);
    return { partageId, lisible: octets !== null && octets.length > 0 };
  });
  assert.equal(await compterVideosC(), 2, "retirer UNE référence ne supprime jamais un fichier encore partagé");
  assert.ok(etape1.lisible, "la vidéo reste lisible dans l'autre contribution");
  // retirer la DERNIÈRE référence : le fichier n'est PAS supprimé — il
  // devient orphelin ; le snapshot « avant-retrait » reste restaurable
  const etape2 = await pageC.evaluate(async (partageId) => {
    const app = document.querySelector("movenso-app");
    const derniere = app.bibliotheque.contributions.find((c) => c.medias.some((m) => m.id === partageId));
    await app.supprimerContribution(derniere.id);
    return app.bibliotheque.contributions.some((c) => c.medias.some((m) => m.id === partageId));
  }, etape1.partageId);
  assert.equal(etape2, false, "plus aucune référence métier vers le média retiré");
  assert.equal(await compterVideosC(), 2, "la dernière référence retirée CONSERVE le fichier : orphelin, jamais de suppression silencieuse (§4)");
  // l'Atelier diagnostique l'orphelin ; suppression physique après
  // prévisualisation OBLIGATOIRE + confirmation — et elle ne touche que lui
  await ouvrirPlus(pageC, "À traiter");
  await pageC.waitForTimeout(lent(400)); // rafraîchissement asynchrone (tailles OPFS)
  assert.equal(
    Number(await pageC.locator(".kpi").filter({ has: pageC.locator(".kpi-libelle", { hasText: "Fichiers inutilisés" }) }).locator(".kpi-nombre").innerText()),
    1,
    "l'orphelin issu du retrait doit être diagnostiqué",
  );
  // D-104 : « Fichiers inutilisés » est un KPI dépliable — on l'ouvre pour voir les lignes
  await pageC.locator(".kpi-filtre").filter({ has: pageC.locator(".kpi-libelle", { hasText: "Fichiers inutilisés" }) }).click();
  await finit(async () => assert.equal(await pageC.locator(".ligne-orpheline .action-danger").count(), 0, "aucune suppression sans prévisualisation"));
  await pageC.locator(".ligne-orpheline .chip-filtre", { hasText: "Vérifier" }).click();
  await pageC.waitForSelector(".ligne-orpheline movenso-video-locale");
  await pageC.locator(".ligne-orpheline .action-danger").click();
  await pageC.waitForSelector(".feuille-confirmation"); // C2 : feuille nommée
  await pageC.locator(".feuille-confirmation .bouton.danger").click();
  await pageC.waitForTimeout(lent(400));
  assert.equal(await pageC.locator(".ligne-orpheline").count(), 0, "l'orphelin supprimé disparaît du diagnostic");
  assert.equal(await compterVideosC(), 1, "la suppression physique n'arrive qu'APRÈS confirmation — et ne touche que l'orphelin");
  // S2.12 (D-168) : un média RETROUVÉ se rattache à une fiche — le fichier ne
  // bouge pas, il redevient référencé (contribution personnelle).
  await pageC.evaluate(async () => {
    const videos = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos", { create: true });
    const h = await videos.getFileHandle("01RTRV0000000000000000ABCD.webm", { create: true });
    const w = await h.createWritable();
    await w.write(new Uint8Array(4096).fill(9));
    await w.close();
  });
  await ouvrirPlus(pageC, "À traiter");
  await pageC.waitForTimeout(lent(400)); // rafraîchissement asynchrone (tailles OPFS)
  await pageC.locator(".kpi-filtre").filter({ has: pageC.locator(".kpi-libelle", { hasText: "Fichiers inutilisés" }) }).click();
  await pageC.waitForSelector(".ligne-orpheline");
  await pageC.locator(".ligne-orpheline .chip-filtre", { hasText: "Vérifier" }).click();
  await pageC.fill('input[aria-label="Rattacher ce fichier à une technique"]', "Mawashi");
  await rendu(pageC);
  await pageC.locator(".ligne-orpheline .chips-filtres .chip-filtre", { hasText: "Mawashi-geri" }).click();
  await pageC.locator(".toast", { hasText: "rattaché" }).waitFor();
  await finit(async () => assert.equal(await pageC.locator(".ligne-orpheline").count(), 0, "le média rattaché n'est plus orphelin"));
  const rattache = await pageC.evaluate(() => {
    const app = document.querySelector("movenso-app");
    return app.bibliotheque.contributions.some((c) => c.medias.some((m) => m.id === "01RTRV0000000000000000ABCD"));
  });
  assert.ok(rattache, "la contribution personnelle porte le média retrouvé");
  // S2.12/D-171 : suppression GROUPÉE des fichiers VÉRIFIÉS — le bouton
  // n'apparaît qu'à partir de 2 vérifiés, nomme le compte et la taille
  // totale, et ne touche jamais un fichier non vérifié.
  await pageC.evaluate(async () => {
    const videos = await (await navigator.storage.getDirectory()).getDirectoryHandle("videos", { create: true });
    for (const n of ["01GRP10000000000000000ABCD", "01GRP20000000000000000ABCD", "01GRP30000000000000000ABCD"]) {
      const h = await videos.getFileHandle(`${n}.webm`, { create: true });
      const w = await h.createWritable();
      await w.write(new Uint8Array(2048).fill(7));
      await w.close();
    }
  });
  await ouvrirPlus(pageC, "À traiter");
  await pageC.waitForTimeout(lent(400)); // rafraîchissement asynchrone (tailles OPFS)
  await pageC.locator(".kpi-filtre").filter({ has: pageC.locator(".kpi-libelle", { hasText: "Fichiers inutilisés" }) }).click();
  await pageC.waitForSelector(".ligne-orpheline");
  assert.equal(await pageC.locator(".ligne-orpheline").count(), 3, "trois orphelins plantés pour la suppression groupée");
  await pageC.locator(".ligne-orpheline .chip-filtre", { hasText: "Vérifier" }).first().click();
  await finit(async () => assert.equal(await pageC.locator(".suppression-groupe-orphelins").count(), 0, "UN seul vérifié : pas de bouton groupé (l'individuel reste le chemin premier)"));
  await pageC.locator(".ligne-orpheline .chip-filtre", { hasText: "Vérifier" }).first().click();
  await finit(async () => assert.match(
    await pageC.locator(".suppression-groupe-orphelins").innerText(),
    /Supprimer les 2 fichiers vérifiés — .+[ko]/i,
    "le bouton groupé nomme le compte ET la taille totale (D-171)",
  ));
  await pageC.locator(".suppression-groupe-orphelins").click();
  await pageC.waitForSelector(".feuille-confirmation");
  assert.match(await pageC.locator(".feuille-confirmation h2").innerText(), /2 fichiers vérifiés/, "la feuille groupée nomme le compte (D-171/C2)");
  await pageC.locator(".feuille-confirmation .bouton.danger").click();
  await pageC.locator(".toast", { hasText: "2 fichiers inutilisés supprimés" }).waitFor();
  await finit(async () => assert.equal(await pageC.locator(".ligne-orpheline").count(), 1, "seuls les fichiers VÉRIFIÉS partent — le non-vérifié reste"));
  // NR : le média encore référencé reste affiché et lisible sur la fiche
  await pageC.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await pageC.locator(".fiche-entete h1", { hasText: "Mawashi-geri" }).waitFor();
  await pageC.waitForSelector(".media-principal");
  assert.ok((await pageC.locator(".media-principal movenso-video-locale").count()) >= 1, "le média distinct survit intact et lisible sur la fiche");
}
await ctxC.close();

await chapitreEspaceInsuffisant({ fichierExport });
await chapitreIntegritePack();
await chapitreReimportMemePack();
await chapitreIdentitePackRenommage();
await chapitreBasculeEtatAtomique();
await chapitreAtomiciteMediaMetier();
await chapitreSauvegardeHonnete();
await chapitreSnapshotRetention();
await chapitreExportDiagnostic();
await chapitrePinCapture();
await chapitrePublicationCibleExterne();
await chapitreDefusionDoublons();
await chapitreCompositionAPlusieurs();
await chapitreFiltresMolette();
await chapitreRetraitsLiens();
await chapitreAnnulationEdition();
await chapitreVignettesDistantes();
await chapitreImagesEnFichiers();

/* ===== B2 (D-211) — PACKS OFFICIELS : catalogue du site public consultable
   dans Plus, installation via le circuit d'import NORMAL (proposition →
   confirmation). Hors site (dev/e2e sans route) : état honnête. ===== */
await ouvrirPlus(page, "Packs officiels");
await finit(async () => assert.ok((await page.locator(".ecran").innerText()).includes("Catalogue injoignable"), "hors du site public, l'écran dit pourquoi (B2)"));
await page.route("**/packs/index.json", (r) => r.fulfill({
  contentType: "application/json",
  // D-333 : le catalogue publie aussi la maturité, la date, l'illustration et
  // l'identité du manifeste. La fixture porte les mêmes champs que le vrai.
  body: JSON.stringify([{ id: "judo", title: "Judo", discipline: "Judo", version: "0.5.0",
    itemCount: "111 techniques · 315 liens expliqués", href: "packs/judo.movpack",
    downloadName: "judo.movpack", statusLabel: "Bêta", updatedAt: "14 août 2026",
    icon: "packs/img/judo-kodokan.webp", packId: "pack-TEST", versionEditoriale: 14 }]),
}));
await page.route("**/packs/img/*.webp", (r) => r.fulfill({
  contentType: "image/webp",
  body: readFileSync(new URL("../public/img/depart-pack-officiel.webp", import.meta.url)),
}));
await page.route("**/packs/judo.movpack", (r) => r.fulfill({
  contentType: "application/octet-stream",
  body: readFileSync(new URL("../donnees/kodokan.json", import.meta.url)),
}));
await page.locator(".action-douce", { hasText: "Réessayer" }).click();
await page.waitForSelector(".pack-officiel");
assert.ok((await page.locator(".pack-officiel").innerText()).includes("Judo"), "le catalogue liste le pack publié (B2)");
// D-333 : l'avertissement d'entrée, dont le LIEU de pratique demandé par le porteur.
{
  const avert = await page.locator(".pack-avert").innerText();
  assert.ok(/professeur qualifié/.test(avert), "l'écran dit que ces packs ne remplacent pas un professeur");
  assert.ok(/lieu adapté/.test(avert), "l'écran dit de pratiquer dans un lieu adapté (D-333)");
  assert.ok(/blessures/.test(avert), "le risque est nommé, pas sous-entendu");
}
// La maturité du pack, publiée depuis toujours et montrée depuis D-333.
assert.equal(await page.locator(".pack-badge", { hasText: "Bêta" }).count(), 1, "le badge de maturité est affiché (D-333)");
assert.ok((await page.locator(".pack-officiel-version").innerText()).includes("14 août 2026"), "la date de mise à jour est dite");
// L'illustration vient du SITE, par le canal déjà ouvert (fetch → blob:) : on
// vérifie qu'elle est RÉELLEMENT décodée, pas seulement présente dans le DOM.
await finit(async () => assert.equal(
  await page.evaluate(() => { const i = document.querySelector(".pack-rond img"); return !!i && i.complete && i.naturalWidth > 0 && i.src.startsWith("blob:"); }),
  true, "l'illustration du pack est chargée depuis le site en blob: (D-333)"), 4000);
// Les disciplines sans pack : une invitation, et « Judo » n'y figure pas
// puisqu'il est au catalogue (la divergence est impossible, pas surveillée).
assert.ok(await page.locator(".pack-venir-c").count() >= 10, "les disciplines sans pack sont proposées (D-333)");
assert.equal(await page.locator(".pack-venir-c", { hasText: /^Judo/ }).count(), 0, "une discipline PUBLIÉE ne peut pas être « à venir » (D-333)");
await page.locator(".pack-officiel-installer").first().click();
// le téléchargement remet au circuit d'import : la PROPOSITION s'ouvre — rien
// ne s'écrit sans accord ; on annule (le réimport idempotent est déjà prouvé D-114).
await page.waitForSelector('.feuille[aria-label="Proposition d\'import"]');
await page.locator(".voile").last().click();
await finit(async () => assert.equal(await page.locator('.feuille[aria-label="Proposition d\'import"]').count(), 0, "annuler la proposition referme sans rien écrire"));
await page.unroute("**/packs/index.json");
await page.unroute("**/packs/img/*.webp");
await page.unroute("**/packs/judo.movpack");

/* ===== S2.4 (D-168) — le voile d'opération longue OFFRE l'annulation quand
   l'opération le permet, et elle répond. (Le circuit réel — annulerExport /
   estAnnule de lireMovpackFlux — est prouvé en unit : abandon propre.) ===== */
{
  await page.evaluate(() => {
    const app = document.querySelector("movenso-app");
    app.occupe = "Épreuve en cours…";
    app.annulationOccupe = { libelle: "Annuler l'épreuve", executer: () => { app.occupe = null; app.annulationOccupe = null; app.requestUpdate(); } };
    app.requestUpdate();
  });
  await page.waitForSelector(".voile-occupe");
  await page.locator(".voile-occupe button", { hasText: "Annuler l'épreuve" }).click();
  await finit(async () => assert.equal(await page.locator(".voile-occupe").count(), 0, "l'annulation du voile répond et retire l'occupation"));
}

/* ===== S2.1 (D-169, option V) — un seul écrivain, garde de doublon par
   chemin : l'explorateur confirme un doublon EXACT (refusé = rien ; accepté
   = identité distincte) ; la capture, elle, ne pose jamais la question. ===== */
{
  // contexte : l'ÉCRAN discipline Judo (kodokan installé) — le champ de
  // création rapide y vit ; « De-ashi-harai » existe déjà
  await page.evaluate(() => {
    const app = document.querySelector("movenso-app");
    const d = app.bibliotheque.disciplines.find((x) => x.nom === "Judo");
    app.ecran = { type: "discipline", disciplineId: d.id };
    app.requestUpdate();
  });
  await page.waitForSelector('input[aria-label="Nom de la nouvelle technique"]');
  const nbAvantGarde = await page.evaluate(() => document.querySelector("movenso-app").bibliotheque.techniques.length);
  // refus : la feuille de garde (C2) se referme par le voile → aucune création
  await page.fill('input[aria-label="Nom de la nouvelle technique"]', "De-ashi-harai");
  await page.press('input[aria-label="Nom de la nouvelle technique"]', "Enter");
  await page.waitForSelector(".feuille-confirmation");
  assert.ok((await page.locator(".feuille-confirmation h2").innerText()).includes("existe déjà"), "la garde nomme le doublon");
  await page.locator(".voile").last().click();
  await finit(async () => assert.equal(await page.evaluate(() => document.querySelector("movenso-app").bibliotheque.techniques.length), nbAvantGarde, "refuser la confirmation ne crée RIEN"));
  // accepté : création d'une identité DISTINCTE (comme la feuille Ajouter)
  await page.fill('input[aria-label="Nom de la nouvelle technique"]', "De-ashi-harai");
  await page.press('input[aria-label="Nom de la nouvelle technique"]', "Enter");
  await page.waitForSelector(".feuille-confirmation");
  await page.locator(".feuille-confirmation .bouton.danger", { hasText: "Créer quand même" }).click();
  await finit(async () => assert.equal(await page.evaluate(() => document.querySelector("movenso-app").bibliotheque.techniques.length), nbAvantGarde + 1, "accepter crée une identité distincte"));
  // nettoyage : retirer la doublonne créée (corbeille puis état stable)
  await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const doublons = app.bibliotheque.techniques.filter((t) => t.nom === "De-ashi-harai");
    const cree = doublons[doublons.length - 1];
    app.bibliotheque.techniques = app.bibliotheque.techniques.filter((t) => t.id !== cree.id);
    await app.stockage.sauvegarder(app.bibliotheque);
  });
  // la CAPTURE ne pose jamais la question (moment chaud) : nouvelle technique
  // au nom déjà existant → créée sans confirm (un dialog ferait échouer ici)
  const dialogInattendu = (d) => { throw new Error("la capture ne doit JAMAIS demander : " + d.message()); };
  page.on("dialog", dialogInattendu);
  const bilanCapture = await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const avant = app.bibliotheque.techniques.length;
    const dId = app.bibliotheque.disciplines.find((d) => d.nom === "Judo").id;
    app.capture = { note: "capture au nom existant", provenance: "personnel" };
    await app.terminerCapture(undefined, "De-ashi-harai", { disciplineId: dId });
    return { crees: app.bibliotheque.techniques.length - avant };
  });
  page.off("dialog", dialogInattendu);
  assert.equal(bilanCapture.crees, 1, "la capture crée sans jamais interrompre (moment chaud, D-169)");
}

/* ===== S2.4 boucle 2 (D-168) — annulation de l'INGESTION VIDÉO : l'abandon
   est vérifié entre les blocs (analyse puis écriture), le brouillon de
   staging est jeté, la bibliothèque est inchangée, jamais un échec. ===== */
{
  const bilanIngestion = await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const t = app.bibliotheque.techniques[0];
    const contributionsAvant = app.bibliotheque.contributions.length;
    app.toast = "";
    // 24 Mo : l'analyse (empreinte par blocs) laisse le temps au drapeau —
    // qu'on lève AVANT l'appel : le premier contrôle inter-blocs le voit.
    const gros = new File([new Uint8Array(24_000_000)], "grosse.webm", { type: "video/webm" });
    const promesse = app.ajouterMediaFiche(t.id, { fichier: gros });
    app.annulerIngestionVideo();
    await promesse;
    let stagingRestant = 0;
    try {
      const d = await (await navigator.storage.getDirectory()).getDirectoryHandle("staging");
      // seuls les BROUILLONS VIDÉO comptent : « import » (zone d'import) et
      // « export-*.movpack » (temporaire d'export, balayé au prochain export)
      // sont d'autres circuits, hors sujet ici.
      for await (const nom of d.keys()) if (nom !== "import" && !nom.startsWith("export-")) stagingRestant++;
    } catch { /* dossier absent */ }
    return {
      toast: app.toast,
      contributionsInchangees: app.bibliotheque.contributions.length === contributionsAvant,
      stagingRestant,
      feuilleFermee: app.enregistrementMedia === null,
    };
  });
  assert.match(bilanIngestion.toast, /Ajout annulé/, "l'abandon est dit, jamais un échec : " + bilanIngestion.toast);
  assert.ok(bilanIngestion.contributionsInchangees, "la bibliothèque est inchangée après l'annulation");
  assert.equal(bilanIngestion.stagingRestant, 0, "aucun brouillon vidéo ne traîne en staging");
  assert.ok(bilanIngestion.feuilleFermee, "la feuille de progression est refermée");
}

await chapitreCertificationSauvegarde();
await chapitreImportTransactionnel();
await chapitreEnvironnementNonSupporte();
await chapitreBibliothequeVide();
await chapitreZoom200();


assert.deepEqual(erreurs, [], "erreurs JS : " + erreurs.join(" | "));
console.log("parcours incrément 1 : OK, zéro erreur JS");
await navigateur.close();
serveur.close();
