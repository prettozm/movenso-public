# Movenso V3 — Instructions permanentes

## Au début de chaque session

1. Vérifier la branche, le commit et l’état Git.
2. Lire `docs/execution/MASTER.md`.
3. Lire `docs/execution/STATE.md` — **tableau de bord, pas récit** : il ne
   contient que le présent, et ses faits chiffrés sont générés.
4. **Ne PAS lire `docs/execution/DECISIONS.md` en entier** (D-276). C'est un
   **journal d'audit** : 275 entrées append-only, qui expliquent *comment on
   en est arrivé là* — pas *ce qui est vrai aujourd'hui*. Une décision
   ancienne peut avoir été annulée par une plus récente, et rien ne le dit à
   l'endroit où on la lit : un raisonnement périmé y ressemble trait pour
   trait à un raisonnement en vigueur. N'y lire que :
   - les décisions **désignées** par `STATE.md` et par le lot courant ;
   - la **queue** (les ~20 dernières) si le contexte récent manque.
5. Lire uniquement le lot courant indiqué dans `STATE.md`.
6. Lire les sections concernées de `docs/execution/QUALITY.md`.
7. Exécuter la vérification rapide disponible.

La mémoire opérationnelle est dans le dépôt. Ne pas se fier à une mémoire
conversationnelle qui contredit ces fichiers.

**Où vit la vérité courante** : `docs/systeme.md` (architecture),
`docs/workflows.md` (parcours), `docs/execution/STATE.md` (présent). Ces trois
fichiers font autorité. `DECISIONS.md` explique le **pourquoi**, il ne dit pas
le **quoi** — s'il semble contredire les trois, ce sont les trois qui priment,
et l'écart est un défaut à corriger, pas un arbitrage à trancher.

## Mode de travail

Travailler en autonomie par boucles verticales courtes. Une boucle traite un seul comportement utilisateur, le vérifie, le documente, puis se termine par un commit vert et une mise à jour de `STATE.md`.

Enchaîner les boucles et les lots tant qu’aucune condition d’arrêt de `MASTER.md` n’est rencontrée.

## Deux dépôts, deux régimes (D-267)

`movenso` est un lieu de **travail** : l'historique, les lots et les décisions y
ont une valeur. `movenso-public` est une **destination** : on n'y développe pas,
on y dépose un build déjà vérifié. Appliquer la même règle aux deux revient soit
à interdire de publier, soit à laisser passer du travail sans revue.

**`movenso`** — toujours une branche, **jamais `main`**, **jamais de fusion**.

**`movenso-public`** — publication **directe sur `main`** autorisée, à quatre
conditions cumulatives :

1. le commit correspondant de `movenso` est **poussé** ;
2. `npm run verifier` est **vert** sur ce commit ;
3. `node verifier-catalogues.mjs` est vert **après** dépôt ;
4. application, packs et source partent **dans le même commit** — jamais un
   sous-ensemble (la garde le refuse désormais, via `app/build.json`).

**Exception — reste en branche + PR** : tout ce qui est **rédigé et engageant**
(mentions, confidentialité, sécurité, licences) et tout ce qui touche la
**posture de sécurité** (CSP, workflows, gardes). La ligne de partage : *ce qui
est produit et gardé va direct ; ce qui est écrit et engageant passe par le
porteur.* Un build se vérifie par des gardes ; une phrase juridique, non.

**APK et releases** suivent la même règle, et ne se génèrent que sur **demande
explicite**.

Si une consigne de démarrage de session contredit cette règle — par exemple en
nommant la même branche pour les deux dépôts — le **signaler** au lieu d'en
appliquer la lettre en silence.

## Consignes LOCALES (D-277)

Quatre fichiers `CLAUDE.md` vivent dans les zones où une erreur coûte cher.
Ils ne se lisent pas au démarrage : ils arrivent **au moment où l'on touche la
zone**, ce qui vaut mieux que de tenir cinquante contraintes en mémoire depuis
le début d'une session.

| zone | ce qu'elle garde |
|---|---|
| `src/echange/` | frontière hostile : rien de ce qui entre n'est cru sur parole |
| `src/stockage/` | un seul écrivain, jamais d'état à moitié écrit |
| `src/app/` | façade et interface — surtout pas de logique métier |
| `tools/` | ce qui est publié doit être reproductible |

Chaque règle y nomme **l'incident qui l'a produite** : une consigne sans son
accident ne tient pas. Ce fichier-ci garde les règles transverses ; ne pas y
recopier une consigne locale.

## Permissions et dépendances (D-282)

`.claude/settings.json` est **versionné** : les droits ne dépendent pas de la
machine ni de l'humeur d'une session. Trois niveaux :

- **libre** — lire, chercher, `git status/diff/log`, `typecheck`, `test`,
  `verifier*`, `etat`, `cliquet`, `checker`, inspecter un `.movpack` ;
- **confirmation** — `npm install`, toucher `package.json` ou un workflow,
  `git commit`/`push`, `publier`, `deposer`, `source`, `gh release` ;
- **refusé** — force-push, `rebase`, `commit --amend`, suppression de branche,
  `--dangerously-skip-permissions`, et la **lecture de tout secret** (keystore,
  `.env`, `~/.ssh`, `~/.android`).

**Une dépendance est une DÉCISION, pas une commodité.** Chaque paquet est
déclaré dans `outils/dependances.json` **avec sa raison** ; la garde refuse un
paquet non déclaré, une entrée devenue inutile, et une justification trop
courte pour en être une. Elle n'interdit rien : elle rend le choix visible
dans le diff. Un agent résout volontiers un problème par un paquet — ici, la
réponse est souvent **« non, vingt-cinq lignes suffisent »**.

## Git : la frontière humaine (D-283)

`main` de `movenso` doit être **protégée côté GitHub** : PR obligatoire,
contrôle `verifier` obligatoire, aucun force-push. La règle cesse alors d'être
une consigne qu'on peut enfreindre par distraction — le serveur refuse.

*(Application par le porteur : elle demande des droits d'administration du
dépôt. Tant qu'elle n'est pas posée, la règle tient par discipline seule.)*

Ce que je peux faire : brancher, coder, tester, committer, pousser **une
branche**, ouvrir une PR. Ce que je ne peux pas : **faire entrer du code dans
`main` tout seul.** Le porteur reste le seul approbateur produit.

Corollaire à ne pas contourner : si une PR est bloquée, la réponse n'est
jamais de pousser ailleurs ni d'assouplir la protection — c'est de corriger ce
que le contrôle refuse, ou de demander.

## Interdictions

- Ne jamais travailler sur `main` **dans `movenso`** (voir « Deux dépôts, deux régimes »).
- Ne jamais fusionner, force-push ou réécrire l’historique.
- Ne jamais modifier Movenso V2.
- Ne jamais commencer deux lots en parallèle.
- Ne jamais ajouter une fonction hors du lot courant.
- Ne jamais supprimer une capacité sans décision explicite.
- Ne jamais committer un secret, un PIN ou un keystore.
- Ne jamais déclarer démontré ce qui ne l’est que partiellement.

## Avant d’écrire un écran : l’INTENTION UTILISATEUR (D-279)

Obligatoire dès qu’une boucle change **ce que l’utilisateur voit ou fait**.
Inutile pour une modification purement technique.

Huit lignes, pas un cahier des charges — écrites **avant** le plan :

```
Utilisateur :
Situation :
Ce qu’il essaie de faire :
Pourquoi :
Geste d’entrée :
Résultat attendu :
Ce qu’il ne doit PAS avoir à comprendre :
Hors périmètre :
```

L’avant-dernière ligne est celle qui travaille. Exemple, sur l’écran Médias :

```
Utilisateur : pratiquant
Situation : sur une fiche technique
Ce qu’il essaie de faire : changer ce qui représente sa technique
Pourquoi : la vignette actuelle ne dit rien de ce qu’il pratique
Geste d’entrée : toucher la vignette
Résultat attendu : choisir une image, une vidéo, ou retirer
Ne doit PAS comprendre : mediaId, fichier orphelin, couverture vs média principal
Hors périmètre : le parc de fichiers, l’intégrité, la maintenance
```

**L’accident qui a produit cette règle.** L’écran Médias a été conçu depuis le
MODÈLE vers l’écran, et il a fallu **cinq passes** pour le rendre utilisable —
chacune déclenchée par un humain qui le regardait : médiathèque tronquée
(D-079), affichée en double et illisible (D-082), vignette ajoutée à côté
(D-083), écran coupé en deux surfaces (D-084), puis « trois contrôles pour
deux idées » en édition (D-091). Aucune de ces passes n’aurait été nécessaire
si on avait d’abord écrit ce que le pratiquant essaie de faire.

**Verrou humain.** Pour une **interaction nouvelle et importante** : pas de
code avant validation du parcours ou d’une maquette légère. Le dépôt en garde
la preuve que ça marche — « validé sur maquette SVG avant implémentation »
(D-091) est la seule de ces cinq passes qui n’a pas eu à être refaite.

**Aucune garde ne tient cette règle**, et je le dis plutôt que de faire
semblant : on ne vérifie pas mécaniquement qu’une intention a été écrite avant
le code. Elle repose sur la discipline, et sur le porteur qui la réclame.

## Avant de corriger : qualifier l’objet (D-251)

Ne jamais corriger un champ, un écran ou un comportement sans avoir écrit son
**cycle** — sinon on corrige le mauvais objet, et le correctif est plus
dangereux que le défaut.

Quatre questions, dont la réponse se **vérifie dans le code**, jamais de
mémoire :

1. **Qui l’écrit, et quand ?** (une saisie validée ? un auto-enregistrement à
   la perte de focus ? un import ?)
2. **À qui appartient la donnée ?** (contenu d’un pack, ou contenu personnel ?)
3. **Où vit-elle, et jusqu’où voyage-t-elle ?** (mémoire, disque, export,
   sauvegarde — un contenu personnel ne s’exporte pas)
4. **Qu’est-ce qui a le droit de l’écraser, et à quel geste précis ?**

Deux champs qui se ressemblent à l’écran peuvent n’avoir aucun rapport : le
titre d’une fiche est une donnée validée en édition, le commentaire est une
note **personnelle auto-enregistrée hors édition**. Les traiter pareil a
produit une perte de saisie silencieuse (D-251).

## Un correctif n’est vert que démontré dans les DEUX sens

- Un test doit **rougir sans le correctif** et **passer avec** — les deux
  mesurés, pas supposés. Un test qui n’a jamais échoué ne prouve rien.
- Le **comportement voisin du même objet** doit être testé dans le même
  chapitre : ici, l’annulation ET la frappe en cours. Corriger l’un en cassant
  l’autre est le mode d’échec normal, pas un accident rare.
- Un test ne doit **jamais fabriquer un événement que le produit n’émet pas**
  (leçon D-231/D-251) : une preuve obtenue sur un chemin inventé ne prouve
  rien du chemin de l’utilisateur.
- Un test **instable n’est pas à stabiliser mais à instruire** : sur machine
  lente, c’est souvent une course réelle qu’on n’a pas encore lue (D-249).

## Une information, un lieu (D-253)

Le piège répété de ce projet n’est pas d’écrire une mauvaise valeur, c’est
d’en écrire une **bonne à un second endroit** : la copie survit à l’original
et rien ne le signale (D-250 — trois états contradictoires du même numéro).

- Une valeur a **un seul lieu d’écriture**. Toute autre mention la **dérive**
  ou n’existe pas.
- Ne jamais créer une seconde liste « pour l’affichage » : deux listes de la
  même chose finissent toujours par diverger (D-252).
- Une duplication qu’on ne peut pas supprimer se **rattache par une garde
  exécutable**, jamais par une consigne — une garde que rien n’exécute est une
  consigne de plus.
- `npm run verifier:references` tient cette règle pour les versions ; y
  **ajouter un cas** dès qu’une information se met à vivre à deux endroits.

## Pas de complications d'horloger (D-324)

Règle du porteur, posée le 2026-08-13 : **une complication ne se construit que
quand une équipe est là pour la tenir, et uniquement si un besoin terrain la
réclame.** Historique de lecture, récurrences, moteurs de suggestion,
généralisations « pendant qu'on y est » : la version la plus simple qui répond
au besoin constaté est la bonne, et le reste attend une demande réelle.

Ce n'est pas de la frilosité, c'est du coût de possession : chaque mécanisme
ajouté doit être compris, testé, migré et corrigé par quelqu'un, à chaque
boucle, pour toujours. La question à se poser n'est pas « est-ce que je sais le
faire ? » mais « qui le maintiendra, et quel usage l'a demandé ? ».

**Corollaire pour un agent** : proposer la version simple ET nommer la
complication écartée, plutôt que de livrer la version riche en espérant qu'elle
plaise. Une capacité qu'on n'a pas construite se rajoute ; une capacité livrée
sans besoin ne se retire plus.

## En cas de doute, demander

Demander **avant d’écrire**, et non après avoir livré, quand : la nature ou le
cycle d’un objet n’est pas certain ; un correctif dépasse le défaut constaté ;
un choix engage le contenu, le format public ou ce que l’utilisateur voit ;
ou quand un rollback est une option défendable. Livrer sous hypothèse tacite
est ce qui coûte le plus cher ici.

## Maker / checker : faire relire par une session NEUVE (D-280)

Celui qui vient d’écrire le code a aussi pris **toutes les décisions qui y ont
mené**. Il relit donc avec les mêmes angles morts, et il relit son **intention**
plutôt que son résultat. Une auto-relecture attrape des étourderies, pas des
erreurs de jugement.

**Quand c’est requis** — `npm run checker` le calcule depuis le diff et le
dit : `src/stockage/`, `src/echange/`, `src/domaine/migrations.ts`,
`src/domaine/validation.ts`, `src/securite/`, `tools/`, `outils/`,
`.github/workflows/`. Et **toujours en fin de lot**. Pas pour un bouton.

**Comment.** `npm run checker` sort les deux commits et imprime la consigne
prête à coller. Elle part dans une **session neuve — surtout pas une reprise** :
c’est l’absence de contexte partagé qui fait toute la valeur du procédé.

**Le checker ne modifie rien** — ni fichier, ni commit, ni branche — et **ne
propose pas de réécriture** : il challenge, il ne conçoit pas. Il rend ce qu’il
a vérifié, ce qu’il n’a **pas** pu vérifier, et ses constats situés (fichier +
ligne). « Ça me semble bon » n’est pas un verdict ; « rien à signaler, voici ce
que j’ai ouvert » en est un.

**Le maker corrige, ou explique pourquoi il ne corrige pas** — puis inscrit le
verdict dans l’entrée de journal de la boucle. Sans trace, la relecture n’a pas
eu lieu.

**Aucune garde ne tient cette règle** : rien ne prouve mécaniquement qu’une
session neuve a relu. Le déclencheur, lui, est calculé — le reste est de la
discipline.

## Fin d’une boucle

Une boucle est terminée seulement si :

- l’INTENTION UTILISATEUR a été écrite AVANT le code, si la boucle change ce
  que l’utilisateur voit ou fait (D-279) ;
- le comportement fonctionne de bout en bout ;
- le test ciblé est vert ;
- les non-régressions voisines sont vérifiées ;
- la **doc est amendée au fil de l’eau, dans le même commit** (règle
  `docs/conventions.md` §12) : `docs/systeme.md` si l’architecture ou un
  comportement change, `docs/workflows.md` si un parcours change,
  `docs/execution/QUALITY.md` pour la recette et les capacités ;
- `docs/execution/STATE.md` est à jour (le **présent** ne vit que là), et
  `npm run etat` a été rejoué si un fait a bougé ;
- si la boucle **clôt ou fait naître un chantier** listé dans
  `docs/execution/RESTE.md` : la ligne en sort ou y entre **dans le même
  commit** (D-288). Il n'y a pas de liste du terminé — le journal l'est.
  Chaque ligne du chemin critique porte qui la tient — `(porteur)`,
  `(agent)`, `(bloqué : <quoi>)` — et un sujet qui dépasse une ligne gagne
  une **fiche** dans `lots/`, pointée depuis sa ligne, qui ne déménage
  jamais : l'état vit sur la ligne, pas dans un emplacement (D-289) ;
- la décision éventuelle est inscrite au journal (`docs/execution/DECISIONS.md`) ;
- un commit local vert existe ;
- si `npm run checker` dit la relecture REQUISE : elle a eu lieu **en session
  neuve**, et son verdict est inscrit au journal (D-280).

Ne jamais laisser la doc « propre » (architecture, parcours) prendre du retard
sur le code : une boucle qui change le produit sans mettre à jour la doc qui
fait autorité sur ce sujet n’est pas verte.

## Fin d’un lot

Un lot est terminé seulement si ses critères obligatoires sont couverts, `npm run verifier` est vert, **les documents décrivent le réel** (aucun écart connu entre `docs/systeme.md`/`docs/workflows.md` et le code) et un checkpoint de lot est inscrit dans `STATE.md`.
