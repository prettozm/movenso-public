# DOSSIER — Compositions / séances (session dédiée réservée)

> **Type : vivant** · Dossier d'INSTRUCTION (patron S1-10) : rien ne se code
> tant que la session dédiée n'est pas ouverte par le porteur, et le gel
> D-240 est LEVÉ (D-307). Ce dossier consolide : les maquettes fournies le
> 2026-08-11 **et les neuf planches du 2026-08-13 (§ SPÉCIFICATION UI)**,
> les arbitrages du porteur (D-290), la proposition d'évolution qui les
> accompagne, et la **confrontation au modèle réel** (vérifiée dans le code,
> D-251 — jamais de mémoire).

## Le problème, tel que le porteur le formule

Le moteur Composition couvre déjà quasiment tous les usages (enchaînement,
Tori/Uke, kata, séance minutée, circuit, multi-rôles, simultanéité, lecture
guidée, voix/bips). Le défaut n'est pas la puissance, c'est son
**accessibilité** pour un non-initié. Principe directeur retenu :

> *ne pas ajouter de concepts métier là où les capacités existent déjà ;
> ajouter des niveaux d'UX qui rendent ces capacités évidentes.*

## Arbitrages posés (D-290)

1. **« Partager » = export/import `.movpack`** — le mot « inviter » est
   banni (pas de compte, pas de collaboration temps réel). Dire « pratiquer
   à plusieurs » ou « partager la composition ».
2. **Assistant de création 100 % local et déterministe** : des choix fermés
   qui préconfigurent le moteur existant. Jamais un second moteur, jamais
   d'IA.
3. **Navigation hors périmètre** : Favoris/Relations restent où ils sont.
   Les maquettes qui montrent une barre refondue ne font pas foi sur ce
   point.
4. **Un seul système de rôles** : Tori/Uke sont des **noms proposés par
   défaut** selon le contexte, strictement le même mécanisme que Toto/Tata.
5. **Simultanéité conservée** (`lien` = rejoint le temps précédent, D-235) ;
   le vocabulaire UX devient « En même temps que l'étape précédente ».
6. **Planification dans la cible ; notifications = chantier plateforme
   séparé** (Android, permissions, arrière-plan, PWA — rien de tout ça ici).

## Confrontation au modèle réel (vérifiée dans le code)

### Existe déjà, tel quel — l'écart est purement d'exposition

- **Blocs** : 9 types (`technique`, `etape` libre, `transition`, `consigne`,
  `objectif`, `duree`, `media`, `repere`, `pause`) — les trois des maquettes
  y sont, plus six (`modele.ts`, TYPES_BLOC).
- **Rôles** : `Acteur[]` nommés librement sur la composition (D-227),
  `acteurId` par bloc, absent = neutre/« les deux ». Exactement le modèle
  que l'arbitrage n° 4 demande.
- **Simultanéité** : `Bloc.lien` — « rejoint le temps du pas précédent »
  (D-235), avec lecture des valeurs héritées D-229. La bascule des maquettes
  existe ; seul le libellé change.
- **Durée facultative** : `dureeSec?` par bloc ; total de séance dérivé
  (somme des durées présentes, D-124).
- **Entonnoir de création** : `type` enchaînement / séance / kata choisi à
  la création (D-126), funnel existant (`ouvrirCreationCompo`,
  `creerCompositionFunnel`, `poserRolesFunnel`). L'« assistant » des
  maquettes est une extension de CET entonnoir, pas un objet neuf.
- **Lecteur** : chrono par pas, phase **préparation** (« Préparez-vous »,
  durée réglable, défaut 3 s — `preferences.transitionSec`), **quatre modes
  sonores** (voix + bips / voix / bips / muet), précédent/suivant/quitter,
  résumé de fin, suspension quand l'écran se cache. Le « Prépa 3 s » et le
  « Voix + bips » des maquettes existent déjà, au réglage près.
- **Recherche** : « une composition ou une technique qu'elle contient » +
  chips de discipline déduites du contenu (+ filtre mixte) — mot pour mot
  ce que la maquette dessine.
- **Duplication / partage** : `dupliquerComposition`,
  `exporterComposition`/`partagerComposition` en **pack jouable** — le
  « Partager » de l'arbitrage n° 1 existe.
- **Provenance** : `Composition.origine` (vient d'un pack) → la séparation
  « Mes compositions / Packs » est un **filtre UX** sur une donnée en place.

### N'existe pas — purement UX, aucune donnée nouvelle

- Onglets **Mes compositions / Packs** (filtre sur `origine`).
- **Fiche de consultation** d'une composition de pack (lecture avant
  édition : Démarrer / Dupliquer / Planifier) — aujourd'hui on tombe dans
  l'édition.
- **Timeline au centre de l'éditeur**, ajout d'étape progressif en
  bottom-sheet (type → puis seulement qui agit / durée / en même temps),
  réorganisation par glisser (primitive `glisser.ts` à évaluer).
- **Tri** (Récent) et hiérarchie de liste.
- Lecteur : **aperçu de l'étape suivante avec son rôle** (les données sont
  déjà dans les blocs).

### Données réellement nouvelles (le SEUL ajout métier : la planification)

- **Planification** : `{ compositionId, date, heure?, (rappel plus tard) }`
  — pas d'objet « Séance » (redondant, tranché par la proposition §9). Une
  composition planifiable N fois sans duplication. Impact : nouvelle
  collection persistée → **bump de schéma + migration additive** (triviale,
  mais c'est une migration — critère D-251 : qui l'écrit, où elle voyage).
- **Curseur de reprise** (« Continuer — dernière lecture il y a 2 j »,
  position 2/6) : l'état de séance actuel est en mémoire, non persisté. À
  qualifier : métadonnée **locale**, auto-écrite, ne s'exporte jamais dans
  un pack.
- **Suggestions de techniques** à l'ajout d'étape : dérivables localement
  (relations, famille, discipline) — un petit moteur, pas de donnée neuve.

### Suggéré par les maquettes et ÉCARTÉ (arbitrages + hors périmètre)

- « Inviter d'autres personnes », comptes, temps réel (n° 1).
- Assistant « générateur » IA ou distant (n° 2).
- Barre de navigation refondue — Favoris/Relations en onglets (n° 3).
- Système Tori/Uke parallèle (n° 4).
- Notifications/rappels système dans CE chantier (n° 6).
- Tags par étape et badge « niveau » : ne pas créer de champs — `consigne`
  et `description` existants les portent si le contenu en a besoin.
- **Undo d'éditeur** (icône des maquettes) : ne pas le promettre — à
  instruire séparément s'il devient nécessaire.

## Ordre d'évolution proposé (proposition §15, confirmé par la confrontation)

- **A — rendre Composition compréhensible** : split Mes/Packs, hiérarchie de
  liste, fiche de consultation pack, duplication (100 % UX).
- **B — simplifier la création** : entrée guidée sur l'entonnoir existant,
  préconfiguration solo/plusieurs (rôles proposés par contexte),
  timeline-centre, ajout d'étape progressif, vocabulaire utilisateur.
- **C — consolider le lecteur** : lisibilité et hiérarchie seulement
  (aperçu du suivant, rôle actif plus net) — le moteur ne bouge pas.
- **D — planification** : modèle minimal, planifier depuis une composition,
  **Liste d'abord**, Calendrier ensuite (même donnée, autre rendu — jamais
  un second stockage).
- **E — rappels** : chantier plateforme indépendant, après que D a servi.

## Questions encore ouvertes (à trancher avant ou pendant la session)

1. La **planification** part-elle dans la **sauvegarde complète** ?
   (probablement oui ; dans un pack : sûrement non). Cycle D-251 à écrire.
2. **Récurrence** (« tous les mardis ») : hors v1 ? La proposition planifie
   N fois à la main — c'est le plus simple, à confirmer.
3. **« Continuer »** : une seule entrée (dernière séance) ou un historique ?
   La v1 la plus simple : une entrée.
4. **Où vit l'Agenda** dans la navigation actuelle (Pratique ? Plus ? une
   vue de l'onglet existant ?) — explicitement laissé à challenger.
5. Les maquettes montrent des **photos par étape** dans les packs : le bloc
   `media` existant couvre-t-il le besoin de contenu, ou est-ce du travail
   éditorial de packs (hors moteur) ?

## Intention utilisateur (D-279) — à écrire par écran, AVANT le code

Chaque boucle d'écran de la session dédiée commencera par ses huit lignes ;
ce dossier n'en dispense aucune. Le verrou humain s'applique : parcours ou
maquette validés avant implémentation pour toute interaction nouvelle
importante (la matière maquette existe déjà — c'est sa force).

**UI-2 — fiche de consultation** *(écrite avant le code, boucle D-319)*

```
Utilisateur : pratiquant
Situation : sur la liste des compositions
Ce qu'il essaie de faire : savoir ce qu'est une composition avant de s'engager
Pourquoi : une séance de 30 min et un kata de 8 pas ne se décident pas pareil
Geste d'entrée : toucher la carte
Résultat attendu : il voit ce que ça dure, qui agit, à quoi ça ressemble, et il démarre
Ne doit PAS comprendre : bloc, acteur, provenance vs attribution, qu'il édite du contenu de pack
Hors périmètre : la planification (AG-1), la reprise de lecture (UI-6)
```

**UI-6 — « Continuer »** *(écrite avant le code, boucle D-324)*

```
Utilisateur : pratiquant qui a interrompu une séance
Situation : il ouvre l'onglet Compositions le lendemain
Ce qu'il essaie de faire : reprendre là où il s'est arrêté
Pourquoi : une séance de trente minutes se fait rarement d'un bloc — et
  retrouver « la sixième étape sur treize » à la main coûte plus que la reprise
Geste d'entrée : ouvrir l'onglet Compositions
Résultat attendu : une carte en tête, nommant la composition et l'étape, qui
  relance le lecteur AU BON PAS
Ne doit PAS comprendre : index, préférence d'appareil, ce qu'est une position
Hors périmètre : un historique (arbitrage porteur : UNE entrée), la
  planification (AG-1)
```

**Le CYCLE de la donnée (D-251), vérifié dans le code avant d'écrire :**

| question | réponse |
|---|---|
| Qui l'écrit, et quand ? | le **lecteur**, tout seul, quand un pas s'affiche — jamais une saisie, jamais une validation |
| À qui appartient-elle ? | à l'**appareil**, pas au savoir : c'est « où j'en étais », pas un contenu |
| Où vit-elle, jusqu'où voyage-t-elle ? | `Preferences` (OPFS, `src/stockage/opfs.ts`) — donc **jamais** dans un pack **ni dans une sauvegarde** : les préférences ne voyagent nulle part (D-020.4). Conséquence assumée : changer de téléphone ne rapporte pas la reprise, et c'est cohérent — on ne restaure pas une position de lecture, on reprend la séance |
| Qu'a le droit de l'écraser, à quel geste ? | **lire une autre composition** (une seule entrée, arbitrage porteur) ; **« Terminer »** l'effface (une séance finie n'a rien à continuer) ; **« Quitter »** la garde (c'est précisément le cas à reprendre) |

**Aucun bump de schéma, aucune migration** : le champ est optionnel dans les
préférences, pas dans la bibliothèque.

**UI-5 — le lecteur** *(écrite avant le code, boucle D-323)*

```
Utilisateur : pratiquant, au bord du tatami, séance lancée
Situation : un pas est en cours, il lui reste vingt secondes
Ce qu'il essaie de faire : savoir où il en est et ce qui vient
Pourquoi : il enchaîne sans reprendre le téléphone en main — et à deux,
  il doit savoir si c'est à lui de faire le pas suivant
Geste d'entrée : aucun (l'écran est déjà là, les mains sont prises)
Résultat attendu : d'un coup d'œil — la part de séance parcourue, le temps qui
  reste, et QUI fait le pas suivant
Ne doit PAS comprendre : bloc, `acteurId`, `lien`, index
Hors périmètre : le moteur (chrono, voix, préparation) qui ne bouge pas ;
  la reprise après sortie (UI-6)
```

**UI-4 — ajouter une étape, et partir d'une composition existante** *(écrite avant le code, boucle D-322)*

```
Utilisateur : pratiquant qui construit sa première séance
Situation : la feuille « ＋ Ajouter un élément » vient de s'ouvrir
Ce qu'il essaie de faire : poser le pas suivant
Pourquoi : il a une séquence en tête et veut la déposer sans réfléchir à l'outil
Geste d'entrée : ＋ Ajouter un élément (entonnoir ou éditeur)
Résultat attendu : on lui demande QUOI d'abord ; les réglages n'apparaissent
  qu'une fois le contenu choisi ; et la recherche lui propose déjà des
  techniques au lieu d'un champ vide
Ne doit PAS comprendre : `dureeSec`, `acteurId`, `lien`, les neuf types de bloc
Hors périmètre : les suggestions par relations/famille (moteur à part),
  la planification
```

**UI-3 — éditeur d'une composition** *(écrite avant le code, boucle D-321)*

```
Utilisateur : pratiquant qui a construit ou reçu une séance
Situation : dans l'éditeur d'une séance de treize pas
Ce qu'il essaie de faire : embrasser la séquence d'un regard, et corriger UN pas
Pourquoi : il ajuste une séance AVANT de la lancer, pas pendant
Geste d'entrée : le ✎ de la barre
Résultat attendu : il voit la suite des pas comme une suite, sait ce que la
  séance pèse, et chaque pas offre ses outils sans les répéter
Ne doit PAS comprendre : type de bloc, `lien`, `acteurId`, ce qu'est un « temps »
Hors périmètre : dupliquer un pas (fonction NOUVELLE, à arbitrer), la planification
```

**UI-1 — liste des compositions** *(écrite avant le code, boucle D-320)*

```
Utilisateur : pratiquant
Situation : il ouvre l'onglet Compositions, qui mélange ses séquences et celles de ses packs
Ce qu'il essaie de faire : retrouver la bonne et la lancer
Pourquoi : à l'entraînement il a trente secondes, pas trois minutes
Geste d'entrée : ouvrir l'onglet ; puis Mes compositions | Packs
Résultat attendu : ce qui est à lui d'un côté, ce que ses packs fournissent de
  l'autre, chaque carte disant sa discipline, son poids et son mode, et ▶ lance
Ne doit PAS comprendre : provenance, attribution, packId, ce qu'est un bloc
Hors périmètre : « Continuer » (UI-6 : la dernière position n'est pas persistée),
  l'agenda (AG-1)
```

---

# SPÉCIFICATION UI — maquettes du 2026-08-13 (9 planches)

> Ajoutée après un retour du porteur : le dossier listait les **écarts** sans
> porter la **spécification visuelle**. Les maquettes ne demandent presque
> aucune fonction nouvelle (l'Agenda excepté) — elles demandent une **UX/UI
> cohérente**. Cette section est la référence d'implémentation ; chaque élément
> dit d'où vient sa donnée, et ce qui manque est nommé.

## 0. Grammaire visuelle commune (à écrire UNE fois, réutilisée partout)

| élément | contenu | source de la donnée |
|---|---|---|
| **En-tête d'écran** | titre + une phrase d'intention, action ronde à droite | statique |
| **Bascule segmentée** | deux onglets exclusifs (Mes/Packs, Liste/Calendrier) | état de session |
| **Carte-liste** | liseré coloré à gauche · vignette · titre · ligne de méta à icônes · ▶ · ⋮ | voir ci-dessous |
| **Ligne de méta** | `☰ N étapes` · `⏱ N min` · `👤 Seul / À plusieurs` | `blocs.length`, somme `dureeSec`, `acteurs` |
| **Pastille de rôle** | nom de l'acteur, couleur par rôle (1ᵉʳ accent, 2ᵈ bleu…) | `Acteur.nom` via `bloc.acteurId` |
| **Pastille de discipline** | nom de la discipline, couleur | disciplines dérivées du contenu (`disciplinesDe`) |
| **Barre d'actions collante** | 2–3 actions en bas d'une fiche | — |
| **Bouton flottant ＋** | création | — |
| **Feuille basse à choix fermés** | segments, chips, bascule, CTA | — |

**Vignette** : la maquette montre un kanji en filigrane — c'est un
**bouche-trou de maquette**. Le réel : `vignetteTechnique` de la première
technique (les packs ont désormais leurs images, judo compris par carte de
famille) ; à défaut, l'initiale sur fond calme, comme partout ailleurs.

**Liseré coloré** : les maquettes l'utilisent sans règle déductible (deux
compositions « Seul » n'ont pas la même couleur). **À trancher** — proposition :
couleur de la **discipline dominante** de la composition, dérivée d'une palette
déterministe (une `Discipline` ne porte pas de couleur dans le modèle ; seuls
les niveaux en ont). Tant que ce n'est pas tranché : liseré accent pour « mes
compositions », neutre pour celles d'un pack.

## 1. Compositions › **Mes compositions** (planche 2)

- En-tête : « Compositions » · *Crée, retrouve et lance tes séquences.* · bouton rond de filtres.
- Bascule **Mes compositions | Packs** → filtre sur `origine` (absent = à moi). **UI seule, donnée en place.**
- Recherche « une composition ou une technique » : **existe déjà**, à reloger.
- Chips de discipline + bouton filtres : **existent déjà** (dérivées du contenu).
- Section **« Continuer » + Tout voir** : carte de la dernière lecture, pastille de rôle, « Dernière lecture il y a 2 j », méta, ▶.
  → **MANQUE la donnée** : la position de séance vit en mémoire. Nouveau champ **local** (`derniereLecture` : compositionId, index, date), auto-écrit, jamais publié dans un pack, cycle D-251 à écrire.
- Section **« Mes compositions »** + **Trier par : Récent ▾** → tri : récent (défaut, existe), nom, durée. **UI seule.**
- Cartes : ▶ (existe) + **⋮ par carte** (le menu existe, il vit ailleurs) — à ramener sur la carte.
- **＋ Créer** flottant (existe en bas d'écran).

## 2. Compositions › **Packs** (planche 3)

- Sous-titre propre : *Découvre les séquences fournies par tes packs.*
- Chips **Tous** + une par discipline.
- Bandeau de section : *Séquences de tes packs — prêtes à l'emploi, classées par discipline.*
- Cartes : **photo** (vignette réelle), **pastille de discipline colorée**, titre, méta, **chip de source** (« Pack Taïso ») → dérivée de `origine.pack` par `nomEditorialSource`, **jamais un libellé saisi** ; ▶, ⋮, **Dupliquer** (existe : `dupliquerComposition`).
- Pied de section explicatif : *Ces compositions viennent de tes packs. Duplique-les pour les personnaliser.* — dit pourquoi l'édition directe n'est pas le geste par défaut.

## 3. **Fiche de consultation** d'une composition (planche 5) — l'écran qui manque le plus

Aujourd'hui, ouvrir une composition de pack tombe **dans l'éditeur**. La fiche
intercale la lecture :

- En-tête : retour · **partager** (existe) · ⋮.
- Vignette + titre + **badge de source** (« Pack Judo »).
- **Description** (`Composition.description` — remplie depuis D-306).
- Méta : `6 étapes` · `30 min` · `À plusieurs` + chip de niveau.
  → **« Tous niveaux » n'existe pas** dans le modèle. Proposition : dériver des niveaux des techniques référencées si elles convergent, sinon **omettre** la chip (jamais inventer un champ).
- **Aperçu des étapes** : numéro, photo, pastille de rôle, titre, sous-ligne (`consigne`), durée à droite — puis **« Voir les N étapes › »**.
- Barre collante : **▶ Démarrer** · **Dupliquer** *(dans Mes compositions)* · **Planifier**.

## 4. **Éditeur** (planche 6)

- En-tête : retour · vignette · titre éditable (✎) · « À plusieurs » · **▶** · ⋮.
- **Bandeau de statistiques** : `6 étapes` · `32 min` *Durée totale* · `Toto, Tata` *Rôles impliqués* — tout dérivé, rien de saisi.
- **Timeline** : numéros reliés par un trait vertical ; chaque étape = pastille de rôle, titre, **type nommé avec son icône** (🥋 Technique · ⇄ Transition · 📝 Note…), durée, et actions en ligne **Déplacer · Dupliquer · Supprimer**.
- **＋ Ajouter une étape** en pointillé, en bas.
- ⚠️ **La maquette dit « Glissez les étapes pour réorganiser » — REFUSÉ** : le glisser-déposer a été retiré (D-233, WCAG 2.5.7). L'action **Déplacer** de la maquette est justement le chemin accessible : elle reste, complétée des ▲/▼ existants. La poignée décorative disparaît.

## 5. **Entonnoir de création** (planche 7 + workflow 2)

Quatre départs — l'entonnoir existe (D-126), il gagne la forme et un cas :

1. **Composition libre** — de zéro, à son rythme.
2. **Séance solo** — préconfigure `type: "seance"`, un seul exécutant.
3. **À plusieurs** — préconfigure les rôles (noms proposés selon le contexte).
   ⚠️ *« invite d'autres personnes »* de la maquette est **REFUSÉ** (arbitrage n° 1 : ni compte ni temps réel) → « prévois les rôles de chacun ; la composition se **partage** en fichier ».
4. **Depuis un pack** — part d'une composition de pack (= dupliquer).

Pied : *Aucun engagement, tout est modifiable.* Puis **Continuer**.
Workflow 2 : nommer → seul/à plusieurs (→ rôles) → étapes → timeline → ordre/rôles → sauvegarder → **Démarrer / Reprendre / Planifier**.

## 6. **Ajouter une étape** — feuille basse progressive (planche 8)

- Segments **Technique | Saisie libre | Transition** (les 9 types du modèle restent accessibles ; ces trois sont les portes rapides).
- Recherche de technique + **Suggestions** (dérivées localement : relations, famille, discipline de l'étape précédente — pas de donnée nouvelle).
- **Qui agit ?** chips : les acteurs de la composition + « Les deux » (= `acteurId` absent) + « Personnalisé ».
- **Durée** chips : 15 s · 30 s · 1 min · **Aucune** (`dureeSec` optionnel).
- Bascule **« En même temps que l'étape précédente »** → `Bloc.lien` (D-235), avec la phrase de la maquette : *cette étape démarrera en parallèle*.
- CTA **＋ Ajouter l'étape**, note : *tu pourras modifier les détails après.*

## 7. **Lecteur** (planche 4) — le moteur ne bouge pas, la hiérarchie change

- Haut : ⌄ replier · nom · `2 temps · Toto · Tata` · **`2 / 6 · 6 min`** · barre de progression.
- Centre : **pastille du rôle actif**, cadran circulaire, vignette en fond, **nom**, **seconde ligne = `nomTraditionnel`** (⚠️ c'est désormais une **glose française** — « Chute du corps », plus 体落 : D-297/D-312), **compte à rebours**.
- **Bloc « ENSUITE »** : pastille du rôle suivant, titre, **schéma de passage de rôle** (deux cercles + flèche) — l'aperçu du suivant est **la seule vraie nouveauté**, et ses données existent déjà.
- Contrôles : Pause · **Voix + bips** · **Prépa 3 s** (existent) ; Précédent · Quitter · Suivant.

## 8. **Agenda** (planche 1) — le seul écran neuf, et il vit DANS l'onglet Compositions

La barre basse de la maquette montre **Compositions** actif : l'Agenda est une
**vue de cet onglet**, pas un sixième onglet. *(Cela répond à la question
ouverte n° 4.)*

- En-tête : « Agenda » · *Planifie tes compositions à l'avance.* · action ronde.
- Bascule **Liste | Calendrier** (même donnée, deux rendus — jamais deux stockages).
- Bandeau de mois : `Mai 2025` · **Aujourd'hui** · ‹ › .
- **Bande de semaine** : 7 jours, aujourd'hui en pastille, **point sous les jours occupés**.
- **Carte « Rappel »** : cloche, `18:30 · <composition>`, **Voir** / ✕.
  → **In-app uniquement** : c'est le prochain créneau du jour, pas une notification système (lot E, chantier plateforme séparé). Le dire dans le libellé plutôt que de laisser croire à une alarme.
- **À venir** + Tout voir : cartes avec date, heure, Seul/À plusieurs, ⋮.
- CTA **＋ Planifier une composition**.
- **Donnée nouvelle** : `Planification { id, compositionId, date, heure? }` → collection persistée, **bump de schéma + migration additive**. Voyage dans une sauvegarde complète (à confirmer), **jamais dans un pack**.

## 9. Workflows (planches 9 et 10) — ce qu'ils imposent au découpage

- **Workflow 1** : trois entrées depuis Compositions (Mes / Packs / ＋ Créer), chacune finissant par une action claire (Démarrer, Dupliquer, Planifier), plus le bloc **Continuer**.
- **Workflow 2** : la création est un **couloir de 8 pas** qui se termine par un choix à trois (Démarrer / Reprendre / Planifier) — donc la planification doit exister pour que le couloir se ferme.
- L'« **Assistant de création** » (« quelques questions → structure personnalisée ») reste **local et déterministe** (arbitrage n° 2) : il préconfigure type, rôles et durées. Il ne **génère** aucun contenu.

## 10. Conflits avec des décisions en vigueur — résolutions proposées

| planche | ce qu'elle montre | décision en vigueur | résolution proposée |
|---|---|---|---|
| 6 | « Glissez les étapes » | D-233 : glisser-déposer retiré (WCAG 2.5.7) | **▲/▼ + action « Déplacer »** ; poignée décorative retirée |
| 7 | « invite d'autres personnes » | arbitrage n° 1 : ni compte, ni temps réel | « **prévois les rôles** » + partage par fichier |
| 4 | seconde ligne en kanji (体落) | D-297/D-312 : `nomTraditionnel` = glose française | la glose s'affiche ; le kanji ne revient pas |
| 5 | chip « Tous niveaux » | aucun champ de niveau sur `Composition` | **dériver** des techniques si elles convergent, sinon **omettre** |
| 8 | vouvoiement (« Choisissez… ») | l'application tutoie partout | **tutoiement** |
| 1 | carte « Rappel » | notifications = lot E séparé | **bandeau in-app** du prochain créneau, dit comme tel |
| 2, 1 | liseré coloré sans règle | — | **à trancher** (proposition : discipline dominante) |

## 11. Découpage révisé — par ÉCRAN, dans l'ordre où l'UI se tient

- **UI-1 — Liste Compositions** : grammaire de carte, bascule Mes/Packs, tri, ⋮ sur carte, sections. *(planches 2 et 3, aucune donnée nouvelle)*
- **UI-2 — Fiche de consultation** : **FAIT** (D-319) — `src/app/composition-fiche.ts` ;
  ouvrir mène à la lecture, l'édition passe par le ✎ ; méta dérivée, jalons non
  numérotés, aperçu de 5 dépliable, Démarrer fort / Dupliquer / Planifier
  désactivé (attend AG-1). Une composition à plusieurs garde son déroulé
  « en temps » plutôt qu'un aperçu plat. *(planche 5)*
- **UI-3 — Éditeur** : bandeau de stats, timeline, actions en ligne. *(planche 6)*
- **UI-4 — Ajout d'étape progressif** + entonnoir de création. *(planches 7 et 8)*
- **UI-5 — Lecteur** : hiérarchie + aperçu du suivant. *(planche 4)*
- **UI-6 — « Continuer »** : petite donnée locale (dernière lecture). *(planche 2)*
- **AG-1 — Agenda** : modèle `Planification`, vue Liste, planifier depuis une composition. *(planche 1)*
- **AG-2 — Calendrier** : second rendu de la même donnée. *(planche 1)*
- **E — Rappels système** : hors de ce chantier.

Chaque écran = une boucle, avec son **INTENTION UTILISATEUR** écrite avant le
code (D-279) et ses e2e. `Planification` touche `src/domaine/` et la
validation : **relecture checker requise** sur AG-1.
