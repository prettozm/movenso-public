# RESTE — tout ce qui n'est pas fait

> **Type : vivant** · Une ligne par chantier, chacune **citant sa source**
> (décision, fiche, document). Règle de vie (D-288) :
>
> - un chantier qui se **termine** sort d'ici **dans le commit qui le clôt** —
>   il n'y a pas de « liste du terminé » : le journal
>   ([DECISIONS.md](DECISIONS.md)) EST cette liste, et Git garde la ligne
>   supprimée ;
> - un chantier qui **naît** entre ici dans le commit qui le fait naître ;
> - ce fichier ne porte **aucun détail** : il pointe. Le détail vit dans la
>   source citée — une copie divergerait (D-253).
>
> Les **P0/P1** vivent dans [STATE.md](STATE.md) (tableau de bord de reprise),
> pas ici. Les **limites assumées** vivent dans
> [KNOWN_LIMITATIONS.md](../KNOWN_LIMITATIONS.md) (D-216), pas ici.
>
> **États et propriétaires (D-289)** : chaque ligne du chemin critique porte
> qui la tient — `(porteur)`, `(agent)`, ou `(bloqué : <quoi>)` quand elle
> attend un échange ou un arbitrage. Ailleurs, le marqueur n'apparaît que
> s'il dit quelque chose. L'état vit **sur la ligne**, jamais dans un
> emplacement : déplacer un fichier pour dire son statut est une copie
> d'état qu'aucune garde ne tient.
>
> **Un sujet qui dépasse une ligne gagne une FICHE** : `lots/<sujet>.md`
> (le patron : [S1-10-dossier-stockage.md](lots/S1-10-dossier-stockage.md)),
> pointée depuis sa ligne. La fiche ne déménage **jamais** — c'est la ligne
> qui vit et meurt ici, et la clôture s'inscrit au journal.

## Chemin critique vers la v1

- `(porteur)` **REC-B4-001 sur appareil**, R0 d'abord — le P1 de STATE ;
  repasses manuels raccrochés : REC-243-001, REC-249-001, REC-255-001 (R7).
- `(agent, sur retour de recette)` **Correctifs de recette** qui en sortiront
  (seuls recevables sous gel D-240, avec le contenu et la dette structurelle).
- `(porteur)` **Relecture checker en session neuve** (D-280) : **34 commits
  jamais lus**, `87071a0..6108a0c` — micro-diff du résidu D-304, puis
  D-305 → D-318 (dont `validation.ts`, `rapprochement.ts`, `tools/publier.ts`).
  Les relectures `f4a467b..87071a0`, `851119a..e06aea4` et `6108a0c..96d1225`
  sont faites et traitées (D-303, D-304, D-326).
- `(agent, en cours)` **Compositions / séances — refonte UX/UI par écrans**
  (go porteur D-317/D-318) : UI-2 (D-319), UI-1 (D-320), UI-3 (D-321),
  UI-4 (D-322), UI-5 (D-323) et UI-6 (D-324) faites — reste **AG-1** (Agenda :
  `Planification`, bump de schéma, relecture checker requise) et **AG-2** — découpage et spécification dans la fiche
  [lots/compositions-seances.md](lots/compositions-seances.md) §11.
- `(agent, en cours)` **Ajustements vue par vue** (demande porteur du
  2026-08-14) : reprise de chaque écran, un à la fois, sur consigne du
  porteur. Fait : **état bibliothèque vierge** (D-328 → D-332) et **packs
  officiels** (D-333, maquette validée avant le code).
- `(bloqué : arbitrage porteur)` **Garde d'unicité des numéros de décision**
  (D-330) : deux entrées `327` ont coexisté, deux sessions ayant numéroté
  depuis la queue du fichier. `verifier:references` vérifie qu'une décision
  citée EXISTE, pas qu'un numéro est UNIQUE. ~5 lignes dans
  `outils/verifier-references.mjs` — non construite dans la boucle qui l'a
  découverte.
- `(agent, sur demande)` **Balayage des tirets cadratins dans TOUT le texte
  visible** (D-331) : la règle du porteur vaut pour le produit entier, la
  garde ne couvre aujourd'hui que l'écran de première ouverture. Beaucoup
  d'épingles e2e citent les textes concernés : c'est une boucle à part, pas
  un passage de `sed`.
- `(bloqué : arbitrage porteur)` **Apprendre les « à venir » à la garde du
  site** (D-333) : `verifier-catalogues.mjs` exige `href` sur chaque entrée,
  donc les disciplines sans pack ne peuvent pas vivre au catalogue. Modifier
  une garde du site passe par une PR, jamais par un dépôt direct.
- `(porteur)` **Fusion de la branche** `claude/movenso-reprise-oa46uj`.
- `(porteur)` **Keystore** : poser le secret `ANDROID_DEBUG_KEYSTORE_B64`
  (commande dans D-110) et écrire la procédure de sauvegarde — le P1 de STATE.
- `(porteur)` **Protéger `main` côté GitHub** (D-283) — droits
  d'administration.
- `(bloqué : arbitrage porteur)` **Publication automatisée** (D-283) : trois
  voies, préconisation (b).
- `(porteur)` **Contenu : versions détaillées des deux katas** (Goshin-jutsu,
  Nage-no-kata) — il les dicte (D-238/D-239).
- `(porteur)` **Soumission Play + bêta interne** — avec la note de
  réinstallation Judo/Jujitsu (D-247, KNOWN_LIMITATIONS).
- `(porteur)` **Config du lanceur de session** : ne plus assigner de branche
  de travail à `movenso-public` (constat D-284) — hors dépôt.

## Sessions dédiées réservées (sur demande explicite du porteur)

- `(bloqué : ouverture sur demande du porteur)` **Bandeau de persistance** —
  spécifié et arbitré (D-257/D-259), non implémenté.

## Post-v1 — chantiers nommés

- **PWA / service worker** : démarrage hors connexion, installation, mises à
  jour contrôlées de l'app web (D-163, S1.8 option B).
- **Registre des packs installés** : mémoriser la version éditoriale — champ
  optionnel, sans migration (D-222, KNOWN_LIMITATIONS).
- **Stockage hybride / emplacement choisi** `Documents/movenso` (D-167,
  dossier S1.10 option 2) — déclenchable sur besoin réel.
- **ZIP64** : exports au-delà de ~4 Go (D-166).
- **Fin de la décomposition de `racine.ts`** : navigation/pile et rendu à
  sortir par composition (D-274).
- **Compositions : embranchements** (variante, « si… alors », D-234) et
  **réaction ciblée** entre deux pas (D-235).
- **Compositions à rôles > 6** : mise en page au-delà de la colonne unique
  (D-231).

## Dette technique acceptée (surveillée, non planifiée)

- Médias **multi-Go non mesurés** en environnement contraint (REC-S2-016).
- **TalkBack** : traversée exhaustive non certifiée (D-172) — remontées
  utilisateur font foi.
- **21 délais fixes** assumés dans l'e2e (durées réelles, tailles OPFS).
- **Un dépôt réécrit les six packs même sans changement de contenu** (constat
  D-325, dépôt du 2026-08-13) : `publier` horodate le manifeste (`creeLe`), donc
  les 9 Mo de conteneurs changent d'octets à chaque publication alors que leur
  `bibliotheque.json` est identique. Sans effet utilisateur (le catalogue et les
  versions ne bougent pas, l'app ne voit pas de mise à jour), mais le diff d'une
  publication devient illisible et l'historique enfle. À traiter si le volume
  devient gênant — pas une complication à construire aujourd'hui (D-324).
- **Instabilité observée une fois, non caractérisée** (D-320) : le renommage de
  discipline de `demarrage-vide` (`parcours/demarrage-vide.mjs:253`) a échoué
  dans un parcours complet, puis passé seul et dans les exécutions suivantes.
  Course réelle probable entre la saisie, le `blur` et le `@change`. À
  **instruire** si elle revient (D-249) — surtout pas à temporiser.
- Comportements **natifs Android** hors portée e2e web (garde D-110,
  `Filesystem` D-106/D-111) — couverts par la recette appareil.
- Le reste est consigné dans
  [KNOWN_LIMITATIONS.md](../KNOWN_LIMITATIONS.md) (D-216).
