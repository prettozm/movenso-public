/**
 * La bibliothèque est-elle VIERGE ? — l'état de première ouverture (D-328).
 *
 * Jusqu'ici l'écran de bienvenue se déclenchait sur « aucune discipline ET
 * aucune technique » (`vues.ts`), ce qui est plus faible que ce qu'il
 * prétend : une bibliothèque dont il ne reste qu'une composition, un favori,
 * une fiche en corbeille ou la trace d'un pack installé n'est pas neuve — et
 * elle recevait pourtant l'écran « bienvenue, choisis comment commencer ».
 *
 * Vierge veut dire ici : **rien n'est jamais arrivé**. Aucun pack installé,
 * aucune technique, aucune composition, aucun contenu importé ni restauré, et
 * aucune trace d'un contenu qui aurait existé (corbeille, fusions, conflits,
 * éditions de packs). L'écran de départ n'apparaît QUE là.
 *
 * La règle se lit sur la FORME de l'état plutôt que sur une liste de champs
 * recopiée ici : tout ce qui est une collection de la bibliothèque est du
 * contenu, sauf les exceptions nommées ci-dessous. Une liste recopiée aurait
 * été une seconde source de vérité — et une collection ajoutée demain y
 * aurait manqué en silence (D-253).
 */

import type { Bibliotheque } from "./modele.ts";

/** Les collections qui ne sont PAS du contenu. `typesRelation` est SEMÉ par
 *  `bibliothequeVide()` (quatre types par défaut) : il est là avant tout
 *  geste, il ne peut donc pas témoigner d'un contenu. Toute autre entrée
 *  ajoutée ici doit dire pourquoi elle n'est pas du contenu. */
const COLLECTIONS_NEUTRES: ReadonlySet<string> = new Set(["typesRelation"]);

/** true : rien n'a jamais été installé, créé, importé ni restauré ici. */
export function bibliothequeVierge(b: Bibliotheque): boolean {
  return Object.entries(b).every(
    ([cle, valeur]) => !Array.isArray(valeur) || COLLECTIONS_NEUTRES.has(cle) || valeur.length === 0,
  );
}
