/**
 * PACKS OFFICIELS (S3 volet B, D-211/B2) : catalogue des packs publiés sur le
 * site public, consultable et installable depuis l'app — le pack transite par
 * le circuit d'import EXISTANT (proposition → confirmation → rapport, D-166) :
 * rien ne s'écrit sans accord, comme pour un fichier choisi à la main.
 *
 * Le catalogue vit dans `packs/index.json` À CÔTÉ de l'app sur le site public
 * (même origine → le CSP `connect-src 'self'` suffit, en web). Dans l'APK
 * (D-219), l'app n'est PAS servie par le site : les ressources se résolvent en
 * ABSOLU vers `SITE_PUBLIC` (CSP `connect-src` ouvert vers ce seul domaine).
 * Servie ailleurs (dev, e2e sans route), la requête échoue proprement →
 * état « catalogue injoignable », jamais un écran cassé.
 */
import type { MovensoApp } from "../racine.ts";
import { disciplinesSansPack } from "../disciplines-a-venir.ts";

/** Racine du site public — les packs officiels y vivent (`packs/`). Le dépôt
 *  de l'app a été renommé `movenso` le 2026-08-09 (D-254) ; movenso-public,
 *  lui, n'a pas bougé — c'est bien lui que vise cette URL. */
const SITE_PUBLIC = "https://prettozm.github.io/movenso-public/";

export interface PackOfficiel {
  id: string;
  title: string;
  version: string;
  itemCount?: string;
  summary?: string;
  href: string;
  downloadName: string;
  /** Champs publiés depuis toujours, montrés seulement depuis D-333. */
  discipline?: string;
  updatedAt?: string;
  statusLabel?: string;
  icon?: string;
  /** Identité du manifeste et édition publiée (D-333) : c'est par là qu'on
   *  reconnaît un pack DÉJÀ installé (`editionsPacks`, D-307). L'id du
   *  catalogue ne le permettait pas, ce n'est pas la même clé. */
  packId?: string;
  versionEditoriale?: number;
}

/* ILLUSTRATIONS du catalogue (D-333) : elles vivent sur le site, à côté des
   packs. Elles sont récupérées par `fetch` — le canal DÉJÀ ouvert par la CSP
   pour le catalogue (`connect-src`) — puis servies en `blob:`, que `img-src`
   autorise déjà. Les poser directement en `src` aurait exigé d'ouvrir
   `img-src` vers le site dans l'APK : une modification de la posture de
   sécurité pour un gain nul, et une PR obligatoire (CLAUDE.md).

   Les `blob:` ne sont jamais révoqués : ils vivent le temps de la session,
   pèsent ~330 Ko au total, et les révoquer casserait le rendu suivant. */
const illustrations = new Map<string, string>();

/** L'URL locale d'une illustration déjà chargée, sinon rien (la carte se rend
 *  sans image plutôt que de retarder l'écran). */
export function illustrationDe(chemin: string | undefined): string | undefined {
  const url = chemin ? illustrations.get(chemin) : undefined;
  return url || undefined;
}

/** Charge les illustrations manquantes, dans l'ordre reçu, et redessine au
 *  fil de l'eau. Une image absente n'est PAS une panne : le catalogue reste
 *  utilisable, seule la vignette manque. */
async function chargerIllustrations(app: MovensoApp, chemins: readonly (string | undefined)[]): Promise<void> {
  for (const chemin of chemins) {
    if (!chemin || illustrations.has(chemin)) continue;
    illustrations.set(chemin, ""); // réservé : jamais deux requêtes pour la même
    try {
      const rep = await fetch(urlSite(chemin), { cache: "force-cache" });
      if (!rep.ok) throw new Error(`HTTP ${rep.status}`);
      illustrations.set(chemin, URL.createObjectURL(await rep.blob()));
      app.requestUpdate();
    } catch { /* pas d'illustration, pas de drame */ }
  }
}

/** URL d'une ressource du site public. En WEB, relative à l'emplacement de
 *  l'app (`app/` sur le site → `../packs/…`) — même origine, e2e routable.
 *  En NATIF (Capacitor), absolue vers `SITE_PUBLIC` : l'app y est servie
 *  depuis l'appareil, le relatif ne mènerait nulle part (D-219). */
function urlSite(chemin: string): string {
  const capacitor = (window as { Capacitor?: { getPlatform?: () => string } }).Capacitor;
  const natif = (capacitor?.getPlatform?.() ?? "web") !== "web";
  return natif ? new URL(chemin, SITE_PUBLIC).toString() : new URL(`../${chemin}`, location.href).toString();
}

/** Charge (une fois) le catalogue des packs officiels. */
export async function chargerCataloguePacks(app: MovensoApp): Promise<void> {
  app.catalogueOfficiel = "chargement";
  app.requestUpdate();
  try {
    const rep = await fetch(urlSite("packs/index.json"), { cache: "no-cache" });
    if (!rep.ok) throw new Error(`HTTP ${rep.status}`);
    const brut: unknown = await rep.json();
    if (!Array.isArray(brut)) throw new Error("catalogue illisible");
    app.catalogueOfficiel = brut.filter(
      (p): p is PackOfficiel =>
        !!p && typeof p === "object"
        && typeof (p as PackOfficiel).id === "string"
        && typeof (p as PackOfficiel).title === "string"
        && typeof (p as PackOfficiel).href === "string"
        && typeof (p as PackOfficiel).downloadName === "string"
        && typeof (p as PackOfficiel).version === "string",
    );
  } catch {
    app.catalogueOfficiel = "indisponible";
  }
  app.requestUpdate();
  // Les illustrations suivent, sans bloquer l'écran : les packs d'abord (ce
  // qu'on vient chercher), les disciplines sans pack ensuite (l'invitation).
  if (Array.isArray(app.catalogueOfficiel))
    void chargerIllustrations(app, [
      ...app.catalogueOfficiel.map((p) => p.icon),
      ...disciplinesSansPack(app.catalogueOfficiel).map((d) => d.icon),
    ]);
}

/** Télécharge un pack officiel puis le remet au circuit d'import normal —
 *  la proposition chiffrée s'affiche, l'utilisateur confirme ou annule. */
export async function installerPackOfficiel(app: MovensoApp, p: PackOfficiel): Promise<void> {
  try {
    const fichier = await app.occuperPendant(`Téléchargement de « ${p.title} »…`, async () => {
      const rep = await fetch(urlSite(p.href), { cache: "no-cache" });
      if (!rep.ok) throw new Error(`HTTP ${rep.status}`);
      const blob = await rep.blob();
      return new File([blob], p.downloadName, { type: "application/octet-stream" });
    });
    await app.importerPack(fichier);
  } catch (e) {
    app.consignerEchec("MOV-E06", e);
    app.afficherToast(`Téléchargement impossible : ${e instanceof Error ? e.message : "réseau indisponible"}`, "alerte");
  }
}
