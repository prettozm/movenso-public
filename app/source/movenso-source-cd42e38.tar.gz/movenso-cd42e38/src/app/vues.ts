/** Gabarits des écrans de la Bibliothèque (racine, explorateur) et de la Fiche. */

import { html, nothing, type TemplateResult } from "lit";
import { keyed } from "lit/directives/keyed.js";
import type { Contribution, Famille, Media, Niveau, Technique } from "../domaine/modele.ts";
import { chercherTechniques } from "../domaine/recherche.ts";
import { doublonsPotentiels } from "../domaine/rapprochement.ts";
import { sectionRelationsFiche } from "./relations-visuelle.ts";
export { vignetteTechnique } from "./vignette.ts";
import { vignetteTechnique, pastilleNiveau, imageDeFamille } from "./vignette.ts";
import { urlImage } from "./services/images.ts";
import { idYoutubeValide, urlSure, domaineDe } from "../securite/liens.ts";
import { compositionsUtilisant } from "../domaine/composition.ts";
import { sourceDe } from "../domaine/modele.ts";
import { bibliothequeVierge } from "../domaine/vacuite.ts";
import { ecranPremiereOuverture } from "./bibliotheque-vierge.ts";
import { RELATIONS_VISUELLES } from "./fonctionnalites.ts";
import type { MovensoApp } from "./racine.ts";

/* ---------- petits utilitaires d'affichage ---------- */

const iconeLoupe = html`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>`;

/** Création depuis l'explorateur (S2.1/D-169, option V) : même garde de
 *  DOUBLON EXACT que la feuille Ajouter — jamais de doublon par inattention,
 *  la création distincte exige une confirmation explicite. L'écrivain reste
 *  unique (`creerTechnique`). */
function creerTechniqueAvecGarde(app: MovensoApp, d: { id: string; nom: string }, champ: HTMLInputElement): void {
  const nom = champ.value.trim();
  if (!nom) return;
  const exacte = doublonsPotentiels(app.bibliotheque!, d.id, nom).exacte;
  if (exacte) {
    // §5 : jamais de doublon par inattention — la création séparée s'assume.
    app.demanderConfirmation({
      titre: `« ${exacte.nom} » existe déjà dans ${d.nom}`,
      corps: "Créer quand même une technique distincte ?",
      bouton: "Créer quand même",
      action: () => { void app.creerTechnique(d.id, nom); champ.value = ""; },
    });
    return;
  }
  void app.creerTechnique(d.id, nom);
  champ.value = "";
}

/* ---------- racine de la Bibliothèque ---------- */

/** En-tête de marque — vit sur la racine de la Bibliothèque (lot 1 §4). */
function enTeteMarque(): TemplateResult {
  return html`<header class="marque">
    <img class="marque-logo" src="./movenso-mark-sombre.svg" width="40" height="40" alt="" aria-hidden="true">
    <div style="flex:1">
      <div class="nom">Movenso</div>
      <div class="devise">Ta mémoire du mouvement.</div>
    </div>
  </header>`;
}

/** Libellé lisible d'une source (« club-judo » → « Club judo »). */
export function nomSource(src: string): string {
  if (src === "local") return "Mon contenu";
  const propre = src.replace(/^pack-/, "").replaceAll("-", " ");
  return propre.charAt(0).toUpperCase() + propre.slice(1);
}

/** Nom éditorial d'une source de contribution (lot 3 §7/§17.F, boucle 3.7) :
 *  la valeur la plus PRÉCISE disponible — l'attribution de l'auteur, sauf si
 *  le nom du pack la contient en plus complet (« Club » ⊂ « Club judo ») ;
 *  jamais un slug, un UUID ou un id de pack brut ; « Moi » en repli
 *  personnel. Le MÊME libellé sert partout (titre de voix, légende,
 *  « Ce contenu vient de … », adaptation locale). */
export function nomEditorialSource(c: { attribution?: string; origine?: { pack: string } }): string {
  const attribution = c.attribution?.trim();
  const brut = c.origine ? nomSource(sourceDe(c)) : undefined; // D-320 : l'identité d'un pack est un ULID (D-247) ; un identifiant nu n'est pas un nom, et ce contrat l'interdit déjà
  const pack = brut && /^[0-9A-HJKMNP-TV-Z]{26}$/.test(brut) ? undefined : brut;
  if (attribution && pack && pack.length > attribution.length && pack.toLowerCase().includes(attribution.toLowerCase()))
    return pack;
  return attribution ?? pack ?? "Moi";
}

/** Résumé d'une discipline (lot 2 §2) : compteurs sur les IDENTITÉS réellement
 *  visibles — jamais l'addition brute des contributions ni un id de pack. */
export function resumeDiscipline(
  b: { techniques: Technique[]; contributions: Contribution[] },
  disciplineId: string,
): { identites: number; sources: number; plurivoix: number } {
  const dansD = b.techniques.filter((t) => t.disciplineId === disciplineId);
  const ids = new Set(dansD.map((t) => t.id));
  const sourcesParIdentite = new Map<string, Set<string>>();
  for (const t of dansD) sourcesParIdentite.set(t.id, new Set([sourceDe(t)]));
  const toutes = new Set<string>();
  for (const t of dansD) toutes.add(sourceDe(t));
  for (const c of b.contributions) {
    if (!c.techniqueId || !ids.has(c.techniqueId)) continue;
    toutes.add(sourceDe(c));
    sourcesParIdentite.get(c.techniqueId)?.add(sourceDe(c));
  }
  const plurivoix = [...sourcesParIdentite.values()].filter((s) => s.size > 1).length;
  return { identites: dansD.length, sources: toutes.size, plurivoix };
}

/* ---------- Bibliothèque unifiée (D-067) : une seule grille de TOUTES les
   disciplines ; la discipline devient un filtre compact parmi d'autres
   (source, famille, niveau), plus jamais une page préalable. ---------- */

function dedupParId<T extends { id: string }>(items: T[]): T[] {
  const vus = new Map<string, T>();
  for (const it of items) if (!vus.has(it.id)) vus.set(it.id, it);
  return [...vus.values()];
}

/** Clé de regroupement d'un niveau par NOM (D-127) : « 1 dan » venu de packs
 *  différents (donc des id distincts) = UN seul filtre, pas trois. */
function cleNiveau(n: { nom: string }): string {
  return n.nom.trim().toLowerCase().replace(/\s+/g, " ");
}
/** Dédup par nom normalisé — garde le premier (sa pastille, son ordre). */
function dedupParNom<T extends { nom: string }>(items: T[]): T[] {
  const vus = new Set<string>();
  return items.filter((x) => { const k = cleNiveau(x); if (vus.has(k)) return false; vus.add(k); return true; });
}

/** Index global famille/niveau par id — pour les libellés des vignettes,
 *  toutes disciplines confondues. */
function indexTaxonomies(b: { disciplines: { familles: Famille[]; niveaux: Niveau[] }[] }): {
  familleParId: Map<string, Famille>;
  niveauParId: Map<string, Niveau>;
} {
  return {
    familleParId: new Map(b.disciplines.flatMap((d) => d.familles).map((x) => [x.id, x])),
    niveauParId: new Map(b.disciplines.flatMap((d) => d.niveaux).map((x) => [x.id, x])),
  };
}

/** Vignette de grille (hiérarchie V2) : aperçu média, badge de la source (le
 *  pack d'origine — ce qui distingue deux fiches homonymes, D-067), famille,
 *  nom, niveau, et un cœur favori actionnable SANS ouvrir la fiche. */
/** Cœur favori standard (icône pleine si favori, contour sinon). */
function iconeCoeur(actif: boolean): TemplateResult {
  return html`<svg width="20" height="20" viewBox="0 0 24 24" fill=${actif ? "currentColor" : "none"}
    stroke="currentColor" stroke-width="2" aria-hidden="true">
    <path d="M12 20.5s-7.2-4.6-9.6-9C1 8.8 2.4 5.5 5.6 5.5c2 0 3.2 1.1 4.4 2.7 1.2-1.6 2.4-2.7 4.4-2.7 3.2 0 4.6 3.3 3.2 6-2.4 4.4-9.6 9-9.6 9Z"/>
  </svg>`;
}

function carteTechnique(
  app: MovensoApp,
  t: Technique,
  _familleParId: Map<string, Famille>,
  niveauParId: Map<string, Niveau>,
): TemplateResult {
  const source = sourceDe(t);
  const favori = app.estFavori(t.id);
  return html`<div class="carte-technique">
    <button class="carte-ouvrir" @click=${() => app.ouvrirFiche(t.id)}>
      <span class="carte-media">${vignetteTechnique(app, t, source)}</span>
      <span class="carte-nom">${t.nom}</span>
      ${t.nomTraditionnel ? html`<span class="carte-jp jp">${t.nomTraditionnel}</span>` : nothing}
      ${t.niveauxIds.length
        ? html`<span class="carte-sous">
            ${t.niveauxIds.map((nid) => {
              const n = niveauParId.get(nid);
              return n ? html`<span class="carte-niveau">${pastilleNiveau(n)}${n.nom}</span>` : nothing;
            })}
          </span>`
        : nothing}
    </button>
    <button class="coeur ${favori ? "actif" : ""}" aria-pressed=${favori}
      aria-label=${favori ? "Retirer des favoris" : "Ajouter aux favoris"} title=${favori ? "Retirer des favoris" : "Ajouter aux favoris"}
      @click=${(e: Event) => { e.stopPropagation(); void app.basculerFavori(t.id); }}>${iconeCoeur(favori)}</button>
  </div>`;
}

/** Style de la grille selon la densité choisie (D-087) : un nombre de colonnes
 *  fixe si l'utilisateur a réglé la densité, sinon la grille responsive par
 *  défaut (chaîne vide → la CSS décide). */
function styleGrilleDensite(app: MovensoApp): string {
  const dens = app.preferences.densiteBibliotheque;
  return dens ? `grid-template-columns:repeat(${dens},1fr)` : "";
}

/** Grille + filtres partagés. Racine : toutes les disciplines (la discipline
 *  est un filtre). Vue discipline : bornée à `disciplineForce`. Retourne le
 *  corps rendu et le nombre de techniques affichées. */
function vueBibliotheque(app: MovensoApp, disciplineForce?: string): { corps: TemplateResult; nombre: number } {
  const b = app.bibliotheque!;
  const f = app.filtres;
  const { familleParId, niveauParId } = indexTaxonomies(b);
  const maj = (patch: Partial<MovensoApp["filtres"]>) => app.majFiltres({ ...f, ...patch });
  const basculer = (cle: "niveauId" | "familleId" | "source", valeur: string) =>
    maj({ [cle]: f[cle] === valeur ? null : valeur } as Partial<MovensoApp["filtres"]>);
  // Changer de discipline PURGE les filtres qui n'existent plus dans le nouveau
  // périmètre (tuning : « si aucune sélection ne s'applique, le filtre saute »).
  // Une catégorie « ne-waza » ou un niveau propres au judo ne doivent pas rester
  // actifs — et masquer toute la grille — quand on bascule sur le jujitsu.
  const choisirDiscipline = (cible: string | null) => {
    const scope = cible ? b.disciplines.filter((d) => d.id === cible) : b.disciplines;
    const famIds = new Set(scope.flatMap((d) => d.familles.map((x) => x.id)));
    const srcSet = new Set(b.techniques.filter((t) => (cible ? t.disciplineId === cible : true)).map(sourceDe));
    // Niveau regroupé par NOM (D-127) : un « 1 dan » sélectionné SURVIT au
    // changement de discipline en se re-mappant sur le « 1 dan » de la cible ;
    // il ne saute que si la cible n'a aucun niveau de ce nom.
    const selNiv = f.niveauId ? niveauParId.get(f.niveauId) : undefined;
    const nomSel = selNiv ? cleNiveau(selNiv) : null;
    const niveauCible = nomSel ? (scope.flatMap((d) => d.niveaux).find((n) => cleNiveau(n) === nomSel)?.id ?? null) : null;
    app.majFiltres({
      ...f,
      disciplineId: cible,
      familleId: f.familleId && famIds.has(f.familleId) ? f.familleId : null,
      niveauId: niveauCible,
      source: f.source && srcSet.has(f.source) ? f.source : null,
    });
  };

  const disciplineActive = disciplineForce ?? f.disciplineId ?? null;
  const base = b.techniques.filter((t) => (disciplineActive ? t.disciplineId === disciplineActive : true));

  const sources = new Set<string>();
  for (const t of base) sources.add(sourceDe(t));

  const disciplinesScope = disciplineActive ? b.disciplines.filter((d) => d.id === disciplineActive) : b.disciplines;
  const familles = dedupParId(disciplinesScope.flatMap((d) => d.familles)).sort((a, z) => (a.ordre ?? 0) - (z.ordre ?? 0));
  // Niveaux regroupés par NOM (D-127) : un seul « 1 dan » même si trois packs
  // en apportent chacun un. Le filtre sélectionné vaut pour TOUS ses homonymes.
  const niveaux = dedupParNom(disciplinesScope.flatMap((d) => d.niveaux).sort((a, z) => (a.ordre ?? 0) - (z.ordre ?? 0)));
  const selNiveau = f.niveauId ? niveauParId.get(f.niveauId) : undefined;
  const nomNiveauSel = selNiveau ? cleNiveau(selNiveau) : null;
  const idsNiveauSel = nomNiveauSel
    ? new Set(disciplinesScope.flatMap((d) => d.niveaux).filter((n) => cleNiveau(n) === nomNiveauSel).map((n) => n.id))
    : null;
  const basculerNiveau = (n: Niveau) => maj({ niveauId: nomNiveauSel === cleNiveau(n) ? null : n.id });

  const vus = (f.texte.trim() ? chercherTechniques({ ...b, techniques: base }, f.texte, 999) : base)
    .filter((t) => (f.familleId ? t.familleId === f.familleId : true))
    .filter((t) => (idsNiveauSel ? t.niveauxIds.some((id) => idsNiveauSel.has(id)) : true))
    .filter((t) => (f.source ? sourceDe(t) === f.source : true))
    .filter((t) => (f.favorisSeuls ? app.estFavori(t.id) : true))
    .sort((a, z) => a.nom.localeCompare(z.nom, "fr"));

  const filtresActifs =
    (!disciplineForce && f.disciplineId !== null) ||
    f.niveauId !== null || f.familleId !== null || f.source !== null || f.favorisSeuls || f.texte.trim() !== "";
  const reinitialiser = () =>
    app.majFiltres({
      disciplineId: disciplineForce ? f.disciplineId : null,
      niveauId: null,
      familleId: null,
      source: null,
      favorisSeuls: false,
      texte: "",
    });

  // Filtre discipline (D-067, tuning post-V3) : la discipline se comporte comme
  // les filtres du dessous — elle restreint la MÊME grille, jamais une page
  // séparée. « Toutes » = la grille unifiée (défaut).
  const chipsDisciplines =
    !disciplineForce && b.disciplines.length >= 1
      ? html`<div class="chips-filtres defilable" aria-label="Disciplines">
          <button class="chip-filtre ${f.disciplineId === null ? "actif" : ""}"
            @click=${() => choisirDiscipline(null)}>Toutes</button>
          ${b.disciplines.map(
            (d) => html`<button class="chip-filtre chip-discipline ${f.disciplineId === d.id ? "actif" : ""}"
              @click=${() => choisirDiscipline(f.disciplineId === d.id ? null : d.id)}>${d.nom}</button>`,
          )}
        </div>`
      : nothing;

  const corps = html`
    <div class="recherche-ligne">
      <div class="recherche">
        ${iconeLoupe}
        <input type="search" placeholder="Rechercher une technique…" autocomplete="off" .value=${f.texte}
               aria-label="Rechercher une technique"
               @input=${(e: InputEvent) => maj({ texte: (e.target as HTMLInputElement).value })}>
      </div>
    </div>
    ${chipsDisciplines}
    ${familles.length > 1
      ? html`<div class="chips-filtres defilable" aria-label="Catégories">
          ${familles.map(
            (fa) => html`<button class="chip-filtre ${f.familleId === fa.id ? "actif" : ""}"
              @click=${() => basculer("familleId", fa.id)}>${fa.nom}</button>`,
          )}
        </div>`
      : nothing}
    ${niveaux.length
      ? html`<div class="chips-filtres defilable" aria-label="Niveaux">
          ${niveaux.map(
            (n) => html`<button class="chip-filtre ${nomNiveauSel === cleNiveau(n) ? "actif" : ""}"
              @click=${() => basculerNiveau(n)}>${pastilleNiveau(n)}${n.nom}</button>`,
          )}
        </div>`
      : nothing}
    ${filtresActifs
      ? html`<div class="chips-filtres">
          <button class="chip-filtre reinitialiser" @click=${reinitialiser}>✕ Réinitialiser les filtres</button>
        </div>`
      : nothing}

    ${vus.length
      ? html`<div class="grille" style=${styleGrilleDensite(app)}>${vus.map((t) => carteTechnique(app, t, familleParId, niveauParId))}</div>`
      : base.length === 0
        ? etatVide(app, disciplineForce ? b.disciplines.find((d) => d.id === disciplineForce)?.nom : undefined)
        : html`<p class="fil-vide sans-resultat" style="padding-top:14px">Aucune technique ne correspond à ces filtres.</p>`}
  `;
  return { corps, nombre: vus.length };
}

/** État vide : dans une discipline nommée → inviter à créer/importer ; sinon
 *  (racine sans aucune technique mais des disciplines) → message discret. */
function etatVide(app: MovensoApp, disciplineNom?: string): TemplateResult {
  if (disciplineNom) {
    return html`<div class="discipline-vide">
      <p class="fil-vide" style="padding-top:14px">« ${disciplineNom} » ne contient encore aucune technique.</p>
      <button class="bouton principal" style="margin:8px 18px 0; align-self:flex-start"
        @click=${(e: Event) => {
          const champ = (e.target as HTMLElement)
            .closest(".ecran")
            ?.querySelector<HTMLInputElement>(".actions-bibliotheque .creation-discipline input");
          champ?.scrollIntoView({ block: "center" });
          champ?.focus();
        }}>Créer la première technique</button>
      <button class="action-douce" style="margin-top:6px" @click=${() => app.choisirPackAImporter()}>
        ⤓ Importer un pack <span>(il peut compléter « ${disciplineNom} » ou en installer d'autres)</span>
      </button>
    </div>`;
  }
  return html`<p class="fil-vide sans-resultat" style="padding-top:14px">Aucune technique pour l'instant — importe un pack ou capture la tienne.</p>`;
}

/** Racine de l'onglet Bibliothèque (D-067) : une seule grille de TOUTES les
 *  techniques, filtres compacts — jamais de page préalable de sélection de
 *  discipline. L'écran de première ouverture ne s'affiche que sur une
 *  bibliothèque VIERGE (D-328, état du domaine) — jamais d'onboarding. */
export function gabaritBibliotheques(app: MovensoApp): TemplateResult {
  const vierge = bibliothequeVierge(app.bibliotheque!);
  return html`
    <div class="ecran ${vierge ? "ecran-vierge" : ""}">
      ${enTeteMarque()}
      ${vierge
        ? ecranPremiereOuverture({
            installerPackOfficiel: () => app.ouvrirPlusSection("packs-officiels"),
            importerDepuisFichier: () => app.choisirPackAImporter(),
            restaurerSauvegarde: () => app.choisirPackAImporter(),
            creerPremiereTechnique: () => { app.ajouter = { creation: true }; app.requestUpdate(); },
          })
        : vueBibliotheque(app).corps}
    </div>
  `;
}

/** Filtres de l'onglet Favoris — session, dynamiques selon les favoris. */
const etatFavoris: { texte: string; disciplineId: string | null; familleId: string | null; niveauId: string | null } = {
  texte: "", disciplineId: null, familleId: null, niveauId: null,
};

/** Onglet Favoris (D-071/D-073) : les techniques favorites, mêmes cartes à deux
 *  colonnes que la Bibliothèque, retrait direct depuis la carte ; recherche et
 *  filtres compacts construits à partir des favoris présents. */
export function gabaritFavoris(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  const { familleParId, niveauParId } = indexTaxonomies(b);
  const favoris = app.techniquesFavorites();
  const enTete = html`<header class="marque"><div style="flex:1"><div class="nom">Favoris</div>
    <div class="devise">Tes techniques marquées, à portée de main.</div></div></header>`;
  if (favoris.length === 0)
    return html`<div class="ecran">${enTete}
      <p class="fil-vide" style="padding:10px 18px">Aucun favori pour le moment. Ajoute-en depuis la Bibliothèque.</p></div>`;

  const f = etatFavoris;
  const maj = (patch: Partial<typeof etatFavoris>) => { Object.assign(etatFavoris, patch); app.requestUpdate(); };
  const basc = (cle: "disciplineId" | "familleId" | "niveauId", val: string) => maj({ [cle]: f[cle] === val ? null : val });
  // Valeurs de filtres présentes PARMI les favoris (dynamiques).
  const disciplines = b.disciplines.filter((d) => favoris.some((t) => t.disciplineId === d.id));
  const famIds = new Set(favoris.map((t) => t.familleId).filter(Boolean) as string[]);
  const familles = [...famIds].map((id) => familleParId.get(id)).filter((x): x is Famille => !!x);
  const nivIds = new Set(favoris.flatMap((t) => t.niveauxIds));
  // Niveaux regroupés par NOM (D-127), comme la Bibliothèque.
  const niveaux = dedupParNom([...nivIds].map((id) => niveauParId.get(id)).filter((x): x is Niveau => !!x));
  const selNivFav = f.niveauId ? niveauParId.get(f.niveauId) : undefined;
  const nomNivFav = selNivFav ? cleNiveau(selNivFav) : null;
  const idsNivFav = nomNivFav
    ? new Set([...nivIds].filter((id) => { const n = niveauParId.get(id); return n ? cleNiveau(n) === nomNivFav : false; }))
    : null;
  const bascNiveauFav = (n: Niveau) => maj({ niveauId: nomNivFav === cleNiveau(n) ? null : n.id });

  const vus = (f.texte.trim() ? chercherTechniques({ ...b, techniques: favoris }, f.texte, 999) : favoris)
    .filter((t) => (f.disciplineId ? t.disciplineId === f.disciplineId : true))
    .filter((t) => (f.familleId ? t.familleId === f.familleId : true))
    .filter((t) => (idsNivFav ? t.niveauxIds.some((id) => idsNivFav.has(id)) : true))
    .sort((a, z) => a.nom.localeCompare(z.nom, "fr"));
  const actifs = f.texte.trim() !== "" || f.disciplineId || f.familleId || f.niveauId;

  return html`
    <div class="ecran">
      ${enTete}
      <div class="recherche-ligne">
        <div class="recherche">${iconeLoupe}
          <input type="search" placeholder="Rechercher dans mes favoris…" autocomplete="off" .value=${f.texte}
                 aria-label="Rechercher dans les favoris"
                 @input=${(e: InputEvent) => maj({ texte: (e.target as HTMLInputElement).value })}></div>
      </div>
      ${disciplines.length > 1
        ? html`<div class="chips-filtres" aria-label="Disciplines">
            ${disciplines.map((d) => html`<button class="chip-filtre ${f.disciplineId === d.id ? "actif" : ""}"
              @click=${() => basc("disciplineId", d.id)}>${d.nom}</button>`)}
          </div>`
        : nothing}
      ${familles.length > 1
        ? html`<div class="chips-filtres" aria-label="Catégories">
            ${familles.map((fa) => html`<button class="chip-filtre ${f.familleId === fa.id ? "actif" : ""}"
              @click=${() => basc("familleId", fa.id)}>${fa.nom}</button>`)}
          </div>`
        : nothing}
      ${niveaux.length > 1
        ? html`<div class="chips-filtres" aria-label="Niveaux">
            ${niveaux.map((n) => html`<button class="chip-filtre ${nomNivFav === cleNiveau(n) ? "actif" : ""}"
              @click=${() => bascNiveauFav(n)}>${pastilleNiveau(n)}${n.nom}</button>`)}
          </div>`
        : nothing}
      ${actifs
        ? html`<div class="chips-filtres"><button class="chip-filtre reinitialiser"
            @click=${() => maj({ texte: "", disciplineId: null, familleId: null, niveauId: null })}>✕ Réinitialiser</button></div>`
        : nothing}
      ${vus.length
        ? html`<div class="grille">${vus.map((t) => carteTechnique(app, t, familleParId, niveauParId))}</div>`
        : html`<p class="fil-vide sans-resultat" style="padding-top:14px">Aucun favori ne correspond à ces filtres.</p>`}
    </div>
  `;
}

/** Vue d'UNE discipline (accès direct : démarrage, rapport d'import, Atelier).
 *  La même grille unifiée, bornée à la discipline, avec sa création de
 *  technique — la discipline garde son écran dédié, la racine ne l'impose plus. */
export function gabaritDiscipline(app: MovensoApp, disciplineId: string): TemplateResult {
  const b = app.bibliotheque!;
  const d = b.disciplines.find((x) => x.id === disciplineId);
  if (!d) return html`<div class="ecran"><p class="fil-vide">Discipline introuvable.</p></div>`;
  const { corps, nombre } = vueBibliotheque(app, disciplineId);
  return html`
    <div class="ecran">
      <div class="barre">
        <button class="bouton-icone" aria-label="Retour" @click=${() => app.retour()}>
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M15 5l-7 7 7 7"/></svg>
        </button>
        <span class="contexte">${d.nom} · <span style="font-variant-numeric:tabular-nums">${nombre}</span> technique${nombre > 1 ? "s" : ""}</span>
      </div>
      ${corps}
      <div class="actions-bibliotheque">
        <div class="creation-discipline">
          <input placeholder="＋ Ajouter une technique (nom)…" aria-label="Nom de la nouvelle technique"
                 @keydown=${(e: KeyboardEvent) => {
                   if (e.key !== "Enter") return;
                   creerTechniqueAvecGarde(app, d, e.target as HTMLInputElement);
                 }}>
          <button class="bouton principal"
            @click=${(e: Event) => {
              const champ = (e.target as HTMLElement).parentElement!.querySelector("input")!;
              creerTechniqueAvecGarde(app, d, champ);
            }}>Créer</button>
        </div>
      </div>
    </div>
  `;
}

function nomFamille(app: MovensoApp, familleId: string | undefined): string {
  if (!familleId) return "";
  return app.bibliotheque!.disciplines.flatMap((d) => d.familles).find((f) => f.id === familleId)?.nom ?? "";
}

/* ---------- fiche ---------- */

/** Tous les médias d'une technique avec leur voix, ordonnés par autorité
 *  (référentiel d'abord) — sert le média principal et son sélecteur. */
function mediasDeTechnique(app: MovensoApp, t: Technique): { media: Media; contribution: Contribution }[] {
  const ordre: Record<string, number> = { referentiel: 0, enseignement: 1, ressource: 2, personnel: 3 };
  return app
    .bibliotheque!.contributions.filter((c) => c.techniqueId === t.id)
    .sort((a, z) => (ordre[a.provenance] ?? 9) - (ordre[z.provenance] ?? 9))
    .flatMap((c) => c.medias.map((media) => ({ media, contribution: c })));
}

export function gabaritFiche(app: MovensoApp, techniqueId: string): TemplateResult {
  const b = app.bibliotheque!;
  const t = app.technique(techniqueId);
  if (!t) return html`<div class="ecran"><p class="fil-vide">Technique introuvable.</p></div>`;

  const discipline = b.disciplines.find((d) => d.id === t.disciplineId);
  // Fiche mono-pack (D-067) : elle ne présente QUE le contenu de son pack —
  // ses contributions sourcées + le carnet personnel. Plus de fiche composite
  // multisource, plus de voix empilées, plus d'« adaptation locale ».
  const rang: Record<string, number> = { referentiel: 1, enseignement: 2, ressource: 3, personnel: 4 };
  const references = b.contributions
    .filter((c) => c.techniqueId === t.id && c.provenance !== "personnel")
    .sort((a, z) => (rang[a.provenance] ?? 9) - (rang[z.provenance] ?? 9));
  // La présentation lue : la contribution du pack qui porte réellement du texte,
  // sinon la première. Une seule — jamais un empilement de sources.
  const presentation = references.find((c) => (c.description ?? "").trim() || c.pointsCles.length) ?? references[0];
  const carnet = b.contributions
    .filter((c) => c.techniqueId === t.id && c.provenance === "personnel" && !c.attribution)
    .sort((a, z) => z.creeLe.localeCompare(a.creeLe));
  const utilisee = compositionsUtilisant(b, t.id);

  // Média principal en tête (hiérarchie V2, D-020.5) : choix explicite, sinon le
  // premier média disponible — jamais bloquant. Le média AFFICHÉ peut changer
  // pendant la session via le sélecteur horizontal.
  const medias = mediasDeTechnique(app, t);
  const principal = medias.find((x) => x.media.id === t.mediaPrincipalId) ?? medias[0];
  const affiche = medias.find((x) => x.media.id === app.mediaAffiche) ?? principal;
  const etiquetteMedia = (x: { media: Media }, i: number): string => x.media.label ?? `Vidéo ${i + 1}`;
  const favori = app.estFavori(t.id);
  const edition = app.editionFiche;
  // Tuning post-V3 (révise D-027) : toute source est éditable. Un contenu de
  // pack édité garde son origine ; sa signature « Modifié par … » est posée par
  // amenderContribution.
  const pointsClesTexte = (presentation?.pointsCles ?? []).join("\n");

  return html`
    <div class="ecran">
      <div class="barre fiche-barre">
        <span class="contexte">${t.nom}</span>
        <div class="fiche-actions">
          ${edition
            ? html`<button class="bouton-icone actif" aria-label="Enregistrer" title="Enregistrer et fermer l'édition"
                @click=${() => app.validerEditionFiche()}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7"/></svg>
              </button>`
            : html`<button class="bouton-icone" aria-label="Modifier" title="Modifier"
                @click=${() =>
                  app.autoriser("modification", `Saisis le PIN pour modifier « ${t.nom} ».`, () => {
                    app.entrerEditionFiche(t.id);
                  })}>
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3z"/><path d="M13.5 6.5l3 3"/></svg>
              </button>`}
          <button class="bouton-icone etoile-favori ${favori ? "actif" : ""}" aria-pressed=${favori}
            aria-label=${favori ? "Retirer des favoris" : "Ajouter aux favoris"}
            title=${favori ? "Retirer des favoris" : "Ajouter aux favoris"}
            @click=${() => void app.basculerFavori(t.id)}>${iconeCoeur(favori)}</button>
          ${edition || !RELATIONS_VISUELLES || !app.preferences.vueRelationBeta
            ? nothing
            : html`<button class="bouton-icone" aria-label="Voir en graphe" title="Voir les relations dans la Carte (bêta)"
                @click=${() => app.ouvrirRelationsVisuelle(t.id, "mindmap")}>
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><circle cx="12" cy="5" r="2.3"/><circle cx="5" cy="18" r="2.3"/><circle cx="19" cy="18" r="2.3"/><path d="M12 7.3 6 16M12 7.3 18 16M6.5 18h11"/></svg>
              </button>`}
          ${edition
            ? nothing
            : html`<button class="bouton-icone" aria-label="Partager" title="Partager"
                @click=${() => void app.demanderPartageTechnique(t.id)}>
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><circle cx="18" cy="5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="19" r="2.6"/><path d="M8.3 10.7l7.4-4.3M8.3 13.3l7.4 4.3"/></svg>
              </button>`}
          ${edition
            ? html`<button class="bouton-icone" aria-label="Annuler l'édition" title="Annuler l'édition (défait les modifications)"
                @click=${() => void app.annulerEditionFiche()}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
              </button>`
            : html`<button class="bouton-icone" aria-label="Fermer" title="Fermer" @click=${() => app.retour()}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
              </button>`}
        </div>
      </div>

      ${edition ? editionTechnique(app, t) : ficheEntete(app, t, discipline)}

      ${edition ? nothing : banniereAlertes(t)}

      ${edition
        ? editionMedias(app, t, medias)
        : affiche
          ? html`<div class="media-principal">
              ${medias.length > 1
                ? html`<div class="chips-filtres media-choix" aria-label="Médias de la technique">
                    ${medias.map(
                      (x, i) => html`<button class="chip-filtre ${x.media.id === affiche.media.id ? "actif" : ""}"
                        @click=${() => { app.mediaAffiche = x.media.id; app.requestUpdate(); }}>${etiquetteMedia(x, i)}</button>`,
                    )}
                  </div>`
                : nothing}
              ${gabaritMedia(app, affiche.media, affiche.contribution.attribution)}
            </div>`
          : illustrationFiche(app, t)
            ? html`<div class="media-principal">
                <img class="couverture-fiche" src=${illustrationFiche(app, t)!.url} alt="">
                <div class="couverture-fiche-pied">
                  <span>${illustrationFiche(app, t)!.propre
                    ? "Illustration — aucune vidéo pour l'instant"
                    : "Illustration de la famille — aucune vidéo pour l'instant"}</span>
                  <button class="chip-filtre" @click=${() => (app.ajoutMedia = { techniqueId: t.id, provenance: "personnel" })}>🎞 Ajouter un média</button>
                </div>
              </div>`
            : html`<div class="media-principal media-absent">
              <div class="fil-vide" style="padding:0 0 8px">Aucun média pour l'instant — le geste se filme, se choisit ou se lie.</div>
              <button class="action-douce" @click=${() => (app.ajoutMedia = { techniqueId: t.id, provenance: "personnel" })}>
                🎞 Ajouter un média <span>(filmer, choisir un fichier ou coller un lien)</span>
              </button>
            </div>`}

      ${presentation && ((presentation.description ?? "").trim() || edition)
        ? html`<section class="bloc-lecture">
            <h2 class="section-titre">Description</h2>
            ${edition
              ? html`<textarea class="champ-note" style="min-height:80px" .value=${presentation.description ?? ""}
                  placeholder="Décris la technique…" aria-label="Description"
                  @change=${(e: Event) => void app.amenderContribution(presentation.id, { description: (e.target as HTMLTextAreaElement).value })}></textarea>`
              : html`<p>${presentation.description}</p>`}
            ${presentation.modifiePar && presentation.modifiePar !== "moi"
              ? html`<div class="geste modifie-par" style="padding-top:4px">Modifié par ${presentation.modifiePar}</div>`
              : nothing}
          </section>`
        : nothing}

      ${presentation && (presentation.pointsCles.length || edition)
        ? html`<section class="bloc-lecture">
            <h2 class="section-titre">Points clés</h2>
            ${edition
              ? html`<textarea class="champ-note" style="min-height:80px" .value=${pointsClesTexte}
                  placeholder="Un point clé par ligne" aria-label="Points clés"
                  @change=${(e: Event) => void app.amenderContribution(presentation.id, { pointsCles: (e.target as HTMLTextAreaElement).value.split("\n") })}></textarea>`
              : html`<ol class="points">${presentation.pointsCles.map((p) => html`<li>${p}</li>`)}</ol>`}
          </section>`
        : nothing}

      ${presentation?.variantes
        ? html`<section class="bloc-lecture"><p><em>${presentation.variantes}</em></p></section>`
        : nothing}

      ${RELATIONS_VISUELLES && app.preferences.vueRelationBeta ? sectionRelationsFiche(app, b, t) : nothing}
      ${utilisee.length && app.preferences.compositionsBeta
        ? html`<div class="liaisons">
            <h2 class="section-titre" style="padding:12px 0 0">Utilisée dans · ${utilisee.length} composition${utilisee.length > 1 ? "s" : ""}</h2>
            <div class="liaison-groupe">
              ${utilisee.map(
                (co) => html`<button class="puce-liaison" @click=${() => app.ouvrirComposition(co.id)}>${co.nom}</button>`,
              )}
            </div>
          </div>`
        : nothing}

      <section class="bloc-lecture commentaire">
        <h2 class="section-titre">Commentaire</h2>
        ${app.pinConfigure
          ? html`<p class="commentaire-zone">${carnet[0]?.description
                ? html`${carnet[0].description}`
                : html`<span class="fil-vide">Aucune note.</span>`}</p>
              <div class="geste" style="padding-top:4px">🔒 Lecture seule — un PIN protège cet appareil.</div>`
          : // Note PERSONNELLE auto-enregistrée à la PERTE DE FOCUS (`change`),
            // pas à la frappe : entre les deux, le DOM est en avance sur le
            // modèle, et c'est normal. Un rendu ordinaire ne doit donc JAMAIS
            // réécrire ce champ — sans quoi il efface une note en cours de
            // frappe (D-251). D'où le `.value=` simple : Lit compare à sa
            // dernière valeur commitée et ne touche à rien tant que le modèle
            // n'a pas bougé.
            // Mais la croix ✕ restaure justement le modèle À SA VALEUR
            // D'AVANT, donc égale au mémo : Lit sauterait l'écriture et
            // laisserait le texte abandonné à l'écran (D-249). `keyed` sur le
            // compteur d'annulations recrée alors le champ — le seul moment
            // où l'on veut écraser ce que porte le DOM.
            keyed(app.generationCarnet, html`<textarea class="champ-note commentaire-zone" style="min-height:72px" .value=${carnet[0]?.description ?? ""}
              placeholder="Ta note, ton repère — juste pour toi" aria-label="Commentaire"
              @change=${(e: Event) => {
                const v = (e.target as HTMLTextAreaElement).value;
                if (carnet[0]) void app.majContribution(carnet[0].id, v);
                else if (v.trim()) void app.ajouterNote(t.id, v);
              }}></textarea>`)}
      </section>
    </div>
  `;
}

/** Illustration à montrer EN TÊTE d'une fiche sans vidéo (D-224) : celle de la
 *  technique, sinon celle de sa FAMILLE (schéma 5) — dérivée, jamais recopiée.
 *  Le pied de l'image DIT laquelle des deux on regarde : une carte de famille
 *  s'annonce, elle ne se fait pas passer pour une photo de la technique. */
function illustrationFiche(app: MovensoApp, t: Technique): { url: string; propre: boolean } | null {
  const propre = t.couverture?.type === "fichier" ? urlImage(t.couverture.imageId) : null;
  if (propre) return { url: propre, propre: true };
  const famille = imageDeFamille(app, t);
  return famille ? { url: famille, propre: false } : null;
}

function ficheEntete(app: MovensoApp, t: Technique, discipline: { niveaux: { id: string; nom: string; couleur?: string; couleur2?: string }[] } | undefined): TemplateResult {
  const famille = nomFamille(app, t.familleId);
  return html`
    <div class="fiche-entete">
      ${famille ? html`<div class="fiche-famille">${famille}</div>` : nothing}
      <h1>${t.nom}</h1>
      ${t.nomTraditionnel ? html`<div class="jp">${t.nomTraditionnel}</div>` : nothing}
    </div>
    ${t.niveauxIds.length
      ? html`<div class="pastilles">
          ${t.niveauxIds.map((nid) => {
            const n = discipline?.niveaux.find((x) => x.id === nid);
            return n ? html`<span class="pastille">${pastilleNiveau(n)}${n.nom}</span>` : nothing;
          })}
        </div>`
      : nothing}
  `;
}

/** Édition contextuelle — sur la fiche, jamais un formulaire administratif (D-020).
 *  Tuning post-V3 : première case = titre, seconde = sous-titre ; discipline et
 *  catégorie en menus déroulants ; niveaux en cases à cocher. La suppression de
 *  la technique n'est plus ici — elle vit dans Plus › Techniques et gestion. */
function editionTechnique(app: MovensoApp, t: Technique): TemplateResult {
  const b = app.bibliotheque!;
  const d = b.disciplines.find((x) => x.id === t.disciplineId);
  return html`
    <div class="edition">
      <label class="etiquette-champ" for="champ-titre">Titre</label>
      <input id="champ-titre" class="champ-edition" .value=${t.nom} placeholder="Titre"
        @change=${(e: Event) => void app.majTechnique(t.id, { nom: (e.target as HTMLInputElement).value || t.nom })}>

      <label class="etiquette-champ" for="champ-sous-titre">Sous-titre</label>
      <input id="champ-sous-titre" class="champ-edition" .value=${t.nomTraditionnel ?? ""} placeholder="Sous-titre (optionnel)"
        @change=${(e: Event) => void app.majTechnique(t.id, { nomTraditionnel: (e.target as HTMLInputElement).value })}>

      <label class="etiquette-champ" for="champ-discipline">Discipline</label>
      <select id="champ-discipline" class="champ-edition"
        @change=${(e: Event) => void app.majTechnique(t.id, { disciplineId: (e.target as HTMLSelectElement).value })}>
        ${b.disciplines.map((disc) => html`<option value=${disc.id} ?selected=${disc.id === t.disciplineId}>${disc.nom}</option>`)}
      </select>

      ${d?.familles.length
        ? html`<label class="etiquette-champ" for="champ-categorie">Catégorie</label>
            <select id="champ-categorie" class="champ-edition"
              @change=${(e: Event) => {
                const v = (e.target as HTMLSelectElement).value;
                void app.majTechnique(t.id, { familleId: (v || undefined) as never });
              }}>
              <option value="" ?selected=${!t.familleId}>— aucune —</option>
              ${d.familles.map((f) => html`<option value=${f.id} ?selected=${f.id === t.familleId}>${f.nom}</option>`)}
            </select>`
        : nothing}

      ${d?.niveaux.length
        ? html`<div class="etiquette-champ">Niveaux</div>
            <div class="niveaux-coches">
              ${d.niveaux.map(
                (n) => html`<label class="niveau-coche">
                  <input type="checkbox" ?checked=${t.niveauxIds.includes(n.id)}
                    @change=${() =>
                      void app.majTechnique(t.id, {
                        niveauxIds: t.niveauxIds.includes(n.id) ? t.niveauxIds.filter((x) => x !== n.id) : [...t.niveauxIds, n.id],
                      })}>
                  ${pastilleNiveau(n)}<span>${n.nom}</span>
                </label>`,
              )}
            </div>`
        : nothing}

    </div>
  `;
}

/** Zone médias en ÉDITION (D-091) : « Ajouter » en tête, puis un bloc par média
 *  (titre → lecteur → « vidéo principale » + retrait), enfin la vignette de
 *  couverture. Un seul modèle mental : plus de sélecteur ni de rangées jumelles.
 *  La consultation garde le sélecteur + un seul lecteur (inchangé). */
function editionMedias(app: MovensoApp, t: Technique, medias: { media: Media; contribution: Contribution }[]): TemplateResult {
  return html`
    <div class="edition edition-medias">
      <div class="etiquette-champ">Médias</div>
      <button class="action-douce" @click=${() => (app.ajoutMedia = { techniqueId: t.id, provenance: "personnel" })}>
        🎞 Ajouter un média <span>(filmer, choisir un fichier ou coller un lien)</span>
      </button>
      ${medias.length === 0
        ? html`<p class="fil-vide" style="padding:6px 0">Aucun média — le geste se filme, se choisit ou se lie.</p>`
        : medias.map(({ media, contribution }, i) => blocMediaEdition(app, t, media, contribution, i, medias.length))}
      ${couvertureEdition(app, t, medias)}
    </div>
  `;
}

/** Un bloc média en édition : titre AVANT la vidéo, puis les actions du média
 *  (principale — badge si déjà, sinon bouton — et retrait). */
function blocMediaEdition(
  app: MovensoApp,
  t: Technique,
  media: Media,
  contribution: Contribution,
  i: number,
  total: number,
): TemplateResult {
  const estPrincipal = media.id === t.mediaPrincipalId || (!t.mediaPrincipalId && i === 0);
  return html`
    <div class="bloc-media-edition">
      <input class="champ-edition" .value=${media.label ?? ""} placeholder="Titre de la vidéo" aria-label="Titre de la vidéo"
        @change=${(e: Event) => void app.majMediaLabel(media.id, (e.target as HTMLInputElement).value)}>
      ${gabaritMedia(app, media, contribution.attribution)}
      <div class="bloc-media-actions">
        ${total > 1
          ? estPrincipal
            ? html`<span class="badge-principal">✓ Vidéo principale</span>`
            : html`<button class="chip-filtre"
                @click=${() => void app.majTechnique(t.id, { mediaPrincipalId: media.id }).then(() => app.afficherToast("Vidéo principale mise à jour ✓"))}>
                ★ Définir comme principale</button>`
          : nothing}
        <button class="bouton-retrait-media" aria-label="Retirer ce média"
          @click=${() => void app.retirerMedia(t.id, media.id)}>🗑 Retirer</button>
      </div>
    </div>
  `;
}

/** Contrôle « Vignette » (D-083) : importer une image (réduite), désigner la
 *  miniature d'une vidéo en ligne, ou retirer la vignette personnalisée. */
function couvertureEdition(app: MovensoApp, t: Technique, medias: { media: Media; contribution: Contribution }[]): TemplateResult {
  const youtube = medias.filter(({ media }) => media.type === "plateforme" && media.service === "youtube");
  return html`
    <div class="etiquette-champ">Vignette</div>
    <div class="couverture-edition chips-filtres">
      <label class="chip-filtre couverture-import">
        🖼 Importer une image
        <input type="file" accept="image/*" hidden
          @change=${(e: Event) => {
            const input = e.target as HTMLInputElement;
            const f = input.files?.[0];
            input.value = "";
            if (f) void app.definirCouvertureImage(t.id, f);
          }}>
      </label>
      ${youtube.map(
        ({ media }, i) => html`<button class="chip-filtre ${t.couverture?.type === "media" && t.couverture.mediaId === media.id ? "actif" : ""}"
          @click=${() => void app.definirCouvertureMedia(t.id, media.id)}>Miniature ${media.label ?? `vidéo ${i + 1}`}</button>`,
      )}
      ${t.couverture ? html`<button class="chip-filtre danger" @click=${() => void app.retirerCouverture(t.id)}>Retirer la vignette</button>` : nothing}
    </div>
    ${apercuCouverture(t)}
  `;
}

/** Aperçu de la vignette en cours d'édition. Le fichier peut manquer (image
 *  jamais posée, ou effacée hors de l'app) : dans ce cas on n'affiche rien
 *  plutôt qu'un cadre vide qui laisserait croire à une image noire. */
function apercuCouverture(t: Technique): TemplateResult | typeof nothing {
  const url = t.couverture?.type === "fichier" ? urlImage(t.couverture.imageId) : null;
  return url ? html`<div class="couverture-apercu"><img src=${url} alt="Vignette actuelle"></div>` : nothing;
}

/** Bandeau d'alerte réglementaire / de sécurité (D-136) — jamais une arête du
 *  graphe : un avertissement porté par la technique (ex. interdit en compétition). */
function banniereAlertes(t: Technique): TemplateResult {
  const alertes = t.alertes ?? [];
  if (!alertes.length) return nothing as unknown as TemplateResult;
  return html`${alertes.map(
    (a) => html`<div class="alerte alerte--${a.niveau}" role="note">
      <span class="alerte-icone" aria-hidden="true">⚠️</span>
      <div class="alerte-corps">
        <strong>${a.libelle}</strong>
        ${a.detail ? html`<span class="alerte-detail">${a.detail}</span>` : nothing}
        ${a.reference?.url && urlSure(a.reference.url)
          ? html`<a class="alerte-ref" href=${urlSure(a.reference.url)} target="_blank" rel="noopener noreferrer"
              title=${`Quitte Movenso — ${domaineDe(a.reference.url) ?? "lien externe"}`}>${a.reference.organisation ?? "Référence"}${a.reference.article ? ` · art. ${a.reference.article}` : ""} ↗</a>`
          : a.reference
            ? html`<span class="alerte-ref">${a.reference.organisation ?? "Référence"}${a.reference.article ? ` · art. ${a.reference.article}` : ""}</span>`
            : nothing}
      </div>
    </div>`,
  )}`;
}

/** Média : plateforme = embed opt-in (le réseau n'entre que sur un geste explicite — contrat §8). */
export function gabaritMedia(app: MovensoApp, m: Media, attribution?: string): TemplateResult {
  const deplie = app.mediasDeplies.has(m.id);
  // Un seul lecteur actif à la fois (NR-003-002) : déplier un média replie
  // les autres et met en pause toute vidéo locale en cours.
  const deplier = () => {
    app.mediasDeplies = new Set([m.id]);
    document.querySelectorAll("video").forEach((v) => v.pause());
    app.requestUpdate();
  };
  if (m.type === "plateforme" && m.service === "youtube") {
    // S1.3 : seul un IDENTIFIANT vérifié s'interpole dans l'embed — une ref
    // hostile (pack importé) devient du texte inerte, jamais une URL.
    if (!idYoutubeValide(m.ref))
      return html`<span class="joint" title="Référence vidéo invalide">🔗 vidéo en ligne non vérifiable</span>`;
    return deplie
      ? html`<div class="media-video"><iframe
            src="https://www.youtube-nocookie.com/embed/${m.ref}"
            title=${m.label ?? "Vidéo"} allow="encrypted-media; picture-in-picture" allowfullscreen></iframe></div>`
      : html`<button class="bouton-video" @click=${deplier}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>
          <span>${m.label ?? `Vidéo${attribution ? ` (${attribution})` : ""}`} — lecture en ligne</span>
        </button>`;
  }
  if (m.type === "lien") {
    // S1.3 : rien de non-https ne se charge — la donnée reste, en texte.
    const srcSure = urlSure(m.ref);
    if (!srcSure) return html`<span class="joint" title="Lien non https — jamais chargé">🔗 ${m.ref}</span>`;
    return deplie
      ? html`<div class="media-video"><video src=${srcSure} controls playsinline
          @play=${(e: Event) => { document.querySelectorAll("video").forEach((v) => { if (v !== e.target) v.pause(); }); }}></video></div>`
      : html`<button class="bouton-video" @click=${deplier}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>
          <span>${m.label ?? "Vidéo"} — lecture en ligne</span>
        </button>`;
  }
  // locale : lue depuis OPFS, hors ligne
  return html`<movenso-video-locale .app=${app} .mediaId=${m.id}></movenso-video-locale>`;
}
