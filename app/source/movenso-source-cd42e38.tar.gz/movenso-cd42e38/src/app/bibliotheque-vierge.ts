/**
 * Écran de PREMIÈRE OUVERTURE, la bibliothèque est vierge (D-311, D-328).
 *
 * Il ne s'affiche que sur l'état `bibliothequeVierge` du domaine : rien
 * n'a jamais été installé, créé, importé ni restauré ici.
 *
 * Quatre départs nommés, mais **pas égaux** (D-328) : « Installer un pack
 * officiel » est le chemin recommandé, c'est le seul qui remplit la
 * bibliothèque en un geste ; les trois autres supposent qu'on a déjà un
 * fichier, une sauvegarde, ou du temps.
 *
 * Vue neuve : elle reçoit ses RAPPELS, jamais `app` entière (D-204).
 */

import { html, type TemplateResult } from "lit";

/** Les quatre gestes de départ, fournis par la racine, jamais décidés ici. */
export interface DepartsPremiereOuverture {
  installerPackOfficiel: () => void;
  importerDepuisFichier: () => void;
  restaurerSauvegarde: () => void;
  creerPremiereTechnique: () => void;
}

/* Illustrations FOURNIES par le porteur (D-332), une par départ plus celle du
   filet. Elles remplacent les vignettes que j'avais dessinées à la main : le
   porteur les a jugées « pas très jolies », et il avait raison, une
   approximation faite au trait ne remplace pas un rendu.

   WebP à 192 px, fond transparent, obtenues des originaux 1254 px par le
   Chromium déjà installé (aucune bibliothèque ajoutée, D-282) : détourage des
   marges transparentes, réduction en une passe, export à 0,92. Les cinq pèsent
   68 Ko ; en PNG, même réduites à 128 px, elles en pesaient 129 et le budget de
   `dist/` n'en offrait que 109. C'est ce chiffre, et pas une préférence de
   format, qui a fait ajouter `.webp` à la liste blanche de `verifier-dist`.

   Servies depuis `public/img/` et citées par leur chemin, comme le logo
   (`./movenso-mark-sombre.svg`) : c'est le patron déjà éprouvé ici, y compris
   sur Android. Les IMPORTER depuis le TypeScript aurait été plus élégant
   (noms hachés), mais `vues.ts` est chargé par deux tests unitaires en Node
   pur, qui ne savent pas résoudre un `.webp` hors de Vite : deux tests rouges
   pour un nom de fichier haché, le compte n'y est pas. */

const ILLUSTRATIONS = {
  packOfficiel: "./img/depart-pack-officiel.webp",
  fichier: "./img/depart-fichier.webp",
  sauvegarde: "./img/depart-sauvegarde.webp",
  creer: "./img/depart-creer.webp",
  filet: "./img/depart-filet.webp",
} as const;

/** Une illustration de départ. Décorative : le libellé de la carte dit déjà
 *  tout, une description alternative ne ferait que répéter à la voix. */
const illustration = (url: string) => html`<img class="depart-illu" src=${url} alt="" aria-hidden="true" width="192" height="192" decoding="async">`;

/** Chevron d'entrée : chaque carte dit qu'elle mène quelque part. */
const CHEVRON = html`<span class="depart-chevron" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9.5 5 7 7-7 7"/></svg></span>`;

/** L'écran entier, en dessous de l'en-tête de marque. */
export function ecranPremiereOuverture(departs: DepartsPremiereOuverture): TemplateResult {
  return html`
    <div class="depart-corps">
      <p class="fil-vide depart-accroche">
        <b>Movenso est ta mémoire du mouvement</b> : tes techniques, tes repères
        et tes séances, dans ta propre bibliothèque.
      </p>
      <p class="fil-vide depart-intro">Elle démarre vide, choisis comment commencer :</p>
      <!-- D-311 : quatre départs NOMMÉS. « Importer un pack » seul cachait les
           deux chemins les plus utiles : le catalogue prêt à installer, et le
           retour d'une sauvegarde quand on change d'appareil.
           D-328 : le premier est RECOMMANDÉ, les trois autres sont des recours. -->
      <button class="action-douce action-depart depart-majeur" @click=${departs.installerPackOfficiel}>
        <span class="action-picto" aria-hidden="true">${illustration(ILLUSTRATIONS.packOfficiel)}</span>
        <span class="action-corps">Installer un pack officiel
          <span>Choisis ton ou tes starter packs : le plus rapide, connexion requise pour le téléchargement</span></span>
        ${CHEVRON}
      </button>
      <p class="fil-vide depart-mineurs-titre">Autres façons de commencer :</p>
      <button class="action-douce action-depart" @click=${departs.importerDepuisFichier}>
        <span class="action-picto" aria-hidden="true">${illustration(ILLUSTRATIONS.fichier)}</span>
        <span class="action-corps">Importer un pack depuis un fichier
          <span>un <code>.movpack</code> qu'on t'a transmis</span></span>
        ${CHEVRON}
      </button>
      <button class="action-douce action-depart" @click=${departs.restaurerSauvegarde}>
        <span class="action-picto" aria-hidden="true">${illustration(ILLUSTRATIONS.sauvegarde)}</span>
        <span class="action-corps">Restaurer une sauvegarde
          <span>tu changes d'appareil : choisis ta sauvegarde complète</span></span>
        ${CHEVRON}
      </button>
      <button class="action-douce action-depart" @click=${departs.creerPremiereTechnique}>
        <span class="action-picto" aria-hidden="true">${illustration(ILLUSTRATIONS.creer)}</span>
        <span class="action-corps">Créer ta première technique
          <span>partir d'une bibliothèque vierge : son nom et sa discipline suffisent</span></span>
        ${CHEVRON}
      </button>
      <p class="depart-filet">
        <span class="depart-filet-picto">${illustration(ILLUSTRATIONS.filet)}</span>
        <span>Tes données et vidéos restent sur cet appareil. Pense à créer une
        sauvegarde de temps en temps (Plus › Sauvegardes), c'est ton filet.</span>
      </p>
    </div>
  `;
}
