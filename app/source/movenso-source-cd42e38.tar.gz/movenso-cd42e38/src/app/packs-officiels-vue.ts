/**
 * Écran « Packs officiels » (B2, D-211 ; refondu D-333) — VUE À DONNÉES
 * CIBLÉES (conventions §13/D-204 : pas de MovensoApp ici) : le catalogue
 * publié sur le site, chaque pack installable via le circuit d'import normal.
 * États honnêtes : chargement, catalogue injoignable (hors ligne, dev, APK
 * avant ouverture du CSP), catalogue vide.
 *
 * D-333, sur maquettes du porteur : une illustration par pack, l'avertissement
 * « des bases pour commencer » en tête, le badge de maturité, l'état installé,
 * et les disciplines qui n'ont pas encore de pack.
 */
import { html, nothing, type TemplateResult } from "lit";
import type { PackOfficiel } from "./services/packs-officiels.ts";
import { illustrationDe } from "./services/packs-officiels.ts";
import { disciplinesSansPack } from "./disciplines-a-venir.ts";
import { carteSection } from "./atelier-commun.ts";

/** Édition d'un pack telle qu'installée ici (D-307), réduite à ce dont
 *  l'écran a besoin : quelle édition, pour quelle identité de pack. */
export interface EditionInstallee { pack: string; versionEditoriale: number }

const ICONE_TELECHARGER = html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"/><path d="m7.5 10.5 4.5 4.5 4.5-4.5"/><path d="M4 18v1.5A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5V18"/></svg>`;
const ICONE_POSE = html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7"/></svg>`;

/** L'avertissement d'entrée : ce que ces packs sont, et ce qu'ils ne sont pas.
 *  Le lieu de pratique y vit avec le reste (D-333) plutôt que dans un second
 *  encart : c'est la même mise en garde, et deux encarts se lisent moins qu'un. */
const AVERTISSEMENT = html`
  <section class="pack-avert">
    <img class="pack-avert-ecusson" src="./img/depart-filet.webp" alt="" aria-hidden="true" width="192" height="192" decoding="async">
    <div>
      <h3>Des bases pour commencer</h3>
      <p>Ces packs sont des bases pour progresser à <b>ton rythme</b>. Ils ne sont
      pas exhaustifs et ne remplacent pas <b>l'enseignement d'un professeur qualifié</b>.</p>
      <p class="pack-avert-lieu"><b>Pratique dans un lieu adapté</b> : surface souple,
      espace dégagé autour de toi, rien qui traîne, et un partenaire d'accord et à ta mesure.</p>
      <p>Adapte toujours les exercices à ton niveau et à ton contexte : la pratique
      peut entraîner des blessures.</p>
    </div>
  </section>`;

/** Ce qu'on sait de l'installation d'un pack : rien, à jour, ou en retard. */
function etatInstallation(p: PackOfficiel, editions: readonly EditionInstallee[]): "absent" | "ajour" | "retard" {
  const posee = p.packId ? editions.find((e) => e.pack === p.packId) : undefined;
  if (!posee) return "absent";
  return p.versionEditoriale !== undefined && p.versionEditoriale > posee.versionEditoriale ? "retard" : "ajour";
}

function cartePack(p: PackOfficiel, etat: ReturnType<typeof etatInstallation>, installer: () => void): TemplateResult {
  const url = illustrationDe(p.icon);
  return html`
    <article class="pack-officiel ${etat === "retard" ? "pack-maj" : ""}">
      <div class="pack-officiel-entete">
        <span class="pack-rond">${url ? html`<img src=${url} alt="" aria-hidden="true" decoding="async">` : nothing}</span>
        <span class="pack-officiel-titres">
          <span class="pack-officiel-nom">${p.title}${p.statusLabel
            ? html`<span class="pack-badge ${p.statusLabel.toLowerCase()}">${p.statusLabel}</span>`
            : nothing}</span>
          <span class="pack-officiel-version">v${p.version}${p.updatedAt ? ` · ${p.updatedAt}` : ""}${
            etat === "retard" ? html` · <b>mise à jour disponible</b>` : nothing}</span>
        </span>
      </div>
      ${p.itemCount ? html`<div class="pack-officiel-meta">${p.itemCount}</div>` : nothing}
      ${p.summary ? html`<p class="pack-officiel-resume">${p.summary}</p>` : nothing}
      ${etat === "ajour"
        ? html`<div class="pack-officiel-installer pose">${ICONE_POSE} Installé</div>`
        : html`<button class="pack-officiel-installer" @click=${installer}>
            ${ICONE_TELECHARGER} ${etat === "retard" ? "Mettre à jour" : "Télécharger et importer"}
          </button>`}
    </article>`;
}

/** Les disciplines sans pack : une invitation, pas une promesse. Le texte le
 *  dit, parce qu'aucune de ces cases n'est en cours de fabrication. */
function sectionAVenir(catalogue: readonly PackOfficiel[]): TemplateResult | typeof nothing {
  const venir = disciplinesSansPack(catalogue);
  if (venir.length === 0) return nothing;
  return html`
    <h3 class="pack-section-titre">À venir</h3>
    <p class="details" style="padding:0 2px 8px">Aucun pack n'existe encore pour ces
    disciplines. Tu en enseignes une ? Movenso sait fabriquer un pack depuis ta propre
    bibliothèque, et tu peux le partager (Plus › Créer ou exporter un pack).</p>
    <div class="pack-venir">
      ${venir.map((d) => {
        const url = illustrationDe(d.icon);
        return html`<div class="pack-venir-c">
          <span class="pack-rond petit">${url ? html`<img src=${url} alt="" aria-hidden="true" decoding="async">` : nothing}</span>
          <span class="pack-venir-n">${d.nom}</span>
          <span class="pack-venir-e">À venir</span>
        </div>`;
      })}
    </div>`;
}

export function ecranPacksOfficiels(
  catalogue: PackOfficiel[] | "chargement" | "indisponible" | null,
  agir: { installer: (p: PackOfficiel) => void; recharger: () => void },
  editions: readonly EditionInstallee[] = [],
): TemplateResult {
  if (catalogue === null || catalogue === "chargement")
    return carteSection("Packs officiels", html`<p class="fil-vide" style="padding:6px 0">Chargement du catalogue…</p>`);
  if (catalogue === "indisponible")
    return carteSection("Packs officiels", html`
      <p class="fil-vide" style="padding:6px 0 10px">
        Catalogue injoignable : il vit sur le site public de Movenso et demande
        une connexion. Tu peux aussi importer un fichier .movpack à la main
        (Plus › Importer un pack).
      </p>
      <button class="action-douce" @click=${agir.recharger}>Réessayer</button>
    `);
  if (catalogue.length === 0)
    return carteSection("Packs officiels", html`<p class="fil-vide" style="padding:6px 0">Aucun pack publié pour l'instant.</p>`);
  return carteSection("Packs officiels", html`
    ${AVERTISSEMENT}
    <p class="details" style="padding:0 2px 8px">Chaque pack s'installe après un
      rapport d'import : rien ne s'écrit sans ton accord, et tout se retire.</p>
    ${catalogue.map((p) => cartePack(p, etatInstallation(p, editions), () => agir.installer(p)))}
    ${sectionAVenir(catalogue)}
  `);
}
