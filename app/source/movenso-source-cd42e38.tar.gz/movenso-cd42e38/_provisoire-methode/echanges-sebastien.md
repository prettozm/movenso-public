# Cohérence mémoire entre sessions — notes de méthode

> Provisoire, destiné à un dépôt dédié (externaliser ce workflow pour de
> nouveaux projets). Notes prises le 2026-08-14 depuis une session Movenso
> « checker », et depuis des échanges avec **Sébastien Arana**, qui construit
> en parallèle un système parent (`vault-ia`).
>
> Les décisions Movenso citées (D-xxx) renvoient à `docs/execution/DECISIONS.md`
> du dépôt Movenso — à ne PAS recopier ici (une copie diverge). On les cite
> comme sources, pas comme contenu.

---

## Partie A — le processus (réponse à « comment tenir la mémoire entre sessions »)

**Le problème.** Des sessions reprises **une à une, séquentiellement**. Risques :
un lot non fini, une dérive sur des points non vus, et la fenêtre de contexte
qui sature en pleine boucle.

### 1. Principe fondateur : la mémoire vit dans le dépôt, jamais dans la conversation
Une session qui reprend ne se fie pas à ce qu'une session précédente « se
souvient » — elle **relit l'état sur disque** et le tient pour vrai contre sa
propre mémoire conversationnelle. La bonne question n'est pas « comment garder
le fil » mais « comment le rendre **reconstructible à froid en ~2 min** par
quelqu'un qui n'était pas là ».

### 2. Trois fichiers, trois rôles — la séparation fait tout
- **`STATE.md` = le présent, rien que le présent** (tableau de bord : boucle
  courante, P0/P1, prochaine action exacte). Aucun historique. *Un STATE qui
  raconte est un STATE qu'on ne lit plus* (Movenso D-275).
- **`DECISIONS.md` = le *pourquoi*, journal append-only.** Piège central : une
  décision ancienne peut avoir été **annulée par une plus récente sans que rien
  ne le signale à l'endroit où on la lit**. On ne lit donc **jamais le journal
  en entier** — seulement les décisions que `STATE` **désigne**, plus la queue
  récente (D-276).
- **`systeme.md` / `workflows.md` = la vérité courante.** S'ils contredisent le
  journal, **eux priment**, et l'écart est un **défaut à corriger**.
- **`RESTE.md` = tout ce qui n'est pas fait**, une ligne par chantier, chacune
  portant **qui la tient** — `(porteur)` / `(agent)` / `(bloqué : quoi)`
  (D-288/D-289). Un fil en suspens n'est jamais « dans une conversation qui a
  scrollé » : il est sur une ligne que la prochaine session lit.

### 3. Les faits sont *générés*, pas écrits à la main
Compteurs (tests, chapitres e2e), versions, tailles de fichiers → dérivés par
script (`npm run etat`) et une garde **refuse le moindre écart**
(`verifier:etat`). *« Claude peut oublier. La machine, non. »* (D-275) Une
session qui reprend ne peut pas hériter d'un chiffre faux.

### 4. Les gardes rendent la discipline **mécanique**
- **présent à jour** : tout changement de code sans mise à jour de `STATE.md`
  est **refusé**, en local ET en CI (D-014/D-300). Tu ne *peux pas* laisser le
  tableau de bord périmé.
- **references** : une version qui a bougé, une décision citée inexistante, une
  dépendance non déclarée → refus.
- **cliquet** : l'archi ne peut pas régresser en douce (taille structurelle qui
  ne remonte jamais, D-278).

« Penser à mettre à jour la mémoire » devient « le build refuse si tu ne l'as
pas fait ». Corollaire (D-253) : *une garde que rien n'exécute est une consigne
de plus.*

### 5. L'unité de travail : la boucle, verte ou jetée
Une **boucle verticale courte** = un seul comportement utilisateur (formulable
en une phrase), qui finit par un **commit vert + STATE à jour dans le même
commit** (doc amendée au fil de l'eau). Un lot = une suite de boucles finies +
un checkpoint. Conséquence :
- **Crasher entre deux boucles n'a aucun coût** : le dernier commit vert est un
  point de reprise complet, `STATE` dit la prochaine action.
- **Le seul risque, c'est de mourir *dans* une boucle** → le travail non
  committé est **jeté** (pas rafistolé), la boucle redémarre depuis `STATE`.
  D'où l'exigence : les boucles restent petites.

### 6. La fenêtre de contexte = un **cadran qualité/coût**, pas un risque de correctness
- Comme rien de à-moitié-écrit ne survit, saturer la fenêtre ne peut pas laisser
  un **état faux** sur disque. La peur habituelle (« perdre le fil » = « écrire
  une bêtise ») est **découplée** ici.
- Mais deux choses qui ne sont **pas** « juste des tokens » :
  1. **La fenêtre borne la taille d'un pas atomique** (la mémoire externe n'est
     rafraîchie qu'aux frontières de boucle) → contrainte de conception, pas
     coût. C'est *pour ça* que les boucles sont courtes.
  2. **La qualité se dégrade avant le mur** : un contexte à moitié plein rate ce
     qu'il a lu au début, se contredit — c'est la « dérive sur des points non
     vus ». Donc on **clôt et repart frais**, souvent. La vraie valeur de la
     mémoire externe : *repartir à zéro coûte trois fois rien* (STATE = 120
     lignes, faits générés, journal non relu en entier).

### 7. Maker / checker : la session neuve comme *feature*
La relecture des zones à risque se fait en **session NEUVE, surtout pas une
reprise** (D-280) : l'absence de contexte partagé est ce qui donne sa valeur à
la relecture (le relecteur relit le *résultat*, pas son *intention*).
- **Nuance importante** : deux gestes distincts.
  - *Vérifier un correctif à un défaut soulevé par la MÊME session* → réutiliser
    le contexte est **correct** (vérif de suivi).
  - *Relire un NOUVEAU lot* → **session neuve** obligatoire.
- **Piège observé** : un checker qu'on **ne renouvelle pas** accumule le
  contexte qui le disqualifie → il dérive silencieusement en **second maker**
  (partage les angles morts, s'ancre sur ses propres verdicts passés). La
  continuité entre relectures ne doit **pas** vivre dans le contexte du checker
  mais **dans le journal** (verdict inscrit → un checker neuf le relit sur
  disque). Si on *ressent le besoin* de garder la session « pour qu'elle se
  souvienne », c'est le signal que le verdict n'a pas été assez écrit.
- Renouveler le maker aussi en fin de lot quand le contexte est lourd ; pour le
  checker c'est **non négociable** : neuf à chaque lot.

### 8. Honnêteté sur les limites
Certaines règles n'ont **aucune garde** et tiennent par discipline : écrire
l'INTENTION UTILISATEUR avant le code, valider une maquette avant une
interaction nouvelle (D-279), et le fait qu'une relecture ait *vraiment* eu lieu
en session neuve (D-280). Le **déclencheur** est calculé (`npm run checker`) ;
le **geste**, non. Le système est surtout du **tissu cicatriciel** : chaque
garde nomme l'accident qui l'a produite (6 commits rouges poussés en se fiant à
un vert local, D-270 ; une bonne valeur écrite à un second endroit qui diverge,
D-250/D-253).

---

## Partie B — relecture critique de ce que construit Sébastien

Sébastien transpose la même philosophie sur `vault-ia` (Obsidian + agents), et
la pousse plus loin en la rendant **native machine**. Deux pièces vues :

### B.1 — L'échelle de RÉSOLUTION (retrouver une note)
Échelle ordonnée **par coût, du déterministe vers le flou** :
`chemin explicite (~0) → wikilink/backlink (1 saut, graphe) → MOC du domaine →
recherche hybride BM25 + vecteurs`. **Boucle d'apprentissage** : un résultat
flou jugé *pertinent et récurrent* est **matérialisé en lien dans le MOC** → la
fois suivante il se résout au niveau déterministe. Le graphe se densifie le long
de l'usage réel, et la boucle **rentre au niveau MOC** (ne re-paie pas les
étapes d'avant).

**Excellent** : ne jamais payer une recherche quand un lien existe ;
**promouvoir le coûteux-mais-récurrent en cheap-et-durable**.

**Ce qui manque — la moitié « garde »** (ce que Movenso appareille toujours à un
« une information, un lieu ») :
1. **La boucle d'écriture mute la mémoire sur un jugement *flou*.** Un mauvais
   lien MOC est **pire que pas de lien** : il court-circuite la recherche qui
   aurait trouvé la vraie note, et le lecteur suivant le prend pour autorité.
   → prévoir une **invalidation** quand la cible bouge/est renommée/supprimée.
2. **« pertinent » et « récurrent » sont deux portes fusionnées en une.** Un
   résultat *récurrent-mais-faux* verrait sa mauvaise réponse **cimentée** — la
   boucle amplifie l'erreur systématique. Séparer : la récurrence *déclenche* ;
   la pertinence doit être **vérifiée** avant d'écrire.
3. **Pas de sortie « pas trouvé ».** Un agent obligé de toujours résoudre finit
   par **halluciner un lien**. (Movenso : la garde *refuse* plutôt qu'inventer.)
4. **Circularité MOC** : l'échelle suppose le MOC fiable, or c'est *la boucle*
   qui le tient → la phase de démarrage (MOC maigres) est la plus risquée en
   écritures.

### B.2 — Le JOURNAL DE DÉCISIONS natif machine (`vault-ia`)
Plus avancé que Movenso sur la partie « source unique + génération » :
- **Journal = source unique**, en **JSONL événementiel, un fichier par session**
  (`s-<ts>-<hash>.jsonl`). La prose (`specification-journal-decisions`) est une
  **vue engendrée**, jamais saisie. Supprime l'étape « l'humain écrit la prose »
  que Movenso garde encore (D-227 mot pour mot : « un index calculé pour l'humain
  ne peut pas être l'unique porteur d'un fait »).
- **Schéma riche & requêtable** : `enregistrement` = le *sujet* (= Movenso
  D-226), `statut` (question_ouverte / tranchee / sans-objet), `proprietaire`,
  `renvois`, `contenu{enonce, enjeu, ce_qui_trancherait}`. Requêtes via
  `decisions.py --repondre Qxx`, écriture via `--ecrire --type decision_tranchee`.
- **Cycle de vie par un COMPTE, pas par l'horloge** (`vault-ia-D308`) :
  `horodatage` est une donnée *saisie* que rien ne confronte à une horloge ; on
  compare le **nombre** de réouvertures/clôtures. = Movenso « une donnée fausse
  reste arbitre pour toujours » (D-285), résolu en dérivant.
- **Sharding un-fichier-par-session** : tue structurellement le lost-update
  (« deux sessions ont fait disparaître cinq entrées sans trace »).

**Questions checker (dans l'ordre de gravité) :**
1. **La prose engendrée est-elle *gardée* ?** Tout tient si elle est
   régénérée/lecture-seule, **refusée à l'édition manuelle**. Existe-t-il un
   `decisions.py --verifier` qui **échoue en CI si la prose diverge du
   journal** ? Sinon « vue engendrée » est une consigne, pas une garde.
2. **La vue marque-t-elle les décisions *périmées* ?** LE piège (D-276) : une
   décision annulée ressemble à une décision en vigueur. Il a la donnée
   (`statut` + généalogie) — la vue **consomme-t-elle** le statut pour barrer le
   remplacé, ou le liste-t-elle encore comme courant ?
3. **Nouveau porteur de confiance = `decisions.py`.** La prose n'étant plus
   porteuse, un bug de requête donne une réponse *confiante et fausse* sans
   recoupement. La logique de requête est-elle testée **dans les deux sens** (un
   test qui rougit sans le correctif) ? (`test_decisions.py`, `test_journal_core.py`
   présents — reste à vérifier la couverture des deux sens.)
4. **Clé d'ordre de confiance ?** D308 écarte l'horloge, mais généalogie et
   « le plus récent l'emporte » ont besoin d'un ordre. Lequel — le numéro
   `Dxxx` ? Est-il **monotone et non-collisionnable** entre sessions concurrentes
   (le D-number Movenso est posé à la main → duplication possible) ?
5. **Drapeau « complications d'horloger » (D-324).** Framework d'*aptitudes*
   (gestion-documentaire, harnais, identités-secrets, postures, rituel-de-session,
   coffre ; manifestes, genres, scellement, CORE-1..5) : riche au point de
   générer sa propre ontologie à trancher (« un module *sans verbe* : aptitude
   ou pièce partagée ? »). Question à poser avant de sceller une abstraction de
   plus : *qui la maintient, quel usage terrain l'a réclamée ?*

**Résumé pour Sébastien** : la moitié « source unique + génération » est plus
forte que Movenso ; ce qu'il reste à **prouver**, c'est la moitié « garde » —
une vérif exécutable qui refuse la prose divergente, et une vue qui *consomme*
le statut pour barrer le périmé.

---

## Partie C — primitives transférables (graine du futur dépôt)

Ce qui se réutilise tel quel pour n'importe quel projet piloté par sessions :

1. **La mémoire est dans le dépôt** ; toute session relit l'état à froid et le
   croit contre sa propre mémoire.
2. **Séparer présent / pourquoi / reste** en fichiers distincts ; ne jamais
   lire le journal en entier ; désigner ce qui doit l'être.
3. **Générer les faits, ne pas les saisir** ; une garde refuse l'écart.
4. **Une information, un lieu** ; toute duplication inévitable est tenue par une
   **garde exécutable**, jamais par une consigne.
5. **La boucle finit verte ou est jetée** ; doc dans le même commit ; le présent
   mis à jour dans le même commit (garde).
6. **Le contexte est un cadran qualité/coût** : boucles courtes, redémarrages
   fréquents, reconstruction bon marché par construction.
7. **Relecture en session neuve** ; continuité par le journal, pas par le
   contexte ; distinguer vérif-de-suivi (réutilise) et relecture-de-lot (neuve).
8. **Chaque garde nomme l'accident qui l'a produite** ; dire explicitement ce
   qui n'a *pas* de garde et tient par discipline.
9. **Vue engendrée = lecture seule + garde de non-divergence** (leçon renforcée
   par `vault-ia` : la génération sans garde retombe dans le double porteur).
10. **Marquer le périmé** dans toute vue dérivée d'un journal append-only (sinon
    un raisonnement annulé se lit comme en vigueur).
