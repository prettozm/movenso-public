# `_provisoire-methode/` — notes de méthode, en transit

**Statut : provisoire.** Ce dossier n'a rien à faire dans le dépôt produit
`movenso` : il est déposé ici **le temps de le migrer** vers un dépôt dédié,
dont l'objectif sera d'**externaliser ce workflow** (mémoire de mission,
gardes, boucle maker/checker) pour de **nouveaux projets**.

Rien ici n'est du code produit — aucune garde du dépôt ne le concerne. À la
création du nouveau dépôt : déplacer le dossier, puis le retirer d'ici dans le
même commit.

## Contenu

- [`echanges-sebastien.md`](echanges-sebastien.md) — la distillation des
  échanges (session Movenso checker, 2026-08-14) : le processus de cohérence
  mémoire entre sessions, et la relecture critique de ce que Sébastien Arana
  construit en parallèle (échelle de résolution Obsidian/MOC ; journal de
  décisions natif machine `vault-ia`).
- [`images/moteur-actuel.png`](images/moteur-actuel.png) — le moteur actuel,
  version complète (boucle + sous-système de vérification).
- [`images/moteur-actuel.svg`](images/moteur-actuel.svg) — **source
  reproductible** de l'image ci-dessus (SVG édité à la main, rendu en PNG via
  Chromium headless).
- [`images/moteur-simplifie.png`](images/moteur-simplifie.png) — variante
  allégée (la boucle seule), pour une slide.
