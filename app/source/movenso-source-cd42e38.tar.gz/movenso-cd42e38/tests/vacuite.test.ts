/** D-328 — l'état VIERGE de la bibliothèque : rien n'a jamais été installé,
 *  créé, importé ni restauré. C'est le seul état qui donne droit à l'écran de
 *  première ouverture. */

import { test } from "node:test";
import assert from "node:assert/strict";
import { bibliothequeVide, type Bibliotheque } from "../src/domaine/modele.ts";
import { bibliothequeVierge } from "../src/domaine/vacuite.ts";
import { bibliotheque, composition, disciplineJudo, technique } from "./aide.ts";

/** Une bibliothèque neuve, à laquelle on ajoute UNE collection non vide.
 *  Le prédicat ne regarde que la présence de contenu : le patch est donc
 *  volontairement structurel, pour couvrir toutes les collections sans
 *  fabriquer un objet métier par champ. */
const avec = (patch: Record<string, unknown[]>): Bibliotheque =>
  ({ ...bibliothequeVide(), ...patch }) as Bibliotheque;

test("vierge : une bibliothèque neuve l'est — les types de relation semés ne comptent pas", () => {
  const neuve = bibliothequeVide();
  assert.equal(neuve.typesRelation.length, 4, "quatre types sont semés par défaut");
  assert.equal(bibliothequeVierge(neuve), true);
});

test("vierge : un type de relation ajouté à la main ne fait pas un contenu", () => {
  const b = bibliothequeVide();
  b.typesRelation.push({ id: "prolonge", libelle: "Prolonge", symetrique: true });
  assert.equal(bibliothequeVierge(b), true);
});

test("PAS vierge : un pack installé (le mini-monde judo)", () => {
  assert.equal(bibliothequeVierge(bibliotheque()), false);
});

test("PAS vierge : une seule technique, sans rien d'autre", () => {
  const judo = disciplineJudo();
  assert.equal(bibliothequeVierge(avec({ disciplines: [judo], techniques: [technique(judo.id)] })), false);
});

test("PAS vierge : une composition seule — l'écran de départ ne doit pas revenir", () => {
  assert.equal(bibliothequeVierge(avec({ compositions: [composition()] })), false);
});

test("PAS vierge : chaque trace d'un contenu qui a existé compte", () => {
  // Corbeille, fusions, conflits, éditions de packs : tout cela raconte qu'un
  // contenu est passé par ici. Une bibliothèque qu'on a vidée n'est pas neuve.
  for (const cle of [
    "favoris",
    "contributions",
    "images",
    "corbeille",
    "fusions",
    "doublonsIgnores",
    "conflitsLiaisons",
    "conflitsContributions",
    "typesAlerte",
    "editionsPacks",
  ]) {
    assert.equal(bibliothequeVierge(avec({ [cle]: [{}] })), false, `« ${cle} » non vide doit rompre la virginité`);
  }
});

test("vierge : les collections optionnelles ABSENTES ne changent rien", () => {
  const { images, doublonsIgnores, ...sansOptionnelles } = bibliothequeVide();
  void images;
  void doublonsIgnores;
  assert.equal(bibliothequeVierge(sansOptionnelles as Bibliotheque), true);
});
